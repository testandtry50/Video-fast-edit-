# VideoSlide Maker — Native Android

A full native Android (Kotlin + Jetpack Compose) rewrite of the original web app. It keeps
every feature of the original 5-step wizard (Script → Photos → Match → Preview → Export),
fixes the two things that don't scale well in a browser tab (large photo files, and audio),
and adds a few genuinely new capabilities on top.

## How to open and build this

1. Install **Android Studio** (Koala/2024.1 or newer).
2. `File → Open`, select the `VideoSlideMaker` folder, let Gradle sync (it will download the
   wrapper automatically — no network is available in the sandbox this was written in, so the
   wrapper jar itself isn't bundled, but Android Studio fetches it on first sync).
3. Run on a device/emulator with **Android 8.0 (API 26) or newer**.
4. If Android Studio suggests a newer Kotlin/AGP/Compose BOM version during sync, accepting the
   upgrade is safe — the versions pinned here are simply the ones current at the time of writing.
5. Optional cleanup: `Code → Optimize Imports` across the project removes a handful of harmless
   unused imports left over from earlier drafts of a few files.

I wrote and reviewed every file carefully, but I don't have an Android SDK or emulator in the
sandbox this was built in, so **this hasn't been compiled or run**. Treat it as a complete,
serious first build rather than a guaranteed zero-error one — if Android Studio flags anything
small (an import, a version mismatch), it'll point straight at the line.

## What the app does (unchanged from your original)

1. **Script** — upload a `.txt` file of `timestamp - sentence` lines.
2. **Photos** — add a pool of photos, reorder, delete.
3. **Match** — go sentence by sentence, listen to it spoken aloud, split or merge sentences,
   and tap a photo to assign it.
4. **Preview** — play through the matched sequence at a faster preview speed.
5. **Export** — pick aspect ratio / resolution / zoom / fade, then render the real video.

Every one of these carried over — nothing was removed.

## The two problems you asked me to fix

**"Handle large file work properly."** The original app reads every photo into memory as a
base64 string via `FileReader`, and keeps all of them there for the whole session — fine for a
few small images, but slow and memory-heavy for a phone camera roll. `data/ImageStore.kt`
instead keeps only a content `Uri` and true pixel size per photo; thumbnails are decoded
downsampled (`BitmapFactory.Options.inSampleSize`) to whatever size is actually on screen, and
full resolution is only ever decoded one photo at a time, right before that photo's export
frames are rendered.

**"The audio."** In the original, the on-device voice (browser `speechSynthesis`) was only ever
used live, while matching a sentence to a photo — the exported video itself was always silent.
That's the one place I changed the app's actual behavior rather than just its plumbing: the same
voice is now synthesized to file and baked into the exported video as a real, timed audio track
(see "New features" below). I flagged this clearly rather than assuming — you can turn narration
off per-project on the Script screen if you'd rather keep silent exports.

## Architecture

```
app/src/main/java/com/videoslidemaker/app/
├── model/         Plain data classes: SentenceSlide, PoolImage, ExportSettings, UiState
├── data/          Script parsing, Uri-based photo storage, JSON draft autosave
├── tts/           Android TextToSpeech wrapper (live speech + synthesize-to-file)
├── export/        The video pipeline (see below)
├── viewmodel/     AppViewModel — single StateFlow<UiState>, one method per user action
├── ui/theme/      Colors/type ported from the original CSS
├── ui/components/ Reusable Compose widgets (cards, toggles, buttons, step bar)
├── ui/screens/    One file per wizard step
├── MainActivity.kt          Compose host + system file pickers (SAF)
└── VideoSlideMakerApp.kt    Notification channel setup
```

**Export pipeline** (`export/`): `VideoExportEngine` is the conductor. It computes the output
resolution, builds the final photo sequence (with the same "fall back to next unused photo"
rule as the original), synthesizes the combined audio timeline first, then renders and encodes
video frame-by-frame:

- `FrameRenderer` — cover-fit crop + Ken Burns zoom + fade, same math as the original canvas code.
- `Yuv420Writer` — converts each rendered frame to the YUV420 the encoder needs.
- `VideoEncoder` / `AudioEncoder` — MediaCodec H.264 / AAC, real presentation timestamps.
- `MuxerHolder` — combines both into one `.mp4` via MediaMuxer.
- `NarrationAudioBuilder` / `AudioDecoder` / `PcmResampler` / `WavUtils` — build the narration +
  music audio timeline described above.
- `ExportForegroundService` — runs all of this off the UI thread with a progress notification.

This replaces the original's `canvas.captureStream()` + `MediaRecorder`, which depends on
whatever codec the phone's browser happens to support and paces frames with `setTimeout`. The
native pipeline uses the device's real encoder with exact per-frame timing, so it doesn't drop
or duplicate frames and doesn't depend on browser codec support.

## What I improved (same feature, done more reliably)

- **Photo handling** — Uri-based, never loads a full photo into memory unless it's actively
  being drawn into a frame (see above).
- **Video encoding** — native MediaCodec/MediaMuxer instead of browser MediaRecorder.
- **Export reliability** — runs in a foreground service, so it keeps going if you switch apps,
  lock the screen, or the export takes a few minutes on a long project.
- **Saving the result** — goes straight into `Movies/VideoSlideMaker` via MediaStore (or the
  legacy public Movies folder on Android 9 and below), instead of a browser download.
- **Split-at-cursor** — uses Compose's real text cursor position instead of a DOM Range hack.

## New features added

- **Per-photo time control (latest addition).** Each photo on the Photos screen now has a
  tappable "⏱ 0:03" chip — tap it, type a time like `2:30` or `15:00`, save. To make that
  meaningful, the Script step became fully optional: if you don't load a script, the app
  automatically treats your photo pool as the timeline, one slide per photo in order, using
  each photo's own time. Match screen is skipped automatically in that case (there's nothing to
  match — each photo already maps to itself); Preview and Export both use whichever timeline is
  active. Loading a script still works exactly as before and takes priority if present.
- **Narration baked into the video** (see above) — on-device TTS per sentence, placed at that
  sentence's exact timestamp, mixed into the final MP4's audio track. Toggle it off on the
  Script screen if you want a silent export like before.
- **Optional background music** — pick an audio file on the Export screen; it's decoded, looped
  or trimmed to the video's length, and mixed underneath the narration at an adjustable volume.
- **Auto-saved project draft** — if you switch apps, rotate the phone, or Android reclaims memory
  in the background, your script, photos, and settings are restored automatically next time you
  open the app (`data/ProjectRepository.kt`). The original had no protection against a lost tab.
- **Share button** after export, using Android's native share sheet.

## Deliberately not changed / not added (so you know where I drew the line)

- The original's CSS hinted at drag-to-reorder photos (`.img-drag` classes) but never actually
  wired it up — only the up/down buttons worked. I kept the up/down buttons (100% reliable) and
  didn't add drag gestures on top, since a hand-rolled drag implementation is one of the riskier
  things to get right without being able to test it. It's a clean follow-up if you want it.
- The launcher icon is a simple placeholder (a purple square with a play glyph) so the project
  compiles out of the box — swap it via Android Studio's `Image Asset` tool for a polished icon.
- Typography uses the system font rather than bundling the original's Space Grotesk/Inter font
  files, again to avoid adding a dependency I couldn't verify without a network connection. Swap
  `FontFamily.Default` in `ui/theme/Type.kt` for bundled `.ttf` files if you want an exact match.

## Permissions

Only `POST_NOTIFICATIONS` (for export progress) and the foreground-service permissions are
requested up front. Photos, script, and music are all picked through Android's Storage Access
Framework, so the app never asks for broad photo-library or storage permission.
