# Add project specific ProGuard rules here.
# Compose, MediaCodec and TextToSpeech all use reflection-light standard Android APIs
# that don't need special keep rules beyond the defaults AGP already applies.

-dontwarn org.jetbrains.annotations.**
