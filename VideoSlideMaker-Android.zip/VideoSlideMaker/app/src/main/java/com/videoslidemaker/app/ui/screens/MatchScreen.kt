package com.videoslidemaker.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.videoslidemaker.app.data.ScriptParser
import com.videoslidemaker.app.model.AppStep
import com.videoslidemaker.app.model.UiState
import com.videoslidemaker.app.ui.components.AlertStyle
import com.videoslidemaker.app.ui.components.BadgeChip
import com.videoslidemaker.app.ui.components.CompactButton
import com.videoslidemaker.app.ui.components.PrimaryButton
import com.videoslidemaker.app.ui.components.ScreenTitle
import com.videoslidemaker.app.ui.components.SectionCard
import com.videoslidemaker.app.ui.components.SecondaryButton
import com.videoslidemaker.app.ui.components.SettingRow
import com.videoslidemaker.app.ui.components.ToggleSwitch
import com.videoslidemaker.app.ui.theme.Accent
import com.videoslidemaker.app.ui.theme.BorderColor
import com.videoslidemaker.app.ui.theme.CardBg
import com.videoslidemaker.app.ui.theme.Green
import com.videoslidemaker.app.ui.theme.Muted
import com.videoslidemaker.app.ui.theme.Surface
import com.videoslidemaker.app.ui.theme.TextMain
import com.videoslidemaker.app.viewmodel.AppViewModel

@Composable
fun MatchScreen(state: UiState, viewModel: AppViewModel) {
    if (!state.scriptLoaded) {
        Column(Modifier.fillMaxWidth().padding(16.dp)) {
            ScreenTitle("Match Photos to Sentences")
            SectionCard {
                Text(
                    "You're using simple mode — no script loaded, so there's nothing to match. " +
                        "Each photo already plays in order with the time you set for it.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Muted
                )
            }
            PrimaryButton("Skip to Preview →", modifier = Modifier.padding(top = 16.dp), onClick = { viewModel.goStep(AppStep.PREVIEW) })
            SecondaryButton("← Back to Photos", onClick = { viewModel.goStep(AppStep.PHOTOS) })
        }
        return
    }

    val idx = state.curMatchIndex
    val slide = state.slides.getOrNull(idx)
    val nextSlide = state.slides.getOrNull(idx + 1)

    if (slide == null) {
        Column(Modifier.fillMaxWidth().padding(16.dp)) {
            Text("No sentences to match yet.", color = Muted)
        }
        return
    }

    var textValue by remember(idx) { mutableStateOf(TextFieldValue(slide.text)) }
    var showSplitPanel by remember(idx) { mutableStateOf(false) }
    var splitTime by remember(idx) { mutableStateOf(slide.timestampSec + 1.0) }

    Column(
        Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        ScreenTitle("Match Photos to Sentences")
        BadgeChip("Sentence ${idx + 1} of ${state.slides.size}", AlertStyle.INFO, Modifier.padding(bottom = 12.dp))

        SectionCard(modifier = Modifier.padding(bottom = 12.dp)) {
            val slotEnd = nextSlide?.timestampSec ?: (slide.timestampSec + state.settings.defaultDurationSec)
            Text(
                "${ScriptParser.formatTime(slide.timestampSec)} – ${ScriptParser.formatTime(slotEnd)}",
                style = MaterialTheme.typography.labelMedium,
                color = Accent
            )
            BasicTextField(
                value = textValue,
                onValueChange = {
                    textValue = it
                    viewModel.editSentenceText(idx, it.text)
                },
                onTextLayout = {},
                textStyle = TextStyle(color = TextMain, fontSize = MaterialTheme.typography.bodyLarge.fontSize),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 10.dp)
                    .background(Surface, RoundedCornerShape(8.dp))
                    .padding(10.dp)
            )

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 4.dp)) {
                CompactButton("🔊 Listen", onClick = { viewModel.speakCurrentSentence() })
                CompactButton("✂️ Split", onClick = {
                    splitTime = (slide.timestampSec + slotEnd) / 2.0
                    showSplitPanel = !showSplitPanel
                })
                CompactButton("🔗 Merge ↓", enabled = nextSlide != null, onClick = { viewModel.mergeCurrentWithNext() })
            }

            if (showSplitPanel) {
                val minSplit = slide.timestampSec.toFloat() + 0.2f
                val maxSplit = slotEnd.toFloat() - 0.2f
                Column(Modifier.padding(top = 12.dp)) {
                    if (maxSplit > minSplit) {
                        Text(
                            "Split at ${ScriptParser.formatTime(splitTime)} — text splits at your cursor position",
                            style = MaterialTheme.typography.bodySmall,
                            color = Muted
                        )
                        Slider(
                            value = splitTime.toFloat().coerceIn(minSplit, maxSplit),
                            onValueChange = { splitTime = it.toDouble() },
                            valueRange = minSplit..maxSplit
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            CompactButton("Cancel", onClick = { showSplitPanel = false })
                            CompactButton("Confirm Split", onClick = {
                                val cursor = textValue.selection.start.coerceIn(0, textValue.text.length)
                                if (viewModel.splitCurrentSentence(cursor, splitTime)) {
                                    showSplitPanel = false
                                }
                            })
                        }
                    } else {
                        Text("This moment is too short to split.", style = MaterialTheme.typography.bodySmall, color = Muted)
                    }
                }
            }

            if (nextSlide != null) {
                Text(
                    "Next: ${nextSlide.text.ifBlank { "(no text)" }}",
                    style = MaterialTheme.typography.bodySmall,
                    color = Muted,
                    maxLines = 1,
                    modifier = Modifier.padding(top = 10.dp)
                )
            }
        }

        SettingRow("Auto-advance", "Move to next sentence after picking a photo") {
            ToggleSwitch(state.autoAdvance, viewModel::setAutoAdvance)
        }

        Text("Currently assigned", style = MaterialTheme.typography.labelMedium, color = Muted, modifier = Modifier.padding(top = 8.dp, bottom = 8.dp))
        val assignedImage = slide.assignedImageId?.let { id -> state.images.firstOrNull { it.id == id } }
        Box(
            Modifier
                .fillMaxWidth()
                .height(140.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(CardBg)
                .border(1.dp, BorderColor, RoundedCornerShape(12.dp)),
            contentAlignment = Alignment.Center
        ) {
            if (assignedImage != null) {
                AsyncImage(model = assignedImage.uri, contentDescription = null, modifier = Modifier.fillMaxWidth().height(140.dp))
            } else {
                Text("No photo assigned yet", color = Muted, style = MaterialTheme.typography.bodySmall)
            }
        }

        Text("Tap a photo to assign it", style = MaterialTheme.typography.labelMedium, color = Muted, modifier = Modifier.padding(top = 16.dp, bottom = 8.dp))
        val usedIds = remember(state.slides) { state.slides.mapNotNull { it.assignedImageId }.toSet() }
        LazyVerticalGrid(
            columns = GridCells.Fixed(3),
            modifier = Modifier.fillMaxWidth().height(320.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(state.images, key = { it.id }) { image ->
                val isUsed = image.id in usedIds
                val isCurrent = image.id == slide.assignedImageId
                Box(
                    Modifier
                        .aspectRatio(1f)
                        .clip(RoundedCornerShape(8.dp))
                        .background(CardBg)
                        .border(2.dp, if (isCurrent) Accent else BorderColor, RoundedCornerShape(8.dp))
                        .clickable { viewModel.pickImage(image.id) }
                ) {
                    AsyncImage(
                        model = image.uri,
                        contentDescription = image.displayName,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxWidth().fillMaxHeight()
                    )
                    if (isUsed && !isCurrent) {
                        Box(
                            Modifier
                                .align(Alignment.TopEnd)
                                .padding(3.dp)
                                .size(18.dp)
                                .clip(RoundedCornerShape(9.dp))
                                .background(Green),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Filled.Check, contentDescription = "Already used", tint = Color.Black, modifier = Modifier.size(12.dp))
                        }
                    }
                }
            }
        }

        Row(Modifier.padding(top = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            CompactButton("← Prev", onClick = viewModel::matchPrev, enabled = idx > 0)
            CompactButton("Skip →", onClick = viewModel::matchSkip, enabled = idx < state.slides.size - 1)
        }

        PrimaryButton(
            "Next — Preview →",
            modifier = Modifier.padding(top = 12.dp),
            onClick = { viewModel.goStep(AppStep.PREVIEW) }
        )
        SecondaryButton("← Back to Photos", onClick = { viewModel.goStep(AppStep.PHOTOS) })
    }
}

