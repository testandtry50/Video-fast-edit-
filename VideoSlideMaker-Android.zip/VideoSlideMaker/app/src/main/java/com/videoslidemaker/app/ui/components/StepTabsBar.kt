package com.videoslidemaker.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.videoslidemaker.app.model.AppStep
import com.videoslidemaker.app.ui.theme.Accent
import com.videoslidemaker.app.ui.theme.BorderColor
import com.videoslidemaker.app.ui.theme.Green
import com.videoslidemaker.app.ui.theme.Muted
import com.videoslidemaker.app.ui.theme.Surface

@Composable
fun StepTabsBar(currentStep: AppStep, onStepClick: (AppStep) -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .background(Surface)
    ) {
        AppStep.entries.forEach { step ->
            val isActive = step == currentStep
            val isDone = step.index < currentStep.index
            Column(
                Modifier
                    .weight(1f)
                    .clickable { onStepClick(step) }
                    .padding(vertical = 11.dp, horizontal = 4.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                val circleColor = when {
                    isActive -> Accent
                    isDone -> Green
                    else -> BorderColor
                }
                val textColor = when {
                    isActive -> Accent
                    isDone -> Green
                    else -> Muted
                }
                Box(
                    Modifier
                        .size(22.dp)
                        .clip(CircleShape)
                        .background(circleColor),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        "${step.index + 1}",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (isActive || isDone) androidx.compose.ui.graphics.Color.Black else Muted,
                        fontWeight = FontWeight.Bold
                    )
                }
                Text(
                    step.label,
                    style = MaterialTheme.typography.labelSmall,
                    color = textColor,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
        }
    }
}
