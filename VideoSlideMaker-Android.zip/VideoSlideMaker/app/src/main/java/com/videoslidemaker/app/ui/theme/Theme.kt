package com.videoslidemaker.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val VideoSlideMakerColorScheme = darkColorScheme(
    primary = Accent,
    secondary = Accent2,
    background = BgDark,
    surface = Surface,
    surfaceVariant = CardBg,
    onPrimary = TextMain,
    onSecondary = TextMain,
    onBackground = TextMain,
    onSurface = TextMain,
    outline = BorderColor,
    error = Red
)

@Composable
fun VideoSlideMakerTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    // The original app is dark-only by design (a night-friendly editing tool), so the palette
    // intentionally doesn't branch on system light/dark mode.
    MaterialTheme(
        colorScheme = VideoSlideMakerColorScheme,
        typography = VideoSlideMakerTypography,
        content = content
    )
}
