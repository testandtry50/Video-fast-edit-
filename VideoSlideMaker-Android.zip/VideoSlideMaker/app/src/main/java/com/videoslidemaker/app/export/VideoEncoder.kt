package com.videoslidemaker.app.export

import android.graphics.Bitmap
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaCodecList
import android.media.MediaFormat

/**
 * Native H.264 encoder driven frame-by-frame from rendered bitmaps. This replaces the original
 * app's approach of capturing a <canvas> through MediaRecorder — which depends on whatever
 * codec the phone's browser happens to support and paces frames with plain setTimeout — with
 * Android's real hardware/software encoder pipeline and exact per-frame timestamps, so output
 * is reliable and doesn't drop or duplicate frames under load.
 */
class VideoEncoder(
    private val width: Int,
    private val height: Int,
    private val fps: Int,
    bitrateBps: Int,
    private val muxer: MuxerHolder
) {
    private val mimeType = MediaFormat.MIMETYPE_VIDEO_AVC
    private val codec: MediaCodec = MediaCodec.createEncoderByType(mimeType)
    private val bufferInfo = MediaCodec.BufferInfo()
    private var trackIndex = -1
    private var frameIndex = 0L

    init {
        val format = MediaFormat.createVideoFormat(mimeType, width, height).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, chooseColorFormat())
            setInteger(MediaFormat.KEY_BIT_RATE, bitrateBps)
            setInteger(MediaFormat.KEY_FRAME_RATE, fps)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 2)
        }
        codec.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        codec.start()
    }

    private fun chooseColorFormat(): Int {
        val flexible = MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible
        try {
            val list = MediaCodecList(MediaCodecList.REGULAR_CODECS)
            val encoderName = list.findEncoderForFormat(MediaFormat.createVideoFormat(mimeType, width, height))
            val info = list.codecInfos.firstOrNull { it.name == encoderName } ?: return flexible
            val supported = info.getCapabilitiesForType(mimeType).colorFormats.toSet()
            return when {
                flexible in supported -> flexible
                MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420SemiPlanar in supported ->
                    MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420SemiPlanar
                else -> flexible
            }
        } catch (_: Exception) {
            return flexible
        }
    }

    /** Encodes one bitmap as the next frame in the sequence. */
    fun encodeFrame(bitmap: Bitmap) {
        val inputIndex = codec.dequeueInputBuffer(TIMEOUT_US)
        if (inputIndex >= 0) {
            val image = try {
                codec.getInputImage(inputIndex)
            } catch (_: Exception) {
                null
            }
            if (image != null) {
                Yuv420Writer.writeBitmapToImage(bitmap, image)
            } else {
                codec.getInputBuffer(inputIndex)?.let { buffer ->
                    Yuv420Writer.writeBitmapToNv12(bitmap, buffer, width, height)
                }
            }
            val ptsUs = frameIndex * 1_000_000L / fps
            val size = width * height * 3 / 2
            codec.queueInputBuffer(inputIndex, 0, size, ptsUs, 0)
            frameIndex++
        }
        drainEncoder(false)
    }

    fun finish() {
        val inputIndex = codec.dequeueInputBuffer(TIMEOUT_US)
        if (inputIndex >= 0) {
            codec.queueInputBuffer(inputIndex, 0, 0, frameIndex * 1_000_000L / fps, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
        }
        drainEncoder(true)
        codec.stop()
        codec.release()
    }

    private fun drainEncoder(endOfStream: Boolean) {
        while (true) {
            val outputIndex = codec.dequeueOutputBuffer(bufferInfo, TIMEOUT_US)
            when {
                outputIndex == MediaCodec.INFO_TRY_AGAIN_LATER -> if (!endOfStream) return
                outputIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                    trackIndex = muxer.addVideoTrack(codec.outputFormat)
                }
                outputIndex >= 0 -> {
                    val encodedData = codec.getOutputBuffer(outputIndex)
                    if (encodedData != null && bufferInfo.size > 0 &&
                        (bufferInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0
                    ) {
                        encodedData.position(bufferInfo.offset)
                        encodedData.limit(bufferInfo.offset + bufferInfo.size)
                        muxer.writeVideoSample(trackIndex, encodedData, bufferInfo)
                    }
                    codec.releaseOutputBuffer(outputIndex, false)
                    if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) return
                }
            }
        }
    }

    companion object {
        private const val TIMEOUT_US = 10_000L
    }
}
