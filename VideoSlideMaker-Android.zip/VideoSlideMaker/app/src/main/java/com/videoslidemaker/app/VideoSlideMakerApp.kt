package com.videoslidemaker.app

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build

class VideoSlideMakerApp : Application() {
    override fun onCreate() {
        super.onCreate()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                EXPORT_CHANNEL_ID,
                "Video export",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Shows progress while your video is being created"
            }
            getSystemService(NotificationManager::class.java)?.createNotificationChannel(channel)
        }
    }

    companion object {
        const val EXPORT_CHANNEL_ID = "export_channel"
    }
}
