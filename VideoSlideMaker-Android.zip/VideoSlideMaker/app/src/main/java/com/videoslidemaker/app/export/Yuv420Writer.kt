package com.videoslidemaker.app.export

import android.graphics.Bitmap
import android.media.Image
import java.nio.ByteBuffer

/**
 * MediaCodec video encoders don't accept RGB pixels directly — they need YUV 4:2:0. This
 * object converts an ARGB_8888 bitmap into that format.
 *
 * The primary path uses MediaCodec's Image/Plane API (`writeBitmapToImage`), which is the
 * approach Android documents for feeding software-rendered frames into an encoder: each plane
 * exposes its own rowStride/pixelStride, so the same code is correct whether the device's
 * encoder is internally planar or semi-planar. [writeBitmapToNv12] is kept as a defensive
 * fallback for the rare device where an Image isn't available for the negotiated format.
 */
object Yuv420Writer {

    private val pixelBuf = ThreadLocal<IntArray?>()

    private fun pixelsFor(bitmap: Bitmap): IntArray {
        val width = bitmap.width
        val height = bitmap.height
        var pixels = pixelBuf.get()
        if (pixels == null || pixels.size < width * height) {
            pixels = IntArray(width * height)
            pixelBuf.set(pixels)
        }
        bitmap.getPixels(pixels, 0, width, 0, 0, width, height)
        return pixels
    }

    fun writeBitmapToImage(bitmap: Bitmap, image: Image) {
        val width = bitmap.width
        val height = bitmap.height
        val pixels = pixelsFor(bitmap)

        val planes = image.planes
        writeLumaPlane(pixels, width, height, planes[0].buffer, planes[0].rowStride)
        writeChromaPlanes(
            pixels, width, height,
            planes[1].buffer, planes[1].rowStride, planes[1].pixelStride,
            planes[2].buffer, planes[2].rowStride, planes[2].pixelStride
        )
    }

    private fun writeLumaPlane(pixels: IntArray, width: Int, height: Int, buffer: ByteBuffer, rowStride: Int) {
        buffer.rewind()
        val row = ByteArray(rowStride)
        for (y in 0 until height) {
            val base = y * width
            for (x in 0 until width) {
                row[x] = luma(pixels[base + x])
            }
            buffer.position(y * rowStride)
            buffer.put(row, 0, rowStride.coerceAtMost(row.size))
        }
    }

    private fun writeChromaPlanes(
        pixels: IntArray, width: Int, height: Int,
        uBuffer: ByteBuffer, uRowStride: Int, uPixelStride: Int,
        vBuffer: ByteBuffer, vRowStride: Int, vPixelStride: Int
    ) {
        val chromaWidth = (width + 1) / 2
        val chromaHeight = (height + 1) / 2

        for (cy in 0 until chromaHeight) {
            val srcY = (cy * 2).coerceAtMost(height - 1)
            val uRowBase = cy * uRowStride
            val vRowBase = cy * vRowStride
            for (cx in 0 until chromaWidth) {
                val srcX = (cx * 2).coerceAtMost(width - 1)
                val c = pixels[srcY * width + srcX]
                // Absolute per-sample writes — NOT a bulk put() of a gap-padded row. On most
                // real devices (semi-planar/NV12), the U and V planes are two views into the
                // SAME interleaved memory, one byte apart. Building a row with zeros in the
                // "other channel's" slots and bulk-put()-ing it works fine for U alone, but
                // then doing the same for V overwrites U's just-written bytes with V's own
                // zero-gaps — silently zeroing almost the entire U channel. Writing one byte
                // at a time by absolute index never touches a byte that belongs to the other
                // plane, so it's correct for both interleaved (semi-planar) and separate
                // (planar) layouts.
                uBuffer.put(uRowBase + cx * uPixelStride, chromaU(c))
                vBuffer.put(vRowBase + cx * vPixelStride, chromaV(c))
            }
        }
    }

    /** Fallback: packs a classic interleaved NV12 buffer directly (used only if Image access fails). */
    fun writeBitmapToNv12(bitmap: Bitmap, out: ByteBuffer, width: Int, height: Int) {
        val pixels = pixelsFor(bitmap)
        out.clear()
        val frameSize = width * height
        val yuv = ByteArray(frameSize + frameSize / 2)

        var yIndex = 0
        var uvIndex = frameSize
        for (y in 0 until height) {
            for (x in 0 until width) {
                val c = pixels[y * width + x]
                yuv[yIndex++] = luma(c)
                if (y % 2 == 0 && x % 2 == 0) {
                    yuv[uvIndex++] = chromaU(c)
                    yuv[uvIndex++] = chromaV(c)
                }
            }
        }
        out.put(yuv)
    }

    // BT.601 full-swing RGB -> YUV, standard integer approximation.
    private fun luma(color: Int): Byte {
        val r = (color shr 16) and 0xFF
        val g = (color shr 8) and 0xFF
        val b = color and 0xFF
        val y = ((66 * r + 129 * g + 25 * b + 128) shr 8) + 16
        return y.coerceIn(0, 255).toByte()
    }

    private fun chromaU(color: Int): Byte {
        val r = (color shr 16) and 0xFF
        val g = (color shr 8) and 0xFF
        val b = color and 0xFF
        val u = ((-38 * r - 74 * g + 112 * b + 128) shr 8) + 128
        return u.coerceIn(0, 255).toByte()
    }

    private fun chromaV(color: Int): Byte {
        val r = (color shr 16) and 0xFF
        val g = (color shr 8) and 0xFF
        val b = color and 0xFF
        val v = ((112 * r - 94 * g - 18 * b + 128) shr 8) + 128
        return v.coerceIn(0, 255).toByte()
    }
}
