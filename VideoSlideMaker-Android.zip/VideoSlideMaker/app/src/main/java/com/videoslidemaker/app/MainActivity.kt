package com.videoslidemaker.app

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import com.videoslidemaker.app.model.AppStep
import com.videoslidemaker.app.data.queryDisplayName
import com.videoslidemaker.app.ui.components.StepTabsBar
import com.videoslidemaker.app.ui.screens.ExportScreen
import com.videoslidemaker.app.ui.screens.MatchScreen
import com.videoslidemaker.app.ui.screens.PhotosScreen
import com.videoslidemaker.app.ui.screens.PreviewScreen
import com.videoslidemaker.app.ui.screens.ScriptScreen
import com.videoslidemaker.app.ui.theme.BgDark
import com.videoslidemaker.app.ui.theme.VideoSlideMakerTheme
import com.videoslidemaker.app.viewmodel.AppViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            VideoSlideMakerTheme {
                Surface(color = BgDark) {
                    AppRoot()
                }
            }
        }
    }
}

@Composable
private fun AppRoot(viewModel: AppViewModel = viewModel()) {
    val context = LocalContext.current
    val state by viewModel.ui.collectAsState()

    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { /* no-op: export still works without the permission, just without a visible notification */ }

    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) ==
                PackageManager.PERMISSION_GRANTED
            if (!granted) notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    val scriptPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val text = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
            if (text != null) viewModel.loadScript(text)
        }
    }

    val imagesPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) viewModel.addImages(uris)
    }

    val musicPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: SecurityException) {
                // Some providers don't support persistable grants; the Uri still works this session.
            }
            val name = queryDisplayName(context, uri)
            viewModel.setMusicUri(uri, name)
        }
    }

    Column(Modifier.fillMaxSize().background(BgDark)) {
        StepTabsBar(currentStep = state.step, onStepClick = { viewModel.goStep(it) })
        Box(Modifier.weight(1f)) {
            when (state.step) {
                AppStep.SCRIPT -> ScriptScreen(state, viewModel, onPickScriptFile = { scriptPicker.launch(arrayOf("text/plain")) })
                AppStep.PHOTOS -> PhotosScreen(state, viewModel, onPickImages = { imagesPicker.launch(arrayOf("image/*")) })
                AppStep.MATCH -> MatchScreen(state, viewModel, onPickImages = { imagesPicker.launch(arrayOf("image/*")) })
                AppStep.PREVIEW -> PreviewScreen(state, viewModel)
                AppStep.EXPORT -> ExportScreen(state, viewModel, onPickMusic = { musicPicker.launch(arrayOf("audio/*")) })
            }
        }
    }
}
