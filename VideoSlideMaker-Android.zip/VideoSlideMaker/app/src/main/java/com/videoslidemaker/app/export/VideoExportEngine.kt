package com.videoslidemaker.app.export

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import com.videoslidemaker.app.data.ImageStore
import com.videoslidemaker.app.data.ScriptParser
import com.videoslidemaker.app.model.AspectRatioOption
import com.videoslidemaker.app.model.ExportSettings
import com.videoslidemaker.app.model.PoolImage
import com.videoslidemaker.app.model.QualityOption
import com.videoslidemaker.app.model.SentenceSlide
import com.videoslidemaker.app.tts.NarrationTts
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

data class ExportResult(val success: Boolean, val outputUri: Uri?, val error: String? = null)

/**
 * Renders the final matched sequence of photos into a real MP4: H.264 video with Ken Burns
 * zoom and fade transitions (matching the original canvas math exactly) muxed together with a
 * synced narration + background-music audio track. Runs entirely off the main thread and
 * reports progress via [onProgress] so it can be driven safely from a foreground service.
 */
class VideoExportEngine(
    private val context: Context,
    private val imageStore: ImageStore,
    private val tts: NarrationTts
) {
    private val fps = 24

    suspend fun export(
        slides: List<SentenceSlide>,
        images: List<PoolImage>,
        settings: ExportSettings,
        onProgress: (percent: Int, message: String) -> Unit
    ): ExportResult = withContext(Dispatchers.Default) {
        if (slides.isEmpty()) return@withContext ExportResult(false, null, "Nothing to export yet.")

        val (outputWidth, outputHeight) = computeOutputSize(images, settings)
        val sequence = buildFinalSequence(slides, images, settings.defaultDurationSec)
        val totalDuration = totalDurationSeconds(slides, images, settings.defaultDurationSec)

        val cacheDir = File(context.cacheDir, "export").apply { mkdirs() }
        val outputFile = File(cacheDir, "export_${System.currentTimeMillis()}.mp4")

        val hasNarrationText = settings.narration.enabled && slides.any { it.text.isNotBlank() }
        val hasMusic = settings.music.uri != null
        val hasAudio = hasNarrationText || hasMusic

        val muxer = MuxerHolder(outputFile.absolutePath, expectAudioTrack = hasAudio)

        try {
            if (hasAudio) {
                onProgress(0, "Preparing narration…")
                val pcmAudio = NarrationAudioBuilder(context, tts).build(slides, totalDuration, settings, cacheDir) { msg ->
                    onProgress(2, msg)
                }
                val audioEncoder = AudioEncoder(
                    sampleRate = pcmAudio.sampleRate,
                    channelCount = pcmAudio.channelCount,
                    bitrateBps = 128_000,
                    muxer = muxer
                )
                val chunkSize = 8192
                var offset = 0
                while (offset < pcmAudio.data.size) {
                    val len = min(chunkSize, pcmAudio.data.size - offset)
                    audioEncoder.feedPcm(pcmAudio.data.copyOfRange(offset, offset + len), len)
                    offset += len
                }
                audioEncoder.finish()
            }

            onProgress(5, "Starting video render…")
            val bitrate = bitrateFor(outputWidth, outputHeight)
            val videoEncoder = VideoEncoder(outputWidth, outputHeight, fps, bitrate, muxer)
            val renderer = FrameRenderer(outputWidth, outputHeight)
            val frameBitmap = Bitmap.createBitmap(outputWidth, outputHeight, Bitmap.Config.ARGB_8888)
            val maxSourceEdge = max(outputWidth, outputHeight)
            val fadeSeconds = 0.4f

            for (i in sequence.indices) {
                val item = sequence[i]
                val totalFrames = max(1, (item.durationSec * fps).roundToInt())
                onProgress(
                    5 + ((i.toFloat() / sequence.size) * 90).roundToInt(),
                    "Image ${i + 1} of ${sequence.size} — ${ScriptParser.formatTime(item.startSec)}"
                )

                val sourceBitmap = item.image?.let { imageStore.decodeForExport(it.uri, maxSourceEdge) }
                if (sourceBitmap != null) {
                    val fadeFraction = if (settings.fadeTransition) min(0.5f, fadeSeconds / item.durationSec.toFloat()) else 0f
                    for (f in 0 until totalFrames) {
                        val progress = f / totalFrames.toFloat()
                        renderer.renderFrame(frameBitmap, sourceBitmap, progress, settings.zoomEffect, fadeFraction, fadeFraction)
                        videoEncoder.encodeFrame(frameBitmap)
                    }
                    sourceBitmap.recycle()
                } else {
                    // Missing/unreadable photo: hold the slot with black frames instead of
                    // collapsing the timeline out of sync with the audio track.
                    val blackCanvas = Canvas(frameBitmap)
                    blackCanvas.drawColor(Color.BLACK)
                    repeat(totalFrames) { videoEncoder.encodeFrame(frameBitmap) }
                }
            }

            videoEncoder.finish()
            frameBitmap.recycle()
        } catch (e: Exception) {
            muxer.release()
            outputFile.delete()
            return@withContext ExportResult(false, null, e.message ?: "Export failed.")
        }

        muxer.release()

        onProgress(97, "Saving to your gallery…")
        val savedUri = saveToGallery(outputFile)
        outputFile.delete()
        onProgress(100, "Done")

        if (savedUri != null) ExportResult(true, savedUri)
        else ExportResult(false, null, "Could not save the finished video to your device storage.")
    }

    private data class SequenceItem(val image: PoolImage?, val startSec: Double, val durationSec: Double)

    private fun buildFinalSequence(
        slides: List<SentenceSlide>,
        images: List<PoolImage>,
        defaultDurationSec: Int
    ): List<SequenceItem> {
        val usedFallbacks = HashSet<String>()
        var fallbackPointer = 0
        fun nextFallback(): PoolImage? {
            while (fallbackPointer < images.size && images[fallbackPointer].id in usedFallbacks) fallbackPointer++
            return images.getOrNull(fallbackPointer)
        }

        return slides.mapIndexed { index, slide ->
            val start = slide.timestampSec
            val assigned = slide.assignedImageId?.let { id -> images.firstOrNull { it.id == id } }

            // For the last slide there's no "next timestamp" to derive a length from, so fall
            // back to that specific photo's own time box if it has one (simple/no-script mode),
            // and only then to the global default (matches the original script-mode behavior).
            val end = slides.getOrNull(index + 1)?.timestampSec
                ?: (start + (assigned?.durationOverrideSec ?: defaultDurationSec.toDouble()))
            val duration = max(0.1, end - start)

            val image = assigned ?: run {
                val fallback = nextFallback()
                if (fallback != null) usedFallbacks.add(fallback.id)
                fallback ?: images.firstOrNull()
            }
            SequenceItem(image, start, duration)
        }
    }

    private fun totalDurationSeconds(slides: List<SentenceSlide>, images: List<PoolImage>, defaultDurationSec: Int): Double {
        if (slides.isEmpty()) return 0.0
        val last = slides.last()
        val lastImage = last.assignedImageId?.let { id -> images.firstOrNull { it.id == id } }
        return last.timestampSec + max(0.1, lastImage?.durationOverrideSec ?: defaultDurationSec.toDouble())
    }

    private fun computeOutputSize(images: List<PoolImage>, settings: ExportSettings): Pair<Int, Int> {
        val ratio = settings.aspectRatio
        if (settings.quality == QualityOption.ORIGINAL) {
            val largest = images.maxByOrNull { it.widthPx.toLong() * it.heightPx.toLong() }
            val maxW = largest?.widthPx?.takeIf { it > 0 } ?: 1920
            val maxH = largest?.heightPx?.takeIf { it > 0 } ?: 1080
            val base = max(maxW, maxH)
            var w: Int
            var h: Int
            if (ratio.w >= ratio.h) {
                h = base * ratio.h / ratio.w
                w = base
                if (w < maxW) { w = maxW; h = (w.toLong() * ratio.h / ratio.w).toInt() }
            } else {
                w = base * ratio.w / ratio.h
                h = base
                if (h < maxH) { h = maxH; w = (h.toLong() * ratio.w / ratio.h).toInt() }
            }
            return evenize(w) to evenize(h)
        }
        return capped(ratio, settings.quality.basePx ?: 720)
    }

    private fun capped(ratio: AspectRatioOption, base: Int): Pair<Int, Int> {
        val w: Int
        val h: Int
        if (ratio.w >= ratio.h) {
            h = base
            w = (base.toLong() * ratio.w / ratio.h).toInt()
        } else {
            w = base
            h = (base.toLong() * ratio.h / ratio.w).toInt()
        }
        return evenize(w) to evenize(h)
    }

    private fun evenize(v: Int): Int = if (v % 2 == 0) v else v + 1

    private fun bitrateFor(width: Int, height: Int): Int {
        val pixels = width.toLong() * height.toLong()
        return when {
            pixels >= 3840L * 2160L -> 20_000_000
            pixels >= 1920L * 1080L -> 8_000_000
            pixels >= 1280L * 720L -> 4_500_000
            else -> 2_500_000
        }
    }

    private fun saveToGallery(sourceFile: File): Uri? {
        val displayName = "VideoSlideMaker_${System.currentTimeMillis()}.mp4"
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, displayName)
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/VideoSlideMaker")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
            val resolver = context.contentResolver
            val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values) ?: return null
            resolver.openOutputStream(uri)?.use { out -> sourceFile.inputStream().use { it.copyTo(out) } }
            values.clear()
            values.put(MediaStore.Video.Media.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
            uri
        } else {
            @Suppress("DEPRECATION")
            val moviesDir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES), "VideoSlideMaker")
            if (!moviesDir.exists()) moviesDir.mkdirs()
            val destFile = File(moviesDir, displayName)
            sourceFile.inputStream().use { input -> FileOutputStream(destFile).use { output -> input.copyTo(output) } }
            android.media.MediaScannerConnection.scanFile(context, arrayOf(destFile.absolutePath), arrayOf("video/mp4"), null)
            Uri.fromFile(destFile)
        }
    }
}
