package com.videoslidemaker.app.export

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.provider.MediaStore
import com.videoslidemaker.app.data.ImageStore
import com.videoslidemaker.app.data.ScriptParser
import com.videoslidemaker.app.model.AspectRatioOption
import com.videoslidemaker.app.model.ExportSettings
import com.videoslidemaker.app.model.PoolImage
import com.videoslidemaker.app.model.QualityOption
import com.videoslidemaker.app.model.SentenceSlide
import com.videoslidemaker.app.tts.NarrationTts
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

data class ExportResult(val success: Boolean, val outputUri: Uri?, val error: String? = null)

/**
 * Renders the final matched sequence of photos into a real MP4: H.264 video with Ken Burns
 * zoom and fade transitions (matching the original canvas math exactly) muxed together with a
 * synced narration + background-music audio track. Runs entirely off the main thread and
 * reports progress via [onProgress] so it can be driven safely from a foreground service.
 */
class VideoExportEngine(
    private val context: Context,
    private val imageStore: ImageStore,
    private val tts: NarrationTts
) {
    private val fps = 24

    suspend fun export(
        slides: List<SentenceSlide>,
        images: List<PoolImage>,
        settings: ExportSettings,
        onProgress: (percent: Int, message: String) -> Unit
    ): ExportResult = withContext(Dispatchers.Default) {
        if (slides.isEmpty()) return@withContext ExportResult(false, null, "Nothing to export yet.")

        val (outputWidth, outputHeight) = computeOutputSize(images, settings)
        val sequence = buildFinalSequence(slides, images, settings.defaultDurationSec)
        val totalDuration = totalDurationSeconds(slides, images, settings.defaultDurationSec)

        val cacheDir = File(context.cacheDir, "export").apply { mkdirs() }
        val outputFile = File(cacheDir, "export_${System.currentTimeMillis()}.mp4")

        // A long or high-resolution export can genuinely need real disk space — both for the
        // temporary narration+music file and the output video itself. Running out mid-export
        // produces a confusing low-level I/O error instead of a clear reason, so estimate what's
        // needed up front and fail fast, before any expensive work, if there isn't room. This
        // isn't exact (final size depends on actual encoder behavior), so it includes a margin.
        val estimatedVideoBytes = (bitrateFor(outputWidth, outputHeight) / 8.0 * totalDuration).toLong()
        val estimatedPcmBytes = (totalDuration * AUDIO_SAMPLE_RATE).toLong() * AUDIO_CHANNELS * 2
        val estimatedNeededBytes = maxOf(estimatedVideoBytes, estimatedPcmBytes) + 200L * 1024 * 1024
        val availableBytes = try {
            StatFs(cacheDir.absolutePath).availableBytes
        } catch (_: Exception) {
            Long.MAX_VALUE // if we can't check for some reason, don't block the export over it
        }
        if (availableBytes < estimatedNeededBytes) {
            val neededMb = estimatedNeededBytes / (1024 * 1024)
            val availableMb = availableBytes / (1024 * 1024)
            return@withContext ExportResult(
                false, null,
                "Not enough free storage for a video this long/large — it needs roughly ${neededMb}MB " +
                    "free and this device only has about ${availableMb}MB. Free up some space (or export " +
                    "a shorter video / lower quality) and try again."
            )
        }

        val hasNarrationText = settings.narration.enabled && slides.any { it.text.isNotBlank() }
        val hasMusic = settings.music.uri != null
        val hasAudio = hasNarrationText || hasMusic

        val muxer = MuxerHolder(outputFile.absolutePath, expectAudioTrack = hasAudio)

        try {
            if (hasAudio) {
                onProgress(0, "Preparing narration…")
                val pcmAudio = NarrationAudioBuilder(context, tts).build(slides, totalDuration, settings, cacheDir) { msg ->
                    onProgress(2, msg)
                }
                try {
                    val audioEncoder = AudioEncoder(
                        sampleRate = pcmAudio.sampleRate,
                        channelCount = pcmAudio.channelCount,
                        bitrateBps = 128_000,
                        muxer = muxer
                    )
                    audioEncoder.feedPcmFile(pcmAudio.file, pcmAudio.totalBytes)
                    audioEncoder.finish()
                } finally {
                    pcmAudio.file.delete()
                }
            }

            onProgress(5, "Starting video render…")
            val bitrate = bitrateFor(outputWidth, outputHeight)
            val videoEncoder = VideoEncoder(outputWidth, outputHeight, fps, bitrate, muxer)
            val renderer = FrameRenderer(outputWidth, outputHeight)
            val frameBitmap = Bitmap.createBitmap(outputWidth, outputHeight, Bitmap.Config.ARGB_8888)
            val maxSourceEdge = max(outputWidth, outputHeight)
            val fadeSeconds = 0.4f

            var successCount = 0
            var firstFailureReason: String? = null

            for (i in sequence.indices) {
                val item = sequence[i]
                val totalFrames = max(1, (item.durationSec * fps).roundToInt())
                onProgress(
                    5 + ((i.toFloat() / sequence.size) * 90).roundToInt(),
                    "Image ${i + 1} of ${sequence.size} — ${ScriptParser.formatTime(item.startSec)}"
                )

                val sourceBitmap = if (item.image == null) {
                    if (firstFailureReason == null) {
                        firstFailureReason = "one of your sentences has no photo assigned and none left to fall back to"
                    }
                    null
                } else {
                    try {
                        val bmp = imageStore.decodeForExport(item.image.uri, maxSourceEdge)
                        if (bmp == null && firstFailureReason == null) {
                            firstFailureReason = "a photo (\"${item.image.displayName}\") couldn't be opened — " +
                                "its file may have moved or been deleted, or its access permission may have expired"
                        }
                        bmp
                    } catch (e: SecurityException) {
                        if (firstFailureReason == null) {
                            firstFailureReason = "a photo's (\"${item.image.displayName}\") access permission has expired"
                        }
                        null
                    } catch (e: Exception) {
                        if (firstFailureReason == null) {
                            firstFailureReason = "a photo (\"${item.image.displayName}\") failed to decode: ${e.message ?: e.javaClass.simpleName}"
                        }
                        null
                    }
                }

                if (sourceBitmap != null) {
                    successCount++
                    val fadeFraction = if (settings.fadeTransition) min(0.5f, fadeSeconds / item.durationSec.toFloat()) else 0f
                    for (f in 0 until totalFrames) {
                        val progress = f / totalFrames.toFloat()
                        renderer.renderFrame(frameBitmap, sourceBitmap, progress, settings.zoomEffect, fadeFraction, fadeFraction)
                        videoEncoder.encodeFrame(frameBitmap)
                    }
                    sourceBitmap.recycle()
                } else {
                    // Missing/unreadable photo: hold the slot with black frames instead of
                    // collapsing the timeline out of sync with the audio track.
                    val blackCanvas = Canvas(frameBitmap)
                    blackCanvas.drawColor(Color.BLACK)
                    repeat(totalFrames) { videoEncoder.encodeFrame(frameBitmap) }
                }
            }

            if (successCount == 0 && sequence.isNotEmpty()) {
                // Every single slide fell back to a black frame — a "successful" export with
                // nothing in it is worse than telling you plainly what's wrong. This is exactly
                // what was happening silently before.
                throw IllegalStateException(
                    "None of your photos could be loaded, so there was nothing to put in the video" +
                        (firstFailureReason?.let { " ($it)" } ?: "") +
                        ". Try removing and re-adding your photos on the Photos step, then export again."
                )
            }

            videoEncoder.finish()
            frameBitmap.recycle()
        } catch (e: Exception) {
            muxer.release()
            outputFile.delete()
            return@withContext ExportResult(false, null, e.message ?: "Export failed.")
        }

        muxer.release()

        onProgress(97, "Saving to your gallery…")
        val savedUri = saveToGallery(outputFile)
        outputFile.delete()
        onProgress(100, "Done")

        if (savedUri != null) ExportResult(true, savedUri)
        else ExportResult(false, null, "Could not save the finished video to your device storage.")
    }

    private data class SequenceItem(val image: PoolImage?, val startSec: Double, val durationSec: Double)

    private fun buildFinalSequence(
        slides: List<SentenceSlide>,
        images: List<PoolImage>,
        defaultDurationSec: Int
    ): List<SequenceItem> {
        val usedFallbacks = HashSet<String>()
        var fallbackPointer = 0
        fun nextFallback(): PoolImage? {
            while (fallbackPointer < images.size && images[fallbackPointer].id in usedFallbacks) fallbackPointer++
            return images.getOrNull(fallbackPointer)
        }

        return slides.mapIndexed { index, slide ->
            val start = slide.timestampSec
            val assigned = slide.assignedImageId?.let { id -> images.firstOrNull { it.id == id } }

            // For the last slide there's no "next timestamp" to derive a length from, so fall
            // back to that specific photo's own time box if it has one (simple/no-script mode),
            // and only then to the global default (matches the original script-mode behavior).
            val end = slides.getOrNull(index + 1)?.timestampSec
                ?: (start + (assigned?.durationOverrideSec ?: defaultDurationSec.toDouble()))
            val duration = max(0.1, end - start)

            val image = assigned ?: run {
                val fallback = nextFallback()
                if (fallback != null) usedFallbacks.add(fallback.id)
                fallback ?: images.firstOrNull()
            }
            SequenceItem(image, start, duration)
        }
    }

    private fun totalDurationSeconds(slides: List<SentenceSlide>, images: List<PoolImage>, defaultDurationSec: Int): Double {
        if (slides.isEmpty()) return 0.0
        val last = slides.last()
        val lastImage = last.assignedImageId?.let { id -> images.firstOrNull { it.id == id } }
        return last.timestampSec + max(0.1, lastImage?.durationOverrideSec ?: defaultDurationSec.toDouble())
    }

    private fun computeOutputSize(images: List<PoolImage>, settings: ExportSettings): Pair<Int, Int> {
        val ratio = settings.aspectRatio
        if (settings.quality == QualityOption.ORIGINAL) {
            val largest = images.maxByOrNull { it.widthPx.toLong() * it.heightPx.toLong() }
            val maxW = largest?.widthPx?.takeIf { it > 0 } ?: 1920
            val maxH = largest?.heightPx?.takeIf { it > 0 } ?: 1080
            val base = max(maxW, maxH)
            var w: Int
            var h: Int
            if (ratio.w >= ratio.h) {
                h = base * ratio.h / ratio.w
                w = base
                if (w < maxW) { w = maxW; h = (w.toLong() * ratio.h / ratio.w).toInt() }
            } else {
                w = base * ratio.w / ratio.h
                h = base
                if (h < maxH) { h = maxH; w = (h.toLong() * ratio.w / ratio.h).toInt() }
            }
            return align16(w) to align16(h)
        }
        return capped(ratio, settings.quality.basePx ?: 720)
    }

    private fun capped(ratio: AspectRatioOption, base: Int): Pair<Int, Int> {
        val w: Int
        val h: Int
        if (ratio.w >= ratio.h) {
            h = base
            w = (base.toLong() * ratio.w / ratio.h).toInt()
        } else {
            w = base
            h = (base.toLong() * ratio.h / ratio.w).toInt()
        }
        return align16(w) to align16(h)
    }

    /**
     * Rounds up to the nearest multiple of 16 — the standard H.264 macroblock size — instead of
     * merely making the value even. Landing exactly on a 16-boundary means most real encoders
     * won't need to pad rows internally at all, so this sidesteps the whole stride-padding class
     * of bug (see the size comment in VideoEncoder.encodeFrame) for the common case, on top of
     * that fix already handling it correctly when padding does still happen.
     */
    private fun align16(v: Int): Int {
        val remainder = v % 16
        return if (remainder == 0) v else v + (16 - remainder)
    }

    private fun bitrateFor(width: Int, height: Int): Int {
        val pixels = width.toLong() * height.toLong()
        return when {
            pixels >= 3840L * 2160L -> 20_000_000
            pixels >= 1920L * 1080L -> 8_000_000
            pixels >= 1280L * 720L -> 4_500_000
            else -> 2_500_000
        }
    }

    private fun saveToGallery(sourceFile: File): Uri? {
        val displayName = "VideoSlideMaker_${System.currentTimeMillis()}.mp4"
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, displayName)
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/VideoSlideMaker")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
            val resolver = context.contentResolver
            val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values) ?: return null
            resolver.openOutputStream(uri)?.use { out -> sourceFile.inputStream().use { it.copyTo(out) } }
            values.clear()
            values.put(MediaStore.Video.Media.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
            uri
        } else {
            @Suppress("DEPRECATION")
            val moviesDir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES), "VideoSlideMaker")
            if (!moviesDir.exists()) moviesDir.mkdirs()
            val destFile = File(moviesDir, displayName)
            sourceFile.inputStream().use { input -> FileOutputStream(destFile).use { output -> input.copyTo(output) } }
            android.media.MediaScannerConnection.scanFile(context, arrayOf(destFile.absolutePath), arrayOf("video/mp4"), null)
            Uri.fromFile(destFile)
        }
    }
}
