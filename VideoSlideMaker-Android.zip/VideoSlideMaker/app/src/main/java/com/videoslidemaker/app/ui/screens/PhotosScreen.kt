package com.videoslidemaker.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.videoslidemaker.app.data.ScriptParser
import com.videoslidemaker.app.model.AppStep
import com.videoslidemaker.app.model.PoolImage
import com.videoslidemaker.app.model.UiState
import com.videoslidemaker.app.ui.components.AlertBox
import com.videoslidemaker.app.ui.components.AlertStyle
import com.videoslidemaker.app.ui.components.PrimaryButton
import com.videoslidemaker.app.ui.components.ScreenTitle
import com.videoslidemaker.app.ui.components.SecondaryButton
import com.videoslidemaker.app.ui.components.StatChip
import com.videoslidemaker.app.ui.theme.Accent
import com.videoslidemaker.app.ui.theme.BorderColor
import com.videoslidemaker.app.ui.theme.CardBg
import com.videoslidemaker.app.ui.theme.Muted
import com.videoslidemaker.app.ui.theme.Red
import com.videoslidemaker.app.ui.theme.TextMain
import com.videoslidemaker.app.viewmodel.AppViewModel

@Composable
fun PhotosScreen(state: UiState, viewModel: AppViewModel, onPickImages: () -> Unit) {
    Column(Modifier.fillMaxWidth().padding(16.dp)) {
        ScreenTitle(
            "Add Your Photos",
            if (state.scriptLoaded) "Add all the photos you'll need. You'll match them to sentences in the next step."
            else "Add your photos, then tap the time on each one to set how long it shows."
        )

        UploadZone(
            done = state.images.isNotEmpty(),
            icon = "🖼️",
            title = "Tap to add photos",
            hint = "You can select many at once — large photos are handled efficiently",
            onClick = onPickImages
        )

        Row(Modifier.fillMaxWidth().padding(vertical = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StatChip("${state.images.size}", "Photos", Modifier.weight(1f))
            if (state.scriptLoaded) {
                StatChip("${state.slides.size}", "Sentences", Modifier.weight(1f))
            } else {
                StatChip("Simple", "Mode", Modifier.weight(1f))
            }
            StatChip(ScriptParser.formatTime(state.totalDurationSec), "Total length", Modifier.weight(1f))
        }

        if (!state.scriptLoaded && state.images.isNotEmpty()) {
            AlertBox(
                "Tap the ⏱ time on any photo to change how long it shows — great for a long video.",
                style = AlertStyle.INFO,
                modifier = Modifier.padding(bottom = 12.dp)
            )
        }

        if (state.images.isNotEmpty()) {
            SecondaryButton("Clear All Photos", modifier = Modifier.padding(bottom = 8.dp), onClick = viewModel::clearAllImages)
        }

        LazyColumn(
            Modifier
                .fillMaxWidth()
                .weight(1f),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(state.images, key = { it.id }) { image ->
                val index = state.images.indexOf(image)
                PhotoRow(
                    image = image,
                    index = index,
                    total = state.images.size,
                    showTimeControl = !state.scriptLoaded,
                    durationSec = image.durationOverrideSec ?: state.settings.defaultDurationSec.toDouble(),
                    onMoveUp = { viewModel.moveImageUp(index) },
                    onMoveDown = { viewModel.moveImageDown(index) },
                    onDelete = { viewModel.deleteImage(image.id) },
                    onDurationChange = { seconds -> viewModel.setPhotoDuration(image.id, seconds) }
                )
            }
        }

        PrimaryButton(
            if (state.scriptLoaded) "Next — Match Photos →" else "Next — Preview →",
            enabled = state.images.isNotEmpty(),
            modifier = Modifier.padding(top = 16.dp),
            onClick = { viewModel.goNextFromPhotos() }
        )
        SecondaryButton("← Back", onClick = { viewModel.goStep(AppStep.SCRIPT) })
    }
}

@Composable
private fun PhotoRow(
    image: PoolImage,
    index: Int,
    total: Int,
    showTimeControl: Boolean,
    durationSec: Double,
    onMoveUp: () -> Unit,
    onMoveDown: () -> Unit,
    onDelete: () -> Unit,
    onDurationChange: (Double) -> Unit
) {
    var showDialog by remember { mutableStateOf(false) }

    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(CardBg)
            .border(1.dp, BorderColor, RoundedCornerShape(10.dp))
            .padding(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        AsyncImage(
            model = image.uri,
            contentDescription = image.displayName,
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .size(56.dp)
                .clip(RoundedCornerShape(8.dp))
        )
        Column(Modifier.weight(1f).padding(horizontal = 10.dp)) {
            Text(
                "#${index + 1} ${image.displayName}",
                style = MaterialTheme.typography.bodyMedium,
                color = TextMain,
                fontWeight = FontWeight.Medium,
                maxLines = 1
            )
            if (image.widthPx > 0) {
                Text("${image.widthPx}×${image.heightPx}", style = MaterialTheme.typography.bodySmall, color = Muted)
            }
        }
        if (showTimeControl) {
            Row(
                Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(Accent.copy(alpha = 0.15f))
                    .clickable { showDialog = true }
                    .padding(horizontal = 10.dp, vertical = 6.dp)
            ) {
                Text("⏱ ${ScriptParser.formatTime(durationSec)}", style = MaterialTheme.typography.labelMedium, color = Accent)
            }
        }
        IconButton(onClick = onMoveUp, enabled = index > 0, modifier = Modifier.size(32.dp)) {
            Icon(Icons.Filled.KeyboardArrowUp, contentDescription = "Move up", tint = if (index > 0) Muted else BorderColor)
        }
        IconButton(onClick = onMoveDown, enabled = index < total - 1, modifier = Modifier.size(32.dp)) {
            Icon(Icons.Filled.KeyboardArrowDown, contentDescription = "Move down", tint = if (index < total - 1) Muted else BorderColor)
        }
        IconButton(onClick = onDelete, modifier = Modifier.size(32.dp)) {
            Icon(Icons.Filled.Close, contentDescription = "Delete", tint = Red)
        }
    }

    if (showDialog) {
        TimeEditDialog(
            initialSeconds = durationSec,
            onConfirm = { seconds -> onDurationChange(seconds); showDialog = false },
            onDismiss = { showDialog = false }
        )
    }
}

@Composable
private fun TimeEditDialog(initialSeconds: Double, onConfirm: (Double) -> Unit, onDismiss: () -> Unit) {
    var text by remember { mutableStateOf(ScriptParser.formatTime(initialSeconds)) }
    var error by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("How long should this photo show?") },
        text = {
            Column {
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it; error = false },
                    placeholder = { Text("e.g. 0:03 or 2:30") },
                    isError = error,
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                if (error) {
                    Text(
                        "Type minutes:seconds, like 2:30",
                        color = Red,
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
                Text(
                    "Minutes : seconds. For a long video, try 3:00 for 3 minutes.",
                    style = MaterialTheme.typography.bodySmall,
                    color = Muted,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val parsed = ScriptParser.parseTime(text)
                if (parsed != null && parsed > 0) onConfirm(parsed) else error = true
            }) { Text("Save") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
