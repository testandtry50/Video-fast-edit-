package com.videoslidemaker.app.data

import kotlin.math.floor

/**
 * Parses a .txt script file where each line is either:
 *   0:06 - some sentence text        (timestamp + sentence)
 *   12 - some sentence text          (plain-second timestamp + sentence)
 *   0:06                             (timestamp only — legacy format, blank sentence)
 * This is a direct Kotlin port of the original web app's regex, so any script file that
 * worked before works identically here.
 */
object ScriptParser {

    // The separator between timestamp and text is deliberately just -/–/— (and optional, so a
    // bare space works too) — NOT ':'. Including ':' here used to be ambiguous with the colon
    // that's already part of the mm:ss timestamp itself (e.g. "0:02 some text", with no dash):
    // when there was no dash to anchor on, the regex would backtrack into matching only the
    // leading digit as the timestamp, then treat the timestamp's OWN colon as the separator —
    // silently turning every line into timestamp 0 and dumping part of the real timestamp into
    // the sentence text. Making the separator optional (so plain whitespace is enough on its
    // own) and dropping ':' from it removes that ambiguity entirely.
    private val LINE_REGEX =
        Regex("""^(\d{1,3}:\d{1,2}(?:\.\d+)?|\d+(?:\.\d+)?)\s*(?:[-–—]\s*)?(.*)$""")

    data class ParsedLine(val timestampSec: Double, val text: String)

    fun parseTime(raw: String): Double? {
        val s = raw.trim()
        if (s.isEmpty()) return null
        val parts = s.split(":")
        return if (parts.size == 2) {
            val minutes = parts[0].toIntOrNull() ?: return null
            val seconds = parts[1].toDoubleOrNull() ?: return null
            minutes * 60 + seconds
        } else {
            s.toDoubleOrNull()
        }
    }

    fun formatTime(seconds: Double): String {
        if (seconds.isNaN() || seconds < 0) return "0:00"
        val m = floor(seconds / 60).toInt()
        val s = floor(seconds % 60).toInt()
        return "$m:${s.toString().padStart(2, '0')}"
    }

    fun parseScript(content: String): List<ParsedLine> {
        val result = mutableListOf<ParsedLine>()
        content.trim().split("\n").forEach { rawLine ->
            val line = rawLine.trim()
            if (line.isEmpty()) return@forEach
            val match = LINE_REGEX.find(line)
            if (match != null) {
                val t = parseTime(match.groupValues[1])
                if (t != null) result.add(ParsedLine(t, match.groupValues[2].trim()))
            } else {
                val t = parseTime(line)
                if (t != null) result.add(ParsedLine(t, ""))
            }
        }
        return result
    }
}
