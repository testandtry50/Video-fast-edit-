package com.videoslidemaker.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.videoslidemaker.app.data.ScriptParser
import com.videoslidemaker.app.model.AppStep
import com.videoslidemaker.app.model.OverlayPosition
import com.videoslidemaker.app.model.OverlayStyle
import com.videoslidemaker.app.model.TextOverlay
import com.videoslidemaker.app.model.UiState
import com.videoslidemaker.app.ui.components.AlertBox
import com.videoslidemaker.app.ui.components.AlertStyle
import com.videoslidemaker.app.ui.components.PrimaryButton
import com.videoslidemaker.app.ui.components.ScreenTitle
import com.videoslidemaker.app.ui.components.SecondaryButton
import com.videoslidemaker.app.ui.components.SectionCard
import com.videoslidemaker.app.ui.theme.Accent
import com.videoslidemaker.app.ui.theme.BorderColor
import com.videoslidemaker.app.ui.theme.CardBg
import com.videoslidemaker.app.ui.theme.Muted
import com.videoslidemaker.app.ui.theme.Red
import com.videoslidemaker.app.ui.theme.Surface
import com.videoslidemaker.app.ui.theme.TextMain
import com.videoslidemaker.app.viewmodel.AppViewModel

/**
 * NEW: character-name (or any short label) text overlays — burned into the exported video for
 * a chosen time window, independent of which photo is showing. Built for "movie explanation"
 * style content, where introducing who's who by name is a common, recurring need.
 */
@Composable
fun TextOverlayScreen(state: UiState, viewModel: AppViewModel) {
    var newText by remember { mutableStateOf("") }

    Column(
        Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        ScreenTitle(
            "Character Names & Text",
            "Add a name that appears on screen for a few seconds — great for introducing who's who as you narrate."
        )

        SectionCard(modifier = Modifier.padding(top = 12.dp, bottom = 16.dp)) {
            Text("Add a name", style = MaterialTheme.typography.labelMedium, color = Muted, modifier = Modifier.padding(bottom = 8.dp))
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(Modifier.weight(1f)) {
                    if (newText.isEmpty()) {
                        Text(
                            "Character name…",
                            color = Muted,
                            style = MaterialTheme.typography.bodyLarge,
                            modifier = Modifier.padding(12.dp)
                        )
                    }
                    BasicTextField(
                        value = newText,
                        onValueChange = { newText = it },
                        singleLine = true,
                        textStyle = TextStyle(color = TextMain, fontSize = MaterialTheme.typography.bodyLarge.fontSize),
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Surface, RoundedCornerShape(8.dp))
                            .padding(12.dp)
                    )
                }
                PrimaryButton(
                    "+ Add",
                    modifier = Modifier.width(90.dp),
                    onClick = {
                        if (newText.isNotBlank()) {
                            viewModel.addTextOverlay(newText)
                            newText = ""
                        }
                    }
                )
            }
        }

        if (state.textOverlays.isEmpty()) {
            AlertBox(
                "No text added yet — type a name above and tap Add, then adjust when and where it appears below.",
                AlertStyle.INFO,
                modifier = Modifier.padding(bottom = 12.dp)
            )
        }

        state.textOverlays.sortedBy { it.startSec }.forEach { overlay ->
            OverlayEditorCard(
                overlay = overlay,
                totalDuration = state.totalDurationSec,
                onUpdate = { text, start, duration, position, style ->
                    viewModel.updateTextOverlay(overlay.id, text, start, duration, position, style)
                },
                onDelete = { viewModel.removeTextOverlay(overlay.id) }
            )
        }

        PrimaryButton("Next — Preview →", modifier = Modifier.padding(top = 8.dp), onClick = { viewModel.goStep(AppStep.PREVIEW) })
        SecondaryButton(
            "← Back",
            onClick = { viewModel.goStep(if (state.scriptLoaded) AppStep.MATCH else AppStep.PHOTOS) }
        )
    }
}

@Composable
private fun OverlayEditorCard(
    overlay: TextOverlay,
    totalDuration: Double,
    onUpdate: (text: String?, start: Double?, duration: Double?, position: OverlayPosition?, style: OverlayStyle?) -> Unit,
    onDelete: () -> Unit
) {
    var textValue by remember(overlay.id) { mutableStateOf(overlay.text) }

    SectionCard(modifier = Modifier.padding(bottom = 12.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Box(Modifier.weight(1f)) {
                BasicTextField(
                    value = textValue,
                    onValueChange = {
                        textValue = it
                        onUpdate(it, null, null, null, null)
                    },
                    singleLine = true,
                    textStyle = TextStyle(color = TextMain, fontSize = MaterialTheme.typography.bodyLarge.fontSize, fontWeight = FontWeight.Bold),
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Surface, RoundedCornerShape(8.dp))
                        .padding(10.dp)
                )
            }
            IconButton(onClick = onDelete, modifier = Modifier.size(36.dp)) {
                Icon(Icons.Filled.Close, contentDescription = "Remove", tint = Red)
            }
        }

        OverlayPreviewBox(
            text = overlay.text.ifBlank { "Name" },
            style = overlay.style,
            position = overlay.position,
            modifier = Modifier.padding(top = 12.dp, bottom = 12.dp)
        )

        Text(
            "Appears at ${ScriptParser.formatTime(overlay.startSec)} for ${formatSeconds(overlay.durationSec)}s" +
                if (overlay.startSec + overlay.durationSec > totalDuration && totalDuration > 0.0) " (past the end of your video)" else "",
            color = Muted,
            style = MaterialTheme.typography.bodySmall
        )

        Row(Modifier.padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("Start", color = Muted, style = MaterialTheme.typography.labelSmall, modifier = Modifier.width(48.dp))
            StepperButton("−") { onUpdate(null, (overlay.startSec - 0.5).coerceAtLeast(0.0), null, null, null) }
            StepperButton("+") { onUpdate(null, overlay.startSec + 0.5, null, null, null) }
            Text("Length", color = Muted, style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(start = 12.dp).width(56.dp))
            StepperButton("−") { onUpdate(null, null, (overlay.durationSec - 0.5).coerceAtLeast(0.5), null, null) }
            StepperButton("+") { onUpdate(null, null, overlay.durationSec + 0.5, null, null) }
        }

        Text("Position", color = Muted, style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(top = 12.dp, bottom = 6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OverlayPosition.entries.forEach { pos ->
                ChoiceChip(pos.label, selected = overlay.position == pos) { onUpdate(null, null, null, pos, null) }
            }
        }

        Text("Style", color = Muted, style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(top = 10.dp, bottom = 6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OverlayStyle.entries.forEach { st ->
                ChoiceChip(st.label, selected = overlay.style == st) { onUpdate(null, null, null, null, st) }
            }
        }
    }
}

@Composable
private fun ChoiceChip(label: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(if (selected) Accent else CardBg)
            .border(1.dp, if (selected) Accent else BorderColor, RoundedCornerShape(20.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp)
    ) {
        Text(label, color = if (selected) Color.Black else TextMain, style = MaterialTheme.typography.labelMedium)
    }
}

@Composable
private fun StepperButton(label: String, onClick: () -> Unit) {
    Box(
        Modifier
            .size(32.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(CardBg)
            .border(1.dp, BorderColor, RoundedCornerShape(8.dp))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = Accent, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
    }
}

/** A rough Compose approximation of how each style renders in the actual export (see
 *  FrameRenderer.drawTextOverlays) — close enough to judge the look and position at a glance. */
@Composable
private fun OverlayPreviewBox(text: String, style: OverlayStyle, position: OverlayPosition, modifier: Modifier = Modifier) {
    Box(
        modifier
            .fillMaxWidth()
            .height(100.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(Brush.linearGradient(listOf(Color(0xFF1A1A2E), Color(0xFF16213E)))),
        contentAlignment = when (position) {
            OverlayPosition.TOP -> Alignment.TopCenter
            OverlayPosition.CENTER -> Alignment.Center
            OverlayPosition.BOTTOM -> Alignment.BottomCenter
        }
    ) {
        Box(Modifier.padding(12.dp)) {
            when (style) {
                OverlayStyle.TAG -> {
                    Row(
                        Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color.Black.copy(alpha = 0.75f)),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(Modifier.width(4.dp).height(26.dp).background(Accent))
                        Text(
                            text,
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                        )
                    }
                }
                OverlayStyle.UNDERLINE -> {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(text, color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                        Box(
                            Modifier
                                .padding(top = 4.dp)
                                .width(60.dp)
                                .height(3.dp)
                                .background(Accent)
                        )
                    }
                }
                OverlayStyle.MINIMAL -> {
                    Text(text, color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                }
            }
        }
    }
}

private fun formatSeconds(v: Double): String {
    val rounded = Math.round(v * 10.0) / 10.0
    return if (rounded == rounded.toLong().toDouble()) rounded.toLong().toString() else rounded.toString()
}
