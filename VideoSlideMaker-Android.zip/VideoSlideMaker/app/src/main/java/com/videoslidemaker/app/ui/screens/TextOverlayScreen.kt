package com.videoslidemaker.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import com.videoslidemaker.app.data.ScriptParser
import com.videoslidemaker.app.model.AppStep
import com.videoslidemaker.app.model.OverlayStyle
import com.videoslidemaker.app.model.TextOverlay
import com.videoslidemaker.app.model.UiState
import com.videoslidemaker.app.ui.components.AlertBox
import com.videoslidemaker.app.ui.components.AlertStyle
import com.videoslidemaker.app.ui.components.PrimaryButton
import com.videoslidemaker.app.ui.components.ScreenTitle
import com.videoslidemaker.app.ui.components.SecondaryButton
import com.videoslidemaker.app.ui.components.SectionCard
import com.videoslidemaker.app.ui.theme.Accent
import com.videoslidemaker.app.ui.theme.BorderColor
import com.videoslidemaker.app.ui.theme.CardBg
import com.videoslidemaker.app.ui.theme.Muted
import com.videoslidemaker.app.ui.theme.Red
import com.videoslidemaker.app.ui.theme.Surface
import com.videoslidemaker.app.ui.theme.TextMain
import com.videoslidemaker.app.viewmodel.AppViewModel

/**
 * NEW: character-name (or any short label) text overlays — burned into the exported video for
 * a chosen time window, independent of which photo is showing. Built for "movie explanation"
 * style content, where introducing who's who by name is a common, recurring need. Position is
 * fully freeform — dragged directly on a mini preview, not picked from a handful of presets.
 */
@Composable
fun TextOverlayScreen(state: UiState, viewModel: AppViewModel) {
    var newText by remember { mutableStateOf("") }

    Column(
        Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        ScreenTitle(
            "Character Names & Text",
            "Add a name that appears on screen for a few seconds — great for introducing who's who as you narrate."
        )

        SectionCard(modifier = Modifier.padding(top = 12.dp, bottom = 16.dp)) {
            Text("Add a name", style = MaterialTheme.typography.labelMedium, color = Muted, modifier = Modifier.padding(bottom = 8.dp))
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(Modifier.weight(1f)) {
                    if (newText.isEmpty()) {
                        Text(
                            "Character name…",
                            color = Muted,
                            style = MaterialTheme.typography.bodyLarge,
                            modifier = Modifier.padding(12.dp)
                        )
                    }
                    BasicTextField(
                        value = newText,
                        onValueChange = { newText = it },
                        singleLine = true,
                        textStyle = TextStyle(color = TextMain, fontSize = MaterialTheme.typography.bodyLarge.fontSize),
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Surface, RoundedCornerShape(8.dp))
                            .padding(12.dp)
                    )
                }
                PrimaryButton(
                    "+ Add",
                    modifier = Modifier.width(90.dp),
                    onClick = {
                        if (newText.isNotBlank()) {
                            viewModel.addTextOverlay(newText)
                            newText = ""
                        }
                    }
                )
            }
        }

        if (state.textOverlays.isEmpty()) {
            AlertBox(
                "No text added yet — type a name above and tap Add, then drag it into place below.",
                AlertStyle.INFO,
                modifier = Modifier.padding(bottom = 12.dp)
            )
        }

        state.textOverlays.sortedBy { it.startSec }.forEach { overlay ->
            OverlayEditorCard(
                overlay = overlay,
                totalDuration = state.totalDurationSec,
                onUpdate = { text, start, duration, xFraction, yFraction, style ->
                    viewModel.updateTextOverlay(overlay.id, text, start, duration, xFraction, yFraction, style)
                },
                onDelete = { viewModel.removeTextOverlay(overlay.id) }
            )
        }

        PrimaryButton("Next — Preview →", modifier = Modifier.padding(top = 8.dp), onClick = { viewModel.goStep(AppStep.PREVIEW) })
        SecondaryButton(
            "← Back",
            onClick = { viewModel.goStep(if (state.scriptLoaded) AppStep.MATCH else AppStep.PHOTOS) }
        )
    }
}

@Composable
private fun OverlayEditorCard(
    overlay: TextOverlay,
    totalDuration: Double,
    onUpdate: (text: String?, start: Double?, duration: Double?, xFraction: Float?, yFraction: Float?, style: OverlayStyle?) -> Unit,
    onDelete: () -> Unit
) {
    var textValue by remember(overlay.id) { mutableStateOf(overlay.text) }
    // NEW: seeded from the current start time, but not re-synced on every recomposition — so it
    // holds whatever the person is mid-typing (including briefly-invalid states like "12:") until
    // it parses to a real value, which is when it actually gets applied.
    var startText by remember(overlay.id) { mutableStateOf(ScriptParser.formatTime(overlay.startSec)) }
    val startParsesOk = ScriptParser.parseTime(startText) != null

    SectionCard(modifier = Modifier.padding(bottom = 12.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Box(Modifier.weight(1f)) {
                BasicTextField(
                    value = textValue,
                    onValueChange = {
                        textValue = it
                        onUpdate(it, null, null, null, null, null)
                    },
                    singleLine = true,
                    textStyle = TextStyle(color = TextMain, fontSize = MaterialTheme.typography.bodyLarge.fontSize, fontWeight = FontWeight.Bold),
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Surface, RoundedCornerShape(8.dp))
                        .padding(10.dp)
                )
            }
            IconButton(onClick = onDelete, modifier = Modifier.size(36.dp)) {
                Icon(Icons.Filled.Close, contentDescription = "Remove", tint = Red)
            }
        }

        Text(
            "Drag the name below to position it",
            style = MaterialTheme.typography.labelSmall,
            color = Muted,
            modifier = Modifier.padding(top = 12.dp, bottom = 6.dp)
        )
        DraggableOverlayPreview(
            text = overlay.text.ifBlank { "Name" },
            style = overlay.style,
            xFraction = overlay.xFraction,
            yFraction = overlay.yFraction,
            onPositionChange = { x, y -> onUpdate(null, null, null, x, y, null) }
        )

        Text(
            "Appears at ${ScriptParser.formatTime(overlay.startSec)} for ${formatSeconds(overlay.durationSec)}s" +
                if (overlay.startSec + overlay.durationSec > totalDuration && totalDuration > 0.0) " (past the end of your video)" else "",
            color = Muted,
            style = MaterialTheme.typography.bodySmall,
            modifier = Modifier.padding(top = 12.dp)
        )

        // NEW: type the start time directly (e.g. "45:30") instead of only nudging by 0.5s —
        // the only practical way to place text late into a long video without tapping hundreds
        // or thousands of times.
        Row(Modifier.padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Start", color = Muted, style = MaterialTheme.typography.labelSmall, modifier = Modifier.width(48.dp))
            Box(Modifier.width(96.dp)) {
                BasicTextField(
                    value = startText,
                    onValueChange = { new ->
                        startText = new
                        onUpdate(null, ScriptParser.parseTime(new), null, null, null, null)
                    },
                    singleLine = true,
                    textStyle = TextStyle(color = if (startParsesOk) TextMain else Red, fontSize = MaterialTheme.typography.bodyMedium.fontSize),
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Surface, RoundedCornerShape(8.dp))
                        .border(1.dp, if (startParsesOk) BorderColor else Red, RoundedCornerShape(8.dp))
                        .padding(8.dp)
                )
            }
            Text("(m:ss)", color = Muted, style = MaterialTheme.typography.labelSmall)
            StepperButton("−") {
                val v = (overlay.startSec - 0.5).coerceAtLeast(0.0)
                startText = ScriptParser.formatTime(v)
                onUpdate(null, v, null, null, null, null)
            }
            StepperButton("+") {
                val v = overlay.startSec + 0.5
                startText = ScriptParser.formatTime(v)
                onUpdate(null, v, null, null, null, null)
            }
        }

        Row(Modifier.padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("Length", color = Muted, style = MaterialTheme.typography.labelSmall, modifier = Modifier.width(48.dp))
            StepperButton("−") { onUpdate(null, null, (overlay.durationSec - 0.5).coerceAtLeast(0.5), null, null, null) }
            StepperButton("+") { onUpdate(null, null, overlay.durationSec + 0.5, null, null, null) }
        }

        Text("Style", color = Muted, style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(top = 12.dp, bottom = 6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OverlayStyle.entries.forEach { st ->
                ChoiceChip(st.label, selected = overlay.style == st) { onUpdate(null, null, null, null, null, st) }
            }
        }
    }
}

/**
 * NEW: a mini version of the actual frame the name will appear on, where the name itself is
 * draggable to any point — not confined to a handful of preset slots. [xFraction]/[yFraction]
 * (0..1) are the CENTER of the tag as a fraction of this box's width/height, and the export
 * (FrameRenderer.drawTextOverlays) and live Preview both read the exact same two numbers, so
 * wherever it's dropped here is exactly where it ends up.
 */
@Composable
private fun DraggableOverlayPreview(
    text: String,
    style: OverlayStyle,
    xFraction: Float,
    yFraction: Float,
    onPositionChange: (xFraction: Float, yFraction: Float) -> Unit
) {
    var containerSize by remember { mutableStateOf(IntSize.Zero) }
    // Drag gestures are set up once (keyed by Unit) and would otherwise keep using whatever
    // xFraction/yFraction/onPositionChange existed at that first setup — rememberUpdatedState
    // keeps a live reference so a drag reads the CURRENT position on every move, not a stale one.
    val latestX = rememberUpdatedState(xFraction)
    val latestY = rememberUpdatedState(yFraction)
    val latestOnChange = rememberUpdatedState(onPositionChange)

    Box(
        Modifier
            .fillMaxWidth()
            .height(140.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(Brush.linearGradient(listOf(Color(0xFF1A1A2E), Color(0xFF16213E))))
            .onSizeChanged { containerSize = it }
    ) {
        // Alignment's bias system (-1..1) centers its child around the point automatically,
        // accounting for the tag's own measured size — no manual "subtract half the width" math.
        val bias = Alignment(xFraction * 2f - 1f, yFraction * 2f - 1f)
        Box(
            Modifier
                .align(bias)
                .pointerInput(Unit) {
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        val w = containerSize.width.coerceAtLeast(1)
                        val h = containerSize.height.coerceAtLeast(1)
                        val newX = (latestX.value + dragAmount.x / w).coerceIn(0.04f, 0.96f)
                        val newY = (latestY.value + dragAmount.y / h).coerceIn(0.08f, 0.92f)
                        latestOnChange.value(newX, newY)
                    }
                }
        ) {
            OverlayTagContent(text, style)
        }
    }
}

/** The actual TAG/UNDERLINE/MINIMAL visual, shared by the draggable editor preview above. */
@Composable
private fun OverlayTagContent(text: String, style: OverlayStyle) {
    when (style) {
        OverlayStyle.TAG -> {
            Row(
                Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color.Black.copy(alpha = 0.75f)),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(Modifier.width(4.dp).height(26.dp).background(Accent))
                Text(
                    text,
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                )
            }
        }
        OverlayStyle.UNDERLINE -> {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(text, color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                Box(
                    Modifier
                        .padding(top = 4.dp)
                        .width(60.dp)
                        .height(3.dp)
                        .background(Accent)
                )
            }
        }
        OverlayStyle.MINIMAL -> {
            Text(text, color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
        }
    }
}

@Composable
private fun ChoiceChip(label: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(if (selected) Accent else CardBg)
            .border(1.dp, if (selected) Accent else BorderColor, RoundedCornerShape(20.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp)
    ) {
        Text(label, color = if (selected) Color.Black else TextMain, style = MaterialTheme.typography.labelMedium)
    }
}

@Composable
private fun StepperButton(label: String, onClick: () -> Unit) {
    Box(
        Modifier
            .size(32.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(CardBg)
            .border(1.dp, BorderColor, RoundedCornerShape(8.dp))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = Accent, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
    }
}

private fun formatSeconds(v: Double): String {
    val rounded = Math.round(v * 10.0) / 10.0
    return if (rounded == rounded.toLong().toDouble()) rounded.toLong().toString() else rounded.toString()
}
