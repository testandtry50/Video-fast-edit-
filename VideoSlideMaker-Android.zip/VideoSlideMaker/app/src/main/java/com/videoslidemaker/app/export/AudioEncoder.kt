package com.videoslidemaker.app.export

import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat

/** Encodes 16-bit PCM into AAC and writes it into the shared muxer's audio track. */
class AudioEncoder(
    private val sampleRate: Int,
    private val channelCount: Int,
    bitrateBps: Int,
    private val muxer: MuxerHolder
) {
    private val mimeType = MediaFormat.MIMETYPE_AUDIO_AAC
    private val codec: MediaCodec = MediaCodec.createEncoderByType(mimeType)
    private val bufferInfo = MediaCodec.BufferInfo()
    private var trackIndex = -1
    private var totalFramesWritten = 0L

    init {
        val format = MediaFormat.createAudioFormat(mimeType, sampleRate, channelCount).apply {
            setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
            setInteger(MediaFormat.KEY_BIT_RATE, bitrateBps)
        }
        codec.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        codec.start()
    }

    /** Feeds up to [length] bytes of 16-bit PCM starting at index 0 of [pcm]. */
    fun feedPcm(pcm: ByteArray, length: Int) {
        var offset = 0
        while (offset < length) {
            val inputIndex = codec.dequeueInputBuffer(TIMEOUT_US)
            if (inputIndex >= 0) {
                val buffer = codec.getInputBuffer(inputIndex)
                if (buffer != null) {
                    buffer.clear()
                    val chunk = minOf(buffer.capacity(), length - offset)
                    buffer.put(pcm, offset, chunk)
                    val ptsUs = totalFramesWritten * 1_000_000L / sampleRate
                    codec.queueInputBuffer(inputIndex, 0, chunk, ptsUs, 0)
                    totalFramesWritten += chunk / (2 * channelCount)
                    offset += chunk
                } else {
                    // Should not happen for a validly dequeued index; queue an empty
                    // buffer so this slot isn't left dangling, and retry next loop.
                    codec.queueInputBuffer(inputIndex, 0, 0, 0, 0)
                }
            }
            drain(false)
        }
    }

    fun finish() {
        val inputIndex = codec.dequeueInputBuffer(TIMEOUT_US)
        if (inputIndex >= 0) {
            val ptsUs = totalFramesWritten * 1_000_000L / sampleRate
            codec.queueInputBuffer(inputIndex, 0, 0, ptsUs, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
        }
        drain(true)
        codec.stop()
        codec.release()
    }

    private fun drain(endOfStream: Boolean) {
        while (true) {
            val outputIndex = codec.dequeueOutputBuffer(bufferInfo, TIMEOUT_US)
            when {
                outputIndex == MediaCodec.INFO_TRY_AGAIN_LATER -> if (!endOfStream) return
                outputIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                    trackIndex = muxer.addAudioTrack(codec.outputFormat)
                }
                outputIndex >= 0 -> {
                    val encodedData = codec.getOutputBuffer(outputIndex)
                    if (encodedData != null && bufferInfo.size > 0 &&
                        (bufferInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0
                    ) {
                        encodedData.position(bufferInfo.offset)
                        encodedData.limit(bufferInfo.offset + bufferInfo.size)
                        muxer.writeAudioSample(trackIndex, encodedData, bufferInfo)
                    }
                    codec.releaseOutputBuffer(outputIndex, false)
                    if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) return
                }
            }
        }
    }

    companion object {
        private const val TIMEOUT_US = 10_000L
    }
}
