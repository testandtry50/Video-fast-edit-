package com.videoslidemaker.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenu
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import com.videoslidemaker.app.model.AppStep
import com.videoslidemaker.app.model.AspectRatioOption
import com.videoslidemaker.app.model.QualityOption
import com.videoslidemaker.app.model.UiState
import com.videoslidemaker.app.ui.components.AlertStyle
import com.videoslidemaker.app.ui.components.BadgeChip
import com.videoslidemaker.app.ui.components.PrimaryButton
import com.videoslidemaker.app.ui.components.ScreenTitle
import com.videoslidemaker.app.ui.components.SectionCard
import com.videoslidemaker.app.ui.components.SettingRow
import com.videoslidemaker.app.ui.components.ToggleSwitch
import com.videoslidemaker.app.ui.theme.Accent
import com.videoslidemaker.app.ui.theme.AccentGradient
import com.videoslidemaker.app.ui.theme.BorderColor
import com.videoslidemaker.app.ui.theme.Muted
import com.videoslidemaker.app.ui.theme.Surface
import com.videoslidemaker.app.viewmodel.AppViewModel
import kotlin.math.max
import kotlin.math.min

private val VOICE_OPTIONS = listOf("hi-IN" to "Hindi", "en-US" to "English", "en-IN" to "English (India)")

@Composable
fun ScriptScreen(state: UiState, viewModel: AppViewModel, onPickScriptFile: () -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        ScreenTitle(
            "Upload Your Script (optional)",
            "Only needed if you want spoken narration synced to sentences. For a simple slideshow, skip straight to Photos and set each photo's time there."
        )

        UploadZone(
            done = state.scriptLoaded,
            icon = "📄",
            title = "Tap to upload script .txt file",
            hint = "Format: 0:06 - admi ne khana khaya",
            onClick = onPickScriptFile
        )

        BadgeChip(
            text = if (state.scriptLoaded) {
                val withText = state.slides.count { it.text.isNotBlank() }
                "✅ ${state.slides.size} timestamps loaded ($withText with sentences)"
            } else "⏳ No file uploaded yet",
            style = if (state.scriptLoaded) AlertStyle.SUCCESS else AlertStyle.WARNING,
            modifier = Modifier.padding(bottom = 12.dp)
        )

        SectionCard(title = "📝 How to write your script file", modifier = Modifier.padding(bottom = 12.dp)) {
            TipLine("Each line: timestamp, then dash, then sentence")
            TipLine("Example: 0:00 - Once upon a time")
            TipLine("Example: 0:06 - admi ne khana khaya")
            TipLine("Mix Hindi, English or Hinglish — all work fine")
            TipLine("Just timestamps with no text also works (old format)")
        }

        SectionCard(title = "⚙️ Settings", modifier = Modifier.padding(bottom = 12.dp)) {
            SettingRow("Default Duration", "Seconds per image") {
                Stepper(
                    value = state.settings.defaultDurationSec,
                    range = 1..30,
                    onChange = viewModel::setDefaultDuration
                )
            }
            SettingRow("Voice Language", "For reading sentences aloud, and for narration in the exported video") {
                LabeledDropdown(
                    options = VOICE_OPTIONS.map { it.second },
                    selectedIndex = VOICE_OPTIONS.indexOfFirst { it.first == state.settings.narration.voiceLocaleTag }.coerceAtLeast(0),
                    onSelect = { idx -> viewModel.setVoiceLocale(VOICE_OPTIONS[idx].first) }
                )
            }
            SettingRow("Zoom Effect", "Ken Burns zoom") {
                ToggleSwitch(state.settings.zoomEffect, viewModel::setZoomEffect)
            }
            SettingRow("Fade Transition", "Smooth fade between images") {
                ToggleSwitch(state.settings.fadeTransition, viewModel::setFadeTransition)
            }
            SettingRow("Narration in video", "NEW — bakes the spoken voice into the exported file") {
                ToggleSwitch(state.settings.narration.enabled, viewModel::setNarrationEnabled)
            }
            SettingRow("Aspect Ratio", "Shape of your video") {
                LabeledDropdown(
                    options = AspectRatioOption.entries.map { it.label },
                    selectedIndex = AspectRatioOption.entries.indexOf(state.settings.aspectRatio),
                    onSelect = { idx -> viewModel.setAspectRatio(AspectRatioOption.entries[idx]) }
                )
            }
            SettingRow("Resolution", "Output video size") {
                LabeledDropdown(
                    options = QualityOption.entries.map { it.label },
                    selectedIndex = QualityOption.entries.indexOf(state.settings.quality),
                    onSelect = { idx -> viewModel.setQuality(QualityOption.entries[idx]) }
                )
            }

            val (outW, outH) = previewOutputSize(state)
            Text(
                "Output size: $outW×$outH",
                style = MaterialTheme.typography.bodySmall,
                color = Muted,
                modifier = Modifier.padding(top = 8.dp)
            )
        }

        AspectPreviewBox(state)

        PrimaryButton(
            if (state.scriptLoaded) "Next — Add Photos →" else "Skip — Add Photos Directly →",
            modifier = Modifier.padding(top = 4.dp),
            onClick = { viewModel.goStep(AppStep.PHOTOS) }
        )
    }
}

@Composable
private fun TipLine(text: String) {
    Row(Modifier.padding(bottom = 5.dp)) {
        Text("→ ", color = Accent, style = MaterialTheme.typography.bodySmall)
        Text(text, color = Muted, style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
fun UploadZone(done: Boolean, icon: String, title: String, hint: String, onClick: () -> Unit) {
    val borderColor = if (done) com.videoslidemaker.app.ui.theme.Green else BorderColor
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(Surface)
            .border(2.dp, borderColor, RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 24.dp, horizontal = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(icon, style = MaterialTheme.typography.headlineSmall)
        Text(title, style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(top = 8.dp, bottom = 4.dp))
        Text(hint, style = MaterialTheme.typography.bodySmall, color = Muted)
    }
}

@Composable
fun Stepper(value: Int, range: IntRange, onChange: (Int) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = { onChange(max(range.first, value - 1)) }, modifier = Modifier.size(32.dp)) {
            Icon(Icons.Filled.Remove, contentDescription = "Decrease", tint = Muted)
        }
        Text("$value", style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(horizontal = 4.dp))
        IconButton(onClick = { onChange(min(range.last, value + 1)) }, modifier = Modifier.size(32.dp)) {
            Icon(Icons.Filled.Add, contentDescription = "Increase", tint = Muted)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LabeledDropdown(options: List<String>, selectedIndex: Int, onSelect: (Int) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    val safeIndex = selectedIndex.coerceIn(0, (options.size - 1).coerceAtLeast(0))
    ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = it }) {
        Row(
            Modifier
                .menuAnchor()
                .clip(RoundedCornerShape(9.dp))
                .background(Surface)
                .border(1.dp, BorderColor, RoundedCornerShape(9.dp))
                .clickable { expanded = true }
                .padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(options.getOrElse(safeIndex) { "" }, style = MaterialTheme.typography.bodyMedium)
            Icon(Icons.Filled.KeyboardArrowDown, contentDescription = null, tint = Muted, modifier = Modifier.size(16.dp))
        }
        ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            options.forEachIndexed { index, label ->
                DropdownMenuItem(
                    text = { Text(label) },
                    onClick = { onSelect(index); expanded = false }
                )
            }
        }
    }
}

@Composable
fun AspectPreviewBox(state: UiState) {
    val ratio = state.settings.aspectRatio
    SectionCard(modifier = Modifier.padding(top = 4.dp, bottom = 12.dp)) {
        Text(
            "PREVIEW SHAPE",
            style = MaterialTheme.typography.labelMedium,
            color = Muted,
            modifier = Modifier.padding(bottom = 14.dp)
        )
        Box(Modifier.fillMaxWidth().height(160.dp), contentAlignment = Alignment.Center) {
            val boxRatio = ratio.w.toFloat() / ratio.h.toFloat()
            Box(
                Modifier
                    .fillMaxWidth(if (boxRatio >= 1f) 0.7f else 0.7f * boxRatio)
                    .aspectRatio(boxRatio)
                    .clip(RoundedCornerShape(8.dp))
                    .background(androidx.compose.ui.graphics.Brush.linearGradient(AccentGradient))
            )
        }
    }
}

/** Mirrors getAspectWH(forExport=true) from the original script, for the live "Output size" label. */
private fun previewOutputSize(state: UiState): Pair<Int, Int> {
    val ratio = state.settings.aspectRatio
    fun evenize(v: Int) = if (v % 2 == 0) v else v + 1
    if (state.settings.quality == QualityOption.ORIGINAL) {
        val largest = state.images.maxByOrNull { it.widthPx.toLong() * it.heightPx.toLong() }
        val maxW = largest?.widthPx?.takeIf { it > 0 } ?: 1920
        val maxH = largest?.heightPx?.takeIf { it > 0 } ?: 1080
        val base = max(maxW, maxH)
        var w: Int
        var h: Int
        if (ratio.w >= ratio.h) {
            h = base * ratio.h / ratio.w; w = base
            if (w < maxW) { w = maxW; h = (w.toLong() * ratio.h / ratio.w).toInt() }
        } else {
            w = base * ratio.w / ratio.h; h = base
            if (h < maxH) { h = maxH; w = (h.toLong() * ratio.w / ratio.h).toInt() }
        }
        return evenize(w) to evenize(h)
    }
    val base = state.settings.quality.basePx ?: 720
    var w: Int
    var h: Int
    if (ratio.w >= ratio.h) { h = base; w = ((base.toLong() * ratio.w) / ratio.h).toInt() }
    else { w = base; h = ((base.toLong() * ratio.h) / ratio.w).toInt() }
    return evenize(w) to evenize(h)
}
