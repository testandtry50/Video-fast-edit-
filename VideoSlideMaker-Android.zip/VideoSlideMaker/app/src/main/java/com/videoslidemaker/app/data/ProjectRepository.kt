package com.videoslidemaker.app.data

import android.content.Context
import android.net.Uri
import com.videoslidemaker.app.model.AppStep
import com.videoslidemaker.app.model.AspectRatioOption
import com.videoslidemaker.app.model.EffectStyle
import com.videoslidemaker.app.model.ExportSettings
import com.videoslidemaker.app.model.MusicTrack
import com.videoslidemaker.app.model.NarrationSettings
import com.videoslidemaker.app.model.OverlayAlign
import com.videoslidemaker.app.model.OverlayPosition
import com.videoslidemaker.app.model.OverlayStyle
import com.videoslidemaker.app.model.PoolImage
import com.videoslidemaker.app.model.QualityOption
import com.videoslidemaker.app.model.SentenceSlide
import com.videoslidemaker.app.model.TextOverlay
import com.videoslidemaker.app.model.TransitionStyle
import com.videoslidemaker.app.model.UiState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * NEW: lightweight auto-save so switching apps, rotating the phone, or a low-memory kill
 * doesn't lose a half-finished project — the original browser tab had no protection against
 * that at all. Only a small JSON descriptor is written; photos and music stay wherever the
 * user picked them from (their content Uri, plus the persisted read permission, is what's saved).
 */
class ProjectRepository(context: Context) {
    private val file = File(context.filesDir, "project_draft.json")

    suspend fun save(state: UiState) = withContext(Dispatchers.IO) {
        try {
            val root = JSONObject()
            root.put("defaultDurationSec", state.settings.defaultDurationSec)
            root.put("voiceLocaleTag", state.settings.narration.voiceLocaleTag)
            root.put("narrationEnabled", state.settings.narration.enabled)
            root.put("effectStyle", state.settings.effectStyle.name)
            root.put("transitionStyle", state.settings.transitionStyle.name)
            root.put("aspectRatio", state.settings.aspectRatio.name)
            root.put("quality", state.settings.quality.name)
            root.put("musicUri", state.settings.music.uri?.toString())
            root.put("musicVolume", state.settings.music.volume.toDouble())

            val slidesArray = JSONArray()
            state.slides.forEach { slide ->
                val obj = JSONObject()
                obj.put("t", slide.timestampSec)
                obj.put("text", slide.text)
                obj.put("assignedImageId", slide.assignedImageId)
                slidesArray.put(obj)
            }
            root.put("slides", slidesArray)

            val imagesArray = JSONArray()
            state.images.forEach { img ->
                val obj = JSONObject()
                obj.put("id", img.id)
                obj.put("uri", img.uri.toString())
                obj.put("name", img.displayName)
                obj.put("w", img.widthPx)
                obj.put("h", img.heightPx)
                obj.put("durationOverrideSec", img.durationOverrideSec)
                imagesArray.put(obj)
            }
            root.put("images", imagesArray)

            val overlaysArray = JSONArray()
            state.textOverlays.forEach { ov ->
                val obj = JSONObject()
                obj.put("id", ov.id)
                obj.put("text", ov.text)
                obj.put("start", ov.startSec)
                obj.put("duration", ov.durationSec)
                obj.put("position", ov.position.name)
                obj.put("align", ov.align.name)
                obj.put("style", ov.style.name)
                overlaysArray.put(obj)
            }
            root.put("textOverlays", overlaysArray)

            file.writeText(root.toString())
        } catch (_: Exception) {
            // Auto-save is best-effort; a failed draft write should never crash the app.
        }
    }

    suspend fun load(): UiState? = withContext(Dispatchers.IO) {
        try {
            if (!file.exists()) return@withContext null
            val root = JSONObject(file.readText())

            val slides = mutableListOf<SentenceSlide>()
            val slidesArray = root.optJSONArray("slides") ?: JSONArray()
            for (i in 0 until slidesArray.length()) {
                val obj = slidesArray.getJSONObject(i)
                slides.add(
                    SentenceSlide(
                        timestampSec = obj.getDouble("t"),
                        text = obj.optString("text", ""),
                        assignedImageId = if (obj.isNull("assignedImageId")) null else obj.optString("assignedImageId")
                    )
                )
            }

            val images = mutableListOf<PoolImage>()
            val imagesArray = root.optJSONArray("images") ?: JSONArray()
            for (i in 0 until imagesArray.length()) {
                val obj = imagesArray.getJSONObject(i)
                images.add(
                    PoolImage(
                        id = obj.getString("id"),
                        uri = Uri.parse(obj.getString("uri")),
                        displayName = obj.optString("name", "photo"),
                        widthPx = obj.optInt("w", 0),
                        heightPx = obj.optInt("h", 0),
                        durationOverrideSec = if (obj.isNull("durationOverrideSec")) null else obj.optDouble("durationOverrideSec").takeIf { !it.isNaN() }
                    )
                )
            }

            val musicUriStr = root.optString("musicUri", "")
            val settings = ExportSettings(
                aspectRatio = AspectRatioOption.entries.firstOrNull { it.name == root.optString("aspectRatio") }
                    ?: AspectRatioOption.R16_9,
                quality = QualityOption.entries.firstOrNull { it.name == root.optString("quality") }
                    ?: QualityOption.P720,
                effectStyle = EffectStyle.entries.firstOrNull { it.name == root.optString("effectStyle") }
                    ?: EffectStyle.ZOOM_IN,
                transitionStyle = TransitionStyle.entries.firstOrNull { it.name == root.optString("transitionStyle") }
                    ?: TransitionStyle.FADE_BLACK,
                defaultDurationSec = root.optInt("defaultDurationSec", 3),
                narration = NarrationSettings(
                    enabled = root.optBoolean("narrationEnabled", true),
                    voiceLocaleTag = root.optString("voiceLocaleTag", "hi-IN")
                ),
                music = MusicTrack(
                    uri = musicUriStr.takeIf { it.isNotBlank() }?.let { Uri.parse(it) },
                    volume = root.optDouble("musicVolume", 0.35).toFloat()
                )
            )

            val overlays = mutableListOf<TextOverlay>()
            val overlaysArray = root.optJSONArray("textOverlays") ?: JSONArray()
            for (i in 0 until overlaysArray.length()) {
                val obj = overlaysArray.getJSONObject(i)
                overlays.add(
                    TextOverlay(
                        id = obj.getString("id"),
                        text = obj.optString("text", ""),
                        startSec = obj.optDouble("start", 0.0),
                        durationSec = obj.optDouble("duration", 3.0),
                        position = OverlayPosition.entries.firstOrNull { it.name == obj.optString("position") }
                            ?: OverlayPosition.BOTTOM,
                        align = OverlayAlign.entries.firstOrNull { it.name == obj.optString("align") }
                            ?: OverlayAlign.CENTER,
                        style = OverlayStyle.entries.firstOrNull { it.name == obj.optString("style") }
                            ?: OverlayStyle.TAG
                    )
                )
            }

            UiState(
                step = if (slides.isNotEmpty()) AppStep.PHOTOS else AppStep.SCRIPT,
                scriptLoaded = slides.isNotEmpty(),
                slides = slides,
                images = images,
                settings = settings,
                textOverlays = overlays
            )
        } catch (_: Exception) {
            null
        }
    }

    suspend fun clear() = withContext(Dispatchers.IO) {
        file.delete()
        Unit
    }
}
