package com.videoslidemaker.app.ui.theme

import androidx.compose.ui.graphics.Color

// Ported 1:1 from the original CSS :root custom properties.
val BgDark = Color(0xFF08080F)
val Surface = Color(0xFF10101A)
val CardBg = Color(0xFF181825)
val BorderColor = Color(0xFF252535)
val Accent = Color(0xFF6C63FF)
val Accent2 = Color(0xFFFF5FA0)
val TextMain = Color(0xFFEDEDFF)
val Muted = Color(0xFF7777AA)
val Green = Color(0xFF3DDC84)
val Yellow = Color(0xFFFFC843)
val Red = Color(0xFFFF5C5C)

val AccentGradient = listOf(Accent, Accent2)
