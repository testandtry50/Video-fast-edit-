package com.videoslidemaker.app.ui.screens

import android.content.Intent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.videoslidemaker.app.data.ScriptParser
import com.videoslidemaker.app.model.AppStep
import com.videoslidemaker.app.model.QualityOption
import com.videoslidemaker.app.model.UiState
import com.videoslidemaker.app.ui.components.AlertBox
import com.videoslidemaker.app.ui.components.AlertStyle
import com.videoslidemaker.app.ui.components.PrimaryButton
import com.videoslidemaker.app.ui.components.ScreenTitle
import com.videoslidemaker.app.ui.components.SecondaryButton
import com.videoslidemaker.app.ui.components.SectionCard
import com.videoslidemaker.app.ui.components.SettingRow
import com.videoslidemaker.app.ui.theme.Accent
import com.videoslidemaker.app.ui.theme.Muted
import com.videoslidemaker.app.viewmodel.AppViewModel

@Composable
fun ExportScreen(state: UiState, viewModel: AppViewModel, onPickMusic: () -> Unit) {
    val context = LocalContext.current
    val progress = state.exportProgress

    Column(Modifier.fillMaxWidth().padding(16.dp)) {
        ScreenTitle("Create Your Video", "Review the details below, then create your finished video.")

        SectionCard(title = "Video Details", modifier = Modifier.padding(bottom = 12.dp)) {
            DetailRow("Photos in sequence", "${state.effectiveSlides.size}")
            DetailRow("Total duration", ScriptParser.formatTime(state.totalDurationSec))
            DetailRow("Zoom effect", if (state.settings.zoomEffect) "On" else "Off")
            DetailRow("Fade transition", if (state.settings.fadeTransition) "On" else "Off")
            DetailRow("Narration in video", if (state.settings.narration.enabled) "On" else "Off")
        }

        SectionCard(title = "🎵 Background Music (optional, new)", modifier = Modifier.padding(bottom = 12.dp)) {
            if (state.settings.music.uri == null) {
                SecondaryButton("Choose a music file", onClick = onPickMusic)
            } else {
                Text(
                    state.settings.music.displayName ?: "Music file selected",
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
                SettingRow("Music volume", "Relative to narration") {
                    Text("${(state.settings.music.volume * 100).toInt()}%", style = MaterialTheme.typography.bodySmall, color = Muted)
                }
                Slider(
                    value = state.settings.music.volume,
                    onValueChange = viewModel::setMusicVolume,
                    valueRange = 0f..1f
                )
                SecondaryButton("Remove music", onClick = { viewModel.setMusicUri(null, null) })
            }
        }

        if (state.settings.quality == QualityOption.P2160 || state.settings.quality == QualityOption.ORIGINAL) {
            AlertBox(
                "High resolution exports take longer and use more battery and storage. The export keeps running in the background even if you switch apps.",
                style = AlertStyle.WARNING,
                modifier = Modifier.padding(bottom = 12.dp)
            )
        }

        when {
            progress.running -> {
                SectionCard(modifier = Modifier.padding(bottom = 12.dp)) {
                    Text(progress.message, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(bottom = 8.dp))
                    LinearProgressIndicator(
                        progress = { progress.percent / 100f },
                        modifier = Modifier.fillMaxWidth(),
                        color = Accent
                    )
                    Text("${progress.percent}%", style = MaterialTheme.typography.labelMedium, color = Muted, modifier = Modifier.padding(top = 6.dp))
                }
                SecondaryButton("Cancel Export", onClick = viewModel::cancelExport)
            }
            progress.done && progress.outputUri != null -> {
                AlertBox("✅ Your video was saved to Movies/VideoSlideMaker.", style = AlertStyle.SUCCESS, modifier = Modifier.padding(bottom = 12.dp))
                PrimaryButton("Share Video", onClick = {
                    val shareIntent = Intent(Intent.ACTION_SEND).apply {
                        type = "video/mp4"
                        putExtra(Intent.EXTRA_STREAM, progress.outputUri)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    context.startActivity(Intent.createChooser(shareIntent, "Share video"))
                })
                SecondaryButton("Create Another Video", onClick = viewModel::startExport)
            }
            progress.done && progress.error != null -> {
                AlertBox("⚠️ ${progress.error}", style = AlertStyle.WARNING, modifier = Modifier.padding(bottom = 12.dp))
                PrimaryButton("Try Again", onClick = viewModel::startExport)
            }
            else -> {
                PrimaryButton("🎬 Create & Save Video", onClick = viewModel::startExport)
            }
        }

        SecondaryButton("← Back to Preview", modifier = Modifier.padding(top = 12.dp), onClick = { viewModel.goStep(AppStep.PREVIEW) })
    }
}

@Composable
private fun DetailRow(label: String, value: String) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, style = MaterialTheme.typography.bodyMedium, color = Muted)
        Text(value, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurface)
    }
}
