package com.videoslidemaker.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.videoslidemaker.app.ui.theme.Accent
import com.videoslidemaker.app.ui.theme.AccentGradient
import com.videoslidemaker.app.ui.theme.BorderColor
import com.videoslidemaker.app.ui.theme.CardBg
import com.videoslidemaker.app.ui.theme.Green
import com.videoslidemaker.app.ui.theme.Muted
import com.videoslidemaker.app.ui.theme.TextMain
import com.videoslidemaker.app.ui.theme.Yellow

@Composable
fun ScreenTitle(title: String, subtitle: String? = null) {
    Column(Modifier.padding(bottom = 20.dp)) {
        Text(title, style = MaterialTheme.typography.headlineSmall, color = TextMain)
        if (subtitle != null) {
            Text(
                subtitle,
                style = MaterialTheme.typography.bodyMedium,
                color = Muted,
                modifier = Modifier.padding(top = 4.dp)
            )
        }
    }
}

@Composable
fun SectionCard(title: String? = null, modifier: Modifier = Modifier, content: @Composable ColumnScopeContent) {
    Column(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(CardBg)
            .border(1.dp, BorderColor, RoundedCornerShape(14.dp))
            .padding(16.dp)
    ) {
        if (title != null) {
            Text(
                title.uppercase(),
                style = MaterialTheme.typography.labelMedium,
                color = Muted,
                modifier = Modifier.padding(bottom = 12.dp)
            )
        }
        content()
    }
}

typealias ColumnScopeContent = @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit

@Composable
fun SettingRow(label: String, hint: String? = null, control: @Composable () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(label, style = MaterialTheme.typography.bodyLarge, color = TextMain, fontWeight = FontWeight.Medium)
            if (hint != null) {
                Text(hint, style = MaterialTheme.typography.bodySmall, color = Muted, modifier = Modifier.padding(top = 2.dp))
            }
        }
        control()
    }
}

@Composable
fun ToggleSwitch(on: Boolean, onToggle: (Boolean) -> Unit, modifier: Modifier = Modifier) {
    val bg = if (on) Accent else BorderColor
    Box(
        modifier
            .size(width = 46.dp, height = 26.dp)
            .clip(RoundedCornerShape(13.dp))
            .background(bg)
            .clickable { onToggle(!on) }
            .padding(3.dp)
    ) {
        Box(
            Modifier
                .size(20.dp)
                .align(if (on) Alignment.CenterEnd else Alignment.CenterStart)
                .clip(CircleShape)
                .background(Color.White)
        )
    }
}

@Composable
fun PrimaryButton(
    text: String,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    onClick: () -> Unit
) {
    Button(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        shape = RoundedCornerShape(14.dp),
        contentPadding = PaddingValues(vertical = 15.dp),
        colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent, disabledContainerColor = Color.Transparent),
        elevation = null
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .background(
                    brush = Brush.linearGradient(if (enabled) AccentGradient else listOf(BorderColor, BorderColor)),
                    shape = RoundedCornerShape(14.dp)
                ),
            contentAlignment = Alignment.Center
        ) {
            Text(text, color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.padding(vertical = 2.dp))
        }
    }
}

@Composable
fun SecondaryButton(text: String, modifier: Modifier = Modifier, enabled: Boolean = true, onClick: () -> Unit) {
    OutlinedButton(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        shape = RoundedCornerShape(14.dp),
        contentPadding = PaddingValues(vertical = 15.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, BorderColor),
        colors = ButtonDefaults.outlinedButtonColors(contentColor = TextMain)
    ) {
        Text(text, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun RowScope.CompactButton(text: String, onClick: () -> Unit, enabled: Boolean = true) {
    OutlinedButton(
        onClick = onClick,
        enabled = enabled,
        modifier = Modifier.weight(1f),
        shape = RoundedCornerShape(9.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, BorderColor),
        colors = ButtonDefaults.outlinedButtonColors(contentColor = TextMain)
    ) {
        Text(text)
    }
}

enum class AlertStyle { INFO, WARNING, SUCCESS }

@Composable
fun AlertBox(text: String, style: AlertStyle = AlertStyle.INFO, modifier: Modifier = Modifier) {
    val (bg, border, fg) = when (style) {
        AlertStyle.INFO -> Triple(Accent.copy(alpha = 0.12f), Accent.copy(alpha = 0.3f), TextMain)
        AlertStyle.WARNING -> Triple(Yellow.copy(alpha = 0.1f), Yellow.copy(alpha = 0.3f), Yellow)
        AlertStyle.SUCCESS -> Triple(Green.copy(alpha = 0.1f), Green.copy(alpha = 0.3f), Green)
    }
    Box(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(9.dp))
            .background(bg)
            .border(1.dp, border, RoundedCornerShape(9.dp))
            .padding(horizontal = 14.dp, vertical = 11.dp)
    ) {
        Text(text, style = MaterialTheme.typography.bodyMedium, color = fg)
    }
}

@Composable
fun BadgeChip(text: String, style: AlertStyle, modifier: Modifier = Modifier) {
    val (bg, fg) = when (style) {
        AlertStyle.SUCCESS -> Green.copy(alpha = 0.13f) to Green
        AlertStyle.WARNING -> Yellow.copy(alpha = 0.1f) to Yellow
        AlertStyle.INFO -> Accent.copy(alpha = 0.13f) to Accent
    }
    Box(
        modifier
            .clip(RoundedCornerShape(20.dp))
            .background(bg)
            .padding(horizontal = 12.dp, vertical = 5.dp)
    ) {
        Text(text, style = MaterialTheme.typography.labelMedium, color = fg)
    }
}

@Composable
fun StatChip(value: String, label: String, modifier: Modifier = Modifier) {
    Column(
        modifier
            .clip(RoundedCornerShape(10.dp))
            .background(CardBg)
            .border(1.dp, BorderColor, RoundedCornerShape(10.dp))
            .padding(10.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(value, style = MaterialTheme.typography.titleMedium, color = Accent)
        Text(label, style = MaterialTheme.typography.labelSmall, color = Muted, modifier = Modifier.padding(top = 2.dp))
    }
}
