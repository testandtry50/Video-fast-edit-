package com.videoslidemaker.app.export

import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Binder
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import com.videoslidemaker.app.MainActivity
import com.videoslidemaker.app.R
import com.videoslidemaker.app.VideoSlideMakerApp
import com.videoslidemaker.app.data.ImageStore
import com.videoslidemaker.app.model.ExportSettings
import com.videoslidemaker.app.model.ExportUiProgress
import com.videoslidemaker.app.model.PoolImage
import com.videoslidemaker.app.model.SentenceSlide
import com.videoslidemaker.app.model.TextOverlay
import com.videoslidemaker.app.tts.NarrationTts
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * NEW / IMPROVED: the original app rendered its export on the same page the person was looking
 * at, in a browser tab that could be lost to a screen lock or a task switch. This runs the same
 * job as a proper Android foreground service with an ongoing notification, so it keeps working
 * — and the person can see progress — no matter what else they do with their phone meanwhile.
 */
class ExportForegroundService : Service() {

    private val scope = CoroutineScope(SupervisorJob())
    private val binder = LocalBinder()
    private var job: Job? = null
    private var wakeLock: PowerManager.WakeLock? = null

    inner class LocalBinder : Binder() {
        fun service(): ExportForegroundService = this@ExportForegroundService
    }

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onCreate() {
        super.onCreate()
        startForeground(NOTIFICATION_ID, buildNotification(0, "Starting…"))
    }

    fun startExport(slides: List<SentenceSlide>, images: List<PoolImage>, settings: ExportSettings, textOverlays: List<TextOverlay> = emptyList()) {
        if (job?.isActive == true) return
        _progress.value = ExportUiProgress(running = true, percent = 0, message = "Starting…")

        // A multi-minute export needs the CPU to keep running at full speed even if the screen
        // turns off while it's working. A foreground service gets SOME protection from Doze, but
        // not full immunity — especially under aggressive OEM battery managers — so a photo/video
        // pipeline like this one holding a wake lock for the duration is standard practice. The
        // timeout is a safety cap (not an indefinite hold) in case release() were ever missed.
        val powerManager = getSystemService(Context.POWER_SERVICE) as? PowerManager
        wakeLock = powerManager?.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "VideoSlideMaker:export")?.apply {
            setReferenceCounted(false)
            acquire(WAKE_LOCK_TIMEOUT_MS)
        }

        val engine = VideoExportEngine(applicationContext, ImageStore(applicationContext), NarrationTts(applicationContext))
        job = scope.launch {
            val result = try {
                engine.export(slides, images, settings, textOverlays) { percent, message ->
                    _progress.value = ExportUiProgress(running = true, percent = percent, message = message)
                    updateNotification(percent, message)
                }
            } finally {
                releaseWakeLock()
            }
            _progress.value = if (result.success) {
                ExportUiProgress(running = false, percent = 100, message = "Done", done = true, outputUri = result.outputUri)
            } else {
                ExportUiProgress(running = false, percent = 0, message = result.error ?: "Export failed", done = true, error = result.error)
            }
            stopForeground(STOP_FOREGROUND_DETACH)
            stopSelf()
        }
    }

    fun cancel() {
        job?.cancel()
        releaseWakeLock()
        _progress.value = ExportUiProgress(running = false, percent = 0, message = "Cancelled", done = true)
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun releaseWakeLock() {
        wakeLock?.let { if (it.isHeld) it.release() }
        wakeLock = null
    }

    private fun updateNotification(percent: Int, message: String) {
        val manager = getSystemService(NotificationManager::class.java)
        manager?.notify(NOTIFICATION_ID, buildNotification(percent, message))
    }

    private fun buildNotification(percent: Int, message: String): Notification {
        val openIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, VideoSlideMakerApp.EXPORT_CHANNEL_ID)
            .setContentTitle("Creating your video")
            .setContentText(message)
            .setSmallIcon(R.drawable.ic_notification)
            .setProgress(100, percent, false)
            .setOngoing(true)
            .setContentIntent(openIntent)
            .build()
    }

    override fun onDestroy() {
        releaseWakeLock()
        scope.cancel()
        super.onDestroy()
    }

    companion object {
        private const val NOTIFICATION_ID = 42
        private const val WAKE_LOCK_TIMEOUT_MS = 30 * 60 * 1000L // safety cap, not an indefinite hold
        private val _progress = MutableStateFlow(ExportUiProgress())
        val progress: StateFlow<ExportUiProgress> = _progress.asStateFlow()
    }
}
