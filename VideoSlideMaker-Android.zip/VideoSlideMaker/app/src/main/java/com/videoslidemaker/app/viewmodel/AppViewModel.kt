package com.videoslidemaker.app.viewmodel

import android.app.Application
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.net.Uri
import android.os.IBinder
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.videoslidemaker.app.data.ImageStore
import com.videoslidemaker.app.data.ProjectRepository
import com.videoslidemaker.app.data.ScriptParser
import com.videoslidemaker.app.export.ExportForegroundService
import com.videoslidemaker.app.model.AppStep
import com.videoslidemaker.app.model.AspectRatioOption
import com.videoslidemaker.app.model.QualityOption
import com.videoslidemaker.app.model.SentenceSlide
import com.videoslidemaker.app.model.UiState
import com.videoslidemaker.app.tts.NarrationTts
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class AppViewModel(application: Application) : AndroidViewModel(application) {

    private val imageStore = ImageStore(application)
    private val tts = NarrationTts(application)
    private val projectRepository = ProjectRepository(application)

    private val _ui = MutableStateFlow(UiState())
    val ui: StateFlow<UiState> =
        combine(_ui, ExportForegroundService.progress) { state, progress -> state.copy(exportProgress = progress) }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), UiState())

    init {
        viewModelScope.launch {
            projectRepository.load()?.let { restored -> _ui.update { restored } }
        }
    }

    private fun persistDraft() {
        viewModelScope.launch { projectRepository.save(_ui.value) }
    }

    // ---------- Navigation ----------

    fun goStep(step: AppStep) {
        val state = _ui.value
        if ((step == AppStep.PREVIEW || step == AppStep.EXPORT) && state.images.isEmpty()) return
        _ui.update { it.copy(step = step) }
        when (step) {
            AppStep.MATCH -> _ui.update { it.copy(curMatchIndex = it.curMatchIndex.coerceIn(0, (it.slides.size - 1).coerceAtLeast(0))) }
            AppStep.PREVIEW -> {
                stopPreview()
                _ui.update { it.copy(previewIndex = 0) }
            }
            else -> {}
        }
    }

    /** Where "Next" from the Photos screen should go: Match only makes sense with a script loaded. */
    fun goNextFromPhotos() {
        goStep(if (_ui.value.scriptLoaded) AppStep.MATCH else AppStep.PREVIEW)
    }

    // ---------- Step 1: Script + global settings ----------

    fun loadScript(content: String) {
        val parsed = ScriptParser.parseScript(content)
        val slides = parsed.map { SentenceSlide(it.timestampSec, it.text) }
        _ui.update { it.copy(slides = slides, scriptLoaded = slides.isNotEmpty(), curMatchIndex = 0) }
        persistDraft()
    }

    fun setDefaultDuration(seconds: Int) {
        _ui.update { it.copy(settings = it.settings.copy(defaultDurationSec = seconds.coerceIn(1, 30))) }
        persistDraft()
    }
    fun setVoiceLocale(tag: String) {
        _ui.update { it.copy(settings = it.settings.copy(narration = it.settings.narration.copy(voiceLocaleTag = tag))) }
        persistDraft()
    }
    fun setZoomEffect(on: Boolean) {
        _ui.update { it.copy(settings = it.settings.copy(zoomEffect = on)) }
        persistDraft()
    }
    fun setFadeTransition(on: Boolean) {
        _ui.update { it.copy(settings = it.settings.copy(fadeTransition = on)) }
        persistDraft()
    }
    fun setAspectRatio(ratio: AspectRatioOption) {
        _ui.update { it.copy(settings = it.settings.copy(aspectRatio = ratio)) }
        persistDraft()
    }
    fun setQuality(quality: QualityOption) {
        _ui.update { it.copy(settings = it.settings.copy(quality = quality)) }
        persistDraft()
    }
    fun setNarrationEnabled(enabled: Boolean) {
        _ui.update { it.copy(settings = it.settings.copy(narration = it.settings.narration.copy(enabled = enabled))) }
        persistDraft()
    }
    fun setMusicUri(uri: Uri?, displayName: String?) {
        _ui.update { it.copy(settings = it.settings.copy(music = it.settings.music.copy(uri = uri, displayName = displayName))) }
        persistDraft()
    }
    fun setMusicVolume(volume: Float) {
        _ui.update { it.copy(settings = it.settings.copy(music = it.settings.music.copy(volume = volume.coerceIn(0f, 1f)))) }
        persistDraft()
    }

    // ---------- Step 2: Photos ----------

    fun addImages(uris: List<Uri>) {
        viewModelScope.launch {
            val added = imageStore.addImages(uris)
            _ui.update { it.copy(images = it.images + added) }
            persistDraft()
        }
    }

    fun deleteImage(id: String) {
        _ui.update { state ->
            state.copy(
                images = state.images.filterNot { it.id == id },
                slides = state.slides.map { s -> if (s.assignedImageId == id) s.copy(assignedImageId = null) else s }
            )
        }
        persistDraft()
    }

    fun clearAllImages() {
        _ui.update { it.copy(images = emptyList(), slides = it.slides.map { s -> s.copy(assignedImageId = null) }) }
        persistDraft()
    }

    fun moveImage(from: Int, to: Int) {
        _ui.update { state ->
            val list = state.images.toMutableList()
            if (from !in list.indices || to !in list.indices) return@update state
            val moved = list.removeAt(from)
            list.add(to, moved)
            state.copy(images = list)
        }
        persistDraft()
    }

    fun moveImageUp(index: Int) { if (index > 0) moveImage(index, index - 1) }
    fun moveImageDown(index: Int) { if (index < _ui.value.images.size - 1) moveImage(index, index + 1) }

    /** NEW: sets one photo's own display time (the editable "2:30" box) — drives simple mode. */
    fun setPhotoDuration(imageId: String, seconds: Double) {
        val clamped = seconds.coerceIn(0.5, 3600.0)
        _ui.update { state ->
            state.copy(images = state.images.map { img -> if (img.id == imageId) img.copy(durationOverrideSec = clamped) else img })
        }
        persistDraft()
    }

    // ---------- Step 3: Match ----------

    fun matchPrev() = _ui.update { it.copy(curMatchIndex = (it.curMatchIndex - 1).coerceAtLeast(0)) }
    fun matchSkip() = _ui.update { it.copy(curMatchIndex = (it.curMatchIndex + 1).coerceAtMost((it.slides.size - 1).coerceAtLeast(0))) }
    fun setAutoAdvance(on: Boolean) = _ui.update { it.copy(autoAdvance = on) }

    fun pickImage(imageId: String) {
        _ui.update { state ->
            val idx = state.curMatchIndex
            val newSlides = state.slides.toMutableList()
            if (idx in newSlides.indices) newSlides[idx] = newSlides[idx].copy(assignedImageId = imageId)
            state.copy(slides = newSlides)
        }
        persistDraft()
        if (_ui.value.autoAdvance) {
            viewModelScope.launch {
                delay(300)
                _ui.update { it.copy(curMatchIndex = (it.curMatchIndex + 1).coerceAtMost((it.slides.size - 1).coerceAtLeast(0))) }
            }
        }
    }

    fun editSentenceText(index: Int, text: String) {
        _ui.update { state ->
            val list = state.slides.toMutableList()
            if (index in list.indices) list[index] = list[index].copy(text = text)
            state.copy(slides = list)
        }
    }

    fun commitSentenceEdit() = persistDraft()

    fun speakCurrentSentence() {
        val state = _ui.value
        val text = state.slides.getOrNull(state.curMatchIndex)?.text ?: return
        tts.speak(text, state.settings.narration.voiceLocaleTag, state.settings.narration.speechRate)
    }

    fun mergeCurrentWithNext() {
        _ui.update { state ->
            val idx = state.curMatchIndex
            if (idx >= state.slides.size - 1) return@update state
            val list = state.slides.toMutableList()
            val combined = listOf(list[idx].text, list[idx + 1].text).filter { it.isNotBlank() }.joinToString(" ")
            list[idx] = list[idx].copy(text = combined)
            list.removeAt(idx + 1)
            state.copy(slides = list)
        }
        persistDraft()
    }

    /** @param cursorOffset character offset within the current sentence where it should be cut. */
    fun splitCurrentSentence(cursorOffset: Int, splitTimeSec: Double): Boolean {
        var applied = false
        _ui.update { state ->
            val idx = state.curMatchIndex
            val slide = state.slides.getOrNull(idx) ?: return@update state
            val next = state.slides.getOrNull(idx + 1)
            val slotStart = slide.timestampSec
            val slotEnd = next?.timestampSec ?: (slotStart + state.settings.defaultDurationSec)
            if (splitTimeSec <= slotStart || splitTimeSec >= slotEnd) return@update state

            val text = slide.text
            val cut = cursorOffset.coerceIn(0, text.length)
            val part1 = text.substring(0, cut).trim()
            val part2 = text.substring(cut).trim()
            if (part1.isBlank() || part2.isBlank()) return@update state

            val list = state.slides.toMutableList()
            list[idx] = slide.copy(text = part1)
            list.add(idx + 1, SentenceSlide(splitTimeSec, part2))
            applied = true
            state.copy(slides = list)
        }
        if (applied) persistDraft()
        return applied
    }

    // ---------- Step 4: Preview ----------

    private var previewJob: Job? = null

    fun previewTogglePlay() {
        if (_ui.value.previewPlaying) {
            stopPreview()
            return
        }
        _ui.update { it.copy(previewPlaying = true) }
        previewJob = viewModelScope.launch {
            while (true) {
                val state = _ui.value
                val timelineSize = state.effectiveSlides.size
                if (timelineSize == 0 || state.previewIndex >= timelineSize - 1) {
                    _ui.update { it.copy(previewPlaying = false, previewIndex = 0) }
                    return@launch
                }
                val durationMs = (state.durationForIndex(state.previewIndex) * 600).toLong().coerceAtLeast(400)
                delay(durationMs)
                _ui.update { it.copy(previewIndex = it.previewIndex + 1) }
            }
        }
    }

    fun stopPreview() {
        previewJob?.cancel()
        _ui.update { it.copy(previewPlaying = false) }
    }

    fun previewPrev() { stopPreview(); _ui.update { it.copy(previewIndex = (it.previewIndex - 1).coerceAtLeast(0)) } }
    fun previewNext() {
        stopPreview()
        _ui.update { it.copy(previewIndex = (it.previewIndex + 1).coerceAtMost((it.effectiveSlides.size - 1).coerceAtLeast(0))) }
    }

    // ---------- Step 5: Export ----------

    fun startExport() {
        val app = getApplication<Application>()
        val state = _ui.value
        val intent = Intent(app, ExportForegroundService::class.java)
        app.startForegroundService(intent)
        app.bindService(intent, object : ServiceConnection {
            override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
                (binder as? ExportForegroundService.LocalBinder)?.service()?.startExport(state.effectiveSlides, state.images, state.settings)
                app.unbindService(this)
            }
            override fun onServiceDisconnected(name: ComponentName?) {}
        }, Context.BIND_AUTO_CREATE)
    }

    fun cancelExport() {
        val app = getApplication<Application>()
        app.bindService(Intent(app, ExportForegroundService::class.java), object : ServiceConnection {
            override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
                (binder as? ExportForegroundService.LocalBinder)?.service()?.cancel()
                app.unbindService(this)
            }
            override fun onServiceDisconnected(name: ComponentName?) {}
        }, Context.BIND_AUTO_CREATE)
    }

    override fun onCleared() {
        tts.shutdown()
        super.onCleared()
    }
}
