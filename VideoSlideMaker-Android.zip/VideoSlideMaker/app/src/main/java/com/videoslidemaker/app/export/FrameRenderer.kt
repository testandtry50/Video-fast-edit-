package com.videoslidemaker.app.export

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF

/**
 * Draws a single export frame into a reusable ARGB_8888 bitmap, replicating the original web
 * app's <canvas> compositing exactly: cover-fit crop (CSS object-fit: cover), an optional Ken
 * Burns zoom from 1.0 to 1.06 across the image's time slot, and an optional fade to/from black
 * at the start and end of that slot.
 */
class FrameRenderer(private val outputWidth: Int, private val outputHeight: Int) {

    private val blackPaint = Paint().apply { color = Color.BLACK }
    private val bitmapPaint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)

    /**
     * @param progress 0f..1f — how far through the current image's time slot this frame is.
     * @param fadeInFraction fraction (0f..0.5f) of the slot spent fading in from black.
     * @param fadeOutFraction fraction (0f..0.5f) of the slot spent fading out to black.
     */
    fun renderFrame(
        target: Bitmap,
        source: Bitmap,
        progress: Float,
        zoomEnabled: Boolean,
        fadeInFraction: Float,
        fadeOutFraction: Float
    ) {
        val canvas = Canvas(target)
        canvas.drawColor(Color.BLACK)

        val scale = if (zoomEnabled) 1f + progress * 0.06f else 1f
        val offsetX = (outputWidth * (scale - 1f)) / 2f
        val offsetY = (outputHeight * (scale - 1f)) / 2f

        val srcRect = coverCropRect(source.width, source.height, outputWidth, outputHeight)
        val dstRect = RectF(0f, 0f, outputWidth.toFloat(), outputHeight.toFloat())

        canvas.save()
        canvas.translate(-offsetX, -offsetY)
        canvas.scale(scale, scale)
        canvas.drawBitmap(source, srcRect, dstRect, bitmapPaint)
        canvas.restore()

        if (fadeInFraction > 0f && progress < fadeInFraction) {
            drawFade(canvas, 1f - (progress / fadeInFraction))
        }
        if (fadeOutFraction > 0f && progress > 1f - fadeOutFraction) {
            drawFade(canvas, (progress - (1f - fadeOutFraction)) / fadeOutFraction)
        }
    }

    private fun drawFade(canvas: Canvas, alpha: Float) {
        blackPaint.alpha = (alpha.coerceIn(0f, 1f) * 255).toInt()
        canvas.drawRect(0f, 0f, outputWidth.toFloat(), outputHeight.toFloat(), blackPaint)
        blackPaint.alpha = 255
    }

    /** Equivalent of CSS `object-fit: cover` — crops the larger dimension, centered. */
    private fun coverCropRect(srcW: Int, srcH: Int, dstW: Int, dstH: Int): Rect {
        val srcAspect = srcW.toFloat() / srcH.toFloat()
        val dstAspect = dstW.toFloat() / dstH.toFloat()
        return if (srcAspect > dstAspect) {
            val cropW = (srcH * dstAspect).toInt()
            val x = (srcW - cropW) / 2
            Rect(x, 0, x + cropW, srcH)
        } else {
            val cropH = (srcW / dstAspect).toInt()
            val y = (srcH - cropH) / 2
            Rect(0, y, srcW, y + cropH)
        }
    }
}
