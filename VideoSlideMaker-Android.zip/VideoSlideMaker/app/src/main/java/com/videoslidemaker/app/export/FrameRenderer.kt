package com.videoslidemaker.app.export

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import com.videoslidemaker.app.model.OverlayPosition
import com.videoslidemaker.app.model.OverlayStyle
import com.videoslidemaker.app.model.TextOverlay

/**
 * Draws a single export frame into a reusable ARGB_8888 bitmap, replicating the original web
 * app's <canvas> compositing exactly: cover-fit crop (CSS object-fit: cover), an optional Ken
 * Burns zoom from 1.0 to 1.06 across the image's time slot, and an optional fade to/from black
 * at the start and end of that slot.
 */
class FrameRenderer(private val outputWidth: Int, private val outputHeight: Int) {

    private val blackPaint = Paint().apply { color = Color.BLACK }
    private val bitmapPaint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)

    // NEW: character-name / text overlay drawing. Reused Paint objects, same pattern as above —
    // plain android.graphics Canvas/Paint (not Compose), since this needs to render identically
    // whether it's burned into an exported frame or drawn live in the Preview screen.
    private val overlayTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        isFakeBoldText = true
        textAlign = Paint.Align.CENTER
    }
    private val overlayBgPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val overlayAccentPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val accentR = 108
    private val accentG = 99
    private val accentB = 255

    /**
     * @param progress 0f..1f — how far through the current image's time slot this frame is.
     * @param fadeInFraction fraction (0f..0.5f) of the slot spent fading in from black.
     * @param fadeOutFraction fraction (0f..0.5f) of the slot spent fading out to black.
     */
    fun renderFrame(
        target: Bitmap,
        source: Bitmap,
        progress: Float,
        zoomEnabled: Boolean,
        fadeInFraction: Float,
        fadeOutFraction: Float
    ) {
        val canvas = Canvas(target)
        canvas.drawColor(Color.BLACK)

        val scale = if (zoomEnabled) 1f + progress * 0.06f else 1f
        val offsetX = (outputWidth * (scale - 1f)) / 2f
        val offsetY = (outputHeight * (scale - 1f)) / 2f

        val srcRect = coverCropRect(source.width, source.height, outputWidth, outputHeight)
        val dstRect = RectF(0f, 0f, outputWidth.toFloat(), outputHeight.toFloat())

        canvas.save()
        canvas.translate(-offsetX, -offsetY)
        canvas.scale(scale, scale)
        canvas.drawBitmap(source, srcRect, dstRect, bitmapPaint)
        canvas.restore()

        if (fadeInFraction > 0f && progress < fadeInFraction) {
            drawFade(canvas, 1f - (progress / fadeInFraction))
        }
        if (fadeOutFraction > 0f && progress > 1f - fadeOutFraction) {
            drawFade(canvas, (progress - (1f - fadeOutFraction)) / fadeOutFraction)
        }
    }

    /**
     * NEW: draws any currently-active text overlays (character names etc.) on top of whatever
     * renderFrame already painted. [overlays] pairs each overlay with its own fade in/out alpha
     * (0..1) — see UiState.overlaysActiveAt — so a name can fade in/out independently of the
     * photo transition underneath it.
     */
    fun drawTextOverlays(target: Bitmap, overlays: List<Pair<TextOverlay, Float>>) {
        if (overlays.isEmpty()) return
        val canvas = Canvas(target)
        val textSizePx = outputHeight * 0.045f
        overlayTextPaint.textSize = textSizePx
        val centerX = outputWidth / 2f

        overlays.forEach { (overlay, alphaF) ->
            if (alphaF <= 0.01f || overlay.text.isBlank()) return@forEach
            val alpha255 = (alphaF.coerceIn(0f, 1f) * 255).toInt()
            val baselineY = when (overlay.position) {
                OverlayPosition.TOP -> outputHeight * 0.16f
                OverlayPosition.CENTER -> outputHeight * 0.52f
                OverlayPosition.BOTTOM -> outputHeight * 0.86f
            }
            val textWidth = overlayTextPaint.measureText(overlay.text)

            when (overlay.style) {
                OverlayStyle.TAG -> {
                    val padH = textSizePx * 0.65f
                    val padV = textSizePx * 0.42f
                    val rect = RectF(
                        centerX - textWidth / 2f - padH,
                        baselineY - textSizePx * 0.95f - padV,
                        centerX + textWidth / 2f + padH,
                        baselineY + padV * 0.55f
                    )
                    overlayBgPaint.color = Color.argb((alphaF * 190).toInt(), 12, 12, 20)
                    canvas.drawRoundRect(rect, textSizePx * 0.35f, textSizePx * 0.35f, overlayBgPaint)
                    overlayAccentPaint.color = Color.argb(alpha255, accentR, accentG, accentB)
                    canvas.drawRoundRect(
                        RectF(rect.left, rect.top, rect.left + textSizePx * 0.16f, rect.bottom),
                        textSizePx * 0.08f, textSizePx * 0.08f, overlayAccentPaint
                    )
                }
                OverlayStyle.UNDERLINE -> {
                    overlayAccentPaint.color = Color.argb(alpha255, accentR, accentG, accentB)
                    val lineTop = baselineY + textSizePx * 0.22f
                    canvas.drawRoundRect(
                        RectF(
                            centerX - textWidth / 2f - textSizePx * 0.15f, lineTop,
                            centerX + textWidth / 2f + textSizePx * 0.15f, lineTop + textSizePx * 0.09f
                        ),
                        textSizePx * 0.04f, textSizePx * 0.04f, overlayAccentPaint
                    )
                }
                OverlayStyle.MINIMAL -> { /* text with a shadow only, drawn below — no extra shape */ }
            }

            overlayTextPaint.alpha = alpha255
            overlayTextPaint.setShadowLayer(textSizePx * 0.12f, 0f, textSizePx * 0.04f, Color.argb((alphaF * 200).toInt(), 0, 0, 0))
            canvas.drawText(overlay.text, centerX, baselineY, overlayTextPaint)
        }
    }

    private fun drawFade(canvas: Canvas, alpha: Float) {
        blackPaint.alpha = (alpha.coerceIn(0f, 1f) * 255).toInt()
        canvas.drawRect(0f, 0f, outputWidth.toFloat(), outputHeight.toFloat(), blackPaint)
        blackPaint.alpha = 255
    }

    /** Equivalent of CSS `object-fit: cover` — crops the larger dimension, centered. */
    private fun coverCropRect(srcW: Int, srcH: Int, dstW: Int, dstH: Int): Rect {
        val srcAspect = srcW.toFloat() / srcH.toFloat()
        val dstAspect = dstW.toFloat() / dstH.toFloat()
        return if (srcAspect > dstAspect) {
            val cropW = (srcH * dstAspect).toInt()
            val x = (srcW - cropW) / 2
            Rect(x, 0, x + cropW, srcH)
        } else {
            val cropH = (srcW / dstAspect).toInt()
            val y = (srcH - cropH) / 2
            Rect(0, y, srcW, y + cropH)
        }
    }
}
