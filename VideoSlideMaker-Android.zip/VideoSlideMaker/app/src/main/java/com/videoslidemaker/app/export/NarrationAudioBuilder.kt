package com.videoslidemaker.app.export

import android.content.Context
import com.videoslidemaker.app.model.ExportSettings
import com.videoslidemaker.app.model.SentenceSlide
import com.videoslidemaker.app.tts.NarrationTts
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

const val AUDIO_SAMPLE_RATE = 44100
const val AUDIO_CHANNELS = 2

/**
 * NEW: in the original app, the on-device voice was only ever heard live, while matching a
 * sentence to a photo — the exported video itself had no audio at all. Here, that same voice
 * is synthesized to a WAV per sentence and placed at that sentence's exact timestamp in one
 * combined PCM timeline, so it becomes a real audio track in the finished video. An optional
 * background-music file is decoded, looped or trimmed to the video's length, and mixed
 * underneath at a lower volume.
 */
class NarrationAudioBuilder(
    private val context: Context,
    private val tts: NarrationTts
) {
    suspend fun build(
        slides: List<SentenceSlide>,
        totalDurationSec: Double,
        settings: ExportSettings,
        cacheDir: File,
        onProgress: (String) -> Unit
    ): PcmAudio = withContext(Dispatchers.IO) {
        val totalFrames = (totalDurationSec * AUDIO_SAMPLE_RATE).toInt().coerceAtLeast(1)
        val timeline = ByteArray(totalFrames * AUDIO_CHANNELS * 2)

        if (settings.narration.enabled) {
            slides.forEachIndexed { index, slide ->
                if (slide.text.isNotBlank()) {
                    onProgress("Recording narration ${index + 1} of ${slides.size}")
                    val wavFile = File(cacheDir, "narration_$index.wav")
                    val ok = tts.synthesizeToFile(
                        slide.text,
                        settings.narration.voiceLocaleTag,
                        settings.narration.speechRate,
                        wavFile
                    )
                    if (ok) {
                        WavUtils.readPcm16Wav(wavFile)?.let { pcm ->
                            val converted = PcmResampler.convert(
                                pcm.data, pcm.sampleRate, pcm.channelCount,
                                AUDIO_SAMPLE_RATE, AUDIO_CHANNELS
                            )
                            val offsetBytes = (slide.timestampSec * AUDIO_SAMPLE_RATE).toInt() * AUDIO_CHANNELS * 2
                            PcmResampler.mixInto(timeline, converted, offsetBytes, gain = 1f)
                        }
                    }
                    wavFile.delete()
                }
            }
        }

        val musicUri = settings.music.uri
        if (musicUri != null) {
            onProgress("Mixing background music")
            val musicPcm = AudioDecoder.decodeToPcm(context, musicUri, AUDIO_SAMPLE_RATE, AUDIO_CHANNELS)
            if (musicPcm != null && musicPcm.isNotEmpty()) {
                val looped = loopOrTrim(musicPcm, timeline.size)
                PcmResampler.mixInto(timeline, looped, 0, gain = settings.music.volume)
            }
        }

        PcmAudio(AUDIO_SAMPLE_RATE, AUDIO_CHANNELS, timeline)
    }

    private fun loopOrTrim(pcm: ByteArray, targetSize: Int): ByteArray {
        if (pcm.isEmpty()) return ByteArray(targetSize)
        val out = ByteArray(targetSize)
        var pos = 0
        while (pos < targetSize) {
            val chunk = minOf(pcm.size, targetSize - pos)
            System.arraycopy(pcm, 0, out, pos, chunk)
            pos += chunk
        }
        return out
    }
}
