package com.videoslidemaker.app.tts

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.suspendCancellableCoroutine
import java.io.File
import java.util.Locale
import java.util.UUID
import kotlin.coroutines.resume

/**
 * Wraps Android's built-in TextToSpeech engine for two jobs:
 *  1. Live "🔊 listen" playback while matching a sentence to a photo — same role the original
 *     app's browser speechSynthesis call played.
 *  2. NEW: synthesizing narration to a WAV file at export time so it can be muxed into the
 *     final MP4 as a real audio track, which the original app never did.
 */
class NarrationTts(context: Context) {
    private var ready = false
    private val engine = TextToSpeech(context.applicationContext) { status ->
        ready = status == TextToSpeech.SUCCESS
    }

    fun speak(text: String, localeTag: String, rate: Float = 0.95f) {
        if (!ready || text.isBlank()) return
        engine.language = Locale.forLanguageTag(localeTag)
        engine.setSpeechRate(rate)
        engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, UUID.randomUUID().toString())
    }

    fun stop() {
        engine.stop()
    }

    /** Returns true if synthesis completed and [outFile] contains a playable WAV. */
    suspend fun synthesizeToFile(text: String, localeTag: String, rate: Float, outFile: File): Boolean {
        if (!ready || text.isBlank()) return false
        engine.language = Locale.forLanguageTag(localeTag)
        engine.setSpeechRate(rate)
        val utteranceId = UUID.randomUUID().toString()

        return suspendCancellableCoroutine { cont ->
            engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}

                override fun onDone(id: String?) {
                    if (id == utteranceId && cont.isActive) cont.resume(true)
                }

                @Deprecated("Deprecated in Java", ReplaceWith(""))
                override fun onError(id: String?) {
                    if (id == utteranceId && cont.isActive) cont.resume(false)
                }

                override fun onError(id: String?, errorCode: Int) {
                    if (id == utteranceId && cont.isActive) cont.resume(false)
                }
            })
            val result = engine.synthesizeToFile(text, null, outFile, utteranceId)
            if (result != TextToSpeech.SUCCESS && cont.isActive) {
                cont.resume(false)
            }
        }
    }

    fun isLanguageAvailable(localeTag: String): Boolean = try {
        engine.isLanguageAvailable(Locale.forLanguageTag(localeTag)) >= TextToSpeech.LANG_AVAILABLE
    } catch (_: Exception) {
        false
    }

    fun shutdown() {
        engine.stop()
        engine.shutdown()
    }
}
