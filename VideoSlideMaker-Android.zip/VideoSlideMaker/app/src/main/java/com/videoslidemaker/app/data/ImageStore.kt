package com.videoslidemaker.app.data

import android.content.ContentResolver
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import com.videoslidemaker.app.model.PoolImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.UUID

/**
 * This is the key fix for "handle large file work properly": the original web app read every
 * uploaded photo into memory as a base64 string (via FileReader.readAsDataURL) and kept every
 * one of them there for the whole session. That works for a handful of small images but falls
 * over — slow UI, huge memory use, possible crashes — with many phone-camera photos.
 *
 * Here, a photo is only ever a content Uri plus its true pixel dimensions (read from the file
 * header, never the pixels). Thumbnails are decoded downsampled to whatever size is actually
 * needed on screen, and full resolution is only decoded one photo at a time, right before that
 * photo's frames are rendered during export.
 */
class ImageStore(private val context: Context) {

    suspend fun addImages(uris: List<Uri>): List<PoolImage> = withContext(Dispatchers.IO) {
        uris.mapNotNull { uri -> loadOne(uri) }
    }

    /**
     * NEW: imports every image directly inside a picked folder in one go — the real fix for
     * "thousands of photos" (e.g. movie frames extracted one-per-file). Picking files
     * individually gives each one its OWN persisted permission grant, and Android's per-app
     * ceiling on those is a few hundred at most — well past that point, most files silently
     * stop being readable later (blank thumbnails, black frames at export, all despite having
     * "worked" at pick time). A folder (tree) grant is different: it's ONE persisted grant for
     * the whole folder, and every file underneath inherits access from it — no per-file limit.
     */
    suspend fun addImagesFromTree(treeUri: Uri): List<PoolImage> = withContext(Dispatchers.IO) {
        val resolver = context.contentResolver
        try {
            resolver.takePersistableUriPermission(treeUri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (_: SecurityException) {
            // Even without a persisted grant, a freshly-picked tree Uri still works for the
            // rest of this session, so still attempt the import rather than bailing out here.
        }

        val results = mutableListOf<PoolImage>()
        try {
            val parentDocId = DocumentsContract.getTreeDocumentId(treeUri)
            val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, parentDocId)
            resolver.query(
                childrenUri,
                arrayOf(
                    DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                    DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                    DocumentsContract.Document.COLUMN_MIME_TYPE
                ),
                null, null, null
            )?.use { cursor ->
                val idIdx = cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DOCUMENT_ID)
                val nameIdx = cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DISPLAY_NAME)
                val mimeIdx = cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_MIME_TYPE)
                while (cursor.moveToNext()) {
                    val mime = cursor.getString(mimeIdx) ?: ""
                    if (!mime.startsWith("image/")) continue
                    val docId = cursor.getString(idIdx) ?: continue
                    val name = cursor.getString(nameIdx) ?: docId
                    val childUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, docId)
                    val (w, h) = decodeBoundsRespectingExif(resolver, childUri) ?: (0 to 0)
                    results.add(
                        PoolImage(
                            id = UUID.randomUUID().toString(),
                            uri = childUri,
                            displayName = name,
                            widthPx = w,
                            heightPx = h,
                            persistedAccess = true // inherited from the one tree-level grant above
                        )
                    )
                }
            }
        } catch (_: Exception) {
            // Whatever was collected before a failure is still returned below, rather than
            // losing an entire large import over one bad entry.
        }
        results.sortedBy { it.displayName }
    }

    private fun loadOne(uri: Uri): PoolImage? {
        val resolver = context.contentResolver
        val persisted = try {
            resolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            // takePersistableUriPermission() can return silently without actually having
            // persisted anything on some providers, so confirm it's really there rather than
            // trusting the absence of an exception.
            resolver.persistedUriPermissions.any { it.uri == uri && it.isReadPermission }
        } catch (_: SecurityException) {
            // Some providers (e.g. certain camera-roll pickers) don't support persistable grants.
            // The Uri still works for the current session, it just won't survive an app restart.
            false
        }

        val (w, h) = decodeBoundsRespectingExif(resolver, uri) ?: (0 to 0)
        val name = queryDisplayName(resolver, uri) ?: uri.lastPathSegment ?: "photo"

        return PoolImage(
            id = UUID.randomUUID().toString(),
            uri = uri,
            displayName = name,
            widthPx = w,
            heightPx = h,
            persistedAccess = persisted
        )
    }

    private fun queryDisplayName(resolver: ContentResolver, uri: Uri): String? {
        resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (idx >= 0) return cursor.getString(idx)
            }
        }
        return null
    }

    /** Reads only the image header (no pixel data) to get true, EXIF-corrected dimensions. */
    private fun decodeBoundsRespectingExif(resolver: ContentResolver, uri: Uri): Pair<Int, Int>? {
        val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        // NOTE: with inJustDecodeBounds = true, BitmapFactory.decodeStream() is *guaranteed* by
        // the Android API contract to return null on every call, no matter what — it only has
        // the side effect of filling in options.outWidth/outHeight. That's not a failure signal,
        // so the "did the stream actually open" check has to happen on its own, separately —
        // chaining it with ?: on the decode call's result was treating an always-null return as
        // an always-failed stream, which silently broke this for every photo, every time.
        val boundsStream = resolver.openInputStream(uri) ?: return null
        boundsStream.use { BitmapFactory.decodeStream(it, null, options) }
        var w = options.outWidth
        var h = options.outHeight
        if (w <= 0 || h <= 0) return null

        val rotation = readExifRotation(resolver, uri)
        if (rotation == 90 || rotation == 270) {
            val tmp = w; w = h; h = tmp
        }
        return w to h
    }

    private fun readExifRotation(resolver: ContentResolver, uri: Uri): Int = try {
        resolver.openInputStream(uri)?.use { stream ->
            val exif = ExifInterface(stream)
            when (exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90
                ExifInterface.ORIENTATION_ROTATE_180 -> 180
                ExifInterface.ORIENTATION_ROTATE_270 -> 270
                else -> 0
            }
        } ?: 0
    } catch (_: Exception) {
        0
    }

    /** Downsampled bitmap safe for thumbnails/lists — never loads full resolution. */
    suspend fun decodeThumbnail(uri: Uri, targetLongEdge: Int = 400): Bitmap? =
        withContext(Dispatchers.IO) { decodeSampled(uri, targetLongEdge) }

    /** Highest-quality decode used at export time, still capped so one huge photo can't OOM the app. */
    suspend fun decodeForExport(uri: Uri, maxLongEdge: Int): Bitmap? =
        withContext(Dispatchers.IO) { decodeSampled(uri, maxLongEdge) }

    private fun decodeSampled(uri: Uri, targetLongEdge: Int): Bitmap? {
        val resolver = context.contentResolver
        val boundsOptions = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        // Same fix as decodeBoundsRespectingExif above: this bounds-only call always returns
        // null by design, so the stream-opened check has to be separate from it.
        val boundsStream = resolver.openInputStream(uri) ?: return null
        boundsStream.use { BitmapFactory.decodeStream(it, null, boundsOptions) }

        var sample = 1
        val longEdge = maxOf(boundsOptions.outWidth, boundsOptions.outHeight)
        while (longEdge / (sample * 2) >= targetLongEdge) sample *= 2

        val decodeOptions = BitmapFactory.Options().apply {
            inSampleSize = sample
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }
        // This second decode call is a REAL pixel decode (inJustDecodeBounds isn't set), so a
        // null return here is a genuine failure and the ?: return null is correct as-is.
        val raw = resolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, decodeOptions)
        } ?: return null

        return applyExifRotation(raw, readExifRotation(resolver, uri))
    }

    private fun applyExifRotation(bitmap: Bitmap, degrees: Int): Bitmap {
        if (degrees == 0) return bitmap
        val matrix = Matrix().apply { postRotate(degrees.toFloat()) }
        val rotated = Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
        if (rotated !== bitmap) bitmap.recycle()
        return rotated
    }
}
