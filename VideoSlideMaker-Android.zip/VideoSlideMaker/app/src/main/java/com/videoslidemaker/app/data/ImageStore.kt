package com.videoslidemaker.app.data

import android.content.ContentResolver
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import android.provider.OpenableColumns
import com.videoslidemaker.app.model.PoolImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.UUID

/**
 * This is the key fix for "handle large file work properly": the original web app read every
 * uploaded photo into memory as a base64 string (via FileReader.readAsDataURL) and kept every
 * one of them there for the whole session. That works for a handful of small images but falls
 * over — slow UI, huge memory use, possible crashes — with many phone-camera photos.
 *
 * Here, a photo is only ever a content Uri plus its true pixel dimensions (read from the file
 * header, never the pixels). Thumbnails are decoded downsampled to whatever size is actually
 * needed on screen, and full resolution is only decoded one photo at a time, right before that
 * photo's frames are rendered during export.
 */
class ImageStore(private val context: Context) {

    suspend fun addImages(uris: List<Uri>): List<PoolImage> = withContext(Dispatchers.IO) {
        uris.mapNotNull { uri -> loadOne(uri) }
    }

    private fun loadOne(uri: Uri): PoolImage? {
        val resolver = context.contentResolver
        val persisted = try {
            resolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            // takePersistableUriPermission() can return silently without actually having
            // persisted anything on some providers, so confirm it's really there rather than
            // trusting the absence of an exception.
            resolver.persistedUriPermissions.any { it.uri == uri && it.isReadPermission }
        } catch (_: SecurityException) {
            // Some providers (e.g. certain camera-roll pickers) don't support persistable grants.
            // The Uri still works for the current session, it just won't survive an app restart.
            false
        }

        val (w, h) = decodeBoundsRespectingExif(resolver, uri) ?: (0 to 0)
        val name = queryDisplayName(resolver, uri) ?: uri.lastPathSegment ?: "photo"

        return PoolImage(
            id = UUID.randomUUID().toString(),
            uri = uri,
            displayName = name,
            widthPx = w,
            heightPx = h,
            persistedAccess = persisted
        )
    }

    private fun queryDisplayName(resolver: ContentResolver, uri: Uri): String? {
        resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (idx >= 0) return cursor.getString(idx)
            }
        }
        return null
    }

    /** Reads only the image header (no pixel data) to get true, EXIF-corrected dimensions. */
    private fun decodeBoundsRespectingExif(resolver: ContentResolver, uri: Uri): Pair<Int, Int>? {
        val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, options) } ?: return null
        var w = options.outWidth
        var h = options.outHeight
        if (w <= 0 || h <= 0) return null

        val rotation = readExifRotation(resolver, uri)
        if (rotation == 90 || rotation == 270) {
            val tmp = w; w = h; h = tmp
        }
        return w to h
    }

    private fun readExifRotation(resolver: ContentResolver, uri: Uri): Int = try {
        resolver.openInputStream(uri)?.use { stream ->
            val exif = ExifInterface(stream)
            when (exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90
                ExifInterface.ORIENTATION_ROTATE_180 -> 180
                ExifInterface.ORIENTATION_ROTATE_270 -> 270
                else -> 0
            }
        } ?: 0
    } catch (_: Exception) {
        0
    }

    /** Downsampled bitmap safe for thumbnails/lists — never loads full resolution. */
    suspend fun decodeThumbnail(uri: Uri, targetLongEdge: Int = 400): Bitmap? =
        withContext(Dispatchers.IO) { decodeSampled(uri, targetLongEdge) }

    /** Highest-quality decode used at export time, still capped so one huge photo can't OOM the app. */
    suspend fun decodeForExport(uri: Uri, maxLongEdge: Int): Bitmap? =
        withContext(Dispatchers.IO) { decodeSampled(uri, maxLongEdge) }

    private fun decodeSampled(uri: Uri, targetLongEdge: Int): Bitmap? {
        val resolver = context.contentResolver
        val boundsOptions = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, boundsOptions) } ?: return null

        var sample = 1
        val longEdge = maxOf(boundsOptions.outWidth, boundsOptions.outHeight)
        while (longEdge / (sample * 2) >= targetLongEdge) sample *= 2

        val decodeOptions = BitmapFactory.Options().apply {
            inSampleSize = sample
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }
        val raw = resolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, decodeOptions)
        } ?: return null

        return applyExifRotation(raw, readExifRotation(resolver, uri))
    }

    private fun applyExifRotation(bitmap: Bitmap, degrees: Int): Bitmap {
        if (degrees == 0) return bitmap
        val matrix = Matrix().apply { postRotate(degrees.toFloat()) }
        val rotated = Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
        if (rotated !== bitmap) bitmap.recycle()
        return rotated
    }
}
