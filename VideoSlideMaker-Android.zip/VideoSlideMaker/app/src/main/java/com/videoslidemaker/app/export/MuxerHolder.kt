package com.videoslidemaker.app.export

import android.media.MediaCodec
import android.media.MediaFormat
import android.media.MediaMuxer
import java.nio.ByteBuffer

/**
 * MediaMuxer requires every track to be registered via addTrack() before start() is called, and
 * no samples may be written until after start(). The video and audio encoders in this app
 * negotiate their final output formats independently, so this holder buffers any samples that
 * arrive before both tracks are known and flushes them the moment the muxer actually starts.
 */
class MuxerHolder(outputPath: String, private val expectAudioTrack: Boolean) {
    private val muxer = MediaMuxer(outputPath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
    private var videoTrack = -1
    private var audioTrack = -1
    private var started = false
    private val pending = mutableListOf<Triple<Int, ByteBuffer, MediaCodec.BufferInfo>>()

    @Synchronized
    fun addVideoTrack(format: MediaFormat): Int {
        videoTrack = muxer.addTrack(format)
        maybeStart()
        return videoTrack
    }

    @Synchronized
    fun addAudioTrack(format: MediaFormat): Int {
        audioTrack = muxer.addTrack(format)
        maybeStart()
        return audioTrack
    }

    private fun maybeStart() {
        val videoReady = videoTrack >= 0
        val audioReady = !expectAudioTrack || audioTrack >= 0
        if (videoReady && audioReady && !started) {
            muxer.start()
            started = true
            pending.forEach { (track, buffer, info) -> muxer.writeSampleData(track, buffer, info) }
            pending.clear()
        }
    }

    @Synchronized
    fun writeVideoSample(track: Int, buffer: ByteBuffer, info: MediaCodec.BufferInfo) = writeSample(track, buffer, info)

    @Synchronized
    fun writeAudioSample(track: Int, buffer: ByteBuffer, info: MediaCodec.BufferInfo) = writeSample(track, buffer, info)

    private fun writeSample(track: Int, buffer: ByteBuffer, info: MediaCodec.BufferInfo) {
        if (!started) {
            val copy = ByteBuffer.allocate(info.size)
            copy.put(buffer)
            copy.flip()
            val copiedInfo = MediaCodec.BufferInfo().apply {
                set(0, info.size, info.presentationTimeUs, info.flags)
            }
            pending.add(Triple(track, copy, copiedInfo))
        } else {
            muxer.writeSampleData(track, buffer, info)
        }
    }

    fun release() {
        try {
            if (started) muxer.stop()
        } finally {
            muxer.release()
        }
    }
}
