package com.videoslidemaker.app.ui.screens

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.BiasAlignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.videoslidemaker.app.data.ScriptParser
import com.videoslidemaker.app.model.AppStep
import com.videoslidemaker.app.model.EffectStyle
import com.videoslidemaker.app.model.OverlayStyle
import com.videoslidemaker.app.model.TransitionStyle
import com.videoslidemaker.app.model.UiState
import com.videoslidemaker.app.ui.components.AlertStyle
import com.videoslidemaker.app.ui.components.BadgeChip
import com.videoslidemaker.app.ui.components.PrimaryButton
import com.videoslidemaker.app.ui.components.ScreenTitle
import com.videoslidemaker.app.ui.components.SecondaryButton
import com.videoslidemaker.app.ui.theme.Accent
import com.videoslidemaker.app.ui.theme.CardBg
import com.videoslidemaker.app.ui.theme.Muted
import com.videoslidemaker.app.viewmodel.AppViewModel

@Composable
fun PreviewScreen(state: UiState, viewModel: AppViewModel) {
    val timeline = state.effectiveSlides
    val sequence = state.finalSequence()
    val index = state.slideIndexAt(state.previewPositionSec).coerceIn(0, (timeline.size - 1).coerceAtLeast(0))
    val currentSlide = timeline.getOrNull(index)
    val currentImage = sequence.getOrNull(index)
    val totalDuration = state.totalDurationSec

    // Motion progress within the CURRENT slide's own window — same math as the real export
    // (export/FrameRenderer.kt), so the motion shown here matches what you'll actually get.
    val slotStart = currentSlide?.timestampSec ?: 0.0
    val slotEnd = timeline.getOrNull(index + 1)?.timestampSec ?: (slotStart + state.settings.defaultDurationSec)
    val slotDuration = (slotEnd - slotStart).coerceAtLeast(0.1)
    val progressInSlide = ((state.previewPositionSec - slotStart) / slotDuration).toFloat().coerceIn(0f, 1f)
    val effectStyle = state.settings.effectStyle
    val scale = when (effectStyle) {
        EffectStyle.NONE -> 1f
        EffectStyle.ZOOM_IN -> 1f + progressInSlide * 0.06f
        EffectStyle.ZOOM_OUT -> 1.06f - progressInSlide * 0.06f
        EffectStyle.PAN_LEFT, EffectStyle.PAN_RIGHT -> 1.12f
    }
    // A simplified, DP-based approximation of the export's pixel-accurate pan (good enough to
    // convey direction and rough motion in a small preview box).
    val panOffsetDp = when (effectStyle) {
        EffectStyle.PAN_LEFT -> (0.5f - progressInSlide) * 40f
        EffectStyle.PAN_RIGHT -> (progressInSlide - 0.5f) * 40f
        else -> 0f
    }

    Column(Modifier.fillMaxWidth().padding(16.dp)) {
        ScreenTitle("Preview", "Plays in real time with the same motion, timing, and narration your export will have.")

        Box(
            Modifier
                .fillMaxWidth()
                .height(280.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(CardBg),
            contentAlignment = Alignment.Center
        ) {
            if (currentImage != null) {
                AnimatedContent(
                    targetState = currentImage.uri,
                    transitionSpec = {
                        when (state.settings.transitionStyle) {
                            TransitionStyle.NONE -> fadeIn(tween(0)) togetherWith fadeOut(tween(0))
                            TransitionStyle.FADE_BLACK -> fadeIn(tween(300, delayMillis = 150)) togetherWith fadeOut(tween(150))
                            TransitionStyle.CROSSFADE -> fadeIn(tween(350)) togetherWith fadeOut(tween(350))
                            TransitionStyle.SLIDE -> slideInHorizontally(tween(350)) { it } togetherWith slideOutHorizontally(tween(350)) { -it }
                        }
                    },
                    label = "preview-photo"
                ) { uri ->
                    AsyncImage(
                        model = uri,
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(280.dp)
                            .scale(scale)
                            .offset(x = panOffsetDp.dp)
                    )
                }
            } else {
                Text("No photos yet", color = Muted)
            }
            if (currentSlide != null && currentSlide.text.isNotBlank()) {
                Box(
                    Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .background(Color.Black.copy(alpha = 0.55f))
                        .padding(10.dp)
                ) {
                    Text(currentSlide.text, color = Color.White, style = MaterialTheme.typography.bodyMedium)
                }
            }
            state.overlaysActiveAt(state.previewPositionSec).forEach { (overlay, alpha) ->
                // Direct fraction -> bias mapping (0..1 fraction becomes Alignment's -1..1 bias)
                // — Alignment's bias system centers around this point accounting for the text's
                // own size automatically, so no separate offset math is needed here. This uses
                // the exact same xFraction/yFraction as the drag editor and the real export, so
                // what's shown here matches both exactly.
                val overlayAlignment = BiasAlignment(
                    horizontalBias = overlay.xFraction * 2f - 1f,
                    verticalBias = overlay.yFraction * 2f - 1f
                )
                Box(
                    Modifier
                        .align(overlayAlignment)
                        .alpha(alpha)
                ) {
                    when (overlay.style) {
                        OverlayStyle.TAG -> {
                            Row(
                                Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color.Black.copy(alpha = 0.75f)),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(Modifier.width(4.dp).height(26.dp).background(Accent))
                                Text(
                                    overlay.text,
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                                )
                            }
                        }
                        OverlayStyle.UNDERLINE -> {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(overlay.text, color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                                Box(Modifier.padding(top = 4.dp).width(60.dp).height(3.dp).background(Accent))
                            }
                        }
                        OverlayStyle.MINIMAL -> {
                            Text(overlay.text, color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                        }
                    }
                }
            }
        }

        Row(
            Modifier.fillMaxWidth().padding(top = 10.dp, bottom = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                "${ScriptParser.formatTime(state.previewPositionSec)} / ${ScriptParser.formatTime(totalDuration)}",
                style = MaterialTheme.typography.bodySmall,
                color = Muted
            )
            if (timeline.isNotEmpty()) {
                Text("${index + 1} / ${timeline.size}", style = MaterialTheme.typography.bodySmall, color = Muted)
            }
        }
        LinearProgressIndicator(
            progress = { if (totalDuration <= 0.0) 0f else (state.previewPositionSec / totalDuration).toFloat().coerceIn(0f, 1f) },
            modifier = Modifier.fillMaxWidth(),
            color = Accent
        )

        Row(
            Modifier.fillMaxWidth().padding(top = 12.dp, bottom = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            BadgeChip(state.settings.effectStyle.label, if (state.settings.effectStyle != EffectStyle.NONE) AlertStyle.SUCCESS else AlertStyle.INFO)
            BadgeChip(state.settings.transitionStyle.label, if (state.settings.transitionStyle != TransitionStyle.NONE) AlertStyle.SUCCESS else AlertStyle.INFO)
            BadgeChip(if (state.settings.narration.enabled) "Narration on" else "Narration off", if (state.settings.narration.enabled) AlertStyle.SUCCESS else AlertStyle.INFO)
        }

        Row(
            Modifier.fillMaxWidth().padding(vertical = 16.dp),
            horizontalArrangement = Arrangement.Center
        ) {
            IconButton(onClick = viewModel::previewPrev, modifier = Modifier.size(52.dp)) {
                Icon(Icons.Filled.SkipPrevious, contentDescription = "Previous", tint = Muted, modifier = Modifier.size(30.dp))
            }
            IconButton(onClick = viewModel::previewTogglePlay, modifier = Modifier.size(64.dp).padding(horizontal = 12.dp)) {
                Icon(
                    if (state.previewPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                    contentDescription = "Play/Pause",
                    tint = Accent,
                    modifier = Modifier.size(40.dp)
                )
            }
            IconButton(onClick = viewModel::previewNext, modifier = Modifier.size(52.dp)) {
                Icon(Icons.Filled.SkipNext, contentDescription = "Next", tint = Muted, modifier = Modifier.size(30.dp))
            }
        }

        if (state.settings.narration.enabled) {
            Text(
                "▶ Press play to hear each sentence spoken as its photo comes up — a good way to confirm photo, text, and voice all line up before exporting.",
                style = MaterialTheme.typography.bodySmall,
                color = Muted,
                modifier = Modifier.padding(bottom = 12.dp)
            )
        }

        PrimaryButton("Next — Export →", onClick = { viewModel.stopPreview(); viewModel.goStep(AppStep.EXPORT) })
        SecondaryButton("← Back to Text", onClick = { viewModel.stopPreview(); viewModel.goStep(AppStep.TEXT) })
    }
}
