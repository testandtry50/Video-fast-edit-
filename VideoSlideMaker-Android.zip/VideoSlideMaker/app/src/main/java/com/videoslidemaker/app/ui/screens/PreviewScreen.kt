package com.videoslidemaker.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.videoslidemaker.app.data.ScriptParser
import com.videoslidemaker.app.model.AppStep
import com.videoslidemaker.app.model.UiState
import com.videoslidemaker.app.ui.components.PrimaryButton
import com.videoslidemaker.app.ui.components.ScreenTitle
import com.videoslidemaker.app.ui.components.SecondaryButton
import com.videoslidemaker.app.ui.theme.Accent
import com.videoslidemaker.app.ui.theme.CardBg
import com.videoslidemaker.app.ui.theme.Muted
import com.videoslidemaker.app.viewmodel.AppViewModel

@Composable
fun PreviewScreen(state: UiState, viewModel: AppViewModel) {
    val sequence = state.finalSequence()
    val index = state.previewIndex.coerceIn(0, (sequence.size - 1).coerceAtLeast(0))
    val currentImage = sequence.getOrNull(index)
    val currentSlide = state.effectiveSlides.getOrNull(index)

    Column(Modifier.fillMaxWidth().padding(16.dp)) {
        ScreenTitle("Preview", "A quick preview at faster-than-real speed — the final export uses the real timing.")

        Box(
            Modifier
                .fillMaxWidth()
                .height(280.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(CardBg),
            contentAlignment = Alignment.Center
        ) {
            if (currentImage != null) {
                AsyncImage(
                    model = currentImage.uri,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxWidth().height(280.dp)
                )
            } else {
                Text("No photos yet", color = Muted)
            }
            if (currentSlide != null && currentSlide.text.isNotBlank()) {
                Box(
                    Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .background(androidx.compose.ui.graphics.Color.Black.copy(alpha = 0.55f))
                        .padding(10.dp)
                ) {
                    Text(currentSlide.text, color = androidx.compose.ui.graphics.Color.White, style = MaterialTheme.typography.bodyMedium)
                }
            }
        }

        Text(
            "${index + 1} / ${sequence.size}  •  ${ScriptParser.formatTime(currentSlide?.timestampSec ?: 0.0)}",
            style = MaterialTheme.typography.bodySmall,
            color = Muted,
            modifier = Modifier.padding(top = 10.dp, bottom = 6.dp)
        )
        LinearProgressIndicator(
            progress = { if (sequence.isEmpty()) 0f else (index + 1).toFloat() / sequence.size },
            modifier = Modifier.fillMaxWidth(),
            color = Accent
        )

        Row(
            Modifier.fillMaxWidth().padding(vertical = 16.dp),
            horizontalArrangement = Arrangement.Center
        ) {
            IconButton(onClick = viewModel::previewPrev, modifier = Modifier.size(52.dp)) {
                Icon(Icons.Filled.SkipPrevious, contentDescription = "Previous", tint = Muted, modifier = Modifier.size(30.dp))
            }
            IconButton(onClick = viewModel::previewTogglePlay, modifier = Modifier.size(64.dp).padding(horizontal = 12.dp)) {
                Icon(
                    if (state.previewPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                    contentDescription = "Play/Pause",
                    tint = Accent,
                    modifier = Modifier.size(40.dp)
                )
            }
            IconButton(onClick = viewModel::previewNext, modifier = Modifier.size(52.dp)) {
                Icon(Icons.Filled.SkipNext, contentDescription = "Next", tint = Muted, modifier = Modifier.size(30.dp))
            }
        }

        PrimaryButton("Next — Export →", onClick = { viewModel.goStep(AppStep.EXPORT) })
        SecondaryButton("← Back to Match", onClick = { viewModel.goStep(AppStep.MATCH) })
    }
}
