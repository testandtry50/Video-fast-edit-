package com.videoslidemaker.app.export

import java.io.File
import java.io.RandomAccessFile

data class PcmAudio(val sampleRate: Int, val channelCount: Int, val data: ByteArray)

/** Minimal reader for the canonical 44-byte-header 16-bit PCM WAV files TextToSpeech writes. */
object WavUtils {
    fun readPcm16Wav(file: File): PcmAudio? {
        if (!file.exists() || file.length() < 44) return null
        RandomAccessFile(file, "r").use { raf ->
            val header = ByteArray(44)
            raf.readFully(header)
            val channelCount = leShort(header, 22).coerceAtLeast(1)
            val sampleRate = leInt(header, 24)
            var dataSize = leInt(header, 40)
            val available = (file.length() - 44).toInt()
            if (dataSize <= 0 || dataSize > available) dataSize = available
            if (dataSize <= 0) return null

            val data = ByteArray(dataSize)
            raf.seek(44)
            raf.readFully(data)
            return PcmAudio(sampleRate, channelCount, data)
        }
    }

    private fun leShort(b: ByteArray, offset: Int): Int =
        (b[offset].toInt() and 0xFF) or ((b[offset + 1].toInt() and 0xFF) shl 8)

    private fun leInt(b: ByteArray, offset: Int): Int =
        (b[offset].toInt() and 0xFF) or
            ((b[offset + 1].toInt() and 0xFF) shl 8) or
            ((b[offset + 2].toInt() and 0xFF) shl 16) or
            ((b[offset + 3].toInt() and 0xFF) shl 24)
}
