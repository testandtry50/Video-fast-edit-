package com.videoslidemaker.app.model

import android.net.Uri

/** The 6-step wizard flow: Script → Photos → Match → Text → Preview → Export. */
enum class AppStep(val index: Int, val label: String) {
    SCRIPT(0, "Script"),
    PHOTOS(1, "Photos"),
    MATCH(2, "Match"),
    TEXT(3, "Text"),
    PREVIEW(4, "Preview"),
    EXPORT(5, "Export")
}

/**
 * One line of the timeline: a timestamp, its sentence text, and which pool photo (if any)
 * has been assigned to it. Equivalent to a parallel (timestamps[i], sentences[i], assigned[i])
 * triple in the original script.
 */
data class SentenceSlide(
    val timestampSec: Double,
    val text: String,
    val assignedImageId: String? = null
)

/**
 * A photo in the shared pool, referenced by its content Uri rather than loaded into memory.
 * NEW: durationOverrideSec is the editable "2:30" time box on the Photos screen. It's what
 * drives timing in simple mode (no script loaded — see UiState.effectiveSlides). When a script
 * is loaded, timing still comes from its timestamps as before, so the two modes never conflict.
 */
data class PoolImage(
    val id: String,
    val uri: Uri,
    val displayName: String,
    val widthPx: Int = 0,
    val heightPx: Int = 0,
    val durationOverrideSec: Double? = null,
    /** False when Android wouldn't grant long-term (persistable) read access to this photo's
     *  source — it'll keep working for the rest of THIS app session, but may fail to open (e.g.
     *  at export time) after the app is closed and reopened. Common for photos picked from
     *  certain messaging-app download folders rather than the regular gallery. */
    val persistedAccess: Boolean = true
)

enum class OverlayStyle(val label: String) {
    TAG("Tag"),
    UNDERLINE("Underline"),
    MINIMAL("Minimal")
}

/**
 * NEW: a short text label — typically a character's name — burned into the video for a chosen
 * time window, e.g. "Abhishek" appearing for a few seconds right when that character is
 * introduced. Independent of which photo is showing at the time. Fades in and out at the edges
 * of its own [startSec, startSec + durationSec) window (its own small transition), regardless
 * of whatever transition the photos are using.
 *
 * [xFraction]/[yFraction] place the CENTER of the text anywhere in the frame (0.0..1.0 of the
 * frame's width/height) — dragged freely in the Text step's editor, not limited to a handful of
 * preset slots.
 */
data class TextOverlay(
    val id: String,
    val text: String,
    val startSec: Double,
    val durationSec: Double,
    val xFraction: Float = 0.5f,
    val yFraction: Float = 0.85f,
    val style: OverlayStyle = OverlayStyle.TAG
)

enum class AspectRatioOption(val label: String, val w: Int, val h: Int) {
    R16_9("16:9 — YouTube", 16, 9),
    R9_16("9:16 — Shorts/Reels", 9, 16),
    R1_1("1:1 — Square", 1, 1),
    R4_5("4:5 — Instagram Post", 4, 5),
    R4_3("4:3 — Classic", 4, 3)
}

/** basePx is null for ORIGINAL, which instead matches the largest uploaded photo. */
enum class QualityOption(val label: String, val basePx: Int?) {
    P480("480p (faster)", 480),
    P720("720p HD", 720),
    P1080("1080p Full HD", 1080),
    P2160("4K Ultra HD", 2160),
    ORIGINAL("Original — match my photos", null)
}

/**
 * NEW: narration is a genuinely new capability. The original app used on-device text-to-speech
 * only so the person matching photos could *hear* a sentence; it never touched the exported
 * file. Here the same synthesized voice is optionally baked into the final MP4's audio track.
 */
data class NarrationSettings(
    val enabled: Boolean = true,
    val voiceLocaleTag: String = "hi-IN",
    val speechRate: Float = 0.95f
)

/** NEW: optional background music mixed underneath the narration. */
data class MusicTrack(
    val uri: Uri? = null,
    val displayName: String? = null,
    val volume: Float = 0.35f
)

enum class EffectStyle(val label: String) {
    NONE("None"),
    ZOOM_IN("Zoom In"),
    ZOOM_OUT("Zoom Out"),
    PAN_LEFT("Pan Left"),
    PAN_RIGHT("Pan Right")
}

enum class TransitionStyle(val label: String) {
    NONE("None (Hard Cut)"),
    FADE_BLACK("Fade to Black"),
    CROSSFADE("Crossfade"),
    SLIDE("Slide")
}

data class ExportSettings(
    val aspectRatio: AspectRatioOption = AspectRatioOption.R16_9,
    val quality: QualityOption = QualityOption.P720,
    val effectStyle: EffectStyle = EffectStyle.ZOOM_IN,
    val transitionStyle: TransitionStyle = TransitionStyle.FADE_BLACK,
    val defaultDurationSec: Int = 3,
    val narration: NarrationSettings = NarrationSettings(),
    val music: MusicTrack = MusicTrack()
)
