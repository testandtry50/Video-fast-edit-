package com.videoslidemaker.app.model

import android.net.Uri

data class ExportUiProgress(
    val running: Boolean = false,
    val percent: Int = 0,
    val message: String = "",
    val done: Boolean = false,
    val outputUri: Uri? = null,
    val error: String? = null
)

/**
 * NEW: live status of a bulk photo import. Null in [UiState.importProgress] means nothing is
 * importing. [total] == 0 means the photos are still being counted/listed.
 */
data class ImportProgress(
    val done: Int = 0,
    val total: Int = 0,
    /** Photos found so far while the folders are still being listed (total is still 0 then). */
    val scanned: Int = 0
)

/** Single source of truth for the whole wizard — mirrors the original app's global JS variables. */
data class UiState(
    val step: AppStep = AppStep.SCRIPT,
    val scriptLoaded: Boolean = false,
    val slides: List<SentenceSlide> = emptyList(),
    val images: List<PoolImage> = emptyList(),
    val settings: ExportSettings = ExportSettings(),
    val curMatchIndex: Int = 0,
    val autoAdvance: Boolean = true,
    /** NEW: character-name (or other short label) text overlays, independent of the photo
     *  timeline — see TextOverlay in TimelineModels.kt. */
    val textOverlays: List<TextOverlay> = emptyList(),
    /** NEW: real elapsed seconds into the preview timeline — drives an actual real-time,
     *  animated playback instead of the old step-through-at-fake-speed index. */
    val previewPositionSec: Double = 0.0,
    val previewPlaying: Boolean = false,
    val exportProgress: ExportUiProgress = ExportUiProgress(),
    /** NEW: set while a big photo import is running, so the app shows a progress bar instead of
     *  looking frozen/black. */
    val importProgress: ImportProgress? = null,
    /** NEW: one-line result of the last import (e.g. "3 photos couldn't be read"), shown on the
     *  Photos screen. Null when everything went fine. */
    val importNote: String? = null
) {
    /**
     * NEW: the timeline actually used for preview/export. When a script has been loaded this
     * is just [slides], unchanged. When there's no script — the simple-slideshow case — one
     * slide is generated per photo, in pool order, using that photo's own time box
     * (PoolImage.durationOverrideSec), or the default duration if it hasn't been set yet.
     */
    val effectiveSlides: List<SentenceSlide>
        get() {
            if (slides.isNotEmpty()) return slides
            if (images.isEmpty()) return emptyList()
            var t = 0.0
            return images.map { image ->
                val duration = (image.durationOverrideSec ?: settings.defaultDurationSec.toDouble()).coerceAtLeast(0.1)
                val slide = SentenceSlide(timestampSec = t, text = "", assignedImageId = image.id)
                t += duration
                slide
            }
        }

    val totalDurationSec: Double
        get() {
            if (slides.isNotEmpty()) {
                return slides.last().timestampSec + settings.defaultDurationSec.toDouble().coerceAtLeast(0.1)
            }
            if (images.isEmpty()) return 0.0
            return images.sumOf { (it.durationOverrideSec ?: settings.defaultDurationSec.toDouble()).coerceAtLeast(0.1) }
        }

    /** NEW: which text overlays are visible at [positionSec], each paired with its own fade
     *  progress (0 = fully transparent, 1 = fully visible) so the renderer can fade each one in
     *  and out independently of whatever transition the photo underneath it is using. */
    fun overlaysActiveAt(positionSec: Double): List<Pair<TextOverlay, Float>> {
        val fadeSec = 0.35
        return textOverlays.mapNotNull { overlay ->
            val end = overlay.startSec + overlay.durationSec
            if (positionSec < overlay.startSec || positionSec >= end) return@mapNotNull null
            val sinceStart = positionSec - overlay.startSec
            val untilEnd = end - positionSec
            val alpha = minOf(1.0, sinceStart / fadeSec, untilEnd / fadeSec).coerceIn(0.0, 1.0)
            overlay to alpha.toFloat()
        }
    }

    fun durationForIndex(index: Int): Double {
        if (slides.isEmpty() && images.isNotEmpty()) {
            // Simple mode: the duration belongs to the photo itself, not to a timestamp gap.
            return (images.getOrNull(index)?.durationOverrideSec ?: settings.defaultDurationSec.toDouble()).coerceAtLeast(0.1)
        }
        val timeline = effectiveSlides
        val start = timeline.getOrNull(index)?.timestampSec ?: return settings.defaultDurationSec.toDouble()
        val end = timeline.getOrNull(index + 1)?.timestampSec ?: (start + settings.defaultDurationSec)
        return (end - start).coerceAtLeast(0.1)
    }

    /** NEW: which slide index is on-screen at [positionSec] into the timeline — the last slide
     *  whose own start time has already been reached. Used to drive real-time preview playback. */
    fun slideIndexAt(positionSec: Double, timeline: List<SentenceSlide> = effectiveSlides): Int {
        if (timeline.isEmpty()) return -1
        // Binary search (the timeline is in time order): fast even with tens of thousands of
        // slides, and callers that already hold the timeline can pass it in to avoid rebuilding it.
        var lo = 0
        var hi = timeline.size - 1
        var found = 0
        while (lo <= hi) {
            val mid = (lo + hi) ushr 1
            if (timeline[mid].timestampSec <= positionSec) {
                found = mid
                lo = mid + 1
            } else {
                hi = mid - 1
            }
        }
        return found
    }

    /**
     * The photo actually shown for each slide: the one explicitly assigned, or — matching the
     * original getFinalSequence() — the next not-yet-used pool photo as a fallback. Uses
     * [effectiveSlides], so this works the same whether a script is loaded or not.
     */
    fun finalSequence(): List<PoolImage?> {
        val timeline = effectiveSlides
        val imageById = images.associateBy { it.id } // O(1) lookups instead of scanning the list per slide
        val usedFallbacks = HashSet<String>()
        var pointer = 0
        fun nextFallback(): PoolImage? {
            while (pointer < images.size && images[pointer].id in usedFallbacks) pointer++
            return images.getOrNull(pointer)
        }
        return timeline.map { slide ->
            val assigned = slide.assignedImageId?.let { id -> imageById[id] }
            assigned ?: nextFallback()?.also { usedFallbacks.add(it.id) } ?: images.firstOrNull()
        }
    }
}
