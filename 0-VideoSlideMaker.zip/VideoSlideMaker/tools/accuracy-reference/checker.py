"""
Audio-transcript accuracy checker - reference implementation (Python).

The AUDIO is the source of truth. Input: timestamped transcript segments, and the words a speech
recognizer heard (each with start/end in ms and a 0..1 confidence). Output: one verdict per segment.

This file is the design the Kotlin code in app/src/main/java/.../check/ is a port of. Keep them in step.

Pipeline
  1. tokenize both sides identically (case, punctuation, fillers, number words -> digits)
  2. align the two word lists globally (unique-trigram anchors + edit-distance DP between anchors)
  3. per segment: classify every word, find where the segment really starts in the audio, decide a status

Status meaning (always from the transcript's point of view):
  TEXT_MISMATCH  a transcript word was replaced by a different spoken word
  MISSING_WORD   a word is spoken in the audio but is NOT in the transcript
  EXTRA_WORD     a word is in the transcript but is NOT spoken in the audio
  TIMESTAMP_ERROR the words are right but the segment starts at a different time
  UNCERTAIN      the recognizer is not sure enough to accuse the transcript
  MATCH          nothing wrong found
"""
from __future__ import annotations

import re
import unicodedata
from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional, Tuple


# ----------------------------------------------------------------------------------------------
# Models
# ----------------------------------------------------------------------------------------------
class Status(Enum):
    MATCH = "MATCH"
    TIMESTAMP_ERROR = "TIMESTAMP ERROR"
    TEXT_MISMATCH = "TEXT MISMATCH"
    MISSING_WORD = "MISSING WORD"
    EXTRA_WORD = "EXTRA WORD"
    UNCERTAIN = "UNCERTAIN"


EMOJI = {
    Status.MATCH: "\U0001F7E2", Status.TIMESTAMP_ERROR: "\U0001F7E1", Status.TEXT_MISMATCH: "\U0001F534",
    Status.MISSING_WORD: "\U0001F534", Status.EXTRA_WORD: "\U0001F534", Status.UNCERTAIN: "\u26AA",
}


@dataclass
class Settings:
    timestamp_tolerance_ms: int = 500      # how far a timestamp may be from the real start before it is an error
    min_word_confidence: float = 0.60      # below this the recognizer's word is "not sure"
    ignore_fillers: bool = True            # um / uh / hmm are ignored on both sides


@dataclass
class Segment:
    timestamp_ms: int
    text: str


@dataclass
class Spoken:
    text: str
    start_ms: int
    end_ms: int
    conf: float = 1.0


@dataclass
class WordIssue:
    kind: Status                      # TEXT_MISMATCH, MISSING_WORD or EXTRA_WORD
    firm: bool                        # False = "possible": shown, but not counted as an error
    transcript_text: str              # "" for MISSING_WORD
    audio_text: str                   # "" for EXTRA_WORD
    audio_start_ms: Optional[int]     # where in the audio (EXTRA_WORD: where the word would have to be)
    audio_end_ms: Optional[int]
    t_from: int                       # transcript words [t_from, t_to) of the segment this is about
    t_to: int
    note: str = ""


@dataclass
class TimestampCheck:
    transcript_ms: int
    actual_ms: Optional[int]
    tolerance_ms: int
    verifiable: bool

    @property
    def diff_ms(self) -> Optional[int]:
        return None if self.actual_ms is None else self.actual_ms - self.transcript_ms

    @property
    def is_error(self) -> bool:
        return self.verifiable and self.actual_ms is not None and abs(self.actual_ms - self.transcript_ms) > self.tolerance_ms

    @property
    def corrected_ms(self) -> Optional[int]:
        return self.actual_ms if self.is_error else None


@dataclass
class SegmentResult:
    index: int
    timestamp_ms: int
    text: str
    words: List[str]
    status: Status
    issues: List[WordIssue]
    timestamp: Optional[TimestampCheck]
    spoken_text: str
    audio_start_ms: Optional[int]
    audio_end_ms: Optional[int]
    matched_words: int
    reason: str = ""


@dataclass
class CheckResult:
    segments: List[SegmentResult]
    word_total: int
    word_matched: int
    whole_second_timestamps: bool

    def count(self, status: Status) -> int:
        return sum(1 for s in self.segments if s.status == status)

    @property
    def accuracy(self) -> float:
        return 1.0 if self.word_total == 0 else self.word_matched / self.word_total


def clock(ms: int) -> str:
    ms = max(0, ms)
    return f"{ms // 3600000:02d}:{(ms // 60000) % 60:02d}:{(ms // 1000) % 60:02d}.{ms % 1000:03d}"


def signed_seconds(ms: int) -> str:
    sign = "+" if ms > 0 else "-" if ms < 0 else ""
    a = abs(ms)
    return f"{sign}{a // 1000}.{a % 1000:03d} seconds"


# ----------------------------------------------------------------------------------------------
# Tokenizing
# ----------------------------------------------------------------------------------------------
@dataclass
class Tok:
    disp: str
    norm: str
    start: int = 0
    end: int = 0
    conf: float = 1.0
    seg: int = -1
    widx: int = -1                # index among the words of its segment
    numeric: bool = False
    nid: int = 0


FILLERS = {"um", "umm", "uh", "uhh", "uhm", "er", "erm", "ah", "hmm", "hm", "mm", "mmm", "mhm", "eh"}

_UNITS = {w: i for i, w in enumerate(
    "zero one two three four five six seven eight nine ten eleven twelve thirteen fourteen fifteen "
    "sixteen seventeen eighteen nineteen".split())}
_TENS = {"twenty": 20, "thirty": 30, "forty": 40, "fourty": 40, "fifty": 50, "sixty": 60,
         "seventy": 70, "eighty": 80, "ninety": 90}
_SCALES = {"hundred": 100, "thousand": 1000, "million": 1_000_000, "billion": 1_000_000_000}


def _num_class(w: str) -> Optional[str]:
    if w in _UNITS:
        return "unit" if _UNITS[w] < 10 else "teen"
    if w in _TENS:
        return "tens"
    if w == "hundred":
        return "hundred"
    if w in _SCALES:
        return "scale"
    return None


def _can_follow(prev: str, cur: str) -> bool:
    p, c = _num_class(prev), _num_class(cur)
    if p is None or c is None:
        return False
    if prev == "zero":
        return False
    if p in ("unit", "teen"):
        return c in ("hundred", "scale") and not (p == "teen" and c == "hundred")
    if p == "tens":
        return c == "unit" and cur != "zero"
    if p == "hundred":
        return c in ("unit", "teen", "tens", "scale") and cur != "zero"
    return c in ("unit", "teen", "tens", "hundred") and cur != "zero"      # after thousand / million ...


def _number_value(words: List[str]) -> int:
    total, cur = 0, 0
    for w in words:
        if w == "and":
            continue
        if w in _UNITS:
            cur += _UNITS[w]
        elif w in _TENS:
            cur += _TENS[w]
        elif w == "hundred":
            cur = (cur or 1) * 100
        else:
            total += (cur or 1) * _SCALES[w]
            cur = 0
    return total + cur


def _is_word_char(c: str) -> bool:
    return unicodedata.category(c)[0] in "LNM"


_BRACKETS = re.compile(r"\[[^\]]*\]")
_SPLIT = re.compile(r"[\s\-\u2010-\u2015/]+")
_CURRENCY = re.compile(r"([$\u20ac\u00a3\u20b9])\s*(\d[\d,]*(?:\.\d+)?)")
_CURRENCY_NAME = {"$": "dollars", "\u20ac": "euros", "\u00a3": "pounds", "\u20b9": "rupees"}


def _spell_symbols(text: str) -> str:
    """A transcript writes '$5', '10%' and 'Q&A'; a speaker says 'five dollars', 'ten percent', 'Q and A'."""
    text = _CURRENCY.sub(lambda m: f"{m.group(2)} {_CURRENCY_NAME[m.group(1)]}", text)
    return text.replace("%", " percent ").replace("&", " and ")


def split_words(text: str) -> List[Tuple[str, str]]:
    """[(display, norm)]. Lower-case, punctuation gone, apostrophes dropped from norm (don't == dont)."""
    text = _BRACKETS.sub(" ", text)
    text = unicodedata.normalize("NFKC", text).replace("\u2019", "'").replace("\u2018", "'")
    text = _spell_symbols(text)
    out = []
    for raw in _SPLIT.split(text):
        a, b = 0, len(raw)
        while a < b and not _is_word_char(raw[a]):
            a += 1
        while b > a and not _is_word_char(raw[b - 1]):
            b -= 1
        disp = raw[a:b]
        norm = "".join(c for c in disp if _is_word_char(c)).lower()
        if norm:
            out.append((disp, norm))
    return out


_YEAR_PREFIX = {"eleven": 11, "twelve": 12, "thirteen": 13, "fourteen": 14, "fifteen": 15, "sixteen": 16,
                "seventeen": 17, "eighteen": 18, "nineteen": 19, "twenty": 20}


def _year_at(toks: List[Tok], i: int) -> Optional[Tuple[int, int]]:
    """A year said in two halves ('nineteen eighty four', 'twenty twenty', 'nineteen oh five'): (value, tokens used)."""
    p = _YEAR_PREFIX.get(toks[i].norm)
    if p is None or i + 1 >= len(toks):
        return None
    a = toks[i + 1].norm
    b = toks[i + 2].norm if i + 2 < len(toks) else ""
    if a in _TENS:
        if b in _UNITS and 1 <= _UNITS[b] <= 9:
            return p * 100 + _TENS[a] + _UNITS[b], 3
        return p * 100 + _TENS[a], 2
    if a in _UNITS and 10 <= _UNITS[a] <= 19:
        return p * 100 + _UNITS[a], 2
    if a in ("oh", "o") and b in _UNITS and 1 <= _UNITS[b] <= 9:
        return p * 100 + _UNITS[b], 3
    return None


def merge_numbers(toks: List[Tok]) -> List[Tok]:
    """'twenty five' -> one token '25', so it equals the digits '25' in a transcript."""
    out: List[Tok] = []
    i = 0
    while i < len(toks):
        t = toks[i]
        year = _year_at(toks, i)
        if year is not None:
            value, used = year
            run = toks[i:i + used]
            out.append(Tok(disp=" ".join(r.disp for r in run), norm=str(value), start=run[0].start, end=run[-1].end,
                           conf=min(r.conf for r in run), seg=t.seg, numeric=True))
            i += used
            continue
        if _num_class(t.norm) is None:
            if t.norm.isdigit():
                t.numeric = True
            out.append(t)
            i += 1
            continue
        run = [t]
        prev = t.norm
        k = i + 1
        while k < len(toks):
            cur = toks[k].norm
            if (cur == "and" and _num_class(prev) in ("hundred", "scale") and k + 1 < len(toks)
                    and _can_follow(prev, toks[k + 1].norm)):
                run += [toks[k], toks[k + 1]]
                prev = toks[k + 1].norm
                k += 2
            elif _can_follow(prev, cur):
                run.append(toks[k])
                prev = cur
                k += 1
            else:
                break
        value = _number_value([r.norm for r in run])
        out.append(Tok(disp=" ".join(r.disp for r in run), norm=str(value), start=run[0].start, end=run[-1].end,
                       conf=min(r.conf for r in run), seg=t.seg, numeric=True))
        i = k
    return out


def _finish(toks: List[Tok], settings: Settings) -> List[Tok]:
    if settings.ignore_fillers:
        toks = [t for t in toks if t.norm not in FILLERS]
    return merge_numbers(toks)


def tokenize_transcript(segments: List[Segment], settings: Settings) -> Tuple[List[Tok], List[Tuple[int, int]]]:
    T: List[Tok] = []
    ranges = []
    for k, seg in enumerate(segments):
        toks = _finish([Tok(d, n, seg=k) for d, n in split_words(seg.text)], settings)
        for w, t in enumerate(toks):
            t.seg, t.widx = k, w
        ranges.append((len(T), len(T) + len(toks)))
        T.extend(toks)
    return T, ranges


def tokenize_spoken(spoken: List[Spoken], settings: Settings) -> List[Tok]:
    toks: List[Tok] = []
    for sp in sorted(spoken, key=lambda s: (s.start_ms, s.end_ms)):
        parts = split_words(sp.text)
        if not parts:
            continue
        span = max(0, sp.end_ms - sp.start_ms)
        for i, (d, n) in enumerate(parts):
            toks.append(Tok(d, n, start=sp.start_ms + span * i // len(parts), end=sp.start_ms + span * (i + 1) // len(parts),
                            conf=sp.conf))
    return _finish(toks, settings)


# ----------------------------------------------------------------------------------------------
# Alignment
# ----------------------------------------------------------------------------------------------
MAX_CELLS = 6_000_000      # a gap between anchors up to this many cells gets the exact DP
BAND = 500                 # bigger gaps: only cells this close to the straight line are considered
MAX_BAND_CELLS = 60_000_000    # a gap even the band cannot cover in this much memory (about 60 MB) stays unpaired (-> UNCERTAIN)
GAP_T = 1.0                # a transcript word with no spoken partner


def _gap_s(s: Tok) -> float:
    return 0.6 + 0.4 * s.conf      # a spoken word with no transcript partner; doubtful words are cheaper to skip


def _lev(a: str, b: str) -> int:
    prev = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        cur = [i]
        for j, cb in enumerate(b, 1):
            cur.append(min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (ca != cb)))
        prev = cur
    return prev[-1]


_sub_cache: Dict[Tuple[int, int], float] = {}    # cleared at the start of every check(): word ids only mean something inside one call


def _sub_cost(t: Tok, s: Tok) -> float:
    if t.nid == s.nid:
        return 0.0
    key = (t.nid, s.nid)
    v = _sub_cache.get(key)
    if v is None:
        a, b = t.norm, s.norm
        m = max(len(a), len(b))
        sim = 0.0 if abs(len(a) - len(b)) > m * 0.5 else max(0.0, 1.0 - _lev(a, b) / m)
        v = 1.0 - 0.6 * ((sim - 0.5) / 0.5) if sim >= 0.5 else 1.0
        _sub_cache[key] = v
    return v


def _find_anchors(T: List[Tok], S: List[Tok], n: int = 3) -> List[Tuple[int, int]]:
    """Word triples that occur exactly once on each side; the longest in-order chain of them."""
    if len(T) < n or len(S) < n:
        return []

    def grams(X):
        d: Dict[tuple, List[int]] = {}
        for i in range(len(X) - n + 1):
            d.setdefault(tuple(x.nid for x in X[i:i + n]), []).append(i)
        return d

    gt, gs = grams(T), grams(S)
    cand = sorted((v[0], gs[k][0]) for k, v in gt.items() if len(v) == 1 and k in gs and len(gs[k]) == 1)
    if not cand:
        return []
    # longest strictly-increasing subsequence of the S positions (patience sorting)
    tails: List[int] = []
    tail_idx: List[int] = []
    prev = [-1] * len(cand)
    import bisect
    for ci, (_, sj) in enumerate(cand):
        pos = bisect.bisect_left(tails, sj)
        if pos == len(tails):
            tails.append(sj)
            tail_idx.append(ci)
        else:
            tails[pos] = sj
            tail_idx[pos] = ci
        prev[ci] = tail_idx[pos - 1] if pos > 0 else -1
    chain = []
    ci = tail_idx[-1]
    while ci >= 0:
        chain.append(cand[ci])
        ci = prev[ci]
    chain.reverse()
    out: List[Tuple[int, int]] = []
    last_t, last_s = -1, -1
    for ti, sj in chain:
        for k in range(n):
            if ti + k > last_t and sj + k > last_s:
                out.append((ti + k, sj + k))
                last_t, last_s = ti + k, sj + k
    return out


def _dp_gap(T, S, ia, ib, ja, jb, pairT, pairS):
    n, m = ib - ia, jb - ja
    if n == 0 or m == 0:
        return
    full = n * m <= MAX_CELLS
    if not full and n * (2 * BAND + 1) > MAX_BAND_CELLS:
        return                               # hours of audio with no common words at all: do not risk the phone's memory

    def bounds(i):
        if full:
            return 0, m
        c = int(round(i * m / n))
        return max(0, c - BAND), min(m, c + BAND)

    INF = float("inf")
    lo, hi = bounds(0)
    row = [0.0] * (hi - lo + 1)
    acc = 0.0
    for j in range(1, hi + 1):
        acc += _gap_s(S[ja + j - 1])
        row[j] = acc
    arrows = [None] * (n + 1)
    arrows[0] = (lo, bytearray([2]) * (hi - lo + 1))
    p_lo, prev = lo, row
    for i in range(1, n + 1):
        lo, hi = bounds(i)
        cur = [INF] * (hi - lo + 1)
        b = bytearray(hi - lo + 1)
        t = T[ia + i - 1]
        p_hi = p_lo + len(prev) - 1
        for j in range(lo, hi + 1):
            best, arrow = INF, 0
            if j >= 1 and p_lo <= j - 1 <= p_hi:
                best = prev[j - 1 - p_lo] + _sub_cost(t, S[ja + j - 1])
            if p_lo <= j <= p_hi:
                c = prev[j - p_lo] + GAP_T
                if c < best:
                    best, arrow = c, 1
            if j - 1 >= lo:
                c = cur[j - 1 - lo] + _gap_s(S[ja + j - 1])
                if c < best:
                    best, arrow = c, 2
            cur[j - lo] = best
            b[j - lo] = arrow
        arrows[i] = (lo, b)
        p_lo, prev = lo, cur
    if not (p_lo <= m <= p_lo + len(prev) - 1) or prev[m - p_lo] == INF:
        return                               # the band never reached the corner: leave this gap unpaired
    i, j = n, m
    while i > 0 or j > 0:
        a = 2 if i == 0 else arrows[i][1][j - arrows[i][0]]
        if a == 0:
            pairT[ia + i - 1] = ja + j - 1
            pairS[ja + j - 1] = ia + i - 1
            i -= 1
            j -= 1
        elif a == 1:
            i -= 1
        else:
            j -= 1


def align(T: List[Tok], S: List[Tok]) -> Tuple[List[int], List[int]]:
    pairT = [-1] * len(T)
    pairS = [-1] * len(S)
    anchors = _find_anchors(T, S)
    for ti, sj in anchors:
        pairT[ti], pairS[sj] = sj, ti
    pt, ps = 0, 0
    for ti, sj in anchors + [(len(T), len(S))]:
        _dp_gap(T, S, pt, ti, ps, sj, pairT, pairS)
        pt, ps = ti + 1, sj + 1
    return pairT, pairS


# ----------------------------------------------------------------------------------------------
# Verdicts
# ----------------------------------------------------------------------------------------------
LOCATED_FRACTION = 0.34     # fewer words than this paired up -> the segment is not really in the audio
EDGE_WORDS = 3              # spoken words next to the transcript's first / last word that still count
EDGE_GAP_MS = 1500
SEGMENT_START_WORDS = 3     # the start of a segment is read from one of its first words
SPLIT_GAP_MS = 700          # a pause this long inside one unscripted passage lets it be shared between two segments
_ISSUE_ORDER = [Status.TEXT_MISMATCH, Status.MISSING_WORD, Status.EXTRA_WORD]
NUMBER_NOTE = "Next to a number, which can be spoken several ways, so this is not counted as an error."


def _word_ms(word: Tok) -> float:
    return 80 + 45 * len(word.norm)             # roughly how long the word takes to say


def _needed_ms(word: Tok) -> float:
    return 0.5 * _word_ms(word)                 # ... and the least room that must exist for it


def _touches_number(X: List[Tok], lo: int, hi: int) -> bool:
    """Is a number inside X[lo:hi] or right next to it? (units like 'dollars' / 'percent' / 'point five' hang off numbers)"""
    return any(0 <= x < len(X) and X[x].numeric for x in range(lo - 1, hi + 1))


def check(segments: List[Segment], spoken: List[Spoken], settings: Settings = Settings()) -> CheckResult:
    tau = settings.min_word_confidence
    _sub_cache.clear()
    T, ranges = tokenize_transcript(segments, settings)
    S = tokenize_spoken(spoken, settings)
    intern: Dict[str, int] = {}
    for t in T + S:
        t.nid = intern.setdefault(t.norm, len(intern))
    pairT, pairS = align(T, S)

    whole = len(segments) >= 3 and sum(1 for s in segments if s.timestamp_ms % 1000 == 0) >= 0.9 * len(segments)
    tolerance = max(settings.timestamp_tolerance_ms, 1000) if whole else settings.timestamp_tolerance_ms

    # --- spoken words nobody claimed ("missing from the transcript"), handed to a segment each
    ins_by_seg: Dict[int, List[int]] = {}
    m = len(S)
    j = 0
    while j < m:
        if pairS[j] >= 0:
            j += 1
            continue
        r0 = j
        while j < m and pairS[j] < 0:
            j += 1
        r1 = j
        left = r0 - 1 if r0 > 0 else None
        right = r1 if r1 < m else None
        if left is None and right is None:
            continue                                       # nothing aligned at all
        if left is None:                                   # speech before the transcript starts: only the words right next to it count
            kept, nxt = [], S[right].start
            for x in range(r1 - 1, r0 - 1, -1):
                if len(kept) >= EDGE_WORDS or nxt - S[x].end > EDGE_GAP_MS:
                    break
                kept.append(x)
                nxt = S[x].start
            for x in kept:
                ins_by_seg.setdefault(T[pairS[right]].seg, []).append(x)
        elif right is None:                                # speech after it ends
            kept, prv = [], S[left].end
            for x in range(r0, r1):
                if len(kept) >= EDGE_WORDS or S[x].start - prv > EDGE_GAP_MS:
                    break
                kept.append(x)
                prv = S[x].end
            for x in kept:
                ins_by_seg.setdefault(T[pairS[left]].seg, []).append(x)
        else:
            a, b = T[pairS[left]].seg, T[pairS[right]].seg
            if a == b:
                cut = r1                                   # inside one segment: all of it belongs there
                first_seg = second_seg = a
            else:
                # One unscripted passage stays in one piece (the nearer segment gets it). Only a real pause inside it
                # (it is two separate remarks) lets the part before the pause go to the earlier segment.
                cut, widest = None, SPLIT_GAP_MS - 1
                for x in range(r0 + 1, r1):
                    g = S[x].start - S[x - 1].end
                    if g > widest:
                        widest, cut = g, x
                if cut is not None:
                    first_seg, second_seg = a, b
                else:
                    nearer = b if (S[right].start - S[r1 - 1].end) < (S[r0].start - S[left].end) else a
                    cut, first_seg, second_seg = r1, nearer, nearer
            for x in range(r0, r1):
                ins_by_seg.setdefault(first_seg if x < cut else second_seg, []).append(x)

    # neighbours (in the audio) of an unpaired transcript word
    prev_paired = [-1] * len(T)
    last = -1
    for i in range(len(T)):
        prev_paired[i] = last
        if pairT[i] >= 0:
            last = pairT[i]
    next_paired = [-1] * len(T)
    nxt_p = -1
    for i in range(len(T) - 1, -1, -1):
        next_paired[i] = nxt_p
        if pairT[i] >= 0:
            nxt_p = pairT[i]

    results: List[SegmentResult] = []
    total_words = matched_words = 0
    for k, seg in enumerate(segments):
        t0, t1 = ranges[k]
        words = [t.disp for t in T[t0:t1]]
        n_tok = t1 - t0
        if n_tok == 0:
            results.append(SegmentResult(k, seg.timestamp_ms, seg.text, words, Status.UNCERTAIN, [], None, "", None, None,
                                         0, "This line has no words to check."))
            continue
        issues: List[WordIssue] = []
        paired = sum(1 for i in range(t0, t1) if pairT[i] >= 0)
        located = paired / n_tok >= LOCATED_FRACTION
        seg_matched = 0

        i = t0
        while i < t1:
            if pairT[i] >= 0:
                s = S[pairT[i]]
                if s.nid == T[i].nid:
                    seg_matched += 1
                    i += 1
                    continue
                # a run of replaced words
                j0 = i
                while i < t1 and pairT[i] >= 0 and S[pairT[i]].nid != T[i].nid:
                    i += 1
                sp = [S[pairT[x]] for x in range(j0, i)]
                numeric = (any(T[x].numeric or S[pairT[x]].numeric for x in range(j0, i))
                           or _touches_number(T, j0, i) or _touches_number(S, pairT[j0], pairT[i - 1] + 1))
                mean_conf = sum(x.conf for x in sp) / len(sp)
                firm = mean_conf >= tau and not numeric
                note = ""
                if numeric:
                    note = NUMBER_NOTE
                elif not firm:
                    note = "The recognizer was not sure what was said here."
                issues.append(WordIssue(Status.TEXT_MISMATCH, firm, " ".join(T[x].disp for x in range(j0, i)),
                                        " ".join(x.disp for x in sp), sp[0].start, sp[-1].end,
                                        T[j0].widx, T[i - 1].widx + 1, note))
            else:
                j0 = i
                while i < t1 and pairT[i] < 0:
                    i += 1
                left, right = prev_paired[j0], next_paired[i - 1]
                lo_ms = S[left].end if left >= 0 else None
                hi_ms = S[right].start if right >= 0 else None
                need = sum(_needed_ms(T[x]) for x in range(j0, i))
                firm = lo_ms is not None and hi_ms is not None and (hi_ms - lo_ms) < need
                numeric = _touches_number(T, j0, i)
                if numeric:
                    firm = False
                note = "" if firm else (NUMBER_NOTE if numeric else
                                        "There is room for the word in the audio, so the recognizer may just have missed it."
                                        if lo_ms is not None and hi_ms is not None
                                        else "This is at the very edge of the recording.")
                issues.append(WordIssue(Status.EXTRA_WORD, firm, " ".join(T[x].disp for x in range(j0, i)), "",
                                        lo_ms if lo_ms is not None else hi_ms, hi_ms if hi_ms is not None else lo_ms,
                                        T[j0].widx, T[i - 1].widx + 1, note))

        # spoken words that the transcript does not have
        ins = sorted(ins_by_seg.get(k, []))
        g = 0
        while g < len(ins):
            h = g
            while h + 1 < len(ins) and ins[h + 1] == ins[h] + 1:
                h += 1
            run = [S[x] for x in ins[g:h + 1]]
            mean_conf = sum(x.conf for x in run) / len(run)
            numeric = _touches_number(S, ins[g], ins[h] + 1)
            stutter = (len(run) == 1 and ((ins[g] > 0 and S[ins[g] - 1].nid == S[ins[g]].nid)
                                          or (ins[g] + 1 < len(S) and S[ins[g] + 1].nid == S[ins[g]].nid)))
            firm = mean_conf >= tau and not numeric and not stutter
            # which transcript position it sits at: just after the last paired word of this segment before it
            pos = 0
            for x in range(t0, t1):
                if pairT[x] >= 0 and pairT[x] < ins[g]:
                    pos = T[x].widx + 1
            note = ("" if firm else NUMBER_NOTE if numeric else "The speaker repeated a word here (a stutter), so this is not counted as an error."
                    if stutter else "The recognizer was not sure about this word.")
            issues.append(WordIssue(Status.MISSING_WORD, firm, "", " ".join(x.disp for x in run), run[0].start, run[-1].end,
                                    pos, pos, note))
            g = h + 1
        issues.sort(key=lambda w: (w.t_from, _ISSUE_ORDER.index(w.kind)))

        # --- where does the segment really start?
        ts_check: Optional[TimestampCheck] = None
        actual_start = actual_end = None
        claimed = [pairT[i] for i in range(t0, t1) if pairT[i] >= 0] + ins_by_seg.get(k, [])
        if claimed:
            actual_start = min(S[x].start for x in claimed)
            actual_end = max(S[x].end for x in claimed)
        anchor_ms = None
        skipped_ms = 0.0          # time taken by spoken words before the anchor that could not serve as one themselves
        for i in range(t0, min(t1, t0 + SEGMENT_START_WORDS)):
            if pairT[i] >= 0:
                s = S[pairT[i]]
                same = s.nid == T[i].nid
                if s.conf >= (0.4 if same else tau) and (same or not T[i].numeric):
                    anchor_ms = max(0, int(round(s.start - skipped_ms)))
                    break
                skipped_ms += _word_ms(T[i])
        if located:
            ts_check = TimestampCheck(seg.timestamp_ms, anchor_ms, tolerance, anchor_ms is not None)

        spoken_text = " ".join(S[x].disp for x in sorted(set(claimed)))
        seg_matched_final = seg_matched
        total_words += n_tok
        matched_words += seg_matched_final

        # --- the status
        reason = ""
        if not located:
            # Hardly any of this line was found. Only "the audio has no room for these words at all" still counts as
            # firm; everything else may just be the recognizer missing a passage, so it is only a doubt.
            for w in issues:
                w.firm = w.firm and w.kind == Status.EXTRA_WORD
            if any(w.firm for w in issues):
                status = Status.EXTRA_WORD
            else:
                status = Status.UNCERTAIN
                reason = "This line could not be found in the audio."
        else:
            firm_issues = [w for w in issues if w.firm]
            if firm_issues:
                status = next(kind for kind in _ISSUE_ORDER if any(w.kind == kind for w in firm_issues))
            elif ts_check is not None and ts_check.is_error:
                status = Status.TIMESTAMP_ERROR
            elif issues or (ts_check is not None and not ts_check.verifiable):
                status = Status.UNCERTAIN
                reason = (next((w.note for w in issues if w.note), "The recognizer was not sure enough about some words.")
                          if issues else "The start of this line could not be located exactly.")
            else:
                status = Status.MATCH
        results.append(SegmentResult(k, seg.timestamp_ms, seg.text, words, status, issues, ts_check, spoken_text,
                                     actual_start, actual_end, seg_matched_final, reason))
    return CheckResult(results, total_words, matched_words, whole)
