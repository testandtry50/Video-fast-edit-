"""
Scenarios for the audio-transcript accuracy checker. The Kotlin test app/src/test/.../check/AccuracyCheckerTest.kt runs
THE SAME scenarios with the same helper data and asserts the same numbers - change one, change the other.

    python3 run_tests.py
"""
import sys
import time
import random

import checker
from checker import (Segment, Spoken, Settings, Status, check, clock, signed_seconds, split_words)

FAILS = []


def expect(cond, what):
    if not cond:
        FAILS.append(what)
        print("   FAIL:", what)


def speak(text, start_ms, per_word=380, conf=1.0, gap=0):
    """Fake recognizer output: one Spoken per word, evenly spaced. (Same formula in the Kotlin tests.)"""
    out, t = [], start_ms
    for w in text.split():
        d = per_word if len(w) < 6 else per_word + 120
        out.append(Spoken(w, t, t + d, conf))
        t += d + 40 + gap
    return out


def chain(lines, start=0, gap=900):
    """[(transcript, spoken)] -> transcript segments stamped at the TRUE spoken starts, and the spoken words."""
    segs, sp, t = [], [], start
    for tx, au in lines:
        segs.append(Segment(t, tx))
        w = speak(au, t)
        sp += w
        t = w[-1].end_ms + gap
    return segs, sp


def scenario(name):
    print("-", name)


# ------------------------------------------------------------------------------------------------------------
scenario("brief example: program -> show, with the exact place in the audio")
r = check([Segment(2000, "Hello everyone, welcome to our program.")], speak("Hello everyone, welcome to our show.", 2000))
s = r.segments[0]
expect(s.status == Status.TEXT_MISMATCH, "status TEXT_MISMATCH")
expect(len(s.issues) == 1 and s.issues[0].transcript_text == "program" and s.issues[0].audio_text == "show", "program -> show")
expect(s.issues[0].firm, "firm")
expect(s.issues[0].audio_start_ms == 4340 and s.issues[0].audio_end_ms == 4720, "audio location 4.340-4.720")
expect(s.issues[0].t_from == 5 and s.issues[0].t_to == 6, "word index 5")
expect(s.timestamp is not None and not s.timestamp.is_error, "timestamp fine")

scenario("brief example: timestamp error 5.000 -> 8.120, +3.120, corrected 8.120")
r = check([Segment(5000, "This is the second part of the talk.")], speak("This is the second part of the talk.", 8120))
s = r.segments[0]
expect(s.status == Status.TIMESTAMP_ERROR, "status TIMESTAMP_ERROR")
expect(s.timestamp.actual_ms == 8120 and s.timestamp.diff_ms == 3120 and s.timestamp.corrected_ms == 8120, "numbers")
expect(clock(5000) == "00:00:05.000" and clock(s.timestamp.actual_ms) == "00:00:08.120", "clock format")
expect(signed_seconds(3120) == "+3.120 seconds" and signed_seconds(-250) == "-0.250 seconds", "signed seconds")

scenario("match / missing word / extra word / text mismatch in one run")
segs, sp = chain([
    ("Welcome back to the channel.", "Welcome back to the channel."),
    ("Today we are looking at the new phone.", "Today we are looking at the very new phone."),
    ("It has a great camera and screen.", "It has a camera and screen."),
    ("The battery lasts all day long.", "The battery lasts all week long."),
])
r = check(segs, sp)
st = [x.status for x in r.segments]
expect(st == [Status.MATCH, Status.MISSING_WORD, Status.EXTRA_WORD, Status.TEXT_MISMATCH], "statuses " + str([x.value for x in st]))
expect(r.segments[1].issues[0].audio_text == "very" and r.segments[1].issues[0].transcript_text == "", "missing = 'very'")
expect(r.segments[1].issues[0].t_from == 6, "'very' goes in before transcript word 6 ('new')")
expect(r.segments[2].issues[0].transcript_text == "great" and r.segments[2].issues[0].audio_text == "", "extra = 'great'")
expect(r.segments[3].issues[0].transcript_text == "day" and r.segments[3].issues[0].audio_text == "week", "day -> week")
expect(r.word_total == 26 and r.word_matched == 24, "26 transcript words, 24 match (got %d/%d)" % (r.word_matched, r.word_total))
expect(abs(r.accuracy - 24 / 26) < 1e-9, "accuracy 24/26")

scenario("uncertain: the recognizer is not sure about the word it heard")
sp = speak("I think the weather is nice today.", 1000)
sp[3] = Spoken("feather", sp[3].start_ms, sp[3].end_ms, 0.35)
r = check([Segment(1000, "I think the weather is nice today.")], sp)
expect(r.segments[0].status == Status.UNCERTAIN, "UNCERTAIN")
expect(len(r.segments[0].issues) == 1 and not r.segments[0].issues[0].firm, "one doubtful issue, not firm")

scenario("case, punctuation, fillers, numbers, years, symbols are NOT errors")
r = check([Segment(0, "We sold 25 units, um, in 2020 -- Don't forget! It costs $5 and 10% & more.")],
          speak("we sold twenty five units uh in twenty twenty dont forget it costs five dollars and ten percent and more", 0))
expect(r.segments[0].status == Status.MATCH, "MATCH, got " + r.segments[0].status.value + str([(w.kind.value, w.transcript_text, w.audio_text) for w in r.segments[0].issues]))
r = check([Segment(0, "Born in 1984 and moved in 1905.")], speak("born in nineteen eighty four and moved in nineteen oh five", 0))
expect(r.segments[0].status == Status.MATCH, "years spoken in halves match digits")
r = check([Segment(0, "There were 250 people and 3000 chairs.")], speak("there were two hundred and fifty people and three thousand chairs", 0))
expect(r.segments[0].status == Status.MATCH, "two hundred and fifty / three thousand")

scenario("a wrong number is never a firm error")
r = check([Segment(0, "We sold 25 units today.")], speak("we sold thirty units today", 0))
expect(r.segments[0].status == Status.UNCERTAIN and r.segments[0].issues[0].kind == Status.TEXT_MISMATCH and not r.segments[0].issues[0].firm,
       "numeric mismatch only possible")

scenario("a line that is not in the audio, at the end -> UNCERTAIN")
segs, sp = chain([("First line here.", "First line here."), ("Totally different words appear.", "Totally different words appear.")])
segs.append(Segment(segs[-1].timestamp_ms + 3000, "This sentence is never spoken."))
r = check(segs, sp)
expect([x.status for x in r.segments] == [Status.MATCH, Status.MATCH, Status.UNCERTAIN], "statuses")
expect("could not be found" in r.segments[2].reason, "reason says why")

scenario("a whole sentence that is not spoken and has NO room between its neighbours -> EXTRA WORD")
segs, sp = chain([("First line here today.", "First line here today."), ("Last line is here now.", "Last line is here now.")], gap=40)
segs.insert(1, Segment(segs[0].timestamp_ms + 2000, "This sentence is never spoken."))
r = check(segs, sp)
expect(r.segments[1].status == Status.EXTRA_WORD, "EXTRA WORD, got " + r.segments[1].status.value)
expect(r.segments[0].status == Status.MATCH and r.segments[2].status == Status.MATCH, "neighbours unharmed")

scenario("the same sentence with plenty of room (long pause) -> only UNCERTAIN, the recognizer may have missed it")
segs, sp = chain([("First line here today.", "First line here today."), ("Last line is here now.", "Last line is here now.")], gap=6000)
segs.insert(1, Segment(segs[0].timestamp_ms + 3000, "This sentence is never spoken."))
r = check(segs, sp)
expect(r.segments[1].status == Status.UNCERTAIN, "UNCERTAIN, got " + r.segments[1].status.value)

scenario("repeated phrases are not confused")
segs, sp = chain([("Thank you so much.", "Thank you so much."), ("Thank you so much.", "Thank you so much."), ("See you next time.", "See you next time.")])
r = check(segs, sp)
expect(all(x.status == Status.MATCH for x in r.segments), "all MATCH")
expect([x.timestamp.actual_ms for x in r.segments] == [x.timestamp_ms for x in segs], "each starts where it was stamped")

scenario("Hindi")
sp_ok = speak("नमस्ते दोस्तों आज हम बात करेंगे", 1000)
r = check([Segment(1000, "नमस्ते दोस्तों आज हम बात करेंगे")], sp_ok)
expect(r.segments[0].status == Status.MATCH, "Hindi match")
r = check([Segment(1000, "नमस्ते दोस्तों आज हम बात करेंगे")], speak("नमस्ते दोस्तों आज हम चर्चा करेंगे", 1000))
expect(r.segments[0].status == Status.TEXT_MISMATCH and r.segments[0].issues[0].transcript_text == "बात"
       and r.segments[0].issues[0].audio_text == "चर्चा", "Hindi mismatch बात -> चर्चा")

scenario("every timestamp 3 s early")
segs, sp = chain([("Welcome back to the channel.", "Welcome back to the channel."), ("Today we look at the new phone.", "Today we look at the new phone."),
                  ("It has a great camera.", "It has a great camera.")], start=10000)
r = check([Segment(x.timestamp_ms - 3000, x.text) for x in segs], sp)
expect(all(x.status == Status.TIMESTAMP_ERROR and x.timestamp.diff_ms == 3000 for x in r.segments), "all +3.000")

scenario("whole-second timestamps: +-1 s is allowed, 3 s is not")
segs, sp = chain([("alpha beta gamma delta.", "alpha beta gamma delta."), ("epsilon zeta eta theta.", "epsilon zeta eta theta."),
                  ("iota kappa lambda sigma.", "iota kappa lambda sigma.")], start=2400, gap=1500)
rounded = [Segment(round(x.timestamp_ms / 1000) * 1000, x.text) for x in segs]
r = check(rounded, sp)
expect(r.whole_second_timestamps and all(x.timestamp.tolerance_ms == 1000 for x in r.segments), "whole seconds detected, tolerance 1000")
expect(all(x.status == Status.MATCH for x in r.segments), "rounding to the second is fine")
r = check([Segment(x.timestamp_ms - 3000 if x.timestamp_ms >= 3000 else x.timestamp_ms + 0, x.text) for x in rounded], sp)
expect(any(x.status == Status.TIMESTAMP_ERROR for x in r.segments), "3 s off still an error")

scenario("one unscripted passage stays in ONE segment")
segs = [Segment(4000, "Let us begin the lesson."), Segment(12000, "That is all for today.")]
sp = speak("Let us begin the lesson.", 4000) + speak("by the way subscribe to my channel please", 7000) + speak("That is all for today.", 12000)
r = check(segs, sp)
holders = [x for x in r.segments if any(w.kind == Status.MISSING_WORD for w in x.issues)]
expect(len(holders) == 1, "exactly one segment holds the passage")
expect(holders[0].issues[0].audio_text == "by the way subscribe to my channel please", "all 8 words together")

scenario("a long pause inside the unscripted speech lets it be shared")
segs = [Segment(4000, "Let us begin the lesson."), Segment(20000, "That is all for today.")]
sp = (speak("Let us begin the lesson.", 4000) + speak("by the way", 7000) + speak("one more thing", 15000) + speak("That is all for today.", 20000))
r = check(segs, sp)
expect(all(any(w.kind == Status.MISSING_WORD for w in x.issues) for x in r.segments), "both segments got one remark")

scenario("a stutter is only a doubt, with its own reason")
r = check([Segment(0, "I went to the market yesterday.")], speak("I went to the the market yesterday.", 0))
expect(r.segments[0].status == Status.UNCERTAIN and "stutter" in r.segments[0].reason, "UNCERTAIN, stutter")

scenario("a segment that starts with a number still gets a start time")
r = check([Segment(3000, "2020 was a big year for everyone.")], speak("twenty twenty was a big year for everyone", 3000))
expect(r.segments[0].status == Status.MATCH and r.segments[0].timestamp.verifiable and r.segments[0].timestamp.actual_ms == 3000, "MATCH, verifiable, 3.000")

scenario("a replaced first word still locates the start")
r = check([Segment(5000, "Okay let us begin the session today.")], speak("Alright let us begin the session today", 8000))
s = r.segments[0]
expect(s.status == Status.TEXT_MISMATCH and s.timestamp.actual_ms == 8000 and s.timestamp.diff_ms == 3000, "mismatch on word 1 and start at 8.000")

scenario("a skipped first word that WAS spoken is allowed for in the start time")
sp = speak("Hello", 7000, conf=0.3) + speak("everyone welcome back to the show", 7420)
r = check([Segment(7000, "Hello everyone welcome back to the show")], sp)
expect(r.segments[0].timestamp.actual_ms is not None and abs(r.segments[0].timestamp.actual_ms - 7000) <= 400, "start within 0.4 s of 7.000")

scenario("speech right after the last line is reported, speech far away is not")
segs = [Segment(1000, "That is all for today.")]
r = check(segs, speak("That is all for today.", 1000) + speak("thank you", 3300))
expect(r.segments[0].status == Status.MISSING_WORD and r.segments[0].issues[0].audio_text == "thank you", "closing words reported")
r = check(segs, speak("That is all for today.", 1000) + speak("thank you", 30000))
expect(r.segments[0].status == Status.MATCH, "a remark 30 s later is not this line's business")

scenario("a line with no words")
r = check([Segment(0, "..."), Segment(2000, "Hello there friend.")], speak("Hello there friend.", 2000))
expect(r.segments[0].status == Status.UNCERTAIN and "no words" in r.segments[0].reason, "empty line UNCERTAIN")
expect(r.segments[1].status == Status.MATCH, "next line fine")

scenario("nothing recognised at all")
r = check([Segment(0, "Hello there friend."), Segment(3000, "How are you today.")], [])
expect(all(x.status == Status.UNCERTAIN for x in r.segments), "no accusations without any audio words")

scenario("results do not depend on earlier calls (word ids are per call)")
base_segs, base_sp = chain([("The help desk was closed.", "The held desk was closed.")])
before = [(w.kind, w.transcript_text, w.audio_text) for w in check(base_segs, base_sp).segments[0].issues]
check([Segment(0, "alpha beta")], speak("alpha gamma", 0))
check([Segment(0, "zebra yak")], speak("zebra xylophone", 0))
after = [(w.kind, w.transcript_text, w.audio_text) for w in check(base_segs, base_sp).segments[0].issues]
expect(before == after, "same answer before and after other calls")

scenario("tokenizer details")
expect([d for d, _ in split_words("Don't stop-believing [music] 1,000 times!")] == ["Don't", "stop", "believing", "1,000", "times"], "split_words display")
expect([n for _, n in split_words("Don't stop-believing [music] 1,000 times!")] == ["dont", "stop", "believing", "1000", "times"], "split_words norm")
expect([n for _, n in split_words("Q&A")] == ["q", "and", "a"], "ampersand is 'and'")
expect([n for _, n in split_words("It costs $5 and 10%")] == ["it", "costs", "5", "dollars", "and", "10", "percent"], "currency and percent spelled out")

scenario("settings: a tighter tolerance and fillers kept")
segs = [Segment(5000, "alpha beta gamma delta epsilon zeta")]
r = check(segs, speak("alpha beta gamma delta epsilon zeta", 5300), Settings(timestamp_tolerance_ms=200))
expect(r.segments[0].status == Status.TIMESTAMP_ERROR and r.segments[0].timestamp.diff_ms == 300, "0.3 s off is an error at 0.2 s tolerance")
r = check(segs, speak("alpha beta gamma delta epsilon zeta", 5300), Settings(timestamp_tolerance_ms=500))
expect(r.segments[0].status == Status.MATCH, "and fine at 0.5 s")

scenario("scale: one hour, 600 segments, 12 wrong words")
random.seed(7)
vocab = ["time", "people", "water", "light", "house", "world", "school", "family", "story", "music", "night", "paper", "green", "small",
         "happy", "river", "stone", "cloud", "market", "garden"]
lines = []
for i in range(600):
    n = random.randint(10, 20)
    w = [random.choice(vocab) + str(random.randint(0, 40)) for _ in range(n)]
    au = list(w)
    if i % 50 == 7:
        au[3] = "zzz"
    lines.append((" ".join(w), " ".join(au)))
segs, sp = chain(lines)
t0 = time.time()
r = check(segs, sp)
dt = time.time() - t0
expect(r.count(Status.TEXT_MISMATCH) == 12 and r.count(Status.MATCH) == 588, "12 mismatches found, 588 match (got %d/%d)" % (r.count(Status.TEXT_MISMATCH), r.count(Status.MATCH)))
expect(dt < 20, "fast enough (%.1fs)" % dt)

scenario("the banded DP (used for gaps too big for the exact one) agrees with the exact DP")
random.seed(5)
words = [random.choice(vocab) + str(random.randint(0, 3000)) for _ in range(500)]
spoken_words = [("zq" + w) if k % 3 == 1 else w for k, w in enumerate(words)]        # every third word wrong: no 3-word anchors survive
segs, sp = chain([(" ".join(words[k:k + 10]), " ".join(spoken_words[k:k + 10])) for k in range(0, 500, 10)])
exact = check(segs, sp)
saved = (checker.MAX_CELLS, checker.BAND)
checker.MAX_CELLS, checker.BAND = 1000, 40
banded = check(segs, sp)
checker.MAX_CELLS, checker.BAND = saved
expect([x.status for x in exact.segments] == [x.status for x in banded.segments], "same statuses with the band")
expect(exact.word_matched == banded.word_matched and exact.word_matched > 300, "same matched-word count (%d)" % exact.word_matched)

scenario("a gap that is too big even for the band is left unpaired instead of using all memory")
saved = (checker.MAX_CELLS, checker.BAND, checker.MAX_BAND_CELLS)
checker.MAX_CELLS, checker.BAND, checker.MAX_BAND_CELLS = 100, 5, 1000
r = check(segs, sp)
checker.MAX_CELLS, checker.BAND, checker.MAX_BAND_CELLS = saved
expect(all(x.status == Status.UNCERTAIN or x.status == Status.EXTRA_WORD for x in r.segments), "no false accusations, got " + str({x.status.value for x in r.segments}))

print()
if FAILS:
    print("%d FAILED" % len(FAILS))
    sys.exit(1)
print("all scenarios passed")
