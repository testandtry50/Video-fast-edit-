"""
Python mirror of app/src/main/java/com/videoslidemaker/app/model/PreviewSpeed.kt.

The Kotlin could not be compiled where it was written, so the maths was written here first and
checked (run_tests.py); PreviewSpeedTest.kt asserts the same numbers, and the first `Build` on
GitHub runs it for real.

Kotlin's roundToInt() rounds ties towards +infinity, so round_half_up() is used for it.
"""
import math

MIN = 0.25
MAX = 4.0
NORMAL = 1.0
PRESETS = [0.25, 0.5, 0.75, 1.0, 1.25, 1.5, 2.0, 3.0]
CYCLE = [0.5, 1.0, 1.5, 2.0, 3.0]
LOG_RANGE = math.log(MAX / MIN)


def round_half_up(x):
    return int(math.floor(x + 0.5))


def snap(speed):
    if speed != speed:  # NaN
        return NORMAL
    clamped = min(max(speed, MIN), MAX)
    return round_half_up(clamped * 20.0) / 20.0


def same(a, b):
    return abs(a - b) < 0.001


def nudge(speed, delta):
    return snap(speed + delta)


def cycle(speed):
    s = snap(speed)
    for c in CYCLE:
        if c > s + 0.001:
            return c
    return CYCLE[0]


def number(speed):
    hundredths = round_half_up(snap(speed) * 100.0)
    whole, fraction = divmod(hundredths, 100)
    if fraction == 0:
        return str(whole)
    if fraction % 10 == 0:
        return "%d.%d" % (whole, fraction // 10)
    return "%d.%02d" % (whole, fraction)


def label(speed):
    return number(speed) + "\u00d7"


def spoken(speed):
    return "Normal speed" if same(snap(speed), NORMAL) else number(speed) + " times normal speed"


def to_slider(speed):
    s = NORMAL if speed != speed else min(max(speed, MIN), MAX)
    return min(max(math.log(s / MIN) / LOG_RANGE, 0.0), 1.0)


def from_slider(position):
    t = 0.5 if position != position else min(max(position, 0.0), 1.0)
    return snap(MIN * math.exp(t * LOG_RANGE))


def watch_seconds(media_sec, speed):
    return media_sec / snap(speed)


def shortest(durations):
    return min(durations) if durations else 0.0


def count_below(durations, threshold_sec, speed):
    s = snap(speed)
    return sum(1 for d in durations if d / s < threshold_sec)


def format_short(seconds):
    if seconds < 0.05:
        return "under 0.1 s"
    tenths = round_half_up(seconds * 10.0)
    whole, fraction = divmod(tenths, 10)
    return "%d s" % whole if fraction == 0 else "%d.%d s" % (whole, fraction)


def fallback_ladder(wanted):
    w = snap(wanted)
    out = [w]
    if w > NORMAL:
        out += [s for s in (2.0, 1.5, 1.25) if s < w]
        out.append(NORMAL)
    elif w < NORMAL:
        out += [s for s in (0.5, 0.75) if s > w]
        out.append(NORMAL)
    return out


def tts_rate(base_rate, speed):
    return min(max(base_rate * snap(speed), 0.1), 4.0)


def drift_tolerance_sec(speed):
    return 0.12 * max(1.0, speed)


def scaled_ms(ms, speed):
    if ms <= 0:
        return 0
    return max(round_half_up(ms / snap(speed)), 1)


def look_ahead(speed):
    return min(max(int(2.0 * math.ceil(snap(speed))), 2), 8)
