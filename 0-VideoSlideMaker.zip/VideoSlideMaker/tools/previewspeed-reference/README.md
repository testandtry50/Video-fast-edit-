# Preview speed - reference

`preview_speed.py` is a Python copy of `app/src/main/java/com/videoslidemaker/app/model/PreviewSpeed.kt`
(speeds, the log-scale slider, labels, watch time, fall-backs when a phone refuses a speed, the voice rate,
fade lengths). `run_tests.py` checks it; `PreviewSpeedTest.kt` asserts the same numbers in Kotlin.

    python3 run_tests.py

The Kotlin could not be compiled where it was written, so the numbers were settled here first.
