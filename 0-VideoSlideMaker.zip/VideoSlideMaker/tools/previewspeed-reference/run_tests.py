"""Runs the same checks as PreviewSpeedTest.kt against the Python mirror: python3 run_tests.py"""
import math
import preview_speed as ps


def close(a, b, tol=1e-4):
    assert abs(a - b) <= tol, "%r != %r" % (a, b)


# ---- snap / same / nudge
close(ps.snap(1.02), 1.0)
close(ps.snap(1.03), 1.05)
close(ps.snap(0.1), 0.25)
close(ps.snap(9.0), 4.0)
close(ps.snap(float("nan")), 1.0)
close(ps.snap(0.25), 0.25)
close(ps.snap(4.0), 4.0)
assert ps.same(1.0, 1.0004) and not ps.same(1.0, 1.05)
close(ps.nudge(1.0, 0.05), 1.05)
close(ps.nudge(1.0, -0.25), 0.75)
close(ps.nudge(0.25, -0.25), 0.25)
close(ps.nudge(4.0, 0.25), 4.0)
close(ps.nudge(2.95, 0.05), 3.0)

# ---- the speed button next to play
for start, want in [(0.5, 1.0), (1.0, 1.5), (1.5, 2.0), (2.0, 3.0), (3.0, 0.5), (0.25, 0.5), (0.75, 1.0),
                    (1.3, 1.5), (2.5, 3.0), (4.0, 0.5)]:
    close(ps.cycle(start), want)
x = 0.5
for _ in range(5):
    x = ps.cycle(x)
close(x, 0.5)
assert all(c in ps.PRESETS for c in ps.CYCLE), "every stop of the button is also a one-tap speed in the card"

# ---- presets
assert ps.PRESETS == sorted(ps.PRESETS) and 1.0 in ps.PRESETS
assert all(ps.MIN <= p <= ps.MAX for p in ps.PRESETS)
assert all(abs(ps.snap(p) - p) < 1e-9 for p in ps.PRESETS)
assert len({ps.label(p) for p in ps.PRESETS}) == len(ps.PRESETS)

# ---- labels
expected = {1.0: "1\u00d7", 0.5: "0.5\u00d7", 0.25: "0.25\u00d7", 0.75: "0.75\u00d7", 1.25: "1.25\u00d7",
            1.5: "1.5\u00d7", 2.0: "2\u00d7", 2.5: "2.5\u00d7", 3.0: "3\u00d7", 4.0: "4\u00d7", 1.05: "1.05\u00d7"}
for speed, text in expected.items():
    assert ps.label(speed) == text, (speed, ps.label(speed), text)
assert ps.spoken(1.0) == "Normal speed"
assert ps.spoken(2.0) == "2 times normal speed"
assert ps.spoken(0.5) == "0.5 times normal speed"

# ---- slider (log scale: normal speed in the middle)
close(ps.to_slider(1.0), 0.5)
close(ps.to_slider(0.25), 0.0)
close(ps.to_slider(4.0), 1.0)
close(ps.to_slider(0.5), 0.25)
close(ps.to_slider(2.0), 0.75)
close(ps.from_slider(0.0), 0.25)
close(ps.from_slider(1.0), 4.0)
close(ps.from_slider(0.5), 1.0)
close(ps.from_slider(0.25), 0.5)
close(ps.from_slider(0.75), 2.0)
close(ps.from_slider(float("nan")), 1.0)
close(ps.from_slider(-3.0), 0.25)
close(ps.from_slider(7.0), 4.0)
for p in ps.PRESETS:
    close(ps.from_slider(ps.to_slider(p)), p)
last = -1.0
steps = 0
for i in range(0, 201):
    v = ps.from_slider(i / 200.0)
    assert v >= last - 1e-9, "slider went backwards"
    assert ps.MIN - 1e-9 <= v <= ps.MAX + 1e-9
    assert abs(v * 20 - round(v * 20)) < 1e-6, "not a multiple of 0.05: %r" % v
    last = v
    steps += 1
assert steps == 201
prev = -1.0
for k in range(5, 81):  # every 0.05 step from 0.25 to 4.0
    sp = k / 20.0
    pos = ps.to_slider(sp)
    assert pos > prev
    prev = pos
    close(ps.from_slider(pos), sp)  # a speed put on the slider and read back is the same speed

# ---- watch time
close(ps.watch_seconds(600.0, 2.0), 300.0)
close(ps.watch_seconds(600.0, 0.5), 1200.0)
close(ps.watch_seconds(600.0, 1.0), 600.0)
close(ps.watch_seconds(100.0, 1.25), 80.0)

# ---- shortest / quick photos
d = [3.0, 0.8, 2.0, 0.5]
close(ps.shortest(d), 0.5)
close(ps.shortest([]), 0.0)
assert ps.count_below(d, 1.0, 1.0) == 2
assert ps.count_below(d, 1.0, 2.0) == 2
assert ps.count_below(d, 1.0, 3.0) == 3
assert ps.count_below(d, 1.0, 0.5) == 0
assert ps.count_below([], 1.0, 2.0) == 0

# ---- short times
assert ps.format_short(0.01) == "under 0.1 s"
assert ps.format_short(0.04) == "under 0.1 s"
assert ps.format_short(0.4) == "0.4 s"
assert ps.format_short(0.8) == "0.8 s"
assert ps.format_short(3.0) == "3 s"
assert ps.format_short(2.96) == "3 s"
assert ps.format_short(9.94) == "9.9 s"
assert ps.format_short(12.0) == "12 s"

# ---- when a phone refuses a speed
assert ps.fallback_ladder(1.0) == [1.0]
assert ps.fallback_ladder(2.0) == [2.0, 1.5, 1.25, 1.0]
assert ps.fallback_ladder(3.0) == [3.0, 2.0, 1.5, 1.25, 1.0]
assert ps.fallback_ladder(4.0) == [4.0, 2.0, 1.5, 1.25, 1.0]
assert ps.fallback_ladder(1.5) == [1.5, 1.25, 1.0]
assert ps.fallback_ladder(1.25) == [1.25, 1.0]
assert ps.fallback_ladder(0.5) == [0.5, 0.75, 1.0]
assert ps.fallback_ladder(0.25) == [0.25, 0.5, 0.75, 1.0]
assert ps.fallback_ladder(0.75) == [0.75, 1.0]
for w in [x / 20.0 for x in range(5, 81)]:
    ladder = ps.fallback_ladder(w)
    assert ladder[0] == ps.snap(w) and len(set(ladder)) == len(ladder)
    assert ladder[-1] == 1.0
    gaps = [abs(a - 1.0) for a in ladder]
    assert gaps == sorted(gaps, reverse=True), "ladder must move towards normal speed: %r" % ladder

# ---- the phone's voice
close(ps.tts_rate(0.95, 1.0), 0.95)
close(ps.tts_rate(0.95, 2.0), 1.9)
close(ps.tts_rate(0.95, 0.25), 0.2375)
close(ps.tts_rate(1.0, 4.0), 4.0)
close(ps.tts_rate(2.0, 4.0), 4.0)
close(ps.tts_rate(0.1, 0.25), 0.1)

# ---- keeping photos with the recording
close(ps.drift_tolerance_sec(1.0), 0.12, 1e-9)
close(ps.drift_tolerance_sec(0.5), 0.12, 1e-9)
close(ps.drift_tolerance_sec(2.0), 0.24, 1e-9)
close(ps.drift_tolerance_sec(3.0), 0.36, 1e-9)
close(ps.drift_tolerance_sec(4.0), 0.48, 1e-9)

# ---- fades
assert ps.scaled_ms(350, 1.0) == 350
assert ps.scaled_ms(350, 2.0) == 175
assert ps.scaled_ms(350, 0.5) == 700
assert ps.scaled_ms(300, 4.0) == 75
assert ps.scaled_ms(150, 3.0) == 50
assert ps.scaled_ms(350, 3.0) == 117
assert ps.scaled_ms(0, 2.0) == 0
assert ps.scaled_ms(1, 4.0) == 1

# ---- loading ahead
assert [ps.look_ahead(s) for s in (0.25, 1.0, 1.25, 2.0, 3.0, 4.0)] == [2, 2, 4, 4, 6, 8]

# ---- clock arithmetic used by AppViewModel.previewFrame (position = anchor + real seconds * speed)
def position(anchor, real_sec, speed):
    return anchor + real_sec * speed
close(position(10.0, 3.0, 2.0), 16.0)
close(position(10.0, 3.0, 0.5), 11.5)
# changing speed mid-way re-anchors at the current position (previewSetSpeed with no sound)
anchor = position(10.0, 3.0, 2.0)          # 16.0 after 3 s at 2x
close(position(anchor, 2.0, 0.5), 17.0)    # then 2 s at 0.5x

print("all PreviewSpeed reference checks passed")
