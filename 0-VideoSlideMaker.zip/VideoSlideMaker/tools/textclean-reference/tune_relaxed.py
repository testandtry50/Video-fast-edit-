"""Searches for a better 'relaxed' gate (no checking). Positives = captions the NORMAL gate misses or not;
negatives = hard text-free boxes. Seeds differ from the ones the final numbers are reported on."""
import sys, itertools, pickle
from multiprocessing import Pool
import numpy as np
import textmask as tm
import synth_text as st
import evaluate as ev
tm._FAST_LABEL = True

def build():
    rng = np.random.RandomState(909)
    cases = []   # (win, region, is_text, normal_found)
    for i in range(96):
        kind = ["source", "blobs", "smooth", "natural", "busy", "stripes"][i % 6]
        style = st.STYLES[i % 6]
        size = int(rng.choice((30, 54, 80)))
        bg = st.background(kind, rng)
        if style == "dark_on_light":
            bg = (255 - (255 - bg.astype(np.float32)) * 0.35).astype(np.uint8)
        short = i % 3 == 0
        text = ["Yes.", "No way!", "Run!", "Okay"][rng.randint(4)] if short else st.LATIN[rng.randint(len(st.LATIN))]
        frame, glyph, core = st.render(bg, text, size, style, st.FONT_LATIN, cy=int(st.H * rng.uniform(0.15, 0.92)))
        if rng.rand() < 0.5:
            frame = ev.degrade(frame, rng)
        box = st.user_box(glyph, size, ("tight", "band")[i % 2], rng, glyph.shape)
        _, win, region = ev.window(frame, box)
        cases.append((win, region, True))
    for i in range(144):
        kind = ["source", "blobs", "smooth", "natural", "busy", "stripes"][i % 6]
        bg = st.natural(rng, st.NATURAL[(i // 6) % len(st.NATURAL)]) if kind == "natural" else st.background(kind, rng)
        if rng.rand() < 0.5:
            bg = ev.degrade(bg, rng)
        size = int(rng.choice((30, 54, 80)))
        cy = int(st.H * rng.uniform(0.15, 0.92)); bh = int(size * rng.uniform(1.2, 2.6)); bw = rng.uniform(0.5, 0.92)
        x0 = int(st.W * (1 - bw) / 2)
        box = (x0, max(0, cy - bh // 2), st.W - x0, min(st.H, cy + bh // 2))
        _, win, region = ev.window(bg, box)
        cases.append((win, region, False))
    return cases

def evaluate(cases, gate):
    tm.RELAXED = dict(min_runs=gate[0], min_ink=gate[1], min_pair=gate[2], t_scale=gate[3])
    tp = fp = nt = nf = 0
    for win, region, is_text in cases:
        found = tm.detect(win, region, relaxed=True) is not None
        if is_text:
            nt += 1; tp += found
        else:
            nf += 1; fp += found
    return tp / nt, fp / nf


if __name__ == "__main__":
    cases = build()
    print("cases built:", sum(c[2] for c in cases), "captions,", sum(not c[2] for c in cases), "text-free boxes", flush=True)
    print(" gate (runs, ink, pair, t_scale)      captions found   text-free boxes wrongly found", flush=True)
    grid = [(3, 45, 0.0, 0.6), (4, 70, 0.25, 0.7), (4, 80, 0.3, 0.8), (5, 90, 0.3, 0.8), (3, 70, 0.3, 0.7), (4, 100, 0.35, 0.9)]
    for g in grid:
        tp, fp = evaluate(cases, g)
        print(f"  {str(g):32s}   {tp:6.1%}            {fp:6.1%}", flush=True)
