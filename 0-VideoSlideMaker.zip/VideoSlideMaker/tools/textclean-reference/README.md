# Text / subtitle finder - reference and measurements

The Python version of the finder that the app's cleaner uses for **subtitles and other text**
(`app/src/main/java/com/videoslidemaker/app/logoclean/TextMask.kt` is a port, same steps and constants).
It was designed and measured here first, the same way as `../logoclean-reference/` (the logo finder).

Needs: `python3`, `numpy`, `opencv-python`, `Pillow` (with raqm for Hindi), `scipy`, `scikit-image` (its bundled sample photos are the hard test pictures).

| File | What it is |
|---|---|
| `textmask.py` | the finder (read its header: four steps in plain words) |
| `synth_text.py` | builds test frames with text of known shape: 6 caption styles, Latin + Hindi, 6 kinds of background, real photographs |
| `evaluate.py` | the measurements quoted in the README (fresh seeds, JPEG'd / softened frames). About 15 min. `python3 evaluate.py quick` for a taste |
| `tune_relaxed.py` | how the "Everywhere in the box" setting was chosen (37.7 % -> 5.8 % false alarms on the hardest boxes) |
| `mirror_scenarios.py` | the exact scenes the Kotlin unit tests (`TextMaskTest.kt`) use, run through the reference so the numbers in Kotlin are measured |
| `kotlin_transliteration_check.py` | the index-heavy Kotlin functions written out statement by statement in Python and compared with the reference (0 mismatches) - a check of the port without a Kotlin compiler |
| `demo.py` | makes `sample/text_cleaner_before_after.png` |
