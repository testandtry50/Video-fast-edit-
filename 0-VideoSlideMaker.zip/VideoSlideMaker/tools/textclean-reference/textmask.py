"""
Reference implementation of the text / subtitle finder used by the cleaner.

Designed, run and measured first (see evaluate.py); the Kotlin code in
app/src/main/java/com/videoslidemaker/app/logoclean/TextMask.kt is a port of it (same steps, same constants).

Why a second finder?  The logo finder (tools/logoclean-reference/logoclean.py) works because a watermark is the same
in every photo. A SUBTITLE is different in every photo, so there is nothing to stack. What IS the same about text is
its look: thin strokes that are much brighter or much darker than the picture right around them, flat in colour,
many of them side by side along a line. So the finder works on ONE photo at a time:

  1. THIN-STROKE RESPONSE  Grey-scale "top-hat": the picture minus its morphological opening (bright thin things
                           such as white letters) and its closing minus the picture (dark thin things such as the
                           black outline of a subtitle). Large objects and smooth shading give ~0.
  2. HYSTERESIS            Strong pixels start a letter; weaker pixels (anti-aliased edges, outline fringe) are kept
                           only when they touch a strong one. Holes inside letters are filled.
  3. IS IT TEXT?           Three cheap checks that real photos fail and captions pass: (a) the busiest rows cross many
                           separate strokes, (b) the ink is high-contrast, (c) bright strokes sit next to dark ones
                           (letter + outline, letter + gap). If not text: "nothing here", the photo is left alone
                           (the caption is simply not on screen in that photo).
  4. TWO MASKS             REMOVE uses the tight letter mask (a little grown for the anti-aliased halo) so only the
                           letters are repainted. BLUR uses the same mask merged into word / line shapes, so the
                           blur reads as one smudge, not as ghost letters.

Only pixels inside the user's box can ever be changed. The rest of the window is only read: to learn how busy the
picture is, and as the colours the repaint copies from.
"""
import numpy as np

_FAST_LABEL = False   # evaluate.py switches this on for speed; the loop in label4 is the reference (and what Kotlin ports)

# ----------------------------------------------------------------------------- constants (mirrored in Kotlin)
R_FRAC = 0.085        # stroke radius (the structuring element is 2r+1 wide) as a share of the box height ...
R_MIN, R_MAX = 2, 14  # ... clamped to this range (pixels)
T_STRONG = 46         # a letter pixel differs from its surroundings by at least this much (0..255 luma) ...
T_WEAK_FRAC = 0.45    # ... and its anti-aliased fringe by at least this share of it
RING_PERCENTILE = 92  # "how busy is the picture" = this percentile of the thin-stroke response OUTSIDE the box
RING_MIN_PX = 200
BUSY_GAIN = 1.5       # strong threshold = max(T_STRONG, BUSY_GAIN * busy)
WEAK_BUSY_GAIN = 1.1  # ... and the fringe threshold never goes below this many times the clutter level
MIN_STRONG_PX = 12
MAX_COVER = 0.75      # a box hugging the text is mostly letters; more than 75 % ink is texture
MIN_COVER = 0.004
GROW_FRAC = 0.30      # the tight mask grows by this share of r (anti-aliased halo, outline fringe)
GAP_FRAC_X = 1.6      # blur mask: merge letters across gaps of up to this many r horizontally ...
GAP_FRAC_Y = 0.8      # ... and vertically
PAIR_R = 3            # "next to" = within this many pixels

# What a box has to look like to count as text. NORMAL = "only where text is found"; RELAXED = "everywhere in the box":
# short or faint captions too, at the price of sometimes repainting texture in a photo that has no caption
# (measured: 96 % of captions found, 5.8 % of the very hardest text-free boxes - stars, gravel, stripes - triggered;
# the first, looser setting (3, 45, 0, 0.6) triggered on 37.7 % of them, see tune_relaxed.py).
NORMAL = dict(min_runs=6, min_ink=110, min_pair=0.45, t_scale=1.0)
RELAXED = dict(min_runs=3, min_ink=70, min_pair=0.30, t_scale=0.7)


# ----------------------------------------------------------------------------- basic ops
def to_luma(rgb):
    rgb = rgb.astype(np.float32)
    return rgb[..., 0] * 0.299 + rgb[..., 1] * 0.587 + rgb[..., 2] * 0.114


def _filter_axis(a, r, axis, take_min):
    """Min (or max) over [i-r, i+r] along one axis; the border repeats. van Herk / Gil-Werman: the work per
    element does not depend on r (blocks of k = 2r+1: a running min from the block start, a running min from the
    block end, and every window is the min of one of each)."""
    if r <= 0:
        return a.copy()
    f = np.minimum if take_min else np.maximum
    x = a if axis == 1 else a.T
    w = x.shape[1]
    k = 2 * r + 1
    m = w + 2 * r
    idx = np.clip(np.arange(m) - r, 0, w - 1)
    p = x[:, idx]
    g = p.copy()
    hh = p.copy()
    for s in range(0, m, k):
        e = min(s + k, m)
        for j in range(s + 1, e):
            g[:, j] = f(g[:, j - 1], p[:, j])
        for j in range(e - 2, s - 1, -1):
            hh[:, j] = f(hh[:, j + 1], p[:, j])
    out = f(hh[:, :w], g[:, k - 1:k - 1 + w])
    return out if axis == 1 else out.T


def erode(a, r):
    return _filter_axis(_filter_axis(a, r, 1, True), r, 0, True)


def dilate(a, r):
    return _filter_axis(_filter_axis(a, r, 1, False), r, 0, False)


def max_filter_bool(b, r):
    return dilate(b.astype(np.uint8), r).astype(bool) if r > 0 else b.copy()


def _dilate_rect(b, rx, ry):
    a = b.astype(np.uint8)
    return _filter_axis(_filter_axis(a, rx, 1, False), ry, 0, False).astype(bool)


def _erode_rect(b, rx, ry):
    a = b.astype(np.uint8)
    return _filter_axis(_filter_axis(a, rx, 1, True), ry, 0, True).astype(bool)


def close_rect(b, rx, ry):
    """Grow by (rx, ry) then shrink by the same: merges things closer than that, keeps the outer shape."""
    return _erode_rect(_dilate_rect(b, rx, ry), rx, ry)


def label4(b):
    """4-connected components. Returns (labels int32, count). 0 = background."""
    if _FAST_LABEL:
        from scipy import ndimage
        lab, n = ndimage.label(b)          # default structure = 4-connectivity, same as the loop below
        return lab.astype(np.int32), int(n)
    h, w = b.shape
    lab = np.zeros((h, w), np.int32)
    n = 0
    flat = b.ravel()
    labf = lab.ravel()
    stack = []
    for start in range(h * w):
        if not flat[start] or labf[start]:
            continue
        n += 1
        labf[start] = n
        stack.append(start)
        while stack:
            i = stack.pop()
            x = i % w
            y = i // w
            if x > 0 and flat[i - 1] and not labf[i - 1]:
                labf[i - 1] = n; stack.append(i - 1)
            if x < w - 1 and flat[i + 1] and not labf[i + 1]:
                labf[i + 1] = n; stack.append(i + 1)
            if y > 0 and flat[i - w] and not labf[i - w]:
                labf[i - w] = n; stack.append(i - w)
            if y < h - 1 and flat[i + w] and not labf[i + w]:
                labf[i + w] = n; stack.append(i + w)
    return lab, n


def fill_holes(b):
    """Everything not reachable from the border through background pixels becomes foreground."""
    h, w = b.shape
    lab, n = label4(~b)
    touching = set()
    touching.update(np.unique(lab[0, :]).tolist()); touching.update(np.unique(lab[h - 1, :]).tolist())
    touching.update(np.unique(lab[:, 0]).tolist()); touching.update(np.unique(lab[:, w - 1]).tolist())
    inner = np.ones(n + 1, bool)
    inner[0] = False
    for t in touching:
        inner[t] = False
    return b | inner[lab]


def hist_percentile(values, pct):
    """Percentile of non-negative float [values] read from a 256-bin histogram (floor of each value, capped 255):
    the smallest bin whose running count reaches ceil(pct/100 * n). Cheap, and identical in Kotlin."""
    if values.size == 0:
        return 0
    q = np.minimum(np.floor(values), 255).astype(np.int64)
    hist = np.bincount(q, minlength=256)
    need = int(np.ceil(pct / 100.0 * q.size))
    return int(np.searchsorted(np.cumsum(hist), max(need, 1)))


# ----------------------------------------------------------------------------- the finder
class TextResult:
    def __init__(self, mask, blur_mask, cover, r):
        self.mask = mask            # tight letter mask (REMOVE, BOTH)
        self.blur_mask = blur_mask  # words / lines merged (BLUR)
        self.cover = cover          # share of the box that is letter
        self.r = r


def stroke_radius(box_h_px):
    return int(min(R_MAX, max(R_MIN, int(np.floor(R_FRAC * box_h_px + 0.5)))))


def thin_response(luma, r):
    """(bright, dark): how much each pixel is a thin BRIGHT stroke (white letters) / a thin DARK stroke (an outline,
    black letters). Both are 0 on smooth areas and on anything wider than 2r+1."""
    er = erode(luma, r)
    op = dilate(er, r)
    di = dilate(luma, r)
    cl = erode(di, r)
    return np.maximum(luma - op, 0), np.maximum(cl - luma, 0)


def row_runs(m, region):
    """How many separate stretches the busiest rows of [m] have. A line of text crosses many strokes in one row
    (each letter has one to three); a lip line, a wire or an eyebrow crosses one or two."""
    prev = np.zeros((m.shape[0], 1), bool)
    shifted = np.concatenate([prev, m[:, :-1]], axis=1)
    per_row = (m & ~shifted).sum(axis=1)          # a run begins where a stroke pixel follows a non-stroke pixel
    rows = per_row[region.any(axis=1)]
    if rows.size == 0:
        return 0
    k = min(3, rows.size)
    return int(np.sort(rows)[-k])                 # the 3rd busiest row: ignores one noisy row, still sees a line


def detect(rgb, region, box_h_px=None, relaxed=False, debug=None):
    """rgb: HxWx3 window (0..255). region: bool HxW, where text may be (the user's box). Returns TextResult or None.
    [debug] (a dict) collects the numbers behind the decision."""
    dbg = debug if debug is not None else {}
    gate = RELAXED if relaxed else NORMAL
    ys, xs = np.nonzero(region)
    if ys.size == 0:
        dbg["why"] = "empty box"
        return None
    bh = int(ys.max() - ys.min() + 1) if box_h_px is None else box_h_px
    r = stroke_radius(bh)
    luma = to_luma(rgb)
    bright, dark = thin_response(luma, r)
    resp = np.maximum(bright, dark)
    ring = ~region
    if int(ring.sum()) >= RING_MIN_PX:
        busy = hist_percentile(resp[ring], RING_PERCENTILE)
    else:                                       # box fills the window (it touches the photo edges): read it inside
        busy = hist_percentile(resp[region], 20)
    resp[~region] = 0
    t_strong = max(T_STRONG * gate["t_scale"], BUSY_GAIN * busy)
    t_weak = max(T_WEAK_FRAC * t_strong, WEAK_BUSY_GAIN * busy)   # on a busy picture the fringe must clear the clutter
    dbg.update(r=r, busy=busy, t_strong=t_strong)
    strong = resp >= t_strong
    n_strong = int(strong.sum())
    dbg["n_strong"] = n_strong
    if n_strong < MIN_STRONG_PX:
        dbg["why"] = "no strong thin strokes"
        return None
    lab, n = label4(resp >= t_weak)
    keep = np.zeros(n + 1, bool)
    keep[np.unique(lab[strong])] = True
    keep[0] = False
    ink = keep[lab] & region
    ink = fill_holes(ink) & region               # thick fill enclosed by its outline, counters of o / e / a
    cover = float(ink.sum()) / float(region.sum())
    sb = (bright >= t_strong) & ink
    sd = (dark >= t_strong) & ink
    runs = max(row_runs(sb, region), row_runs(sd, region))
    ink_med = hist_percentile(resp[ink], 50) if ink.any() else 0
    near_d = max_filter_bool(sd, PAIR_R)
    near_b = max_filter_bool(sb, PAIR_R)
    pair = max(float((sb & near_d).sum()) / max(1, int(sb.sum())), float((sd & near_b).sum()) / max(1, int(sd.sum())))
    dbg.update(cover=cover, runs=runs, ink_med=ink_med, pair=pair)
    if cover < MIN_COVER:
        dbg["why"] = "too little ink"
        return None
    if cover > MAX_COVER:
        dbg["why"] = "too much ink (texture)"
        return None
    if runs < gate["min_runs"]:
        dbg["why"] = "not line-like"
        return None
    if ink_med < gate["min_ink"]:
        dbg["why"] = "too faint"
        return None
    if pair < gate["min_pair"]:
        dbg["why"] = "strokes not paired like letters"
        return None
    grow = max(1, int(np.floor(GROW_FRAC * r + 0.5)))
    tight = max_filter_bool(ink, grow) & region
    gx = max(1, int(np.floor(GAP_FRAC_X * r + 0.5)))
    gy = max(1, int(np.floor(GAP_FRAC_Y * r + 0.5)))
    blurm = close_rect(ink, gx, gy) & region     # letters merged into words / lines
    blurm = max_filter_bool(blurm, grow) & region
    return TextResult(tight, blurm, cover, r)
