"""Measures the text finder. Seeds here are NOT the ones the thresholds were tuned on.
   python3 evaluate.py            full run (about 2 minutes)
   python3 evaluate.py quick      a few cases"""
import sys, time
from collections import Counter, defaultdict
import numpy as np
import cv2
import textmask as tm
import synth_text as st
sys.path.insert(0, st.os.path.join(st.HERE, "..", "logoclean-reference"))
import logoclean as lc
import synth as lsynth

tm._FAST_LABEL = True
QUICK = len(sys.argv) > 1 and sys.argv[1] == "quick"
SHORT = ["Yes.", "No way!", "Run!", "Okay", "I know", "Hello", "Stop it"]


def psnr(a, b, m):
    d = (a.astype(np.float32) - b.astype(np.float32))[m]
    mse = float((d * d).mean()) if d.size else 0.0
    return 99.0 if mse < 1e-9 else 10 * np.log10(255.0 ** 2 / mse)


def degrade(img, rng):
    """What real video frames look like: slightly soft, a bit of JPEG."""
    out = img
    if rng.rand() < 0.6:
        out = cv2.GaussianBlur(out, (0, 0), rng.uniform(0.4, 0.9))
    return lsynth.jpeg(out, int(rng.randint(60, 92)))


def window(frame, box):
    wx0, wy0, wx1, wy1 = st.window_for(box, frame.shape[:2])
    win = frame[wy0:wy1, wx0:wx1]
    region = np.zeros(win.shape[:2], bool)
    region[box[1] - wy0:box[3] - wy0, box[0] - wx0:box[2] - wx0] = True
    return (wx0, wy0, wx1, wy1), win, region


def run_positive(bg, frame, glyph, core, box, relaxed=False):
    (wx0, wy0, wx1, wy1), win, region = window(frame, box)
    dbg = {}
    t0 = time.time()
    res = tm.detect(win, region, relaxed=relaxed, debug=dbg)
    out = {"found": res is not None, "secs": time.time() - t0, "why": dbg.get("why")}
    if res is None:
        return out
    g, c = glyph[wy0:wy1, wx0:wx1], core[wy0:wy1, wx0:wx1]
    m = res.mask
    out.update(recall_any=float((m & g).sum() / max(1, g.sum())), recall_core=float((m & c).sum() / max(1, c.sum())),
               area_ratio=float(m.sum() / max(1, g.sum())))
    truth = bg[wy0:wy1, wx0:wx1]
    near = cv2.dilate(g.astype(np.uint8), np.ones((9, 9), np.uint8)).astype(bool) & region
    out["psnr_none"] = psnr(win, truth, near)
    out["psnr_text"] = psnr(lc.inpaint(win, m), truth, near)
    out["psnr_box"] = psnr(lc.inpaint(win, region), truth, near)
    return out


def positives(seed, kinds, sizes, texts=None):
    rng = np.random.RandomState(seed)
    rows = []
    for kind in kinds:
        for style in st.STYLES:
            for size in sizes:
                for bk in ("tight", "band"):
                    bg = st.background(kind, rng)
                    if style == "dark_on_light":
                        bg = (255 - (255 - bg.astype(np.float32)) * 0.35).astype(np.uint8)
                    if texts:
                        text, font = texts[rng.randint(len(texts))], st.FONT_LATIN
                    elif rng.rand() < 0.3:
                        text, font = st.HINDI[rng.randint(len(st.HINDI))], st.FONT_DEVANAGARI
                    else:
                        text, font = st.LATIN[rng.randint(len(st.LATIN))], st.FONT_LATIN
                    cy = int(st.H * rng.uniform(0.15, 0.92))
                    frame, glyph, core = st.render(bg, text, size, style, font, cy=cy)
                    truth = st.render_truth(bg, text, size, style, font, cy=cy)   # only the letters go, a strip stays
                    if rng.rand() < 0.5:
                        frame = degrade(frame, rng)
                    box = st.user_box(glyph, size, bk, rng, glyph.shape)
                    r = run_positive(truth, frame, glyph, core, box)
                    r2 = run_positive(truth, frame, glyph, core, box, relaxed=True)
                    r.update(kind=kind, style=style, size=size, box=bk, hindi=font == st.FONT_DEVANAGARI, found_relaxed=r2["found"])
                    rows.append(r)
    return rows


def negatives_synth(seed, kinds, n):
    rng = np.random.RandomState(seed)
    rows = []
    for kind in kinds:
        for k in range(n):
            bg = st.background(kind, rng)
            if rng.rand() < 0.5:
                bg = degrade(bg, rng)
            size = int(rng.choice((30, 54, 80)))
            cy = int(st.H * rng.uniform(0.15, 0.92))
            box = (int(st.W * 0.04), max(0, cy - int(size * 1.2)), int(st.W * 0.96), min(st.H, cy + int(size * 1.2)))
            rows.append(neg_row(bg, box, kind))
    return rows


def negatives_natural(seed, per_image):
    rng = np.random.RandomState(seed)
    rows = []
    for name in st.NATURAL:
        for k in range(per_image):
            bg = st.natural(rng, name)
            if rng.rand() < 0.5:
                bg = degrade(bg, rng)
            size = int(rng.choice((30, 54, 80)))
            cy = int(st.H * rng.uniform(0.15, 0.92))
            bh = int(size * rng.uniform(1.2, 2.6))
            bw = rng.uniform(0.5, 0.92)
            x0 = int(st.W * (1 - bw) / 2)
            box = (x0, max(0, cy - bh // 2), st.W - x0, min(st.H, cy + bh // 2))
            rows.append(neg_row(bg, box, name))
    return rows


def neg_row(bg, box, tag):
    _, win, region = window(bg, box)
    return {"tag": tag, "found": tm.detect(win, region) is not None, "found_relaxed": tm.detect(win, region, relaxed=True) is not None}


def pct(x):
    return "%5.1f%%" % (100 * x)


def table(rows, key, label):
    groups = defaultdict(list)
    for r in rows:
        groups[r[key]].append(r)
    print("  %-16s  n   found  relaxed   recall  mask/text  PSNR before -> text mask | whole box" % label)
    for k, rs in groups.items():
        f = [r for r in rs if r["found"]]
        line = "  %-16s %3d  %s  %s" % (k, len(rs), pct(len(f) / len(rs)), pct(np.mean([r["found_relaxed"] for r in rs])))
        if f:
            line += "  %s  %5.2fx    %5.1f -> %5.1f dB       | %5.1f dB" % (
                pct(np.mean([r["recall_any"] for r in f])), np.mean([r["area_ratio"] for r in f]),
                np.mean([r["psnr_none"] for r in f]), np.mean([r["psnr_text"] for r in f]), np.mean([r["psnr_box"] for r in f]))
        print(line)


if __name__ == "__main__":
    t = time.time()
    kinds = ["source", "blobs", "smooth", "natural"] if QUICK else ["source", "blobs", "smooth", "natural", "busy", "stripes"]
    sizes = (54,) if QUICK else (30, 54, 80)
    pos = positives(101, kinds, sizes)
    print("CAPTIONS (3-8 words), %d frames, half of them JPEG'd / softened    [%.0fs]" % (len(pos), time.time() - t))
    f = [r for r in pos if r["found"]]
    print("  found %s (relaxed %s)   letters covered %s   mask area / text area %.2fx   %.2f s per box" % (
        pct(len(f) / len(pos)), pct(np.mean([r["found_relaxed"] for r in pos])), pct(np.mean([r["recall_any"] for r in f])),
        np.mean([r["area_ratio"] for r in f]), np.mean([r["secs"] for r in pos])))
    for key in ("kind", "style", "size", "box", "hindi"):
        table(pos, key, key)
    print("  not found because:", dict(Counter(r["why"] for r in pos if not r["found"])))

    short = positives(202, ["source", "natural"], (30, 54) if not QUICK else (54,), texts=SHORT)
    f = [r for r in short if r["found"]]
    print("\nSHORT CAPTIONS (1-2 words), %d frames: found %s, relaxed %s" % (len(short), pct(len(f) / len(short)), pct(np.mean([r["found_relaxed"] for r in short]))))

    neg = negatives_synth(303, kinds, 4 if QUICK else 12) + negatives_natural(404, 6 if QUICK else 30)
    print("\nNO TEXT IN THE BOX, %d boxes (hard: faces, fur, grass, gravel, bricks, stars, stripes)" % len(neg))
    print("  wrongly 'text found':  normal %d (%s)   relaxed %d (%s)" % (
        sum(r["found"] for r in neg), pct(np.mean([r["found"] for r in neg])), sum(r["found_relaxed"] for r in neg), pct(np.mean([r["found_relaxed"] for r in neg]))))
    by = defaultdict(list)
    for r in neg:
        by[r["tag"]].append(r)
    worst = sorted(by.items(), key=lambda kv: -sum(x["found"] for x in kv[1]))[:5]
    print("  most-fooled pictures (normal):", ", ".join("%s %d/%d" % (k, sum(x["found"] for x in v), len(v)) for k, v in worst))
