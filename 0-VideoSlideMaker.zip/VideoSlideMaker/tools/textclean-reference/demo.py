"""Makes sample/text_cleaner_before_after.png: a subtitle drawn on the bundled real frame (a close-up face), then
cleaned with REMOVE and with BLUR - the same layout as ../logoclean-reference/sample/before_after.png.
   python3 demo.py"""
import os, sys
import numpy as np
import cv2
import textmask as tm
import synth_text as st
sys.path.insert(0, os.path.join(st.HERE, "..", "logoclean-reference"))
import logoclean as lc

tm._FAST_LABEL = True
OUT = os.path.join(st.HERE, "sample", "text_cleaner_before_after.png")


def blur_strength(mask, strength=0.4):
    ys, xs = np.nonzero(mask)
    side = min(xs.max() - xs.min() + 1, ys.max() - ys.min() + 1)
    sigma = (0.12 + 0.48 * strength) * side
    return sigma, max(2.0, 0.45 * sigma)


def row(bg, text, font, style, size, label_note):
    frame, glyph, core = st.render(bg, text, size, style, font, cy=int(st.H * 0.86))
    box = st.user_box(glyph, size, "band", np.random.RandomState(1), glyph.shape)
    x0, y0, x1, y1 = st.window_for(box, glyph.shape)
    win = frame[y0:y1, x0:x1]
    region = np.zeros(win.shape[:2], bool)
    region[box[1] - y0:box[3] - y0, box[0] - x0:box[2] - x0] = True
    dbg = {}
    res = tm.detect(win, region, debug=dbg)
    assert res is not None, dbg
    removed = lc.inpaint(win, res.mask)
    sigma, feather = blur_strength(res.blur_mask)
    blurred = lc.blur_logo(win, res.blur_mask, sigma=sigma, feather=feather)
    changed = (np.abs(removed.astype(int) - win.astype(int)).sum(2) > 0).sum() / region.sum()
    print(f"{label_note}: mask covers {res.mask.sum() / region.sum():.1%} of the box; REMOVE changes {changed:.1%} of the box")
    # show a strip of the picture around the subtitle (the whole width, a band of rows)
    r0, r1 = max(0, y0), min(st.H, y1)
    def strip(win_img):
        full = frame.copy()
        full[y0:y1, x0:x1] = win_img
        return full[r0:r1]
    return strip(win), strip(removed), strip(blurred)


def label(img, text):
    out = img.copy()
    cv2.putText(out, text, (8, 24), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 255, 0), 2, cv2.LINE_AA)
    return out


if __name__ == "__main__":
    rng = np.random.RandomState(4)
    rows = []
    bg = st.background("source", rng)
    a = row(bg, "I told you the truth, I never left", st.FONT_LATIN, "white_outline", 54, "English, white + black outline, on a face")
    rows.append(np.hstack([label(a[0], "original"), label(a[1], "REMOVE"), label(a[2], "BLUR")]))
    bg2 = st.background("blobs", np.random.RandomState(9))
    b = row(bg2, st.HINDI[1], st.FONT_DEVANAGARI, "yellow_outline", 60, "Hindi, yellow + black outline, on a scene")
    rows.append(np.hstack([label(b[0], "original"), label(b[1], "REMOVE"), label(b[2], "BLUR")]))
    h = max(r.shape[0] for r in rows)
    rows = [np.pad(r, ((0, h - r.shape[0]), (0, 0), (0, 0))) for r in rows]
    sheet = np.vstack(rows)
    scale = 1900 / sheet.shape[1]
    sheet = cv2.resize(sheet, (1900, int(sheet.shape[0] * scale)), interpolation=cv2.INTER_AREA)
    cv2.imwrite(OUT, cv2.cvtColor(sheet, cv2.COLOR_RGB2BGR))
    print("wrote", OUT, sheet.shape)
