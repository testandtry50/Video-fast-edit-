"""Builds test frames with SUBTITLES / TEXT of known shape (so the finder can be measured, not guessed).

Every frame comes with the exact mask of the pixels the text touched (glyphs + outline + shadow), the clean
background it was drawn on, and the box a user would plausibly draw."""
import os
import sys
import cv2
import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageFilter

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "logoclean-reference"))
import synth as lsynth   # noqa: E402  (real screenshot + procedural scenes from the logo cleaner's tests)

FONT_LATIN = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"
FONT_LATIN_LIGHT = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"
FONT_DEVANAGARI = "/usr/share/fonts/truetype/freefont/FreeSansBold.ttf"

LATIN = ["I told you the truth", "EASY DEPOSITS. FAST PAYOUTS.", "Where were you last night?", "Subscribe for more videos",
         "He never came back home", "Welcome to the show 2024"]
HINDI = ["\u092e\u0948\u0902\u0928\u0947 \u0924\u0941\u092e\u094d\u0939\u0947\u0902 \u0938\u091a \u092c\u0924\u093e\u092f\u093e",
         "\u0906\u092a \u0915\u0932 \u0930\u093e\u0924 \u0915\u0939\u093e\u0901 \u0925\u0947",
         "\u092f\u0939 \u092c\u0939\u0941\u0924 \u0905\u091a\u094d\u091b\u093e \u0939\u0948"]

W, H = 1280, 720


# ----------------------------------------------------------------------------- backgrounds
def _resize(img, w=W, h=H):
    return cv2.resize(img, (w, h), interpolation=cv2.INTER_AREA)


NATURAL = ("astronaut", "camera", "coffee", "chelsea", "rocket", "grass", "gravel", "brick", "horse", "coins",
           "moon", "retina", "hubble_deep_field", "clock", "immunohistochemistry", "cell")


def natural(rng, name=None):
    """A real photograph from scikit-image's bundled samples, cropped / zoomed / resized to W x H (no text in them)."""
    import skimage.data as sd
    name = name or NATURAL[rng.randint(len(NATURAL))]
    im = getattr(sd, name)()
    if im.ndim == 2:
        im = np.repeat(im[..., None], 3, axis=2)
    im = im[..., :3]
    if im.dtype != np.uint8:
        im = (255 * (im.astype(np.float32) / im.max())).astype(np.uint8)
    h, w = im.shape[:2]
    z = rng.uniform(1.0, 2.2)
    ch, cw = int(h / z), int(w / z)
    y, x = rng.randint(0, h - ch + 1), rng.randint(0, w - cw + 1)
    crop = np.ascontiguousarray(im[y:y + ch, x:x + cw])
    out = cv2.resize(crop, (W, H), interpolation=cv2.INTER_CUBIC)
    return out


def background(kind, rng):
    """Returns a W x H uint8 RGB picture."""
    if kind == "source":     # the user's real frame (a blurry face close-up), zoomed / shifted / recoloured
        plate = lsynth.clean_plate(lsynth.load_source())
        return _resize(lsynth.variant_of_source(plate, rng))
    if kind == "natural":
        return natural(rng)
    if kind == "blobs":      # made-up scene: soft colour blobs, a few hard-edged shapes, noise
        return _resize(lsynth.procedural(rng, 1920, 1080))
    if kind == "smooth":     # vertical gradient, like a studio wall
        top, bot = rng.uniform(20, 235, 3), rng.uniform(20, 235, 3)
        t = np.linspace(0, 1, H)[:, None, None]
        img = top * (1 - t) + bot * t
        img = np.repeat(img, W, axis=1) + rng.normal(0, 2.0, (H, W, 3))
        return img.clip(0, 255).astype(np.uint8)
    if kind == "busy":       # leaves / grass / crowd: strong fine texture in every direction
        out = np.zeros((H, W), np.float32)
        for s, a in ((1.5, 22), (3.0, 20), (7.0, 16), (16.0, 12)):
            n = rng.normal(0, 1, (H, W)).astype(np.float32)
            n = cv2.GaussianBlur(n, (0, 0), s)
            out += a * n / max(1e-6, n.std())
        base = rng.uniform(70, 170)
        gray = (base + out).clip(0, 255)
        tint = rng.uniform(0.7, 1.2, 3)
        return (gray[..., None] * tint).clip(0, 255).astype(np.uint8)
    if kind == "extreme":    # the old, brutal version: black specks everywhere (stress test, not a pass/fail case)
        out = np.zeros((H, W), np.float32)
        for s, a in ((1.5, 70), (3.0, 60), (7.0, 45), (16.0, 35)):
            n = rng.normal(0, 1, (H, W)).astype(np.float32)
            n = cv2.GaussianBlur(n, (0, 0), s)
            out += a * n / max(1e-6, n.std())
        return (np.repeat((rng.uniform(70, 170) + out)[..., None], 3, axis=2)).clip(0, 255).astype(np.uint8)
    if kind == "stripes":    # blinds / fence / shirt pattern: thin high-contrast lines that are NOT text
        period = int(rng.randint(5, 14))
        yy = np.arange(H)[:, None]
        xx = np.arange(W)[None, :]
        ang = rng.uniform(0, np.pi)
        v = np.sin((xx * np.cos(ang) + yy * np.sin(ang)) * 2 * np.pi / period)
        img = 128 + 70 * np.sign(v) * (np.abs(v) > 0.2)
        img = cv2.GaussianBlur(img.astype(np.float32), (0, 0), 0.8)
        return np.repeat(img[..., None], 3, axis=2).clip(0, 255).astype(np.uint8)
    raise ValueError(kind)


# ----------------------------------------------------------------------------- text
STYLES = ("white_outline", "yellow_outline", "white_shadow", "white_plain", "dark_on_light", "white_on_plate")


def _font(path, size):
    return ImageFont.truetype(path, int(size))


def render(bg, text, size, style="white_outline", font_path=FONT_LATIN, cx=None, cy=None):
    """Draws [text] on [bg]. Returns (frame uint8, glyph_mask bool [every pixel the text changed], core bool)."""
    h, w = bg.shape[:2]
    cx = w // 2 if cx is None else cx
    cy = int(h * 0.86) if cy is None else cy
    base = Image.fromarray(bg).convert("RGBA")
    layer = Image.new("RGBA", base.size, (0, 0, 0, 0))
    d = ImageDraw.Draw(layer)
    font = _font(font_path, size)
    sw = max(2, int(round(size / 12)))
    if style == "white_outline":
        d.text((cx, cy), text, font=font, fill=(255, 255, 255, 255), stroke_width=sw, stroke_fill=(0, 0, 0, 255), anchor="mm")
    elif style == "yellow_outline":
        d.text((cx, cy), text, font=font, fill=(255, 224, 40, 255), stroke_width=sw, stroke_fill=(0, 0, 0, 255), anchor="mm")
    elif style == "white_shadow":
        sh = Image.new("RGBA", base.size, (0, 0, 0, 0))
        ImageDraw.Draw(sh).text((cx + size // 14, cy + size // 14), text, font=font, fill=(0, 0, 0, 220), anchor="mm")
        sh = sh.filter(ImageFilter.GaussianBlur(max(1, size // 24)))
        layer = Image.alpha_composite(layer, sh)
        ImageDraw.Draw(layer).text((cx, cy), text, font=font, fill=(255, 255, 255, 255), anchor="mm")
    elif style == "white_plain":
        d.text((cx, cy), text, font=font, fill=(255, 255, 255, 255), anchor="mm")
    elif style == "dark_on_light":
        d.text((cx, cy), text, font=font, fill=(20, 20, 24, 255), anchor="mm")
    elif style == "white_on_plate":
        l, t, r, b = d.textbbox((cx, cy), text, font=font, anchor="mm")
        pad = size // 4
        plate = Image.new("RGBA", base.size, (0, 0, 0, 0))
        ImageDraw.Draw(plate).rectangle((l - pad, t - pad, r + pad, b + pad), fill=(0, 0, 0, 150))
        layer = Image.alpha_composite(layer, plate)
        ImageDraw.Draw(layer).text((cx, cy), text, font=font, fill=(255, 255, 255, 255), anchor="mm")
    else:
        raise ValueError(style)
    alpha = np.asarray(layer)[..., 3].astype(np.float32) / 255.0
    out = np.asarray(Image.alpha_composite(base, layer).convert("RGB"))
    glyph = alpha > 0.04
    core = alpha > 0.5
    if style == "white_on_plate":      # the plate is not "text": ground truth is the letters only
        only = Image.new("RGBA", base.size, (0, 0, 0, 0))
        ImageDraw.Draw(only).text((cx, cy), text, font=font, fill=(255, 255, 255, 255), anchor="mm")
        a2 = np.asarray(only)[..., 3].astype(np.float32) / 255.0
        glyph, core = a2 > 0.04, a2 > 0.5
    return out, glyph, core


def user_box(glyph, size, kind, rng, shape):
    """The box a person would draw. 'tight' hugs the text with a little margin; 'band' is a loose strip across
    the picture that holds one or two lines. Returns (x0, y0, x1, y1) with x1/y1 exclusive."""
    h, w = shape
    ys, xs = np.nonzero(glyph)
    x0, x1, y0, y1 = xs.min(), xs.max() + 1, ys.min(), ys.max() + 1
    if kind == "tight":
        m = int(size * rng.uniform(0.15, 0.4))
        return max(0, x0 - m), max(0, y0 - m), min(w, x1 + m), min(h, y1 + m)
    my = int(size * rng.uniform(0.35, 0.9))
    return int(w * 0.04), max(0, y0 - my), int(w * 0.96), min(h, y1 + my)


def window_for(box, shape):
    """Same rule as LogoPaint.planTextRegion in Kotlin: the box plus some surroundings to copy colours from."""
    h, w = shape
    x0, y0, x1, y1 = box
    ctx = max(24, int(round(0.5 * min(x1 - x0, y1 - y0))))
    return max(0, x0 - ctx), max(0, y0 - ctx), min(w, x1 + ctx), min(h, y1 + ctx)


def render_truth(bg, text, size, style, font_path=FONT_LATIN, cx=None, cy=None):
    """The picture a perfect cleaner would leave: the background, plus the dark strip when the style has one (a
    cleaner that removes only the LETTERS must not be blamed for the strip staying)."""
    if style != "white_on_plate":
        return bg
    h, w = bg.shape[:2]
    cx = w // 2 if cx is None else cx
    cy = int(h * 0.86) if cy is None else cy
    base = Image.fromarray(bg).convert("RGBA")
    d = ImageDraw.Draw(Image.new("RGBA", base.size))
    font = _font(font_path, size)
    l, t, r, b = d.textbbox((cx, cy), text, font=font, anchor="mm")
    pad = size // 4
    plate = Image.new("RGBA", base.size, (0, 0, 0, 0))
    ImageDraw.Draw(plate).rectangle((l - pad, t - pad, r + pad, b + pad), fill=(0, 0, 0, 150))
    return np.asarray(Image.alpha_composite(base, plate).convert("RGB"))
