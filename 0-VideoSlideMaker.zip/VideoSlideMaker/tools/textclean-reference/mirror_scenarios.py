"""The exact synthetic scenarios used by the Kotlin unit tests (TextMaskTest.kt), run through the Python reference so
the numbers asserted in Kotlin are measured, not guessed. No randomness, no fonts: a 5x7 pixel font drawn in code."""
import os, sys
import numpy as np
import textmask as tm
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "logoclean-reference"))
import logoclean as lc

W, H = 360, 140
BOX = (40, 40, 320, 100)          # x0, y0, x1, y1 (exclusive)
TEXT_X, TEXT_Y, SCALE, OUT = 70, 62, 3, 2

FONT = {
    "H": ["X...X", "X...X", "X...X", "XXXXX", "X...X", "X...X", "X...X"],
    "E": ["XXXXX", "X....", "X....", "XXXX.", "X....", "X....", "XXXXX"],
    "L": ["X....", "X....", "X....", "X....", "X....", "X....", "XXXXX"],
    "O": [".XXX.", "X...X", "X...X", "X...X", "X...X", "X...X", ".XXX."],
    "T": ["XXXXX", "..X..", "..X..", "..X..", "..X..", "..X..", "..X.."],
    "S": [".XXXX", "X....", "X....", ".XXX.", "....X", "....X", "XXXX."],
    " ": ["....."] * 7,
}


def background(): 
    y, x = np.mgrid[0:H, 0:W].astype(np.float64)
    return np.clip(90 + 0.2 * x + 0.25 * y + 10 * np.sin(0.05 * x), 0, 255)


def fill_mask(text):
    m = np.zeros((H, W), bool)
    for i, ch in enumerate(text):
        for cy, row in enumerate(FONT[ch]):
            for cx, c in enumerate(row):
                if c == "X":
                    x = TEXT_X + (i * 6 + cx) * SCALE
                    y = TEXT_Y + cy * SCALE
                    m[y:y + SCALE, x:x + SCALE] = True
    return m


def grow(m, r):
    out = m.copy()
    for dy in range(-r, r + 1):
        for dx in range(-r, r + 1):
            out |= np.roll(np.roll(m, dy, 0), dx, 1)
    return out


def caption(text="HELLO TEST", fill=250, outline=10):
    """Returns (picture float HxW, glyph mask = letters + outline). outline None = no outline."""
    v = background()
    f = fill_mask(text)
    g = f
    if outline is not None:
        g = grow(f, OUT)
        v[g] = outline
    v[f] = fill
    return v, g


def thin_line():
    v = background()
    v[69:71, 100:260] = 40
    return v


def stripes():
    y, x = np.mgrid[0:H, 0:W].astype(np.float64)
    return np.clip(128 + 70 * np.sign(np.sin(2 * np.pi * (x + y) / 6.0)), 0, 255)


def rgb_of(v):
    g = np.clip(np.floor(v + 0.5), 0, 255).astype(np.uint8)    # the Kotlin tests store grey ints
    return np.stack([g, g, g], axis=2)


def region():
    r = np.zeros((H, W), bool)
    r[BOX[1]:BOX[3], BOX[0]:BOX[2]] = True
    return r


def run(name, v, relaxed=False, glyph=None, clean=None):
    dbg = {}
    res = tm.detect(rgb_of(v), region(), relaxed=relaxed, debug=dbg)
    line = f"{name:34s} found={res is not None}"
    if res is None:
        print(line, "  why:", dbg.get("why"), {k: (round(x, 2) if isinstance(x, float) else x) for k, x in dbg.items() if k in ("runs", "ink_med", "pair", "cover")})
        return res
    line += f"  r={res.r} cover={res.cover:.3f} runs={dbg['runs']} ink_med={dbg['ink_med']} pair={dbg['pair']:.2f}"
    if glyph is not None:
        m = res.mask
        line += f"  recall={(m & glyph).sum() / glyph.sum():.4f} mask/glyph={m.sum() / glyph.sum():.2f} outside_box={(m & ~region()).sum()}"
        line += f"  blurmask/glyph={res.blur_mask.sum() / glyph.sum():.2f}"
    print(line)
    return res


if __name__ == "__main__":
    tm._FAST_LABEL = False         # the reference loop, exactly what Kotlin ports
    bg = background()
    v, g = caption()
    res = run("caption white+outline", v, glyph=g)
    run("no text (smooth)", bg)
    run("thin dark line (a lip, a wire)", thin_line())
    run("fine stripes (a texture)", stripes())
        # faint plain caption: grey letters a little brighter than the picture, no outline
    vf = background()
    f = fill_mask("HELLO")
    vf[f] = vf[f] + 80
    print("faint caption, strict gate:", end=" ")
    run("", vf)
    print("faint caption, relaxed gate:", end=" ")
    run("", vf, relaxed=True, glyph=f)
    # repair numbers (REMOVE) for the main caption
    out = lc.inpaint(rgb_of(v), res.mask)
    inside = g
    err = np.abs(out[..., 0].astype(float) - bg)[inside].mean()
    far = ~grow(res.mask, 14)
    same_far = (out[..., 0][far] == rgb_of(v)[..., 0][far]).all()
    print(f"REMOVE: mean abs error inside the letters vs the true background: {err:.2f}   far pixels untouched: {same_far}")
    # BLUR: how much of the letters' edge contrast is left
    blurred = lc.blur_logo(rgb_of(v), res.blur_mask, sigma=0.28 * (res.blur_mask.any(1).sum()), feather=2.0)

    def edge_energy(a):
        a = a[..., 0].astype(float)
        return np.abs(np.diff(a, axis=1))[g[:, 1:]].mean()
    print(f"BLUR: edge contrast over the letters {edge_energy(rgb_of(v)):.1f} -> {edge_energy(blurred):.1f}")
