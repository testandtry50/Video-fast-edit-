"""Statement-by-statement Python transliteration of the index-heavy parts of TextMask.kt, compared with textmask.py
(whose min/max filters were verified against OpenCV). Catches off-by-one mistakes in the Kotlin port without a
Kotlin compiler.   python3 kotlin_transliteration_check.py"""
import numpy as np
import textmask as tm


def pick(a, b, take_min):
    return (a if a < b else b) if take_min else (a if a > b else b)


def extreme_line(p, m, n, k, take_min):            # TextMask.extremeLine
    g = [0.0] * m
    hh = [0.0] * m
    s = 0
    while s < m:
        e = min(s + k, m)
        g[s] = p[s]
        for j in range(s + 1, e):
            g[j] = pick(g[j - 1], p[j], take_min)
        hh[e - 1] = p[e - 1]
        for j in range(e - 2, s - 1, -1):          # e - 2 downTo s
            hh[j] = pick(hh[j + 1], p[j], take_min)
        s += k
    return [pick(hh[i], g[i + k - 1], take_min) for i in range(n)]


def extreme2d(src, w, h, r, take_min):             # TextMask.extreme2d
    if r <= 0:
        return list(src)
    k = 2 * r + 1
    tmp = [0.0] * (w * h)
    for y in range(h):
        m = w + 2 * r
        row = y * w
        p = [src[row + min(max(j - r, 0), w - 1)] for j in range(m)]
        line = extreme_line(p, m, w, k, take_min)
        for x in range(w):
            tmp[row + x] = line[x]
    out = [0.0] * (w * h)
    for x in range(w):
        m = h + 2 * r
        p = [tmp[min(max(j - r, 0), h - 1) * w + x] for j in range(m)]
        line = extreme_line(p, m, h, k, take_min)
        for y in range(h):
            out[y * w + x] = line[y]
    return out


def max_filter_rect(src, w, h, rx, ry):            # TextMask.maxFilterRect
    tmp = [False] * (w * h)
    if rx <= 0:
        tmp = list(src)
    else:
        for y in range(h):
            row = y * w
            count = 0
            for x in range(0, min(rx, w - 1) + 1):
                if src[row + x]:
                    count += 1
            for x in range(w):
                tmp[row + x] = count > 0
                add = x + rx + 1
                rem = x - rx
                if add < w and src[row + add]:
                    count += 1
                if rem >= 0 and src[row + rem]:
                    count -= 1
    if ry <= 0:
        return tmp
    out = [False] * (w * h)
    for x in range(w):
        count = 0
        for y in range(0, min(ry, h - 1) + 1):
            if tmp[y * w + x]:
                count += 1
        for y in range(h):
            out[y * w + x] = count > 0
            add = y + ry + 1
            rem = y - ry
            if add < h and tmp[add * w + x]:
                count += 1
            if rem >= 0 and tmp[rem * w + x]:
                count -= 1
    return out


def close_rect(b, w, h, rx, ry):                   # TextMask.closeRect
    grown = max_filter_rect(b, w, h, rx, ry)
    inv = [not x for x in grown]
    shrunk_inv = max_filter_rect(inv, w, h, rx, ry)
    return [not x for x in shrunk_inv]


def row_runs(m, region, w, h):                     # TextMask.rowRuns
    counts = []
    for y in range(h):
        in_region = False
        runs = 0
        prev = False
        for x in range(w):
            i = y * w + x
            if region[i]:
                in_region = True
            cur = m[i]
            if cur and not prev:
                runs += 1
            prev = cur
        if in_region:
            counts.append(runs)
    if not counts:
        return 0
    counts.sort()
    k = min(3, len(counts))
    return counts[len(counts) - k]


def hist_percentile(values, sel, want, pct):       # TextMask.histPercentile
    import math
    hist = [0] * 256
    n = 0
    for i in range(len(values)):
        if sel[i] != want:
            continue
        hist[min(255, int(math.floor(values[i])))] += 1
        n += 1
    if n == 0:
        return 0
    need = max(1, int(math.ceil(pct / 100.0 * n)))
    cum = 0
    for b in range(256):
        cum += hist[b]
        if cum >= need:
            return b
    return 255


if __name__ == "__main__":
    rng = np.random.RandomState(7)
    bad = 0
    for trial in range(40):
        w, h = int(rng.randint(5, 40)), int(rng.randint(5, 30))
        a = (rng.rand(h, w) * 255).astype(np.float32)
        for r in (1, 2, 3, 6, 11):
            for tmn in (True, False):
                got = np.array(extreme2d(a.ravel().tolist(), w, h, r, tmn)).reshape(h, w)
                want = tm.erode(a, r) if tmn else tm.dilate(a, r)
                bad += int(not np.array_equal(got, want))
        b = rng.rand(h, w) < 0.15
        for rx, ry in ((1, 1), (3, 1), (2, 5), (0, 2), (4, 0)):
            got = np.array(max_filter_rect(b.ravel().tolist(), w, h, rx, ry)).reshape(h, w)
            want = tm._dilate_rect(b, rx, ry)
            bad += int(not np.array_equal(got, want))
            got = np.array(close_rect(b.ravel().tolist(), w, h, max(rx, 1), max(ry, 1))).reshape(h, w)
            want = tm.close_rect(b, max(rx, 1), max(ry, 1))
            bad += int(not np.array_equal(got, want))
        reg = rng.rand(h, w) < 0.8
        bad += int(row_runs(b.ravel().tolist(), reg.ravel().tolist(), w, h) != tm.row_runs(b, reg))
        vals = (rng.rand(h * w) * 300).astype(np.float32)
        sel = reg.ravel()
        for pct in (20, 50, 92):
            bad += int(hist_percentile(vals.tolist(), sel.tolist(), True, pct) != tm.hist_percentile(vals[sel], pct))
            bad += int(hist_percentile(vals.tolist(), sel.tolist(), False, pct) != tm.hist_percentile(vals[~sel], pct))
    print("mismatches between the Kotlin transliteration and the reference:", bad)
