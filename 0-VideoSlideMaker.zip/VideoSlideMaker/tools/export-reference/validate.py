"""Independent structural validator for fragmented MP4, written from ISO/IEC 14496-12 and NOT from the writer's code.
Usage: python3 validate.py file.mp4 ...   (each file needs the file.mp4.json written by Gen.java)"""
import sys, struct, json

def boxes(d, s, e):
    out = []; i = s
    while i < e:
        if i + 8 > e: raise ValueError(f"truncated box header at {i}")
        size, typ = struct.unpack(">I4s", d[i:i+8]); typ = typ.decode("latin1"); hdr = 8
        if size == 1: size = struct.unpack(">Q", d[i+8:i+16])[0]; hdr = 16
        elif size == 0: size = e - i
        if size < hdr or i + size > e: raise ValueError(f"bad box size for '{typ}' at {i}: {size} (end {e})")
        out.append((typ, i, size, hdr)); i += size
    return out
def tolerant_boxes(d, s, e):
    """Like boxes(), but stops quietly at a box that does not fit (a file cut short)."""
    out = []; i = s
    while i + 8 <= e:
        size, typ = struct.unpack(">I4s", d[i:i+8]); hdr = 8
        if size == 1:
            if i + 16 > e: break
            size = struct.unpack(">Q", d[i+8:i+16])[0]; hdr = 16
        if size < hdr or i + size > e: break
        out.append((typ.decode("latin1"), i, size, hdr)); i += size
    return out
def find(bs, t): return [b for b in bs if b[0] == t]
def one(bs, t):
    r = find(bs, t)
    if len(r) != 1: raise ValueError(f"expected exactly one '{t}', found {len(r)}")
    return r[0]
def kids(d, b): return boxes(d, b[1] + b[3], b[1] + b[2])
def fullbox(d, b): v = d[b[1]+b[3]]; fl = int.from_bytes(d[b[1]+b[3]+1:b[1]+b[3]+4], "big"); return v, fl, b[1]+b[3]+4
errors = []
def check(c, msg):
    if not c: errors.append(msg)
def desc(d, i):
    tag = d[i]; i += 1; ln = 0
    for _ in range(4):
        b = d[i]; i += 1; ln = (ln << 7) | (b & 0x7F)
        if not b & 0x80: break
    return tag, i, ln

def validate(path, cut=None):
    """cut=N: validate only the first N bytes, as an interrupted export would have left them."""
    data = open(path, "rb").read(); meta = json.load(open(path + ".json"))
    partial = cut is not None
    if partial: data = data[:cut]
    n = len(data)
    top = tolerant_boxes(data, 0, n) if partial else boxes(data, 0, n); types = [b[0] for b in top]
    check(types[0] == "ftyp" and types[1] == "moov", f"file must start with ftyp, moov: {types[:3]}")
    if not partial: check(types[-1] == "mfra", f"file must end with mfra: {types[-3:]}")
    body = top[2:] if partial else top[2:-1]
    if partial and len(body) % 2 == 1: body = body[:-1]          # a moof whose mdat was cut off: that fragment is simply not there yet
    check(len(body) % 2 == 0 and all(body[i][0] == ("moof" if i % 2 == 0 else "mdat") for i in range(len(body))), "between moov and mfra there must be only moof,mdat pairs")
    check(data[top[0][1]+8:top[0][1]+12] == b"isom", "major brand")
    moov = top[1]; mk = kids(data, moov)
    mvhd = one(mk, "mvhd"); v, fl, o = fullbox(data, mvhd); check(v == 1, "mvhd v1")
    timescale = struct.unpack(">I", data[o+16:o+20])[0]; duration = struct.unpack(">Q", data[o+20:o+28])[0]
    check(timescale == 1000 and duration == meta["plannedUs"] // 1000, f"mvhd timescale/duration {timescale}/{duration}")
    mex = kids(data, one(mk, "mvex")); mehd = one(mex, "mehd"); v, fl, o = fullbox(data, mehd)
    check(struct.unpack(">Q", data[o:o+8])[0] == meta["plannedUs"] // 1000, "mehd fragment_duration")
    check(len(find(mex, "trex")) == (2 if meta["audio"] else 1), "one trex per track")
    traks = find(mk, "trak"); check(len(traks) == (2 if meta["audio"] else 1), f"{len(traks)} tracks")
    for tr in traks:
        tk = kids(data, tr); tkhd = one(tk, "tkhd"); v, fl, o = fullbox(data, tkhd); check(v == 1 and fl == 7, "tkhd v1 flags 7")
        mdia = one(tk, "mdia"); md = kids(data, mdia); mdhd = one(md, "mdhd"); v2, f2, o2 = fullbox(data, mdhd)
        ts = struct.unpack(">I", data[o2+16:o2+20])[0]; dur = struct.unpack(">Q", data[o2+20:o2+28])[0]
        hd = one(md, "hdlr"); _, _, oh = fullbox(data, hd); htype = data[oh+4:oh+8].decode()
        sb = kids(data, one(kids(data, one(md, "minf")), "stbl"))
        for t in ("stts", "stsc", "stsz", "stco"):
            b = one(sb, t); _, _, oo = fullbox(data, b); check(all(x == 0 for x in data[oo:b[1]+b[2]]), f"{t} must be empty in a fragmented file")
        stsd = one(sb, "stsd"); _, _, os_ = fullbox(data, stsd); check(struct.unpack(">I", data[os_:os_+4])[0] == 1, "stsd entry count"); entry = boxes(data, os_ + 4, stsd[1] + stsd[2])[0]
        if htype == "vide":
            check(entry[0] == "avc1", "video sample entry avc1"); eo = entry[1] + 8
            w, h = struct.unpack(">HH", data[eo+24:eo+28]); check((w, h) == (1920, 1080), f"avc1 size {w}x{h}")
            check(ts == 90000, "video timescale"); check(dur == meta["plannedUs"] * 90000 // 1_000_000, f"video mdhd duration {dur}")
            cs = boxes(data, eo + 78, entry[1] + entry[2]); avcc = one(cs, "avcC"); a = data[avcc[1]+8:avcc[1]+avcc[2]]
            check(a[0] == 1 and a[1] == meta["profile"] and a[4] == 0xFF, f"avcC header {a[:6].hex()}"); check((a[5] & 0x1F) == 1, "one SPS"); l = struct.unpack(">H", a[6:8])[0]; sps = a[8:8+l]; check(sps[0] == 0x67 and sps[1] == meta["profile"], "SPS bytes")
            p = 8 + l; check(a[p] == 1, "one PPS"); pl = struct.unpack(">H", a[p+1:p+3])[0]; check(a[p+3] == 0x68, "PPS nal"); rest = a[p+3+pl:]
            check((rest == bytes([0xFD, 0xF8, 0xF8, 0])) if meta["profile"] == 0x64 else len(rest) == 0, f"avcC high-profile extension: {rest.hex()}")
        else:
            check(entry[0] == "mp4a", "audio sample entry mp4a"); eo = entry[1] + 8
            ch, sz = struct.unpack(">HH", data[eo+16:eo+20]); sr = struct.unpack(">I", data[eo+24:eo+28])[0] >> 16; check((ch, sz, sr) == (2, 16, 44100), f"mp4a {ch},{sz},{sr}"); check(ts == 44100, "audio timescale")
            cs = boxes(data, eo + 28, entry[1] + entry[2]); es = one(cs, "esds"); _, _, oe = fullbox(data, es); i = oe
            tag, i, ln = desc(data, i); check(tag == 3, "ES_Descriptor"); end3 = i + ln; i += 3; tag, i, ln = desc(data, i); check(tag == 4, "DecoderConfig"); check(data[i] == 0x40 and data[i+1] == 0x15, "objectType/streamType")
            end4 = i + ln; j = i + 13; tag, j, ln = desc(data, j); check(tag == 5 and data[j:j+ln] == b"\x12\x10", "AudioSpecificConfig"); check(j + ln == end4, "DecoderConfig length"); j = end4; tag, j, ln = desc(data, j); check(tag == 6 and data[j] == 2 and j + ln == end3, "SLConfig and ES length")
    seq = 0; nextdts = {}; vcount = 0; acount = 0; frag_idx = {1: [], 2: []}; v_expected_dts = 0; a_expected_k = 0; fragments = 0
    for i in range(0, len(body) - len(body) % 2, 2):
        moof, mdat = body[i], body[i+1]; fragments += 1; mk2 = kids(data, moof); _, _, o = fullbox(data, one(mk2, "mfhd")); s = struct.unpack(">I", data[o:o+4])[0]; check(s == seq + 1, f"fragment sequence {s} after {seq}"); seq = s
        check(moof[1] + moof[2] == mdat[1], "mdat must directly follow its moof"); payload_start = mdat[1] + mdat[3]; payload_end = mdat[1] + mdat[2]; trafs = find(mk2, "traf"); expect_off = payload_start - moof[1]; total = 0; frag_v = None
        for ti, traf in enumerate(trafs):
            tf = kids(data, traf); v, fl, o = fullbox(data, one(tf, "tfhd")); check(fl == 0x020000, f"tfhd flags {fl:#x}"); tid = struct.unpack(">I", data[o:o+4])[0]
            v, fl, o = fullbox(data, one(tf, "tfdt")); check(v == 1, "tfdt v1"); base = struct.unpack(">Q", data[o:o+8])[0]
            trun = one(tf, "trun"); v, fl, o = fullbox(data, trun); check(fl == 0x701, f"trun flags {fl:#x}"); cnt, off = struct.unpack(">Ii", data[o:o+8]); o += 8
            check(off == expect_off, f"trun data_offset {off} != expected {expect_off}"); ents = [struct.unpack(">III", data[o+12*k:o+12*k+12]) for k in range(cnt)]; check(trun[1] + trun[2] == o + 12 * cnt, "trun length")
            if tid in nextdts: check(base == nextdts[tid], f"track {tid}: fragment {fragments} starts at {base} but the previous ended at {nextdts[tid]}")
            nextdts[tid] = base + sum(e[0] for e in ents); pos = moof[1] + off
            if tid == 1:
                frag_v = (base, nextdts[tid]); frag_idx[1].append((base, moof[1])); check(base == v_expected_dts, f"video base {base} != expected {v_expected_dts}")
                for (dur, size, flags) in ents:
                    s_ = data[pos:pos+size]; k = 0; ntypes = []; first = None
                    while k < size:
                        l = struct.unpack(">I", s_[k:k+4])[0]; nal = s_[k+4:k+4+l]; check(len(nal) == l, "NAL length overruns the sample"); ntypes.append(nal[0] & 0x1F)
                        if first is None: first = nal
                        k += 4 + l
                    check(k == size, "NAL lengths do not add up to the sample size"); check(ntypes in ([1], [5]), f"unexpected NAL types {ntypes} (SPS/PPS/AUD must be stripped)")
                    idx = sum((first[1+j] & 0x7F) << (7*j) for j in range(4)); check(idx == vcount, f"video sample {vcount} carries frame index {idx}")
                    check((flags == 0x02000000) == (5 in ntypes) and flags in (0x02000000, 0x01010000), f"video sample {vcount} flags {flags:#x} vs nal {ntypes}")
                    check(dur == 3750, f"video sample duration {dur}"); pos += size; vcount += 1; v_expected_dts += dur
                if meta["scenario"] != "big_frames": check(ents[0][2] == 0x02000000, "a fragment must start at a key frame")
            else:
                check(base == a_expected_k * 1024, f"audio base {base} != {a_expected_k * 1024}"); frag_idx[2].append((base, moof[1], ti + 1))
                for (dur, size, flags) in ents:
                    s_ = data[pos:pos+size]; idx = sum((s_[j] & 0x7F) << (7*j) for j in range(4)); check(idx == acount, f"audio sample {acount} carries index {idx}"); check(dur == 1024 and flags == 0x02000000, f"audio dur/flags {dur},{flags:#x}"); pos += size; acount += 1; a_expected_k += 1
                if frag_v is not None:
                    vs, ve = frag_v[0] / 90000, frag_v[1] / 90000; as_, ae = base / 44100, nextdts[tid] / 44100
                    check(as_ >= vs - 0.05 and as_ < ve + 0.05 and ae <= ve + 0.05, f"audio {as_:.3f}-{ae:.3f}s is not interleaved with video {vs:.3f}-{ve:.3f}s")
            expect_off += sum(e[1] for e in ents); total += sum(e[1] for e in ents)
        check(total == payload_end - payload_start, f"traf sizes {total} != mdat payload {payload_end - payload_start}")
    if partial: return n, fragments, vcount, acount
    mfra = top[-1]; mk3 = kids(data, mfra); mfro = one(mk3, "mfro"); _, _, o = fullbox(data, mfro)
    check(mfro[2] == 16 and struct.unpack(">I", data[o:o+4])[0] == mfra[2], f"mfro says mfra is {struct.unpack('>I', data[o:o+4])[0]} bytes, it is {mfra[2]}")
    check(mfra[1] + mfra[2] == n, "mfra must end the file")
    for t in find(mk3, "tfra"):
        v, fl, o = fullbox(data, t); tid, rsv, cnt = struct.unpack(">III", data[o:o+12]); check(v == 1 and rsv == 0, "tfra header"); o += 12; got = []
        for k in range(cnt): tm, mo = struct.unpack(">QQ", data[o:o+16]); tn, rn, sn = data[o+16:o+19]; got.append((tm, mo, tn)); check(rn == 1 and sn == 1, "tfra run/sample number"); o += 19
        want = frag_idx[tid]; check([(x[0], x[1]) for x in got] == [(x[0], x[1]) for x in want], f"tfra track {tid} does not match the fragments")
        if tid == 2: check([g[2] for g in got] == [w_[2] for w_ in want], "tfra traf_number")
    check(vcount == meta["frames"], f"{vcount} video samples, generator wrote {meta['frames']}"); check(acount == meta["audioCount"], f"{acount} audio samples, generator wrote {meta['audioCount']}")
    check(fragments == meta["fragments"], f"{fragments} fragments, writer reported {meta['fragments']}"); check(n == meta["bytes"], f"file is {n} bytes, writer reported {meta['bytes']}")
    return n, fragments, vcount, acount

def prefix_tests(path):
    """Cut the file where an interrupted export could have stopped; each copy must be a valid video up to its last COMPLETE fragment:
    exactly on a fragment boundary, inside a fragment's header (moof), and inside its payload (mdat)."""
    data = open(path, "rb").read(); top = boxes(data, 0, len(data))
    moofs = [b[1] for b in top if b[0] == "moof"]; mdats = [b[1] for b in top if b[0] == "mdat"]
    bad = 0; tried = 0
    for k in sorted({1, 2, len(moofs) // 2, len(moofs) - 1}):
        if not 1 <= k < len(moofs): continue
        for label, cut in ((f"on the boundary before fragment {k + 1}", moofs[k]), (f"inside the header of fragment {k + 1}", moofs[k] + 40), (f"inside the payload of fragment {k + 1}", mdats[k] + 20)):
            errors.clear(); tried += 1
            try: res = validate(path, cut)
            except Exception as e: errors.append(f"EXCEPTION {type(e).__name__}: {e}"); res = None
            if res and res[1] != k: errors.append(f"expected {k} complete fragments, found {res[1]}")
            if errors: bad += 1; print(f"FAIL {path} cut {label} ({cut:,} bytes): {errors[:3]}")
    print(f"OK   {path}: {tried} interrupted copies, each valid up to its last complete fragment" if not bad else f"FAIL {path}: {bad} of {tried} interrupted copies were not valid")
    return bad

if __name__ == "__main__":
    if sys.argv[1] == "--prefix":
        sys.exit(1 if sum(prefix_tests(p) for p in sys.argv[2:]) else 0)
    bad = 0
    for p in sys.argv[1:]:
        errors.clear()
        try: res = validate(p)
        except Exception as e: errors.append(f"EXCEPTION {type(e).__name__}: {e}"); res = None
        if errors: bad += 1; print(f"FAIL {p}: {len(errors)} problem(s)"); [print("    -", e) for e in errors[:8]]
        else: print(f"OK   {p}: {res[0]:,} bytes, {res[1]} fragments, {res[2]} video + {res[3]} audio samples")
    sys.exit(1 if bad else 0)
