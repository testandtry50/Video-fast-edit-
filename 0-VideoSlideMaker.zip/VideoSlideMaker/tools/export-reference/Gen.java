import java.io.*;
import java.util.*;

/** Generates synthetic encoder output (H.264 Annex B frames + AAC frames), runs the writer on it, and records what it fed in. */
public class Gen {
    static final Random R = new Random(42);
    static byte[] rnd(int n) { byte[] b = new byte[n]; for (int i = 0; i < n; i++) b[i] = (byte) (1 + R.nextInt(255)); return b; }       // never 0: no accidental start codes
    static byte[] tag(int idx, int total) { byte[] b = rnd(total); for (int i = 0; i < 4; i++) b[i] = (byte) (0x80 | ((idx >>> (7 * i)) & 0x7F)); return b; }
    static void cat(ByteArrayOutputStream o, byte[]... parts) { for (byte[] p : parts) o.write(p, 0, p.length); }
    static final byte[] SC4 = {0, 0, 0, 1}, SC3 = {0, 0, 1};

    public static void main(String[] a) throws Exception {
        String scenario = a[0], outPath = a[1];
        int frames = 2400, gop = 48, fps = 24; double audioExtraSec = 3.0; boolean audio = true, emptyAudio = false; int frameMin = 500, frameMax = 60000; int profile = 0x42;
        switch (scenario) { case "av": break; case "video_only": audio = false; break; case "audio_longer": audioExtraSec = 12.5; frames = 480; break; case "big_frames": frames = 40; gop = 1000; frameMin = frameMax = 2 * 1024 * 1024; break;
            case "empty_audio": emptyAudio = true; frames = 300; break; case "high_profile": profile = 0x64; frames = 300; break; default: throw new IllegalArgumentException(scenario); }
        byte[] sps = new byte[]{0x67, (byte) profile, (byte) 0xC0, 0x1F, (byte) 0xAC, (byte) 0xD9, 0x40, 0x50, 0x05, (byte) 0xBB, 0x01, 0x10, 0x00, 0x00, 0x03, 0x00, 0x10, 0x00, 0x00, 0x03, 0x03, (byte) 0xC0, (byte) 0xF1, (byte) 0x83, 0x19, 0x60};
        byte[] pps = new byte[]{0x68, (byte) 0xCB, (byte) 0x83, (byte) 0xCB, 0x20};
        ByteArrayOutputStream csd0 = new ByteArrayOutputStream(), csd1 = new ByteArrayOutputStream(); cat(csd0, SC4, sps); cat(csd1, SC4, pps);
        Fmp4.Avc avc = Fmp4.Avc.fromCsd(csd0.toByteArray(), csd1.toByteArray());
        byte[] asc = {0x12, 0x10};                                                  // AAC-LC, 44.1 kHz, stereo
        int sr = 44100; long frameDurUs = 1_000_000L / fps; long videoUs = frames * 1_000_000L / fps;
        File spoolFile = new File(outPath + ".spool"); Fmp4.Spool spool = new Fmp4.Spool(spoolFile); int audioCount = 0;
        if (audio && !emptyAudio) { long totalUs = videoUs + (long) (audioExtraSec * 1_000_000L); for (int k = 0; ; k++) { long pts = (long) k * 1024L * 1_000_000L / sr; if (pts >= totalUs) break; spool.append(pts, 0, tag(k, 200 + R.nextInt(400))); audioCount++; } }
        FileOutputStream fos = new FileOutputStream(outPath); Fmp4.StreamSink sink = new Fmp4.StreamSink(new BufferedOutputStream(fos, 1 << 20));
        Fmp4.Writer w = new Fmp4.Writer(sink, new Fmp4.VideoTrack(1920, 1080, avc), audio ? new Fmp4.AudioTrack(sr, 2, asc, 128_000, 1024) : null, audio ? spool.reader() : null, videoUs, frameDurUs);
        w.start(); StringBuilder meta = new StringBuilder("{\"scenario\":\"" + scenario + "\",\"frames\":" + frames + ",\"fps\":" + fps + ",\"audio\":" + audio + ",\"audioCount\":" + audioCount + ",\"plannedUs\":" + videoUs + ",\"profile\":" + profile + ",\"keys\":[");
        boolean firstKey = true;
        for (int i = 0; i < frames; i++) { boolean key = i % gop == 0; ByteArrayOutputStream f = new ByteArrayOutputStream(); int payload = frameMin + (frameMax > frameMin ? R.nextInt(frameMax - frameMin) : 0);
            if (key) { cat(f, SC4, sps); cat(f, SC4, pps); cat(f, SC4, new byte[]{0x65}, tag(i, payload)); } else { if (i % 7 == 0) cat(f, SC4, new byte[]{0x09, (byte) 0xF0}); cat(f, (i % 2 == 0 ? SC4 : SC3), new byte[]{0x41}, tag(i, payload)); }
            byte[] fb = f.toByteArray(); long pts = (long) i * 1_000_000L / fps; w.writeVideoSample(fb, 0, fb.length, pts, key); if (key) { meta.append(firstKey ? "" : ",").append(i); firstKey = false; } }
        w.finish(); sink.flush(); fos.close();
        meta.append("],\"fragments\":").append(w.fragments).append(",\"videoSamples\":").append(w.videoSamples).append(",\"audioSamples\":").append(w.audioSamples).append(",\"bytes\":").append(sink.position()).append("}");
        try (PrintWriter pw = new PrintWriter(outPath + ".json")) { pw.print(meta); } spoolFile.delete();
        System.out.println(scenario + ": " + sink.position() + " bytes, " + w.fragments + " fragments, " + w.videoSamples + " video, " + w.audioSamples + " audio samples");
    }
}
