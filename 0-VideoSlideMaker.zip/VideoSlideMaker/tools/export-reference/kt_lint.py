"""Balanced-delimiter check for Kotlin files (there is no Kotlin compiler in the sandbox). Usage: python3 kt_lint.py File.kt ..."""
import sys
def strip(src):
    out=[]; i=0; n=len(src)
    while i<n:
        c=src[i]
        if src.startswith('//',i):
            while i<n and src[i]!='\n': i+=1
        elif src.startswith('/*',i):
            depth=1; i+=2
            while i<n and depth:
                if src.startswith('/*',i): depth+=1; i+=2
                elif src.startswith('*/',i): depth-=1; i+=2
                else: i+=1
        elif src.startswith('"""',i):
            j=src.index('"""',i+3); i=j+3; out.append('S')
        elif c=='"':
            i+=1
            while src[i]!='"': i+= 2 if src[i]=='\\' else 1
            i+=1; out.append('S')
        elif c=="'":
            i+=1
            while src[i]!="'": i+= 2 if src[i]=='\\' else 1
            i+=1; out.append('C')
        else: out.append(c); i+=1
    return ''.join(out)
bad=0
for f in sys.argv[1:]:
    raw=open(f,encoding='utf-8').read(); s=strip(raw)
    st=[]; pairs={')':'(',']':'[','}':'{'}; ok=True
    for ln,line in enumerate(s.split('\n'),1):
        for ch in line:
            if ch in '([{': st.append((ch,ln))
            elif ch in ')]}':
                if not st or st[-1][0]!=pairs[ch]: print(f"{f}:{ln}: unbalanced '{ch}'"); bad+=1; ok=False; st=[]; break
                st.pop()
    if st: print(f"{f}: unclosed {st[-3:]}"); bad+=1; ok=False
    if ok: print(f"{f}: ok ({raw.count(chr(10))} lines)")
sys.exit(1 if bad else 0)
