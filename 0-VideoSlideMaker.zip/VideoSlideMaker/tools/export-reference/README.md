# Large-export verification (there is no Kotlin compiler where this was written)

`export/mp4/` is a streaming (fragmented) MP4 writer. To check its bytes without a compiler:

* `Fmp4.java` - a line-by-line Java transliteration of the Kotlin (Mp4Buf, AnnexB, AvcConfig, Esds, SampleSpool, FragmentedMp4Writer). Keep it in step.
* `Gen.java` - feeds the writer synthetic encoder output (H.264 Annex-B incl. SPS/PPS/AUD to strip; AAC frames) and records what it fed.
* `validate.py` - an INDEPENDENT validator written from ISO/IEC 14496-12, not from the writer: box tree, every size/offset, timestamp continuity,
  NAL conversion, flags, audio/video interleaving, `mfra` index; `--prefix` cuts the file where an interrupted export could have stopped.

    javac -d out Fmp4.java Gen.java      # or: java -m jdk.compiler/com.sun.tools.javac.Main -d out Fmp4.java Gen.java
    for s in av video_only audio_longer big_frames empty_audio high_profile; do java -cp out Gen $s /tmp/$s.mp4; done
    python3 validate.py /tmp/*.mp4 ; python3 validate.py --prefix /tmp/av.mp4 /tmp/video_only.mp4 ...

`kt_lint.py` checks that the Kotlin's delimiters balance (it cannot find type errors).
