import java.io.*;
import java.util.*;

/** Java transliteration (written from the KOTLIN source) of export/mp4: Mp4Buf, AnnexB, AvcConfig, Esds, SampleSpool, FragmentedMp4Writer.
 *  Used to produce real bytes that validate.py checks independently, because there is no Kotlin compiler in the sandbox.
 *  Keep it in step with the Kotlin. */
public class Fmp4 {
    interface ByteSink { void write(byte[] b, int off, int len) throws IOException; long position(); void flush() throws IOException; }
    static final class StreamSink implements ByteSink { final OutputStream out; long pos; StreamSink(OutputStream o) { out = o; }
        public void write(byte[] b, int off, int len) throws IOException { out.write(b, off, len); pos += len; } public long position() { return pos; } public void flush() throws IOException { out.flush(); } }

    static final class Buf { byte[] buf; int size;
        Buf(int cap) { buf = new byte[cap]; }
        void ensure(int extra) { if (size + extra > buf.length) buf = Arrays.copyOf(buf, Math.max(buf.length * 2, size + extra)); }
        void u8(int v) { ensure(1); buf[size++] = (byte) v; }
        void u16(int v) { ensure(2); buf[size++] = (byte) (v >>> 8); buf[size++] = (byte) v; }
        void u32(long v) { ensure(4); buf[size++] = (byte) (v >>> 24); buf[size++] = (byte) (v >>> 16); buf[size++] = (byte) (v >>> 8); buf[size++] = (byte) v; }
        void u64(long v) { ensure(8); for (int s = 56; s >= 0; s -= 8) buf[size++] = (byte) (v >>> s); }
        void bytes(byte[] b, int off, int len) { ensure(len); System.arraycopy(b, off, buf, size, len); size += len; }
        void bytes(byte[] b) { bytes(b, 0, b.length); }
        void zeros(int n) { ensure(n); Arrays.fill(buf, size, size + n, (byte) 0); size += n; }
        void fourcc(String s) { if (s.length() != 4) throw new IllegalArgumentException(s); for (char c : s.toCharArray()) u8(c); }
        int begin(String type) { int p = size; u32(0L); fourcc(type); return p; }
        int beginFull(String type, int version, int flags) { int p = begin(type); u8(version); u8((flags >>> 16) & 0xFF); u8((flags >>> 8) & 0xFF); u8(flags & 0xFF); return p; }
        void end(int p) { int len = size - p; buf[p] = (byte) (len >>> 24); buf[p + 1] = (byte) (len >>> 16); buf[p + 2] = (byte) (len >>> 8); buf[p + 3] = (byte) len; }
        byte[] toByteArray() { return Arrays.copyOf(buf, size); }
        void writeTo(ByteSink s) throws IOException { s.write(buf, 0, size); } }

    static List<int[]> nals(byte[] d, int off, int len) { int end = off + len; List<int[]> out = new ArrayList<>(); int i = off; int nalStart = -1;
        while (i + 2 < end) { if (d[i] == 0 && d[i + 1] == 0 && d[i + 2] == 1) { if (nalStart >= 0) out.add(new int[]{nalStart, trimZeros(d, nalStart, i)}); nalStart = i + 3; i += 3; } else i++; }
        if (nalStart >= 0 && nalStart < end) out.add(new int[]{nalStart, trimZeros(d, nalStart, end)}); return out; }
    static int trimZeros(byte[] d, int start, int end) { int e = end; while (e > start && d[e - 1] == 0) e--; return e; }
    static int nalType(byte[] d, int s) { return d[s] & 0x1F; }
    static byte[] toLengthPrefixed(byte[] d, int off, int len) { List<int[]> ns = nals(d, off, len); if (ns.isEmpty()) throw new IllegalArgumentException("no start code"); int total = 0;
        for (int[] n : ns) { int t = nalType(d, n[0]); if (t != 7 && t != 8 && t != 9) total += 4 + (n[1] - n[0]); } byte[] out = new byte[total]; int p = 0;
        for (int[] n : ns) { int t = nalType(d, n[0]); if (t == 7 || t == 8 || t == 9) continue; int l = n[1] - n[0]; out[p++] = (byte) (l >>> 24); out[p++] = (byte) (l >>> 16); out[p++] = (byte) (l >>> 8); out[p++] = (byte) l; System.arraycopy(d, n[0], out, p, l); p += l; } return out; }

    static final class Avc { final List<byte[]> sps, pps; Avc(List<byte[]> s, List<byte[]> p) { if (s.isEmpty() || p.isEmpty()) throw new IllegalArgumentException("need SPS and PPS"); if (s.get(0).length < 4) throw new IllegalArgumentException("SPS short"); sps = s; pps = p; }
        int profile() { return sps.get(0)[1] & 0xFF; }
        byte[] avcC() { Buf b = new Buf(64); b.u8(1); b.u8(sps.get(0)[1] & 0xFF); b.u8(sps.get(0)[2] & 0xFF); b.u8(sps.get(0)[3] & 0xFF); b.u8(0xFC | 3); b.u8(0xE0 | sps.size());
            for (byte[] s : sps) { b.u16(s.length); b.bytes(s); } b.u8(pps.size()); for (byte[] p : pps) { b.u16(p.length); b.bytes(p); }
            int pr = profile(); if (pr == 100 || pr == 110 || pr == 122 || pr == 144) { b.u8(0xFC | 1); b.u8(0xF8); b.u8(0xF8); b.u8(0); } return b.toByteArray(); }
        static Avc fromCsd(byte[]... csd) { List<byte[]> sps = new ArrayList<>(), pps = new ArrayList<>(); for (byte[] c : csd) { if (c == null) continue; for (int[] n : nals(c, 0, c.length)) { byte[] nal = Arrays.copyOfRange(c, n[0], n[1]); int t = nalType(c, n[0]); if (t == 7) sps.add(nal); else if (t == 8) pps.add(nal); } } return new Avc(sps, pps); } }

    static void descLen(Buf b, int len) { b.u8(0x80 | ((len >>> 21) & 0x7F)); b.u8(0x80 | ((len >>> 14) & 0x7F)); b.u8(0x80 | ((len >>> 7) & 0x7F)); b.u8(len & 0x7F); }
    static byte[] esds(byte[] asc, int avgBitrate) { Buf dsi = new Buf(16); dsi.u8(0x05); descLen(dsi, asc.length); dsi.bytes(asc);
        Buf dcd = new Buf(32); dcd.u8(0x04); descLen(dcd, 13 + dsi.size); dcd.u8(0x40); dcd.u8(0x15); dcd.u8(0); dcd.u8(0); dcd.u8(0); dcd.u32(Math.max(0, avgBitrate)); dcd.u32(Math.max(0, avgBitrate)); dcd.bytes(dsi.toByteArray());
        byte[] sl = {0x06, (byte) 0x80, (byte) 0x80, (byte) 0x80, 0x01, 0x02}; Buf es = new Buf(64); es.u8(0x03); descLen(es, 3 + dcd.size + sl.length); es.u16(0); es.u8(0); es.bytes(dcd.toByteArray()); es.bytes(sl); return es.toByteArray(); }

    record Spooled(long ptsUs, int flags, byte[] data) {}
    interface AudioSource { Long peekPts() throws IOException; Spooled next() throws IOException; }
    static final class Spool { final File file; DataOutputStream out; long count, bytes; Spool(File f) { file = f; }
        void append(long pts, int flags, byte[] d) throws IOException { if (out == null) out = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(file), 1 << 18)); out.writeLong(pts); out.writeInt(flags); out.writeInt(d.length); out.write(d, 0, d.length); count++; bytes += 16 + d.length; }
        void finishWriting() throws IOException { if (out != null) { out.flush(); out.close(); out = null; } else if (!file.exists()) file.createNewFile(); }
        Reader reader() throws IOException { finishWriting(); return new Reader(file); }
        static final class Reader implements AudioSource { final DataInputStream in; Spooled head; boolean eof; Reader(File f) throws IOException { in = new DataInputStream(new BufferedInputStream(new FileInputStream(f), 1 << 18)); }
            void fill() throws IOException { if (head != null || eof) return; try { long pts = in.readLong(); int flags = in.readInt(); int len = in.readInt(); if (len < 0 || len > 64 * 1024 * 1024) { eof = true; return; } byte[] b = new byte[len]; in.readFully(b); head = new Spooled(pts, flags, b); } catch (EOFException e) { eof = true; } }
            public Long peekPts() throws IOException { fill(); return head == null ? null : head.ptsUs(); }
            public Spooled next() throws IOException { fill(); Spooled h = head; head = null; return h; } } }

    record VideoTrack(int width, int height, Avc avc) {}
    record AudioTrack(int sampleRate, int channelCount, byte[] asc, int bitrate, int samplesPerFrame) {}
    static final long VIDEO_TIMESCALE = 90_000L, MAX_FRAGMENT_BYTES = 16L * 1024 * 1024; static final int AUDIO_CHUNK_SAMPLES = 94, VIDEO_TRACK = 1, AUDIO_TRACK = 2;
    static final int SYNC = 0x02000000, NON_SYNC = 0x01010000, TRUN_FLAGS = 0x000701, TFHD_DEFAULT_BASE_IS_MOOF = 0x020000, TRAF_FIXED = 64, TRAF_PER_SAMPLE = 12, MOOF_FIXED = 24;

    static final class Writer { final ByteSink sink; final VideoTrack video; final AudioTrack audio; final AudioSource audioSource; final long plannedDurationUs, frameDurationUs;
        static final class VS { long pts; boolean key; byte[] data; VS(long p, boolean k, byte[] d) { pts = p; key = k; data = d; } }
        final List<VS> pending = new ArrayList<>(); long pendingBytes, sequence = 1, lastEndPtsUs; boolean started, finished; final List<long[]> videoIndex = new ArrayList<>(), audioIndex = new ArrayList<>(); int fragments; long videoSamples, audioSamples;
        Writer(ByteSink s, VideoTrack v, AudioTrack a, AudioSource src, long planned, long frameDur) { sink = s; video = v; audio = a; audioSource = src; plannedDurationUs = planned; frameDurationUs = frameDur; }
        long videoDts(long pts) { return (pts * VIDEO_TIMESCALE + 500_000L) / 1_000_000L; } long audioDts(long pts) { return (pts * (long) audio.sampleRate() + 500_000L) / 1_000_000L; }
        void start() throws IOException { if (started) throw new IllegalStateException("already started"); Buf b = new Buf(8192); int ftyp = b.begin("ftyp"); b.fourcc("isom"); b.u32(512L); for (String br : new String[]{"isom", "iso5", "iso6", "avc1", "mp41"}) b.fourcc(br); b.end(ftyp); writeMoov(b); b.writeTo(sink); started = true; }
        void matrix(Buf b) { for (long v : new long[]{0x00010000L, 0, 0, 0, 0x00010000L, 0, 0, 0, 0x40000000L}) b.u32(v); }
        void writeMoov(Buf b) { long plannedMs = plannedDurationUs / 1000L; int moov = b.begin("moov"); int mvhd = b.beginFull("mvhd", 1, 0); b.u64(0); b.u64(0); b.u32(1000L); b.u64(plannedMs); b.u32(0x00010000L); b.u16(0x0100); b.u16(0); b.u32(0); b.u32(0); matrix(b); for (int i = 0; i < 6; i++) b.u32(0); b.u32(audio != null ? 3L : 2L); b.end(mvhd);
            int mvex = b.begin("mvex"); int mehd = b.beginFull("mehd", 1, 0); b.u64(plannedMs); b.end(mehd); trex(b, VIDEO_TRACK); if (audio != null) trex(b, AUDIO_TRACK); b.end(mvex); videoTrak(b, plannedMs); if (audio != null) audioTrak(b, plannedMs); b.end(moov); }
        void trex(Buf b, int id) { int p = b.beginFull("trex", 0, 0); b.u32(id); b.u32(1); b.u32(0); b.u32(0); b.u32(0); b.end(p); }
        void tkhd(Buf b, int id, long plannedMs, int volume, int w, int h) { int p = b.beginFull("tkhd", 1, 0x000007); b.u64(0); b.u64(0); b.u32(id); b.u32(0); b.u64(plannedMs); b.u32(0); b.u32(0); b.u16(0); b.u16(0); b.u16(volume); b.u16(0); matrix(b); b.u32((long) w << 16); b.u32((long) h << 16); b.end(p); }
        void mdhd(Buf b, long ts, long dur) { int p = b.beginFull("mdhd", 1, 0); b.u64(0); b.u64(0); b.u32(ts); b.u64(dur); b.u16(0x55C4); b.u16(0); b.end(p); }
        void hdlr(Buf b, String type, String name) { int p = b.beginFull("hdlr", 0, 0); b.u32(0); b.fourcc(type); b.u32(0); b.u32(0); b.u32(0); b.bytes(name.getBytes(java.nio.charset.StandardCharsets.US_ASCII)); b.u8(0); b.end(p); }
        void dinf(Buf b) { int d = b.begin("dinf"); int dref = b.beginFull("dref", 0, 0); b.u32(1); int url = b.beginFull("url ", 0, 1); b.end(url); b.end(dref); b.end(d); }
        void emptyTables(Buf b) { int p = b.beginFull("stts", 0, 0); b.u32(0); b.end(p); p = b.beginFull("stsc", 0, 0); b.u32(0); b.end(p); p = b.beginFull("stsz", 0, 0); b.u32(0); b.u32(0); b.end(p); p = b.beginFull("stco", 0, 0); b.u32(0); b.end(p); }
        void videoTrak(Buf b, long plannedMs) { int trak = b.begin("trak"); tkhd(b, VIDEO_TRACK, plannedMs, 0, video.width(), video.height()); int mdia = b.begin("mdia"); mdhd(b, VIDEO_TIMESCALE, plannedDurationUs * VIDEO_TIMESCALE / 1_000_000L); hdlr(b, "vide", "VideoHandler");
            int minf = b.begin("minf"); int vmhd = b.beginFull("vmhd", 0, 1); b.u16(0); b.u16(0); b.u16(0); b.u16(0); b.end(vmhd); dinf(b); int stbl = b.begin("stbl"); int stsd = b.beginFull("stsd", 0, 0); b.u32(1); int avc1 = b.begin("avc1");
            b.zeros(6); b.u16(1); b.u16(0); b.u16(0); b.u32(0); b.u32(0); b.u32(0); b.u16(video.width()); b.u16(video.height()); b.u32(0x00480000L); b.u32(0x00480000L); b.u32(0); b.u16(1); b.zeros(32); b.u16(0x0018); b.u16(0xFFFF);
            int avcC = b.begin("avcC"); b.bytes(video.avc().avcC()); b.end(avcC); b.end(avc1); b.end(stsd); emptyTables(b); b.end(stbl); b.end(minf); b.end(mdia); b.end(trak); }
        void audioTrak(Buf b, long plannedMs) { AudioTrack a = audio; int trak = b.begin("trak"); tkhd(b, AUDIO_TRACK, plannedMs, 0x0100, 0, 0); int mdia = b.begin("mdia"); mdhd(b, a.sampleRate(), plannedDurationUs * (long) a.sampleRate() / 1_000_000L); hdlr(b, "soun", "SoundHandler");
            int minf = b.begin("minf"); int smhd = b.beginFull("smhd", 0, 0); b.u16(0); b.u16(0); b.end(smhd); dinf(b); int stbl = b.begin("stbl"); int stsd = b.beginFull("stsd", 0, 0); b.u32(1); int mp4a = b.begin("mp4a");
            b.zeros(6); b.u16(1); b.u16(0); b.u16(0); b.u32(0); b.u16(a.channelCount()); b.u16(16); b.u16(0); b.u16(0); b.u32((long) a.sampleRate() << 16); int e = b.beginFull("esds", 0, 0); b.bytes(esds(a.asc(), a.bitrate())); b.end(e); b.end(mp4a); b.end(stsd); emptyTables(b); b.end(stbl); b.end(minf); b.end(mdia); b.end(trak); }
        void writeVideoSample(byte[] d, int off, int len, long pts, boolean key) throws IOException { if (!started || finished) throw new IllegalStateException("not open"); byte[] data = toLengthPrefixed(d, off, len);
            if (!pending.isEmpty()) { if (!(pts > pending.get(pending.size() - 1).pts)) throw new IllegalArgumentException("order"); if (key || pendingBytes >= MAX_FRAGMENT_BYTES) flushVideo(pts); } pending.add(new VS(pts, key, data)); pendingBytes += data.length; }
        static final class Track { int id; long baseDts; long[] durations; int[] sizes; int[] flags; List<byte[]> payloads; int count() { return sizes.length; } long bytes() { long a = 0; for (int s : sizes) a += s; return a; } }
        void flushVideo(long endPts) throws IOException { int n = pending.size(); long[] dts = new long[n + 1]; for (int i = 0; i <= n; i++) dts[i] = i < n ? videoDts(pending.get(i).pts) : videoDts(endPts); long[] dur = new long[n]; for (int i = 0; i < n; i++) dur[i] = dts[i + 1] - dts[i];
            int[] sizes = new int[n]; int[] flags = new int[n]; List<byte[]> payloads = new ArrayList<>(); for (int i = 0; i < n; i++) { sizes[i] = pending.get(i).data.length; flags[i] = pending.get(i).key ? SYNC : NON_SYNC; payloads.add(pending.get(i).data); }
            List<Spooled> aud = new ArrayList<>(); AudioSource src = audioSource; if (audio != null && src != null) { while (true) { Long p = src.peekPts(); if (p == null) break; if (p >= endPts) break; aud.add(src.next()); } }
            Track vt = new Track(); vt.id = VIDEO_TRACK; vt.baseDts = dts[0]; vt.durations = dur; vt.sizes = sizes; vt.flags = flags; vt.payloads = payloads; Track at = aud.isEmpty() ? null : audioRun(aud, src);
            writeFragment(vt, at); videoSamples += n; lastEndPtsUs = endPts; pending.clear(); pendingBytes = 0; }
        Track audioRun(List<Spooled> aud, AudioSource src) throws IOException { AudioTrack a = audio; int n = aud.size(); long[] dts = new long[n]; for (int i = 0; i < n; i++) dts[i] = audioDts(aud.get(i).ptsUs()); Long next = src.peekPts(); long[] dur = new long[n];
            for (int i = 0; i < n; i++) dur[i] = i + 1 < n ? dts[i + 1] - dts[i] : next != null ? audioDts(next) - dts[i] : a.samplesPerFrame(); int[] sizes = new int[n]; int[] flags = new int[n]; List<byte[]> pl = new ArrayList<>();
            for (int i = 0; i < n; i++) { sizes[i] = aud.get(i).data().length; flags[i] = SYNC; pl.add(aud.get(i).data()); } Track t = new Track(); t.id = AUDIO_TRACK; t.baseDts = dts[0]; t.durations = dur; t.sizes = sizes; t.flags = flags; t.payloads = pl; return t; }
        void writeFragment(Track vid, Track aud) throws IOException { List<Track> tracks = new ArrayList<>(); if (vid != null) tracks.add(vid); if (aud != null) tracks.add(aud); int moofSize = MOOF_FIXED; for (Track t : tracks) moofSize += TRAF_FIXED + TRAF_PER_SAMPLE * t.count();
            long payload = 0; for (Track t : tracks) payload += t.bytes(); boolean bigMdat = payload + 8L > 0xFFFFFFFFL; int mdatHeader = bigMdat ? 16 : 8; long moofOffset = sink.position();
            Buf b = new Buf(moofSize + 32); int moof = b.begin("moof"); int mfhd = b.beginFull("mfhd", 0, 0); b.u32(sequence); b.end(mfhd); long dataOffset = moofSize + mdatHeader;
            for (Track t : tracks) { int traf = b.begin("traf"); int tfhd = b.beginFull("tfhd", 0, TFHD_DEFAULT_BASE_IS_MOOF); b.u32(t.id); b.end(tfhd); int tfdt = b.beginFull("tfdt", 1, 0); b.u64(t.baseDts); b.end(tfdt);
                int trun = b.beginFull("trun", 0, TRUN_FLAGS); b.u32(t.count()); b.u32(dataOffset); for (int i = 0; i < t.count(); i++) { b.u32(t.durations[i]); b.u32(t.sizes[i]); b.u32(t.flags[i] & 0xFFFFFFFFL); } b.end(trun); b.end(traf); dataOffset += t.bytes(); }
            b.end(moof); if (b.size != moofSize) throw new IllegalStateException("moof size " + b.size + " != " + moofSize);
            if (bigMdat) { b.u32(1L); b.fourcc("mdat"); b.u64(payload + 16L); } else { b.u32(payload + 8L); b.fourcc("mdat"); } b.writeTo(sink); for (Track t : tracks) for (byte[] p : t.payloads) sink.write(p, 0, p.length); sink.flush();
            if (vid != null) videoIndex.add(new long[]{vid.baseDts, moofOffset}); if (aud != null) audioIndex.add(new long[]{aud.baseDts, moofOffset, vid != null ? 2L : 1L}); if (aud != null) audioSamples += aud.count(); sequence++; fragments++; }
        void finish() throws IOException { if (finished) return; if (!started) throw new IllegalStateException("never started"); if (!pending.isEmpty()) flushVideo(pending.get(pending.size() - 1).pts + frameDurationUs);
            AudioSource src = audioSource; if (audio != null && src != null) { while (src.peekPts() != null) { List<Spooled> chunk = new ArrayList<>(); while (chunk.size() < AUDIO_CHUNK_SAMPLES) { Spooled s = src.next(); if (s == null) break; chunk.add(s); } if (chunk.isEmpty()) break; writeFragment(null, audioRun(chunk, src)); } }
            writeMfra(); sink.flush(); finished = true; }
        void writeMfra() throws IOException { Buf b = new Buf(64 + 25 * (videoIndex.size() + audioIndex.size())); int mfra = b.begin("mfra"); tfra(b, VIDEO_TRACK, videoIndex, false); if (audio != null) tfra(b, AUDIO_TRACK, audioIndex, true);
            int mfro = b.beginFull("mfro", 0, 0); b.u32(b.size - mfra + 4); b.end(mfro); b.end(mfra); b.writeTo(sink); }
        void tfra(Buf b, int id, List<long[]> index, boolean hasTraf) { int p = b.beginFull("tfra", 1, 0); b.u32(id); b.u32(0); b.u32(index.size()); for (long[] e : index) { b.u64(e[0]); b.u64(e[1]); b.u8(hasTraf ? (int) e[2] : 1); b.u8(1); b.u8(1); } b.end(p); } }
}
