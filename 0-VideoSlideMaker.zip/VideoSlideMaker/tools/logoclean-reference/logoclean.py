"""
Reference implementation of the logo / watermark cleaner.

This is the version that was designed, run and measured first; the Kotlin code in
app/src/main/java/com/videoslidemaker/app/logoclean/ is a port of it (same steps, same constants).

Pipeline
  1. DETECT   - a watermark is the one thing that sits at the SAME place in many photos. Every photo is
                shrunk to 640 px, turned into an edge map, and the maps are stacked. Pixels that are an
                edge in (almost) every photo are the logo; scenery edges land in different places and
                vanish. The result is cut into blobs; the compact, small ones are the candidates.
  2. MATCH    - a candidate is remembered as a set of edge points. To decide whether ANOTHER photo has the
                logo (and where, if it moved), the points are slid over that photo's edge map and the
                best "hit rate" is the score. Photos without the logo score low and are left alone.
  3. FILL     - REMOVE: harmonic (diffusion) inpainting on a multi-resolution pyramid, plus grain that
                matches the neighbourhood, feathered into the photo.
                BLUR: a strong blur that is blended in through the same feathered mask.
                Only pixels inside the logo mask are ever changed.
"""
import math
import numpy as np

L_ANALYSIS = 640          # long edge of the analysis image
MIN_COUNT = 3             # a pixel must be an edge in at least this many photos
TAU = 0.70                # ... and in at least this fraction of them
LINK_R = 3                # blobs closer than this (analysis px) are joined
MIN_BLOB_PX = 30
MAX_AREA_FRAC = 0.08      # a logo is smaller than 8 % of the photo
MIN_AREA_FRAC = 0.0002
MAX_ASPECT = 12.0
MATCH_FIXED = 0.65        # score needed when the logo is expected at the same place (+-6 px)
MATCH_FOLLOW = 0.82       # score needed when the whole photo is searched (it has far more chances to be fooled)
OFF_GUARD = 0.60
MAX_QUIET = 400           # quiet check points kept per logo
MAX_MATCH_PTS = 400       # edge points kept per logo for matching (keeps the whole-photo search fast)


# ----------------------------------------------------------------------------- basic image ops
def to_luma(rgb):
    rgb = rgb.astype(np.float32)
    return rgb[..., 0] * 0.299 + rgb[..., 1] * 0.587 + rgb[..., 2] * 0.114


N_ORI = 8   # edge directions (modulo 180 deg), 22.5 deg each


def sobel(l):
    """Returns (magnitude, gx, gy). magnitude = (|gx|+|gy|)/4: a step of height h gives about h. Border = 0."""
    m = np.zeros_like(l, dtype=np.float32)
    gxf = np.zeros_like(m); gyf = np.zeros_like(m)
    gx = (l[:-2, 2:] + 2 * l[1:-1, 2:] + l[2:, 2:]) - (l[:-2, :-2] + 2 * l[1:-1, :-2] + l[2:, :-2])
    gy = (l[2:, :-2] + 2 * l[2:, 1:-1] + l[2:, 2:]) - (l[:-2, :-2] + 2 * l[:-2, 1:-1] + l[:-2, 2:])
    m[1:-1, 1:-1] = (np.abs(gx) + np.abs(gy)) / 4.0
    gxf[1:-1, 1:-1] = gx; gyf[1:-1, 1:-1] = gy
    return m, gxf, gyf


def edge_map(l):
    """-> (edges bool HxW, orientation int8 HxW in 0..7; only meaningful where edges is True)."""
    m, gx, gy = sobel(l)
    hist = np.bincount(np.clip(m, 0, 255).astype(np.int64).ravel(), minlength=256)
    p98 = int(np.searchsorted(np.cumsum(hist), 0.98 * m.size))
    thr = min(40.0, max(10.0, 0.35 * p98))
    e = m > thr
    theta = np.arctan2(gy, gx) % np.pi                      # edge normal direction, 0..pi
    o = (np.floor(theta / np.pi * N_ORI).astype(np.int32)) % N_ORI
    return e, o.astype(np.int8)


def max_filter(b, r):
    """Square (2r+1) max filter on a bool array, done separably."""
    if r <= 0:
        return b.copy()
    h, w = b.shape
    out = b.copy()
    for d in range(1, r + 1):
        out[:, d:] |= b[:, : w - d]
        out[:, : w - d] |= b[:, d:]
    b2 = out.copy()
    for d in range(1, r + 1):
        out[d:, :] |= b2[: h - d, :]
        out[: h - d, :] |= b2[d:, :]
    return out


def min_filter(b, r):
    return ~max_filter(~b, r)


def label4(b):
    """4-connected components of a bool array -> (labels int32, count)."""
    h, w = b.shape
    lab = np.zeros((h, w), np.int32)
    n = 0
    for y0 in range(h):
        for x0 in range(w):
            if b[y0, x0] and lab[y0, x0] == 0:
                n += 1
                stack = [(y0, x0)]
                lab[y0, x0] = n
                while stack:
                    y, x = stack.pop()
                    for yy, xx in ((y - 1, x), (y + 1, x), (y, x - 1), (y, x + 1)):
                        if 0 <= yy < h and 0 <= xx < w and b[yy, xx] and lab[yy, xx] == 0:
                            lab[yy, xx] = n
                            stack.append((yy, xx))
    return lab, n


# ----------------------------------------------------------------------------- 1. detect
def consistency_counts(edge_maps):
    """edge_maps: list of (edges, orient). -> (count of 1-px-dilated edges, count of raw edges, orientation votes[8,h,w])."""
    h, w = edge_maps[0][0].shape
    cnt = np.zeros((h, w), np.int32)
    raw = np.zeros((h, w), np.int32)
    votes = np.zeros((N_ORI, h, w), np.int32)
    for e, o in edge_maps:
        cnt += max_filter(e, 1)
        raw += e
        for k in range(N_ORI):
            votes[k] += (e & (o == k))
    return cnt, raw, votes


class Candidate:
    def __init__(self, box, score, support, pts, counts_ok, quiet=None, ori=None):
        self.box = box              # (l, t, r, b) in analysis px, r/b exclusive
        self.score = score
        self.support = support      # mean fraction of photos that contain each logo pixel
        self.pts = pts              # (y, x) arrays of the consistent edge pixels (thin core)
        self.counts_ok = counts_ok
        self.quiet = quiet          # (y, x) arrays of box pixels that are almost never an edge
        self.ori = ori              # edge direction (0..7) of each core point


def detect(edge_maps, max_candidates=3):
    """Find logo-like blobs that repeat at the same place. Returns candidates, best first."""
    n = len(edge_maps)
    if n < MIN_COUNT:
        return [], None
    h, w = edge_maps[0][0].shape
    cnt, raw, votes = consistency_counts(edge_maps)
    need = max(MIN_COUNT, math.ceil(TAU * n))
    hi = cnt >= need
    linked = max_filter(hi, LINK_R)
    lab, k = label4(linked)
    out = []
    for i in range(1, k + 1):
        comp = (lab == i) & hi
        ys, xs = np.nonzero(comp)
        if len(ys) < MIN_BLOB_PX:
            continue
        # the stacked maps are dilated by 1 px and Sobel adds ~1 px more: shrink by 1 to get the real extent
        l, r = xs.min() + 1, xs.max()
        t, b = ys.min() + 1, ys.max()
        bw, bh = r - l, b - t
        area = bw * bh / float(w * h)
        if area > MAX_AREA_FRAC or area < MIN_AREA_FRAC:
            continue
        aspect = max(bw, bh) / float(max(1, min(bw, bh)))
        if aspect > MAX_ASPECT:
            continue
        if l <= 1 or t <= 1 or r >= w - 1 or b >= h - 1:
            continue                                  # touches the border: letter-box / frame line
        support = float(cnt[comp].mean()) / n
        # thin core of the logo: pixels that are a RAW edge in at least half of the photos
        core = comp & (raw >= max(2, math.ceil(0.5 * n)))
        cy, cx = np.nonzero(core)
        if len(cy) < 40:                       # too thin (soft logo): fall back to the thick set
            cy, cx = ys, xs
        # quiet points: inside the box, almost never an edge in any photo, and >= 3 px from the logo's lines
        near = max_filter(core if len(cy) else comp, 3)
        co = votes[:, cy, cx].argmax(axis=0).astype(np.int8)     # the logo's own edge direction at each core point
        qm = np.zeros_like(raw, dtype=bool)
        qm[t:b, l:r] = (raw[t:b, l:r] <= int(0.1 * n)) & ~near[t:b, l:r]
        qy, qx = np.nonzero(qm)
        if len(qy) > MAX_QUIET:                # keep the work bounded
            sel = np.linspace(0, len(qy) - 1, MAX_QUIET).astype(int)
            qy, qx = qy[sel], qx[sel]
        out.append(Candidate((l, t, r, b), len(ys) * support, support, (cy, cx), need, (qy, qx), co))
    out.sort(key=lambda c: -c.score)
    return out[:max_candidates], cnt


# ----------------------------------------------------------------------------- 2. match
def make_template(cand, shape):
    """Edge points of a candidate, stored relative to the photo size so other sizes can use them."""
    h, w = shape
    ys, xs = cand.pts
    ori = np.asarray(cand.ori, np.int32)
    if len(ys) > MAX_MATCH_PTS:
        sel = np.linspace(0, len(ys) - 1, MAX_MATCH_PTS).astype(int)
        ys, xs, ori = ys[sel], xs[sel], ori[sel]
    l, t, r, b = cand.box
    qy, qx = cand.quiet if cand.quiet is not None else (np.zeros(0, int), np.zeros(0, int))
    return {
        "ptsx": (xs + 0.5) / w, "ptsy": (ys + 0.5) / h, "pto": ori,
        "qx": (qx + 0.5) / w, "qy": (qy + 0.5) / h,
        "box": (l / w, t / h, r / w, b / h),
    }


def match_score(target, tpl, search_r=None, detail=False):
    """
    Slide the template over the photo's edge map. Returns (score, dx, dy); dx/dy in analysis px
    (0,0 = same place). search_r=None searches the whole photo.
      on  = share of the logo's edge points that land on an edge of the photo with the SAME direction
      off = share of the logo's quiet points that are really quiet (no edge) in the photo
      score = on, scaled down when off < OFF_GUARD (a very busy box is not the logo)
    """
    edge_map_t, ori_t = target
    h, w = edge_map_t.shape
    px = np.round(tpl["ptsx"] * w - 0.5).astype(np.int32)
    py = np.round(tpl["ptsy"] * h - 0.5).astype(np.int32)
    po = tpl["pto"]
    qx = np.round(tpl["qx"] * w - 0.5).astype(np.int32)
    qy = np.round(tpl["qy"] * h - 0.5).astype(np.int32)
    # one dilated map per edge direction; a direction also accepts its two neighbours (22.5 deg jitter)
    dil = [max_filter(edge_map_t & (ori_t == k), 1) for k in range(N_ORI)]
    ed = [(dil[k] | dil[(k - 1) % N_ORI] | dil[(k + 1) % N_ORI]).astype(np.float32) for k in range(N_ORI)]
    raw = edge_map_t.astype(np.float32)
    allx = np.concatenate([px, qx]); ally = np.concatenate([py, qy])
    dx_lo, dx_hi = -int(allx.min()), w - 1 - int(allx.max())   # every point must stay inside the photo
    dy_lo, dy_hi = -int(ally.min()), h - 1 - int(ally.max())
    if search_r is not None:
        dx_lo, dx_hi = max(dx_lo, -search_r), min(dx_hi, search_r)
        dy_lo, dy_hi = max(dy_lo, -search_r), min(dy_hi, search_r)
    if dx_hi < dx_lo or dy_hi < dy_lo:
        return (0.0, 0, 0, 0.0, 0.0) if detail else (0.0, 0, 0)
    nx, ny = dx_hi - dx_lo + 1, dy_hi - dy_lo + 1
    on = np.zeros((ny, nx), np.float32)
    for k in range(len(px)):
        on += ed[po[k]][py[k] + dy_lo: py[k] + dy_lo + ny, px[k] + dx_lo: px[k] + dx_lo + nx]
    on /= max(1, len(px))
    iy, ix = np.unravel_index(np.argmax(on), on.shape)
    dx, dy = int(ix + dx_lo), int(iy + dy_lo)
    s_on = float(on[iy, ix])
    if len(qx):
        busy = float(sum(raw[qy[k] + dy, qx[k] + dx] for k in range(len(qx)))) / len(qx)
        off = 1.0 - busy
    else:
        off = 1.0
    score = s_on * min(1.0, off / OFF_GUARD)
    return (score, dx, dy, s_on, off) if detail else (score, dx, dy)


# ----------------------------------------------------------------------------- mask
def refine_mask(pts, box, shape, gap_h, gap_v, grow):
    """Solid logo mask (analysis px, whole-photo sized) from the logo's edge pixels."""
    h, w = shape
    l, t, r, b = box
    m = np.zeros((h, w), bool)
    ys, xs = pts
    m[ys, xs] = True
    sub = m[t:b, l:r].copy()
    # close gaps along rows, then along columns
    def close_rows(a, gap):
        o = a.copy()
        for y in range(a.shape[0]):
            idx = np.nonzero(a[y])[0]
            if len(idx) < 2:
                continue
            d = np.diff(idx)
            for j in np.nonzero(d <= gap)[0]:
                o[y, idx[j]:idx[j + 1] + 1] = True
        return o
    sub = close_rows(sub, gap_h)
    sub = close_rows(sub.T, gap_v).T | sub
    m[t:b, l:r] = sub
    return max_filter(m, grow)


# ----------------------------------------------------------------------------- 3. fill
def box_blur_f(a, r):
    """Mean filter radius r with edge replication on a 2-D float array (separable, via cumsum)."""
    if r <= 0:
        return a.copy()
    p = np.pad(a, ((r, r), (r, r)), mode="edge")
    c = np.cumsum(p, axis=1, dtype=np.float64)
    c = np.concatenate([np.zeros((p.shape[0], 1)), c], axis=1)
    p = (c[:, 2 * r + 1:] - c[:, :-(2 * r + 1)]) / (2 * r + 1)
    c = np.cumsum(p, axis=0, dtype=np.float64)
    c = np.concatenate([np.zeros((1, p.shape[1])), c], axis=0)
    return ((c[2 * r + 1:, :] - c[:-(2 * r + 1), :]) / (2 * r + 1)).astype(np.float32)


def gauss_blur(a, sigma):
    """Three box passes approximate a Gaussian."""
    if sigma < 0.5:
        return a.copy()
    r = max(1, int(round(math.sqrt(12 * sigma * sigma / 3 + 1) / 2 - 0.5)))
    out = a
    for _ in range(3):
        out = box_blur_f(out, r)
    return out


def _down(img, known):
    h, w = known.shape
    h2, w2 = (h + 1) // 2, (w + 1) // 2
    pi = np.zeros((h2 * 2, w2 * 2, img.shape[2]), np.float32)
    pk = np.zeros((h2 * 2, w2 * 2), np.float32)
    pi[:h, :w] = img * known[..., None]
    pk[:h, :w] = known
    s = pi[0::2, 0::2] + pi[1::2, 0::2] + pi[0::2, 1::2] + pi[1::2, 1::2]
    c = pk[0::2, 0::2] + pk[1::2, 0::2] + pk[0::2, 1::2] + pk[1::2, 1::2]
    k2 = c > 0
    d = np.where(k2[..., None], s / np.maximum(c, 1)[..., None], 0).astype(np.float32)
    return d, k2.astype(np.float32)


def _jacobi(img, known, iters):
    unk = known < 0.5
    for _ in range(iters):
        p = np.pad(img, ((1, 1), (1, 1), (0, 0)), mode="edge")
        avg = (p[:-2, 1:-1] + p[2:, 1:-1] + p[1:-1, :-2] + p[1:-1, 2:]) * 0.25
        img = np.where(unk[..., None], avg, img)
    return img


def harmonic_fill(img, mask, iters=60):
    """img float HxWx3, mask bool (True = to fill). Multi-resolution diffusion fill."""
    known = (~mask).astype(np.float32)
    if known.sum() == 0:
        return img
    levels = [(img * known[..., None], known)]
    while True:
        im, kn = levels[-1]
        if min(kn.shape) < 8 or (kn < 0.5).sum() == 0 or max(kn.shape) <= 12:
            break
        d, k2 = _down(im, kn)
        levels.append((d, k2))
        if (k2 < 0.5).sum() == 0:
            break
    # coarsest level: start from the mean of the known pixels
    im, kn = levels[-1]
    mean = (im * kn[..., None]).sum((0, 1)) / max(1.0, kn.sum())
    cur = np.where(kn[..., None] > 0.5, im, mean).astype(np.float32)
    cur = _jacobi(cur, kn, iters * 3)
    for li in range(len(levels) - 2, -1, -1):
        im, kn = levels[li]
        h, w = kn.shape
        up = np.repeat(np.repeat(cur, 2, axis=0), 2, axis=1)[:h, :w]
        cur = np.where(kn[..., None] > 0.5, im, up)
        cur = _jacobi(cur, kn, iters)
    return cur


def estimate_grain(crop, mask, ring=6):
    """Std-dev of the fine detail just outside the mask (the photo's own noise)."""
    ring_m = max_filter(mask, ring) & ~mask
    if ring_m.sum() < 20:
        return 0.0
    l = crop.mean(axis=2)
    hp = l - gauss_blur(l, 1.5)
    return float(hp[ring_m].std())


def inpaint(rgb, mask, grain=0.8, feather=1.5, seed=1234):
    """
    rgb uint8 HxWx3 crop WITH context around the logo, mask bool (True = logo).
    Only masked pixels (plus a soft feather) change.
    """
    img = rgb.astype(np.float32)
    fill = harmonic_fill(img, mask)
    sigma = estimate_grain(img, mask) * grain
    if sigma > 0:
        rng = np.random.RandomState(seed)
        noise = rng.normal(0, sigma, size=mask.shape).astype(np.float32)
        noise = noise - gauss_blur(noise, 1.0) * 0.5          # mildly spatially correlated like real grain
        fill = fill + noise[..., None]
    soft = gauss_blur(mask.astype(np.float32), feather)
    soft = np.where(mask, 1.0, soft)
    out = fill * soft[..., None] + img * (1 - soft[..., None])
    return np.clip(out + 0.5, 0, 255).astype(np.uint8)


def blur_logo(rgb, mask, sigma, feather=1.5):
    img = rgb.astype(np.float32)
    blurred = np.stack([gauss_blur(img[..., c], sigma) for c in range(3)], axis=2)
    soft = gauss_blur(mask.astype(np.float32), feather)
    soft = np.where(mask, 1.0, soft)
    out = blurred * soft[..., None] + img * (1 - soft[..., None])
    return np.clip(out + 0.5, 0, 255).astype(np.uint8)


# ----------------------------------------------------------------------------- full-resolution helpers
def upscale_mask(mask_a, box_a, scale, full_box):
    """Bilinear-upsample the analysis-resolution mask (cut to box_a) to full_box = (X0,Y0,X1,Y1) full-res px."""
    X0, Y0, X1, Y1 = full_box
    l, t, r, b = box_a
    sub = mask_a.astype(np.float32)
    h, w = sub.shape
    ys = (np.arange(Y0, Y1) + 0.5) * scale - 0.5
    xs = (np.arange(X0, X1) + 0.5) * scale - 0.5
    y0 = np.clip(np.floor(ys).astype(int), 0, h - 1); y1 = np.clip(y0 + 1, 0, h - 1); fy = np.clip(ys - y0, 0, 1)
    x0 = np.clip(np.floor(xs).astype(int), 0, w - 1); x1 = np.clip(x0 + 1, 0, w - 1); fx = np.clip(xs - x0, 0, 1)
    a = sub[y0][:, x0] * (1 - fx) + sub[y0][:, x1] * fx
    c = sub[y1][:, x0] * (1 - fx) + sub[y1][:, x1] * fx
    return (a * (1 - fy)[:, None] + c * fy[:, None]) > 0.5


def clean_photo(rgb, cand, tpl_shape, scale, mode="remove", dx=0, dy=0, blur_strength=0.5, pad_px=None):
    """
    Clean ONE photo (uint8 HxWx3, any size) whose analysis scale is `scale` (analysis px per full px).
    cand = detected logo; (dx, dy) = where the logo is in this photo relative to the template, analysis px.
    Only the logo's mask (plus a few px) is changed; everything else is returned bit-identical.
    """
    H, W = rgb.shape[:2]
    ah, aw = tpl_shape
    mask_a = refine_mask(cand.pts, cand.box, tpl_shape, gap_h=12, gap_v=4, grow=1)
    l, t, r, b = cand.box
    ml = max(0, l - 3); mt = max(0, t - 3); mr = min(aw, r + 3); mb = min(ah, b + 3)
    sub = mask_a[mt:mb, ml:mr]
    inv = 1.0 / scale
    # full-res rectangle of the (shifted) logo
    fx0 = int(math.floor((ml + dx) * inv)); fy0 = int(math.floor((mt + dy) * inv))
    fx1 = int(math.ceil((mr + dx) * inv)); fy1 = int(math.ceil((mb + dy) * inv))
    fm = upscale_mask(sub, (0, 0, sub.shape[1], sub.shape[0]), scale, (0, 0, fx1 - fx0, fy1 - fy0))
    pad = pad_px if pad_px is not None else max(2, int(round(0.9 * inv)))     # covers the 1-px analysis jitter
    fm = max_filter(fm, pad)
    # work window = mask rectangle + context
    ctx = max(24, int(0.6 * max(fm.shape)))
    X0, Y0 = max(0, fx0 - ctx), max(0, fy0 - ctx)
    X1, Y1 = min(W, fx1 + ctx), min(H, fy1 + ctx)
    full_mask = np.zeros((Y1 - Y0, X1 - X0), bool)
    ys0, xs0 = fy0 - Y0, fx0 - X0
    cy0, cx0 = max(0, -ys0), max(0, -xs0)
    hh, ww = fm.shape
    full_mask[max(0, ys0):min(Y1 - Y0, ys0 + hh), max(0, xs0):min(X1 - X0, xs0 + ww)] = \
        fm[cy0:cy0 + min(Y1 - Y0, ys0 + hh) - max(0, ys0), cx0:cx0 + min(X1 - X0, xs0 + ww) - max(0, xs0)]
    crop = rgb[Y0:Y1, X0:X1]
    if mode == "remove":
        res = inpaint(crop, full_mask)
    else:
        sigma = (0.12 + 0.48 * blur_strength) * min(fm.shape)
        res = blur_logo(crop, full_mask, sigma, feather=max(2.0, 0.45 * sigma))
    out = rgb.copy()
    out[Y0:Y1, X0:X1] = res
    return out, (X0, Y0, X1, Y1), full_mask


def rounded_rect_mask(shape, x0, y0, x1, y1, radius):
    """Rounded rectangle (x1/y1 exclusive) - the Kotlin roundedRectMask. Used for a box the user drew by hand."""
    h, w = shape
    rad = max(0, min(radius, (x1 - x0) // 2, (y1 - y0) // 2))
    m = np.zeros((h, w), bool)
    for y in range(max(0, y0), min(h, y1)):
        cy = y0 + rad if y < y0 + rad else (y1 - rad - 1 if y >= y1 - rad else y)
        for x in range(max(0, x0), min(w, x1)):
            cx = x0 + rad if x < x0 + rad else (x1 - rad - 1 if x >= x1 - rad else x)
            if (x - cx) ** 2 + (y - cy) ** 2 <= rad * rad:
                m[y, x] = True
    return m
