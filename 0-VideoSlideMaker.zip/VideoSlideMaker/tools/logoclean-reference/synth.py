"""Builds test frames: the REAL 4RABET logo (cut out of the user's screenshot) pasted at a fixed place on
many different backgrounds, plus frames without it. Used by experiment.py / mirror tests."""
import cv2
import numpy as np

import os
SRC = os.path.join(os.path.dirname(os.path.abspath(__file__)), "sample", "screenshot_with_logo.jpg")
LOGO_BOX = (900, 345, 1063, 392)        # x0, y0, x1, y1 of pill + tagline in the screenshot


def load_source():
    return cv2.cvtColor(cv2.imread(SRC), cv2.COLOR_BGR2RGB)


def logo_rgba(src):
    x0, y0, x1, y1 = LOGO_BOX
    patch = src[y0:y1, x0:x1].astype(np.float32)
    h, w = patch.shape[:2]
    alpha = np.zeros((h, w), np.float32)
    # pill: rounded rectangle, fully opaque
    px0, px1, py1 = 919 - x0, 1045 - x0, 378 - y0
    pill = np.zeros((h, w), np.uint8)
    cv2.rectangle(pill, (px0 + 6, 0), (px1 - 6, py1), 255, -1)
    cv2.rectangle(pill, (px0, 6), (px1, py1 - 6), 255, -1)
    for cx, cy in ((px0 + 6, 6), (px1 - 6, 6), (px0 + 6, py1 - 6), (px1 - 6, py1 - 6)):
        cv2.circle(pill, (cx, cy), 6, 255, -1)
    alpha = np.maximum(alpha, pill / 255.0)
    # tagline: bright pixels below the pill become white text with soft edges
    lum = patch.mean(axis=2)
    tag = np.clip((lum - 170) / 45.0, 0, 1)
    tag[: py1 + 1, :] = 0
    colour = patch.copy()
    colour[tag > 0] = (255, 250, 245)
    alpha = np.maximum(alpha, tag)
    return colour, alpha


def paste(frame, colour, alpha, x0=None, y0=None):
    f = frame.astype(np.float32)
    h, w = alpha.shape
    x0 = LOGO_BOX[0] if x0 is None else x0
    y0 = LOGO_BOX[1] if y0 is None else y0
    reg = f[y0:y0 + h, x0:x0 + w]
    f[y0:y0 + h, x0:x0 + w] = reg * (1 - alpha[..., None]) + colour * alpha[..., None]
    return f.clip(0, 255).astype(np.uint8)


def clean_plate(src):
    x0, y0, x1, y1 = LOGO_BOX
    m = np.zeros(src.shape[:2], np.uint8)
    m[y0 - 4:y1 + 4, x0 - 4:x1 + 4] = 255
    return cv2.cvtColor(cv2.inpaint(cv2.cvtColor(src, cv2.COLOR_RGB2BGR), m, 5, cv2.INPAINT_TELEA), cv2.COLOR_BGR2RGB)


def procedural(rng, w=1920, h=754):
    """A made-up 'scene': blurry colour blobs + a few hard-edged shapes + noise."""
    base = np.zeros((h, w, 3), np.float32) + rng.uniform(40, 200, 3)
    for _ in range(rng.randint(4, 9)):
        c = rng.uniform(0, 255, 3)
        cx, cy, r = rng.randint(0, w), rng.randint(0, h), rng.randint(80, 500)
        yy, xx = np.ogrid[:h, :w]
        a = np.exp(-(((xx - cx) ** 2 + (yy - cy) ** 2) / (2.0 * (r / 2) ** 2)))[..., None]
        base = base * (1 - a) + c * a
    img = base.clip(0, 255).astype(np.uint8)
    for _ in range(rng.randint(3, 10)):
        c = tuple(int(v) for v in rng.uniform(0, 255, 3))
        x, y = rng.randint(0, w - 100), rng.randint(0, h - 80)
        cv2.rectangle(img, (x, y), (x + rng.randint(40, 400), y + rng.randint(30, 300)), c, -1 if rng.rand() < .5 else 3)
    img = cv2.GaussianBlur(img, (0, 0), rng.uniform(0.5, 4.0))
    img = img.astype(np.float32) + rng.normal(0, rng.uniform(1, 6), img.shape)
    return img.clip(0, 255).astype(np.uint8)


def variant_of_source(plate, rng):
    """A different 'shot' made from the real photo: zoom / shift / flip / colour change."""
    h, w = plate.shape[:2]
    z = rng.uniform(1.0, 2.6)
    cw, ch = int(w / z), int(h / z)
    x, y = rng.randint(0, w - cw + 1), rng.randint(0, h - ch + 1)
    crop = plate[y:y + ch, x:x + cw]
    if rng.rand() < .5:
        crop = crop[:, ::-1]
    out = cv2.resize(np.ascontiguousarray(crop), (w, h), interpolation=cv2.INTER_CUBIC).astype(np.float32)
    out = out * rng.uniform(0.6, 1.3) + rng.uniform(-30, 30)
    out = out * rng.uniform(0.85, 1.15, 3)
    return out.clip(0, 255).astype(np.uint8)


def jpeg(img, q=85):
    ok, buf = cv2.imencode(".jpg", cv2.cvtColor(img, cv2.COLOR_RGB2BGR), [cv2.IMWRITE_JPEG_QUALITY, q])
    return cv2.cvtColor(cv2.imdecode(buf, cv2.IMREAD_COLOR), cv2.COLOR_BGR2RGB)


def make_set(n, n_without=0, seed=1, kind="mixed", x0=None, y0=None):
    """Returns (frames, has_logo flags). kind: 'mixed' | 'procedural' | 'source'"""
    rng = np.random.RandomState(seed)
    src = load_source()
    colour, alpha = logo_rgba(src)
    plate = clean_plate(src)
    frames, flags = [], []
    for i in range(n):
        if kind == "procedural" or (kind == "mixed" and i % 2 == 0):
            bg = procedural(rng)
        else:
            bg = variant_of_source(plate, rng)
        with_logo = i >= n_without
        frame = paste(bg, colour, alpha, x0, y0) if with_logo else bg
        frames.append(jpeg(frame))
        flags.append(with_logo)
    return frames, flags
