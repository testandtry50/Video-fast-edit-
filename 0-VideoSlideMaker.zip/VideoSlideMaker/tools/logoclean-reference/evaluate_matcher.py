import numpy as np, logoclean as lc, synth
from common import analysis
frames, flags = synth.make_set(10, 2, seed=7, kind='mixed')
ems = [analysis(f)[0] for f in frames]
cands, cnt = lc.detect(ems); tpl = lc.make_template(cands[0], ems[0][0].shape)
def scores(fr, r): return np.array([lc.match_score(analysis(f)[0], tpl, r)[0] for f in fr])
W, WO = {}, {}
for kind in ('mixed','source','procedural'):
    W[kind]  = np.concatenate([scores(synth.make_set(20,0,seed=500+i,kind=kind)[0], None) for i in range(2)])
    WO[kind] = np.concatenate([scores(synth.make_set(20,20,seed=600+i,kind=kind)[0], None) for i in range(2)])
for kind in W:
    print(f"{kind:10s} full-search: WITH min {W[kind].min():.2f} p5 {np.percentile(W[kind],5):.2f} | WITHOUT max {WO[kind].max():.2f} p95 {np.percentile(WO[kind],95):.2f}"
          f"   FN@{lc.MATCH_FOLLOW}: {(W[kind]<lc.MATCH_FOLLOW).mean()*100:.0f}%  FP@{lc.MATCH_FOLLOW}: {(WO[kind]>=lc.MATCH_FOLLOW).mean()*100:.0f}%")
W2 = {k: np.concatenate([scores(synth.make_set(20,0,seed=700+i,kind=k)[0], 6) for i in range(2)]) for k in W}
WO2= {k: np.concatenate([scores(synth.make_set(20,20,seed=800+i,kind=k)[0], 6) for i in range(2)]) for k in W}
for kind in W2:
    print(f"{kind:10s} fixed(+-6): WITH min {W2[kind].min():.2f} | WITHOUT max {WO2[kind].max():.2f}   FN@{lc.MATCH_FIXED}: {(W2[kind]<lc.MATCH_FIXED).mean()*100:.0f}%  FP@{lc.MATCH_FIXED}: {(WO2[kind]>=lc.MATCH_FIXED).mean()*100:.0f}%")
