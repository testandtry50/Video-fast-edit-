"""Runs the whole pipeline on the bundled screenshot and writes sample/before_after.png.
   python3 demo.py        (needs numpy + opencv-python only for this demo; the algorithm itself is numpy)"""
import os, cv2, numpy as np
import logoclean as lc, synth
from common import analysis

HERE = os.path.dirname(os.path.abspath(__file__))
# 1. a handful of other frames that carry the same logo at the same spot (stand-ins for "your other photos")
frames, _ = synth.make_set(10, 0, seed=7, kind="mixed")
maps = [analysis(f)[0] for f in frames]
scale = analysis(frames[0])[1]
cands, _ = lc.detect(maps)
cand = cands[0]
shape = maps[0][0].shape
print("detected logo box (px):", [round(v / scale) for v in cand.box], " support: %.0f%%" % (cand.support * 100))

# 2. clean the real screenshot both ways
src = synth.load_source()
removed, _, _ = lc.clean_photo(src, cand, shape, scale, "remove")
blurred, _, _ = lc.clean_photo(src, cand, shape, scale, "blur", blur_strength=0.4)
diff = np.abs(removed.astype(int) - src.astype(int)).sum(2) > 0
print("pixels changed by REMOVE: %d of %d (%.2f%%)" % (diff.sum(), diff.size, 100.0 * diff.mean()))

crop = lambda im: cv2.resize(im[300:430, 860:1110], None, fx=2.5, fy=2.5, interpolation=cv2.INTER_CUBIC)
rows = []
for im, label in ((src, "original"), (removed, "REMOVE"), (blurred, "BLUR")):
    p = crop(im).copy()
    cv2.putText(p, label, (8, 26), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 255, 0), 2)
    rows.append(p)
out = os.path.join(HERE, "sample", "before_after.png")
cv2.imwrite(out, cv2.cvtColor(np.hstack(rows), cv2.COLOR_RGB2BGR))
cv2.imwrite(os.path.join(HERE, "sample", "removed_full.jpg"), cv2.cvtColor(removed, cv2.COLOR_RGB2BGR), [cv2.IMWRITE_JPEG_QUALITY, 95])
print("wrote", out)
