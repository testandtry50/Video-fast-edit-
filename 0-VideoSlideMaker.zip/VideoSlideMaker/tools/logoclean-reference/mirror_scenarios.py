"""The exact synthetic scenarios used by the Kotlin unit tests (LogoCleanTest.kt), run through the
Python reference so the numbers asserted in Kotlin are measured, not guessed."""
import math
import numpy as np
import logoclean as lc

W, H = 320, 200
LOGO = (130, 90, 190, 112)   # x0, y0, x1, y1 (exclusive)


def frame(k, with_logo):
    ys, xs = np.mgrid[0:H, 0:W].astype(np.float64)
    v = 110 + 55 * np.sin(0.045 * xs + 0.9 * k) * np.cos(0.037 * ys - 0.7 * k) + 35 * np.sin(0.011 * (xs + ys) * (k + 1))
    bx, by = (37 * k) % 200, (53 * k) % 120
    v[by:by + 40, bx:bx + 50] += 70
    if with_logo:
        x0, y0, x1, y1 = LOGO
        v[y0:y1, x0:x1] = 25
        for x in range(140, 180):
            if ((x - 140) // 5) % 2 == 0:
                v[95:107, x] = 235
    return np.clip(v, 0, 255).astype(np.float32)


def edges(k, with_logo):
    return lc.edge_map(frame(k, with_logo))


if __name__ == "__main__":
    maps = [edges(k, True) for k in range(6)]
    cands, cnt = lc.detect(maps)
    print("candidates:", [(c.box, round(c.support, 2), len(c.pts[0])) for c in cands])
    tpl = lc.make_template(cands[0], (H, W))
    for name, k, wl in (("with logo  k=7", 7, True), ("with logo  k=9", 9, True), ("no logo    k=8", 8, False), ("no logo    k=11", 11, False)):
        e = edges(k, wl)
        s_fixed = lc.match_score(e, tpl, lc.FIXED_R if hasattr(lc, "FIXED_R") else 6, detail=True)
        s_full = lc.match_score(e, tpl, None, detail=True)
        print(f"{name}: fixed score {s_fixed[0]:.2f} (dx,dy={s_fixed[1]},{s_fixed[2]})  full score {s_full[0]:.2f} (dx,dy={s_full[1]},{s_full[2]})")
    # logo moved by (+25,+17) in a new frame -> found by whole-photo search
    f = frame(7, False)
    x0, y0, x1, y1 = LOGO
    dx, dy = 25, 17
    f[y0 + dy:y1 + dy, x0 + dx:x1 + dx] = 25
    for x in range(140, 180):
        if ((x - 140) // 5) % 2 == 0:
            f[95 + dy:107 + dy, x + dx] = 235
    s = lc.match_score(lc.edge_map(f), tpl, None, detail=True)
    print("moved (+25,+17): full-search score %.2f at (dx,dy)=(%d,%d)" % (s[0], s[1], s[2]))
    # frames where only 2 of 6 have the logo -> nothing repeats
    maps2 = [edges(k, k < 2) for k in range(6)]
    print("2 of 6 frames with logo -> candidates:", len(lc.detect(maps2)[0]))
    # inpaint on a linear gradient
    ys, xs = np.mgrid[0:80, 0:120]
    g = (40 + 1.2 * xs + 0.8 * ys).clip(0, 255)
    rgb = np.stack([g, g * 0.9, g * 0.8], axis=2).astype(np.uint8)
    mask = np.zeros((80, 120), bool); mask[30:50, 40:80] = True
    out = lc.inpaint(rgb, mask)
    err = np.abs(out.astype(float) - rgb.astype(float)).mean(axis=2)
    far = ~lc.max_filter(mask, 8)
    print("inpaint gradient: mean|err| inside mask = %.2f, max inside = %.1f, changed outside(>8px) = %d" % (err[mask].mean(), err[mask].max(), int((err[far] > 0).sum())))
    out2 = lc.blur_logo(rgb, mask, 6.0, feather=3.0)
    print("blur: changed outside(>12px) = %d" % int((np.abs(out2.astype(int) - rgb.astype(int)).sum(2)[~lc.max_filter(mask, 12)] > 0).sum()))
