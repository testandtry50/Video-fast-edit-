import time, cv2, numpy as np
import logoclean as lc, synth

def analysis(img):
    h, w = img.shape[:2]
    s = lc.L_ANALYSIS / max(h, w)
    small = cv2.resize(img, (round(w*s), round(h*s)), interpolation=cv2.INTER_AREA)
    return lc.edge_map(lc.to_luma(small)), s

truth = synth.LOGO_BOX
def iou(a, b):
    ix = max(0, min(a[2], b[2]) - max(a[0], b[0])); iy = max(0, min(a[3], b[3]) - max(a[1], b[1]))
    inter = ix*iy; u = (a[2]-a[0])*(a[3]-a[1]) + (b[2]-b[0])*(b[3]-b[1]) - inter
    return inter/u

