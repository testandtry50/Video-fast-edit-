#!/usr/bin/env bash
# Compiles ProjectRepository (+ the model classes it needs) with a real Kotlin compiler and runs the harness against a
# temporary folder. Needs: kotlinc 1.9.x on PATH (or KOTLINC=...), a JDK, org.json (ORGJSON=path/to/json.jar) and the
# coroutines jar that ships in kotlinc's lib folder (COROUTINES=...). See README.md in this folder.
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
A="$HERE/../../app/src/main/java/com/videoslidemaker/app"
KOTLINC="${KOTLINC:-kotlinc}"
: "${ORGJSON:?set ORGJSON to an org.json jar (the Android unit tests use org.json:json:20240303)}"
: "${COROUTINES:?set COROUTINES to kotlinx-coroutines-core-jvm.jar}"
STDLIB="${STDLIB:-$(dirname "$(command -v "$KOTLINC")")/../lib/kotlin-stdlib.jar}"
OUT="$(mktemp -d)"
"$KOTLINC" -nowarn -jvm-target 1.8 -cp "$ORGJSON:$COROUTINES" \
  "$HERE/AndroidUriStub.kt" "$HERE/AndroidContextStub.kt" \
  "$A"/model/*.kt "$A"/align/AlignmentState.kt "$A"/align/AlignmentModels.kt "$A"/logoclean/LogoModels.kt \
  "$A"/voicefx/VoiceFxSettings.kt "$A"/adjust/AdjustModels.kt "$A"/adjust/AdjustLogCodec.kt "$A"/adjust/SlideTimes.kt \
  "$A"/data/ScriptParser.kt "$A"/data/TimestampParser.kt "$A"/data/TranscriptFormats.kt \
  "$A"/data/ProjectIndex.kt "$A"/data/ProjectRepository.kt "$HERE/RepoHarness.kt" -d "$OUT"
java -cp "$OUT:$ORGJSON:$STDLIB:$COROUTINES" harness.RepoHarnessKt
