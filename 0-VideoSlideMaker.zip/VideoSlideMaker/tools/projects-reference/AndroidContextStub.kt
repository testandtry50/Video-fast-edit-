package android.content

open class Context(val filesDirPath: java.io.File) {
    val filesDir: java.io.File get() = filesDirPath
    val applicationContext: Context get() = this
}
