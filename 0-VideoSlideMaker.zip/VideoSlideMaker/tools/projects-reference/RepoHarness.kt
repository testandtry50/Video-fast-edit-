package harness

import android.content.Context
import android.net.Uri
import com.videoslidemaker.app.data.ProjectIndexCodec
import com.videoslidemaker.app.data.ProjectRepository
import com.videoslidemaker.app.logoclean.CleanTarget
import com.videoslidemaker.app.logoclean.LogoCleanMode
import com.videoslidemaker.app.model.*
import kotlinx.coroutines.*
import java.io.File

var passed = 0
var failed = 0
fun check(name: String, ok: Boolean, detail: String = "") {
    if (ok) passed++ else { failed++; println("  FAIL: $name $detail") }
}

fun tmpDir(): File = java.nio.file.Files.createTempDirectory("vsm").toFile()

fun richState(tag: String, slides: Int = 5, images: Int = 4, cleanedDir: File? = null): UiState {
    val imgs = (0 until images).map { i ->
        if (cleanedDir != null && i == 0) {
            cleanedDir.mkdirs()
            val f = File(cleanedDir, "img${tag}0_123.jpg"); f.writeText("cleaned-$tag")
            PoolImage("img${tag}0", Uri.fromFile(f), "photo0.jpg", 800, 600, 2.5, true,
                Uri.parse("content://media/orig0"), LogoCleanMode.REMOVE, mapOf(CleanTarget.LOGO to LogoCleanMode.REMOVE))
        } else PoolImage("img$tag$i", Uri.parse("content://media/$tag/$i"), "photo$i.jpg", 1000 + i, 700, null)
    }
    return UiState(
        step = AppStep.PHOTOS, scriptLoaded = slides > 0,
        slides = (0 until slides).map { SentenceSlide(it * 3.0, "line $tag $it", if (it < images) "img$tag$it" else null, if (it == 1) 2.5 else null) },
        images = imgs,
        textOverlays = listOf(TextOverlay("t1", "Name $tag", 1.0, 2.0, 0.4f, 0.8f, OverlayStyle.TAG)),
        settings = ExportSettings(aspectRatio = AspectRatioOption.R9_16, quality = QualityOption.P1080, defaultDurationSec = 7)
    )
}

fun sameProject(a: UiState, b: UiState) =
    a.slides == b.slides && a.images == b.images && a.textOverlays == b.textOverlays &&
        a.settings.aspectRatio == b.settings.aspectRatio && a.settings.quality == b.settings.quality &&
        a.settings.defaultDurationSec == b.settings.defaultDurationSec

fun main() = runBlocking {
    // ---------------------------------------------------------------- 1. very first start
    run {
        val d = tmpDir(); val repo = ProjectRepository(Context(d))
        val lib = repo.openLibrary()
        check("fresh: empty list", lib.index.projects.isEmpty() && lib.migratedId == null)
        val (info, idx) = repo.create(null)
        check("fresh: first project is 'Project 1'", info.name == "Project 1" && idx.projects.size == 1)
        check("fresh: file exists", repo.hasFile(info.id))
        val loaded = repo.load(info.id)
        check("fresh: loads as empty", loaded != null && loaded.slides.isEmpty() && loaded.images.isEmpty())
        repo.setActive(info.id)
        val again = ProjectRepository(Context(d)).openLibrary()
        check("fresh: list + open project survive restart", again.index.activeId == info.id && again.index.projects.size == 1 && again.migratedId == null)
    }

    // ---------------------------------------------------------------- 2. migration from the single-draft versions
    run {
        val d = tmpDir()
        val cleaned = File(d, "logoclean").also { it.mkdirs() }
        val cf = File(cleaned, "p1_999.jpg"); cf.writeText("x")
        val legacy = """{"step":"MATCH","defaultDurationSec":4,"voiceLocaleTag":"hi-IN","aspectRatio":"R4_5",
            "slides":[{"t":0.0,"text":"hello","assignedImageId":"p1"},{"t":3.5,"text":"world"}],
            "images":[{"id":"p1","uri":"${Uri.fromFile(cf)}","name":"a.jpg","w":10,"h":20,"origUri":"content://orig/1","cleanMode":"REMOVE"},
                      {"id":"p2","uri":"content://x/2","name":"b.jpg"}],
            "textOverlays":[{"id":"o1","text":"Hero","start":1.0,"duration":2.0}]}"""
        File(d, "project_draft.json").writeText(legacy)
        File(d, "scroll_positions.json").writeText("""{"match_index":[1,0]}""")
        val repo = ProjectRepository(Context(d))
        val lib = repo.openLibrary()
        val id = lib.migratedId
        check("migrate: id reported", id != null)
        check("migrate: one project named Project 1", lib.index.projects.size == 1 && lib.index.projects[0].name == "Project 1")
        check("migrate: becomes the open project", lib.index.activeId == id)
        check("migrate: old draft kept as .migrated", File(d, "project_draft.json.migrated").exists() && !File(d, "project_draft.json").exists())
        check("migrate: scroll positions moved to the project", !File(d, "scroll_positions.json").exists() && File(d, ProjectRepository.scrollFileName(id!!)).exists())
        val st = repo.load(id!!)!!
        check("migrate: slides intact", st.slides.size == 2 && st.slides[0].text == "hello" && st.slides[1].timestampSec == 3.5)
        check("migrate: images intact incl. cleaned copy", st.images.size == 2 && st.images[0].originalUri != null && st.images[0].cleanMode == LogoCleanMode.REMOVE)
        check("migrate: settings intact", st.settings.aspectRatio == AspectRatioOption.R4_5 && st.settings.defaultDurationSec == 4)
        check("migrate: overlay intact", st.textOverlays.size == 1 && st.textOverlays[0].text == "Hero")
        check("migrate: step restored (old rule: MATCH -> PHOTOS)", st.step == AppStep.PHOTOS)
        val lib2 = ProjectRepository(Context(d)).openLibrary()
        check("migrate: second start does not migrate again", lib2.migratedId == null && lib2.index.projects.size == 1)
    }

    // ---------------------------------------------------------------- 3. round trip and isolation of two projects
    run {
        val d = tmpDir(); val repo = ProjectRepository(Context(d)); repo.openLibrary()
        val (a, _) = repo.create("Alpha"); val (b, _) = repo.create("Beta")
        val sa = richState("A", 6, 5, File(d, "logoclean")); val sb = richState("B", 3, 2)
        repo.save(sa, a.id); repo.save(sb, b.id)
        check("roundtrip A", sameProject(sa, repo.load(a.id)!!))
        check("roundtrip B", sameProject(sb, repo.load(b.id)!!))
        val sa2 = sa.copy(slides = sa.slides + SentenceSlide(99.0, "extra"))
        val before = File(d, "projects/${b.id}.json").readText()
        repo.save(sa2, a.id)
        check("saving A leaves B's file byte-identical", File(d, "projects/${b.id}.json").readText() == before)
        check("A updated", repo.load(a.id)!!.slides.size == 7)
        val idx = repo.snapshot()
        check("summary: slides/photos/duration on the card", idx.find(a.id)!!.slideCount == 7 && idx.find(a.id)!!.photoCount == 5 && idx.find(a.id)!!.durationSec > 0)
        check("names unique", repo.create("alpha").first.name == "alpha (2)")
    }

    // ---------------------------------------------------------------- 4. no resurrection, unsafe ids
    run {
        val d = tmpDir(); val repo = ProjectRepository(Context(d)); repo.openLibrary()
        val (a, _) = repo.create("A")
        repo.save(richState("A"), a.id)
        val after = repo.delete(a.id)
        check("delete: gone from list", !after.contains(a.id) && after.activeId == null)
        check("delete: file gone", !repo.hasFile(a.id))
        check("late save after delete writes nothing", repo.save(richState("A"), a.id) == null && !repo.hasFile(a.id))
        check("unsafe id load", repo.load("../x") == null && repo.load("a/b") == null)
        check("unsafe id save", repo.save(richState("A"), "../evil") == null && !File(d, "evil.json").exists())
    }

    // ---------------------------------------------------------------- 5. duplicate keeps cleaned photos independent
    run {
        val d = tmpDir(); val repo = ProjectRepository(Context(d)); repo.openLibrary()
        val logo = File(d, "logoclean")
        val (a, _) = repo.create("Trip")
        repo.save(richState("A", 4, 3, logo), a.id)
        val (copy, idx) = repo.duplicate(a.id, null)!!
        check("dup: named 'Trip copy'", copy.name == "Trip copy" && idx.projects.size == 2)
        val orig = repo.load(a.id)!!; val dup = repo.load(copy.id)!!
        check("dup: same content", dup.slides == orig.slides && dup.textOverlays == orig.textOverlays && dup.images.size == orig.images.size)
        val ou = orig.images[0].uri; val du = dup.images[0].uri
        check("dup: own cleaned file", ou != du && File(du.path!!).exists() && File(ou.path!!).exists() && dup.images[0].originalUri != null)
        File(ou.path!!).delete()   // the original project discards its cleaned copy
        check("dup: still has its cleaned file after the original lost its", File(du.path!!).exists() && repo.load(copy.id)!!.images[0].originalUri != null)
        // a copy that cannot be made falls back to the untouched original photo
        val (b, _) = repo.create("Gone")
        val st = richState("G", 2, 2, logo)
        repo.save(st, b.id)
        File(st.images[0].uri.path!!).delete()
        val (c, _) = repo.duplicate(b.id, "Fallback")!!
        val cl = repo.load(c.id)!!
        check("dup: missing cleaned file -> original photo", cl.images[0].uri == Uri.parse("content://media/orig0") && cl.images[0].originalUri == null && cl.images[0].cleanLog.isEmpty())
        check("dup: unknown source", repo.duplicate("nope", null) == null)
        val dd = repo.duplicate(a.id, "Trip copy")!!.first.name
        check("dup: explicit name made unique", dd == "Trip copy (2)", dd)
    }

    // ---------------------------------------------------------------- 6. damaged files
    run {
        val d = tmpDir(); val repo = ProjectRepository(Context(d)); repo.openLibrary()
        val (a, _) = repo.create("Keep me"); val (b, _) = repo.create("Other")
        repo.save(richState("A"), a.id); repo.save(richState("B"), b.id)
        File(d, "projects/index.json").writeText("{ this is not json")
        val lib = ProjectRepository(Context(d)).openLibrary()
        check("damaged list: both projects recovered", lib.index.projects.size == 2 && lib.index.projects.all { it.name.startsWith("Recovered project") }, lib.index.projects.map { it.name }.toString())
        check("damaged list: names unique", lib.index.projects.map { it.name }.toSet().size == 2)
        check("damaged list: data still loads", sameProject(richState("A"), repo.load(a.id)!!))
        // damaged project file
        File(d, "projects/${a.id}.json").writeText("{ broken")
        check("damaged project: load null", repo.load(a.id) == null)
        check("damaged project: file still reported present", repo.hasFile(a.id))
        check("damaged project: backup kept", File(d, "projects/${a.id}.json.corrupt").readText() == "{ broken")
        check("damaged project: other project untouched", sameProject(richState("B"), repo.load(b.id)!!))
    }

    // ---------------------------------------------------------------- 7. rename / active / refreshSummary
    run {
        val d = tmpDir(); val repo = ProjectRepository(Context(d)); repo.openLibrary()
        val (a, _) = repo.create("One"); val (b, _) = repo.create("Two")
        check("rename ok", repo.rename(b.id, "Final  cut").find(b.id)!!.name == "Final cut")
        check("rename clash", repo.rename(b.id, "one").find(b.id)!!.name == "one (2)")
        check("setActive", repo.setActive(a.id).activeId == a.id)
        val st = richState("S", 10, 8)
        val before = repo.snapshot().find(a.id)!!.updatedAtMs
        val sum = repo.refreshSummary(a.id, st).find(a.id)!!
        check("refreshSummary: counts, edit time unchanged", sum.slideCount == 10 && sum.photoCount == 8 && sum.updatedAtMs == before)
    }

    // ---------------------------------------------------------------- 8. many saves and switches at once
    run {
        val d = tmpDir(); val repo = ProjectRepository(Context(d)); repo.openLibrary()
        val ids = (1..3).map { repo.create("P$it").first.id }
        coroutineScope {
            (1..150).map { n ->
                launch(Dispatchers.Default) {
                    val k = n % 3
                    repo.save(richState("T$k", 3 + k, 2), ids[k])
                    if (n % 7 == 0) repo.setActive(ids[k])
                    if (n % 11 == 0) repo.rename(ids[k], "Name $k")
                    if (n % 13 == 0) repo.snapshot()
                }
            }
        }
        var ok = true
        for ((k, id) in ids.withIndex()) {
            val st = repo.load(id)
            if (st == null || st.slides.size != 3 + k || st.slides.any { !it.text.contains("T$k") }) ok = false
        }
        check("concurrent saves: every file valid and in its own project", ok)
        check("concurrent: index file valid", ProjectIndexCodec.decode(File(d, "projects/index.json").readText())?.projects?.size == 3)
        check("concurrent: no temp files left", File(d, "projects").list()!!.none { it.endsWith(".tmp") })
    }

    // ---------------------------------------------------------------- 9. a 5-hour project (and a lot of photos), ten of them
    run {
        val d = tmpDir(); val repo = ProjectRepository(Context(d)); repo.openLibrary()
        val lines = 6000       // ~one line every 3 s for 5 hours
        val photos = 6000
        val big = UiState(
            scriptLoaded = true,
            slides = (0 until lines).map { SentenceSlide(it * 3.0, "Sentence number $it of the long narration for this film.", "i$it") },
            images = (0 until photos).map { PoolImage("i$it", Uri.parse("content://media/external/images/media/$it"), "IMG_$it.jpg", 1920, 1080) }
        )
        val ids = (1..10).map { repo.create("Film $it").first.id }
        var t0 = System.nanoTime()
        for (id in ids) repo.save(big, id)
        val saveMs = (System.nanoTime() - t0) / 1_000_000 / ids.size
        t0 = System.nanoTime()
        val back = repo.load(ids[4])!!
        val loadMs = (System.nanoTime() - t0) / 1_000_000
        t0 = System.nanoTime()
        val list = repo.snapshot()
        val listMs = (System.nanoTime() - t0) / 1_000_000
        val dur = list.find(ids[0])!!.durationSec
        check("5h: roundtrip", back.slides.size == lines && back.images.size == photos)
        check("5h: card shows ~5 hours", dur in 17990.0..18010.0, dur.toString())
        println("  perf: one 5-hour project = ${File(d, "projects/${ids[0]}.json").length() / 1024} KB; save ${saveMs} ms, load ${loadMs} ms, list of 10 projects ${listMs} ms")
        // saving one project writes one file
        val stamp = ids.map { File(d, "projects/$it.json").lastModified() }
        Thread.sleep(1100)
        repo.save(big.copy(slides = big.slides.drop(1)), ids[0])
        val stamp2 = ids.map { File(d, "projects/$it.json").lastModified() }
        check("saving one project touches only its own file", stamp2[0] != stamp[0] && (1 until 10).all { stamp2[it] == stamp[it] })
    }

    println("RESULT: $passed passed, $failed failed")
    if (failed > 0) System.exit(1)
}
