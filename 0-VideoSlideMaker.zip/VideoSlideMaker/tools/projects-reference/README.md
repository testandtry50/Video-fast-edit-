# projects-reference

Checks the multi-project storage (`data/ProjectRepository.kt`, `data/ProjectIndex.kt`) **without Android**: the real
repository and the real model classes are compiled with a Kotlin compiler, with two tiny stand-ins for `android.net.Uri`
and `android.content.Context`, and run against a temporary folder.

51 checks: first start, migrating an old single draft (incl. scroll positions), save/load round trips, two projects
staying isolated, rename / copy / delete, copies keeping their own cleaned photos, a damaged project list, a damaged
project file, unsafe ids, 150 concurrent saves, and a 5-hour project (6,000 lines + 6,000 photos) x 10.

    ORGJSON=/path/to/json-20240303.jar COROUTINES=/path/to/kotlinx-coroutines-core-jvm.jar ./run.sh

Expected last line: `RESULT: 51 passed, 0 failed`. It is a development aid only; the app does not use it, and the Android
unit tests (`app/src/test/.../data/ProjectIndexTest.kt`) run on every GitHub build.
