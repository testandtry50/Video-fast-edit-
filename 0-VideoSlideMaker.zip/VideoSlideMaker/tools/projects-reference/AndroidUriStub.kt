package android.net

class Uri private constructor(private val s: String) {
    val scheme: String? get() = s.substringBefore(':', "").ifEmpty { null }
    val path: String? get() = if (s.startsWith("file://")) s.removePrefix("file://") else s.substringAfter(':').substringBefore('?')
    override fun toString() = s
    override fun equals(other: Any?) = other is Uri && other.s == s
    override fun hashCode() = s.hashCode()
    companion object {
        @JvmStatic fun parse(s: String): Uri = Uri(s)
        @JvmStatic fun fromFile(f: java.io.File): Uri = Uri("file://" + f.absolutePath)
    }
}
