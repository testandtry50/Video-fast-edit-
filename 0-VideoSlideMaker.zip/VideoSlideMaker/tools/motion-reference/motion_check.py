"""
Python mirror of model/PhotoMotion.kt (PhotoMotion + TransitionMath) and of the export / preview frame schedules.
There is no Kotlin compiler in the sandbox, so the numbers are checked here, the same way the other tools/*-reference
folders do it. Run:  python3 motion_check.py
Checks: the mix patterns, zoom/pan end points, that NOTHING jumps (inside a photo, at the start of a crossfade or slide,
and between two photos), that the preview shows the same picture as the export, and (for the record) that the OLD code did jump.
"""
import math

ZOOM = 0.15
PAN_SCALE = 1.12
BLEND = 0.4
MIX = ["IN", "OUT", "IN", "IN", "OUT"]

def plan(style, n):
    if style == "NONE": return ["STILL"] * n
    if style in ("ZOOM_IN", "ZOOM_OUT", "PAN_LEFT", "PAN_RIGHT"): return [style.replace("ZOOM_", "ZOOM_")] * n
    if style == "ZOOM_ALTERNATE": return ["ZOOM_IN" if i % 2 == 0 else "ZOOM_OUT" for i in range(n)]
    if style == "ZOOM_MIX": return ["ZOOM_" + MIX[i % 5] for i in range(n)]
    if style == "RANDOM_MIX":
        choices = ["ZOOM_IN", "ZOOM_OUT", "PAN_LEFT", "PAN_RIGHT"]
        out, seed, prev = [], 0x2F6E2B1, None
        for _ in range(n):
            seed = (seed * 1103515245 + 12345) & 0x7FFFFFFF
            pick = choices[(seed >> 8) % 4]
            if pick == prev: pick = choices[(choices.index(pick) + 1) % 4]
            out.append(pick); prev = pick
        return out
    raise ValueError(style)

def frame_at(move, p):
    p = min(1.0, max(0.0, p))
    if move == "STILL": return (1.0, 0.5)
    if move == "ZOOM_IN": return (1 + ZOOM * p, 0.5)
    if move == "ZOOM_OUT": return (1 + ZOOM * (1 - p), 0.5)
    if move == "PAN_LEFT": return (PAN_SCALE, 1 - p)
    if move == "PAN_RIGHT": return (PAN_SCALE, p)

def blend_seconds(slot): return min(slot / 3.0, BLEND)
def blend_t(pos, slot):
    ln = blend_seconds(slot)
    return 0.0 if ln <= 0 else min(1.0, max(0.0, (pos - (slot - ln)) / ln))
def fade_fraction(slot): return min(0.5, BLEND / max(slot, 0.1))
def fade_black_alpha(p, slot):
    ff = fade_fraction(slot); a = 1.0
    if p < ff: a = min(a, p / ff)
    if p > 1 - ff: a = min(a, (1 - p) / ff)
    return min(1.0, max(0.0, a))

def layer_look(style, pos, start, dur, prev_dur, has_next):
    dur = max(0.1, dur); local = pos - start
    if local < 0 and prev_dur <= 0: local = 0.0
    if local < 0:
        t = blend_t(local + prev_dur, prev_dur)
        if style == "CROSSFADE": return (t, 0.0, 0.0) if t > 0 else (0, 0, 0)
        if style == "SLIDE": return (1.0, 1 - t, 0.0) if t > 0 else (0, 0, 0)
        return (0, 0, 0)
    p = min(1.0, max(0.0, local / dur))
    if style == "FADE_BLACK": return (fade_black_alpha(p, dur), 0.0, p)
    if style == "SLIDE": return (1.0, -blend_t(local, dur) if has_next else 0.0, p)
    return (1.0, 0.0, p)

# ---------- export schedule (mirrors VideoExportEngine + FrameRenderer) ----------
def export_frames(style_fx, style_tr, durations, fps=30, fixed=True):
    """Yield (slot, k, layers). layers = list of dict(alpha, shift, scale, panX, slot) bottom->top."""
    moves = plan(style_fx, len(durations)); out = []
    for i, d in enumerate(durations):
        total = max(1, round(d * fps))
        has_next = i + 1 < len(durations)
        fade_frac = min(0.5, 0.4 / d) if style_tr == "FADE_BLACK" else 0.0
        tf = min(total // 3, round(0.4 * fps)) if (has_next and style_tr in ("CROSSFADE", "SLIDE")) else 0
        steady = total - tf
        def photo(slot, move, prog, shift=0.0, alpha=1.0):
            sc, px = frame_at(move, prog)
            return dict(alpha=alpha, shift=shift, scale=sc, panX=px, slot=slot)
        for f in range(steady):
            prog = f / total
            a = 1.0
            if fade_frac > 0 and prog < fade_frac: a = min(a, prog / fade_frac)
            if fade_frac > 0 and prog > 1 - fade_frac: a = min(a, 1 - (prog - (1 - fade_frac)) / fade_frac)
            out.append((i, f, [photo(i, moves[i], prog, alpha=a)]))
        for f in range(tf):
            t = f / tf
            k = steady + f
            if fixed:
                fp, tp = k / total, 0.0
            else:  # OLD behaviour: both photos drawn with NO zoom/pan at all
                fp, tp = None, None
            def old_photo(slot, shift=0.0, alpha=1.0): return dict(alpha=alpha, shift=shift, scale=1.0, panX=0.5, slot=slot)
            if style_tr == "CROSSFADE":
                lay = [photo(i, moves[i], fp), photo(i + 1, moves[i + 1], tp, alpha=t)] if fixed else [old_photo(i), old_photo(i + 1, alpha=t)]
            else:
                lay = [photo(i, moves[i], fp, shift=-t), photo(i + 1, moves[i + 1], tp, shift=1 - t)] if fixed else [old_photo(i, -t), old_photo(i + 1, 1 - t)]
            out.append((i, k, lay))
    return out

def preview_layers(style_fx, style_tr, durations, slot, k, fps=30):
    starts = [sum(durations[:i]) for i in range(len(durations))]
    moves = plan(style_fx, len(durations))
    pos = starts[slot] + k / fps
    cur = max(i for i in range(len(durations)) if starts[i] <= pos + 1e-9)
    need_next = style_tr in ("CROSSFADE", "SLIDE")
    last = min(cur + 1, len(durations) - 1) if need_next else cur
    lay = []
    for idx in range(cur, last + 1):
        a, sh, pr = layer_look(style_tr, pos, starts[idx], durations[idx], durations[idx - 1] if idx > 0 else 0.0, idx < len(durations) - 1)
        if a <= 0: continue
        sc, px = frame_at(moves[idx], pr)
        lay.append(dict(alpha=a, shift=sh, scale=sc, panX=px, slot=idx))
    return lay

def main():
    fails = 0
    def check(cond, msg):
        nonlocal fails
        if not cond: fails += 1; print("FAIL:", msg)

    # --- the mix patterns ---
    check(plan("ZOOM_MIX", 10) == ["ZOOM_" + x for x in ["IN","OUT","IN","IN","OUT","IN","OUT","IN","IN","OUT"]], "mix pattern")
    check(plan("ZOOM_ALTERNATE", 6) == ["ZOOM_IN","ZOOM_OUT"] * 3, "alternate")
    r = plan("RANDOM_MIX", 500)
    check(all(a != b for a, b in zip(r, r[1:])), "random never repeats neighbours")
    check(r == plan("RANDOM_MIX", 500) and r[:50] == plan("RANDOM_MIX", 50), "random is fixed + prefix-stable")
    check(len(set(r)) == 4, "random uses all four moves")
    # --- end points ---
    check(frame_at("ZOOM_IN", 0) == (1.0, .5) and abs(frame_at("ZOOM_IN", 1)[0] - 1.15) < 1e-9, "zoom in ends")
    check(abs(frame_at("ZOOM_OUT", 0)[0] - 1.15) < 1e-9 and frame_at("ZOOM_OUT", 1)[0] == 1.0, "zoom out ends")
    check(frame_at("PAN_LEFT", 0)[1] == 1 and frame_at("PAN_LEFT", 1)[1] == 0, "pan left goes right->left view")
    check(frame_at("PAN_RIGHT", 0)[1] == 0 and frame_at("PAN_RIGHT", 1)[1] == 1, "pan right goes left->right view")

    durations = [3.0, 2.0, 3.0, 0.9, 3.0, 4.0]
    fps = 30
    worst_new = worst_old = 0.0
    for fx in ["NONE","ZOOM_IN","ZOOM_OUT","PAN_LEFT","PAN_RIGHT","ZOOM_ALTERNATE","ZOOM_MIX","RANDOM_MIX"]:
        for tr in ["NONE","FADE_BLACK","CROSSFADE","SLIDE"]:
            frames = export_frames(fx, tr, durations, fps)
            # (a) inside one photo: the photo that is under everything moves a little at a time, never jumps
            for (s1, k1, l1), (s2, k2, l2) in zip(frames, frames[1:]):
                if s1 != s2 or tr in ("CROSSFADE", "SLIDE") and (len(l1) != len(l2)):
                    pass
                base1 = [l for l in l1 if l["slot"] == s1][0]; base2 = [l for l in l2 if l["slot"] == s1]
                if s1 == s2 and base2:
                    ds = abs(base1["scale"] - base2[0]["scale"]); dp = abs(base1["panX"] - base2[0]["panX"])
                    worst_new = max(worst_new, ds)
                    check(ds <= ZOOM / (durations[s1] * fps) * 1.05 + 1e-9, f"{fx}/{tr}: scale jump {ds:.4f} slot {s1} frame {k1}")
                    check(dp <= 1.0 / (durations[s1] * fps) * 1.05 + 1e-9, f"{fx}/{tr}: pan jump {dp:.4f}")
            # (b) between two photos: the incoming photo's last transition frame == the next slot's first frame
            if tr in ("CROSSFADE", "SLIDE"):
                for i in range(len(durations) - 1):
                    last = [f for f in frames if f[0] == i][-1][2][-1]
                    first = [f for f in frames if f[0] == i + 1][0][2][0]
                    check(abs(last["scale"] - first["scale"]) < 1e-9 and abs(last["panX"] - first["panX"]) < 1e-9, f"{fx}/{tr}: incoming photo pose differs from next slot start ({i})")
                    tf_i = min(round(durations[i] * fps) // 3, round(0.4 * fps))
                    check(abs(last["shift"]) <= 1.0 / tf_i + 1e-9 and last["alpha"] >= 1 - 1.0 / tf_i - 1e-9, f"{fx}/{tr}: last blend frame is more than one step from arrived ({i})")
            # (c) preview == export (within one frame of the blend, which the export reaches 1 frame earlier)
            for (slot, k, lay) in frames:
                pv = preview_layers(fx, tr, durations, slot, k, fps)
                ex = [l for l in lay if l["alpha"] > 1e-6 and abs(l["shift"]) < 1 - 1e-9]   # skip layers that are fully transparent / fully off-screen
                tol_t = 1e-6
                for e in ex:
                    m = [p for p in pv if p["slot"] == e["slot"]]
                    if not m: check(False, f"{fx}/{tr}: preview missing layer slot {e['slot']} at slot {slot} frame {k}"); continue
                    m = m[0]
                    check(abs(m["scale"] - e["scale"]) < 0.01 + 1e-9 and abs(m["panX"] - e["panX"]) < 0.04, f"{fx}/{tr}: preview pose != export at {slot}/{k}")
                    check(abs(m["shift"] - e["shift"]) <= 1e-6 and abs(m["alpha"] - e["alpha"]) <= (1e-6 if tr != "FADE_BLACK" else 1.0 / (0.4 * fps) + 1e-6), f"{fx}/{tr}: preview blend != export at {slot}/{k} ({m['alpha']:.3f}/{m['shift']:.3f} vs {e['alpha']:.3f}/{e['shift']:.3f})")

    # --- for the record: the OLD export really did jump when a crossfade / slide began ---
    for tr in ("CROSSFADE", "SLIDE"):
        old = export_frames("ZOOM_IN", tr, [3.0, 3.0], fps, fixed=False)
        tf = min(90 // 3, round(0.4 * fps)); steady = 90 - tf
        before = [f for f in old if f[0] == 0][steady - 1][2][0]["scale"] if False else 1.0 + 0.06 * ((steady - 1) / 90)
        after = [f for f in old if f[0] == 0][steady][2][0]["scale"]
        worst_old = max(worst_old, abs(before - after))
    print(f"largest scale step between two frames, NEW: {worst_new:.5f} (the zoom speed itself)")
    print(f"OLD code, size jump at the start of a crossfade/slide with Zoom In: {worst_old:.4f} (= {worst_old*100:.1f}% of the frame in ONE frame)")
    print("ALL CHECKS PASSED" if not fails else f"{fails} CHECK(S) FAILED")
    raise SystemExit(1 if fails else 0)

if __name__ == "__main__":
    main()
