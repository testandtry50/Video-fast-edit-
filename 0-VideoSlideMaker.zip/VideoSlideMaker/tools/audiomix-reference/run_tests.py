import math, random
from smartmix import *

RATE = 8000
def speech_signal(bursts, total_s, seed=1):
    """noise-modulated tone in the given (start,end) seconds, tiny hiss elsewhere"""
    random.seed(seed)
    n = int(total_s * RATE); out = []
    for i in range(n):
        t = i / RATE
        on = any(a <= t < b for a, b in bursts)
        env = (0.5 + 0.5 * math.sin(2 * math.pi * 4 * t)) if on else 0.0
        v = 0.25 * env * math.sin(2 * math.pi * 180 * t) + (0.0005 * random.uniform(-1, 1))
        out.append(v)
    return out

ok = 0
def check(name, cond):
    global ok
    print(("PASS " if cond else "FAIL ") + name)
    assert cond, name
    ok += 1

# --- speech mask finds the bursts, not the hiss
bursts = [(1.0, 2.5), (4.0, 5.0)]
rms = energy_windows(speech_signal(bursts, 7.0), RATE)
m = speech_mask(rms)
t = lambda s: int(s * 1000 / WINDOW_MS)
check("mask: active inside burst 1", sum(m[t(1.2):t(2.3)]) > 0.6 * (t(2.3) - t(1.2)))
check("mask: silent in gap", not any(m[t(2.8):t(3.8)]))
check("mask: silent before speech", not any(m[0:t(0.9)]))
check("mask: all-silent input -> no speech", not any(speech_mask(energy_windows([0.0] * RATE * 3, RATE))))
check("mask: empty input", speech_mask([]) == [])

# --- ducking: quiet during speech, recovers in gaps, starts BEFORE speech (lookahead)
duck = 10 ** (-14 / 20)
g = duck_gains(m, duck)
check("duck: ~duck level mid-burst", g[t(1.8)] < duck * 1.25)
check("duck: back to ~1 well into the gap", g[t(3.8)] > 0.9)
check("duck: already lowered 40 ms before the burst starts", g[t(1.0) - 2] < 0.9)
check("duck: bridges a short pause inside speech (hold)", True)
short = [True] * 20 + [False] * 8 + [True] * 20   # 160 ms pause < hold 300 ms
gs = duck_gains(short, duck)
check("duck: 160 ms pause does not pump the music back up", min(gs[25:28]) < 0.4)
check("duck: gains stay in (0,1]", all(0 < x <= 1.0 for x in g))
check("duck: smooth - max step per 20ms window < 0.25", max(abs(g[i + 1] - g[i]) for i in range(len(g) - 1)) < 0.25)

# --- auto level hits its target
voice_db = active_level_db(rms, m)
music = [0.3 * math.sin(2 * math.pi * 440 * i / RATE) for i in range(RATE * 4)]
mdb = music_level_db(energy_windows(music, RATE))
for duck_on in (True, False):
    off = bed_offset_db(duck_on)
    gain = auto_level_gain(voice_db, mdb, off)
    after = mdb + db_of(gain)
    check("level: music lands %.0f dB from voice (duck=%s)" % (off, duck_on), abs(after - (voice_db + off)) < 0.01)
check("level: no voice -> gain 1", auto_level_gain(None, mdb, -10) == 1.0)
check("level: gain is clamped", auto_level_gain(0.0, -110.0, 0.0) == 6.0 and auto_level_gain(-110.0, 0.0, 0.0) == 0.03)

# --- fades
check("fade: starts at 0", fade(0, 10, 2, 2) == 0.0)
check("fade: full in the middle", fade(5, 10, 2, 2) == 1.0)
check("fade: ends at 0", abs(fade(10, 10, 2, 2)) < 1e-9)
check("fade: monotonic in", all(fade(i / 10, 10, 2, 0) <= fade((i + 1) / 10, 10, 2, 0) for i in range(19)))
check("fade: no fade = 1", fade(0, 5, 0, 0) == 1.0)

# --- clip editing
a = clip("a", start=0, src_start=0, src_end=60)
check("trim start keeps timeline start, shortens", (lambda c: (c['start'] == 0 and length(c) == 50))(trim_start(a, 10)))
check("trim start cannot pass the end", length(trim_start(a, 999)) >= MIN - 1e-9)
check("trim end clamps to file length", trim_end(a, 999)['s1'] == 60)
check("trim end cannot pass the start", trim_end(a, -5)['s1'] >= MIN)
p = split(a, 20, "b")
check("split: two clips covering the same audio", len(p) == 2 and length(p[0]) == 20 and length(p[1]) == 40 and p[1]['start'] == 20 and p[1]['s0'] == 20)
check("split too close to the edge is ignored", len(split(a, 0.01, "b")) == 1)
# cut with ripple
b = clip("b", start=60, src_start=0, src_end=30)
res = cut_in_track([a, b], "a", 10, 20, True, "a2")
check("cut+close gap: left, right, and later clip slides left", [c['id'] for c in res] == ["a", "a2", "b"] and res[1]['start'] == 10 and res[2]['start'] == 50)
check("cut+close gap: removes exactly the cut audio", abs(sum(length(c) for c in res[:2]) - 50) < 1e-9)
res2 = cut_in_track([a, b], "a", 10, 20, False, "a2")
check("cut, keep gap: right part stays where it was", res2[1]['start'] == 20 and res2[2]['start'] == 60)
res3 = cut_in_track([a], "a", 0, 20, True, "x")
check("cut from the very start: first surviving part keeps the id", len(res3) == 1 and res3[0]['id'] == "a" and length(res3[0]) == 40 and res3[0]['start'] == 0)
res4 = cut_in_track([a], "a", 40, 60, False, "x")
check("cut up to the end leaves only the left part", len(res4) == 1 and length(res4[0]) == 40)
check("cut nearly nothing is a no-op", len(cut_in_track([a], "a", 5, 5.01, True, "x")) == 1 and length(cut_in_track([a], "a", 5, 5.01, True, "x")[0]) == 60)
check("cut with swapped from/to works", len(cut_in_track([a], "a", 20, 10, True, "x")) == 2)
c = combine([clip("b", start=50, src_end=5), clip("a", start=10, src_end=10), clip("c", start=200, src_end=2)])
check("combine: in time order, back to back, from the earliest start", [(x['id'], x['start']) for x in c] == [("a", 10), ("b", 20), ("c", 25)])
check("combine with a gap", [x['start'] for x in combine([clip("a", src_end=4), clip("b", start=9, src_end=4)], 1.0)] == [0, 5])
print("\n%d checks passed" % ok)
