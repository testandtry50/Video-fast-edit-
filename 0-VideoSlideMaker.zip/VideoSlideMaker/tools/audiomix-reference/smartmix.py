"""Python mirror of audio/SmartMix.kt and audio/ClipEdit.kt (there is no Kotlin compiler in the sandbox, so the
maths is proven here first and the Kotlin is a line-for-line port). Run: python3 run_tests.py"""
import math

WINDOW_MS = 20
SILENCE_DB = -55.0

def db_of(x):
    return 20.0 * math.log10(max(x, 1e-6))

def energy_windows(samples, rate):
    """samples: list of floats (mono, -1..1) -> RMS per 20 ms window (drops a trailing partial window)."""
    w = rate * WINDOW_MS // 1000
    out = []
    for i in range(0, len(samples) - w + 1, w):
        s = sum(v * v for v in samples[i:i + w]) / w
        out.append(math.sqrt(s))
    return out

def speech_mask(rms):
    n = len(rms)
    if n == 0:
        return []
    db = [db_of(v) for v in rms]
    s = sorted(db)
    floor = s[int(n * 0.10)]
    peak = s[min(n - 1, int(n * 0.95))]
    if peak < SILENCE_DB:
        return [False] * n
    if peak - floor < 8.0:
        return [d > -45.0 for d in db]
    thr = max(-50.0, floor + 0.3 * (peak - floor))
    return [d >= thr for d in db]

def duck_gains(mask, duck_gain, attack_ms=60, release_ms=400, hold_ms=300, lookahead_ms=100):
    n = len(mask)
    H = hold_ms // WINDOW_MS
    L = lookahead_ms // WINDOW_MS
    INF = 10 ** 9
    last = [-INF] * n
    prev = -INF
    for i in range(n):
        if mask[i]:
            prev = i
        last[i] = prev
    nxt = [INF] * n
    nx = INF
    for i in range(n - 1, -1, -1):
        if mask[i]:
            nx = i
        nxt[i] = nx
    g = 1.0
    out = []
    for i in range(n):
        ducked = (i - last[i] <= H) or (nxt[i] - i <= L)
        target = duck_gain if ducked else 1.0
        tau = attack_ms if target < g else release_ms
        a = 1.0 - math.exp(-WINDOW_MS / tau)
        g += (target - g) * a
        out.append(g)
    return out

def active_level_db(rms, mask):
    tot = 0.0; c = 0
    for r, m in zip(rms, mask):
        if m:
            tot += r * r; c += 1
    if c == 0:
        return None
    return db_of(math.sqrt(tot / c))

def music_level_db(rms, gate_db=-60.0):
    tot = 0.0; c = 0
    for r in rms:
        if db_of(r) > gate_db:
            tot += r * r; c += 1
    if c == 0:
        return None
    return db_of(math.sqrt(tot / c))

def auto_level_gain(voice_db, music_db, offset_db):
    if voice_db is None or music_db is None:
        return 1.0
    g = 10 ** ((voice_db + offset_db - music_db) / 20.0)
    return min(6.0, max(0.03, g))

def bed_offset_db(auto_duck):
    return -10.0 if auto_duck else -18.0

def fade(pos, length, fade_in, fade_out):
    if length <= 0: return 0.0
    g = 1.0
    if fade_in > 0 and pos < fade_in:
        x = max(0.0, pos / fade_in); g *= x * x * (3 - 2 * x)
    left = length - pos
    if fade_out > 0 and left < fade_out:
        x = max(0.0, left / fade_out); g *= x * x * (3 - 2 * x)
    return g

# ---------------- clip editing ----------------
MIN = 0.1

def clip(id, start=0.0, src_start=0.0, src_end=10.0, **kw):
    d = dict(id=id, start=start, s0=src_start, s1=src_end, dur=max(src_end, kw.pop('dur', src_end)), fi=0.0, fo=0.0, loop=False)
    d.update(kw)
    return d

def length(c): return max(0.0, c['s1'] - c['s0'])
def end(c): return c['start'] + length(c)

def trim_start(c, v):
    c = dict(c); c['s0'] = min(max(v, 0.0), max(c['s1'] - MIN, 0.0)); return c

def trim_end(c, v):
    c = dict(c); hi = c['dur'] if c['dur'] > 0 else 1e12
    c['s1'] = min(max(v, c['s0'] + MIN), hi); return c

def split(c, at, new_id):
    if at < MIN or at > length(c) - MIN:
        return [c]
    cut = c['s0'] + at
    a = dict(c, s1=cut, fo=0.0, loop=False)
    b = dict(c, id=new_id, s0=cut, start=c['start'] + at, fi=0.0, loop=False)
    return [a, b]

def cut_in_track(clips, cid, frm, to, close_gap, new_id):
    target = next(c for c in clips if c['id'] == cid)
    ln = length(target)
    frm = min(max(frm, 0.0), ln); to = min(max(to, 0.0), ln)
    if to < frm: frm, to = to, frm
    if to - frm < MIN:
        return list(clips)
    removed = to - frm
    old_end = end(target)
    left_ok = frm >= MIN
    right_ok = ln - to >= MIN
    parts = []
    if left_ok:
        parts.append(dict(target, s1=target['s0'] + frm, fo=0.0, loop=False))
    if right_ok:
        rid = target['id'] if not left_ok else new_id
        st = target['start'] + (frm if close_gap else to) if left_ok or close_gap else target['start'] + to
        if not left_ok and close_gap:
            st = target['start']
        elif not left_ok:
            st = target['start'] + to
        else:
            st = target['start'] + (frm if close_gap else to)
        parts.append(dict(target, id=rid, s0=target['s0'] + to, start=st, fi=0.0 if left_ok else target['fi'], loop=False))
    out = []
    for c in clips:
        if c['id'] == cid:
            out.extend(parts)
        elif close_gap and c['start'] >= old_end - 1e-6:
            out.append(dict(c, start=max(0.0, c['start'] - removed)))
        else:
            out.append(c)
    return out

def combine(clips, gap=0.0):
    if not clips: return []
    s = sorted(clips, key=lambda c: c['start'])
    t = s[0]['start']; out = []
    for c in s:
        out.append(dict(c, start=t)); t += length(c) + gap
    return out
