# Audio step (2.17) - reference

`smartmix.py` is a line-for-line Python mirror of `audio/SmartMix.kt` (speech detector, ducking curve, loudness match, fades)
and `audio/ClipEdit.kt` (trim, split, cut, combine, swap). There is no Kotlin compiler in the sandbox, so the maths was
proven here first (`python3 run_tests.py`, 36 checks on synthetic speech) and then ported. The Kotlin tests in
`app/src/test/.../audio/` repeat the same checks.
