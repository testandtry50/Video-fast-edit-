# Audio step (2.17) - reference

`smartmix.py` is a line-for-line Python mirror of `audio/SmartMix.kt` (speech detector, ducking curve, loudness match, fades)
and `audio/ClipEdit.kt` (trim, split, cut, combine, swap). There is no Kotlin compiler in the sandbox, so the maths was
proven here first (`python3 run_tests.py`, 36 checks on synthetic speech) and then ported. The Kotlin tests in
`app/src/test/.../audio/` repeat the same checks.

## 2.19: mark a part of the original, sound kinds, exact repeats

`beatmark.py` mirrors `audio/MarkMath.kt`, `audio/SoundKinds.kt` and the 2.19 parts of `ClipEdit.kt`, `BackgroundSlots.kt` and
`AudioMixRenderer.kt` (typed times, moving marks, "keep only this part", fitting ONLY the marked part to a range or the video,
play-once, assigning to a slot, the kind / mood table, the exact-repeat loop with its tiny join fade, per-sound lowering depth and
loudness). `python3 run_beat_tests.py` runs 90 checks (the 2.17 ones stay in `run_tests.py`).
