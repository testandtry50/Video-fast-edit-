import math
from beatmark import *
from smartmix import duck_gains

ok = 0
def check(name, cond):
    global ok
    print(("PASS " if cond else "FAIL ") + name)
    assert cond, name
    ok += 1
near = lambda a, b, e=1e-9: abs(a - b) < e

# ---- typed times
check("time: plain seconds", parse_time("72") == 72.0 and parse_time("72.5") == 72.5)
check("time: minutes and seconds", parse_time("1:12") == 72.0 and parse_time("1:12.5") == 72.5)
check("time: hours", parse_time("1:02:03") == 3723.0)
check("time: comma works as the decimal point", parse_time("1:12,5") == 72.5 and parse_time("3,25") == 3.25)
check("time: spaces and a trailing s are ignored", parse_time("  4.5 s ") == 4.5 and parse_time("0:08s") == 8.0)
check("time: seconds of 60 or more after a colon are refused", parse_time("1:75") is None and parse_time("1:60") is None)
check("time: garbage, empty, negative and odd forms are refused",
      all(parse_time(x) is None for x in ["", "  ", "abc", "1:", ":30", "1:2:3:4", "-5", "1.5:30", "NaN", "5d", "1e3", "0x10", "1.2.3"]))

# ---- mark maths
F = 200.0
check("fix: puts the pair in order and inside the file", fix(50, 10, F) == (10, 50) and fix(-5, 999, F) == (0, F))
check("fix: a pair closer than the shortest clip is opened up", near(fix(10, 10.01, F)[1] - fix(10, 10.01, F)[0], MIN))
check("fix: at the very end of the file the start gives way", fix(199.99, 200, F) == (F - MIN, F))
check("start: moves only the start", with_start(10, 20, 14, F) == (14, 20))
check("start: past the end carries the end along, keeping the length", with_start(10, 20, 50, F) == (50, 60))
check("start: near the end of the file stays inside it", (lambda p: p[1] <= F and p[1] - p[0] >= MIN - 1e-9)(with_start(10, 20, 199.99, F)))
check("end: moves only the end", with_end(10, 20, 30, F) == (10, 30))
check("end: before the start carries the start along, keeping the length", with_end(10, 20, 5, F) == (0, 5) or near(with_end(10, 20, 5, F)[1] - with_end(10, 20, 5, F)[0], MIN))
check("end: pulling the end back past the start keeps the length when there is room", with_end(100, 110, 50, F) == (40, 50))
check("shift: keeps the length and stops at the file's ends", shift(10, 14, 3, F) == (13, 17) and shift(1, 5, -10, F) == (0, 4) and shift(196, 200, 10, F) == (196, 200))
check("nearest handle: closer one wins, start on a tie", nearest_is_start(10, 20, 12) and not nearest_is_start(10, 20, 18) and nearest_is_start(10, 20, 15))
check("nan never moves a mark", with_start(10, 20, float('nan'), F) == (10, 20) and with_end(10, 20, float('nan'), F) == (10, 20))

# ---- keep only the marked part (a beat in a 3 minute song)
song = aclip("song", dur=180.0)
beat = keep_only(song, 72.0, 76.0)
check("keep: start, end and marked end are the beat's", beat['s0'] == 72 and beat['s1'] == 76 and beat['mark'] == 76 and has_mark(beat))
check("keep: the sound is now 4 s long and says it uses only part of the file", near(length(beat), 4.0) and uses_part(beat))
check("keep: a short part is a beat, so it repeats exactly", beat['exact'])
check("keep: a long part does not switch exact repeat on by itself", not keep_only(song, 10, 60)['exact'])
check("keep: a switched-on exact repeat stays on for a long part", keep_only(dict(song, exact=True), 10, 60)['exact'])
check("keep: the ends may be given in either order", keep_only(song, 76.0, 72.0) == beat)
check("keep: marking the whole file means no mark", (lambda c: c['mark'] == 0 and not has_mark(c) and not uses_part(c))(keep_only(song, 0, 180)))
check("keep: a part shorter than the shortest clip changes nothing", keep_only(song, 5, 5.05) == song)
check("keep: a sound whose length is not known yet changes nothing", keep_only(aclip("u", dur=0.0, s1=0.0), 1, 5) == aclip("u", dur=0.0, s1=0.0))
check("keep: marks past the file are held inside it", (lambda c: c['s1'] == 180 and c['s0'] == 170)(keep_only(song, 170, 999)))
back = use_whole_file(beat)
check("whole original: brings the whole file back", back['s0'] == 0 and back['s1'] == 180 and back['mark'] == 0 and not uses_part(back))
check("whole original: keeps volume, kind and place", (lambda c: c['kind'] == 'MUSIC' and c['vol'] == 0.5 and c['start'] == 7)(use_whole_file(keep_only(dict(song, kind='MUSIC', vol=0.5, start=7), 10, 20))))

# ---- THE POINT: only the marked part is fitted, not the rest of the file
slot = aclip("slot", dur=180.0, start=4.0, re=20.0, slot="B1")
old = follow_range(slot)                          # nothing marked: the file (to its end) fills the 16 s range - cut
check("range, no mark: a long song is cut to the range (as before 2.19)", near(length(old), 16.0) and not old['loop'])
marked = follow_range(keep_only(slot, 72.0, 76.0))
check("range, marked beat: ONLY the 4 s beat repeats to fill the 16 s", near(length(marked), 4.0) and marked['loop'] and marked['s0'] == 72)
check("range, marked beat: the repeat plays the beat's 4 s, not the song's next 108 s", marked['s1'] == 76)
check("range, marked beat longer than the range: cut to the range", (lambda c: near(length(c), 16.0) and not c['loop'])(follow_range(keep_only(slot, 40, 100))))
vid = aclip("v", dur=180.0, fit=True)
check("video, no mark: the song is cut to the video", near(length(follow_video(vid, 60.0)), 60.0))
mv = follow_video(keep_only(vid, 72, 76), 60.0)
check("video, marked beat: ONLY the beat repeats over the video", near(length(mv), 4.0) and mv['loop'] and mv['s0'] == 72)
check("video, marked beat: follows a longer video by repeating the beat, not by running on into the song",
      (lambda c: near(length(c), 4.0) and c['loop'])(follow_video(keep_only(vid, 72, 76), 300.0)))
check("unmarked clip: the fit is exactly what it was before 2.19", follow_range(slot) == follow_range(dict(slot, mark=0.0)) and material_end(slot) == 180.0)
sfx = dict(keep_only(slot, 10, 11), once=True)
check("play once: a one-shot sound shorter than the range is not repeated", (lambda c: not c['loop'] and near(length(c), 1.0))(follow_range(sfx)))
check("play once: not for a sound that is longer than the range (it is cut)", (lambda c: not c['loop'] and near(length(c), 16.0))(follow_range(dict(slot, once=True))))
check("play once: also over the whole video", (lambda c: not c['loop'] and near(length(c), 1.0))(follow_video(dict(keep_only(vid, 10, 11), once=True), 60.0)))

# ---- marks stay in step with trims, splits and cuts
check("trim end: moves the marked end with it", (lambda c: c['mark'] == 75 and c['s1'] == 75)(trim_end(beat, 75.0)))
check("trim end: leaves an unmarked clip unmarked", trim_end(song, 100.0)['mark'] == 0)
halves = split(keep_only(song, 70, 90), 5.0, "b")
check("split: the first half's marked end is where it ends, the second keeps the old one",
      halves[0]['mark'] == 75 and halves[0]['s1'] == 75 and halves[1]['mark'] == 90 and halves[1]['s0'] == 75)
check("split: an unmarked clip's halves stay unmarked", all(h['mark'] == 0 for h in split(song, 50.0, "b")))

# ---- assigning an edited sound to a slot
src = aclip("music", dur=180.0, fit=True, fi=1.0, kind='MUSIC', vol=0.8)
b1 = aclip("slot1", dur=0.0, s1=0.0, start=4.0, re=20.0, slot="B1", fi=0.3, fo=0.3, uri='')
filled = assign_to_slot(keep_only(src, 72, 76), b1)
check("assign: the slot keeps its id, name and time range", filled['id'] == "slot1" and filled['slot'] == "B1" and filled['start'] == 4 and filled['re'] == 20)
check("assign: it takes the file, the marked beat, volume and kind", filled['uri'] == 'content://x/music' and filled['s0'] == 72 and filled['mark'] == 76 and filled['vol'] == 0.8 and filled['kind'] == 'MUSIC')
check("assign: it is not stretched over the video any more", not filled['fit'] and not filled['loop'])
check("assign: fades are never shorter than the slot's (no click at the range's edges)", filled['fi'] == 1.0 and filled['fo'] == 0.3)
fitted = follow_range(filled)
check("assign: the beat then repeats to fill B1's range", near(length(fitted), 4.0) and fitted['loop'] and fitted['re'] == 20)
once_src = dict(aclip("door", dur=3.0, once=True, fi=0.02, fo=0.05), fit=False)
check("assign: a one-shot sound keeps its own tiny fades", (lambda c: c['fi'] == 0.02 and c['fo'] == 0.05)(assign_to_slot(once_src, b1)))

# ---- kinds and profiles: the table makes sense
P = {(k, m): profile(k, m) for k in KINDS for m in ALL_MOODS}
check("kinds: every effect plays once, is not lowered under the voice, and is heard (louder than any bed)",
      all(profile(k, 'NONE')['once'] and not profile(k, 'NONE')['duck'] and profile(k, 'NONE')['lvl'] >= -6.0 for k in EFFECTS))
check("kinds: no bed or music plays once", all(not P[(k, m)]['once'] for k in KINDS if k not in EFFECTS for m in ALL_MOODS))
check("kinds: every bed and music is lowered under the voice", all(P[(k, m)]['duck'] for k in KINDS if k not in EFFECTS for m in ALL_MOODS))
check("kinds: background voices sit lowest and step aside the most", profile('CROWD', 'NONE')['lvl'] < profile('AMBIENCE', 'NONE')['lvl'] and profile('CROWD', 'NONE')['dadj'] < 0)
check("kinds: ambience and nature barely pump (they are lowered LESS than music)", profile('AMBIENCE', 'NONE')['dadj'] > 0 and profile('NATURE', 'NONE')['dadj'] > 0)
check("kinds: every number is in a sane range", all(
    (p['lvl'] is None or -30.0 <= p['lvl'] <= 0.0) and -24.0 <= p['dadj'] <= 24.0 and p['fi'] >= 0 and p['fo'] >= 0 for p in P.values()))
check("moods: action sits louder than calm, calm and emotional step aside more", profile('MUSIC', 'ACTION')['lvl'] > profile('MUSIC', 'CALM')['lvl'] and
      profile('MUSIC', 'CALM')['dadj'] < profile('MUSIC', 'ACTION')['dadj'] and profile('MUSIC', 'EMOTIONAL')['dadj'] < 0)
check("moods: no mood = the smart mix's standard level", profile('MUSIC', 'NONE')['lvl'] is None and profile('MUSIC', 'NONE')['dadj'] == 0.0)
check("moods: instrumental sits one dB higher than music with the same feeling", all(
    near(profile('INSTRUMENTAL', m)['lvl'] - profile('MUSIC', m)['lvl'], 1.0) for m in MOODS_TABLE))
check("moods: instrumental with no feeling is a little above the standard bed", near(profile('INSTRUMENTAL', 'NONE')['lvl'], STANDARD_BED_DB + 1.0))
check("beat: repeats exactly with short fades", profile('BEAT', 'NONE')['exact'] and profile('BEAT', 'NONE')['fi'] < profile('MUSIC', 'NONE')['fi'])
check("standard bed distance is the smart mix's own", STANDARD_BED_DB == bed_offset_db(True))

# applying a kind
m0 = aclip("m", dur=60.0, fit=True, vol=0.7, start=0.0)
a = apply_kind(m0, 'MUSIC', 'ACTION')
check("apply: music + action sets lowering, loudness and the kind", a['kind'] == 'MUSIC' and a['mood'] == 'ACTION' and a['duck'] and a['lvl'] == -7.0 and a['dadj'] == 3.0)
check("apply: volume, marked part and place are left alone", a['vol'] == 0.7 and a['s0'] == 0 and a['fit'])
check("apply: a mood is dropped for a kind that has none", apply_kind(m0, 'AMBIENCE', 'ACTION')['mood'] == 'NONE')
d = apply_kind(m0, 'SFX_IMPACT', 'NONE')
check("apply: an effect stops covering the whole video and plays once", d['once'] and not d['fit'] and not d['loop'] and not d['duck'])
bt = apply_kind(m0, 'BEAT', 'NONE')
check("apply: a beat turns exact repeat on", bt['exact'])
check("apply: switching to music keeps an exact repeat the user chose", apply_kind(dict(m0, exact=True), 'MUSIC', 'NONE')['exact'])
short = apply_kind(aclip("s", dur=60.0, start=5.0, re=9.0, slot="B2"), 'MUSIC', 'NONE')
check("apply: fades leave room in a short range (a quarter each at most)", short['fi'] <= 1.0 and short['fo'] <= 1.0 and short['fi'] == 1.0 and short['fo'] == 1.0)
tiny = apply_kind(aclip("s", dur=60.0, start=5.0, re=6.0, slot="B2"), 'AMBIENCE', 'NONE')
check("apply: a 1 s range gets fades of at most 0.25 s", near(tiny['fi'], 0.25) and near(tiny['fo'], 0.25))

# ---- exact repeats: same length every round, no drift, no click
RATE = 8000
beat_frames = 2 * RATE
src_beat = [math.sin(2 * math.pi * 220 * i / RATE) * 0.5 + (0.4 if i % 2000 < 40 else 0.0) for i in range(beat_frames)]
period = beat_frames
declick = int(DECLICK_SEC * RATE)
rounds = 6
out = fill_looped(src_beat, period, 0, declick, 0, period * rounds)
check("exact: six rounds are exactly six beats long", len(out) == period * rounds)
mid = [i for i in range(period) if min(i, period - 1 - i) >= declick]
check("exact: inside a round the sound is the beat, sample for sample", all(out[r * period + i] == src_beat[i] for r in range(rounds) for i in mid[::37]))
check("exact: the join is smoothed (starts and ends near silence)", all(abs(out[r * period]) < 0.1 and abs(out[r * period + period - 1]) < 0.1 for r in range(rounds)))
jump = max(abs(out[r * period + period] - out[r * period + period - 1]) for r in range(rounds - 1))
raw = max(abs(src_beat[0] - src_beat[-1]), 0.0)
check("exact: no click at the join", jump < 0.1)
check("exact: the fade is only a few thousandths of a second", declick / RATE <= 0.003 + 1e-9 and declick == 24)
check("exact: the fade weights rise smoothly from near 0 to 1", declick_weight(0, 24) < 0.01 and declick_weight(23, 24) > 0.99 and
      all(declick_weight(i, 24) <= declick_weight(i + 1, 24) + 1e-12 for i in range(23)) and declick_weight(24, 24) == 1.0)
# the old blended repeat is shorter than the beat by the blend: its tempo drifts
cross = min(int(1.5 * RATE), beat_frames // 4)
check("blended repeat (the old way) is shorter than the beat, exact is not", (beat_frames - cross) < beat_frames and period == beat_frames)
blend = fill_looped(src_beat, beat_frames - cross, cross, 0, 0, 10)
check("blended repeat still reads from the file after the round (unchanged behaviour)", len(blend) == 10)
check("exact: an offset start (window of a long mix) lands in the right place in the beat", fill_looped(src_beat, period, 0, 0, period + 500, 3) == src_beat[500:503])

# ---- per-sound lowering depth
k1, db1 = duck_curve_key(-14.0, 0.0)
k2, db2 = duck_curve_key(-14.0, 8.0)
k3, db3 = duck_curve_key(-14.0, -4.0)
check("duck depth: no adjustment is exactly the global depth (so old projects sound the same)", db1 == -14.0 and k1 == -140)
check("duck depth: ambience dips less, background voices dip more", db2 == -6.0 and db3 == -18.0)
check("duck depth: kept inside the smart mix's own limits", duck_curve_key(-28.0, -9.0)[1] == -30.0 and duck_curve_key(-5.0, 9.0)[1] == -3.0)
mask = [False] * 50 + [True] * 100 + [False] * 150
g_ref = duck_gains(mask, 10 ** (-14.0 / 20))
g_amb = duck_gains(mask, 10 ** (db2 / 20))
g_voi = duck_gains(mask, 10 ** (db3 / 20))
mid_speech = 100
check("duck depth: under speech the order is ambience (least) > music > background voices (most)", g_amb[mid_speech] > g_ref[mid_speech] > g_voi[mid_speech])
check("duck depth: in the gaps all three are back to full", all(g[290] > 0.99 for g in (g_ref, g_amb, g_voi)))

# ---- loudness distance per sound
check("level: no value uses the smart mix's standard distance", clip_level_offset(aclip("a"), True) == -10 and clip_level_offset(aclip("a"), False) == -18)
check("level: a kind's own value wins", clip_level_offset(aclip("a", lvl=-5.0), True) == -5.0)
voice_db, music_db = -20.0, -32.0
g_std = auto_level_gain(voice_db, music_db, clip_level_offset(aclip("a"), True))
g_sfx = auto_level_gain(voice_db, music_db, clip_level_offset(aclip("a", lvl=-5.0), True))
g_amb2 = auto_level_gain(voice_db, music_db, clip_level_offset(aclip("a", lvl=-20.0), True))
check("level: an effect is brought well above a bed, ambience well below", g_sfx > g_std > g_amb2)
check("level: the effect ends up 5 dB under the voice", near(db_of(g_sfx) + music_db - voice_db, -5.0, 1e-6))

print("\n%d checks passed" % ok)
