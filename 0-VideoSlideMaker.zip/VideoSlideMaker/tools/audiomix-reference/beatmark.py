"""
2.19 reference: marking a part of the ORIGINAL sound, fitting only that part, the sound-kind profiles, exact repeats and
per-sound lowering. A line-for-line mirror of audio/MarkMath.kt, audio/SoundKinds.kt and the 2.19 parts of audio/ClipEdit.kt,
audio/BackgroundSlots.kt and audio/AudioMixRenderer.kt. There is no Kotlin compiler in the sandbox, so the logic is proven
here (python3 run_beat_tests.py) and then ported; app/src/test/.../audio/MarkAndKindTest.kt repeats the same checks.
"""
import math
from smartmix import duck_gains, auto_level_gain, bed_offset_db, db_of

MIN = 0.1
EXACT_LOOP_AUTO_MAX = 8.0
DECLICK_SEC = 0.003
STANDARD_BED_DB = -10.0

# ------------------------------------------------------------------ typed times / mark maths (MarkMath.kt)
def parse_time(text):
    t = text.strip().lower()
    if t.endswith('s'):
        t = t[:-1]
    t = t.strip().replace(',', '.')
    if not t:
        return None
    parts = t.split(':')
    if len(parts) > 3:
        return None
    total = 0.0
    for i, raw in enumerate(parts):
        part = raw.strip()
        if not part:
            return None
        try:
            # only plain digits and one point (Kotlin's own number reader would also take "5d", "1e3" or "0x1p3")
            if not all(ch in '0123456789.' for ch in part):
                return None
            v = float(part)
        except ValueError:
            return None
        if math.isnan(v) or math.isinf(v) or v < 0.0:
            return None
        last = i == len(parts) - 1
        if not last and v != math.floor(v):
            return None
        if i > 0 and v >= 60.0:
            return None
        total = total * 60.0 + v
    return total

def fix(start, end, file_sec):
    if file_sec <= MIN:
        return 0.0, max(file_sec, 0.0)
    a = min(max(min(start, end), 0.0), file_sec)
    b = min(max(max(start, end), 0.0), file_sec)
    if b - a < MIN:
        b = min(a + MIN, file_sec)
        a = max(b - MIN, 0.0)
    return a, b

def with_start(start, end, t, file_sec):
    if math.isnan(t):
        return fix(start, end, file_sec)
    old_len = max(MIN, end - start)
    a = min(max(t, 0.0), max(file_sec - MIN, 0.0))
    b = a + old_len if end < a + MIN else end
    return fix(a, b, file_sec)

def with_end(start, end, t, file_sec):
    if math.isnan(t):
        return fix(start, end, file_sec)
    old_len = max(MIN, end - start)
    b = min(max(t, min(MIN, file_sec)), file_sec)
    a = b - old_len if start > b - MIN else start
    return fix(a, b, file_sec)

def shift(start, end, delta, file_sec):
    ln = max(MIN, end - start)
    a = min(max(start + delta, 0.0), max(file_sec - ln, 0.0))
    return fix(a, a + ln, file_sec)

def nearest_is_start(start, end, t):
    return abs(t - start) <= abs(t - end)

# ------------------------------------------------------------------ clips (AudioClip / ClipEdit)
def aclip(id, dur=60.0, s0=0.0, s1=None, start=0.0, **kw):
    d = dict(id=id, uri='content://x/' + id, dur=dur, s0=s0, s1=dur if s1 is None else s1, start=start,
             fi=0.0, fo=0.0, loop=False, fit=False, slot='', re=0.0, mark=0.0, once=False, exact=False,
             duck=True, dadj=0.0, lvl=None, kind='UNSET', mood='NONE', vol=1.0, muted=False)
    d.update(kw)
    return d

def length(c): return max(0.0, c['s1'] - c['s0'])
def has_mark(c): return c['mark'] > c['s0'] + MIN
def has_range(c): return c['re'] > c['start'] + MIN
def file_end(c): return c['dur'] if c['dur'] > 0 else c['s1']
def material_end(c):
    return max(min(c['mark'], file_end(c)), c['s0']) if has_mark(c) else file_end(c)
def uses_part(c): return c['s0'] > 0.05 or file_end(c) - material_end(c) > 0.05

def trim_end(c, v):
    hi = c['dur'] if c['dur'] > 0 else 1e300
    lo = c['s0'] + MIN
    e = min(max(v, lo), max(lo, hi))
    return dict(c, s1=e, mark=e if c['mark'] > 0 else 0.0)

def split(c, at, new_id):
    if at < MIN or at > length(c) - MIN:
        return [c]
    cut = c['s0'] + at
    first = dict(c, s1=cut, mark=cut if c['mark'] > 0 else 0.0, fo=0.0, loop=False, slot='', re=0.0)
    second = dict(c, id=new_id, s0=cut, start=c['start'] + at, fi=0.0, loop=False, slot='', re=0.0)
    return [first, second]

def keep_only(c, frm, to):
    if c['dur'] <= 0 or math.isnan(frm) or math.isnan(to):
        return c
    fe = c['dur']
    a = min(max(min(frm, to), 0.0), fe)
    b = min(max(max(frm, to), 0.0), fe)
    if b - a < MIN:
        return c
    whole = a <= 1e-6 and b >= fe - 1e-6
    exact = c['exact'] if whole else ((b - a <= EXACT_LOOP_AUTO_MAX) or c['exact'])
    return dict(c, s0=a, s1=b, mark=0.0 if whole else b, exact=exact)

def use_whole_file(c):
    if c['dur'] <= 0:
        return c
    return dict(c, s0=0.0, s1=c['dur'], mark=0.0)

def follow_video(c, total):
    if not c['fit'] or total <= 0:
        return c
    avail = max(material_end(c) - c['s0'], 0.0)
    if avail <= 0:
        return c
    if avail >= total:
        return dict(c, start=0.0, s1=c['s0'] + total, loop=False)
    if c['once']:
        return dict(c, start=0.0, s1=c['s0'] + avail, loop=False)
    return dict(c, start=0.0, s1=c['s0'] + avail, loop=True)

def follow_range(c):
    if c['fit'] or not c['uri'] or not has_range(c):
        return c
    rng = c['re'] - c['start']
    avail = max(material_end(c) - c['s0'], 0.0)
    if avail <= 0:
        return c
    if avail >= rng - 1e-6:
        return dict(c, s1=c['s0'] + rng, loop=False)
    if c['once']:
        return dict(c, s1=c['s0'] + avail, loop=False)
    return dict(c, s1=c['s0'] + avail, loop=True)

def assign_to_slot(src, slot):
    return dict(src, id=slot['id'], slot=slot['slot'], start=slot['start'], re=slot['re'], muted=slot['muted'],
                fit=False, loop=False,
                fi=src['fi'] if src['once'] else max(src['fi'], slot['fi']),
                fo=src['fo'] if src['once'] else max(src['fo'], slot['fo']))

# ------------------------------------------------------------------ sound kinds (SoundKinds.kt)
MUSIC_LIKE = {'MUSIC', 'INSTRUMENTAL', 'BEAT'}
EFFECTS = {'SFX_OBJECT', 'SFX_HUMAN', 'SFX_ANIMAL', 'SFX_IMPACT', 'SFX_WHOOSH'}
KINDS = ['MUSIC', 'INSTRUMENTAL', 'BEAT', 'AMBIENCE', 'NATURE', 'CROWD', 'SFX_OBJECT', 'SFX_HUMAN', 'SFX_ANIMAL',
         'SFX_IMPACT', 'SFX_WHOOSH', 'OTHER']
MOODS_TABLE = {
    'ACTION': (-7.0, 3.0), 'EPIC': (-8.0, 2.0), 'DRAMATIC': (-9.0, 0.0), 'HAPPY': (-9.0, 1.0), 'FUNNY': (-9.0, 1.0),
    'MYSTERY': (-12.0, -1.0), 'DARK': (-12.0, -1.0), 'EMOTIONAL': (-12.0, -2.0), 'CALM': (-13.0, -2.0),
    'ROMANTIC': (-13.0, -2.0),
}
ALL_MOODS = ['NONE'] + list(MOODS_TABLE)

def _music(mood, bonus, beat):
    tune = MOODS_TABLE.get(mood)
    if tune is not None:
        level = tune[0] + bonus
    elif bonus != 0.0:
        level = STANDARD_BED_DB + bonus
    else:
        level = None
    return dict(duck=True, dadj=tune[1] if tune else 0.0, lvl=level, once=False, exact=beat,
                fi=0.2 if beat else 1.0, fo=0.3 if beat else 1.5)

def _effect(level):
    return dict(duck=False, dadj=0.0, lvl=level, once=True, exact=False, fi=0.02, fo=0.05)

def _bed(level, dadj, fade):
    return dict(duck=True, dadj=dadj, lvl=level, once=False, exact=False, fi=fade, fo=fade)

def profile(kind, mood):
    if kind in ('UNSET', 'OTHER'):
        return dict(duck=True, dadj=0.0, lvl=None, once=False, exact=False, fi=1.0, fo=1.0)
    if kind == 'MUSIC': return _music(mood, 0.0, False)
    if kind == 'INSTRUMENTAL': return _music(mood, 1.0, False)
    if kind == 'BEAT': return _music(mood, 0.0, True)
    if kind == 'AMBIENCE': return _bed(-20.0, 8.0, 2.0)
    if kind == 'NATURE': return _bed(-19.0, 8.0, 2.0)
    if kind == 'CROWD': return _bed(-22.0, -4.0, 1.5)
    if kind in ('SFX_OBJECT', 'SFX_HUMAN', 'SFX_ANIMAL'): return _effect(-5.0)
    if kind == 'SFX_IMPACT': return _effect(-3.0)
    if kind == 'SFX_WHOOSH': return _effect(-6.0)
    raise ValueError(kind)

def apply_kind(c, kind, mood):
    used = mood if kind in MUSIC_LIKE else 'NONE'
    p = profile(kind, used)
    room = (c['re'] - c['start']) / 4.0 if has_range(c) else 1e300
    out = dict(c, kind=kind, mood=used, duck=p['duck'], dadj=p['dadj'], lvl=p['lvl'], once=p['once'],
               exact=c['exact'] or p['exact'], fi=min(p['fi'], room), fo=min(p['fo'], room))
    return dict(out, fit=False, loop=False) if p['once'] else out

# ------------------------------------------------------------------ renderer pieces (AudioMixRenderer.kt / SmartMix.kt)
def declick_weight(edge, declick):
    if declick <= 0 or edge >= declick:
        return 1.0
    x = (max(edge, 0) + 0.5) / declick
    return x * x * (3 - 2 * x)

def fill_looped(src, period, cross, declick, pos, n):
    """src: list of floats (the clip). Mirrors fillLooped: returns n output samples starting at loop position pos."""
    def read(i):
        return src[i] if 0 <= i < len(src) else 0.0
    out = []
    produced = 0
    cyc = pos % period
    while produced < n:
        in_head = cross > 0 and cyc < cross
        room = (cross - cyc) if in_head else (period - cyc)
        take = min(room, n - produced)
        chunk = [read(cyc + i) for i in range(take)]
        if in_head:
            for i in range(take):
                x = (cyc + i + 0.5) / cross
                wi = math.sin(min(max(x, 0.0), 1.0) * math.pi / 2)
                wo = math.cos(min(max(x, 0.0), 1.0) * math.pi / 2)
                chunk[i] = chunk[i] * wi + read(period + cyc + i) * wo
        if declick > 0:
            for i in range(take):
                p = cyc + i
                edge = min(p, period - 1 - p)
                if edge < declick:
                    chunk[i] *= declick_weight(edge, declick)
        out.extend(chunk)
        produced += take
        cyc += take
        if cyc >= period:
            cyc = 0
    return out

def duck_curve_key(smart_duck_db, adjust_db, lo=-30.0, hi=-3.0):
    db = min(max(smart_duck_db + adjust_db, lo), hi)
    return int(math.floor(db * 10.0 + 0.5)), db

def clip_level_offset(c, smart_auto_duck):
    return c['lvl'] if c['lvl'] is not None else bed_offset_db(smart_auto_duck)
