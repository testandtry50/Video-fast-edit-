"""
Numerical checks for the voice changer DSP in dsp.py (the Kotlin code in app/.../voicefx/ is a
line-by-line port of it, so these results describe what the app does).

    python3 run_tests.py        (needs numpy and scipy; takes about a minute)
"""
import math, sys
import numpy as np
from scipy.signal import hilbert
from dsp import Fft, PitchShifter, Processor, Rng
from synth import voice, f0_autocorr, fs

failures = []
def check(name, ok, detail=""):
    print(("PASS  " if ok else "FAIL  ") + name + ("  - " + detail if detail else ""))
    if not ok: failures.append(name)

rms = lambda a: math.sqrt(float(np.mean(np.asarray(a) ** 2)))
db = lambda v: 20 * math.log10(max(v, 1e-12))

# 1. FFT agrees with numpy
f = Fft(256); x = np.random.default_rng(1).standard_normal(256) + 0j
re, im = list(x.real), list(x.imag); f.transform(re, im)
check("fft matches numpy", np.max(np.abs(np.array(re) + 1j * np.array(im) - np.fft.fft(x))) < 1e-9)

# 2. pitch accuracy and level on a clean tone
t = np.arange(int(1.3 * fs)) / fs
tone = 0.5 * np.sin(2 * np.pi * 220 * t)
for st in (-7.0, -2.35, 0.05, 2.35, 7.0):
    p = PitchShifter(fs); p.set_semitones(st)
    out = np.array([p.process(v) for v in list(tone) + [0.0] * p.latency])[p.latency:]
    seg = out[int(0.4 * fs):int(0.4 * fs) + 32768]
    spec = np.abs(np.fft.rfft(seg * np.hanning(len(seg)), 1 << 17)); fr = np.fft.rfftfreq(1 << 17, 1 / fs)
    i = int(np.argmax(spec * ((fr > 50) & (fr < 8000))))
    a, b, c = np.log(spec[i - 1]), np.log(spec[i]), np.log(spec[i + 1]); d = 0.5 * (a - c) / (a - 2 * b + c)
    got = (i + d) * fs / (1 << 17); want = 220 * 2 ** (st / 12)
    cents = 1200 * math.log2(got / want)
    amp_db = db(np.max(np.abs(out[int(0.4 * fs):int(1.0 * fs)])) / 0.5)
    check(f"pitch {st:+.2f} st", abs(cents) < 3 and abs(amp_db) < 1.5, f"{cents:+.2f} cents, level {amp_db:+.2f} dB")

# 3. speech-like voice: F0 ratio, level, alignment
v, _ = voice(1.6)
for st in (3.0, -3.0):
    p = Processor(fs, pitch=st); l, _r = p.run(v)
    ratios = []
    for s0 in (0.15, 0.67, 1.19):
        a, b = int((s0 + 0.08) * fs), int((s0 + 0.22) * fs)
        ratios.append(f0_autocorr(l[a:b]) / f0_autocorr(v[a:b]))
    want = 2 ** (st / 12)
    check(f"voice F0 {st:+.0f} st", all(abs(r / want - 1) < 0.01 for r in ratios), f"ratios {[round(r, 4) for r in ratios]} want {want:.4f}")
    check(f"voice level {st:+.0f} st", abs(db(rms(l) / rms(v))) < 1.0, f"{db(rms(l) / rms(v)):+.2f} dB")
    def env(s): k = int(0.006 * fs); return np.convolve(s ** 2, np.ones(k) / k, 'same')
    ei, eo = env(v), env(l)
    best = max(range(-400, 400, 2), key=lambda L: np.dot(ei[3000:-3000], np.roll(eo, -L)[3000:-3000]))
    check(f"stays in sync {st:+.0f} st", abs(best) / fs < 0.008, f"{best / fs * 1000:+.2f} ms")

# 4. humanize: drift, room tone, level, alignment
tt = np.arange(int(6 * fs)) / fs; tn = 0.3 * np.sin(2 * np.pi * 1000 * tt)
l, _r = Processor(fs, humanize=1.0).run(tn)
inst = np.diff(np.unwrap(np.angle(hilbert(l)))) * fs / (2 * np.pi); k = int(0.04 * fs)
inst = np.convolve(inst, np.ones(k) / k, 'same'); cents = 1200 * np.log2(inst[fs // 2:-fs // 2] / 1000)
check("humanize drift stays within +-12 cents", cents.max() < 12 and cents.min() > -12 and cents.std() > 1.5, f"{cents.min():+.1f}..{cents.max():+.1f}")
l, _r = Processor(fs, humanize=1.0).run(np.zeros(3 * fs))
check("room tone is faint (-55..-48 dBFS at 100%)", -55 < db(rms(l)) < -48, f"{db(rms(l)):.1f} dBFS")
l, _r = Processor(fs, humanize=0.0).run(np.zeros(fs))
check("humanize 0 adds nothing", float(np.max(np.abs(l))) == 0.0)
l, _r = Processor(fs, humanize=1.0).run(v)
check("humanize keeps level within 3 dB", abs(db(rms(l) / rms(v))) < 3.0, f"{db(rms(l) / rms(v)):+.2f} dB")
p = Processor(fs, humanize=0.8); l, _r = p.run(v)
a0, b0 = int(0.2 * fs), int(1.2 * fs)
best = max(range(-300, 300), key=lambda L: np.dot(v[a0:b0], l[a0 + L:b0 + L]))
check("humanize waveform stays aligned", abs(best) < 30, f"{best} samples")

# 5. breaths only in real pauses
vv, _ = voice(1.0, seed=3)
sig = np.concatenate([vv, np.zeros(int(1.2 * fs)), vv])
l, _r = Processor(fs, breaths=True).run(sig); d = l - sig
n1, n2 = len(vv), len(vv) + int(1.2 * fs)
act = np.where(np.abs(d) > 1e-5)[0]
check("breath lands inside the pause", len(act) > 0 and act.min() >= n1 and act.max() < n2, f"{act.min() / fs:.2f}-{act.max() / fs:.2f} s")
check("breath is quiet (peak below -26 dBFS)", db(float(np.max(np.abs(d)))) < -26, f"{db(float(np.max(np.abs(d)))):.1f} dBFS")
sig2 = np.concatenate([vv, np.zeros(int(0.15 * fs)), vv])
l2, _r = Processor(fs, breaths=True).run(sig2)
check("no breath in a short pause", float(np.max(np.abs(l2 - sig2))) == 0.0)

# 6. every effect: finite, bounded, sane level, and silence in -> (nearly) silence out
for name in ('aqua', 'revolve', 'room', 'hall', 'cave', 'echo', 'robot', 'telephone', 'megaphone', 'whisper'):
    for a in (0.0, 0.6, 1.0):
        l, r = Processor(fs, effect=name, amount=a).run(v)
        ok = bool(np.all(np.isfinite(l)) and np.all(np.isfinite(r)) and max(np.max(np.abs(l)), np.max(np.abs(r))) < 1.0)
        lvl = db(rms(np.concatenate([l, r])) / rms(v))
        check(f"effect {name} {a:.1f}", ok and -7 < lvl < 5, f"{lvl:+.1f} dB")
l, r = Processor(fs, effect='revolve', amount=1.0, speed=1.0).run(np.tile(v, 3)[:int(6 * fs)])
w = int(0.5 * fs); bal = [db(rms(l[i:i + w]) / max(rms(r[i:i + w]), 1e-9)) for i in range(0, len(l) - w, w)]
check("revolve moves the voice between the ears", max(bal) > 3 and min(bal) < -3, f"L/R balance swings {min(bal):+.1f}..{max(bal):+.1f} dB")

# 7. combinations stay finite, and streaming in odd chunk sizes is irrelevant (state is kept)
l1, r1 = Processor(fs, pitch=-2.5, humanize=0.7, breaths=True, effect='hall', amount=0.8).run(v)
check("all stages together are finite and bounded", bool(np.all(np.isfinite(l1)) and np.max(np.abs(l1)) < 1.0))

print()
print("ALL PASSED" if not failures else "FAILED: " + ", ".join(failures))
sys.exit(1 if failures else 0)
