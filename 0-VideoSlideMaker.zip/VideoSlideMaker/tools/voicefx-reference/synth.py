import numpy as np, math
from scipy.signal import lfilter
fs = 44100

def voice(dur=2.0, f0_base=120.0, seed=1):
    """Speech-like test signal: glottal pulse train with moving F0, three formants, syllable bursts."""
    rng = np.random.default_rng(seed)
    n = int(dur*fs)
    t = np.arange(n)/fs
    f0 = f0_base + 12*np.sin(2*np.pi*0.7*t)
    phase = np.cumsum(f0)/fs
    # band-limited-ish pulse: sum of harmonics with 1/h^1.5 roll-off
    x = np.zeros(n)
    for h in range(1, 60):
        fh = f0*h
        a = 1.0/(h**1.5)
        a = a*(fh < 0.45*fs)
        x += a*np.sin(2*np.pi*h*phase)
    # formants
    y = x
    for fc, bw in ((700, 90), (1220, 110), (2600, 160)):
        r = math.exp(-math.pi*bw/fs); th = 2*math.pi*fc/fs
        y = lfilter([1-r], [1, -2*r*math.cos(th), r*r], y)
    y /= np.max(np.abs(y))
    # syllable envelope: 0.30 s voiced, 0.22 s gap
    env = np.zeros(n)
    period = 0.52
    for k in range(int(dur/period)+1):
        s0 = 0.15 + k*period
        for i in range(int(s0*fs), min(n, int((s0+0.30)*fs))):
            u = (i/fs - s0)/0.30
            env[i] = math.sin(math.pi*u)**0.6
    return (0.6*y*env).astype(np.float64), env

def f0_autocorr(seg, lo=70, hi=400):
    seg = seg - np.mean(seg)
    ac = np.correlate(seg, seg, 'full')[len(seg)-1:]
    lags = np.arange(int(fs/hi), int(fs/lo))
    k = lags[np.argmax(ac[lags])]
    # parabolic refine
    a, b, c = ac[k-1], ac[k], ac[k+1]
    d = 0.5*(a-c)/(a-2*b+c)
    return fs/(k+d)
