"""Mirror of app/.../export/SincResampler.kt (band-limited resampler) plus the measurement that motivated it.

    python3 resample_check.py

Prints how much of the voice's "mirror image" (the part above the source's own Nyquist frequency) is left after
converting a phone-voice-like signal to 44.1 kHz with (a) the old straight-line interpolation and (b) this filter.
The image is harmless at normal pitch, but the voice changer moves it down into the audible range as hiss.
"""
import math
import numpy as np

HALF_WIDTH, KAISER_BETA, CUTOFF_MARGIN, MAX_PHASES = 32.0, 10.0, 0.93, 2048

class Plan:
    def __init__(self, src, dst):
        g = math.gcd(src, dst)
        self.s, self.d = src // g, dst // g
        self.phases = min(self.d, MAX_PHASES)
        cutoff = min(1.0, dst / src) * CUTOFF_MARGIN
        self.h = int(math.ceil(HALF_WIDTH / cutoff))
        self.taps = 2 * self.h
        norm = np.i0(KAISER_BETA)
        table = np.zeros((self.phases, self.taps))
        t = np.arange(self.taps) - self.h + 1
        for p in range(self.phases):
            x = p / self.phases - t
            safe = np.where(np.abs(x) < 1e-12, 1.0, x)
            sinc = np.where(np.abs(x) < 1e-12, cutoff, np.sin(math.pi * cutoff * x) / (math.pi * safe))
            r = x / self.h
            w = np.where(np.abs(r) < 1.0, np.i0(KAISER_BETA * np.sqrt(np.maximum(0.0, 1.0 - r * r))) / norm, 0.0)
            row = sinc * w
            table[p] = row / row.sum()
        self.table = table.astype(np.float32)

class Channel:
    def __init__(self, plan):
        self.p = plan
        self.tail = np.zeros(plan.h, dtype=np.float32)
        self.tail_start = -plan.h
        self.out_index = 0

    def push(self, x):
        p = self.p
        count = len(x)
        if count <= 0:
            return np.zeros(0, dtype=np.float32)
        work = np.concatenate([self.tail, x.astype(np.float32)])
        work_start = self.tail_start
        avail = work_start + len(work)
        out = []
        while True:
            num = self.out_index * p.s
            base = num // p.d
            phase = int((num % p.d) / p.d * p.phases + 0.5)
            if phase >= p.phases:
                phase = 0
                base += 1
            if base + p.h >= avail:
                break
            first = base - p.h + 1 - work_start
            out.append(float(np.dot(work[first:first + p.taps].astype(np.float64), p.table[phase].astype(np.float64))))
            self.out_index += 1
        next_base = (self.out_index * p.s) // p.d
        keep_from = max(work_start, next_base - p.h + 1)
        frm = min(max(keep_from - work_start, 0), len(work))
        self.tail = work[frm:]
        self.tail_start = work_start + frm
        return np.array(out, dtype=np.float32)

    def finish(self):
        return self.push(np.zeros(self.p.h, dtype=np.float32))

def convert_whole(x, src, dst):
    plan = Plan(src, dst)
    ch = Channel(plan)
    dst_len = int(round(len(x) * dst / src))
    a = ch.push(x)
    b = ch.finish()
    return np.concatenate([a, b])[:dst_len]

def linear(x, src, dst):
    ratio = dst / src
    n = int(round(len(x) * ratio))
    pos = np.arange(n) / ratio
    i0 = np.clip(pos.astype(int), 0, len(x) - 1)
    i1 = np.minimum(i0 + 1, len(x) - 1)
    fr = pos - i0
    return x[i0] * (1 - fr) + x[i1] * fr

def tone_power(x, fs, f):
    """Amplitude of the component at f (Hann-windowed, so a strong tone does not leak into far-away bins)."""
    n = np.arange(len(x))
    w = 0.5 - 0.5 * np.cos(2 * math.pi * n / len(x))
    return abs(np.sum(x * w * np.exp(-2j * math.pi * f * n / fs))) / np.sum(w) * 2

if __name__ == '__main__':
    # 1) image of an 8 kHz tone from a 22.05 kHz source: appears at 14.05 kHz in the 44.1 kHz output
    src, dst = 22050, 44100
    n = src
    tone = (0.5 * np.sin(2 * math.pi * 8000 * np.arange(n) / src)).astype(np.float32)
    for name, y in (("linear (old)", linear(tone, src, dst)), ("sinc   (new)", convert_whole(tone, src, dst))):
        seg = y[4000:4000 + 32768]
        wanted = tone_power(seg, dst, 8000.0)
        image = tone_power(seg, dst, 14050.0)
        print(f"{name}: tone {20*math.log10(wanted):6.1f} dBFS, image {20*math.log10(image + 1e-12):6.1f} dBFS  -> image is {20*math.log10(image/wanted + 1e-12):6.1f} dB below the tone")
    # 2) level of a 1 kHz tone, 22.05k -> 44.1k and 48k -> 44.1k
    for s2 in (22050, 24000, 48000, 16000):
        t = (0.5 * np.sin(2 * math.pi * 1000 * np.arange(s2) / s2)).astype(np.float32)
        y = convert_whole(t, s2, 44100)
        seg = y[3000:3000 + 20000]
        print(f"{s2}->44100: 1 kHz tone level {20*math.log10(tone_power(seg,44100,1000.0)/0.5):+.3f} dB, length {len(y)} (expected {round(s2 and len(t)*44100/s2)})")
    # 3) streaming in odd pieces equals the whole
    x = (np.random.default_rng(3).standard_normal(30000) * 0.1).astype(np.float32)
    whole = convert_whole(x, 24000, 44100)
    plan = Plan(24000, 44100)
    ch = Channel(plan)
    pieces, pos, k = [], 0, 0
    sizes = [7, 1000, 36, 8192, 1, 5000]
    while pos < len(x):
        m = min(sizes[k % len(sizes)], len(x) - pos)
        pieces.append(ch.push(x[pos:pos + m])); pos += m; k += 1
    got = np.concatenate(pieces)
    m = min(len(got), len(whole))
    print("streaming vs whole: common length", m, "max difference", float(np.max(np.abs(got[:m] - whole[:m]))))
