"""Prints the numbers that app/src/test/.../voicefx/VoiceFxTest.kt compares the Kotlin code against."""
import math
from dsp import Processor, Rng

fs = 44100
N = 8000
IDX = (3000, 6000, 7999)

def signal(i):
    t = i / fs
    return 0.5 * math.sin(2 * math.pi * 220 * t) + 0.2 * math.sin(2 * math.pi * 1375 * t)

cases = [
    ("pitch +3",          dict(pitch=3.0)),
    ("humanize 0.5",      dict(humanize=0.5)),
    ("aqua 0.5/0.5",      dict(effect='aqua', amount=0.5, speed=0.5)),
    ("revolve 0.75/0.5",  dict(effect='revolve', amount=0.75, speed=0.5)),
    ("hall 0.5",          dict(effect='hall', amount=0.5)),
    ("whisper 0.5",       dict(effect='whisper', amount=0.5)),
    ("echo 0.5",          dict(effect='echo', amount=0.5)),
    ("megaphone 0.5",     dict(effect='megaphone', amount=0.5)),
    ("combo",             dict(pitch=-2.5, humanize=0.75, effect='robot', amount=0.5)),
]
r = Rng(0x2545F491)
print("rng:", [repr(r.next()) for _ in range(3)], "u32:", r.next_u32())
for name, kw in cases:
    p = Processor(fs, **kw)
    out = {}
    for i in range(N):
        l, rr = p.process(signal(i))
        if i in IDX:
            out[i] = (l, rr)
    print(name)
    for i in IDX:
        print("   ", i, "%.12f" % out[i][0], "%.12f" % out[i][1])
