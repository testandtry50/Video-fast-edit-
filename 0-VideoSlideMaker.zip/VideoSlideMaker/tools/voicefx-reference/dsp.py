"""
Reference implementation of the voice changer DSP (pitch shift, humanize, effects).

This file is the design oracle for app/src/main/java/.../voicefx/*.kt: the Kotlin code is a
line-by-line port, so what is measured here (pitch accuracy, alignment, level, stability) is
what the app does. Everything is streaming, one sample at a time, mono in -> stereo out.
"""
import math
import numpy as np

TWO_PI = 2.0 * math.pi


class Rng:
    """xorshift32 - identical in Kotlin, so noise is deterministic."""
    def __init__(self, seed=0x2545F491):
        self.s = (seed & 0xFFFFFFFF) or 1

    def next_u32(self):
        x = self.s
        x ^= (x << 13) & 0xFFFFFFFF
        x ^= x >> 17
        x ^= (x << 5) & 0xFFFFFFFF
        self.s = x
        return x

    def next(self):  # [-1, 1)
        return (self.next_u32() >> 8) / 8388608.0 - 1.0

    def unit(self):  # [0, 1)
        return (self.next_u32() >> 8) / 16777216.0


# --------------------------------------------------------------------------- FFT
class Fft:
    """In-place iterative radix-2 complex FFT on separate re/im arrays (forward, unnormalised)."""
    def __init__(self, n):
        self.n = n
        self.cos = [math.cos(TWO_PI * i / n) for i in range(n // 2)]
        self.sin = [math.sin(TWO_PI * i / n) for i in range(n // 2)]
        bits = n.bit_length() - 1
        self.rev = [int(format(i, '0%db' % bits)[::-1], 2) for i in range(n)]

    def transform(self, re, im, inverse=False):
        n = self.n
        rev = self.rev
        for i in range(n):
            j = rev[i]
            if j > i:
                re[i], re[j] = re[j], re[i]
                im[i], im[j] = im[j], im[i]
        size = 2
        while size <= n:
            half = size // 2
            step = n // size
            for start in range(0, n, size):
                k = 0
                for j in range(start, start + half):
                    wr = self.cos[k]
                    wi = -self.sin[k] if not inverse else self.sin[k]
                    xr = re[j + half] * wr - im[j + half] * wi
                    xi = re[j + half] * wi + im[j + half] * wr
                    re[j + half] = re[j] - xr
                    im[j + half] = im[j] - xi
                    re[j] += xr
                    im[j] += xi
                    k += step
            size *= 2


# --------------------------------------------------------------------------- Biquad
class Biquad:
    def __init__(self):
        self.b0 = 1.0; self.b1 = 0.0; self.b2 = 0.0; self.a1 = 0.0; self.a2 = 0.0
        self.z1 = 0.0; self.z2 = 0.0

    def set(self, b0, b1, b2, a0, a1, a2):
        self.b0 = b0 / a0; self.b1 = b1 / a0; self.b2 = b2 / a0
        self.a1 = a1 / a0; self.a2 = a2 / a0

    def process(self, x):
        y = self.b0 * x + self.z1
        self.z1 = self.b1 * x - self.a1 * y + self.z2
        self.z2 = self.b2 * x - self.a2 * y
        return y

    @staticmethod
    def _w(fs, f0):
        f0 = min(max(f0, 10.0), fs * 0.45)
        return TWO_PI * f0 / fs

    def lowpass(self, fs, f0, q):
        w = self._w(fs, f0); c = math.cos(w); al = math.sin(w) / (2 * q)
        self.set((1 - c) / 2, 1 - c, (1 - c) / 2, 1 + al, -2 * c, 1 - al); return self

    def highpass(self, fs, f0, q):
        w = self._w(fs, f0); c = math.cos(w); al = math.sin(w) / (2 * q)
        self.set((1 + c) / 2, -(1 + c), (1 + c) / 2, 1 + al, -2 * c, 1 - al); return self

    def bandpass(self, fs, f0, q):  # constant 0 dB peak gain
        w = self._w(fs, f0); c = math.cos(w); al = math.sin(w) / (2 * q)
        self.set(al, 0.0, -al, 1 + al, -2 * c, 1 - al); return self

    def low_shelf(self, fs, f0, gain_db):
        a = 10 ** (gain_db / 40); w = self._w(fs, f0); c = math.cos(w); s = math.sin(w)
        beta = 2 * math.sqrt(a) * (s / 2) * math.sqrt(2.0)  # shelf slope S = 1
        self.set(a * ((a + 1) - (a - 1) * c + beta), 2 * a * ((a - 1) - (a + 1) * c),
                 a * ((a + 1) - (a - 1) * c - beta), (a + 1) + (a - 1) * c + beta,
                 -2 * ((a - 1) + (a + 1) * c), (a + 1) + (a - 1) * c - beta); return self

    def high_shelf(self, fs, f0, gain_db):
        a = 10 ** (gain_db / 40); w = self._w(fs, f0); c = math.cos(w); s = math.sin(w)
        beta = 2 * math.sqrt(a) * (s / 2) * math.sqrt(2.0)
        self.set(a * ((a + 1) + (a - 1) * c + beta), -2 * a * ((a - 1) + (a + 1) * c),
                 a * ((a + 1) + (a - 1) * c - beta), (a + 1) - (a - 1) * c + beta,
                 2 * ((a - 1) - (a + 1) * c), (a + 1) - (a - 1) * c - beta); return self


class OnePole:
    """y += k (x - y). k from a cutoff in Hz."""
    def __init__(self, fs, fc):
        self.y = 0.0
        self.set_cutoff(fs, fc)

    def set_cutoff(self, fs, fc):
        self.k = 1.0 - math.exp(-TWO_PI * min(fc, fs * 0.45) / fs)

    def process(self, x):
        self.y += self.k * (x - self.y)
        return self.y


# --------------------------------------------------------------------------- delay line
class DelayLine:
    """Circular buffer. write() then read(d) with d >= 1 sample (cubic interpolation)."""
    def __init__(self, max_samples):
        size = 1
        while size < max_samples + 8:
            size *= 2
        self.buf = [0.0] * size
        self.mask = size - 1
        self.w = 0

    def write(self, x):
        self.w = (self.w + 1) & self.mask
        self.buf[self.w] = x

    def read_int(self, d):
        return self.buf[(self.w - d) & self.mask]

    def read(self, d):
        pos = self.w - d
        i = math.floor(pos)
        f = pos - i
        m = self.mask
        y0 = self.buf[(i - 1) & m]; y1 = self.buf[i & m]
        y2 = self.buf[(i + 1) & m]; y3 = self.buf[(i + 2) & m]
        c1 = 0.5 * (y2 - y0)
        c2 = y0 - 2.5 * y1 + 2.0 * y2 - 0.5 * y3
        c3 = 0.5 * (y3 - y0) + 1.5 * (y1 - y2)
        return ((c3 * f + c2) * f + c1) * f + y1


# --------------------------------------------------------------------------- pitch shifter
GAIN = 2.0 / 1.5  # calibrated: unity level at osamp 8 with Hann analysis+synthesis windows


class PitchShifter:
    """Phase-vocoder pitch shifter (peak-locked). Measured: output sample i is the input at i - DELAY (DELAY = N)."""
    N = 2048
    OSAMP = 8

    def __init__(self, fs):
        n = self.N
        self.fs = fs
        self.step = n // self.OSAMP
        self.fifo_offset = n - self.step   # where new input starts inside the frame buffer
        self.latency = n                    # measured end-to-end delay in samples (see test_lat)
        self.fft = Fft(n)
        self.window = [-0.5 * math.cos(TWO_PI * k / n) + 0.5 for k in range(n)]
        self.in_fifo = [0.0] * n
        self.out_fifo = [0.0] * n
        self.accum = [0.0] * (2 * n)
        self.last_phase = [0.0] * (n // 2 + 1)
        self.syn_phase = [0.0] * (n // 2 + 1)
        self.ana_magn = [0.0] * (n // 2 + 1)
        self.ana_phase = [0.0] * (n // 2 + 1)
        self.new_phase = [0.0] * (n // 2 + 1)
        self.peaks = [0] * (n // 2 + 2)
        self.syn_magn = [0.0] * (n // 2 + 1)
        self.syn_freq = [0.0] * (n // 2 + 1)
        self.re = [0.0] * n
        self.im = [0.0] * n
        self.rover = self.fifo_offset
        self.ratio = 1.0

    def set_semitones(self, st):
        self.ratio = 2.0 ** (st / 12.0)

    def process(self, x):
        n = self.N
        self.in_fifo[self.rover] = x
        y = self.out_fifo[self.rover - self.fifo_offset]
        self.rover += 1
        if self.rover >= n:
            self.rover = self.fifo_offset
            self._frame()
        return y

    def _frame(self):
        """One analysis/synthesis frame with identity phase locking (Laroche & Dolson 1999):
        every spectral peak is moved to its new bin as a unit, so the bins around a harmonic keep
        their phase relationship and the voice does not turn watery/phasey."""
        n = self.N; half = n // 2; osamp = self.OSAMP; step = self.step
        freq_per_bin = self.fs / n
        expct = TWO_PI * step / n
        re = self.re; im = self.im
        for k in range(n):
            re[k] = self.in_fifo[k] * self.window[k]
            im[k] = 0.0
        self.fft.transform(re, im)
        magn = self.ana_magn
        phs = self.ana_phase
        for k in range(half + 1):
            magn[k] = math.sqrt(re[k] * re[k] + im[k] * im[k])
            phs[k] = math.atan2(im[k], re[k])

        # peaks: strictly larger than two neighbours on each side
        npeaks = 0
        peaks = self.peaks
        for k in range(2, half - 1):
            m = magn[k]
            if m > 1e-9 and m > magn[k - 1] and m > magn[k + 1] and m >= magn[k - 2] and m >= magn[k + 2]:
                peaks[npeaks] = k
                npeaks += 1

        for k in range(half + 1):
            self.syn_magn[k] = 0.0
        if npeaks == 0:
            peaks[0] = 0  # silence / pure noise floor: nothing to move
        r = self.ratio
        lower = 0
        for pi in range(npeaks):
            kp = peaks[pi]
            upper = (kp + peaks[pi + 1]) // 2 if pi + 1 < npeaks else half
            # true frequency of the peak from its phase advance since the last frame
            tmp = phs[kp] - self.last_phase[kp]
            tmp -= kp * expct
            qpd = int(tmp / math.pi)
            if qpd >= 0:
                qpd += qpd & 1
            else:
                qpd -= qpd & 1
            tmp -= math.pi * qpd
            tmp = osamp * tmp / TWO_PI
            true_freq = kp * freq_per_bin + tmp * freq_per_bin
            q = int(math.floor(kp * r + 0.5))
            if q > half:
                lower = upper + 1
                continue
            adv = (true_freq * r - q * freq_per_bin) / freq_per_bin
            adv = TWO_PI * adv / osamp + q * expct
            peak_phase = self.syn_phase[q] + adv
            delta = q - kp
            for k in range(lower, upper + 1):
                d = k + delta
                if d < 0 or d > half:
                    continue
                if magn[k] >= self.syn_magn[d]:
                    self.syn_magn[d] = magn[k]
                    self.new_phase[d] = peak_phase + (phs[k] - phs[kp])
            lower = upper + 1
        for k in range(half + 1):
            self.last_phase[k] = phs[k]
        for k in range(half + 1):
            if self.syn_magn[k] > 0.0:
                ph = self.new_phase[k]
                ph -= TWO_PI * math.floor(ph / TWO_PI + 0.5)   # keep in [-pi, pi): hours of audio stay exact
                self.syn_phase[k] = ph
                m = self.syn_magn[k] * 2.0
                re[k] = m * math.cos(ph)
                im[k] = m * math.sin(ph)
            else:
                re[k] = 0.0
                im[k] = 0.0
        for k in range(half + 1, n):
            re[k] = 0.0
            im[k] = 0.0
        self.fft.transform(re, im, inverse=True)
        scale = GAIN / (half * osamp)
        for k in range(n):
            self.accum[k] += self.window[k] * re[k] * scale
        for k in range(step):
            self.out_fifo[k] = self.accum[k]
        for k in range(n):
            self.accum[k] = self.accum[k + step]
        for k in range(n, 2 * n):
            self.accum[k] = 0.0
        for k in range(self.fifo_offset):
            self.in_fifo[k] = self.in_fifo[k + step]


# --------------------------------------------------------------------------- reverb (Freeverb)
class Reverb:
    COMB_L = [1116, 1188, 1277, 1356, 1422, 1491, 1557, 1617]
    ALLPASS = [556, 441, 341, 225]
    SPREAD = 23

    def __init__(self, fs, room, damp, wet, predelay_ms=0.0):
        sc = fs / 44100.0
        self.combs_l = [[0.0] * max(1, round(n * sc)) for n in self.COMB_L]
        self.combs_r = [[0.0] * max(1, round((n + self.SPREAD) * sc)) for n in self.COMB_L]
        self.ci_l = [0] * 8; self.ci_r = [0] * 8
        self.cs_l = [0.0] * 8; self.cs_r = [0.0] * 8
        self.ap_l = [[0.0] * max(1, round(n * sc)) for n in self.ALLPASS]
        self.ap_r = [[0.0] * max(1, round((n + self.SPREAD) * sc)) for n in self.ALLPASS]
        self.ai_l = [0] * 4; self.ai_r = [0] * 4
        self.feedback = room * 0.28 + 0.7
        self.damp1 = damp * 0.4
        self.damp2 = 1.0 - self.damp1
        self.wet = wet
        pd = int(predelay_ms * 0.001 * fs)
        self.pre = DelayLine(max(pd, 1) + 2)
        self.pre_n = pd

    def process(self, l, r):
        """Returns ONLY the reverberated signal (caller adds it to the dry signal)."""
        x = (l + r) * 0.015
        if self.pre_n > 0:
            self.pre.write(x)
            x = self.pre.read_int(self.pre_n)
        out_l = 0.0; out_r = 0.0
        fb = self.feedback; d1 = self.damp1; d2 = self.damp2
        for i in range(8):
            b = self.combs_l[i]; k = self.ci_l[i]
            o = b[k]; self.cs_l[i] = o * d2 + self.cs_l[i] * d1
            b[k] = x + self.cs_l[i] * fb
            self.ci_l[i] = k + 1 if k + 1 < len(b) else 0
            out_l += o
            b = self.combs_r[i]; k = self.ci_r[i]
            o = b[k]; self.cs_r[i] = o * d2 + self.cs_r[i] * d1
            b[k] = x + self.cs_r[i] * fb
            self.ci_r[i] = k + 1 if k + 1 < len(b) else 0
            out_r += o
        for i in range(4):
            b = self.ap_l[i]; k = self.ai_l[i]
            bo = b[k]; b[k] = out_l + bo * 0.5; out_l = -out_l + bo
            self.ai_l[i] = k + 1 if k + 1 < len(b) else 0
            b = self.ap_r[i]; k = self.ai_r[i]
            bo = b[k]; b[k] = out_r + bo * 0.5; out_r = -out_r + bo
            self.ai_r[i] = k + 1 if k + 1 < len(b) else 0
        return out_l * self.wet, out_r * self.wet


def soft_limit(y):
    a = abs(y)
    if a <= 0.9:
        return y
    s = 0.9 + 0.1 * math.tanh((a - 0.9) / 0.1)
    return s if y > 0 else -s


# --------------------------------------------------------------------------- humanizer
NOISE_NORM = 3.55   # makes the room-tone chain (noise -> 3.5 kHz low-pass -> 90 Hz high-pass) unit RMS
BREATH_NORM = 4.95  # same for the breath chain (noise -> band-pass 1.4 kHz)


class Humanizer:
    """Makes a too-clean synthetic voice feel recorded: tiny pitch drift, warmth, gentle dynamics,
    room tone, a hint of room reflections and (optionally) soft breaths between phrases."""
    BASE_DELAY_S = 0.002

    def __init__(self, fs, h, breaths, seed=0x1234ABCD):
        self.fs = fs
        self.h = h
        self.breaths = breaths
        self.rng = Rng(seed)
        self.wobble_on = h > 0.001
        self.base = int(round(self.BASE_DELAY_S * fs))
        self.latency = self.base if self.wobble_on else 0
        self.depth = 0.0008 * h * fs
        self.dly = DelayLine(self.base + int(self.depth) + 8)
        self.ph = [0.0, 1.3, 4.1]
        self.inc = [TWO_PI * f / fs for f in (0.37, 1.13, 3.7)]
        self.low = Biquad().low_shelf(fs, 180.0, 2.2 * h)
        self.high = Biquad().high_shelf(fs, 7000.0, -3.0 * h)
        # compressor / saturation
        self.thr = 0.07
        self.ratio = 1.0 + 1.4 * h
        self.att = math.exp(-1.0 / (0.006 * fs))
        self.rel = math.exp(-1.0 / (0.160 * fs))
        self.env = 0.0
        self.makeup = 10 ** (6.0 * (1.0 - 1.0 / self.ratio) / 20.0)
        self.drive = 1.0 + 0.8 * h
        # room tone
        self.tone_lp = OnePole(fs, 3500.0)
        self.tone_hp = Biquad().highpass(fs, 90.0, 0.7)
        self.tone_gain = 10 ** ((-64.0 + 12.0 * h) / 20.0) * NOISE_NORM
        self.tone_ph = 0.0
        self.tone_inc = TWO_PI * 0.23 / fs
        # reflections
        self.taps = [int(round(ms * 0.001 * fs)) for ms in (7.0, 13.0, 19.0, 29.0)]
        self.tap_gain = [0.22 * h, 0.16 * h, 0.12 * h, 0.08 * h]
        self.refl = DelayLine(self.taps[-1] + 4)
        # breaths
        self.b_env = 0.0
        self.b_silence = 0
        self.b_speech = 0
        self.b_armed = False
        self.b_pos = -1
        self.b_len = 0
        self.b_amp = 0.0
        self.b_gain = 1.0
        self.b_level = 0.0
        self.b_bp = Biquad().bandpass(fs, 1400.0, 0.7)
        self.b_att = math.exp(-1.0 / (0.003 * fs))
        self.b_rel = math.exp(-1.0 / (0.080 * fs))

    def _breath(self, x):
        ax = abs(x)
        c = self.b_att if ax > self.b_env else self.b_rel
        self.b_env = c * self.b_env + (1.0 - c) * ax
        fs = self.fs
        voiced = self.b_env > 0.004
        if voiced:
            self.b_speech += 1
            self.b_silence = 0
            if self.b_env > self.b_level:
                self.b_level = self.b_env
            if self.b_speech > int(0.4 * fs):
                self.b_armed = True
        else:
            self.b_speech = 0
            self.b_silence += 1
            self.b_level *= 0.99999
            if self.b_armed and self.b_pos < 0 and self.b_silence >= int(0.20 * fs):
                self.b_armed = False
                self.b_pos = 0
                self.b_len = int((0.30 + 0.12 * self.rng.unit()) * fs)
                self.b_amp = min(0.012, max(0.001, 0.03 * self.b_level))
                self.b_gain = 1.0
        if self.b_pos < 0:
            return 0.0
        if voiced:
            self.b_gain *= 0.997
        n = self.rng.next()
        shape = math.sin(math.pi * self.b_pos / self.b_len)
        y = self.b_bp.process(n) * BREATH_NORM * shape * shape * self.b_amp * self.b_gain
        self.b_pos += 1
        if self.b_pos >= self.b_len or self.b_gain < 0.001:
            self.b_pos = -1
        return y

    def process(self, x):
        h = self.h
        breath = self._breath(x) if self.breaths else 0.0
        y = x
        if self.wobble_on:
            for i in range(3):
                self.ph[i] += self.inc[i]
                if self.ph[i] > TWO_PI:
                    self.ph[i] -= TWO_PI
            m = (math.sin(self.ph[0]) + 0.6 * math.sin(self.ph[1]) + 0.35 * math.sin(self.ph[2])) / 1.95
            self.dly.write(x)
            y = self.dly.read(self.base + self.depth * m)
            y = self.high.process(self.low.process(y))
            # compressor
            ay = abs(y)
            c = self.att if ay > self.env else self.rel
            self.env = c * self.env + (1.0 - c) * ay
            g = 1.0
            if self.env > self.thr:
                g = (self.env / self.thr) ** (-(1.0 - 1.0 / self.ratio))
            y = y * g * self.makeup
            y = math.tanh(self.drive * y) / self.drive
            # room tone
            self.tone_ph += self.tone_inc
            if self.tone_ph > TWO_PI:
                self.tone_ph -= TWO_PI
            n = self.tone_hp.process(self.tone_lp.process(self.rng.next()))
            y += n * self.tone_gain * (1.0 + 0.15 * math.sin(self.tone_ph))
        y += breath
        if not self.wobble_on:
            return y, y
        self.refl.write(y)
        t = self.taps; gn = self.tap_gain
        l = y + gn[0] * self.refl.read_int(t[0]) + gn[2] * self.refl.read_int(t[2])
        r = y + gn[1] * self.refl.read_int(t[1]) + gn[3] * self.refl.read_int(t[3])
        return l, r


# --------------------------------------------------------------------------- effects
def lerp(a, b, t):
    return a + (b - a) * t


class AquaEffect:
    """Underwater: muffled, wobbling (watery) and with a few soft bubbles."""
    def __init__(self, fs, a, s, seed=0xA11CE5):
        self.fs = fs; self.a = a
        fc = 4500.0 * (700.0 / 4500.0) ** a
        self.lp = Biquad().lowpass(fs, fc, 0.9)
        self.depth = (0.0005 + 0.0030 * a) * fs
        self.base = self.depth + 2.0
        self.dly = DelayLine(int(self.base + self.depth) + 8)
        self.rate = TWO_PI * (0.35 + 1.4 * s) / fs
        self.ph = 0.0
        self.gain = 1.0 + 0.5 * a
        self.rev = Reverb(fs, 0.55, 0.7, 0.18 + 0.22 * a, 10.0)
        self.rng = Rng(seed)
        self.rate_bub = (0.6 + 3.0 * a) / fs
        self.b_on = [False] * 6; self.b_f = [0.0] * 6; self.b_ph = [0.0] * 6
        self.b_t = [0.0] * 6; self.b_amp = [0.0] * 6; self.b_pan = [0.5] * 6

    def process(self, l, r):
        x = (l + r) * 0.5
        y = self.lp.process(x) * self.gain
        self.ph += self.rate
        if self.ph > TWO_PI:
            self.ph -= TWO_PI
        self.dly.write(y)
        wl = self.dly.read(self.base + self.depth * math.sin(self.ph))
        wr = self.dly.read(self.base + self.depth * math.sin(self.ph + math.pi / 2))
        ol = 0.65 * wl + 0.35 * y
        orr = 0.65 * wr + 0.35 * y
        rl, rr = self.rev.process(ol, orr)
        ol += rl; orr += rr
        # bubbles
        if self.rng.unit() < self.rate_bub:
            for i in range(6):
                if not self.b_on[i]:
                    self.b_on[i] = True
                    self.b_f[i] = 350.0 + 750.0 * self.rng.unit()
                    self.b_ph[i] = 0.0; self.b_t[i] = 0.0
                    self.b_amp[i] = (0.02 + 0.02 * self.rng.unit()) * (0.4 + 0.6 * self.a)
                    self.b_pan[i] = self.rng.unit()
                    break
        dt = 1.0 / self.fs
        for i in range(6):
            if self.b_on[i]:
                t = self.b_t[i]
                f = self.b_f[i] * (1.0 + 10.0 * min(t, 0.05))
                self.b_ph[i] += TWO_PI * f * dt
                env = math.exp(-t / 0.022) * (1.0 - math.exp(-t / 0.002))
                v = math.sin(self.b_ph[i]) * env * self.b_amp[i]
                ol += v * (1.0 - self.b_pan[i]); orr += v * self.b_pan[i]
                self.b_t[i] = t + dt
                if t > 0.12:
                    self.b_on[i] = False
        return ol, orr


class RevolveEffect:
    """8D audio: the voice circles around the head (pan + ear delay + head shadow + back darkening)."""
    CONTROL = 32

    def __init__(self, fs, a, s):
        self.fs = fs; self.a = a
        period = lerp(14.0, 3.0, s)
        self.inc = TWO_PI / (period * fs)
        self.theta = 0.0
        self.tau = 0.00066 * fs
        self.dly = DelayLine(int(self.tau) + 8)
        self.yl = 0.0; self.yr = 0.0; self.bl = 0.0; self.br = 0.0
        self.kl = 1.0; self.kr = 1.0; self.kb = 1.0
        self.dl = 2.0; self.dr = 2.0; self.gl = 0.707; self.gr = 0.707
        self.count = 0
        self.rev = Reverb(fs, 0.5, 0.5, 0.12 + 0.20 * a, 6.0)
        self.makeup = 1.3

    def _control(self):
        a = self.a; fs = self.fs
        sn = math.sin(self.theta); cs = math.cos(self.theta)
        pan = sn * (0.4 + 0.6 * a)
        ang = (pan + 1.0) * math.pi / 4.0
        self.gl = math.cos(ang); self.gr = math.sin(ang)
        self.dl = 2.0 + self.tau * max(0.0, sn) * a
        self.dr = 2.0 + self.tau * max(0.0, -sn) * a
        far_l = max(0.0, sn) * a; far_r = max(0.0, -sn) * a
        fcl = 20000.0 * (2500.0 / 20000.0) ** far_l
        fcr = 20000.0 * (2500.0 / 20000.0) ** far_r
        self.kl = 1.0 - math.exp(-TWO_PI * min(fcl, fs * 0.45) / fs)
        self.kr = 1.0 - math.exp(-TWO_PI * min(fcr, fs * 0.45) / fs)
        back = max(0.0, -cs) * a
        fcb = 20000.0 * (5500.0 / 20000.0) ** back
        self.kb = 1.0 - math.exp(-TWO_PI * min(fcb, fs * 0.45) / fs)
        self.bgain = 1.0 - 0.2 * back

    def process(self, l, r):
        if self.count == 0:
            self._control()
        self.count = (self.count + 1) % self.CONTROL
        self.theta += self.inc
        if self.theta > TWO_PI:
            self.theta -= TWO_PI
        x = (l + r) * 0.5
        self.dly.write(x)
        el = self.dly.read(self.dl); er = self.dly.read(self.dr)
        self.yl += self.kl * (el - self.yl); self.yr += self.kr * (er - self.yr)
        self.bl += self.kb * (self.yl - self.bl); self.br += self.kb * (self.yr - self.br)
        ol = self.bl * self.gl * self.bgain * self.makeup
        orr = self.br * self.gr * self.bgain * self.makeup
        rl, rr = self.rev.process(ol, orr)
        return ol + rl, orr + rr


class ReverbEffect:
    PRESETS = {  # room size, damping, max wet level, pre-delay ms
        'room': (0.35, 0.50, 0.6, 8.0),
        'hall': (0.78, 0.35, 0.8, 20.0),
        'cave': (0.92, 0.55, 0.8, 35.0),
    }

    def __init__(self, fs, kind, a):
        room, damp, wet_max, pd = self.PRESETS[kind]
        self.rev = Reverb(fs, room, damp, wet_max * (0.3 + 0.7 * a), pd)

    def process(self, l, r):
        rl, rr = self.rev.process(l, r)
        return l + rl, r + rr


class EchoEffect:
    def __init__(self, fs, a):
        self.n = int(0.30 * fs)
        self.dl = DelayLine(self.n + 4); self.dr = DelayLine(self.n + 4)
        self.fb = 0.25 + 0.40 * a
        self.wet = 0.30 + 0.40 * a
        self.lpl = OnePole(fs, 4000.0); self.lpr = OnePole(fs, 4000.0)

    def process(self, l, r):
        el = self.dl.read_int(self.n); er = self.dr.read_int(self.n)
        self.dl.write((l + r) * 0.5 + self.fb * self.lpr.process(er))
        self.dr.write(self.fb * self.lpl.process(el))
        return l + self.wet * el, r + self.wet * er


class RobotEffect:
    def __init__(self, fs, a):
        self.fs = fs
        self.m = 0.4 + 0.6 * a
        self.carrier = TWO_PI * 50.0 / fs
        self.ph = 0.0
        self.n = int(0.004 * fs)
        self.cg = 0.55 * a
        self.dly = DelayLine(self.n + 4)

    def process(self, l, r):
        x = (l + r) * 0.5
        self.ph += self.carrier
        if self.ph > TWO_PI:
            self.ph -= TWO_PI
        y = x * (1.0 - self.m) + x * math.sin(self.ph) * self.m * 1.4
        self.dly.write(y)
        y = y + self.cg * self.dly.read_int(self.n)
        return y, y


class BandEffect:
    """Telephone and megaphone: narrow the band, push it into soft clipping."""
    def __init__(self, fs, a, kind):
        if kind == 'telephone':
            hp = 120.0 + 230.0 * a; lp = 7000.0 - 3800.0 * a; self.drive = 1.0 + 0.6 * a; self.out = 1.35
            self.slap = 0
        else:
            hp = 250.0 + 300.0 * a; lp = 6500.0 - 2500.0 * a; self.drive = 1.5 + 2.5 * a; self.out = 1.7 + 0.9 * a
            self.slap = int(0.045 * fs)
        self.hp = [Biquad().highpass(fs, hp, 0.8), Biquad().highpass(fs, hp, 0.8)]
        self.lp = [Biquad().lowpass(fs, lp, 0.8), Biquad().lowpass(fs, lp, 0.8)]
        self.dly = DelayLine(self.slap + 4)
        self.norm = math.tanh(self.drive)

    def process(self, l, r):
        x = (l + r) * 0.5
        y = self.lp[1].process(self.lp[0].process(self.hp[1].process(self.hp[0].process(x))))
        y = math.tanh(self.drive * y) / max(self.drive, 1.0) * self.out
        if self.slap:
            self.dly.write(y)
            y += 0.25 * self.dly.read_int(self.slap)
        return y, y


class WhisperEffect:
    BANDS = 14

    def __init__(self, fs, a, seed=0x57415349):
        self.fs = fs
        self.a = a
        self.rng = Rng(seed)
        self.wet = 0.35 + 0.65 * a
        self.dry = (1.0 - self.wet) * 0.5
        nb = self.BANDS
        self.ana = []; self.syn = []; self.env = [0.0] * nb; self.norm = []
        self.k_env = 1.0 - math.exp(-TWO_PI * 40.0 / fs)
        cal = Rng(0xCAFE)
        for i in range(nb):
            fc = 150.0 * (9000.0 / 150.0) ** (i / (nb - 1))
            self.ana.append(Biquad().bandpass(fs, fc, 3.2))
            self.syn.append(Biquad().bandpass(fs, fc, 3.2))
            probe = Biquad().bandpass(fs, fc, 3.2)
            acc = 0.0
            for _ in range(8192):
                v = probe.process(cal.next()); acc += v * v
            rms = math.sqrt(acc / 8192)
            self.norm.append(1.0 / (0.8 * max(rms, 1e-6)))

    def process(self, l, r):
        x = (l + r) * 0.5
        n = self.rng.next()
        acc = 0.0
        for i in range(self.BANDS):
            band = self.ana[i].process(x)
            self.env[i] += self.k_env * (abs(band) - self.env[i])
            acc += self.syn[i].process(n) * self.norm[i] * self.env[i]
        y = (acc * self.wet + x * self.dry) * (0.95 - 0.20 * self.a)
        return y, y


def make_effect(fs, name, a, s):
    if name == 'aqua': return AquaEffect(fs, a, s)
    if name == 'revolve': return RevolveEffect(fs, a, s)
    if name in ('room', 'hall', 'cave'): return ReverbEffect(fs, name, a)
    if name == 'echo': return EchoEffect(fs, a)
    if name == 'robot': return RobotEffect(fs, a)
    if name in ('telephone', 'megaphone'): return BandEffect(fs, a, name)
    if name == 'whisper': return WhisperEffect(fs, a)
    return None


class Processor:
    def __init__(self, fs, pitch=0.0, humanize=0.0, breaths=False, effect='none', amount=0.6, speed=0.5):
        self.fs = fs
        self.pitch = PitchShifter(fs) if abs(pitch) >= 0.005 else None
        if self.pitch: self.pitch.set_semitones(pitch)
        self.hum = Humanizer(fs, humanize, breaths) if (humanize > 0.001 or breaths) else None
        self.fx = make_effect(fs, effect, amount, speed)
        self.latency = (self.pitch.latency if self.pitch else 0) + (self.hum.latency if self.hum else 0)

    def process(self, x):
        if self.pitch: x = self.pitch.process(x)
        if self.hum: l, r = self.hum.process(x)
        else: l = r = x
        if self.fx: l, r = self.fx.process(l, r)
        return soft_limit(l), soft_limit(r)

    def run(self, mono):
        """Whole-signal helper: returns (L, R) aligned with the input and the same length."""
        n = len(mono); lat = self.latency
        out_l = np.empty(n + lat); out_r = np.empty(n + lat)
        for i in range(n + lat):
            v = mono[i] if i < n else 0.0
            out_l[i], out_r[i] = self.process(v)
        return out_l[lat:], out_r[lat:]
