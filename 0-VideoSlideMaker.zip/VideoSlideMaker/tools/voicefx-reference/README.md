# Voice changer – reference implementation

`dsp.py` is the Python original of the voice changer in `app/src/main/java/com/videoslidemaker/app/voicefx/`
(pitch shifter, "make it sound human", Aqua / Revolve 8D / reverbs / echo / robot / telephone / megaphone / whisper).
The Kotlin code is a line-by-line port. It was designed and measured here first because there is no Android
device in the place this was written.

```
pip install numpy scipy
python3 run_tests.py      # about a minute: pitch accuracy, level, sync, breath placement, every effect bounded
python3 make_golden.py    # prints the numbers VoiceFxTest.kt compares the Kotlin code against, sample for sample
```

What `run_tests.py` checks (all pass):

| Check | Result |
|---|---|
| Pitch -7 … +7 semitones on a tone | within 0.01 cent |
| Pitch on a speech-like voice (F0 ratio) | within 0.3 % of the target |
| Level after pitch shifting | within 0.15 dB |
| Sync (amplitude envelope) after pitch shift | within 8 ms (the delay is measured and removed) |
| Humanize drift | stays within ±12 cents, never sounds out of tune |
| Room tone at 100 % | about -51 dBFS |
| Breaths | only inside real pauses (≥ 0.2 s) after speech, below -26 dBFS, none in short pauses |
| Every effect at 0 / 60 / 100 % | finite, below full scale, level within -7 … +5 dB |
| Revolve | left/right balance swings both ways |
