"""Python mirror of the colour system in app/src/main/java/.../ui/theme/ (Appearance.kt, Color.kt, ColorMath.kt).

It was written first because there is no Android build in the place this was written: every style x accent
combination is checked here against the same WCAG contrast rules as ThemeContrastTest.kt, and the colour
fitting (ColorMath.fitColor) is the same algorithm, step for step.

    python3 palette_check.py        # prints a summary and exits non-zero on any failure
"""
import math, sys

# ---------------------------------------------------------------- colour maths (mirrors ColorMath.kt)
def rgb(hexstr):
    h = hexstr.lstrip('#')
    return tuple(int(h[i:i+2], 16) / 255.0 for i in (0, 2, 4))

def chan(v):
    return v / 12.92 if v <= 0.03928 else ((v + 0.055) / 1.055) ** 2.4

def lum(c):
    return 0.2126 * chan(c[0]) + 0.7152 * chan(c[1]) + 0.0722 * chan(c[2])

def ratio(a, b):
    la, lb = lum(a), lum(b)
    return (max(la, lb) + 0.05) / (min(la, lb) + 0.05)

def over(fg, alpha, bg):
    return tuple(fg[i] * alpha + bg[i] * (1 - alpha) for i in range(3))

def to_hsl(c):
    r, g, b = c
    mx, mn = max(r, g, b), min(r, g, b)
    l = (mx + mn) / 2
    d = mx - mn
    if d < 1e-9:
        return 0.0, 0.0, l
    s = d / (1 - abs(2 * l - 1))
    if mx == r:
        h = ((g - b) / d) % 6
    elif mx == g:
        h = (b - r) / d + 2
    else:
        h = (r - g) / d + 4
    return (h * 60) % 360, s, l

def from_hsl(h, s, l):
    c = (1 - abs(2 * l - 1)) * s
    hp = (h % 360) / 60
    x = c * (1 - abs(hp % 2 - 1))
    r1, g1, b1 = [(c, x, 0), (x, c, 0), (0, c, x), (0, x, c), (x, 0, c), (c, 0, x)][int(hp) % 6]
    m = l - c / 2
    return (r1 + m, g1 + m, b1 + m)

def fit_color(base, toward_light, target, backgrounds):
    """Nudges the lightness of `base` (0.01 at a time, towards light or dark) until it reads at `target`:1
    on every background that backgrounds(candidate) returns. Always ends: pure white / black always pass."""
    def ok(c):
        return min(ratio(c, b) for b in backgrounds(c)) >= target
    if ok(base):
        return base
    h, s, l = to_hsl(base)
    for _ in range(100):
        l = min(1.0, l + 0.01) if toward_light else max(0.0, l - 0.01)
        cand = from_hsl(h, s, l)
        if ok(cand):
            return cand
    return from_hsl(h, s, 1.0 if toward_light else 0.0)

WHITE, BLACK, SOFT_BLACK = rgb('FFFFFF'), rgb('000000'), rgb('0E0E0E')

def pick_on(fill, dark):
    preferred = SOFT_BLACK if dark else WHITE
    if ratio(preferred, fill) >= 4.6:
        return preferred
    return WHITE if ratio(WHITE, fill) >= ratio(BLACK, fill) else BLACK

# ---------------------------------------------------------------- styles (mirrors Appearance.kt)
# bg, surface, card, border, outline, textMain, muted
DARK = {
 'CHARCOAL': ('131313','1B1B1B','222222','303030','7E7E7E','E6E6E6','A9A9A9'),
 'BLACK':    ('000000','0C0C0C','171717','2A2A2A','7E7E7E','E6E6E6','A9A9A9'),
 'SLATE':    ('1C2128','222830','2B323B','414A56','8793A1','D8DEE6','A3AEBB'),
 'MIDNIGHT': ('0B1220','111A2C','17233A','26354F','7C8CA8','E4EAF5','A3AEC4'),
 'FOREST':   ('0E1511','141E18','1A2620','2B3B32','7F9686','E3EBE5','A2B3A8'),
 'MOCHA':    ('17120E','1F1914','282019','3A3027','9A8878','EFE6DC','B5A596'),
 'PLUM':     ('150F1A','1D1624','261C2E','372A42','9684A6','EEE6F3','B3A5C0'),
}
LIGHT = {
 'PAPER':    ('F4F2EE','EBE8E2','FBFAF8','DDD9D1','7D7A74','2B2D31','5B5E64'),
 'SNOW':     ('F2F5F9','E7ECF2','FAFBFD','D5DCE6','70798A','1F2733','566072'),
 'SEPIA':    ('F3EAD7','E9DEC6','FBF5E7','D8CBAE','7D705A','3A3123','61563F'),
 'MINT':     ('EEF4EF','E1ECE4','F8FBF8','CFE0D4','6B8274','1E2B23','4F6257'),
 'BLUSH':    ('F7EFF1','EFE3E7','FDF9FA','E3D2D8','87707A','2E2327','66535B'),
 'LAVENDER': ('F2F0F8','E8E4F2','FBFAFE','D8D2E8','7A7290','25212F','5A546B'),
}
# name: (dark tone, light tone)
ACCENTS = {
 'RED':     ('F28B82','B3261E'),
 'CORAL':   ('FF9E80','B23A12'),
 'ORANGE':  ('F5A964','8F4A0A'),
 'AMBER':   ('FFCA5C','8A5B00'),
 'YELLOW':  ('F2E266','746200'),
 'LIME':    ('BDE05A','4F6B00'),
 'LEAF':    ('8FDB6B','2F7A1C'),
 'SAGE':    ('86D39B','2C6B3F'),
 'EMERALD': ('4FD6A0','0B6B45'),
 'TEAL':    ('55CFC0','0B6B63'),
 'CYAN':    ('5FD3E8','0A6678'),
 'SKY':     ('7CC4FA','1566A0'),
 'BLUE':    ('86B4F2','2459A6'),
 'INDIGO':  ('9FA8F5','3F46A8'),
 'VIOLET':  ('B8A0F7','5B3FB8'),
 'PURPLE':  ('D6A0F2','8A2FAE'),
 'MAGENTA': ('F395E6','A6208F'),
 'ROSE':    ('F29AB8','A8325E'),
 'BROWN':   ('D2A98A','7A4A2B'),
 'SLATE':   ('A7B4C4','4A5A6E'),
}
GREEN  = {True: '6FD394', False: '1F6B43'}
YELLOWS= {True: 'F2C14E', False: '855500'}
REDS   = {True: 'FF8A80', False: 'B3302B'}

def custom_tone(hue, dark):
    return from_hsl(hue, 0.78, 0.68) if dark else from_hsl(hue, 0.70, 0.34)

def build(dark, style, accent_base, hc):
    bg, surface, card, border, outline, text, muted = [rgb(x) for x in style]
    textMain = text
    if hc:
        if dark: textMain, muted, border, outline = rgb('FFFFFF'), rgb('D6D6D6'), rgb('8A8A8A'), rgb('C8C8C8')
        else:    textMain, muted, border, outline = rgb('000000'), rgb('2E2E2E'), rgb('6B6B6B'), rgb('3D3D3D')
    base3 = lambda c: [bg, surface, card]
    accent = fit_color(accent_base, dark, 4.55,
        lambda a: [bg, surface, card, over(a, 0.15, card), over(a, 0.13, bg)])
    def status(hexv):
        return fit_color(rgb(hexv), dark, 4.55,
            lambda c: [bg, surface, card, over(c, 0.10, card), over(c, 0.13, bg)])
    green, yellow, red = status(GREEN[dark]), status(YELLOWS[dark]), status(REDS[dark])
    muted = fit_color(muted, dark, 7.2 if hc else 4.7, base3)
    outline = fit_color(outline, dark, 3.2, base3)
    return dict(isDark=dark, bg=bg, surface=surface, card=card, border=border, outline=outline,
                accent=accent, onAccent=pick_on(accent, dark), textMain=textMain, muted=muted,
                green=green, yellow=yellow, red=red, onStatus=pick_on(green, dark))

# ---------------------------------------------------------------- the same checks as ThemeContrastTest.kt
fails = []
def check(look, what, fg, bg, minimum):
    r = ratio(fg, bg)
    if r < minimum:
        fails.append(f"{look}: {what} is only {r:.2f}:1 (needs {minimum})")

def run_checks(look, c, hc):
    text_min = 7.0 if hc else 4.5
    for bgn, bgc in (('page', c['bg']), ('bar', c['surface']), ('card', c['card'])):
        check(look, f'main text on {bgn}', c['textMain'], bgc, text_min)
        check(look, f'muted text on {bgn}', c['muted'], bgc, text_min)
        for k in ('accent', 'green', 'yellow', 'red'):
            check(look, f'{k} on {bgn}', c[k], bgc, 4.5)
        check(look, f'outline on {bgn}', c['outline'], bgc, 3.0)
    check(look, 'text on accent button', c['onAccent'], c['accent'], 4.5)
    check(look, 'tick on green', c['onStatus'], c['green'], 4.5)
    check(look, 'disabled button text', c['muted'], c['surface'], 4.5)
    check(look, 'yellow warning', c['yellow'], over(c['yellow'], .10, c['card']), 4.5)
    check(look, 'green success', c['green'], over(c['green'], .10, c['card']), 4.5)
    check(look, 'info text', c['textMain'], over(c['accent'], .12, c['card']), 4.5)
    check(look, 'accent time chip', c['accent'], over(c['accent'], .15, c['card']), 4.5)
    check(look, 'accent badge', c['accent'], over(c['accent'], .13, c['bg']), 4.5)
    check(look, 'green badge', c['green'], over(c['green'], .13, c['bg']), 4.5)
    check(look, 'yellow badge', c['yellow'], over(c['yellow'], .13, c['bg']), 4.5)
    check(look, 'selected chip text', c['textMain'], over(c['accent'], .22, c['surface']), 4.5)

def main():
    looks = 0
    shifted = []
    for dark, styles in ((True, DARK), (False, LIGHT)):
        for sname, style in styles.items():
            for hc in (False, True):
                for aname, (dk, lt) in ACCENTS.items():
                    base = rgb(dk if dark else lt)
                    c = build(dark, style, base, hc)
                    run_checks(f"{'dark' if dark else 'light'}/{sname}{'+HC' if hc else ''}/{aname}", c, hc)
                    looks += 1
                    if not hc and sname in ('CHARCOAL', 'PAPER') and max(abs(c['accent'][i] - base[i]) for i in range(3)) > 1e-9:
                        shifted.append(f"{'dark' if dark else 'light'}/{sname}/{aname}")
                for hue in range(0, 360, 5):
                    c = build(dark, style, custom_tone(hue, dark), hc)
                    run_checks(f"{'dark' if dark else 'light'}/{sname}{'+HC' if hc else ''}/custom{hue}", c, hc)
                    looks += 1
    # calm light / soft dark guards
    for sname, style in LIGHT.items():
        c = build(False, style, rgb(ACCENTS['BLUE'][1]), False)
        for k in ('bg', 'surface', 'card'):
            if lum(c[k]) >= 0.97: fails.append(f'light/{sname}: {k} too white')
        if lum(c['textMain']) <= 0.005: fails.append(f'light/{sname}: text pure black')
        if ratio(c['textMain'], c['bg']) >= 15.0: fails.append(f'light/{sname}: text too strong {ratio(c["textMain"], c["bg"]):.1f}')
    for sname, style in DARK.items():
        c = build(True, style, rgb(ACCENTS['BLUE'][0]), False)
        if lum(c['textMain']) >= 0.9: fails.append(f'dark/{sname}: text pure white')
    print(f"{looks} looks checked, {len(fails)} failures")
    print("presets nudged by fitting on the two default styles:", shifted or "none")
    for f in fails[:40]: print("  FAIL", f)
    return 1 if fails else 0

if __name__ == '__main__':
    sys.exit(main())
