"""
Python reference of the alignment engine. Mirrors the Kotlin implementation step by step so the
numbers/thresholds validated here are the ones shipped. Integer milliseconds for all times.
"""
import math, re
import numpy as np
from scipy.signal import lfilter

HOP_MS = 10

# ---------------------------------------------------------------- features
def biquad(kind, fs, f0, q=0.7071):
    w0 = 2 * math.pi * f0 / fs
    cw, sw = math.cos(w0), math.sin(w0)
    alpha = sw / (2 * q)
    if kind == "hp":
        b = [(1 + cw) / 2, -(1 + cw), (1 + cw) / 2]
    else:
        b = [(1 - cw) / 2, 1 - cw, (1 - cw) / 2]
    a0 = 1 + alpha
    a = [1, -2 * cw / a0, (1 - alpha) / a0]
    return [x / a0 for x in b], a

def frame_energy_db(x, fs):
    """Band-limit (150 Hz..min(4 kHz, 0.45 fs)) then 10 ms RMS in dBFS."""
    y = x
    for kind, f in (("hp", 150.0), ("lp", min(4000.0, 0.45 * fs))):
        b, a = biquad(kind, fs, f)
        y = lfilter(b, a, y)
    n = int(fs * HOP_MS / 1000)
    k = len(y) // n
    p = (y[: k * n].reshape(k, n) ** 2).mean(axis=1)
    return 10 * np.log10(p + 1e-10)

# ---------------------------------------------------------------- VAD
def percentile(a, p):
    return float(np.percentile(a, p))

def detect_speech(e):
    """Returns (speech mask bool[k], noise floor dB per frame). Adaptive noise floor / speech level."""
    k = len(e)
    BLOCK = 500  # 5 s
    nb = max(1, math.ceil(k / BLOCK))
    noise_b, speech_b = np.zeros(nb), np.zeros(nb)
    for b in range(nb):
        seg = e[b * BLOCK:(b + 1) * BLOCK]
        noise_b[b] = percentile(seg, 15)
        speech_b[b] = percentile(seg, 95)
    # smooth over +-3 blocks (median) -> slow-moving noise floor, stable speech level
    nf = np.array([np.median(noise_b[max(0, b - 3):b + 4]) for b in range(nb)])
    sl = np.array([np.median(speech_b[max(0, b - 6):b + 7]) for b in range(nb)])
    noise = np.repeat(nf, BLOCK)[:k]
    speech = np.repeat(sl, BLOCK)[:k]
    rng_db = speech - noise
    margin = np.maximum(6.0, 0.30 * rng_db)
    thr_on = noise + margin
    thr_off = thr_on - 4.0
    ok = rng_db >= 9.0  # flat recording => no speech decision at all
    mask = np.zeros(k, dtype=bool)
    on = False
    for i in range(k):
        if not ok[i]:
            on = False
        elif on:
            on = e[i] >= thr_off[i]
        else:
            on = e[i] >= thr_on[i]
        mask[i] = on
    mask = remove_stationary(e, mask)
    return mask, noise, float(np.median(rng_db))

def remove_stationary(e, mask, half=10, max_std=1.5, min_len=40):
    """Clear mask over stretches whose short-term energy barely varies (hum, steady tone/music bed).
    Speech always has syllable-rate modulation of several dB; a >=400 ms stretch with std < 1.5 dB isn't speech."""
    k = len(e)
    c1 = np.concatenate(([0.0], np.cumsum(e)))
    c2 = np.concatenate(([0.0], np.cumsum(e * e)))
    idx = np.arange(k)
    lo = np.maximum(0, idx - half); hi = np.minimum(k, idx + half + 1)
    n = (hi - lo).astype(float)
    mean = (c1[hi] - c1[lo]) / n
    var = np.maximum(0.0, (c2[hi] - c2[lo]) / n - mean * mean)
    flat = np.sqrt(var) < max_std
    out = mask.copy()
    i = 0
    while i < k:
        if flat[i]:
            j = i
            while j < k and flat[j]: j += 1
            if j - i >= min_len: out[i:j] = False
            i = j
        else:
            i += 1
    return out

def runs_from_mask(mask, min_speech=6, bridge=10):
    """[start,end) frame runs; gaps < bridge frames bridged; runs < min_speech frames dropped."""
    idx = np.flatnonzero(np.diff(np.concatenate(([0], mask.astype(np.int8), [0]))))
    runs = [[int(idx[i]), int(idx[i + 1])] for i in range(0, len(idx), 2)]
    merged = []
    for s, t in runs:
        if merged and s - merged[-1][1] < bridge:
            merged[-1][1] = t
        else:
            merged.append([s, t])
    return [(s, t) for s, t in merged if t - s >= min_speech]

def refine_edges(runs, e, noise, foot_db=6.0, max_back=15):
    """Move each run start back to the foot of the rise, each end forward to the foot of the fall."""
    out = []
    k = len(e)
    for s, t in runs:
        s2 = s
        while s2 > 0 and (s - s2) < max_back and e[s2 - 1] >= noise[s2 - 1] + foot_db:
            s2 -= 1
        t2 = t
        while t2 < k and (t2 - t) < max_back and e[t2] >= noise[t2] + foot_db:
            t2 += 1
        out.append((s2, t2))
    # refinement can make neighbours touch/overlap -> clip to previous end
    fixed = []
    for s, t in out:
        if fixed and s < fixed[-1][1]:
            s = fixed[-1][1]
        if t > s:
            fixed.append((s, t))
    return fixed

def find_dips(e, runs, min_depth=4.0, span=12, min_sep=15):
    """Interior syllable/word dips inside speech runs. Returns [(time_frame, depth_db)] (time = end of valley floor)."""
    k = len(e)
    es = e.copy()
    es[1:-1] = (e[:-2] + 2 * e[1:-1] + e[2:]) / 4.0
    found = []
    for s, t in runs:
        lo, hi = s + 3, t - 3
        for i in range(lo, hi):
            if es[i] > es[i - 1] or es[i] >= es[i + 1]:
                continue
            l0, r1 = max(0, i - span), min(k, i + span + 1)
            lm = es[l0:i].max(); rm = es[i + 1:r1].max()
            depth = min(lm, rm) - es[i]
            if depth >= min_depth:
                found.append((i, depth))
    # keep the deeper of any two dips closer than min_sep frames
    found.sort(key=lambda d: -d[1])
    kept = []
    for i, d in found:
        if all(abs(i - j) >= min_sep for j, _ in kept):
            kept.append((i, d))
    kept.sort()
    out = []
    for i, d in kept:
        j = i
        while j + 1 < k and es[j + 1] <= es[i] + 0.15 * d and j - i < 8:
            j += 1
        out.append((j, d))
    return out

# ---------------------------------------------------------------- text model
def units(text):
    n = 0.0
    for tok in re.findall(r"[^\W_]+", text, flags=re.UNICODE):
        if tok.isdigit():
            n += len(tok) * 1.0
            continue
        lat = re.findall(r"[aeiouyAEIOUY]+", tok)
        if lat and re.match(r"[A-Za-z]", tok):
            n += max(1, len(lat))
        else:
            n += max(1, len(tok) / 2.0)
    return max(n, 1.0)

RATE0 = 4.5  # syllable-ish units / second of voiced speech

def drift_at(ts, shifts, t, window=120000):
    """Robust local drift: median shift of anchors within +-window ms, falling back to nearest anchors."""
    ts = np.asarray(ts); sh = np.asarray(shifts)
    sel = np.abs(ts - t) <= window
    if sel.sum() >= 3:
        return float(np.median(sh[sel]))
    order = np.argsort(np.abs(ts - t))[:3]
    return float(np.median(sh[order]))
