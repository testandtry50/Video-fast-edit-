"""Run the scenario matrix and save per-line rows (features, fused answer, truth). Used to calibrate and to evaluate."""
import sys, pickle, time, numpy as np
from concurrent.futures import ProcessPoolExecutor
import harness as H, lexical as X, fusion as U, align2 as A

SCEN = {   # name: (generator kwargs, offset fn(sec), jitter sec)
    "drift+jitter": (dict(), lambda s: 3.0 * s / 360, 0.3),
    "jitter 1s":    (dict(), lambda s: 0.0, 1.0),
    "step +6s":     (dict(), lambda s: 2.0 if s < 180 else 8.0, 0.1),
    "step +20s":    (dict(), lambda s: 2.0 if s < 180 else 22.0, 0.1),
    "noisy":        (dict(noise_db=-38), lambda s: 1.5 * s / 360, 0.2),
    "music bed":    (dict(music=True), lambda s: 1.5 * s / 360, 0.2),
    "no pauses":    (dict(p_cont=0.6), lambda s: 1.2, 0.1),
    "lead silence": (dict(lead=60.0), lambda s: 2.5, 0.1),
    "coughs":       (dict(bursts=8), lambda s: 1.5 * s / 360, 0.2),
    "fast":         (dict(mean_gap=0.05), lambda s: 1.2, 0.1),
}
SEVS = ["none", "clean", "typical", "hard", "awful"]


def one(args):
    name, sev, seed, minutes = args
    kw, off, jit = SCEN[name]
    rng, texts, starts, durs, audio = H.gen(minutes, seed, **kw)
    T = H.stamps(starts, rng, off, jit)
    truth = [int(s * 1000) for s in starts]
    F = H.feats(audio)
    spoken = [] if sev == "none" else H.asr_sim(texts, starts, durs, np.random.default_rng(seed + 999), **H.SEVERITY[sev])
    L = X.lexical_lines(texts, spoken) if spoken else [None] * len(T)
    lex = [l["start"] if X.strong(l) else None for l in L]
    m, rows, rho = U.acoustic_full(T, texts, F, lex if spoken else None)
    units = [A.units(t) for t in texts]
    fused = U.fuse_lines(T, texts, m, rows, L if spoken else None, spoken, units)
    out = []
    for d in fused: d["clarity"] = U.clarity_of(F["rdb"])
    for i, d in enumerate(fused):
        y = int(d["final"] is not None and abs(d["final"] - truth[i]) <= 250)
        out.append(dict(scen=name, sev=sev, seed=seed, i=i, T=T[i], truth=truth[i], final=d["final"], cls=d["cls"], y=y,
                        x=U.feature_vector(d), contra=d["contra"], rdb=F["rdb"], a=d["a"], tL=d["tL"], strongL=d["strongL"], cA=d["cA"]))
    return out


if __name__ == "__main__":
    seeds = [int(x) for x in sys.argv[2].split(",")]
    minutes = int(sys.argv[3]) if len(sys.argv) > 3 else 6
    jobs = [(n, sv, sd, minutes) for n in SCEN for sv in SEVS for sd in seeds]
    t0 = time.time(); rows = []
    with ProcessPoolExecutor() as ex:
        for r in ex.map(one, jobs, chunksize=2): rows += r
    pickle.dump(rows, open(sys.argv[1], "wb"))
    print(f"{len(jobs)} runs, {len(rows)} lines, {time.time() - t0:.0f}s -> {sys.argv[1]}")
