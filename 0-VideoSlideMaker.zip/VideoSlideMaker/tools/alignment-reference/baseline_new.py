import numpy as np, harness as H

def scen(name, minutes, seeds, offset_fn, jitter=0.0, **kw):
    for sd in seeds:
        rng, texts, starts, durs, audio = H.gen(minutes, sd, **kw)
        T = H.stamps(starts, rng, offset_fn, jitter)
        F = H.feats(audio)
        det, conf = H.acoustic(texts, T, F)
        H.report(f"{name} s{sd}", det, conf, [int(s * 1000) for s in starts])

print("== CURRENT engine (acoustic only) on the cases in the brief, 8-minute synthetic recordings")
scen("small errors  +-0.15s jitter", 8, (71, 72), lambda s: 0.0, 0.15)
scen("exact constant offset +0.430s", 8, (71, 72), lambda s: 0.43)
scen("gradual drift 0 -> 3.0 s", 8, (71, 72), lambda s: 3.0 * s / 480, 0.1)
scen("step +2s then +8s (6 s step)", 8, (71, 72), lambda s: 2.0 if s < 240 else 8.0, 0.1)
scen("step 0 then -5 s", 8, (71, 72), lambda s: 0.0 if s < 240 else -5.0, 0.1)
scen("3 offsets +1 / +3.5 / -2", 9, (71, 72), lambda s: 1.0 if s < 180 else (3.5 if s < 360 else -2.0), 0.1)
scen("step +20s (big edit)", 8, (71, 72), lambda s: 2.0 if s < 240 else 22.0, 0.1)
scen("90 s silence before speech", 8, (71, 72), lambda s: 2.5, 0.1, lead=90.0)
scen("no pauses (60% continuous)", 8, (71, 72), lambda s: 1.2, 0.1, p_cont=0.6)
scen("fast: gaps ~0.25s only", 8, (71, 72), lambda s: 1.2, 0.1, mean_gap=0.05)
scen("noisy SNR~12dB", 8, (71, 72), lambda s: 1.2, 0.1, noise_db=-38)
