"""Synthetic 'speech-like' audio + transcripts with controllable timestamp error, for validating the aligner."""
import numpy as np, re

SR = 16000

def syllables(text):
    n = 0
    for w in re.findall(r"[A-Za-z]+", text):
        g = re.findall(r"[aeiouyAEIOUY]+", w)
        n += max(1, len(g))
    return max(1, n)

def make_voice(duration, sr=SR, rng=None, f0=120.0):
    n = int(duration * sr)
    t = np.arange(n) / sr
    f = f0 * (1 + 0.08 * np.sin(2 * np.pi * 0.7 * t + rng.uniform(0, 6)))
    phase = 2 * np.pi * np.cumsum(f) / sr
    sig = np.zeros(n)
    for h in range(1, 18):
        sig += np.sin(h * phase) / h ** 0.8
    rate = rng.uniform(4.0, 5.5)
    env = 0.55 + 0.45 * np.sin(2 * np.pi * rate * t + rng.uniform(0, 6))
    env = np.clip(env, 0.05, 1) ** 1.3
    fade = int(0.02 * sr)
    w = np.ones(n)
    w[:fade] = np.linspace(0, 1, fade)
    w[-fade:] = np.linspace(1, 0, fade)
    return sig * env * w

WORDS = "the quick brown fox jumps over lazy dog and then runs away from every hunter who wonders where it went today".split()

def make_script(n_segments, rng, mean_gap=0.7, p_continuous=0.0, rate_var=0.2, sentence_words=(3, 12)):
    """Returns texts, true starts, true ends (sec), total duration. Non-overlapping speech by construction."""
    texts, starts, ends, durs = [], [], [], []
    t = rng.uniform(1.0, 4.0)
    for _ in range(n_segments):
        k = rng.integers(*sentence_words)
        txt = " ".join(rng.choice(WORDS, k)).capitalize() + "."
        dur = syllables(txt) / 4.6 * rng.uniform(1 - rate_var, 1 + rate_var)
        texts.append(txt); starts.append(t); durs.append(dur); ends.append(t + dur)
        gap = 0.0 if rng.random() < p_continuous else max(0.25, rng.exponential(mean_gap))
        t += dur + gap
    return texts, starts, ends, durs, t + 3.0

def build(starts, durs, total, noise_db=-50, rng=None, voice_db=-20, music=False, bursts=0):
    n = int(total * SR)
    audio = rng.normal(0, 1, n) * 10 ** (noise_db / 20)
    if music:
        t = np.arange(n) / SR
        audio += 0.01 * np.sin(2 * np.pi * 220 * t) * (0.5 + 0.5 * np.sin(2 * np.pi * 0.2 * t))
    for s, dur in zip(starts, durs):
        v = make_voice(dur, sr=SR, rng=rng)
        v = v / (np.abs(v).max() + 1e-9) * 10 ** (voice_db / 20) * rng.uniform(0.6, 1.4)
        i = int(s * SR)
        seg = v[: max(0, n - i)]
        audio[i:i + len(seg)] += seg
    # untranscribed short noises (door slams / coughs): 120 ms bursts at random places
    for _ in range(bursts):
        i = int(rng.uniform(0, total - 1) * SR)
        m = int(0.12 * SR)
        audio[i:i + m] += rng.normal(0, 1, min(m, n - i)) * 10 ** ((voice_db - 6) / 20)
    return audio
