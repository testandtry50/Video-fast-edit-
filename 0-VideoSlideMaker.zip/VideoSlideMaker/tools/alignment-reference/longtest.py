import numpy as np, time, sys
import synth, engine, align2 as align

FS = 8000
synth.SR = FS

def drift_profile(t):
    pts = [(0, 0.0), (10, 0.0), (320, 0.8), (1215, 1.4), (2730, 2.1), (4000, 2.5)]
    xs = [p[0] for p in pts]; ys = [p[1] for p in pts]
    return float(np.interp(t, xs, ys))

def make(total_min=46, seed=21, p_untranscribed=0.08, p_phantom=0.03, jitter=0.25, noise_db=-48, music=False):
    rng = np.random.default_rng(seed)
    total_target = total_min * 60
    texts_all, starts_all, durs_all, flags = [], [], [], []
    t = 3.0
    while t < total_target - 10:
        k = rng.integers(3, 14)
        txt = " ".join(rng.choice(synth.WORDS, k)).capitalize() + "."
        dur = synth.syllables(txt) / 4.6 * rng.uniform(0.8, 1.2)
        texts_all.append(txt); starts_all.append(t); durs_all.append(dur)
        flags.append(rng.random() >= p_untranscribed)
        t += dur + max(0.25, rng.exponential(0.7))
    total = t + 5
    audio = synth.build(starts_all, durs_all, total, noise_db=noise_db, rng=rng, music=music, bursts=int(total / 60))
    audio = audio.astype(np.float32)
    # transcript: only flagged ones; plus phantom lines
    T, texts, truth = [], [], []
    for txt, s, f in zip(texts_all, starts_all, flags):
        if not f: continue
        err = drift_profile(s) + rng.normal(0, jitter)
        T.append(int(round((s - err) * 1000))); texts.append(txt); truth.append(int(s * 1000))
        if rng.random() < p_phantom:
            ph = "Narrator says something not present in this recording at all."
            T.append(T[-1] + 1500); texts.append(ph); truth.append(None)
    for i in range(1, len(T)):
        if T[i] <= T[i - 1]: T[i] = T[i - 1] + 50
    return audio, T, texts, truth, total

def run(audio, T, texts, truth):
    t0 = time.time()
    e = engine.frame_energy_db(audio, FS)
    mask, noise, rng_db = engine.detect_speech(e)
    runs = engine.refine_edges(engine.runs_from_mask(mask), e, noise)
    dips = engine.find_dips(e, runs)
    bounds = align.build_boundaries(runs, dips)
    prefix = np.concatenate(([0], np.cumsum(mask.astype(np.int64))))
    t1 = time.time()
    m, cands, best, marg, skipm, rho = align.align(T, texts, bounds, prefix, mask=mask)
    confs = align.confidence(m, cands, best, marg, skipm, rho, range_db=rng_db)
    t2 = time.time()
    return m, cands, best, confs, rho, rng_db, (t1 - t0, t2 - t1)

if __name__ == "__main__":
    audio, T, texts, truth, total = make()
    print(f"recording {total/60:.1f} min, {len(T)} transcript lines ({sum(x is None for x in truth)} phantom)")
    m, cands, best, confs, rho, rng_db, (tf, ta) = run(audio, T, texts, truth)
    print(f"features {tf:.1f}s  align {ta:.1f}s  rho={rho:.2f} clarity={rng_db:.1f}dB")
    real = [(i, truth[i]) for i in range(len(T)) if truth[i] is not None]
    errs = []; hi = []; wrong_hi = []
    for i, tr in real:
        if best[i] is None: continue
        got = int(m.bt[cands[i][best[i]]]); err = got - tr
        errs.append(err)
        if confs[i]['conf'] >= 0.8:
            hi.append(err)
            if abs(err) > 250: wrong_hi.append((i, err, round(confs[i]['conf'], 2)))
    errs = np.array(errs); hi = np.array(hi)
    print(f"real lines: within 150ms {np.mean(np.abs(errs)<=150)*100:.1f}%  within 300ms {np.mean(np.abs(errs)<=300)*100:.1f}%  median|err| {np.median(np.abs(errs)):.0f}ms  max|err| {np.max(np.abs(errs))}")
    print(f"high-confidence (>=.8): {len(hi)} of {len(errs)} ({len(hi)/len(errs)*100:.0f}%), within 250ms: {np.mean(np.abs(hi)<=250)*100:.1f}%, wrong: {wrong_hi[:5]}")
    ph = [i for i in range(len(T)) if truth[i] is None and best[i] is not None]
    ph_hi = [i for i in ph if confs[i]['conf'] >= 0.8]
    print(f"phantom lines: {len(ph)}  rated high-confidence: {len(ph_hi)}  (conf pctl 50/90: {np.percentile([confs[i]['conf'] for i in ph],[50,90]).round(2)})")
    # recovered drift vs truth at the user's anchor times
    for t_anchor in (10, 320, 1215, 2730):
        near = [(i, tr) for i, tr in real if best[i] is not None and abs(tr/1000 - t_anchor) < 40 and confs[i]['conf'] >= 0.8]
        if near:
            sh = [int(m.bt[cands[i][best[i]]]) - T[i] for i, _ in near]
            print(f"  t≈{t_anchor:5d}s  true drift {drift_profile(t_anchor):.2f}s   detected median shift {np.median(sh)/1000:+.2f}s  (n={len(near)})")
