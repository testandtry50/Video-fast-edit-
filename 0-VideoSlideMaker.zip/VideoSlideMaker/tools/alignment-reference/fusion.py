"""Fusion of the two independent kinds of evidence about where each script line really starts:

  AUDIO  (align2.py)  - speech/pause structure: ms-exact onsets, but it cannot tell WHICH sentence it is hearing.
  WORDS  (lexical.py) - what the recognizer heard, matched to the line's text: knows WHICH sentence, at ANY offset, but its
                        word times are only good to about +-50-150 ms.

Words choose the line, the audio chooses the millisecond. Everything is integer ms. Mirrors the Kotlin LineFusion.
"""
import numpy as np
import align2 as A
import lexical as X

AGREE_MS = 300          # words and audio agree if their starts are this close
SNAP_MS = 300           # a lexical start is snapped to an audio boundary at most this far away
CONFLICT_MS = 1500      # ... and they flatly disagree beyond this
LEAD_MS = 200           # recognized words within [start - LEAD, start + max(1.5 s, expected length)] belong to a line


def acoustic_full(T, texts, F, lex_starts=None):
    """The audio engine, plus everything fusion needs about its picks."""
    m, cands, best, marg, skipm, rho = A.align(T, texts, F["bounds"], F["prefix"], mask=F["mask"], lex=lex_starts)
    cf = A.confidence(m, cands, best, marg, skipm, rho, range_db=F["rdb"])
    rows = []
    for i in range(len(T)):
        if best[i] is None:
            rows.append(None); continue
        j = cands[i][best[i]]
        rows.append(dict(t=int(m.bt[j]), conf=float(cf[i]["conf"]) if cf[i] else 0.0, kind=int(m.kind[j]), ev=float(m.ev[j]),
                         margin=float(cf[i]["margin"]) if cf[i] else 0.0))
    return m, rows, rho


def nearest_boundary(m, t, within=SNAP_MS):
    """The audio boundary (pause onset preferred over a dip) closest to t, within `within` ms: (time, kind, evidence) or None."""
    lo = int(np.searchsorted(m.bt, t - within, "left")); hi = int(np.searchsorted(m.bt, t + within, "right"))
    best = None
    for j in range(lo, hi):
        d = abs(int(m.bt[j]) - t) + (0 if m.kind[j] == 0 else 60)      # a dip must be clearly nearer than a pause onset to win
        if best is None or d < best[0]: best = (d, int(m.bt[j]), int(m.kind[j]), float(m.ev[j]))
    return None if best is None else best[1:]


def words_near(spoken, a, b):
    """Recognized words that start inside [a, b): (count, mean confidence)."""
    ws = [w for w in spoken if a <= w[1] < b]
    return len(ws), (sum(w[3] for w in ws) / len(ws) if ws else 0.0)


def fuse_lines(T, texts, m, rows, lex_lines, spoken, units):
    """One decision per line. Words choose WHICH line it is; the audio chooses the millisecond - except inside continuous
    speech, where the audio has only a weak dip to offer and the words time the line better (measured, see README).
      AUDIO     pause onset, the words have nothing to say         -> audio time
      BOTH      pause onset and the words agree (<= 300 ms)         -> audio time
      DISAGREE  pause onset, but the words put the line elsewhere   -> audio time, confidence drops
      DIP       a dip in continuous speech, no words                -> audio time (imprecise)
      WORDDIP   a dip in continuous speech and the words           -> WORD time
      SNAP      the audio found nothing, the words did             -> nearest pause onset within 150 ms, else the word time
      NONE      no evidence."""
    out = []
    for i in range(len(T)):
        r = rows[i]; L = lex_lines[i] if lex_lines else None
        sL = X.strong(L); tL = L["start"] if L else None
        mfrac = (L["matched"] / L["n"]) if L else 0.0
        contra, near = 0, mfrac
        if r is not None and spoken:
            span = max(1500, int(units[i] / A.RATE0 * 1000))
            # how many of THIS line's words are heard near where the audio puts it (a match somewhere else in the recording is no help)
            near = (sum(1 for t in L["times"] if r["t"] - 300 <= t < r["t"] + span + 300) / L["n"]) if L else 0.0
            n_w, mc = words_near(spoken, r["t"] - LEAD_MS, r["t"] + span)
            # the recognizer hears something fairly confidently right here that is not this line's text
            if n_w >= 3 and mc >= 0.5 and near < 0.34: contra = 1
        d = dict(i=i, a=None if r is None else r["t"], cA=0.0 if r is None else r["conf"], kind=0 if r is None else r["kind"],
                 ev=0.0 if r is None else r["ev"], strongL=int(sL), tL=tL, mfrac=mfrac, anchor_conf=L["anchor_conf"] if sL else 0.0,
                 matched=L["matched"] if L else 0, near=near, contra=contra, gap=None, final=None, cls="NONE")
        if r is not None:
            gap = abs(r["t"] - tL) if sL else None
            d["gap"] = gap
            if r["kind"] == 1:
                if sL: d.update(final=tL, cls="WORDDIP")
                else: d.update(final=r["t"], cls="DIP")
            elif not sL:
                d.update(final=r["t"], cls="AUDIO")
            elif gap <= AGREE_MS:
                d.update(final=r["t"], cls="BOTH")
            else:
                d.update(final=r["t"], cls="DISAGREE")
        elif sL:
            b = nearest_boundary(m, tL, 150)
            if b is not None and b[1] == 0: d.update(final=b[0], cls="SNAP", ev=b[2])
            else: d.update(final=tL, cls="WORDS")
        out.append(d)
    return out


CLASSES = ["AUDIO", "BOTH", "DISAGREE", "DIP", "WORDDIP", "SNAP", "WORDS"]
FEATURES = ["cA", "strongL", "mfrac", "anchor_conf", "gap300", "gap1500", "contra", "ev", "clarity"] + ["is_" + c for c in CLASSES]


def clarity_of(rdb_db):
    """Speech-vs-background level difference of the recording (dB) -> 0..1. Below ~9 dB the engine decides nothing at all."""
    return min(1.0, max(0.0, (rdb_db - 9.0) / 30.0))


def feature_vector(d):
    gap = d["gap"] if d["gap"] is not None else 0
    return [d["cA"], float(d["strongL"]), d["mfrac"], d["anchor_conf"], float(gap > AGREE_MS), float(gap > CONFLICT_MS),
            float(d["contra"]), d["ev"], d.get("clarity", 0.0)] + [float(d["cls"] == c) for c in CLASSES]
