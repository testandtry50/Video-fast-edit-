"""Situations where the right answer is 'I cannot tell': no line may be rated high unless it is really right."""
import numpy as np, harness as H, pipeline as P

def summarize(label, items, truth, phantom=None):
    phantom = phantom or set()
    hi = [it for it in items if it["status"] in ("MATCHES", "CORRECTION_READY")]
    bad = [it for it in hi if it["index"] in phantom or truth[it["index"]] is None or abs(it["detected"] - truth[it["index"]]) > 250]
    cnt = {k: sum(1 for it in items if it["status"] == k) for k in ("MATCHES", "CORRECTION_READY", "NEEDS_REVIEW", "ESTIMATED", "CANNOT_ALIGN")}
    sec = P.sections(items)
    print(f"{label:46s} lines={len(items):4d} high={len(hi):4d} WRONG-high={len(bad):2d} | review={cnt['NEEDS_REVIEW']:4d} est={cnt['ESTIMATED']:3d} cannot={cnt['CANNOT_ALIGN']:3d} sections={len(sec)}")
    return len(bad)

def base(seed, minutes=6, **kw):
    rng, texts, starts, durs, audio = H.gen(minutes, seed, **kw)
    return rng, texts, starts, durs, audio

def asr(texts, starts, durs, seed, sev="typical"):
    return H.asr_sim(texts, starts, durs, np.random.default_rng(seed), **H.SEVERITY[sev])

bad = 0
for seed in (41, 42):
    print(f"--- seed {seed}")
    rng, texts, starts, durs, audio = base(seed); F = H.feats(audio); truth = [int(s*1000) for s in starts]
    T_ok = H.stamps(starts, rng, lambda s: 1.5, 0.1)
    sp = asr(texts, starts, durs, seed + 1)
    bad += summarize("baseline: words + audio, +1.5 s", P.run(T_ok, texts, F, sp), truth)
    bad += summarize("baseline: audio only", P.run(T_ok, texts, F, []), truth)
    # 1. shuffled text at the right times (rhythm right, words wrong)
    sh = list(texts); np.random.default_rng(seed).shuffle(sh)
    bad += summarize("shuffled text, right times, recognizer ON", P.run(T_ok, sh, F, sp), [None]*len(sh))
    # 2. a transcript of a DIFFERENT recording
    _, texts2, starts2, _, _ = base(seed + 50)
    T2 = [int(s*1000) for s in starts2]
    bad += summarize("unrelated transcript, recognizer ON", P.run(T2, texts2, F, sp), [None]*len(T2))
    bad += summarize("unrelated transcript, audio only", P.run(T2, texts2, F, []), [None]*len(T2))
    # 3. silence and a steady tone
    sil = (np.random.default_rng(1).normal(0, 1, len(audio)) * 10**(-50/20)).astype(np.float32)
    bad += summarize("silent recording", P.run(T_ok, texts, H.feats(sil), []), [None]*len(T_ok))
    tone = (0.05*np.sin(2*np.pi*440*np.arange(len(audio))/H.FS)).astype(np.float32)
    bad += summarize("steady tone", P.run(T_ok, texts, H.feats(tone), []), [None]*len(T_ok))
    # 4. recognizer hallucinates confident garbage over the real speech
    r = np.random.default_rng(seed + 7)
    garbage = [(H.LEX[0][int(r.integers(0, 3000))], int(s*1000 + k*300), int(s*1000 + k*300 + 250), 0.9) for s, d in zip(starts, durs) for k in range(int(d/0.3))]
    bad += summarize("recognizer: confident garbage words", P.run(T_ok, texts, F, garbage), truth)
    # 5. 25 phantom lines (text that is not in the recording) mixed in
    rr = np.random.default_rng(seed + 9); texts_p, T_p, truth_p, phantom = [], [], [], set()
    for i, (tx, t) in enumerate(zip(texts, T_ok)):
        texts_p.append(tx); T_p.append(t); truth_p.append(truth[i])
        if rr.random() < 0.15:
            texts_p.append(" ".join(rr.choice(H.LEX[0], 8)).capitalize() + "."); T_p.append(t + 900); truth_p.append(None); phantom.add(len(texts_p)-1)
    for i in range(1, len(T_p)):
        if T_p[i] <= T_p[i-1]: T_p[i] = T_p[i-1] + 50
    bad += summarize(f"{len(phantom)} phantom lines inserted, recognizer ON", P.run(T_p, texts_p, F, sp), truth_p, phantom)
    bad += summarize(f"{len(phantom)} phantom lines inserted, audio only", P.run(T_p, texts_p, F, []), truth_p, phantom)
    # 6. transcript covers only the middle 40 %
    a, b = int(len(texts)*0.3), int(len(texts)*0.7)
    bad += summarize("middle 40% only, +3 s, recognizer ON", P.run(H.stamps(starts[a:b], rng, lambda s: 3.0, 0.1), texts[a:b], F, sp), truth[a:b])
    # 7. blank text
    bad += summarize("blank transcript text", P.run([t - 3000 for t in truth], [""]*len(texts), F, sp), [None]*len(texts))
    # 8. offset bigger than the audio engine can search (90 s)
    T90 = H.stamps(starts, rng, lambda s: 90.0, 0.1)
    bad += summarize("offset 90 s, recognizer ON (words must find it)", P.run(T90, texts, F, sp), truth)
    bad += summarize("offset 90 s, audio only (beyond +-40 s search)", P.run(T90, texts, F, []), truth)
print("\nTOTAL wrong-high lines:", bad)
