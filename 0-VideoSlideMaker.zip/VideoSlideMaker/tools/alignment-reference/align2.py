"""Boundary DP with skip edges (Python reference for the Kotlin TimestampAligner)."""
import math
import numpy as np
from engine import HOP_MS, units, RATE0, drift_at
import coarse

INF = 1e18
SKIP_COST = 6.0
MAX_SKIP = 2

def base_cost_run(pause_ms): return 3.0 * (1.0 - min(1.0, pause_ms / 350.0))
def base_cost_dip(depth_db): return 4.5 - 1.5 * min(1.0, depth_db / 12.0)

def build_boundaries(runs_frames, dips):
    """(time_ms, evidence 0..1, kind 0=run 1=dip, base_cost) sorted by time."""
    out = []; prev_end = 0
    for s, t in runs_frames:
        pause = (s - prev_end) * HOP_MS
        out.append((s * HOP_MS, min(1.0, pause / 350.0), 0, base_cost_run(pause)))
        prev_end = t
    for f, d in dips:
        out.append((f * HOP_MS, 0.55 * min(1.0, d / 12.0), 1, base_cost_dip(d)))
    out.sort()
    return out

class Model:
    def __init__(self, T, texts, bounds, prefix):
        self.T = T; self.U = [units(t) for t in texts]; self.n = len(T)
        self.bt = np.array([b[0] for b in bounds]); self.ev = np.array([b[1] for b in bounds])
        self.kind = np.array([b[2] for b in bounds]); self.bc = np.array([b[3] for b in bounds])
        self.prefix = prefix
        self.Sarr = np.array([self.S(t) for t in self.bt]) if len(bounds) else np.zeros(0)
    def S(self, ms):
        f = int(min(max(ms, 0) // HOP_MS, len(self.prefix) - 1))
        return float(self.prefix[f]) * HOP_MS

def edge_cost(m, p, j, ids_a, ids_b, rho):
    """Cost matrix for edge segment p -> segment j (j>p). Returns (total, mass cost)."""
    ta = m.bt[ids_a][:, None]; tb = m.bt[ids_b][None, :]
    dt = tb - ta
    dshift = (tb - m.T[j]) - (ta - m.T[p])
    cd = np.minimum(np.abs(dshift) / 1000.0, 2.0) / 1.5
    mass = (m.Sarr[ids_b][None, :] - m.Sarr[ids_a][:, None]) / 1000.0
    e = m.U[p] / RATE0 * rho
    lr = np.log((np.maximum(mass, 0.0) + 0.3) / (e + 0.3))
    cm = np.minimum(lr * lr / (2 * 0.45 ** 2), 4.0)
    tot = cd + cm + SKIP_COST * (j - p - 1)
    return np.where(dt < 150, INF, tot), cm

LEX_WEIGHT = 3.0     # cost of a candidate 3 s away from a strong lexical start (linear below that)

def run_dp(m, centers, radius, rho, sig, max_cands=64, lex=None):
    n = m.n
    cands = []
    for i in range(n):
        parts = []
        for c in centers[i]:
            a = int(np.searchsorted(m.bt, c - radius, "left")); b = int(np.searchsorted(m.bt, c + radius, "right"))
            parts.append(np.arange(a, b))
        ids = np.unique(np.concatenate(parts)) if parts else np.zeros(0, dtype=int)
        if len(ids) > max_cands:
            near = np.min(np.abs(m.bt[ids][:, None] - np.asarray(centers[i], float)[None, :]), axis=1)
            ids = np.sort(ids[np.argsort(near)[:max_cands]])
        cands.append(ids)
    has = [len(c) > 0 for c in cands]
    un = [(m.bc[c] + 0.5 * np.minimum(np.min(np.abs(m.bt[c][:, None] - np.asarray(centers[i], float)[None, :]), axis=1), 4000.0) / 4000.0 / sig)
          if has[i] else None for i, c in enumerate(cands)]
    if lex is not None:      # words say where this line is: candidates far from that are less likely (soft: the audio can overrule)
        for i in range(n):
            if has[i] and lex[i] is not None:
                un[i] = un[i] + LEX_WEIGHT * np.minimum(np.abs(m.bt[cands[i]] - lex[i]), 3000.0) / 3000.0
    # predecessor segments of j: previous candidate-bearing segments, at most MAX_SKIP candidate-bearing ones skipped
    preds = []
    for j in range(n):
        lst = []; skipped_with_cands = 0; p = j - 1
        while p >= 0 and skipped_with_cands <= MAX_SKIP:
            if has[p]:
                lst.append(p); skipped_with_cands += 1
            p -= 1
        preds.append(lst if has[j] else [])
    F = [None] * n; bp = [None] * n
    lead_cost = lambda j: SKIP_COST * j
    for j in range(n):
        if not has[j]: continue
        # leading option: all earlier segments skipped (only if few candidate-bearing ones precede)
        nb_before = sum(has[:j])
        best = un[j] + (lead_cost(j) if nb_before <= MAX_SKIP else INF)
        ptr = np.full(len(cands[j]), -1, dtype=np.int64)       # -1 = start; else encoded p*100000+a
        for p in preds[j]:
            tot, _ = edge_cost(m, p, j, cands[p], cands[j], rho)
            v = F[p][:, None] + tot
            a_idx = np.argmin(v, axis=0)
            vb = v[a_idx, np.arange(v.shape[1])] + un[j]
            better = vb < best
            best = np.where(better, vb, best)
            ptr = np.where(better, p * 100000 + a_idx, ptr)
        F[j] = best; bp[j] = ptr
    # backward
    B = [None] * n
    succs = [[] for _ in range(n)]
    for j in range(n):
        for p in preds[j]: succs[p].append(j)
    for i in range(n - 1, -1, -1):
        if not has[i]: continue
        trailing = n - 1 - i
        nb_after = sum(has[i + 1:])
        cur = np.full(len(cands[i]), SKIP_COST * trailing if nb_after <= MAX_SKIP else INF)
        for j in succs[i]:
            tot, _ = edge_cost(m, i, j, cands[i], cands[j], rho)
            cur = np.minimum(cur, np.min(tot + (un[j] + B[j])[None, :], axis=1))
        B[i] = cur
    # best path
    totals = []
    for i in range(n):
        if not has[i]: continue
        trailing = n - 1 - i
        nb_after = sum(has[i + 1:])
        endc = SKIP_COST * trailing if nb_after <= MAX_SKIP else INF
        totals.append((float(np.min(F[i] + endc)), i, int(np.argmin(F[i] + endc))))
    best = [None] * n
    if not totals: return cands, best, [None] * n, [INF] * n, F, B, un
    _, i, a = min(totals)
    while True:
        best[i] = a
        code = int(bp[i][a])
        if code < 0: break
        i, a = code // 100000, code % 100000
    marg = [None] * n
    for i in range(n):
        if has[i]: marg[i] = F[i] + B[i]
    # skip max-marginals
    skipm = [INF] * n
    for j in range(n):
        if not has[j]: continue
        for p in preds[j]:
            if j - p == 1: continue
            tot, _ = edge_cost(m, p, j, cands[p], cands[j], rho)
            v = float(np.min(F[p][:, None] + tot + (un[j] + B[j])[None, :]))
            for s in range(p + 1, j): skipm[s] = min(skipm[s], v)
    return cands, best, marg, skipm, F, B, un

def posterior_sum(M, k):
    w = np.exp(-(M - M.min())); return float(w[k] / w.sum())

def matched_chain(best):
    return [i for i, b in enumerate(best) if b is not None]

def span_mass_costs(m, cands, best, rho):
    n = m.n; cm = [0.0] * n
    ch = matched_chain(best)
    for x in range(len(ch) - 1):
        p, j = ch[x], ch[x + 1]
        if j - p - 1 > MAX_SKIP + 20: continue
        _, c = edge_cost(m, p, j, cands[p][[best[p]]], cands[j][[best[j]]], rho)
        cm[p] = float(c[0, 0])
    return cm

def anchor_hypotheses(ts, sh, t, window=120000, k=8, agree=1000):
    """Where could line time t be, given the confident anchors? The robust median of anchors within +-window (smooth drift),
    unless the anchors just before and just after disagree (a STEP in the offset): then both sides are returned."""
    ts = np.asarray(ts); sh = np.asarray(sh)
    old = drift_at(ts, sh, t, window)
    order = np.argsort(ts); ts, sh = ts[order], sh[order]
    cut = int(np.searchsorted(ts, t, "right"))
    lo = int(np.searchsorted(ts, t - window, "left")); hi = int(np.searchsorted(ts, t + window, "right"))
    left = sh[max(lo, cut - k):cut]; right = sh[cut:min(hi, cut + k)]
    sides = ([float(np.median(left))] if len(left) else []) + ([float(np.median(right))] if len(right) else [])
    if not sides or all(abs(c - old) <= agree for c in sides): return [old]
    out = []
    for c in sorted(sides):
        if not out or abs(c - out[-1]) > agree: out.append(c)
    return out

def align(T, texts, bounds, prefix, mask=None, passes=3, lex=None):
    m = Model(T, texts, bounds, prefix); n = len(T)
    rho, sig = 1.0, 1.0
    # --- pass 0 centres: wide coarse drift search (no fixed offset assumed) ---
    info = coarse.estimate(T, texts, mask) if mask is not None else []
    m.coarse = info
    centers, radius = [], 2500
    m.cov = []                     # per line: the coarse lags a nearby window actually vouches for (empty = unverified)
    for i in range(n):
        hs, cov = coarse.shift_hypotheses(info, T[i]) if info else ([], [])
        centers.append([T[i] + int(h) for h in hs] if hs else [T[i]]); m.cov.append(cov)
    def with_lex(cs):
        if lex is None: return cs
        return [(c + [lex[i]]) if lex[i] is not None and all(abs(lex[i] - x) > 500 for x in c) else c for i, c in enumerate(cs)]
    centers = with_lex(centers)
    out = None
    for pass_no in range(passes):
        cands, best, marg, skipm, F, B, un = run_dp(m, centers, radius, rho, sig, lex=lex)
        out = (cands, best, marg, skipm, rho, [list(c) for c in centers], radius)
        if pass_no == passes - 1: break
        ts, sh = [], []
        for i in range(n):
            if best[i] is None: continue
            j = cands[i][best[i]]
            if m.kind[j] == 0 and m.ev[j] >= 0.7 and margin(m, cands[i], marg[i], best[i], skipm[i]) >= 3.0:
                ts.append(T[i]); sh.append(m.bt[j] - T[i])
        if len(sh) < 3: break
        centers = with_lex([[T[i] + int(round(h)) for h in anchor_hypotheses(ts, sh, T[i])] for i in range(n)])
        ratios = []
        ch = matched_chain(best)
        for x in range(len(ch) - 1):
            p, q = ch[x], ch[x + 1]
            if q - p != 1: continue
            jp, jq = cands[p][best[p]], cands[q][best[q]]
            if m.ev[jp] < 0.7 or m.ev[jq] < 0.7 or m.kind[jp] or m.kind[jq]: continue
            ratios.append((m.Sarr[jq] - m.Sarr[jp]) / 1000.0 / (m.U[p] / RATE0))
        if len(ratios) >= 3: rho = float(np.clip(np.median(ratios), 0.5, 2.0))
    cands, best, marg, skipm, rho, centers_f, radius_f = out
    m.centers = centers_f; m.radius = radius_f
    return m, cands, best, marg, skipm, rho

def margin(m, cands_i, M, k, skip_val, min_sep=250):
    tb = m.bt[cands_i[k]]
    best_other = None
    for a, j in enumerate(cands_i):
        if abs(m.bt[j] - tb) < min_sep: continue
        v = M[a] - M[k]
        if best_other is None or v < best_other: best_other = v
    sv = skip_val - M[k]
    cand = [x for x in (best_other, sv) if x is not None and x < INF / 2]
    return 6.0 if not cand else min(min(cand), 6.0)

def confidence(m, cands, best, marg, skipm, rho, range_db=30.0):
    n = m.n; cm = span_mass_costs(m, cands, best, rho)
    ch = matched_chain(best); prev_of = {}
    for x in range(1, len(ch)): prev_of[ch[x]] = ch[x - 1]
    out = [None] * n
    for i in range(n):
        if best[i] is None: continue
        j = cands[i][best[i]]
        mg = margin(m, cands[i], marg[i], best[i], skipm[i])
        c_margin = 1.0 - math.exp(-mg / 1.2)
        f = 0.4 + 0.6 * m.ev[j]
        q = math.exp(-(cm[i] + (cm[prev_of[i]] if i in prev_of else 0.0)) / 8.0)
        conf = c_margin * f * q
        conf = min(conf, 0.6 + 0.4 * min(1.0, max(0.0, (range_db - 9.0) / 12.0)))
        # a pick near the edge of its search window may just be the closest of the wrong onsets
        edge = min(abs(m.bt[j] - c) for c in m.centers[i]) / float(m.radius)
        if edge >= 0.75: conf = min(conf, 0.5)
        # The fine pick must agree with the independent coarse drift estimate, and that estimate must really EXIST for
        # this stretch: where no window had a clear peak we cannot vouch for anything, so it is never "high".
        if not m.cov[i]:
            conf = min(conf, 0.5)
        elif min(abs((m.bt[j] - m.T[i]) - c) for c in m.cov[i]) > 1500:
            conf = min(conf, 0.5)
        out[i] = dict(conf=conf, margin=mg, ev=float(m.ev[j]), q=q)
    return out

# ---------------------------------------------------------------- end of speech
def find_end(runs_ms, start_ms, limit_ms, expected_ms, max_gap=600):
    """End of the spoken segment that begins at start_ms. runs_ms = [(start, end)] sorted. None if no run there."""
    idx = None
    for k, (s, e) in enumerate(runs_ms):
        if e > start_ms and s <= start_ms + 200:
            idx = k; break
        if s > start_ms + 200: break
    if idx is None: return None
    end = min(runs_ms[idx][1], limit_ms); cur = idx
    while True:
        nx = cur + 1
        if nx >= len(runs_ms) or runs_ms[nx][0] >= limit_ms: break
        if runs_ms[nx][0] - runs_ms[cur][1] > max_gap: break
        if runs_ms[nx][1] - start_ms > 2.2 * expected_ms + 1500: break
        cur = nx; end = min(runs_ms[nx][1], limit_ms)
    return int(end)
