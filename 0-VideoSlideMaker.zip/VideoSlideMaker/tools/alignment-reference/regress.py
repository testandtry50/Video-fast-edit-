import numpy as np, warnings, time; warnings.filterwarnings("ignore")
import synth, engine, align2 as A, longtest as L, coarse
synth.SR = L.FS

def feats(audio):
    e = engine.frame_energy_db(audio, L.FS); mask, noise, rdb = engine.detect_speech(e)
    runs = engine.refine_edges(engine.runs_from_mask(mask), e, noise); dips = engine.find_dips(e, runs)
    return mask, A.build_boundaries(runs, dips), np.concatenate(([0], np.cumsum(mask.astype(np.int64)))), rdb

def gen(minutes, seed, mean_gap=0.7, p_cont=0.0, noise_db=-48, music=False, bursts=0):
    rng = np.random.default_rng(seed)
    texts, starts, durs, t = [], [], [], 3.0
    while t < minutes*60-10:
        k = rng.integers(3,14); txt=" ".join(rng.choice(synth.WORDS,k)).capitalize()+"."
        d = synth.syllables(txt)/4.6*rng.uniform(0.8,1.2); texts.append(txt); starts.append(t); durs.append(d)
        t += d + (0.0 if rng.random()<p_cont else max(0.25, rng.exponential(mean_gap)))
    audio = synth.build(starts, durs, t+5, noise_db=noise_db, rng=rng, music=music, bursts=bursts).astype(np.float32)
    return rng, texts, starts, durs, audio

def evaluate(label, texts, T, truth, audio, tol=250, thr=0.8):
    mask, bounds, prefix, rdb = feats(audio)
    t0=time.time(); m, cands, best, marg, skipm, rho = A.align(T, texts, bounds, prefix, mask=mask)
    confs = A.confidence(m, cands, best, marg, skipm, rho, range_db=rdb); dt=time.time()-t0
    real=[i for i in range(len(T)) if truth[i] is not None and best[i] is not None]
    errs=np.array([abs(int(m.bt[cands[i][best[i]]])-truth[i]) for i in real]) if real else np.array([])
    hi=[i for i in range(len(T)) if best[i] is not None and confs[i] and confs[i]['conf']>=thr]
    hi_real=[i for i in hi if truth[i] is not None]; hi_bad=[i for i in hi_real if abs(int(m.bt[cands[i][best[i]]])-truth[i])>tol]
    hi_phantom=[i for i in hi if truth[i] is None]
    okp = (np.mean(errs<=tol)*100) if len(errs) else float('nan')
    print(f"{label:38s} lines={len(T):4d} acc={okp:5.1f}%  high={len(hi):4d} high_WRONG={len(hi_bad)} phantom_high={len(hi_phantom)}  {dt:4.1f}s")
    return len(hi_bad)+len(hi_phantom)

bad=0
def shifted(starts, rng, f, jitter=0.0):
    T=[int(round((s - f(s) - rng.normal(0,jitter))*1000)) for s in starts]
    for i in range(1,len(T)):
        if T[i]<=T[i-1]: T[i]=T[i-1]+50
    return T

print("== accuracy scenarios (8-minute recordings, 3 seeds pooled by printing each)")
for name, kw, f, jit in [
    ("clean drift 0->2.1s",   {}, lambda s: 2.1*s/480, 0.0),
    ("drift + jitter .5s",    {}, lambda s: 2.1*s/480, 0.5),
    ("jitter 1.0s only",      {}, lambda s: 0.0, 1.0),
    ("music bed",             dict(music=True), lambda s: 1.5*s/480, 0.2),
    ("short bursts (coughs)", dict(bursts=10), lambda s: 1.5*s/480, 0.2),
    ("30% continuous speech", dict(p_cont=0.3), lambda s: 1.5*s/480, 0.2),
    ("dense speech gap .3",   dict(mean_gap=0.3), lambda s: 1.5*s/480, 0.2),
    ("noisy (SNR~12dB)",      dict(noise_db=-38), lambda s: 1.5*s/480, 0.2),
    ("const 25 s offset",     {}, lambda s: 25.0, 0.2),
    ("negative offset -7 s",  {}, lambda s: -7.0, 0.2)]:
    for sd in (51,52):
        rng, texts, starts, durs, audio = gen(8, sd, **kw)
        T = shifted(starts, rng, f, jit)
        bad += evaluate(f"{name} s{sd}", texts, T, [int(s*1000) for s in starts], audio)

print("== adversarial: nothing should be rated high-confidence")
rng, texts, starts, durs, audio = gen(8, 61)
rng2, texts2, starts2, _, _ = gen(8, 62)
T2 = [int(s*1000) for s in starts2]
bad += evaluate("unrelated transcript vs audio", texts2, T2, [None]*len(T2), audio)
sil = (np.random.default_rng(1).normal(0,1,L.FS*300)*10**(-50/20)).astype(np.float32)
bad += evaluate("silence", texts, [int(s*1000) for s in starts[:50]], [None]*50, sil)
tone = (0.05*np.sin(2*np.pi*440*np.arange(L.FS*300)/L.FS)).astype(np.float32)
bad += evaluate("steady tone", texts, [int(s*1000) for s in starts[:50]], [None]*50, tone)
blank=[""]*len(starts)
bad += evaluate("blank-text transcript", blank, [int(s*1000)-3000 for s in starts], [None]*len(starts), audio)
shuf = list(texts); np.random.default_rng(3).shuffle(shuf)
# Shuffled words but real pauses: scored against the true onsets. Corrections here are timing-correct
# (the pauses are real); this does NOT show the words were verified -- they are not (no speech
# recognition). See README "Important limits".
bad += evaluate("right times, shuffled text (timing)", shuf, [int(s*1000)-2000 for s in starts], [int(s*1000) for s in starts], audio)

print("== partial: transcript covers only a middle 40% of the recording")
a,b = int(len(texts)*0.3), int(len(texts)*0.7)
T = shifted(starts[a:b], rng, lambda s: 3.0)
bad += evaluate("middle 40% only, +3s", texts[a:b], T, [int(s*1000) for s in starts[a:b]], audio)

print("TOTAL dangerous (wrong-high + phantom-high):", bad)
