"""Run the complete pipeline on fresh seeds and report, per status, how often the detected time is right."""
import sys, numpy as np, collections
import harness as H, pipeline as P
from experiment import SCEN

def run_one(name, sev, seed, minutes=6):
    kw, off, jit = SCEN[name]
    rng, texts, starts, durs, audio = H.gen(minutes, seed, **kw)
    T = H.stamps(starts, rng, off, jit); truth = [int(s * 1000) for s in starts]
    F = H.feats(audio)
    spoken = [] if sev == "none" else H.asr_sim(texts, starts, durs, np.random.default_rng(seed + 999), **H.SEVERITY[sev])
    return P.run(T, texts, F, spoken), truth

if __name__ == "__main__":
    sevs = sys.argv[1].split(","); seeds = [int(x) for x in sys.argv[2].split(",")]
    for sev in sevs:
        by = collections.defaultdict(list); allit = []
        for name in SCEN:
            for sd in seeds:
                items, truth = run_one(name, sev, sd)
                for it in items:
                    it["err"] = None if it["detected"] is None else abs(it["detected"] - truth[it["index"]])
                    by[it["status"]].append(it); allit.append(it)
        n = len(allit)
        print(f"== recognizer: {sev}   ({n} lines)")
        print(f"   {'status':17s} {'lines':>6s} {'share':>6s} {'<=100ms':>8s} {'<=250ms':>8s} {'mean stated':>11s} {'median err':>10s}")
        for st in ("MATCHES", "CORRECTION_READY", "NEEDS_REVIEW", "ESTIMATED", "CANNOT_ALIGN"):
            sel = by.get(st, [])
            if not sel: continue
            e = np.array([x["err"] for x in sel if x["err"] is not None])
            ms = np.mean([x["confidence"] for x in sel]) * 100
            print(f"   {st:17s} {len(sel):6d} {len(sel)/n*100:5.1f}% {(np.mean(e<=100)*100 if len(e) else float('nan')):7.1f}% {(np.mean(e<=250)*100 if len(e) else float('nan')):7.1f}% {ms:10.1f}% {np.median(e) if len(e) else float('nan'):10.0f}")
        hi = by["MATCHES"] + by["CORRECTION_READY"]
        wrong = [x for x in hi if x["err"] > 250]
        print(f"   HIGH-confidence lines wrong by >250 ms: {len(wrong)} of {len(hi)}  (worst {max([x['err'] for x in wrong], default=0)} ms)")
        sec = 0
        print()
