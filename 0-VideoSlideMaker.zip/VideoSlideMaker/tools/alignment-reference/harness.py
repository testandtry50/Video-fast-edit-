"""Shared scenario generator + measurement for the alignment experiments (no side effects on import).
Synthetic speech with KNOWN ground truth; times in integer ms. FS=8000 like longtest/regress."""
import numpy as np, warnings
warnings.filterwarnings("ignore")
import synth, engine, align2 as A

FS = 8000
synth.SR = FS


_CONS = list("bdfgklmnprstvz") + ["ch", "sh", "th"]
_VOW = list("aeiou")


def lexicon(seed=1234, size=3000):
    """Pseudo-words of 1-4 syllables, Zipf-weighted like real text (a few very common words, a long tail)."""
    r = np.random.default_rng(seed)
    words = set()
    while len(words) < size:
        n = int(r.choice([1, 2, 3, 4], p=[0.35, 0.40, 0.20, 0.05]))
        words.add("".join(r.choice(_CONS) + r.choice(_VOW) for _ in range(n)))
    words = sorted(words)
    r.shuffle(words)
    w = 1.0 / np.arange(1, size + 1)
    return words, w / w.sum()


LEX = lexicon()


def gen(minutes, seed, mean_gap=0.7, p_cont=0.0, noise_db=-48, music=False, bursts=0, lead=3.0, words=(3, 14), lex=True):
    """-> rng, texts, starts(sec), durs(sec), audio. `lead` = seconds of silence before the first line.
    lex=True: sentences drawn from a Zipf lexicon (realistic repetition); False: the old 20-word toy vocabulary."""
    rng = np.random.default_rng(seed)
    texts, starts, durs, t = [], [], [], lead
    while t < minutes * 60 - 10:
        k = rng.integers(*words)
        ws = list(rng.choice(LEX[0], k, p=LEX[1])) if lex else list(rng.choice(synth.WORDS, k))
        txt = " ".join(ws).capitalize() + "."
        d = synth.syllables(txt) / 4.6 * rng.uniform(0.8, 1.2)
        texts.append(txt); starts.append(t); durs.append(d)
        t += d + (0.0 if rng.random() < p_cont else max(0.25, rng.exponential(mean_gap)))
    audio = synth.build(starts, durs, t + 5, noise_db=noise_db, rng=rng, music=music, bursts=bursts).astype(np.float32)
    return rng, texts, starts, durs, audio


def feats(audio):
    e = engine.frame_energy_db(audio, FS)
    mask, noise, rdb = engine.detect_speech(e)
    runs = engine.refine_edges(engine.runs_from_mask(mask), e, noise)
    dips = engine.find_dips(e, runs)
    prefix = np.concatenate(([0], np.cumsum(mask.astype(np.int64))))
    return dict(e=e, mask=mask, noise=noise, rdb=rdb, runs=runs, dips=dips,
                bounds=A.build_boundaries(runs, dips), prefix=prefix)


def stamps(starts, rng, offset_fn, jitter=0.0):
    """User timestamps = true start - error(t) - jitter. Kept strictly increasing like a real script."""
    T = [int(round((s - offset_fn(s) - rng.normal(0, jitter)) * 1000)) for s in starts]
    for i in range(1, len(T)):
        if T[i] <= T[i - 1]: T[i] = T[i - 1] + 50
    return T


def acoustic(texts, T, F):
    """The CURRENT engine. -> (detected_ms[i] or None, conf[i] or 0)"""
    m, cands, best, marg, skipm, rho = A.align(T, texts, F["bounds"], F["prefix"], mask=F["mask"])
    cf = A.confidence(m, cands, best, marg, skipm, rho, range_db=F["rdb"])
    det = [None if best[i] is None else int(m.bt[cands[i][best[i]]]) for i in range(len(T))]
    conf = [0.0 if best[i] is None or cf[i] is None else cf[i]["conf"] for i in range(len(T))]
    return det, conf


def report(label, det, conf, truth, thr=0.8, tol=250, extra=""):
    n = len(truth)
    real = [i for i in range(n) if truth[i] is not None and det[i] is not None]
    err = np.array([abs(det[i] - truth[i]) for i in real], float)
    hi = [i for i in range(n) if det[i] is not None and conf[i] >= thr]
    hi_bad = [i for i in hi if truth[i] is not None and abs(det[i] - truth[i]) > tol]
    if len(err):
        p = np.percentile(err, [50, 90, 95, 99])
        pr = f"med={p[0]:5.0f} p90={p[1]:5.0f} p95={p[2]:5.0f} p99={p[3]:6.0f}ms  <=100ms:{(err<=100).mean()*100:5.1f}%  <=250ms:{(err<=250).mean()*100:5.1f}%"
    else:
        pr = "no matches"
    print(f"{label:34s} n={n:4d} found={len(real):4d} | {pr} | high={len(hi):4d} high_WRONG={len(hi_bad)} {extra}")
    return len(hi_bad)


def word_ms(w):
    return 80 + 45 * len(w)


def asr_sim(texts, starts, durs, rng, wer_del=0.05, wer_sub=0.10, wer_ins=0.02, drop_line=0.02, jitter_ms=60, heavy=0.08,
            conf_good=(8, 2), conf_bad=(2, 4)):
    """A stand-in for a speech recognizer, with the failure modes that matter. -> [(text, start_ms, end_ms, conf)].
    Every transcript word is spoken inside its line; the recognizer drops some words, substitutes others (wrong word, low
    confidence), inserts noise words, loses whole lines, and its word times jitter (8 % of them badly)."""
    out = []
    for k, (txt, s0, d) in enumerate(zip(texts, starts, durs)):
        if rng.random() < drop_line:
            continue
        ws = [w.strip(".,").lower() for w in txt.split()]
        wt = np.array([word_ms(w) * rng.uniform(0.7, 1.3) for w in ws])
        wt = wt / wt.sum() * d * 1000.0
        t = s0 * 1000.0
        for w, dur in zip(ws, wt):
            a, b = t, t + dur
            t = b
            r = rng.random()
            if r < wer_del:
                continue
            sig = jitter_ms * (4.0 if rng.random() < heavy else 1.0)
            sa, sb = a + rng.normal(0, sig), b + rng.normal(0, sig)
            if sb <= sa + 20:
                sb = sa + 40
            if r < wer_del + wer_sub:
                out.append((LEX[0][int(rng.integers(0, len(LEX[0])))], int(sa), int(sb), float(np.clip(rng.beta(*conf_bad), 0.05, 0.95))))
            else:
                out.append((w, int(sa), int(sb), float(np.clip(rng.beta(*conf_good), 0.3, 1.0))))
            if rng.random() < wer_ins:
                out.append((LEX[0][int(rng.integers(0, len(LEX[0])))], int(sb + 10), int(sb + 200), float(np.clip(rng.beta(*conf_bad), 0.05, 0.9))))
    out.sort(key=lambda x: (x[1], x[2]))
    return out


SEVERITY = {
    "clean":   dict(wer_del=0.03, wer_sub=0.05, wer_ins=0.01, drop_line=0.01, jitter_ms=40),
    "typical": dict(wer_del=0.06, wer_sub=0.12, wer_ins=0.02, drop_line=0.03, jitter_ms=60),
    "hard":    dict(wer_del=0.12, wer_sub=0.25, wer_ins=0.04, drop_line=0.08, jitter_ms=100),
    "awful":   dict(wer_del=0.25, wer_sub=0.45, wer_ins=0.08, drop_line=0.20, jitter_ms=150),
}
