"""Fit P(|detected - truth| <= 250 ms) from the per-line features by L2-regularised logistic regression (IRLS), then check
that the stated confidence is HONEST on seeds the fit never saw. Prints the coefficients to paste into the Kotlin/Python code."""
import pickle, sys, numpy as np
import fusion as U

def design(rows):
    X = np.array([r["x"] for r in rows], float)
    return np.hstack([X, np.ones((len(rows), 1))])

def fit(rows, l2=1.0, iters=50):
    rows = [r for r in rows if r["final"] is not None]
    X = design(rows); y = np.array([r["y"] for r in rows], float)
    w = np.zeros(X.shape[1]); R = l2 * np.eye(X.shape[1]); R[-1, -1] = 0
    for _ in range(iters):
        p = 1 / (1 + np.exp(-X @ w)); g = X.T @ (p - y) + R @ w
        H = (X * (p * (1 - p))[:, None]).T @ X + R + 1e-6 * np.eye(len(w))
        step = np.linalg.solve(H, g); w -= step
        if np.abs(step).max() < 1e-8: break
    return w

def predict(w, rows):
    return 1 / (1 + np.exp(-design(rows) @ w))

def reliability(p, y, edges=(0, .5, .7, .8, .9, .95, .98, 1.01), label=""):
    print(f"  {label}")
    print(f"  {'stated conf':>12s} {'lines':>6s} {'observed':>9s} {'wilson95 lo':>12s}")
    for lo, hi in zip(edges[:-1], edges[1:]):
        s = (p >= lo) & (p < hi)
        if s.sum() == 0: continue
        k, n = y[s].sum(), s.sum(); ph = k / n; z = 1.96
        wl = (ph + z*z/(2*n) - z*np.sqrt(ph*(1-ph)/n + z*z/(4*n*n))) / (1 + z*z/n)
        print(f"  {lo:5.2f}-{min(hi,1):4.2f} {n:6d} {ph*100:8.1f}% {wl*100:11.1f}%")

if __name__ == "__main__":
    tr = pickle.load(open("/tmp/train.pkl", "rb")); te = pickle.load(open("/tmp/test.pkl", "rb"))
    w = fit(tr)
    print("features:", U.FEATURES + ["bias"]); print("w = [" + ", ".join(f"{v:.3f}" for v in w) + "]")
    for name, rows in (("TRAIN", tr), ("HELD-OUT TEST (unseen seeds)", te)):
        got = [r for r in rows if r["final"] is not None]
        p = predict(w, got); y = np.array([r["y"] for r in got], float)
        reliability(p, y, label=name)
        print()
