import numpy as np, warnings, io, contextlib; warnings.filterwarnings("ignore")
with contextlib.redirect_stdout(io.StringIO()):
    import regress as R
import align2 as A, engine, synth, longtest as L
synth.SR = L.FS

def run(texts, T, audio):
    mask, bounds, prefix, rdb = R.feats(audio)
    m,c,b,mg,sk,rho = A.align(T, texts, bounds, prefix, mask=mask)
    cf = A.confidence(m,c,b,mg,sk,rho,range_db=rdb)
    out=[]
    for i in range(len(T)):
        if b[i] is None: out.append(None); continue
        j=c[i][b[i]]; conf=cf[i]['conf']
        st = 'REVIEW' if conf<0.8 else ('MATCH' if abs(int(m.bt[j])-T[i])<=100 else 'HIGH')
        out.append((int(m.bt[j]), conf, st))
    return out

def quality(out, truth_of, minTrusted, label):
    det=[(i,o) for i,o in enumerate(out) if o]
    w200=sum(abs(o[0]-truth_of(i))<=200 for i,o in det)
    trusted=[(i,o) for i,o in det if o[2]!='REVIEW']
    worst=max([abs(o[0]-truth_of(i)) for i,o in trusted], default=0)
    ok = (worst<=250) and (w200>=0.9*len(det)) and (len(trusted)>=minTrusted*len(out))
    return ok, f"{label}: within200 {w200}/{len(det)}, trusted {len(trusted)}/{len(out)}, worst trusted err {worst}ms"

fails=0
for sd in range(100,108):
    rng,texts,starts,durs,audio = R.gen(4, sd)
    S=[int(s*1000) for s in starts]; total=len(audio)/L.FS*1000
    # 1 drift 0 -> 2.1 s (error = 2100*t/total)
    T=[S[0]-int(2100*S[0]/total)]
    for s in S[1:]:
        v=s-int(2100*s/total); T.append(max(v,T[-1]+50))
    out=run(texts,T,audio)
    ok,msg=quality(out,lambda i:S[i],0.5,"drift"); 
    tr=[o for o in out if o and o[2]!='REVIEW']
    early=np.mean([o[0]-T[i] for i,o in enumerate(out) if o and o[2]!='REVIEW'][:10]); late=np.mean([o[0]-T[i] for i,o in enumerate(out) if o and o[2]!='REVIEW'][-10:])
    ok = ok and (late-early>1200)
    fails += not ok; print(sd, "drift      ", "OK " if ok else "FAIL", msg, f"early {early:.0f} late {late:.0f}")
    # 2 script 25 s too early, only lines >= 27 s
    keep=[i for i,s in enumerate(S) if s>=27000]
    out=run([texts[i] for i in keep],[S[i]-25000 for i in keep],audio)
    ok,msg=quality(out,lambda i:S[keep[i]],0.5,"+25s subset"); fails += not ok; print(sd,"big offset ", "OK " if ok else "FAIL", msg)
    # 3 script 25 s too late
    out=run(texts,[s+25000 for s in S],audio); ok,msg=quality(out,lambda i:S[i],0.5,"-25s"); fails += not ok; print(sd,"-25 s       ", "OK " if ok else "FAIL", msg)
    # 4 jitter .4 + drift 1.5
    r2=np.random.default_rng(sd); T=[]
    for s in S:
        v=s-int(1500*s/total)-int(r2.normal(0,400)); T.append(v if not T or v>T[-1] else T[-1]+50)
    out=run(texts,T,audio); ok,msg=quality(out,lambda i:S[i],0.2,"jitter"); fails += not ok; print(sd,"jitter      ", "OK " if ok else "FAIL", msg)
    # 5 missing line inserted at index 11
    T=[s-1200 for s in S]; tx=list(texts); tx.insert(11,"This sentence was cut from the recording."); T.insert(11,(T[10]+T[11])//2)
    out=run(tx,T,audio)
    wrong=sum(1 for i,o in enumerate(out) if i!=11 and o and o[2]!='REVIEW' and abs(o[0]-S[i if i<11 else i-1])>250)
    inv_ok = (out[11] is None) or out[11][2]=='REVIEW'
    ok = wrong==0 and inv_ok; fails += not ok; print(sd,"phantom line", "OK " if ok else "FAIL", f"wrong trusted {wrong}, invented line untrusted={inv_ok}")
print("FAILED SCENARIOS:", fails)
