"""Lexical evidence: WHERE each transcript line is spoken, from the recognized WORDS (text-only; no timestamps used).
Reuses the accuracy checker's tokenizer and global aligner (tools/accuracy-reference/checker.py)."""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "accuracy-reference"))
import checker as C


def word_ms(tok):
    return 80 + 45 * len(tok.norm)


def lexical_lines(texts, spoken):
    """spoken = [(text, start_ms, end_ms, conf)]. -> per line: None when no usable words, else dict(
         start, end   : estimated speech start / end of the line (ms),
         n, matched   : words in the line / words the recognizer confirmed,
         first        : index of the first confirmed word (0 = the line's first word),
         anchor_conf  : recognizer confidence of the word the start was read from,
         mean_conf    : mean recognizer confidence of the confirmed words,
         times        : start times of the confirmed words)"""
    st = C.Settings()
    segs = [C.Segment(0, t) for t in texts]
    C._sub_cache.clear()
    T, ranges = C.tokenize_transcript(segs, st)
    S = C.tokenize_spoken([C.Spoken(t, a, b, c) for t, a, b, c in spoken], st)
    intern = {}
    for t in T + S:
        t.nid = intern.setdefault(t.norm, len(intern))
    pairT, pairS = C.align(T, S)
    out = []
    for k, (t0, t1) in enumerate(ranges):
        n = t1 - t0
        eq = [i for i in range(t0, t1) if pairT[i] >= 0 and S[pairT[i]].nid == T[i].nid]
        if n == 0 or not eq:
            out.append(None); continue
        f = eq[0]
        sw = S[pairT[f]]
        before = sum(word_ms(T[x]) for x in range(t0, f))            # words before it that were not heard: they were spoken too
        last = eq[-1]; ew = S[pairT[last]]
        after = sum(word_ms(T[x]) for x in range(last + 1, t1))
        out.append(dict(start=int(round(sw.start - before)), end=int(round(ew.end + after)), n=n, matched=len(eq), times=[S[pairT[i]].start for i in eq],
                        first=f - t0, anchor_conf=sw.conf, mean_conf=sum(S[pairT[i]].conf for i in eq) / len(eq)))
    return out


def strong(L):
    """Enough confirmed words, early enough in the line, with a believable recognizer confidence, to place the line."""
    if L is None: return False
    need = min(3, L["n"])
    return L["matched"] >= need and L["first"] <= 3 and L["anchor_conf"] >= 0.5 and L["matched"] / L["n"] >= 0.4
