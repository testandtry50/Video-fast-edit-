# Alignment reference (Python)

The algorithm in `app/src/main/java/com/videoslidemaker/app/align/` was designed and tuned here
first, against synthetic speech with known ground truth, and the Kotlin is a port of it. Use it to
re-check numbers or to compare against the Kotlin results.

    pip install numpy scipy
    python3 regress.py        # accuracy scenarios + adversarial cases (nothing may be rated high)
    python3 mirror_tests.py   # the exact scenarios/assertions of the Kotlin unit tests, 8 seeds
    python3 longtest.py       # 46-minute recording with the 0 -> +2.5 s drift profile

Files: `engine.py` (features, speech detection, onset refinement, dips) -> `coarse.py` (global drift
search) -> `align2.py` (per-line DP, confidence, end of speech). Thresholds here are the shipped ones.
