# Alignment reference (Python)

The algorithm in `app/src/main/java/com/videoslidemaker/app/align/` was designed and tuned here
first, against synthetic speech with known ground truth, and the Kotlin is a port of it. Use it to
re-check numbers or to compare against the Kotlin results.

    pip install numpy scipy
    python3 regress.py        # accuracy scenarios + adversarial cases (nothing may be rated high)
    python3 mirror_tests.py   # the exact scenarios/assertions of the Kotlin unit tests, 8 seeds
    python3 longtest.py       # 46-minute recording with the 0 -> +2.5 s drift profile

Files: `engine.py` (features, speech detection, onset refinement, dips) -> `coarse.py` (global drift
search) -> `align2.py` (per-line DP, confidence, end of speech). Thresholds here are the shipped ones.


## 2.12: words + audio fusion, calibration, and the reproducible measurements

Everything quoted in the app's README under *NEW in 2.12.0* comes from these scripts. No script here uses real speech: the
audio is synthetic with known ground truth (`synth.py`, `harness.py`), and the speech recognizer is *simulated*
(`harness.asr_sim`, with the failure modes that matter: dropped / wrong / extra words, lost lines, jittery word times,
confidence correlated with correctness). Treat the numbers as upper bounds for real recordings.

| File | What it is |
|---|---|
| `harness.py` | Scenario generator (Zipf lexicon, drift/step/jitter/noise/music/no-pause/lead-silence), the simulated recognizer, `report()` |
| `baseline_new.py` | The cases the original harness never tested (offset steps, long lead-in silence, ...) on the audio-only engine |
| `coarse.py` / `align2.py` | The audio engine. 2.12 changes: unlimited-jump tracker (`viterbi_tv`), `shift_hypotheses`, `anchor_hypotheses`, no extrapolation, lexical prior in the DP |
| `lexical.py` | Where each line is spoken according to the recognized words (text only, any offset) |
| `fusion.py` | Per-line decision: words choose the line, audio chooses the millisecond (except in continuous speech) |
| `pipeline.py` | Calibrated confidence + hard gates, estimates for lines with no evidence, statuses, sections |
| `experiment.py`, `calibrate.py` | Build the per-line data set (train/held-out seeds) and fit / check the confidence model |
| `evaluate_pipeline.py` | Accuracy per status on fresh seeds, for each recognizer quality |
| `adversarial2.py` | Silence, tone, blank text, unrelated transcript, shuffled text, phantom lines, garbage recognizer, 90 s offset |
| `export_golden.py` | Writes `app/src/test/resources/alignment_golden.txt`, the cases + outputs the Kotlin test must reproduce |

```
export PYTHONPATH=.
python3 baseline_new.py                                   # audio-only engine on the new cases
python3 experiment.py /tmp/train.pkl 11,12,13,14 6        # ~3 min: 200 recordings x ~70 lines
python3 experiment.py /tmp/test.pkl  21,22,23    6        # held-out seeds
python3 calibrate.py                                      # coefficients + reliability table (paste W into pipeline.py / LineFusion.Calibration)
python3 evaluate_pipeline.py none,clean,typical,hard,awful 51,52
python3 adversarial2.py
python3 export_golden.py ../../app/src/test/resources/alignment_golden.txt
```

Findings that shaped the design (each one changed the code):

- **Offset steps broke the original engine** and it rated wrong lines high (see the app README). Fixed in `coarse.py`/`align2.py`.
- **When audio and words disagree by 0.3-1.5 s the audio is right 85-100 % of the time** and the word-time estimate 0-12 %: word
  start times identify the line, they do not decide the millisecond. (My first fusion snapped *to the words* and was right on
  0-9 % of those lines.)
- **Inside continuous speech the words are better than the audio** (median 44 ms vs 106 ms): the audio only has a weak loudness dip.
- **A linear confidence model is untrustworthy in the tail it rarely sees.** It gave 0.96-0.97 to lines whose audio score was 0.49-0.63
  (and to strongly-matching words at the wrong place). Hence the hard gates in `pipeline.calibrated`.
- **Noisy audio reads late** (median +55-75 ms): reported as a wider ± and lower confidence, not corrected against the recognizer.
- Neighbour consistency as a *model feature* helped only a little (log-loss 0.0508 -> 0.0460) for a two-stage model, so it is used
  only where it is essential: estimating lines with no evidence of their own.
