"""Coarse global drift search (Python reference of Kotlin CoarseDriftEstimator).
Cross-correlates 'transcript says speech here' with 'audio has speech here' at 100 ms resolution,
in overlapping windows over +-MAX_LAG, then Viterbi-smooths the per-window lag so drift can change over time."""
import math
import numpy as np
from engine import HOP_MS, units, RATE0

BIN_MS = 100
BIN_FR = BIN_MS // HOP_MS
WIN_BINS = 900          # 90 s
STEP_BINS = 450         # 45 s
MAX_LAG_BINS = 400      # +-40 s
MIN_PEAK = 0.30

def speech_bins(mask, bridge_frames=25):
    """Bridge short gaps (<250 ms), then fraction-of-bin speech -> 0/1 per 100 ms."""
    k = len(mask)
    m = mask.copy()
    i = 0
    while i < k:
        if not m[i]:
            j = i
            while j < k and not m[j]: j += 1
            if 0 < i and j < k and (j - i) < bridge_frames: m[i:j] = True
            i = j
        else:
            i += 1
    nb = k // BIN_FR
    return (m[: nb * BIN_FR].reshape(nb, BIN_FR).mean(axis=1) >= 0.5).astype(np.float32)

def transcript_bins(T, texts, n_bins, rho=0.85):
    """1 where the transcript expects speech (from each line's stated start for its estimated spoken length)."""
    out = np.zeros(n_bins + 2 * MAX_LAG_BINS + 1, dtype=np.float32)  # padded by MAX_LAG both sides at index offset
    off = MAX_LAG_BINS
    n = len(T)
    for i in range(n):
        dur_ms = units(texts[i]) / RATE0 * rho * 1000.0
        if i + 1 < n: dur_ms = min(dur_ms, max(0, T[i + 1] - T[i]))
        a = int(T[i] // BIN_MS) + off
        b = int((T[i] + dur_ms) // BIN_MS) + off + 1
        a = max(0, a); b = min(len(out), b)
        if b > a: out[a:b] = 1.0
    return out  # index = bin + off

def window_scores(tb, sb, w0, w1, lags):
    """Pearson correlation of transcript window [w0,w1) against audio speech bins shifted by each lag."""
    off = MAX_LAG_BINS
    e = tb[w0 + off: w1 + off].astype(np.float64)
    n = len(e)
    scores = np.zeros(len(lags), dtype=np.float32)
    nbins = len(sb)
    em = e - e.mean()
    ne = float(np.sqrt((em * em).sum()))
    if ne < 1e-6: return scores           # transcript has no speech/silence contrast here
    for li, lag in enumerate(lags):
        a, b = w0 + lag, w1 + lag
        if a < 0 or b > nbins: continue   # only fully-covered windows (no edge artefacts)
        s = sb[a:b].astype(np.float64)
        sm = s - s.mean()
        ns = float(np.sqrt((sm * sm).sum()))
        if ns < 1e-6: continue
        scores[li] = float((em * sm).sum()) / (ne * ns)
    return scores

def estimate(T, texts, mask):
    """Returns (centers_shift_fn data, per-window info). shift_ms(t) = interpolated lag (ms) at transcript time t."""
    sb = speech_bins(mask)
    nb = len(sb)
    tb = transcript_bins(T, texts, max(nb, int(max(T) // BIN_MS) + 2))
    last_t_bin = int(max(T) // BIN_MS) + 1
    lags = np.arange(-MAX_LAG_BINS, MAX_LAG_BINS + 1)
    wins = []
    w0 = 0
    end = max(last_t_bin, 1)
    while w0 < end:
        w1 = min(w0 + WIN_BINS, max(end, w0 + 1))
        wins.append((w0, w1))
        if w1 >= end: break
        w0 += STEP_BINS
    # per-window: only score windows that actually contain transcript speech
    S = []
    for (a, b) in wins:
        S.append(window_scores(tb, sb, a, b, lags))
    S = np.array(S)                       # [W, L]
    W, L = S.shape
    # Viterbi over windows: score = correlation; penalty on lag change (drift changes slowly)
    NEG = -1e9
    pen_per_bin = 0.004                   # per 100 ms of lag change between adjacent windows
    max_jump = 40                         # 4 s per window step
    V = np.full((W, L), NEG); P = np.zeros((W, L), dtype=np.int32)
    V[0] = S[0]
    for w in range(1, W):
        for li in range(L):
            lo, hi = max(0, li - max_jump), min(L, li + max_jump + 1)
            cand = V[w - 1, lo:hi] - pen_per_bin * np.abs(np.arange(lo, hi) - li)
            k = int(np.argmax(cand)); V[w, li] = cand[k] + S[w, li]; P[w, li] = lo + k
    path = np.zeros(W, dtype=np.int32); path[-1] = int(np.argmax(V[-1]))
    for w in range(W - 1, 0, -1): path[w - 1] = P[w, path[w]]
    info = []
    for w, (a, b) in enumerate(wins):
        s = S[w]; pk = float(s[path[w]])
        # sharpness: best score at least 2 s away from the chosen lag
        far = np.abs(lags - lags[path[w]]) >= 20
        second = float(s[far].max()) if far.any() else 0.0
        info.append(dict(center_ms=int((a + b) / 2 * BIN_MS), lag_ms=int(lags[path[w]] * BIN_MS), peak=pk, second=second,
                         ok=(pk >= MIN_PEAK and pk - second >= 0.12)))
    return info

def shift_at(info, t_ms):
    """Lag (ms) at transcript time t: linear interpolation between window centres of windows with a clear peak."""
    good = [x for x in info if x['ok']]
    if not good: return None, False
    xs = np.array([x['center_ms'] for x in good], float); ys = np.array([x['lag_ms'] for x in good], float)
    v = float(np.interp(t_ms, xs, ys))
    # distance to nearest good window (reliability of the interpolation)
    dist = float(np.min(np.abs(xs - t_ms)))
    return v, dist <= 100000
