"""Coarse global drift search (Python reference of Kotlin CoarseDriftEstimator).
Cross-correlates 'transcript says speech here' with 'audio has speech here' at 100 ms resolution,
in overlapping windows over +-MAX_LAG, then Viterbi-smooths the per-window lag so drift can change over time."""
import math
import numpy as np
from engine import HOP_MS, units, RATE0

BIN_MS = 100
BIN_FR = BIN_MS // HOP_MS
WIN_BINS = 900          # 90 s
STEP_BINS = 450         # 45 s
MAX_LAG_BINS = 400      # +-40 s
MIN_PEAK = 0.30

def speech_bins(mask, bridge_frames=25):
    """Bridge short gaps (<250 ms), then fraction-of-bin speech -> 0/1 per 100 ms."""
    k = len(mask)
    m = mask.copy()
    i = 0
    while i < k:
        if not m[i]:
            j = i
            while j < k and not m[j]: j += 1
            if 0 < i and j < k and (j - i) < bridge_frames: m[i:j] = True
            i = j
        else:
            i += 1
    nb = k // BIN_FR
    return (m[: nb * BIN_FR].reshape(nb, BIN_FR).mean(axis=1) >= 0.5).astype(np.float32)

def transcript_bins(T, texts, n_bins, rho=0.85):
    """1 where the transcript expects speech (from each line's stated start for its estimated spoken length)."""
    out = np.zeros(n_bins + 2 * MAX_LAG_BINS + 1, dtype=np.float32)  # padded by MAX_LAG both sides at index offset
    off = MAX_LAG_BINS
    n = len(T)
    for i in range(n):
        dur_ms = units(texts[i]) / RATE0 * rho * 1000.0
        if i + 1 < n: dur_ms = min(dur_ms, max(0, T[i + 1] - T[i]))
        a = int(T[i] // BIN_MS) + off
        b = int((T[i] + dur_ms) // BIN_MS) + off + 1
        a = max(0, a); b = min(len(out), b)
        if b > a: out[a:b] = 1.0
    return out  # index = bin + off

def window_scores(tb, sb, w0, w1, lags):
    """Pearson correlation of transcript window [w0,w1) against audio speech bins shifted by each lag."""
    off = MAX_LAG_BINS
    e = tb[w0 + off: w1 + off].astype(np.float64)
    n = len(e)
    scores = np.zeros(len(lags), dtype=np.float32)
    nbins = len(sb)
    em = e - e.mean()
    ne = float(np.sqrt((em * em).sum()))
    if ne < 1e-6: return scores           # transcript has no speech/silence contrast here
    for li, lag in enumerate(lags):
        a, b = w0 + lag, w1 + lag
        if a < 0 or b > nbins: continue   # only fully-covered windows (no edge artefacts)
        s = sb[a:b].astype(np.float64)
        sm = s - s.mean()
        ns = float(np.sqrt((sm * sm).sum()))
        if ns < 1e-6: continue
        scores[li] = float((em * sm).sum()) / (ne * ns)
    return scores

def viterbi_tv(S, pen_per_bin):
    """Best lag path over windows. S[w][l] = correlation score; a lag CHANGE between adjacent windows costs pen_per_bin per
    100 ms bin, with no limit on the jump. Linear penalty -> the best predecessor of every lag comes from two O(L) sweeps."""
    W, L = S.shape
    V = np.zeros((W, L)); P = np.zeros((W, L), dtype=np.int32)
    V[0] = S[0]
    for w in range(1, W):
        prev = V[w - 1]
        fv = np.empty(L); fa = np.empty(L, dtype=np.int32)
        fv[0] = prev[0]; fa[0] = 0
        for li in range(1, L):
            if prev[li] >= fv[li - 1] - pen_per_bin: fv[li] = prev[li]; fa[li] = li
            else: fv[li] = fv[li - 1] - pen_per_bin; fa[li] = fa[li - 1]
        gv = np.empty(L); ga = np.empty(L, dtype=np.int32)
        gv[-1] = prev[-1]; ga[-1] = L - 1
        for li in range(L - 2, -1, -1):
            if prev[li] >= gv[li + 1] - pen_per_bin: gv[li] = prev[li]; ga[li] = li
            else: gv[li] = gv[li + 1] - pen_per_bin; ga[li] = ga[li + 1]
        use_f = fv >= gv
        V[w] = np.where(use_f, fv, gv) + S[w]
        P[w] = np.where(use_f, fa, ga)
    path = np.zeros(W, dtype=np.int32); path[-1] = int(np.argmax(V[-1]))
    for w in range(W - 1, 0, -1): path[w - 1] = P[w, path[w]]
    return path


def estimate(T, texts, mask):
    """Returns (centers_shift_fn data, per-window info). shift_ms(t) = interpolated lag (ms) at transcript time t."""
    sb = speech_bins(mask)
    nb = len(sb)
    tb = transcript_bins(T, texts, max(nb, int(max(T) // BIN_MS) + 2))
    last_t_bin = int(max(T) // BIN_MS) + 1
    lags = np.arange(-MAX_LAG_BINS, MAX_LAG_BINS + 1)
    wins = []
    w0 = 0
    end = max(last_t_bin, 1)
    while w0 < end:
        w1 = min(w0 + WIN_BINS, max(end, w0 + 1))
        wins.append((w0, w1))
        if w1 >= end: break
        w0 += STEP_BINS
    # per-window: only score windows that actually contain transcript speech
    S = []
    for (a, b) in wins:
        S.append(window_scores(tb, sb, a, b, lags))
    S = np.array(S)                       # [W, L]
    W, L = S.shape
    # Viterbi over windows: score = correlation; a lag CHANGE between adjacent windows costs pen_per_bin per 100 ms.
    # The jump is NOT limited (an edited video can shift by 20 s at once): with a linear penalty the best predecessor of
    # every lag is found in O(L) by two sweeps (forward and backward), instead of O(L * max_jump).
    path = viterbi_tv(S, 0.004)
    info = []
    for w, (a, b) in enumerate(wins):
        s = S[w]; pk = float(s[path[w]])
        # sharpness: best score at least 2 s away from the chosen lag
        far = np.abs(lags - lags[path[w]]) >= 20
        second = float(s[far].max()) if far.any() else 0.0
        info.append(dict(center_ms=int((a + b) / 2 * BIN_MS), lag_ms=int(lags[path[w]] * BIN_MS), peak=pk, second=second,
                         ok=(pk >= MIN_PEAK and pk - second >= 0.12)))
    return info

COVER_MS = 60000        # a window vouches for lines up to this far from its centre (windows are 90 s wide, 45 s apart)
STEP_AGREE_MS = 1000    # neighbouring windows whose lags differ by more than this are a STEP, not drift

def shift_hypotheses(info, t_ms):
    """Where could the script time t_ms really be in the audio?  Returns (lags, covered):
    lags = candidate shifts (ms): one interpolated value while the lag changes smoothly (drift), BOTH neighbouring
    values across a step (the line may lie on either side of it); covered = the subset a nearby window actually vouches for.
    Nothing is extrapolated across stretches where no window had a clear peak."""
    good = [x for x in info if x['ok']]
    if not good: return [], []
    left = [x for x in good if x['center_ms'] <= t_ms]; right = [x for x in good if x['center_ms'] > t_ms]
    l = left[-1] if left else None; r = right[0] if right else None
    if l and r and abs(l['lag_ms'] - r['lag_ms']) <= STEP_AGREE_MS:
        a, b = l['center_ms'], r['center_ms']
        v = l['lag_ms'] + (r['lag_ms'] - l['lag_ms']) * (t_ms - a) / max(1, b - a)
        near = min(t_ms - a, b - t_ms) <= COVER_MS
        return [float(v)], ([float(v)] if near else [])
    lags, cov = [], []
    for w in (l, r):
        if w is None: continue
        lags.append(float(w['lag_ms']))
        if abs(w['center_ms'] - t_ms) <= COVER_MS: cov.append(float(w['lag_ms']))
    return lags, cov
