"""Writes app/src/test/resources/alignment_golden.txt: randomized inputs AND the outputs the Python reference produces for them.
The Kotlin test AlignmentGoldenTest.kt feeds the same inputs to the Kotlin code and requires the same outputs, so the port is
checked against the tested reference on cases nobody hand-picked.

    PYTHONPATH=. python3 export_golden.py ../../app/src/test/resources/alignment_golden.txt

Format: one record per line, tokens separated by single spaces; text lines are 'T <whole line>'. Floats are repr() so they parse back exactly.
"""
import sys
import numpy as np
import harness as H, lexical as X, fusion as U, pipeline as P, align2 as A, coarse

out = []
w = out.append


def f(x):
    return repr(float(x))


def lexline(tag, i, L):
    if L is None:
        w(f"{tag} {i} NULL"); return
    w(f"{tag} {i} {L['start']} {L['end']} {L['n']} {L['matched']} {L['first']} {f(L['anchor_conf'])} {f(L['mean_conf'])} "
      f"{','.join(str(int(t)) for t in L['times'])} {int(X.strong(L))}")


def dump_spoken(sp, offset=0):
    w(f"SPOKEN {len(sp)}")
    for t, a, b, c in sp:
        w(f"W {t} {a + offset} {b + offset} {f(c)}")


# ------------------------------------------------------------------------------------------ lexical cases
for k, (seed, sev) in enumerate([(201, "clean"), (202, "typical"), (203, "hard"), (204, "awful"), (205, "typical")]):
    rng, texts, starts, durs, audio = H.gen(2, seed, lex=True)
    sp = H.asr_sim(texts, starts, durs, np.random.default_rng(seed + 5), **H.SEVERITY[sev])
    if k == 4:                                   # the script has two lines swapped and one invented
        texts = list(texts); texts[3], texts[7] = texts[7], texts[3]; texts[10] = "Ba ka ta noroshi lemo."
    L = X.lexical_lines(texts, sp)
    w(f"LEX_CASE {k}")
    w(f"N {len(texts)}")
    for t in texts: w(f"T {t}")
    dump_spoken(sp)
    for i, l in enumerate(L): lexline("LO", i, l)
    w("END")


# ------------------------------------------------------------------------------------------ fusion + judging cases
def fuse_case(name, T, texts, F, spoken, clock_offset=0):
    L = X.lexical_lines(texts, spoken) if spoken else [None] * len(T)
    lex = [l["start"] if X.strong(l) else None for l in L]
    m, rows, rho = U.acoustic_full(T, texts, F, lex if spoken else None)
    units = [A.units(t) for t in texts]
    fused = U.fuse_lines(T, texts, m, rows, L if spoken else None, spoken, units)
    clarity = U.clarity_of(F["rdb"])
    items = P.judge(T, fused, clarity)
    secs = P.sections(items)
    w(f"FUSE_CASE {name}")
    w(f"N {len(T)}"); w(f"OFFSET {clock_offset}"); w(f"CLARITY {f(clarity)}")
    w("ORIG " + " ".join(str(int(t)) for t in T))
    w("UNITS " + " ".join(f(u) for u in units))
    w(f"BOUNDS {len(m.bt)}")
    for t, kd, ev in zip(m.bt, m.kind, m.ev): w(f"B {int(t)} {int(kd)} {f(ev)}")
    for i, r in enumerate(rows):
        w(f"PICK {i} NONE" if r is None else f"PICK {i} {r['t']} {f(r['conf'])} {r['kind']} {f(r['ev'])}")
    # the recognizer's output is on the RECORDING's clock = internal clock + clock_offset
    dump_spoken(spoken, clock_offset)
    for i, l in enumerate(L):
        if l is not None:
            l = dict(l, start=l["start"] + clock_offset, end=l["end"] + clock_offset, times=[t + clock_offset for t in l["times"]])
        lexline("LEXIN", i, l if spoken else None)
    for it in items:
        status = {"CORRECTION_READY": "HIGH_CONFIDENCE"}.get(it["status"], it["status"])
        det = "NONE" if it["detected"] is None else str(int(it["detected"]))
        prec = "NONE" if it["precision"] is None else str(int(it["precision"]))
        w(f"OUT {it['index']} {det} {f(it['confidence'])} {prec} {it['evidence']} {status}")
    w("SEC " + ";".join(f"{a},{b},{wst}" for a, b, c, wst in secs))
    w("END")


def prep(minutes, seed, offset_fn, jitter, sev, **kw):
    rng, texts, starts, durs, audio = H.gen(minutes, seed, **kw)
    T = H.stamps(starts, rng, offset_fn, jitter)
    sp = [] if sev == "none" else H.asr_sim(texts, starts, durs, np.random.default_rng(seed + 9), **H.SEVERITY[sev])
    return rng, texts, starts, durs, audio, T, sp


rng, texts, starts, durs, audio, T, sp = prep(2, 301, lambda s: 1.5, 0.1, "typical")
F = H.feats(audio)
fuse_case("clean_words_and_audio", T, texts, F, sp)
fuse_case("clean_with_clock_offset", T, texts, F, sp, clock_offset=1234)
fuse_case("audio_only", T, texts, F, [])
rng, texts, starts, durs, audio, T, sp = prep(2, 302, lambda s: 1.5, 0.1, "typical")
F = H.feats(audio)
sh = list(texts); np.random.default_rng(3).shuffle(sh)
fuse_case("shuffled_text", T, sh, F, sp)
rng, texts, starts, durs, audio, T, sp = prep(3, 303, lambda s: 2.0 if s < 90 else 8.0, 0.1, "typical")
fuse_case("step", T, texts, H.feats(audio), sp)
rng, texts, starts, durs, audio, T, sp = prep(2, 304, lambda s: 1.2, 0.1, "typical", p_cont=0.6)
fuse_case("no_pauses", T, texts, H.feats(audio), sp)
rng, texts, starts, durs, audio, T, sp = prep(2, 309, lambda s: 0.0, 0.03, "typical")
fuse_case("already_correct", T, texts, H.feats(audio), sp)
rng, texts, starts, durs, audio, T, sp = prep(2, 308, lambda s: 1.2, 0.1, "none", p_cont=0.6)
fuse_case("no_pauses_audio_only", T, texts, H.feats(audio), [])
rng, texts, starts, durs, audio, T, sp = prep(2, 305, lambda s: 1.5 * s / 120, 0.2, "hard", noise_db=-38)
fuse_case("noisy_hard_asr", T, texts, H.feats(audio), sp)
# phantom lines: text that is not in the recording
rng, texts, starts, durs, audio, T, sp = prep(3, 306, lambda s: 1.5, 0.1, "typical")
rr = np.random.default_rng(9); tp, Tp = [], []
for tx, t in zip(texts, T):
    tp.append(tx); Tp.append(t)
    if rr.random() < 0.2:
        tp.append(" ".join(rr.choice(H.LEX[0], 8)).capitalize() + "."); Tp.append(t + 900)
for i in range(1, len(Tp)):
    if Tp[i] <= Tp[i - 1]: Tp[i] = Tp[i - 1] + 50
fuse_case("phantom_lines", Tp, tp, H.feats(audio), sp)
rng, texts, starts, durs, audio, T, sp = prep(2, 307, lambda s: 1.5, 0.1, "typical")
sil = (np.random.default_rng(1).normal(0, 1, len(audio)) * 10 ** (-50 / 20)).astype(np.float32)
fuse_case("silence", T, texts, H.feats(sil), [])


# ------------------------------------------------------------------------------------------ coarse tracker: Viterbi and hypotheses
r = np.random.default_rng(77)
for k in range(6):
    Wn, L = int(r.integers(5, 10)), 41
    S = r.uniform(0.0, 0.2, (Wn, L))
    lag = int(r.integers(5, 35))
    for wi in range(Wn):
        if r.random() < 0.15: lag = int(np.clip(lag + r.integers(-30, 30), 0, L - 1))      # a step (any size)
        elif r.random() < 0.5: lag = int(np.clip(lag + r.integers(-1, 2), 0, L - 1))        # drift
        if r.random() < 0.85: S[wi, lag] += r.uniform(0.3, 0.8)
    path = coarse.viterbi_tv(S, 0.004)
    w(f"VIT_CASE {k} {Wn} {L}")
    for row in S: w("S " + " ".join(f(x) for x in row))
    w("PATH " + " ".join(str(int(x)) for x in path)); w("END")

for k in range(8):
    n = int(r.integers(4, 9)); info = []; lag = int(r.integers(-3000, 3000)); c = 45000
    for _ in range(n):
        if r.random() < 0.3: lag += int(r.integers(-20000, 20000))
        else: lag += int(r.integers(-400, 400))
        info.append(dict(center_ms=c, lag_ms=lag, ok=bool(r.random() < 0.7))); c += 45000
    w(f"HYP_CASE {k} {len(info)}")
    for x in info: w(f"WIN {x['center_ms']} {x['lag_ms']} {int(x['ok'])}")
    edge = [x['center_ms'] + d for x in info for d in (-60500, -60000, -59500, 59500, 60000, 60500)]      # right at the cover distance
    for t in sorted({int(v) for v in r.integers(0, c + 60000, 12)} | {max(0, e) for e in edge}):
        lags, cov = coarse.shift_hypotheses(info, t)
        w(f"Q {t} {','.join(f(x) for x in lags) or '-'} {','.join(f(x) for x in cov) or '-'}")
    w("END")


# long stretches with no usable window (the "not covered" outcomes), smooth and stepped
for k, (oks, lags) in enumerate([([1, 0, 0, 0, 0, 1], [500, 0, 0, 0, 0, 700]), ([1, 0, 0, 0, 1], [500, 0, 0, 0, 9000]), ([0, 0, 1, 0, 0, 0, 0], [0, 0, 300, 0, 0, 0, 0])]):
    info = [dict(center_ms=45000 * (i + 1), lag_ms=lags[i], ok=bool(oks[i])) for i in range(len(oks))]
    w(f"HYP_CASE {100 + k} {len(info)}")
    for x in info: w(f"WIN {x['center_ms']} {x['lag_ms']} {int(x['ok'])}")
    for t in range(0, 45000 * (len(oks) + 2), 7500):
        lags_, cov = coarse.shift_hypotheses(info, t)
        w(f"Q {t} {','.join(f(x) for x in lags_) or '-'} {','.join(f(x) for x in cov) or '-'}")
    w("END")


# ------------------------------------------------------------------------------------------ step-aware re-centring from anchors
for k in range(8):
    n = int(r.integers(6, 40)); ts = sorted(int(v) for v in r.integers(0, 600000, n)); base = int(r.integers(-3000, 3000)); sh_ = []
    cut = int(r.choice(ts))
    for t in ts:
        step = int(r.integers(3000, 12000)) if (k % 2 == 0 and t > cut) else 0
        sh_.append(base + step + int(r.integers(-150, 150)))
    order = r.permutation(n)          # the Kotlin code must not assume the anchors arrive sorted
    ts_u = [ts[i] for i in order]; sh_u = [sh_[i] for i in order]
    w(f"ANCHOR_CASE {k} {n}")
    w("TS " + " ".join(map(str, ts_u))); w("SH " + " ".join(map(str, sh_u)))
    for t in sorted(int(v) for v in r.integers(0, 620000, 10)):
        hs = A.anchor_hypotheses(ts_u, sh_u, t)
        w(f"Q {t} {','.join(f(x) for x in hs)}")
    w("END")

open(sys.argv[1], "w", encoding="utf-8").write("\n".join(out) + "\n")
print(f"wrote {len(out)} lines -> {sys.argv[1]}")
