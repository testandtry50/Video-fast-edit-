"""The complete alignment pipeline (reference for the Kotlin implementation): evidence -> fused start -> calibrated
confidence -> estimates for lines with no evidence -> status -> sections that cannot be aligned confidently.

Confidence means: the estimated probability that the detected start is within 250 ms of where the line is really spoken.
It was fitted on SIMULATED recordings with known ground truth (calibrate.py) and is never reported above 99 %.
"""
import numpy as np
import fusion as U
import lexical as X
import align2 as A

HIGH = 0.95              # a correction is applied automatically only at or above this
MATCH_TOL_MS = 100       # a timestamp this close to the detected start already matches
CAP_BOTH = 0.99          # two independent kinds of evidence agree
CAP_ONE = 0.97           # only one kind of evidence: never more than this
CAP_ESTIMATE = 0.70      # inferred from neighbours: never "high"
GATE_AUDIO = 0.80        # audio-led evidence below this audio confidence is never "high"
GATE_FLOOR = 0.50        # ... and below this it is at most 0.60

# coefficients of the logistic model over U.FEATURES + bias (calibrate.py output)
W = [6.687, 0.764, 0.315, -0.094, -1.785, -1.582, -0.674, 0.770, 5.473, -0.353, -0.175, -1.039, -0.411, -0.347, 0.000, 2.325, -1.366]

# 90th-percentile absolute error (ms) per evidence class when the recording is clear / noisy (measured, see README)
PRECISION = {"AUDIO": (40, 120), "BOTH": (40, 120), "DISAGREE": (60, 150), "DIP": (320, 400), "WORDDIP": (150, 250), "SNAP": (150, 250), "WORDS": (250, 350)}


def logistic(x):
    return 1.0 / (1.0 + np.exp(-x))


def calibrated(d):
    """-> P(within 250 ms), capped. d = a fused line (fusion.fuse_lines) with 'clarity' set."""
    if d["final"] is None:
        return 0.0
    x = U.feature_vector(d) + [1.0]
    p = float(logistic(sum(w * v for w, v in zip(W, x))))
    p = min(p, CAP_BOTH if d["cls"] == "BOTH" else CAP_ONE)
    # Hard gates carried over from the audio engine (measured: 0 wrong among its "high" lines). A fitted curve is unreliable in
    # the low-confidence tail, so it may never talk the audio score up: audio-led evidence needs cA >= 0.80 to be "high".
    if d["cls"] in ("AUDIO", "DIP", "DISAGREE") and d["cA"] < GATE_AUDIO:
        p = min(p, 0.90)
    if d["a"] is not None and d["cA"] < GATE_FLOOR:
        p = min(p, 0.60)
    # Flat contradictions are never a score: confident words here that are not this line's, or this line's words found
    # strongly at a quite different place (out of order, or its timestamp is far off).
    if d["contra"]:
        p = min(p, 0.40)
    if d["strongL"] and d["gap"] is not None and d["gap"] > U.CONFLICT_MS:
        p = min(p, 0.50)
    return p


def precision_ms(d):
    lo, hi = PRECISION[d["cls"]]
    return int(round(lo + (hi - lo) * (1.0 - d.get("clarity", 1.0))))


def reason_for(d, p):
    if d["final"] is None:
        return "No matching speech was found for this line."
    if d["contra"]:
        return "The words spoken here do not match this line's text."
    if d["strongL"] and d["gap"] is not None and d["gap"] > U.CONFLICT_MS:
        return "This line's words are heard at a different place in the recording: the line may be out of order, or its timestamp is far off."
    if d["cls"] == "DISAGREE":
        return "The audio and the speech recognizer disagree about where this line starts."
    if d["cls"] in ("DIP", "WORDDIP", "WORDS"):
        return "No clear pause before this line (continuous speech), so its exact start is less certain."
    if d.get("clarity", 1.0) < 0.35:
        return "The recording is noisy, so the start is less certain."
    return "Not enough evidence to be sure of this line."


def estimate_for(t, anchors):
    left = [a for a in anchors if a[0] <= t and t - a[0] <= 60000][-1:]
    right = [a for a in anchors if a[0] > t and a[0] - t <= 60000][:1]
    if left and right:
        (tl, sl), (tr, sr) = left[0], right[0]
        gap = abs(sl - sr)
        if gap <= 250:
            return sl + (sr - sl) * (t - tl) / max(1, tr - tl), 0.70, max(250, int(gap) + 150)
        if gap <= 1000:
            return sl + (sr - sl) * (t - tl) / max(1, tr - tl), 0.50, int(gap) + 250
        return None            # the neighbours disagree about the offset (a step): the line could be on either side
    one = left or right
    if one and abs(one[0][0] - t) <= 20000:
        return one[0][1], 0.50, 600
    return None


def run(T, texts, F, spoken):
    """The whole thing for one recording. F = harness.feats(audio) (or the equivalent); spoken = [(text, start_ms, end_ms, conf)].
    -> list of items: dict(index, original, detected, diff, confidence, precision, status, evidence, reason)."""
    n = len(T)
    L = X.lexical_lines(texts, spoken) if spoken else [None] * n
    lex = [l["start"] if X.strong(l) else None for l in L]
    m, rows, rho = U.acoustic_full(T, texts, F, lex if spoken else None)
    units = [A.units(t) for t in texts]
    fused = U.fuse_lines(T, texts, m, rows, L if spoken else None, spoken, units)
    return judge(T, fused, U.clarity_of(F["rdb"]))


def judge(T, fused, clarity):
    """Calibrated confidence, estimates for lines with no evidence, statuses. fused = fusion.fuse_lines(...)."""
    n = len(T)
    items = []
    for i, d in enumerate(fused):
        d["clarity"] = clarity
        p = calibrated(d)
        items.append(dict(index=i, original=T[i], detected=d["final"], confidence=p, precision=precision_ms(d) if d["final"] is not None else None,
                          evidence=d["cls"], reason=None, d=d))
    anchors = [(it["original"], it["detected"] - it["original"]) for it in items if it["detected"] is not None and it["confidence"] >= HIGH]
    for it in items:
        d = it["d"]
        if it["detected"] is None:
            e = estimate_for(it["original"], anchors) if anchors else None
            if e is not None:
                shift, c, prec = e
                it.update(detected=int(round(it["original"] + shift)), confidence=min(c, CAP_ESTIMATE), precision=prec, evidence="ESTIMATE")
        diff = None if it["detected"] is None else it["detected"] - it["original"]
        it["diff"] = diff
        if it["detected"] is None:
            it["status"] = "CANNOT_ALIGN"; it["reason"] = "No matching speech was found for this line."
        elif it["evidence"] == "ESTIMATE":
            it["status"] = "ESTIMATED"; it["reason"] = "No speech evidence for this line: placed from the neighbouring lines."
        elif it["confidence"] >= HIGH:
            it["status"] = "MATCHES" if abs(diff) <= MATCH_TOL_MS else "CORRECTION_READY"
        else:
            it["status"] = "NEEDS_REVIEW"; it["reason"] = reason_for(d, it["confidence"])
    return items


def sections(items, min_lines=2):
    """Stretches of consecutive lines that could not be aligned with confidence. -> [(first, last, count, worst_status)]"""
    bad = {"NEEDS_REVIEW", "ESTIMATED", "CANNOT_ALIGN"}
    out, i, n = [], 0, len(items)
    while i < n:
        if items[i]["status"] in bad:
            j = i
            while j + 1 < n and items[j + 1]["status"] in bad: j += 1
            if j - i + 1 >= min_lines or any(items[k]["status"] == "CANNOT_ALIGN" for k in range(i, j + 1)):
                worst = "CANNOT_ALIGN" if any(items[k]["status"] == "CANNOT_ALIGN" for k in range(i, j + 1)) else \
                        ("NEEDS_REVIEW" if any(items[k]["status"] == "NEEDS_REVIEW" for k in range(i, j + 1)) else "ESTIMATED")
                out.append((i, j, j - i + 1, worst))
            i = j + 1
        else:
            i += 1
    return out
