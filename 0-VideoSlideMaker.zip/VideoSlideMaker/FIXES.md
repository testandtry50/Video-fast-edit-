# Fixes in this build

## 1. Photos turning blank (Preview and exported video)
Photos are stored only as links (content Uris) to the original files. When Android no longer allows reading that link
(more than ~500 single photos picked, a source that refuses long-term access, file moved/deleted, app restarted), the
photo could not be opened - the Preview showed nothing and the exporter silently drew a black slide.

* `data/ImageStore.kt`
  * Single photos that Android will NOT remember access to are copied (unchanged bytes) into the app's private
    `files/photos` folder on import, so they can never expire. Whole-folder imports and remembered photos are not copied.
  * A photo whose header can't be read at all is no longer added as a 0x0 "ghost" photo; it is skipped and counted in the
    existing "couldn't be added" note.
  * New `canOpen(uri)` quick check.
* `export/VideoExportEngine.kt`
  * Before any slow work, every photo used by the video is checked. If any can't be opened the export stops and names them.
  * If some (not all) slides still fail while rendering, the export fails with a reason instead of producing black gaps.
* `ui/screens/PreviewScreen.kt`: a photo that can't be opened now shows "This photo can't be opened" on the picture.

Photos that are ALREADY broken in an existing project must be removed and added again once (Photos step).

## 2. Background music not heard in Preview
The Preview deliberately did not play background music ("Hear it in the Audio step").

* New `audio/BackgroundPreviewPlayer.kt`: builds the real background mix (same renderer as the export) 40 s at a time and
  streams it through one AudioTrack; the next piece is built while the current one plays.
* `viewmodel/AppViewModel.kt`: starts it together with the photo clock (music and pictures begin together), stops it on
  pause / seek / leave / end, restarts it when the speed changes.
* The music in Preview is the music alone (no lowering under the voice). "Hear the mix" in the Audio step is still the
  exact final mix.

Not compiled or run here (no Android SDK in the sandbox) - only a bracket-balance check was done. Please build and test.

## 3. Folder import order (Photos step)
Tapping "Add a whole folder + sub-folders" now first asks: Oldest → newest, Newest → oldest, or By file name.
Date = the file's date in the phone's file manager (what its ⋮ menu sorts by), across the folder and all sub-folders;
photos with no date go last. Files: `data/ImageStore.kt` (FolderSort, date column + sorting),
`viewmodel/AppViewModel.kt` (setFolderSort), `ui/screens/PhotosScreen.kt` (the choice dialog).
