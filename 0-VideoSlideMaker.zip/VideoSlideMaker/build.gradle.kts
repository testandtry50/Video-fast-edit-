// Top-level build file. Individual module build files apply the plugins they need.
plugins {
    // 8.9.1 is the first Android Gradle plugin that supports API 36 (Google Play needs targetSdk 36); it needs Gradle 8.11.1+
    id("com.android.application") version "8.9.1" apply false
    id("org.jetbrains.kotlin.android") version "1.9.24" apply false
}
