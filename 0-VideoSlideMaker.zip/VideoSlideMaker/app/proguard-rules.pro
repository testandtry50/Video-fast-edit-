# Add project specific ProGuard rules here.
# Compose, MediaCodec and TextToSpeech all use reflection-light standard Android APIs
# that don't need special keep rules beyond the defaults AGP already applies.

-dontwarn org.jetbrains.annotations.**

# Vosk speech recognition (the transcript accuracy checker). JNA finds Vosk's native functions by name at run time, so
# neither library's classes may be renamed or removed by R8, and JNA mentions desktop-only classes that Android lacks.
-keep class com.sun.jna.** { *; }
-keepclassmembers class * extends com.sun.jna.** { public *; }
-keep class org.vosk.** { *; }
-dontwarn java.awt.**
-dontwarn com.sun.jna.**
