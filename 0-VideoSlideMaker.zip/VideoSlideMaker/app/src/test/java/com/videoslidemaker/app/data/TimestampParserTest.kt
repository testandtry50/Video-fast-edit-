package com.videoslidemaker.app.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import java.util.Random

class TimestampParserTest {

    // ---------- helpers ----------

    private fun ms(text: String): Long = when (val r = TimestampParser.parse(text)) {
        is TimestampParser.Result.Ok -> r.millis
        is TimestampParser.Result.Error -> { fail("Expected \"$text\" to parse but got: ${r.message}"); -1L }
    }

    private fun error(text: String): String = when (val r = TimestampParser.parse(text)) {
        is TimestampParser.Result.Ok -> { fail("Expected \"$text\" to be rejected but it parsed as ${r.millis} ms"); "" }
        is TimestampParser.Result.Error -> r.message
    }

    private fun hms(h: Long, m: Long, s: Long, milli: Long = 0): Long =
        h * 3_600_000L + m * 60_000L + s * 1_000L + milli

    // ---------- the formats from the requirements ----------

    @Test fun requiredFormats() {
        assertEquals(0L, ms("00:00"))
        assertEquals(0L, ms("00:00:00"))
        assertEquals(0L, ms("00:00:000"))
        assertEquals(0L, ms("00:00:00.000"))
        assertEquals(0L, ms("00:00.000"))
        assertEquals(5_000L, ms("0:05"))
        assertEquals(83_000L, ms("1:23"))
        assertEquals(hms(1, 23, 45), ms("01:23:45"))
        assertEquals(hms(1, 23, 45, 500), ms("01:23:45.500"))
        assertEquals(5_025_500L, ms("01:23:45.500"))
    }

    // ---------- milliseconds must never be read as seconds (and vice versa) ----------

    @Test fun millisecondsAreNotSeconds() {
        assertEquals(500L, ms("00:00:500"))      // M:SS:mmm
        assertEquals(500L, ms("00:00.500"))
        assertEquals(500L, ms("0:00.5"))
        assertEquals(50L, ms("0:00.05"))
        assertEquals(5L, ms("0:00.005"))
        assertEquals(5L, ms("00:00:005"))
        assertEquals(10L, ms("0:00:010"))
        assertEquals(999L, ms("00:00:999"))
        assertEquals(hms(0, 1, 23, 456), ms("1:23:456"))
        assertEquals(1_500L, ms("00:01:500"))
        assertEquals(500L, ms("00:00:00.5"))
    }

    @Test fun threePartWithShortLastPartIsHoursMinutesSeconds() {
        assertEquals(5_000L, ms("00:00:05"))
        assertEquals(10_000L, ms("0:00:10"))
        assertEquals(hms(0, 5, 0), ms("00:05:00"))
        assertEquals(hms(1, 2, 3), ms("1:02:03"))
        assertEquals(hms(1, 2, 3), ms("1:2:3"))
        assertEquals(hms(1, 2, 30), ms("1:02:30"))
        assertEquals(hms(10, 0, 0), ms("10:00:00"))
    }

    // ---------- leading zeros / bare seconds / long minutes ----------

    @Test fun leadingZerosAreOptional() {
        assertEquals(5_000L, ms("0:5"))
        assertEquals(5_000L, ms("00:05"))
        assertEquals(5_000L, ms("000:05"))
        assertEquals(0L, ms("0:0"))
        assertEquals(hms(0, 0, 0), ms("0:0:0"))
        assertEquals(7_000L, ms("007"))
    }

    @Test fun bareSecondsKeepWorking() {
        assertEquals(12_000L, ms("12"))
        assertEquals(12_500L, ms("12.5"))
        assertEquals(0L, ms("0"))
        assertEquals(75_000L, ms("75"))
    }

    @Test fun minutesInMinutesSecondsMayExceed59() {
        assertEquals(90 * 60_000L, ms("90:00"))
        assertEquals(125 * 60_000L + 30_000L, ms("125:30"))
        assertEquals(15 * 60_000L, ms("15:00"))
    }

    // ---------- whitespace and invisible characters ----------

    @Test fun surroundingWhitespaceIsIgnored() {
        assertEquals(5_000L, ms(" 0:05 "))
        assertEquals(83_000L, ms("\t1:23\n"))
        assertEquals(5_000L, ms("\u00A0 0:05 \u00A0"))
        assertEquals(5_000L, ms("\uFEFF0:05"))          // byte-order mark
        assertEquals(5_000L, ms("\u200B0:05\u200B"))    // zero-width space
    }

    // ---------- rounding of extra decimal digits ----------

    @Test fun extraDecimalDigitsRoundHalfUp() {
        assertEquals(1_234L, ms("0:01.2344"))
        assertEquals(1_235L, ms("0:01.2345"))
        assertEquals(2_000L, ms("0:01.9996"))   // carries into the next second
        assertEquals(1_500L, ms("1.5000000"))
        assertEquals(1_000L, ms("1.0004"))
    }

    // ---------- rejection, with useful messages ----------

    @Test fun invalidTimestampsAreRejected() {
        val bad = listOf(
            "", "   ", "abc", "1:", ":30", "1::30", "1:2:3:4", "12:34:56:789",
            "0:60", "0:75", "1:60:00", "1:00:60", "99:59:60",
            "-5", "\u22125", "+5", "1.2.3", "1:23.", ".5", "1:23.5:6",
            "00:00:000.5", "00:00:0000", "0:005", "1:234", "0:123.5",
            "1 : 23", "1e3", "NaN", "Infinity", "5d", "5f", "0x10", "1,5", "0:5s",
            "\u0663:\u0660\u0665",                      // Arabic-Indic digits
            "999999999999", "100:00:00", "0:00:00.000.0"
        )
        for (text in bad) {
            val message = error(text)
            assertTrue("Message for \"$text\" should not be blank", message.isNotBlank())
        }
    }

    @Test fun errorMessagesExplainTheProblem() {
        assertTrue(error("").contains("empty", ignoreCase = true))
        assertTrue(error("0:75").contains("between 0 and 59"))
        assertTrue(error("1:60:00").contains("minutes"))
        assertTrue(error("1:00:60").contains("seconds"))
        assertTrue(error("-5").contains("negative"))
        assertTrue(error("1:2:3:4").contains("too many parts"))
        assertTrue(error("1.2.3").contains("decimal point"))
        assertTrue(error("abc").contains("'a'"))
        assertTrue(error("1 : 23").contains("space"))
        assertTrue(error("00:00:000.5").contains("milliseconds"))
        assertTrue(error("100:00:00").contains("maximum"))
        assertTrue(error("0:75").contains("\"0:75\""))   // quotes what the user typed
    }

    @Test fun maximumIsAcceptedAndOneMillisecondOverIsNot() {
        assertEquals(TimestampParser.MAX_MILLIS, ms("99:59:59.999"))
        error("100:00:00")
        error("99:59:60")
    }

    // ---------- exhaustive / property checks against an independent calculation ----------

    @Test fun everyHmsStyleMatchesIndependentArithmetic() {
        val milliValues = longArrayOf(0, 1, 5, 9, 10, 50, 99, 100, 500, 999)
        for (h in 0L..2L) for (m in 0L..59L) for (s in 0L..59L) for (milli in milliValues) {
            val expected = hms(h, m, s, milli)
            val hh = h.toString().padStart(2, '0')
            val mm = m.toString().padStart(2, '0')
            val ss = s.toString().padStart(2, '0')
            val fff = milli.toString().padStart(3, '0')

            // H:MM:SS.fff in padded and unpadded styles
            assertEquals(expected, ms("$hh:$mm:$ss.$fff"))
            assertEquals(expected, ms("$h:$m:$s.$fff"))
            if (milli == 0L) {
                assertEquals(expected, ms("$hh:$mm:$ss"))
                assertEquals(expected, ms("$h:$m:$s"))
            }

            // M:SS:mmm and M:SS.fff, where the minutes are the total minutes
            val totalMinutes = h * 60 + m
            assertEquals(expected, ms("$totalMinutes:$ss:$fff"))
            assertEquals(expected, ms("$totalMinutes:$ss.$fff"))
        }
    }

    @Test fun formatThenParseIsExactForEveryMillisecondInTheFirstSeconds() {
        for (value in 0L..400_000L) {
            assertEquals(value, ms(TimestampParser.format(value)))
            assertEquals(value, ms(TimestampParser.formatCanonical(value)))
        }
    }

    @Test fun formatThenParseIsExactForRandomValuesUpToTheMaximum() {
        val rnd = Random(12345)
        repeat(200_000) {
            val value = (rnd.nextDouble() * TimestampParser.MAX_MILLIS).toLong()
            assertEquals(value, ms(TimestampParser.format(value)))
            assertEquals(value, ms(TimestampParser.formatCanonical(value)))
            // Whole-second display parses to the same value with the milliseconds floored away.
            assertEquals(value / 1000 * 1000, ms(TimestampParser.format(value, includeMillis = false)))
        }
    }

    @Test fun displayFormatAdaptsToTheValue() {
        assertEquals("0:00", TimestampParser.format(0))
        assertEquals("0:05", TimestampParser.format(5_000))
        assertEquals("12:30", TimestampParser.format(750_000))
        assertEquals("1:00:00", TimestampParser.format(3_600_000))
        assertEquals("1:01:40", TimestampParser.format(3_700_000))
        assertEquals("0:02.500", TimestampParser.format(2_500))
        assertEquals("0:00.005", TimestampParser.format(5))
        assertEquals("1:23:45.500", TimestampParser.format(5_025_500))
        assertEquals("0:02", TimestampParser.format(2_500, includeMillis = false))
        assertEquals("0:00", TimestampParser.format(-1_000))
        assertEquals("01:23:45.500", TimestampParser.formatCanonical(5_025_500))
        assertEquals("00:00:00.000", TimestampParser.formatCanonical(0))
    }

    // ---------- the seconds-based helpers the rest of the app uses ----------

    @Test fun secondsHelpersAreExact() {
        assertEquals(5.0, ScriptParser.parseTime("0:05")!!, 0.0)
        assertEquals(5025.5, ScriptParser.parseTime("01:23:45.500")!!, 0.0)
        assertEquals(0.5, ScriptParser.parseTime("00:00:500")!!, 0.0)
        assertEquals(null, ScriptParser.parseTime("0:75"))
        assertEquals(null, ScriptParser.parseTime("NaN"))

        assertEquals("0:00", ScriptParser.formatTime(Double.NaN))
        assertEquals("0:00", ScriptParser.formatTime(-3.0))
        assertEquals("0:00", ScriptParser.formatTime(Double.POSITIVE_INFINITY))
        assertEquals("0:02.500", ScriptParser.formatTime(2.5))
        assertEquals("0:00.300", ScriptParser.formatTime(0.1 + 0.2))   // floating-point noise doesn't leak
        assertEquals("1:01:40", ScriptParser.formatTime(3700.0))
        assertEquals("2:05", ScriptParser.formatClock(125.7))
        assertEquals("0:03", ScriptParser.formatClock(2.9996))
    }

    @Test fun secondsRoundTripThroughDisplayTextExactly() {
        for (value in 0L..200_000L step 7) {
            val seconds = value / 1000.0
            assertEquals(seconds, ScriptParser.parseTime(ScriptParser.formatTime(seconds))!!, 0.0)
        }
    }

    // ---------- whole scripts ----------

    @Test fun scriptAcceptsEveryFormatOnOneFile() {
        val script = listOf(
            "00:00 - Intro",
            "0:05 - Hello",
            "00:00:10 - Ten seconds",
            "00:00:015 - Fifteen ms",
            "00:20.250 - Twenty and a quarter",
            "00:00:25.500 - With hours and fraction",
            "1:23 text with no dash",
            "01:23:45.500 - Late in the video",
            "12 - plain seconds",
            "0:06"
        ).joinToString("\n")

        val result = ScriptParser.parseScriptDetailed(script)
        assertTrue(result.issues.isEmpty())
        assertEquals(
            listOf(0L, 5_000L, 10_000L, 15L, 20_250L, 25_500L, 83_000L, 5_025_500L, 12_000L, 6_000L),
            result.lines.map { it.timestampMs }
        )
        assertEquals("Intro", result.lines[0].text)
        assertEquals("Fifteen ms", result.lines[3].text)
        assertEquals("With hours and fraction", result.lines[5].text)
        assertEquals("text with no dash", result.lines[6].text)
        assertEquals("Late in the video", result.lines[7].text)
        assertEquals("", result.lines[9].text)
        assertEquals(5025.5, result.lines[7].timestampSec, 0.0)
    }

    @Test fun scriptSeparatorsAndDigitsInText() {
        val result = ScriptParser.parseScript(
            "0:05 - 3 men walked in\n0:10 3 more\n0:15-no spaces\n0:20 – en dash\n0:25 — em dash\n  0:30   -   padded  "
        )
        assertEquals(
            listOf("3 men walked in", "3 more", "no spaces", "en dash", "em dash", "padded"),
            result.map { it.text }
        )
        assertEquals(listOf(5_000L, 10_000L, 15_000L, 20_000L, 25_000L, 30_000L), result.map { it.timestampMs })
    }

    @Test fun scriptHandlesBomAndWindowsLineEndings() {
        val result = ScriptParser.parseScriptDetailed("\uFEFF0:00 - first\r\n0:05 - second\r\n\r\n00:00:10 - third\r\n")
        assertTrue(result.issues.isEmpty())
        assertEquals(listOf(0L, 5_000L, 10_000L), result.lines.map { it.timestampMs })
        assertEquals(listOf("first", "second", "third"), result.lines.map { it.text })
    }

    @Test fun scriptReportsSkippedLinesWithOriginalLineNumbers() {
        val script = "My Story\n\n0:05 - fine\n0:75 - bad seconds\n1:2:3:4 - too many parts\n0:10 - also fine\n[0:12] bracketed"
        val result = ScriptParser.parseScriptDetailed(script)

        assertEquals(listOf(5_000L, 10_000L), result.lines.map { it.timestampMs })
        assertEquals(listOf(1, 4, 5, 7), result.issues.map { it.lineNumber })
        assertTrue(result.issues[0].message.contains("doesn't start with a timestamp"))
        assertTrue(result.issues[1].message.contains("between 0 and 59"))
        assertTrue(result.issues[2].message.contains("too many parts"))
        assertTrue(result.issues[1].describe().startsWith("Line 4:"))
    }

    @Test fun malformedRunIsNeverHalfRead() {
        // 1.2.3 must not become 1.2 seconds with ".3 Introduction" leaking into the sentence.
        val result = ScriptParser.parseScriptDetailed("1.2.3 Introduction")
        assertTrue(result.lines.isEmpty())
        assertEquals(1, result.issues.size)
    }
}
