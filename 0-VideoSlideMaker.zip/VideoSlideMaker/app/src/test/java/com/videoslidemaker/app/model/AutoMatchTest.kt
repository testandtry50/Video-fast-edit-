package com.videoslidemaker.app.model

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** The Match screen's "Auto-match" rule: photo 1 on the earliest sentence, photo 2 on the next, and so on. */
class AutoMatchTest {

    private fun times(n: Int) = List(n) { it * 3.0 }
    private fun none(n: Int): List<String?> = List(n) { null }
    private fun pool(n: Int) = List(n) { "p${it + 1}" }

    @Test
    fun photosGoOnSentencesInOrder() {
        val r = AutoMatch.plan(times(4), none(4), pool(4), replaceExisting = true)
        assertEquals(listOf<String?>("p1", "p2", "p3", "p4"), r.assignments)
        assertEquals(4, r.changed)
        assertEquals(4, r.withPhoto)
        assertEquals(0, r.withoutPhoto)
        assertEquals(0, r.unusedPhotos)
    }

    @Test
    fun fewerPhotosThanSentencesLeavesTheLastSentencesEmpty() {
        val r = AutoMatch.plan(times(5), none(5), pool(3), replaceExisting = true)
        assertEquals(listOf<String?>("p1", "p2", "p3", null, null), r.assignments)
        assertEquals(3, r.withPhoto)
        assertEquals(2, r.withoutPhoto)
        assertEquals(0, r.unusedPhotos)
    }

    @Test
    fun morePhotosThanSentencesLeavesTheLastPhotosUnused() {
        val r = AutoMatch.plan(times(2), none(2), pool(5), replaceExisting = true)
        assertEquals(listOf<String?>("p1", "p2"), r.assignments)
        assertEquals(0, r.withoutPhoto)
        assertEquals(3, r.unusedPhotos)
    }

    @Test
    fun replaceStartsOverAndClearsOldMatchesBeyondThePhotos() {
        // sentences 4 and 5 were matched by hand, but there are only 3 photos: starting over clears them
        val current = listOf<String?>("p3", null, "p2", "p1", "p1")
        val r = AutoMatch.plan(times(5), current, pool(3), replaceExisting = true)
        assertEquals(listOf<String?>("p1", "p2", "p3", null, null), r.assignments)
    }

    @Test
    fun sentencesAreFilledInTimeOrderEvenIfTheListIsNotSorted() {
        // list order: 6s, 0s, 3s  ->  the 0s sentence (index 1) is the earliest and gets photo 1
        val r = AutoMatch.plan(listOf(6.0, 0.0, 3.0), none(3), pool(3), replaceExisting = true)
        assertEquals(listOf<String?>("p3", "p1", "p2"), r.assignments)
    }

    @Test
    fun sentencesWithTheSameTimeKeepTheirListOrder() {
        val r = AutoMatch.plan(listOf(1.0, 1.0, 1.0), none(3), pool(3), replaceExisting = true)
        assertEquals(listOf<String?>("p1", "p2", "p3"), r.assignments)
    }

    @Test
    fun fillOnlyKeepsExistingMatchesAndUsesUnusedPhotosInPoolOrder() {
        // sentence 2 already has p2 (by hand); the empty ones get the unused photos p1, p3, p4 in order
        val current = listOf<String?>(null, "p2", null, null)
        val r = AutoMatch.plan(times(4), current, pool(4), replaceExisting = false)
        assertEquals(listOf<String?>("p1", "p2", "p3", "p4"), r.assignments)
        assertEquals(3, r.changed)
    }

    @Test
    fun fillOnlyNeverTouchesAMatchedSentence() {
        val current = listOf<String?>("p4", null, "p4", null)
        val r = AutoMatch.plan(times(4), current, pool(4), replaceExisting = false)
        assertEquals("p4", r.assignments[0])
        assertEquals("p4", r.assignments[2])
        // the unused photos p1, p2, p3 go to the two empty sentences, earliest first
        assertEquals("p1", r.assignments[1])
        assertEquals("p2", r.assignments[3])
        assertEquals(1, r.unusedPhotos) // p3
    }

    @Test
    fun fillOnlyTreatsAMatchToAPhotoThatIsGoneAsEmpty() {
        val current = listOf<String?>("gone", "p1")
        val r = AutoMatch.plan(times(2), current, pool(2), replaceExisting = false)
        assertEquals(listOf<String?>("p2", "p1"), r.assignments)
    }

    @Test
    fun fillOnlyStopsWhenThePhotosRunOut() {
        val current = listOf<String?>("p1", null, null, null)
        val r = AutoMatch.plan(times(4), current, pool(2), replaceExisting = false)
        assertEquals(listOf<String?>("p1", "p2", null, null), r.assignments)
        assertEquals(2, r.withoutPhoto)
    }

    @Test
    fun noPhotosMeansNothingIsWipedInEitherMode() {
        val current = listOf<String?>("p1", "p2", null)
        for (replace in listOf(true, false)) {
            val r = AutoMatch.plan(times(3), current, emptyList(), replaceExisting = replace)
            assertEquals(current, r.assignments)
            assertEquals(0, r.changed)
        }
    }

    @Test
    fun noSentencesIsHarmless() {
        val r = AutoMatch.plan(emptyList(), emptyList(), pool(3), replaceExisting = true)
        assertTrue(r.assignments.isEmpty())
        assertEquals(0, r.changed)
        assertEquals(3, r.unusedPhotos)
    }

    @Test
    fun doingItTwiceChangesNothingTheSecondTime() {
        val first = AutoMatch.plan(times(6), none(6), pool(4), replaceExisting = true)
        val second = AutoMatch.plan(times(6), first.assignments, pool(4), replaceExisting = true)
        assertEquals(first.assignments, second.assignments)
        assertEquals(0, second.changed)
        assertEquals("Nothing changed - the photos are already matched in this order.", second.message())
    }

    @Test
    fun messagesTellTheTruth() {
        val few = AutoMatch.plan(times(5), none(5), pool(3), replaceExisting = true)
        assertEquals(
            "Done - 3 of 5 sentences now have a photo, matched in order. 2 sentences have no photo (not enough photos).",
            few.message()
        )
        val many = AutoMatch.plan(times(2), none(2), pool(3), replaceExisting = true)
        assertEquals(
            "Done - 2 of 2 sentences now have a photo, matched in order. 1 photo was not used (more photos than sentences).",
            many.message()
        )
        val allFilled = AutoMatch.plan(times(2), listOf("p1", "p2"), pool(2), replaceExisting = false)
        assertEquals("Nothing changed - no sentence was without a photo.", allFilled.message())
        val noneLeft = AutoMatch.plan(times(3), listOf("p1", null, null), pool(1), replaceExisting = false)
        assertEquals(
            "Nothing changed - there are no unused photos left for the sentences that have none.",
            noneLeft.message()
        )
    }

    @Test
    fun aVeryLongProjectIsFast() {
        // 6,000 sentences and 6,000 photos (a 5-hour film)
        val n = 6000
        val started = System.nanoTime()
        val r = AutoMatch.plan(times(n), none(n), pool(n), replaceExisting = true)
        val ms = (System.nanoTime() - started) / 1_000_000
        assertEquals("p1", r.assignments.first())
        assertEquals("p6000", r.assignments.last())
        assertTrue("took $ms ms", ms < 1000)
    }

    // ---------- Adding photos in batches, and photos that cannot be opened ----------

    @Test
    fun fiveHundredSentencesFilledTwentyPhotosAtATime() {
        val at = times(500)
        var have = none(500)
        for (batch in 1..25) {
            val photos = pool(batch * 20) // the photo list grows by 20 each time
            // the very first time nothing is matched yet, so the button just runs ("start over")
            val r = AutoMatch.plan(at, have, photos, replaceExisting = batch == 1)
            assertEquals(20, r.changed)
            assertEquals(batch * 20, r.withPhoto)
            assertEquals(500 - batch * 20, r.withoutPhoto)
            have = r.assignments
            assertEquals(photos, have.take(batch * 20))
            assertTrue(have.drop(batch * 20).all { it == null })
        }
    }

    @Test
    fun aBrokenPhotoLeavesItsSentenceEmptyAndTheOthersKeepTheirPlaces() {
        val r = AutoMatch.plan(times(5), none(5), pool(4), replaceExisting = true, unopenable = setOf("p2"))
        assertEquals(listOf<String?>("p1", null, "p3", "p4", null), r.assignments)
        assertEquals(listOf("p2"), r.brokenIds)
        assertTrue(r.message(listOf("two.jpg")).contains("1 photo can't be opened: two.jpg."))
    }

    @Test
    fun fillEmptyCarriesOnAfterAnOldMatchThatNoLongerOpens() {
        // p2 stopped opening after it was matched: it stays where it is, and the new photo goes on the NEXT sentence
        val current = listOf<String?>("p1", "p2", null, null)
        val r = AutoMatch.plan(times(4), current, pool(3), replaceExisting = false, unopenable = setOf("p2"))
        assertEquals(listOf<String?>("p1", "p2", "p3", null), r.assignments)
        assertEquals(listOf("p2"), r.brokenIds)
    }

    @Test
    fun allPhotosBrokenWipesNothing() {
        val current = listOf<String?>("p1", null)
        val r = AutoMatch.plan(times(2), current, pool(2), replaceExisting = true, unopenable = setOf("p1", "p2"))
        assertEquals(current, r.assignments)
        assertEquals(0, r.changed)
        assertTrue(r.message().startsWith("Nothing changed."))
        assertTrue(r.message().contains("2 photos can't be opened"))
    }
}
