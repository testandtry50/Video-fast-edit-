package com.videoslidemaker.app.model

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * The numbers behind the photo effects (zoom in / out, pan, and the "Mix" effects) and the transitions between photos.
 * The Preview and the exported video both use these, so one set of checks covers both.
 *
 * The same checks run in Python in tools/motion-reference/motion_check.py (which also compares the preview with the export frame by frame).
 */
class PhotoMotionTest {
    private val eps = 0.0001f

    @Test
    fun plainEffectsGiveEveryPhotoTheSameMove() {
        assertEquals(List(4) { PhotoMove.ZOOM_IN }, PhotoMotion.plan(EffectStyle.ZOOM_IN, 4))
        assertEquals(List(4) { PhotoMove.ZOOM_OUT }, PhotoMotion.plan(EffectStyle.ZOOM_OUT, 4))
        assertEquals(List(3) { PhotoMove.PAN_LEFT }, PhotoMotion.plan(EffectStyle.PAN_LEFT, 3))
        assertEquals(List(3) { PhotoMove.PAN_RIGHT }, PhotoMotion.plan(EffectStyle.PAN_RIGHT, 3))
        assertEquals(List(2) { PhotoMove.STILL }, PhotoMotion.plan(EffectStyle.NONE, 2))
        assertTrue(PhotoMotion.plan(EffectStyle.ZOOM_IN, 0).isEmpty())
    }

    @Test
    fun alternateZoomsInThenOutThenIn() {
        val expected = listOf(
            PhotoMove.ZOOM_IN, PhotoMove.ZOOM_OUT, PhotoMove.ZOOM_IN, PhotoMove.ZOOM_OUT, PhotoMove.ZOOM_IN
        )
        assertEquals(expected, PhotoMotion.plan(EffectStyle.ZOOM_ALTERNATE, 5))
    }

    @Test
    fun mixIsInOutInInOutAndThenRepeats() {
        val five = listOf(
            PhotoMove.ZOOM_IN, PhotoMove.ZOOM_OUT, PhotoMove.ZOOM_IN, PhotoMove.ZOOM_IN, PhotoMove.ZOOM_OUT
        )
        assertEquals(five, PhotoMotion.plan(EffectStyle.ZOOM_MIX, 5))
        assertEquals(five + five, PhotoMotion.plan(EffectStyle.ZOOM_MIX, 10))
    }

    @Test
    fun randomMixIsFixedNeverRepeatsANeighbourAndUsesEveryMove() {
        val plan = PhotoMotion.plan(EffectStyle.RANDOM_MIX, 500)
        for (i in 1 until plan.size) assertFalse("photos $i and ${i - 1} have the same move", plan[i] == plan[i - 1])
        assertEquals(plan, PhotoMotion.plan(EffectStyle.RANDOM_MIX, 500))
        // adding photos at the end must not change the moves of the photos before them
        assertEquals(plan.take(50), PhotoMotion.plan(EffectStyle.RANDOM_MIX, 50))
        assertEquals(4, plan.toSet().size)
    }

    @Test
    fun zoomInGrowsAndZoomOutShrinksBetweenTheSameTwoSizes() {
        val big = 1f + PhotoMotion.ZOOM_AMOUNT
        assertEquals(1f, PhotoMotion.frameAt(PhotoMove.ZOOM_IN, 0f).scale, eps)
        assertEquals(big, PhotoMotion.frameAt(PhotoMove.ZOOM_IN, 1f).scale, eps)
        assertEquals(big, PhotoMotion.frameAt(PhotoMove.ZOOM_OUT, 0f).scale, eps)
        assertEquals(1f, PhotoMotion.frameAt(PhotoMove.ZOOM_OUT, 1f).scale, eps)
        assertEquals(0.5f, PhotoMotion.frameAt(PhotoMove.ZOOM_IN, 0.3f).panX, eps)
        // out-of-range progress is held at the ends instead of zooming past them
        assertEquals(big, PhotoMotion.frameAt(PhotoMove.ZOOM_IN, 7f).scale, eps)
        assertEquals(1f, PhotoMotion.frameAt(PhotoMove.ZOOM_IN, -3f).scale, eps)
        assertEquals(1f, PhotoMotion.frameAt(PhotoMove.ZOOM_IN, Float.NaN).scale, eps)
    }

    @Test
    fun panLeftMovesTheViewToTheLeftAndPanRightToTheRight() {
        assertEquals(1f, PhotoMotion.frameAt(PhotoMove.PAN_LEFT, 0f).panX, eps)
        assertEquals(0f, PhotoMotion.frameAt(PhotoMove.PAN_LEFT, 1f).panX, eps)
        assertEquals(0f, PhotoMotion.frameAt(PhotoMove.PAN_RIGHT, 0f).panX, eps)
        assertEquals(1f, PhotoMotion.frameAt(PhotoMove.PAN_RIGHT, 1f).panX, eps)
        assertEquals(PhotoMotion.PAN_SCALE, PhotoMotion.frameAt(PhotoMove.PAN_LEFT, 0.5f).scale, eps)
    }

    @Test
    fun blendIsAtMostFourTenthsOfASecondAndAtMostAThirdOfTheSlot() {
        assertEquals(0.4, TransitionMath.blendSeconds(3.0), 1e-9)
        assertEquals(0.3, TransitionMath.blendSeconds(0.9), 1e-9)
        // not started, half way, finished
        assertEquals(0f, TransitionMath.blendT(2.0, 3.0), eps)
        assertEquals(0.5f, TransitionMath.blendT(2.8, 3.0), eps)
        assertEquals(1f, TransitionMath.blendT(3.0, 3.0), eps)
    }

    @Test
    fun fadeToBlackIsDarkAtBothEndsAndFullInTheMiddle() {
        assertEquals(0f, TransitionMath.fadeBlackAlpha(0f, 3.0), eps)
        assertEquals(1f, TransitionMath.fadeBlackAlpha(0.5f, 3.0), eps)
        assertEquals(0f, TransitionMath.fadeBlackAlpha(1f, 3.0), eps)
    }

    @Test
    fun crossfadeBringsTheNextPhotoInOverTheEndOfTheCurrentOne() {
        // photo 0: 0..3 s, photo 1: 3..6 s
        val before = TransitionMath.layerLook(TransitionStyle.CROSSFADE, 1.0, 3.0, 3.0, 3.0, true)
        assertEquals(0f, before.alpha, eps) // not started: invisible
        val mid = TransitionMath.layerLook(TransitionStyle.CROSSFADE, 2.8, 3.0, 3.0, 3.0, true)
        assertEquals(0.5f, mid.alpha, eps)
        assertEquals(0f, mid.progress, eps) // arrives in its starting pose, so there is no jump at the cut
        val current = TransitionMath.layerLook(TransitionStyle.CROSSFADE, 2.8, 0.0, 3.0, 0.0, true)
        assertEquals(1f, current.alpha, eps) // the outgoing photo stays solid underneath (no dip to black)
        val cut = TransitionMath.layerLook(TransitionStyle.CROSSFADE, 3.0, 3.0, 3.0, 3.0, true)
        assertEquals(1f, cut.alpha, eps)
        assertEquals(0f, cut.progress, eps)
    }

    @Test
    fun slideMovesTheCurrentPhotoOutAndTheNextOneInTogether() {
        val outgoing = TransitionMath.layerLook(TransitionStyle.SLIDE, 2.8, 0.0, 3.0, 0.0, true)
        val incoming = TransitionMath.layerLook(TransitionStyle.SLIDE, 2.8, 3.0, 3.0, 3.0, true)
        assertEquals(-0.5f, outgoing.shift, eps)
        assertEquals(0.5f, incoming.shift, eps)
        // the very last photo has nothing to slide out for
        assertEquals(0f, TransitionMath.layerLook(TransitionStyle.SLIDE, 5.9, 3.0, 3.0, 3.0, false).shift, eps)
    }

    @Test
    fun theFirstPhotoIsShownFromTheStartEvenIfItsTimestampIsLater() {
        val look = TransitionMath.layerLook(TransitionStyle.NONE, 0.0, 5.0, 3.0, 0.0, true)
        assertEquals(1f, look.alpha, eps)
        assertEquals(0f, look.progress, eps)
    }

    @Test
    fun aHardCutNeverShowsTheNextPhotoEarly() {
        assertEquals(0f, TransitionMath.layerLook(TransitionStyle.NONE, 2.9, 3.0, 3.0, 3.0, true).alpha, eps)
        assertEquals(0f, TransitionMath.layerLook(TransitionStyle.FADE_BLACK, 2.9, 3.0, 3.0, 3.0, true).alpha, eps)
    }
}
