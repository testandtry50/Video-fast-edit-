package com.videoslidemaker.app.logoclean

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin

/**
 * Tests for the logo cleaner. The synthetic scenarios are identical to
 * tools/logoclean-reference/mirror_scenarios.py, which was run first - the numbers asserted here
 * (with margins) are what that reference measured.
 */
class LogoCleanTest {
    private val W = 320
    private val H = 200

    // the "logo": a dark pill with bright stripes at x 130..189, y 90..111
    private val logoL = 130
    private val logoT = 90
    private val logoR = 190
    private val logoB = 112

    /** Smooth moving "scenery" plus (optionally) the logo at a fixed place. Deterministic, no randomness. */
    private fun frame(k: Int, withLogo: Boolean, shiftX: Int = 0, shiftY: Int = 0): FloatArray {
        val v = FloatArray(W * H)
        val bx = (37 * k) % 200
        val by = (53 * k) % 120
        for (y in 0 until H) {
            for (x in 0 until W) {
                var p = 110.0 + 55.0 * sin(0.045 * x + 0.9 * k) * cos(0.037 * y - 0.7 * k) +
                    35.0 * sin(0.011 * (x + y) * (k + 1))
                if (x in bx until bx + 50 && y in by until by + 40) p += 70.0
                v[y * W + x] = p.coerceIn(0.0, 255.0).toFloat()
            }
        }
        if (withLogo) {
            for (y in logoT until logoB) for (x in logoL until logoR) put(v, x + shiftX, y + shiftY, 25f)
            for (x in 140 until 180) {
                if (((x - 140) / 5) % 2 == 0) for (y in 95 until 107) put(v, x + shiftX, y + shiftY, 235f)
            }
        }
        return v
    }

    private fun put(v: FloatArray, x: Int, y: Int, value: Float) {
        if (x in 0 until W && y in 0 until H) v[y * W + x] = value
    }

    private fun edges(k: Int, withLogo: Boolean, shiftX: Int = 0, shiftY: Int = 0): EdgeData =
        LogoDetector.computeEdges(frame(k, withLogo, shiftX, shiftY), W, H)

    private fun templateFromSixFrames(): LogoTemplate {
        val c = LogoDetector.consistency((0 until 6).map { edges(it, true) })!!
        val blob = LogoDetector.findBlobs(c).first()
        return LogoDetector.toTemplate(blob, c)
    }

    // ------------------------------------------------------------------------------ detection

    @Test
    fun findsTheLogoThatRepeatsAtTheSamePlace() {
        val c = LogoDetector.consistency((0 until 6).map { edges(it, true) })!!
        val blobs = LogoDetector.findBlobs(c)
        assertTrue("a logo should be found", blobs.isNotEmpty())
        val b = blobs[0]
        // reference measured the box as (129, 89, 191, 113) against a true (130, 90, 190, 112)
        assertTrue("left ${b.l}", b.l in 126..134)
        assertTrue("top ${b.t}", b.t in 86..94)
        assertTrue("right ${b.r}", b.r in 186..194)
        assertTrue("bottom ${b.b}", b.b in 108..117)
        assertTrue("every photo has it", b.support > 0.9f)
    }

    @Test
    fun findsNothingWhenTheLogoIsNotRepeated() {
        // only 2 of 6 photos have the logo: it is not at the same place "in (almost) all" photos
        val c = LogoDetector.consistency((0 until 6).map { edges(it, it < 2) })!!
        assertTrue(LogoDetector.findBlobs(c).isEmpty())
    }

    @Test
    fun needsAtLeastThreePhotos() {
        val c = LogoDetector.consistency((0 until 2).map { edges(it, true) })!!
        assertTrue(LogoDetector.findBlobs(c).isEmpty())
    }

    // ------------------------------------------------------------------------------ matching

    @Test
    fun matchSeparatesPhotosWithAndWithoutTheLogo() {
        val tpl = templateFromSixFrames()
        for (k in intArrayOf(7, 9)) {
            val m = LogoDetector.match(edges(k, true), tpl, LogoDetector.FIXED_SEARCH_R)
            assertTrue("with logo k=$k scored ${m.score}", m.score >= LogoDetector.MATCH_FIXED)
            assertTrue("same place, off by ${m.dx},${m.dy}", abs(m.dx) <= 2 && abs(m.dy) <= 2)
        }
        for (k in intArrayOf(8, 11)) {
            val m = LogoDetector.match(edges(k, false), tpl, LogoDetector.FIXED_SEARCH_R)
            assertTrue("without logo k=$k scored ${m.score}", m.score < LogoDetector.MATCH_FIXED)
            val whole = LogoDetector.match(edges(k, false), tpl, -1)
            assertTrue("whole-photo search k=$k scored ${whole.score}", whole.score < LogoDetector.MATCH_FOLLOW)
        }
    }

    @Test
    fun wholePhotoSearchFollowsALogoThatMoved() {
        val tpl = templateFromSixFrames()
        val moved = edges(7, true, shiftX = 25, shiftY = 17)
        val m = LogoDetector.match(moved, tpl, -1)
        assertTrue("score ${m.score}", m.score >= LogoDetector.MATCH_FOLLOW)
        assertTrue("found shift ${m.dx},${m.dy}", abs(m.dx - 25) <= 2 && abs(m.dy - 17) <= 2)
    }

    @Test
    fun templateForABoxFindsRepeatingEdgesInsideIt() {
        val c = LogoDetector.consistency((0 until 6).map { edges(it, true) })!!
        // a box around the logo has a logo in it...
        assertNotNull(LogoDetector.blobInBox(c, 120, 80, 200, 122))
        // ...a box over plain scenery does not
        assertNull(LogoDetector.blobInBox(c, 10, 150, 70, 190))
    }

    // ------------------------------------------------------------------------------ imaging

    private fun gradientImage(w: Int, h: Int): FloatArray {
        val img = FloatArray(w * h * 3)
        for (y in 0 until h) for (x in 0 until w) {
            val g = (40f + 1.2f * x + 0.8f * y).coerceIn(0f, 255f)
            img[(y * w + x) * 3] = g
            img[(y * w + x) * 3 + 1] = g * 0.9f
            img[(y * w + x) * 3 + 2] = g * 0.8f
        }
        return img
    }

    private fun rectMask(w: Int, h: Int, x0: Int, y0: Int, x1: Int, y1: Int): BooleanArray {
        val m = BooleanArray(w * h)
        for (y in y0 until y1) for (x in x0 until x1) m[y * w + x] = true
        return m
    }

    @Test
    fun removeRebuildsASmoothBackgroundAndTouchesNothingFarAway() {
        val w = 120
        val h = 80
        val img = gradientImage(w, h)
        val mask = rectMask(w, h, 40, 30, 80, 50)
        val out = inpaint(img, w, h, mask)
        val near = maxFilter(mask, w, h, 8)
        var sumErr = 0.0
        var inside = 0
        for (i in 0 until w * h) {
            val err = (0..2).maxOf { abs(out[i * 3 + it] - img[i * 3 + it]) }
            if (mask[i]) { sumErr += err; inside++ }
            if (!near[i]) assertEquals("pixel far from the mask must not change", 0f, err, 1e-2f)
        }
        // reference: mean error 0.11 on this gradient (a gradient is exactly what diffusion reproduces)
        assertTrue("mean error inside the mask ${sumErr / inside}", sumErr / inside < 2.0)
    }

    @Test
    fun blurOnlyChangesTheMaskedSpot() {
        val w = 120
        val h = 80
        val img = FloatArray(w * h * 3) { if (((it / 3) % w / 3) % 2 == 0) 30f else 220f } // vertical stripes
        val mask = rectMask(w, h, 40, 30, 80, 50)
        val out = blurMasked(img, w, h, mask, sigma = 6f, feather = 3f)
        val near = maxFilter(mask, w, h, 12)
        var innerChange = 0f
        for (i in 0 until w * h) {
            val d = abs(out[i * 3] - img[i * 3])
            if (!near[i]) assertEquals("pixel far from the mask must not change", 0f, d, 1e-2f)
            if (mask[i]) innerChange = max(innerChange, d)
        }
        assertTrue("the logo area must really be blurred", innerChange > 40f)
    }

    @Test
    fun maxFilterGrowsAndLabelCountsBlobs() {
        val w = 20
        val h = 10
        val b = BooleanArray(w * h)
        b[5 * w + 5] = true
        b[5 * w + 15] = true
        val grown = maxFilter(b, w, h, 1)
        assertEquals(18, grown.count { it })           // two 3x3 squares
        assertEquals(2, label4(grown, w, h).count)     // far apart: two blobs
        assertEquals(1, label4(maxFilter(b, w, h, 6), w, h).count) // grown until they touch: one blob
    }

    @Test
    fun roundedRectHasRoundCornersAndAFilledMiddle() {
        val m = roundedRectMask(30, 20, 0, 0, 30, 20, 6)
        assertFalse("corner pixel is cut off", m[0])
        assertTrue("middle is filled", m[10 * 30 + 15])
        assertTrue("edge middle is filled", m[0 * 30 + 15])
    }

    @Test
    fun upscaledMaskKeepsItsShape() {
        val small = rectMask(4, 4, 1, 1, 3, 3)
        val big = upscaleMask(small, 4, 4, 40, 40)
        assertTrue(big[20 * 40 + 20])
        assertFalse(big[2 * 40 + 2])
        assertFalse(big[38 * 40 + 38])
    }

    // ------------------------------------------------------------------------------ planning / painting

    @Test
    fun planForADrawnBoxStaysInsideThePhoto() {
        val plan = LogoPaint.planMask(1000, 600, LogoBox(0.4f, 0.4f, 0.6f, 0.5f), null, 0f, 0f)
        assertNotNull(plan)
        plan!!
        assertTrue(plan.x0 >= 0 && plan.y0 >= 0 && plan.x0 + plan.w <= 1000 && plan.y0 + plan.h <= 600)
        assertEquals(plan.w * plan.h, plan.mask.size)
        assertTrue(plan.mask.any { it })
        // the mask covers the box (400..600 x 240..300) but not the whole window
        val cx = 500 - plan.x0
        val cy = 270 - plan.y0
        assertTrue(plan.mask[cy * plan.w + cx])
        assertFalse(plan.mask[0])
    }

    @Test
    fun planRefusesAnAreaThatIsTooBigToRepaint() {
        assertNull(LogoPaint.planMask(8000, 6000, LogoBox(0.05f, 0.05f, 0.95f, 0.95f), null, 0f, 0f))
    }

    @Test
    fun paintLeavesPixelsAwayFromTheMaskIdenticalAndKeepsAlpha() {
        val w = 60
        val h = 40
        val px = IntArray(w * h) { (0xFF shl 24) or (((it % w) * 4) shl 16) or (((it / w) * 6) shl 8) or 90 }
        val mask = rectMask(w, h, 25, 15, 35, 25)
        val out = LogoPaint.paint(px, w, h, mask, LogoCleanMode.REMOVE, 0.4f)
        val near = maxFilter(mask, w, h, 8)
        for (i in 0 until w * h) {
            assertEquals("alpha kept", 0xFF, (out[i] ushr 24) and 0xFF)
            if (!near[i]) assertEquals("pixel $i changed", px[i], out[i])
        }
    }

    // ------------------------------------------------------------------------------ Remove + Blur

    private fun gray(v: Int): Int {
        val c = v.coerceIn(0, 255)
        return (0xFF shl 24) or (c shl 16) or (c shl 8) or c
    }

    /** A scene with a bright striped "logo" in the rectangle (40,30)-(80,50); [noisy] adds film-grain-like noise. */
    private fun sceneWithLogo(w: Int, h: Int, noisy: Boolean): Pair<IntArray, IntArray> {
        val clean = IntArray(w * h)
        val withLogo = IntArray(w * h)
        for (y in 0 until h) for (x in 0 until w) {
            val noise = if (noisy) ((x * 7919 + y * 104729) % 17) - 8 else 0
            val bg = (60 + 0.8f * x + 0.5f * y).toInt() + noise
            clean[y * w + x] = gray(bg)
            val inLogo = x in 40 until 80 && y in 30 until 50
            withLogo[y * w + x] = if (inLogo) gray(if (x % 6 < 3) 250 else 15) else gray(bg)
        }
        return clean to withLogo
    }

    @Test
    fun removePlusBlurPaintsTheLogoOutAndTouchesNothingFarAway() {
        val w = 120
        val h = 80
        val (clean, withLogo) = sceneWithLogo(w, h, noisy = false)
        val mask = rectMask(w, h, 40, 30, 80, 50)
        val out = LogoPaint.paint(withLogo, w, h, mask, LogoCleanMode.BOTH, 0.4f)
        val near = maxFilter(mask, w, h, 12)
        var sumErr = 0.0
        var inside = 0
        for (i in 0 until w * h) {
            assertEquals("alpha kept", 0xFF, (out[i] ushr 24) and 0xFF)
            if (!near[i]) assertEquals("pixel $i far from the logo changed", withLogo[i], out[i])
            if (mask[i]) {
                sumErr += abs((out[i] and 0xFF) - (clean[i] and 0xFF))
                inside++
            }
        }
        // the stripes (15 and 250) must be gone: what is left is close to the smooth background
        assertTrue("mean error inside the logo ${sumErr / inside}", sumErr / inside < 6.0)
    }

    @Test
    fun removePlusBlurIsSofterThanRemoveAloneOnTheRepairedSpot() {
        val w = 120
        val h = 80
        val (_, withLogo) = sceneWithLogo(w, h, noisy = true)
        val mask = rectMask(w, h, 40, 30, 80, 50)
        val removed = LogoPaint.paint(withLogo, w, h, mask, LogoCleanMode.REMOVE, 0.4f)
        val both = LogoPaint.paint(withLogo, w, h, mask, LogoCleanMode.BOTH, 0.4f)
        // how "busy" the middle of the repaired spot is: average step between neighbouring pixels
        fun busy(px: IntArray): Double {
            var sum = 0.0
            var n = 0
            for (y in 36 until 44) for (x in 48 until 72) {
                sum += abs((px[y * w + x] and 0xFF) - (px[y * w + x + 1] and 0xFF))
                n++
            }
            return sum / n
        }
        assertTrue("Remove + Blur must not be busier than Remove alone", busy(both) <= busy(removed) + 0.01)
        // and it really did something on top of Remove
        assertTrue("the extra blur changed the repaired spot", both.indices.any { both[it] != removed[it] })
    }

    @Test
    fun theThreeModesAreNamedAndSurviveSavingByName() {
        assertEquals(3, LogoCleanMode.entries.size)
        for (m in LogoCleanMode.entries) {
            assertTrue(m.label.isNotBlank() && m.doneLabel.isNotBlank() && m.verb.isNotBlank())
            // the saved draft stores the mode by name and reads it back the same way
            assertEquals(m, LogoCleanMode.entries.first { it.name == m.name })
        }
        assertEquals("Remove + Blur", LogoCleanMode.BOTH.label)
        assertTrue(LogoCleanMode.BOTH.verb.contains("removed") && LogoCleanMode.BOTH.verb.contains("blurred"))
    }

    // ------------------------------------------------------------------------------ the box type

    @Test
    fun boxIsKeptInsideAndTheRightWayRound() {
        val c = LogoBox(0.7f, 0.9f, 0.2f, 1.4f).coerced()
        assertTrue(c.left == 0.2f && c.right == 0.7f)
        assertTrue(c.top == 0.9f && c.bottom == 1f)
        val tiny = LogoBox(0.5f, 0.5f, 0.5f, 0.5f).coerced()
        assertTrue(tiny.width >= LogoBox.MIN_SIZE - 1e-6f && tiny.height >= LogoBox.MIN_SIZE - 1e-6f)
        val edge = LogoBox(1f, 1f, 1f, 1f).coerced()
        assertTrue(edge.left >= 0f && edge.right <= 1f && edge.width >= LogoBox.MIN_SIZE - 1e-6f)
    }

    @Test
    fun boxNearIsToleranceBased() {
        val a = LogoBox(0.2f, 0.2f, 0.4f, 0.4f)
        assertTrue(a.near(LogoBox(0.201f, 0.2f, 0.4f, 0.399f)))
        assertFalse(a.near(LogoBox(0.25f, 0.2f, 0.4f, 0.4f)))
        assertEquals(0.2f, a.width, 1e-6f)
        assertEquals(0.3f, a.shifted(0.1f, 0f).left, 1e-6f)
    }
}
