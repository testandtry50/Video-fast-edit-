package com.videoslidemaker.app.audio

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * NEW (2.19): marking a part of the ORIGINAL sound, fitting only that part, the sound-kind profiles and giving an edited
 * sound to a slot. Mirrors tools/audiomix-reference/run_beat_tests.py (where the same checks run on plain Python).
 */
class MarkAndKindTest {
    private val eps = 1e-9
    private val file = 200.0

    private fun song(id: String = "song", dur: Double = 180.0) = AudioClip(id = id, uri = "content://x/$id", name = id, sourceDurationSec = dur)
    private fun slot(start: Double = 4.0, end: Double = 20.0, dur: Double = 180.0): AudioClip =
        ClipEdit.replaceSource(BgSlots.placeholder("slot", "B1", start, end), "content://x/slot", "song.mp3", dur)

    private fun assertPair(a: Double, b: Double, p: Pair<Double, Double>) {
        assertEquals(a, p.first, 1e-6); assertEquals(b, p.second, 1e-6)
    }

    // ---- typed times ------------------------------------------------------------------------------------

    @Test fun typedTimesAreReadInEveryUsualForm() {
        assertEquals(72.0, MarkMath.parseTime("72")!!, eps)
        assertEquals(72.5, MarkMath.parseTime("72.5")!!, eps)
        assertEquals(72.0, MarkMath.parseTime("1:12")!!, eps)
        assertEquals(72.5, MarkMath.parseTime("1:12.5")!!, eps)
        assertEquals(3723.0, MarkMath.parseTime("1:02:03")!!, eps)
        // a comma is a decimal point (many keyboards have no dot on the first page); spaces and a trailing s are ignored
        assertEquals(72.5, MarkMath.parseTime("1:12,5")!!, eps)
        assertEquals(3.25, MarkMath.parseTime("3,25")!!, eps)
        assertEquals(4.5, MarkMath.parseTime("  4.5 s ")!!, eps)
        assertEquals(8.0, MarkMath.parseTime("0:08s")!!, eps)
    }

    @Test fun typingMistakesChangeNothing() {
        for (bad in listOf("", "  ", "abc", "1:", ":30", "1:2:3:4", "-5", "1.5:30", "NaN", "1:75", "1:60", "5d", "1e3", "0x10", "1.2.3")) {
            assertNull("\"$bad\" must be refused", MarkMath.parseTime(bad))
        }
    }

    // ---- moving the marks -------------------------------------------------------------------------------

    @Test fun fixOrdersAndKeepsTheMarkInsideTheFile() {
        assertPair(10.0, 50.0, MarkMath.fix(50.0, 10.0, file))
        assertPair(0.0, file, MarkMath.fix(-5.0, 999.0, file))
        val tiny = MarkMath.fix(10.0, 10.01, file)
        assertEquals(AudioLimits.MIN_CLIP_SEC, tiny.second - tiny.first, 1e-6)
        assertPair(file - AudioLimits.MIN_CLIP_SEC, file, MarkMath.fix(199.99, 200.0, file))
    }

    @Test fun movingTheStartOrTheEnd() {
        assertPair(14.0, 20.0, MarkMath.withStart(10.0, 20.0, 14.0, file))
        // past the end: the whole mark moves and keeps its length
        assertPair(50.0, 60.0, MarkMath.withStart(10.0, 20.0, 50.0, file))
        assertPair(10.0, 30.0, MarkMath.withEnd(10.0, 20.0, 30.0, file))
        assertPair(40.0, 50.0, MarkMath.withEnd(100.0, 110.0, 50.0, file))
        assertPair(0.0, 5.0, MarkMath.withEnd(10.0, 20.0, 5.0, file))
        val nearEnd = MarkMath.withStart(10.0, 20.0, 199.99, file)
        assertTrue(nearEnd.second <= file && nearEnd.second - nearEnd.first >= AudioLimits.MIN_CLIP_SEC - 1e-9)
        // not-a-number never moves a mark
        assertPair(10.0, 20.0, MarkMath.withStart(10.0, 20.0, Double.NaN, file))
        assertPair(10.0, 20.0, MarkMath.withEnd(10.0, 20.0, Double.NaN, file))
    }

    @Test fun shiftingKeepsTheLengthAndStopsAtTheFileEnds() {
        assertPair(13.0, 17.0, MarkMath.shift(10.0, 14.0, 3.0, file))
        assertPair(0.0, 4.0, MarkMath.shift(1.0, 5.0, -10.0, file))
        assertPair(196.0, 200.0, MarkMath.shift(196.0, 200.0, 10.0, file))
    }

    @Test fun aTouchMovesTheNearerMark() {
        assertTrue(MarkMath.nearestIsStart(10.0, 20.0, 12.0))
        assertFalse(MarkMath.nearestIsStart(10.0, 20.0, 18.0))
        assertTrue(MarkMath.nearestIsStart(10.0, 20.0, 15.0))   // a tie goes to the start
    }

    // ---- keep only the marked part ----------------------------------------------------------------------

    @Test fun keepOnlyTheBeat() {
        val beat = ClipEdit.keepOnly(song(), 72.0, 76.0)
        assertEquals(72.0, beat.srcStartSec, eps); assertEquals(76.0, beat.srcEndSec, eps); assertEquals(76.0, beat.markEndSec, eps)
        assertTrue(beat.hasMark && beat.usesPartOfFile)
        assertEquals(4.0, beat.lengthSec, eps)
        // a short part is a beat: it repeats exactly. A long one does not switch that on by itself.
        assertTrue(beat.exactLoop)
        assertFalse(ClipEdit.keepOnly(song(), 10.0, 60.0).exactLoop)
        assertTrue(ClipEdit.keepOnly(song().copy(exactLoop = true), 10.0, 60.0).exactLoop)
        // either order of the two ends
        assertEquals(beat, ClipEdit.keepOnly(song(), 76.0, 72.0))
    }

    @Test fun keepOnlyEdgeCases() {
        val whole = ClipEdit.keepOnly(song(), 0.0, 180.0)
        assertEquals(0.0, whole.markEndSec, eps)
        assertFalse(whole.hasMark || whole.usesPartOfFile)
        val s = song()
        assertEquals(s, ClipEdit.keepOnly(s, 5.0, 5.05))                       // shorter than the shortest clip
        val unmeasured = AudioClip("u", "content://u", "u", 0.0)
        assertEquals(unmeasured, ClipEdit.keepOnly(unmeasured, 1.0, 5.0))        // length not known yet
        val held = ClipEdit.keepOnly(s, 170.0, 999.0)                             // held inside the file
        assertEquals(170.0, held.srcStartSec, eps); assertEquals(180.0, held.srcEndSec, eps)
    }

    @Test fun theWholeOriginalComesBack() {
        val edited = ClipEdit.keepOnly(song().copy(kind = SoundKind.MUSIC, volume = 0.5f, startSec = 7.0), 10.0, 20.0)
        val back = ClipEdit.useWholeFile(edited)
        assertEquals(0.0, back.srcStartSec, eps); assertEquals(180.0, back.srcEndSec, eps); assertEquals(0.0, back.markEndSec, eps)
        assertFalse(back.usesPartOfFile)
        assertEquals(SoundKind.MUSIC, back.kind); assertEquals(0.5f, back.volume, 1e-6f); assertEquals(7.0, back.startSec, eps)
    }

    // ---- the point: only the marked part is cut or repeated ------------------------------------------------

    @Test fun aSlotRepeatsOnlyTheMarkedBeatNotTheRestOfTheSong() {
        val unmarked = ClipEdit.followRange(slot())
        assertEquals(16.0, unmarked.lengthSec, eps); assertFalse(unmarked.loop)                 // as before 2.19: the song is cut
        val marked = ClipEdit.followRange(ClipEdit.keepOnly(slot(), 72.0, 76.0))
        assertEquals(4.0, marked.lengthSec, eps); assertTrue(marked.loop)
        assertEquals(72.0, marked.srcStartSec, eps); assertEquals(76.0, marked.srcEndSec, eps)  // plays the beat, never the next 108 s
        val longer = ClipEdit.followRange(ClipEdit.keepOnly(slot(), 40.0, 100.0))               // longer than the range: cut to it
        assertEquals(16.0, longer.lengthSec, eps); assertFalse(longer.loop)
    }

    @Test fun theWholeVideoRepeatsOnlyTheMarkedBeat() {
        val vid = song().copy(fitVideo = true)
        assertEquals(60.0, ClipEdit.followVideo(vid, 60.0).lengthSec, eps)
        val shortVideo = ClipEdit.followVideo(ClipEdit.keepOnly(vid, 72.0, 76.0), 60.0)
        assertEquals(4.0, shortVideo.lengthSec, eps); assertTrue(shortVideo.loop); assertEquals(72.0, shortVideo.srcStartSec, eps)
        val longVideo = ClipEdit.followVideo(ClipEdit.keepOnly(vid, 72.0, 76.0), 300.0)
        assertEquals(4.0, longVideo.lengthSec, eps); assertTrue(longVideo.loop)                  // never runs on into the song
    }

    @Test fun anUnmarkedClipFitsExactlyAsItDidBefore() {
        val s = slot()
        assertEquals(180.0, s.materialEndSec, eps)
        assertEquals(ClipEdit.followRange(s), ClipEdit.followRange(s.copy(markEndSec = 0.0)))
        assertEquals(BgSlots.fit(s), SlotFit.Trimmed(180.0, 16.0))
    }

    @Test fun aOneShotSoundPlaysOnceInsteadOfFillingTheRange() {
        val door = ClipEdit.keepOnly(slot(), 10.0, 11.0).copy(playOnce = true)
        val c = ClipEdit.followRange(door)
        assertFalse(c.loop); assertEquals(1.0, c.lengthSec, eps)
        assertTrue(BgSlots.fit(door) is SlotFit.PlaysOnce)
        assertTrue(BgSlots.describeFit(door).contains("plays once"))
        // longer than the range it is still cut
        val long = ClipEdit.followRange(slot().copy(playOnce = true))
        assertFalse(long.loop); assertEquals(16.0, long.lengthSec, eps)
        val video = ClipEdit.followVideo(ClipEdit.keepOnly(song().copy(fitVideo = true), 10.0, 11.0).copy(playOnce = true), 60.0)
        assertFalse(video.loop); assertEquals(1.0, video.lengthSec, eps)
    }

    @Test fun theFitMessageSaysWhenItIsTheMarkedPartThatRepeats() {
        val msg = BgSlots.describeFit(ClipEdit.keepOnly(slot(), 72.0, 76.0))
        assertTrue(msg, msg.contains("marked part") && msg.contains("repeats"))
        assertTrue(BgSlots.describeFit(slot()).startsWith("File is"))                             // unchanged for an unmarked file
    }

    // ---- marks stay in step with trims, splits and cuts ----------------------------------------------------

    @Test fun trimmingTheEndMovesTheMarkedEnd() {
        val beat = ClipEdit.keepOnly(song(), 72.0, 76.0)
        val t = ClipEdit.trimEnd(beat, 75.0)
        assertEquals(75.0, t.srcEndSec, eps); assertEquals(75.0, t.markEndSec, eps)
        assertEquals(0.0, ClipEdit.trimEnd(song(), 100.0).markEndSec, eps)
    }

    @Test fun splittingAMarkedClipKeepsEachHalfsMark() {
        val halves = ClipEdit.split(ClipEdit.keepOnly(song(), 70.0, 90.0), 5.0, "b")
        assertEquals(75.0, halves[0].srcEndSec, eps); assertEquals(75.0, halves[0].markEndSec, eps)
        assertEquals(75.0, halves[1].srcStartSec, eps); assertEquals(90.0, halves[1].markEndSec, eps)
        assertTrue(ClipEdit.split(song(), 50.0, "b").all { it.markEndSec == 0.0 })
    }

    @Test fun cuttingAPartOutOfAMarkedClip() {
        val marked = ClipEdit.keepOnly(song(), 70.0, 90.0)
        val r = ClipEdit.cutInTrack(listOf(marked), marked.id, 5.0, 10.0, true, "x")
        assertEquals(2, r.size)
        assertEquals(75.0, r[0].srcEndSec, eps); assertEquals(75.0, r[0].markEndSec, eps)
        assertEquals(80.0, r[1].srcStartSec, eps); assertEquals(90.0, r[1].markEndSec, eps)
    }

    @Test fun choosingAnotherFileClearsTheMark() {
        val c = ClipEdit.replaceSource(ClipEdit.keepOnly(song(), 72.0, 76.0), "content://new", "new.mp3", 30.0)
        assertEquals(0.0, c.markEndSec, eps); assertEquals(0.0, c.srcStartSec, eps); assertEquals(30.0, c.srcEndSec, eps)
    }

    // ---- assigning an edited sound to B1 -------------------------------------------------------------------

    @Test fun anEditedSoundMovesIntoTheSlot() {
        val src = ClipEdit.keepOnly(song("music").copy(fitVideo = true, fadeInSec = 1.0, kind = SoundKind.MUSIC, volume = 0.8f), 72.0, 76.0)
        val b1 = BgSlots.placeholder("slot1", "B1", 4.0, 20.0)
        val filled = ClipEdit.assignToSlot(src, b1)
        assertEquals("slot1", filled.id); assertEquals("B1", filled.slot)
        assertEquals(4.0, filled.startSec, eps); assertEquals(20.0, filled.rangeEndSec, eps)
        assertEquals("content://x/music", filled.uri); assertEquals(76.0, filled.markEndSec, eps)
        assertEquals(0.8f, filled.volume, 1e-6f); assertEquals(SoundKind.MUSIC, filled.kind)
        assertFalse(filled.fitVideo || filled.loop || filled.isPlaceholder)
        assertEquals(1.0, filled.fadeInSec, eps); assertEquals(BgSlots.DEFAULT_FADE_SEC, filled.fadeOutSec, eps)
        val played = ClipEdit.followRange(filled)
        assertEquals(4.0, played.lengthSec, eps); assertTrue(played.loop)
        // a one-shot sound keeps its own tiny fades
        val door = song("door", 3.0).copy(playOnce = true, fadeInSec = 0.02, fadeOutSec = 0.05)
        val d = ClipEdit.assignToSlot(door, b1)
        assertEquals(0.02, d.fadeInSec, eps); assertEquals(0.05, d.fadeOutSec, eps)
    }

    // ---- kinds and profiles --------------------------------------------------------------------------------

    private val effects = SoundKind.values().filter { it.isEffect }
    private val beds = SoundKind.values().filter { it != SoundKind.UNSET && !it.isEffect }

    @Test fun everyEffectPlaysOnceAndIsHeardOverTheVoice() {
        assertEquals(5, effects.size)
        for (k in effects) {
            val p = SoundProfiles.profile(k, SoundMood.NONE)
            assertTrue(k.name, p.playOnce && !p.duck)
            assertTrue(k.name, p.levelDb!! >= -6.0)
        }
    }

    @Test fun bedsAndMusicAreLoweredUnderTheVoiceAndNeverPlayOnce() {
        for (k in beds) for (m in SoundMood.values()) {
            val p = SoundProfiles.profile(k, m)
            assertTrue("$k $m", p.duck && !p.playOnce)
        }
    }

    @Test fun theTableMakesSense() {
        val crowd = SoundProfiles.profile(SoundKind.CROWD, SoundMood.NONE)
        val amb = SoundProfiles.profile(SoundKind.AMBIENCE, SoundMood.NONE)
        assertTrue(crowd.levelDb!! < amb.levelDb!! && crowd.duckAdjustDb < 0.0)                 // voices sit lowest and step aside most
        assertTrue(amb.duckAdjustDb > 0.0 && SoundProfiles.profile(SoundKind.NATURE, SoundMood.NONE).duckAdjustDb > 0.0)   // steady beds barely pump
        val action = SoundProfiles.profile(SoundKind.MUSIC, SoundMood.ACTION)
        val calm = SoundProfiles.profile(SoundKind.MUSIC, SoundMood.CALM)
        assertTrue(action.levelDb!! > calm.levelDb!! && calm.duckAdjustDb < action.duckAdjustDb)
        assertTrue(SoundProfiles.profile(SoundKind.MUSIC, SoundMood.EMOTIONAL).duckAdjustDb < 0.0)
        val plain = SoundProfiles.profile(SoundKind.MUSIC, SoundMood.NONE)
        assertNull(plain.levelDb); assertEquals(0.0, plain.duckAdjustDb, eps)                   // no feeling = the smart mix's standard
        for (m in SoundMood.values()) {
            val diff = SoundProfiles.profile(SoundKind.INSTRUMENTAL, m).levelDb
            if (m != SoundMood.NONE) assertEquals(SoundProfiles.profile(SoundKind.MUSIC, m).levelDb!! + 1.0, diff!!, eps)
        }
        assertEquals(SoundProfiles.STANDARD_BED_DB + 1.0, SoundProfiles.profile(SoundKind.INSTRUMENTAL, SoundMood.NONE).levelDb!!, eps)
        assertEquals(SmartMix.bedOffsetDb(true), SoundProfiles.STANDARD_BED_DB, eps)
        for (k in SoundKind.values()) for (m in SoundMood.values()) {
            val p = SoundProfiles.profile(k, m)
            assertTrue("$k $m", (p.levelDb == null || (p.levelDb!! >= -30.0 && p.levelDb!! <= 0.0)) && p.duckAdjustDb in -24.0..24.0 && p.fadeInSec >= 0.0 && p.fadeOutSec >= 0.0)
        }
    }

    @Test fun aBeatRepeatsExactly() {
        val b = SoundProfiles.profile(SoundKind.BEAT, SoundMood.NONE)
        assertTrue(b.exactLoop && b.fadeInSec < SoundProfiles.profile(SoundKind.MUSIC, SoundMood.NONE).fadeInSec)
    }

    @Test fun applyingAKindSetsTheMixingChoices() {
        val c = song().copy(fitVideo = true, volume = 0.7f)
        val a = SoundProfiles.apply(c, SoundKind.MUSIC, SoundMood.ACTION)
        assertEquals(SoundKind.MUSIC, a.kind); assertEquals(SoundMood.ACTION, a.mood)
        assertTrue(a.autoDuck); assertEquals(-7.0, a.levelDb!!, eps); assertEquals(3.0, a.duckAdjustDb, eps)
        // volume, marked part and place are left alone
        assertEquals(0.7f, a.volume, 1e-6f); assertTrue(a.fitVideo)
        // a mood is dropped for a kind that has none
        assertEquals(SoundMood.NONE, SoundProfiles.apply(c, SoundKind.AMBIENCE, SoundMood.ACTION).mood)
        // an effect stops covering the whole video and plays once
        val d = SoundProfiles.apply(c, SoundKind.SFX_IMPACT, SoundMood.NONE)
        assertTrue(d.playOnce && !d.fitVideo && !d.loop && !d.autoDuck)
        // a beat turns exact repeat on; an exact repeat the user chose is kept
        assertTrue(SoundProfiles.apply(c, SoundKind.BEAT, SoundMood.NONE).exactLoop)
        assertTrue(SoundProfiles.apply(c.copy(exactLoop = true), SoundKind.MUSIC, SoundMood.NONE).exactLoop)
        assertFalse(SoundProfiles.apply(c, SoundKind.MUSIC, SoundMood.NONE).exactLoop)
    }

    @Test fun fadesLeaveRoomInAShortRange() {
        val tiny = SoundProfiles.apply(slot(5.0, 6.0), SoundKind.AMBIENCE, SoundMood.NONE)
        assertEquals(0.25, tiny.fadeInSec, eps); assertEquals(0.25, tiny.fadeOutSec, eps)
        val roomy = SoundProfiles.apply(slot(5.0, 30.0), SoundKind.MUSIC, SoundMood.NONE)
        assertEquals(1.0, roomy.fadeInSec, eps); assertEquals(1.5, roomy.fadeOutSec, eps)
    }

    @Test fun theTagAndTheDescriptionAreReadable() {
        assertEquals("", SoundProfiles.tag(song()))
        assertEquals("Background music", SoundProfiles.tag(song().copy(kind = SoundKind.MUSIC)))
        assertEquals("Background music · Action", SoundProfiles.tag(song().copy(kind = SoundKind.MUSIC, mood = SoundMood.ACTION)))
        val d = SoundProfiles.describe(SoundKind.SFX_OBJECT, SoundMood.NONE)
        assertTrue(d, d.contains("not lowered") && d.contains("once"))
        assertTrue(SoundProfiles.describe(SoundKind.CROWD, SoundMood.NONE).contains("steps well aside"))
        assertTrue(SoundProfiles.describe(SoundKind.BEAT, SoundMood.NONE).contains("exactly"))
        assertEquals(12, SoundKind.choices.size)
        assertFalse(SoundKind.choices.contains(SoundKind.UNSET))
    }

    @Test fun savedNamesComeBackAndUnknownOnesAreHarmless() {
        for (k in SoundKind.values()) assertEquals(k, SoundKind.fromName(k.name))
        for (m in SoundMood.values()) assertEquals(m, SoundMood.fromName(m.name))
        assertEquals(SoundKind.UNSET, SoundKind.fromName("FROM_THE_FUTURE")); assertEquals(SoundKind.UNSET, SoundKind.fromName(null))
        assertEquals(SoundMood.NONE, SoundMood.fromName("")); assertEquals(SoundMood.NONE, SoundMood.fromName(null))
    }

    // ---- the exact repeat's smoothing ----------------------------------------------------------------------

    @Test fun theJoinFadeRisesSmoothlyFromNearZeroToOne() {
        val n = 24L
        assertTrue(SmartMix.declickWeight(0L, n) < 0.01f)
        assertTrue(SmartMix.declickWeight(23L, n) > 0.99f)
        for (i in 0 until 23) assertTrue(SmartMix.declickWeight(i.toLong(), n) <= SmartMix.declickWeight(i + 1L, n) + 1e-6f)
        assertEquals(1f, SmartMix.declickWeight(24L, n), 0f)
        assertEquals(1f, SmartMix.declickWeight(5L, 0L), 0f)
        assertTrue(AudioLimits.DECLICK_SEC <= 0.005)
    }

    @Test fun markedPartsNeverTouchOtherClipsFields() {
        val c = ClipEdit.keepOnly(song(), 72.0, 76.0)
        assertNotNull(c.uri); assertEquals("content://x/song", c.uri); assertEquals(180.0, c.sourceDurationSec, eps)
    }
}
