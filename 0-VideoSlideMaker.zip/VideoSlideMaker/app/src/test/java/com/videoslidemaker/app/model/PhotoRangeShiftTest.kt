package com.videoslidemaker.app.model

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * The Match screen's "Move a series of photos" rule: everything between a start and an end sentence - photos AND empty
 * sentences - slides by one sentence, and the photos outside the series stay where they are.
 */
class PhotoRangeShiftTest {

    private fun photos(vararg ids: String?): List<String?> = ids.toList()

    // ---------- forward ----------

    @Test
    fun forwardSlidesPhotosAndGapsTogetherAndTheLastPhotoLandsJustAfterTheSeries() {
        // A, a gap, then B C D: the whole series goes one sentence on - the gap moves with it
        val r = PhotoRangeShift.plan(photos("A", null, "B", "C", "D", null), start = 0, end = 4, forward = true)!!
        assertEquals(photos(null, "A", null, "B", "C", "D"), r.assignments)
        assertEquals(4, r.movedPhotos)
        assertEquals(0, r.emptySentence)
        assertEquals(5, r.spilledTo)
        assertNull(r.lostPhotoId)
        assertEquals(1, r.newStart)
        assertEquals(5, r.newEnd)
    }

    @Test
    fun movingForwardAgainCarriesTheSamePhotosOneMoreSentence() {
        val first = PhotoRangeShift.plan(photos("A", null, "B", "C", "D", null), 0, 4, true)!!
        val again = PhotoRangeShift.plan(first.assignments, first.newStart, first.newEnd, true)!!
        // D has no sentence left now: it is the only thing lost, A B C moved on
        assertEquals(photos(null, null, "A", null, "B", "C"), again.assignments)
        assertEquals("D", again.lostPhotoId)
        assertEquals(5, again.lostSentence)
        assertTrue(again.lostFellOffTimeline)
        assertEquals(3, again.movedPhotos)
        assertEquals(2, again.newStart)
        assertEquals(5, again.newEnd)
    }

    @Test
    fun forwardCoversThePhotoRightAfterTheSeries() {
        val r = PhotoRangeShift.plan(photos("A", "B", "X", "Y"), 0, 1, true)!!
        assertEquals(photos(null, "A", "B", "Y"), r.assignments)
        assertEquals("X", r.lostPhotoId)
        assertEquals(2, r.lostSentence)
        assertFalse(r.lostFellOffTimeline)
        assertNotNull(r.warning())
    }

    @Test
    fun forwardOnASeriesThatEndsOnAGapNeverCoversThePhotoAfterIt() {
        val r = PhotoRangeShift.plan(photos("A", null, "B"), 0, 1, true)!!
        assertEquals(photos(null, "A", "B"), r.assignments)
        assertNull(r.spilledTo)
        assertNull(r.lostPhotoId)
        assertEquals(1, r.movedPhotos)
        assertEquals(1, r.newStart)
        assertEquals(1, r.newEnd)
    }

    @Test
    fun aPhotoThatIsCoveredButUsedOnAnotherSentenceIsNotLost() {
        val r = PhotoRangeShift.plan(photos("A", "B", "B"), 0, 0, true)!!
        assertEquals(photos(null, "A", "B"), r.assignments)
        assertNull(r.lostPhotoId)
    }

    @Test
    fun photosOutsideTheSeriesStayExactlyWhereTheyAre() {
        val r = PhotoRangeShift.plan(photos("P", "Q", "R", null, "A", "B", null, "C", "S", "T"), 4, 7, true)!!
        assertEquals(photos("P", "Q", "R", null, null, "A", "B", null, "C", "T"), r.assignments)
        assertEquals("S", r.lostPhotoId)
    }

    @Test
    fun aSingleSentenceSeriesMovesItsPhotoOneSentenceOn() {
        val r = PhotoRangeShift.plan(photos("A", null), 0, 0, true)!!
        assertEquals(photos(null, "A"), r.assignments)
        assertEquals(1, r.newStart)
        assertEquals(1, r.newEnd)
    }

    @Test
    fun forwardOffTheLastSentenceClearsTheSelectionBecauseNothingOfItIsLeft() {
        val r = PhotoRangeShift.plan(photos(null, "A"), 1, 1, true)!!
        assertEquals(photos(null, null), r.assignments)
        assertEquals("A", r.lostPhotoId)
        assertEquals(-1, r.newStart)
        assertEquals(-1, r.newEnd)
        assertEquals(0, r.movedPhotos)
        assertTrue(r.message().startsWith("No photo could move forward."))
    }

    // ---------- back ----------

    @Test
    fun backSlidesPhotosAndGapsTogetherAndTheFirstPhotoLandsJustBeforeTheSeries() {
        val r = PhotoRangeShift.plan(photos(null, "A", null, "B", "C", "D"), start = 1, end = 5, forward = false)!!
        assertEquals(photos("A", null, "B", "C", "D", null), r.assignments)
        assertEquals(4, r.movedPhotos)
        assertEquals(5, r.emptySentence)
        assertEquals(0, r.spilledTo)
        assertNull(r.lostPhotoId)
        assertEquals(0, r.newStart)
        assertEquals(4, r.newEnd)
    }

    @Test
    fun backCoversThePhotoRightBeforeTheSeries() {
        val r = PhotoRangeShift.plan(photos("X", "A", "B"), 1, 2, false)!!
        assertEquals(photos("A", "B", null), r.assignments)
        assertEquals("X", r.lostPhotoId)
        assertEquals(0, r.lostSentence)
        assertFalse(r.lostFellOffTimeline)
    }

    @Test
    fun backOffTheFirstSentenceDropsThatPhotoFromTheTimeline() {
        val r = PhotoRangeShift.plan(photos("A", "B", "C"), 0, 2, false)!!
        assertEquals(photos("B", "C", null), r.assignments)
        assertEquals("A", r.lostPhotoId)
        assertTrue(r.lostFellOffTimeline)
        assertEquals(2, r.movedPhotos)
        assertEquals(0, r.newStart)
        assertEquals(1, r.newEnd)
    }

    @Test
    fun backOnASeriesThatStartsOnAGapNeverCoversThePhotoBeforeIt() {
        val r = PhotoRangeShift.plan(photos("X", null, "A", "B"), 1, 3, false)!!
        assertEquals(photos("X", "A", "B", null), r.assignments)
        assertNull(r.spilledTo)
        assertNull(r.lostPhotoId)
        assertEquals(2, r.movedPhotos)
    }

    @Test
    fun movingForwardThenBackPutsEverythingBackWhenNothingWasCovered() {
        val original = photos("A", null, "B", "C", "D", null)
        val fwd = PhotoRangeShift.plan(original, 0, 4, true)!!
        val back = PhotoRangeShift.plan(fwd.assignments, fwd.newStart, fwd.newEnd, false)!!
        assertEquals(original, back.assignments)
    }

    // ---------- when it cannot be done ----------

    @Test
    fun aSeriesWithoutAnyPhotoCannotBeMoved() {
        assertFalse(PhotoRangeShift.canShift(photos(null, null, "A"), 0, 1))
        assertNull(PhotoRangeShift.plan(photos(null, null, "A"), 0, 1, true))
    }

    @Test
    fun anInvalidSeriesCannotBeMoved() {
        assertFalse(PhotoRangeShift.canShift(photos("A"), 1, 0))   // start after end
        assertFalse(PhotoRangeShift.canShift(photos("A"), 0, 1))   // end past the last sentence
        assertFalse(PhotoRangeShift.canShift(photos("A"), -1, 0))  // start before the first
        assertTrue(PhotoRangeShift.canShift(photos(null, "A"), 0, 1))
    }

    @Test
    fun theMessageTellsWhatHappened() {
        val r = PhotoRangeShift.plan(photos("A", null, "B", "C", "D", null), 0, 4, true)!!
        val text = r.message()
        assertTrue(text.contains("4 photos moved one sentence forward"))
        assertTrue(text.contains("Sentence 1 is now empty"))
        assertTrue(text.contains("sentence 6"))
    }
}
