package com.videoslidemaker.app.model

import org.junit.Assert.assertEquals
import org.junit.Test

/** "Select multiple photos -> Apply to sentences": the selected photos go on the sentences one by one, in order. */
class MultiPhotoApplyTest {

    private fun times(n: Int) = List(n) { it * 3.0 }
    private fun none(n: Int): List<String?> = List(n) { null }
    private fun ids(n: Int) = List(n) { "p${it + 1}" }

    @Test
    fun exactlyAsManyPhotosAsSentences() {
        val r = MultiPhotoApply.plan(times(500), none(500), ids(500), 0)
        assertEquals(500, r.applied)
        assertEquals(0, r.extraPhotos)
        assertEquals("p1", r.assignments.first())
        assertEquals("p500", r.assignments.last())
    }

    @Test
    fun morePhotosThanSentencesLeavesTheExtraUnused() {
        val r = MultiPhotoApply.plan(times(3), none(3), ids(5), 0)
        assertEquals(listOf<String?>("p1", "p2", "p3"), r.assignments)
        assertEquals(2, r.extraPhotos)
    }

    @Test
    fun fewerPhotosThanSentencesKeepsTheRestAsItWas() {
        val current = listOf<String?>("x1", "x2", "x3", "x4")
        val r = MultiPhotoApply.plan(times(4), current, ids(2), 0)
        assertEquals(listOf<String?>("p1", "p2", "x3", "x4"), r.assignments)
        assertEquals(2, r.replaced)
    }

    @Test
    fun startsOnTheGivenSentence() {
        val r = MultiPhotoApply.plan(times(5), none(5), ids(2), 2)
        assertEquals(listOf<String?>(null, null, "p1", "p2", null), r.assignments)
        assertEquals(3, r.firstSentence)
        assertEquals(4, r.lastSentence)
    }

    @Test
    fun startNearTheEndDropsWhatDoesNotFit() {
        val r = MultiPhotoApply.plan(times(4), none(4), ids(5), 3)
        assertEquals(listOf<String?>(null, null, null, "p1"), r.assignments)
        assertEquals(4, r.extraPhotos)
    }

    @Test
    fun followsTimeOrderEvenIfTheListIsNotSorted() {
        // list order 6s, 0s, 3s; start on the 0s sentence (index 1)
        val r = MultiPhotoApply.plan(listOf(6.0, 0.0, 3.0), none(3), ids(3), 1)
        assertEquals(listOf<String?>("p3", "p1", "p2"), r.assignments)
    }

    @Test
    fun samePhotoAlreadyThereIsNotAChange() {
        val r = MultiPhotoApply.plan(times(2), listOf("p1", "p2"), ids(2), 0)
        assertEquals(0, r.changed)
        assertEquals(0, r.replaced)
    }

    @Test
    fun nothingSelectedChangesNothing() {
        val r = MultiPhotoApply.plan(times(3), listOf("a", null, "b"), emptyList(), 0)
        assertEquals(listOf<String?>("a", null, "b"), r.assignments)
        assertEquals(0, r.applied)
    }

    @Test
    fun noSentencesIsSafe() {
        val r = MultiPhotoApply.plan(emptyList(), emptyList(), ids(2), 0)
        assertEquals(0, r.applied)
    }
}
