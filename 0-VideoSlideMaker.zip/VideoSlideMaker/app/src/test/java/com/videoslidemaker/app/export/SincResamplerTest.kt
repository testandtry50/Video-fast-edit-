package com.videoslidemaker.app.export

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * The sample-rate converter must not leave a "mirror image" of the voice above the source's own Nyquist frequency:
 * the voice changer moves the sound around, and any image that was left there would slide down into the audible range
 * as a fuzzy hiss. The numbers asserted here were measured with tools/voicefx-reference/resample_check.py
 * (new filter: image about 107 dB below the tone; the old straight-line interpolation: about 8 dB).
 */
class SincResamplerTest {

    private fun tonePcm(rate: Int, seconds: Double, freq: Double, amp: Double): ByteArray {
        val n = (rate * seconds).toInt()
        val b = ByteArray(n * 2)
        for (i in 0 until n) {
            val v = (amp * 32767.0 * sin(2.0 * PI * freq * i / rate)).roundToInt()
            b[i * 2] = (v and 0xFF).toByte()
            b[i * 2 + 1] = ((v shr 8) and 0xFF).toByte()
        }
        return b
    }

    private fun toShorts(b: ByteArray): ShortArray =
        ShortArray(b.size / 2) { (((b[it * 2 + 1].toInt()) shl 8) or (b[it * 2].toInt() and 0xFF)).toShort() }

    /** Amplitude of the component at [f] Hz (Hann-windowed, so a loud tone does not leak into far-away frequencies). */
    private fun amplitudeAt(x: ShortArray, from: Int, count: Int, fs: Int, f: Double): Double {
        var re = 0.0
        var im = 0.0
        var wSum = 0.0
        for (i in 0 until count) {
            val w = 0.5 - 0.5 * cos(2.0 * PI * i / count)
            val a = 2.0 * PI * f * i / fs
            val v = x[from + i].toDouble() * w
            re += v * cos(a)
            im -= v * sin(a)
            wSum += w
        }
        return sqrt(re * re + im * im) / wSum * 2.0
    }

    @Test fun theMirrorImageOfAHighToneIsGone() {
        // 8 kHz at 22.05 kHz: its mirror image lands at 14.05 kHz in the 44.1 kHz result.
        val out = toShorts(PcmResampler.convert(tonePcm(22050, 1.0, 8000.0, 0.5), 22050, 1, 44100, 1))
        val tone = amplitudeAt(out, 4000, 32768, 44100, 8000.0)
        val image = amplitudeAt(out, 4000, 32768, 44100, 14050.0)
        assertTrue("the tone itself must survive (amplitude $tone)", tone > 0.45 * 32767.0)
        val db = 20.0 * log10(max(image, 1e-9) / tone)
        assertTrue("image is only ${"%.1f".format(-db)} dB below the tone (needs 80)", db < -80.0)
    }

    @Test fun levelAndLengthAreKeptForCommonPhoneRates() {
        for (rate in listOf(16000, 22050, 24000, 48000)) {
            val src = tonePcm(rate, 1.0, 1000.0, 0.5)
            val out = toShorts(PcmResampler.convert(src, rate, 1, 44100, 1))
            assertEquals("length from $rate Hz", 44100, out.size)
            val amp = amplitudeAt(out, 3000, 20000, 44100, 1000.0)
            val change = 20.0 * log10(amp / (0.5 * 32767.0))
            assertTrue("level changed by $change dB from $rate Hz", abs(change) < 0.1)
        }
    }

    @Test fun sameRateStaysThePlainSound() {
        val src = tonePcm(44100, 0.2, 440.0, 0.6)
        val out = toShorts(PcmResampler.convert(src, 44100, 1, 44100, 1))
        val ref = toShorts(src)
        assertEquals(ref.size, out.size)
        for (i in ref.indices) assertTrue("sample $i", abs(ref[i] - out[i]) <= 1)
    }

    @Test fun streamingInOddPiecesMatchesTheWholeClip() {
        val rate = 24000
        val noise = ByteArray(30000 * 2)
        var s = 12345
        for (i in 0 until 30000) {
            s = s * 1103515245 + 12345
            val v = ((s shr 16) and 0x7FFF) / 32768.0 - 0.5
            val q = (v * 6000.0).roundToInt()
            noise[i * 2] = (q and 0xFF).toByte()
            noise[i * 2 + 1] = ((q shr 8) and 0xFF).toByte()
        }
        val whole = toShorts(PcmResampler.convert(noise, rate, 1, 44100, 1))

        val conv = StreamingPcmConverter(rate, 1, 44100, 1)
        val sizes = intArrayOf(14, 2000, 72, 16384, 2, 10000)
        var pieces = ByteArray(0)
        var pos = 0
        var k = 0
        while (pos < noise.size) {
            val n = minOf(sizes[k % sizes.size], noise.size - pos)
            pieces += conv.convert(noise.copyOfRange(pos, pos + n))
            pos += n
            k++
        }
        val streamed = toShorts(pieces)

        // the stream does not look past the last input sample, so it stops a few dozen frames short of the whole clip
        val missing = whole.size - streamed.size
        assertTrue("streamed is $missing frames shorter", missing in 0..120)
        for (i in streamed.indices) assertTrue("frame $i differs", abs(streamed[i] - whole[i]) <= 2)
    }

    @Test fun channelsAreMappedWithoutChangingTheRate() {
        // mono -> stereo copies, stereo -> mono averages; at the same rate nothing else may happen to the sound.
        val mono = ByteArray(4)
        mono[0] = (1000 and 0xFF).toByte(); mono[1] = ((1000 shr 8) and 0xFF).toByte()
        val m = (-2000)
        mono[2] = (m and 0xFF).toByte(); mono[3] = ((m shr 8) and 0xFF).toByte()
        val stereo = toShorts(StreamingPcmConverter(44100, 1, 44100, 2).convert(mono))
        assertEquals(listOf<Short>(1000, 1000, -2000, -2000), stereo.toList())

        val lr = ByteArray(4)
        lr[0] = (1000 and 0xFF).toByte(); lr[1] = ((1000 shr 8) and 0xFF).toByte()
        lr[2] = (3000 and 0xFF).toByte(); lr[3] = ((3000 shr 8) and 0xFF).toByte()
        val down = toShorts(StreamingPcmConverter(44100, 2, 44100, 1).convert(lr))
        assertEquals(listOf<Short>(2000), down.toList())
    }
}
