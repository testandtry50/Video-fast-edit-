package com.videoslidemaker.app.model

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * The Match screen's "Move photos along" rule: a photo and the photos right after it move one sentence forward or back.
 * The group stops at the first empty sentence; photos beyond it are not touched.
 */
class PhotoShiftTest {

    private fun photos(vararg ids: String?): List<String?> = ids.toList()

    // ---------- forward ----------

    @Test
    fun forwardIntoTheEmptyNextSentenceMovesOnlyThatPhoto() {
        // A moves on; C and D are already placed, so they do not go anywhere
        val r = PhotoShift.plan(photos("A", null, "C", "D"), index = 0, forward = true)!!
        assertEquals(photos(null, "A", "C", "D"), r.assignments)
        assertEquals(1, r.movedPhotos)
        assertNull(r.lostPhotoId)
        assertEquals(0, r.emptySentence)
        assertEquals(1, r.stoppedAt)
    }

    @Test
    fun movingForwardAgainCarriesTheWholeGroupThatNowStandsTogether() {
        // after the move above, A has C and D right behind it: all three move on, and D has no sentence left
        val r = PhotoShift.plan(photos(null, "A", "C", "D"), index = 1, forward = true)!!
        assertEquals(photos(null, null, "A", "C"), r.assignments)
        assertEquals(2, r.movedPhotos)
        assertEquals("D", r.lostPhotoId)
        assertEquals(3, r.lostSentence)
        assertNull(r.stoppedAt)
    }

    @Test
    fun forwardStopsAtTheFirstEmptySentenceAndLeavesEverythingAfterItAlone() {
        val r = PhotoShift.plan(photos("A", "B", "C", null, "E", "F"), index = 1, forward = true)!!
        assertEquals(photos("A", null, "B", "C", "E", "F"), r.assignments)
        assertEquals(2, r.movedPhotos)          // B, C
        assertNull(r.lostPhotoId)
        assertEquals(3, r.stoppedAt)
        assertEquals(1, r.emptySentence)
    }

    @Test
    fun forwardWithTheLastSentenceEmptyUsesItUpAndLosesNothing() {
        val r = PhotoShift.plan(photos("A", "B", "C", "D", null), index = 1, forward = true)!!
        assertEquals(photos("A", null, "B", "C", "D"), r.assignments)
        assertEquals(3, r.movedPhotos)          // B, C, D
        assertNull(r.lostPhotoId)
        assertEquals(4, r.stoppedAt)
    }

    @Test
    fun forwardPushesTheLastPhotoOffTheTimelineWhenNoSentenceIsEmpty() {
        val r = PhotoShift.plan(photos("A", "B", "C"), index = 0, forward = true)!!
        assertEquals(photos(null, "A", "B"), r.assignments)
        assertEquals(2, r.movedPhotos)
        assertEquals("C", r.lostPhotoId)
        assertEquals(2, r.lostSentence)
    }

    @Test
    fun forwardKeepsEarlierPhotosExactlyWhereTheyWere() {
        val r = PhotoShift.plan(photos("A", "B", "C", "D"), index = 2, forward = true)!!
        assertEquals(photos("A", "B", null, "C"), r.assignments)
    }

    @Test
    fun forwardIsNotPossibleOnTheLastSentence() {
        val cur = photos("A", "B", "C")
        assertFalse(PhotoShift.canShift(cur, 2, forward = true))
        assertNull(PhotoShift.plan(cur, 2, forward = true))
    }

    @Test
    fun forwardNeedsAPhotoOnThisSentence() {
        val cur = photos("A", null, "C")
        assertFalse(PhotoShift.canShift(cur, 1, forward = true))
        assertNull(PhotoShift.plan(cur, 1, forward = true))
        assertTrue(PhotoShift.canShift(cur, 0, forward = true))
    }

    // ---------- back ----------

    @Test
    fun backMovesThisPhotoIntoThePreviousSentenceAndTheGroupFollows() {
        val r = PhotoShift.plan(photos("A", "B", "C", "D"), index = 2, forward = false)!!
        // C covers B, D follows, the last sentence is left empty
        assertEquals(photos("A", "C", "D", null), r.assignments)
        assertEquals(2, r.movedPhotos)          // C, D
        assertEquals("B", r.lostPhotoId)
        assertEquals(1, r.lostSentence)
        assertEquals(3, r.emptySentence)
        assertFalse(r.closedGap)
    }

    @Test
    fun backStopsAtTheFirstEmptySentenceAndLeavesEverythingAfterItAlone() {
        val r = PhotoShift.plan(photos("A", "B", "C", "D", null, "F"), index = 2, forward = false)!!
        assertEquals(photos("A", "C", "D", null, null, "F"), r.assignments)
        assertEquals(2, r.movedPhotos)          // C, D
        assertEquals("B", r.lostPhotoId)
        assertEquals(3, r.emptySentence)
    }

    @Test
    fun backIntoAnEmptyPreviousSentenceCoversNothing() {
        val r = PhotoShift.plan(photos("A", null, "C", "D", null, "F"), index = 2, forward = false)!!
        assertEquals(photos("A", "C", "D", null, null, "F"), r.assignments)
        assertNull(r.lostPhotoId)
    }

    @Test
    fun backIsNotPossibleOnTheFirstSentence() {
        val cur = photos("A", "B")
        assertFalse(PhotoShift.canShift(cur, 0, forward = false))
        assertNull(PhotoShift.plan(cur, 0, forward = false))
    }

    @Test
    fun backOnAnEmptySentencePullsTheGroupAfterItBackOverTheGap() {
        val r = PhotoShift.plan(photos("A", "B", null, "C", "D", null, "F"), index = 2, forward = false)!!
        assertEquals(photos("A", "B", "C", "D", null, null, "F"), r.assignments)
        assertTrue(r.closedGap)
        assertEquals(2, r.movedPhotos)          // C, D
        assertNull(r.lostPhotoId)
        assertEquals(4, r.emptySentence)
    }

    @Test
    fun backOnAnEmptyFirstSentenceStillClosesTheGap() {
        val r = PhotoShift.plan(photos(null, "A", "B"), index = 0, forward = false)!!
        assertEquals(photos("A", "B", null), r.assignments)
        assertTrue(r.closedGap)
    }

    @Test
    fun backOnAnEmptySentenceWithNoPhotoRightAfterItIsNotPossible() {
        assertFalse(PhotoShift.canShift(photos("A", null, null), 1, forward = false))
        assertNull(PhotoShift.plan(photos("A", null, null), 1, forward = false))
        assertFalse(PhotoShift.canShift(photos("A", null), 1, forward = false))
    }

    // ---------- both ----------

    @Test
    fun aPhotoStillUsedElsewhereIsNotCountedAsLost() {
        // B also sits on the last sentence, so covering the first B takes nothing off the timeline
        val r = PhotoShift.plan(photos("A", "B", "C", "B"), index = 2, forward = false)!!
        assertEquals(photos("A", "C", "B", null), r.assignments)
        assertNull(r.lostPhotoId)
    }

    @Test
    fun theListKeepsItsLengthWhateverIsPressed() {
        val lists = listOf(
            photos("A", "B", "C", "D", "E", "F"),
            photos("A", null, "C", null, "E", "F"),
            photos(null, null, "C", "D", null, null)
        )
        for (cur in lists) {
            for (i in cur.indices) {
                for (forward in listOf(true, false)) {
                    val r = PhotoShift.plan(cur, i, forward) ?: continue
                    assertEquals(cur.size, r.assignments.size)
                    // nothing before the current sentence changes when going forward; nothing before the previous one when going back
                    val untouched = if (forward) i else i - 1
                    for (k in 0 until untouched.coerceAtLeast(0)) assertEquals(cur[k], r.assignments[k])
                }
            }
        }
    }

    @Test
    fun aBigListShiftsInOneGoAndEverySentenceBeforeTheCurrentOneIsUntouched() {
        val cur: List<String?> = List(490) { "p${it + 1}" }
        val r = PhotoShift.plan(cur, index = 52, forward = true)!!          // sentence 53
        for (i in 0 until 52) assertEquals(cur[i], r.assignments[i])
        assertNull(r.assignments[52])
        for (i in 53 until 490) assertEquals(cur[i - 1], r.assignments[i])
        assertEquals("p490", r.lostPhotoId)
        assertEquals(489 - 52, r.movedPhotos)
    }

    @Test
    fun aBigListWithOneEmptySentenceOnlyMovesTheGroupBeforeIt() {
        val cur: List<String?> = List(490) { if (it == 100) null else "p${it + 1}" }
        val r = PhotoShift.plan(cur, index = 52, forward = true)!!
        for (i in 0 until 52) assertEquals(cur[i], r.assignments[i])
        assertNull(r.assignments[52])
        for (i in 53..100) assertEquals(cur[i - 1], r.assignments[i])       // the group, the empty sentence 101 took it up
        for (i in 101 until 490) assertEquals(cur[i], r.assignments[i])     // everything after it stayed
        assertNull(r.lostPhotoId)
        assertEquals(100, r.stoppedAt)
        assertEquals(100 - 52, r.movedPhotos)
    }

    @Test
    fun messagesAreShortAndSayWhatHappened() {
        val fwd = PhotoShift.plan(photos("A", "B", "C"), 0, forward = true)!!
        assertTrue(fwd.message().contains("2 photos moved one sentence forward"))
        assertTrue(fwd.message().contains("Sentence 1 is now empty"))
        assertTrue(fwd.message().contains("still in your photo list"))

        val stop = PhotoShift.plan(photos("A", null, "C"), 0, forward = true)!!
        assertTrue(stop.message().contains("1 photo moved one sentence forward"))
        assertTrue(stop.message().contains("stopped at sentence 2"))

        val back = PhotoShift.plan(photos("A", "B", "C"), 1, forward = false)!!
        assertTrue(back.message().contains("2 photos moved one sentence back"))
        assertTrue(back.message().contains("Sentence 3 is now empty"))

        val gap = PhotoShift.plan(photos("A", null, "C"), 1, forward = false)!!
        assertTrue(gap.message().contains("is closed"))
        assertNotNull(gap.message())
    }
}
