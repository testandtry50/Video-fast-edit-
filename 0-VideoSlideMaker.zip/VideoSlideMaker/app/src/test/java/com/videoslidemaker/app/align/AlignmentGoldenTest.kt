package com.videoslidemaker.app.align

import com.videoslidemaker.app.check.SpokenWord
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Differential test. tools/alignment-reference/export_golden.py writes randomized inputs AND the outputs the (tested, measured)
 * Python reference produces for them into src/test/resources/alignment_golden.txt. This feeds the same inputs to the Kotlin code
 * and requires the same outputs: lexical anchors, fusion with calibrated confidence, estimates, statuses, sections, the coarse
 * tracker's Viterbi and hypotheses, and the step-aware re-centring. If the Kotlin ever drifts from the reference, this fails.
 */
class AlignmentGoldenTest {

    private val lines: List<String> by lazy {
        val stream = javaClass.classLoader!!.getResourceAsStream("alignment_golden.txt")
            ?: error("alignment_golden.txt is missing from the test resources")
        stream.bufferedReader(Charsets.UTF_8).use { it.readLines() }
    }

    private class Cursor(val lines: List<String>, var pos: Int = 0) {
        fun next(): String = lines[pos++]
        fun peek(): String = lines[pos]
        fun atEnd(): Boolean = pos >= lines.size
        fun tokens(): List<String> = next().split(" ")
    }

    private fun readSpoken(c: Cursor): List<SpokenWord> {
        val n = c.tokens()[1].toInt()
        return List(n) {
            val p = c.tokens()
            SpokenWord(p[1], p[2].toLong(), p[3].toLong(), p[4].toDouble())
        }
    }

    private fun parseLex(p: List<String>): LexicalLine? {
        if (p[2] == "NULL") return null
        val times = if (p[9].isEmpty()) LongArray(0) else p[9].split(",").map { it.toLong() }.toLongArray()
        return LexicalLine(p[2].toLong(), p[3].toLong(), p[4].toInt(), p[5].toInt(), p[6].toInt(), p[7].toDouble(), p[8].toDouble(), times)
    }

    private fun doubles(s: String): DoubleArray = if (s == "-" || s.isEmpty()) DoubleArray(0) else s.split(",").map { it.toDouble() }.toDoubleArray()

    @Test fun theKotlinCodeReproducesThePythonReference() {
        val c = Cursor(lines)
        val seen = HashMap<String, Int>()
        while (!c.atEnd()) {
            val h = c.tokens()
            if (h[0].isEmpty()) continue
            seen[h[0]] = (seen[h[0]] ?: 0) + 1
            when (h[0]) {
                "LEX_CASE" -> lexCase(c, h[1])
                "FUSE_CASE" -> fuseCase(c, h[1])
                "VIT_CASE" -> vitCase(c, h)
                "HYP_CASE" -> hypCase(c, h)
                "ANCHOR_CASE" -> anchorCase(c, h)
                else -> error("unknown record ${h[0]}")
            }
        }
        // the file really contains every kind of case (an empty or truncated file must not pass)
        for (kind in listOf("LEX_CASE", "FUSE_CASE", "VIT_CASE", "HYP_CASE", "ANCHOR_CASE")) {
            assertTrue("no $kind in the golden file", (seen[kind] ?: 0) > 0)
        }
    }

    private fun lexCase(c: Cursor, id: String) {
        val n = c.tokens()[1].toInt()
        val texts = List(n) { c.next().substring(2) }
        val spoken = readSpoken(c)
        val got = LexicalAnchors.compute(texts, spoken)
        for (i in 0 until n) {
            val p = c.tokens()
            val exp = parseLex(p)
            val g = got[i]
            val w = "lexical case $id line $i"
            if (exp == null) {
                assertNull("$w: expected no match", g)
                continue
            }
            assertTrue("$w: expected a match", g != null)
            g!!
            assertEquals("$w start", exp.startMs, g.startMs)
            assertEquals("$w end", exp.endMs, g.endMs)
            assertEquals("$w n", exp.n, g.n)
            assertEquals("$w matched", exp.matched, g.matched)
            assertEquals("$w first", exp.first, g.first)
            assertEquals("$w anchorConf", exp.anchorConf, g.anchorConf, 0.0)
            assertEquals("$w meanConf", exp.meanConf, g.meanConf, 1e-12)
            assertArrayEquals("$w times", exp.timesMs, g.timesMs)
            assertEquals("$w strong", p[10] == "1", g.isStrong)
        }
        c.next() // END
    }

    private fun fuseCase(c: Cursor, name: String) {
        val n = c.tokens()[1].toInt()
        val offset = c.tokens()[1].toLong()
        val clarity = c.tokens()[1].toDouble()
        val orig = c.tokens().drop(1).map { it.toInt() }.toIntArray()
        val units = c.tokens().drop(1).map { it.toDouble() }.toDoubleArray()
        val nb = c.tokens()[1].toInt()
        val bt = IntArray(nb)
        val bk = IntArray(nb)
        val bev = DoubleArray(nb)
        for (i in 0 until nb) {
            val p = c.tokens()
            bt[i] = p[1].toInt(); bk[i] = p[2].toInt(); bev[i] = p[3].toDouble()
        }
        val picks = arrayOfNulls<AudioPick>(n)
        for (i in 0 until n) {
            val p = c.tokens()
            if (p[2] != "NONE") picks[i] = AudioPick(p[2].toInt(), p[3].toDouble(), p[4].toInt(), p[5].toDouble())
        }
        val spoken = readSpoken(c)
        val lex = List(n) { parseLex(c.tokens()) }
        val index = if (spoken.isEmpty()) null else SpokenIndex(spoken, offset)
        val fused = LineFusion.fuse(picks, if (spoken.isEmpty()) null else lex, index, BoundarySet(bt, bk, bev), units, offset)
        val verdicts = LineFusion.judge(fused, orig, clarity)
        for (i in 0 until n) {
            val p = c.tokens()
            val w = "fusion case $name line $i"
            val v = verdicts[i]
            assertEquals("$w detected", if (p[2] == "NONE") null else p[2].toInt(), v.detectedMs)
            assertEquals("$w confidence", p[3].toDouble(), v.confidence, 1e-9)
            assertEquals("$w precision", if (p[4] == "NONE") null else p[4].toInt(), v.precisionMs)
            assertEquals("$w evidence", p[5], pythonEvidence(fused[i].cls, v.evidence))
            assertEquals("$w status", p[6], v.status.name)
        }
        val sec = c.next().removePrefix("SEC").trim()
        val got = AlignmentSections.find(verdicts.map { it.status }).joinToString(";") { "${it.first},${it.last},${it.worst.name}" }
        assertEquals("fusion case $name sections", sec, got)
        c.next() // END
    }

    /** Python names the evidence by fusion class, and "ESTIMATE" for lines placed from their neighbours. */
    private fun pythonEvidence(cls: FusionClass, e: AlignmentEvidence): String = if (e == AlignmentEvidence.ESTIMATE) "ESTIMATE" else cls.name

    private fun vitCase(c: Cursor, h: List<String>) {
        val nW = h[2].toInt()
        val nL = h[3].toInt()
        val scores = Array(nW) { val p = c.tokens(); DoubleArray(nL) { l -> p[1 + l].toDouble() } }
        val exp = c.tokens().drop(1).map { it.toInt() }
        val got = CoarseDrift.viterbi(scores)
        assertEquals("viterbi case ${h[1]}", exp, got.toList())
        c.next() // END
    }

    private fun hypCase(c: Cursor, h: List<String>) {
        val n = h[2].toInt()
        val windows = List(n) {
            val p = c.tokens()
            CoarseWindow(p[1].toInt(), p[2].toInt(), 1.0, 0.0, p[3] == "1")
        }
        while (c.peek() != "END") {
            val p = c.tokens()
            val t = p[1].toInt()
            val g = CoarseDrift.shiftHypotheses(windows, t)
            assertArrayEquals("hypotheses case ${h[1]} t=$t lags", doubles(p[2]), g.lags, 0.0)
            assertArrayEquals("hypotheses case ${h[1]} t=$t covered", doubles(p[3]), g.covered, 0.0)
        }
        c.next() // END
    }

    private fun anchorCase(c: Cursor, h: List<String>) {
        val n = h[2].toInt()
        val ts = c.tokens().drop(1).take(n).map { it.toInt() }.toIntArray()
        val sh = c.tokens().drop(1).take(n).map { it.toInt() }.toIntArray()
        while (c.peek() != "END") {
            val p = c.tokens()
            val t = p[1].toInt()
            assertArrayEquals("anchor hypotheses case ${h[1]} t=$t", doubles(p[2]), TimestampAligner.anchorHypotheses(ts, sh, t), 0.0)
        }
        c.next() // END
    }
}
