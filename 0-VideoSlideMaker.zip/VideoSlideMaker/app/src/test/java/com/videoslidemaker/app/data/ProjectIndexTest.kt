package com.videoslidemaker.app.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertSame
import org.junit.Assert.assertTrue
import org.junit.Test

/** The project list: ordering, naming, summaries, and how it is written to disk and read back. */
class ProjectIndexTest {

    private fun info(id: String, name: String, updated: Long = 0L) =
        ProjectInfo(id = id, name = name, createdAtMs = 1L, updatedAtMs = updated)

    private fun list(vararg p: ProjectInfo, active: String? = null) = ProjectIndex(p.toList(), active)

    // ---------------------------------------------------------------- the list

    @Test
    fun plusAddsAtTheEndAndNeverDoublesAnId() {
        val a = info("a", "One")
        val idx = list(a).plus(info("b", "Two")).plus(info("a", "One again"))
        assertEquals(listOf("b", "a"), idx.projects.map { it.id })
        assertEquals("One again", idx.find("a")!!.name)
    }

    @Test
    fun removingTheOpenProjectLeavesNothingOpen() {
        val idx = list(info("a", "A"), info("b", "B"), active = "a")
        val after = idx.minus("a")
        assertNull(after.activeId)
        assertEquals(listOf("b"), after.projects.map { it.id })
        assertEquals("a", idx.minus("b").activeId)
    }

    @Test
    fun withActiveIgnoresAnUnknownId() {
        val idx = list(info("a", "A"))
        assertEquals("a", idx.withActive("a").activeId)
        assertNull(idx.withActive("zzz").activeId)
        assertNull(idx.withActive(null).activeId)
    }

    @Test
    fun orderedPutsTheOpenProjectFirstThenNewestEditFirst() {
        val idx = list(info("old", "Old", 10), info("new", "New", 30), info("mid", "Mid", 20), info("open", "Open", 5), active = "open")
        assertEquals(listOf("open", "new", "mid", "old"), idx.ordered().map { it.id })
        assertEquals(listOf("new", "mid", "old", "open"), idx.withActive(null).ordered().map { it.id })
    }

    @Test
    fun mostRecentOtherThanSkipsTheGivenProject() {
        val idx = list(info("a", "A", 10), info("b", "B", 30), info("c", "C", 20))
        assertEquals("b", idx.mostRecentOtherThan(null)!!.id)
        assertEquals("c", idx.mostRecentOtherThan("b")!!.id)
        assertNull(list(info("only", "Only")).mostRecentOtherThan("only"))
    }

    // ---------------------------------------------------------------- rename

    @Test
    fun renameCleansTheNameAndKeepsItUniqueAmongTheOthers() {
        val idx = list(info("a", "Trip"), info("b", "Home"))
        assertEquals("trip (2)", idx.renamed("b", "  trip  ", 99).find("b")!!.name)
        assertEquals("Holiday film", idx.renamed("b", "Holiday    film", 99).find("b")!!.name)
        assertEquals(99L, idx.renamed("b", "Holiday", 99).find("b")!!.updatedAtMs)
    }

    @Test
    fun renameToItsOwnNameOrABlankNameChangesNothing() {
        val idx = list(info("a", "Trip", 5))
        assertSame(idx, idx.renamed("a", "Trip", 99))
        assertSame(idx, idx.renamed("a", "   ", 99))
        assertSame(idx, idx.renamed("missing", "X", 99))
    }

    @Test
    fun renameKeepsTheCapitalLettersOfTheNewName() {
        val idx = list(info("a", "Trip"))
        // Only the letter case differs from its own name: that is allowed (it is not "another" project).
        assertEquals("TRIP", idx.renamed("a", "TRIP", 1).find("a")!!.name)
    }

    // ---------------------------------------------------------------- summary

    @Test
    fun summaryUpdatesTheCardAndTheEditedTimeOnlyWhenAsked() {
        val idx = list(info("a", "A", 5))
        val edited = idx.withSummary("a", 1200, 980, 18000.0, nowMs = 777)
        assertEquals(1200, edited.find("a")!!.slideCount)
        assertEquals(980, edited.find("a")!!.photoCount)
        assertEquals(18000.0, edited.find("a")!!.durationSec, 0.0)
        assertEquals(777L, edited.find("a")!!.updatedAtMs)

        val opened = idx.withSummary("a", 3, 4, 5.0, nowMs = null)
        assertEquals(5L, opened.find("a")!!.updatedAtMs) // opening a project is not an edit
    }

    @Test
    fun summaryThatChangesNothingReturnsTheSameList() {
        val idx = list(info("a", "A", 5)).withSummary("a", 3, 4, 5.0, nowMs = null)
        assertSame(idx, idx.withSummary("a", 3, 4, 5.0, nowMs = null))
    }

    @Test
    fun summaryRefusesNonsenseNumbers() {
        val s = list(info("a", "A")).withSummary("a", -5, -1, Double.NaN, nowMs = null).find("a")!!
        assertEquals(0, s.slideCount)
        assertEquals(0, s.photoCount)
        assertEquals(0.0, s.durationSec, 0.0)
    }

    // ---------------------------------------------------------------- names

    @Test
    fun cleanTrimsCollapsesAndCutsAtTheLimit() {
        assertEquals("a b c", ProjectNames.clean("  a \n b\t c  "))
        assertEquals("", ProjectNames.clean("   "))
        val long = "x".repeat(200)
        assertEquals(ProjectNames.MAX_LENGTH, ProjectNames.clean(long).length)
    }

    @Test
    fun uniqueCountsUpAndIgnoresCapitals() {
        assertEquals("Trip", ProjectNames.unique("Trip", emptyList()))
        assertEquals("Trip (2)", ProjectNames.unique("Trip", listOf("trip")))
        assertEquals("Trip (3)", ProjectNames.unique("Trip", listOf("Trip", "TRIP (2)")))
    }

    @Test
    fun defaultNamesAreNumbered() {
        assertEquals("Project 1", ProjectNames.nextDefault(emptyList()))
        assertEquals("Project 3", ProjectNames.nextDefault(listOf("Project 1", "Something")))
        // "Project 2" is taken, so the next free one is used rather than a clash.
        assertEquals("Project 2 (2)", ProjectNames.nextDefault(listOf("Project 2")))
    }

    @Test
    fun copyNamesAreUnique() {
        assertEquals("Trip copy", ProjectNames.copyOf("Trip", listOf("Trip")))
        assertEquals("Trip copy (2)", ProjectNames.copyOf("Trip", listOf("Trip", "Trip copy")))
        assertEquals("Project copy", ProjectNames.copyOf("  ", emptyList()))
    }

    @Test
    fun searchMatchesEveryWordInAnyOrder() {
        assertTrue(ProjectNames.matches("Episode 12 - Final cut", ""))
        assertTrue(ProjectNames.matches("Episode 12 - Final cut", "final episode"))
        assertTrue(ProjectNames.matches("Episode 12 - Final cut", "  CUT "))
        assertFalse(ProjectNames.matches("Episode 12 - Final cut", "episode 13"))
    }

    @Test
    fun durationFormat() {
        assertEquals("0:00", ProjectNames.formatDuration(0.0))
        assertEquals("0:00", ProjectNames.formatDuration(-3.0))
        assertEquals("0:00", ProjectNames.formatDuration(Double.NaN))
        assertEquals("4:05", ProjectNames.formatDuration(245.0))
        assertEquals("1:02:03", ProjectNames.formatDuration(3723.4))
        assertEquals("5:00:00", ProjectNames.formatDuration(5 * 3600.0))
        assertEquals("10:00:00", ProjectNames.formatDuration(36000.0))
    }

    // ---------------------------------------------------------------- the file

    @Test
    fun theListSurvivesBeingWrittenAndRead() {
        val idx = ProjectIndex(
            listOf(
                ProjectInfo("a1", "Episode 12", 100L, 200L, 1200, 980, 18000.5),
                ProjectInfo("b-2_x", "Hindi “story” \u0939\u093F\u0928\u094D\u0926\u0940", 300L, 400L, 0, 0, 0.0)
            ),
            activeId = "b-2_x"
        )
        val back = ProjectIndexCodec.decode(ProjectIndexCodec.encode(idx))
        assertNotNull(back)
        assertEquals(idx, back)
    }

    @Test
    fun aListWithNoOpenProjectComesBackWithNone() {
        val idx = ProjectIndex(listOf(info("a", "A")), null)
        assertNull(ProjectIndexCodec.decode(ProjectIndexCodec.encode(idx))!!.activeId)
    }

    @Test
    fun anOpenIdThatIsNotInTheListIsDropped() {
        val text = """{"version":1,"activeId":"ghost","projects":[{"id":"a","name":"A"}]}"""
        val back = ProjectIndexCodec.decode(text)!!
        assertNull(back.activeId)
        assertEquals(1, back.projects.size)
    }

    @Test
    fun damagedFilesAreReportedAsNullNotAsCrashes() {
        assertNull(ProjectIndexCodec.decode(""))
        assertNull(ProjectIndexCodec.decode("not json at all"))
        assertNull(ProjectIndexCodec.decode("""{"version":1}"""))
        assertNull(ProjectIndexCodec.decode("""[1,2,3]"""))
    }

    @Test
    fun badEntriesAreSkippedAndGoodOnesKept() {
        val text = """
            {"projects":[
              {"id":"good","name":"Good"},
              {"name":"no id"},
              {"id":"../escape","name":"path trick"},
              {"id":"good","name":"duplicate id"},
              {"id":"blank","name":"   "},
              {"id":"neg","name":"N","slides":-4,"photos":-1,"duration":-9},
              "garbage"
            ]}
        """.trimIndent()
        val back = ProjectIndexCodec.decode(text)!!
        assertEquals(listOf("good", "blank", "neg"), back.projects.map { it.id })
        assertEquals("Good", back.find("good")!!.name)
        assertEquals("Untitled", back.find("blank")!!.name)
        assertEquals(0, back.find("neg")!!.slideCount)
        assertEquals(0, back.find("neg")!!.photoCount)
        assertEquals(0.0, back.find("neg")!!.durationSec, 0.0)
    }

    @Test
    fun idsBecomeFileNamesSoOnlyPlainOnesAreSafe() {
        assertTrue(ProjectIndexCodec.isSafeId("3f9a0c1b2d4e5f60"))
        assertTrue(ProjectIndexCodec.isSafeId("a-b_C9"))
        assertFalse(ProjectIndexCodec.isSafeId(""))
        assertFalse(ProjectIndexCodec.isSafeId("../x"))
        assertFalse(ProjectIndexCodec.isSafeId("a/b"))
        assertFalse(ProjectIndexCodec.isSafeId("a b"))
        assertFalse(ProjectIndexCodec.isSafeId("a.json"))
        assertFalse(ProjectIndexCodec.isSafeId("x".repeat(65)))
    }

    // ---------------------------------------------------------------- what the screen sees

    @Test
    fun projectsUiKnowsTheOpenProjectsNameAndOrder() {
        val ui = ProjectsUi(
            projects = listOf(info("a", "Alpha", 10), info("b", "Beta", 20)),
            activeId = "a"
        )
        assertEquals("Alpha", ui.activeName)
        assertEquals(listOf("a", "b"), ui.ordered().map { it.id })
        assertNull(ProjectsUi().activeName)
    }
}
