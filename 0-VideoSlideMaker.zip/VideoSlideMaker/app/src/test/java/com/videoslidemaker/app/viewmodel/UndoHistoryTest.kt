package com.videoslidemaker.app.viewmodel

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** The undo / redo stacks: what Undo and Redo hand back, and when each is available. */
class UndoHistoryTest {

    @Test
    fun startsEmpty() {
        val h = UndoHistory<Int>()
        assertFalse(h.canUndo)
        assertFalse(h.canRedo)
        assertNull(h.undo(1))
        assertNull(h.redo(1))
    }

    @Test
    fun undoReturnsTheStateBeforeTheChangeAndRedoReturnsToIt() {
        val h = UndoHistory<Int>()
        h.push(before = 1, label = "a") // 1 -> 2
        h.push(before = 2, label = "b") // 2 -> 3

        val back = h.undo(current = 3)!!
        assertEquals(2, back.snapshot)
        assertEquals("b", back.label)
        assertTrue(h.canRedo)

        val back2 = h.undo(current = 2)!!
        assertEquals(1, back2.snapshot)
        assertFalse(h.canUndo)

        assertEquals(2, h.redo(current = 1)!!.snapshot)
        assertEquals(3, h.redo(current = 2)!!.snapshot)
        assertFalse(h.canRedo)
        assertTrue(h.canUndo)
    }

    @Test
    fun aNewChangeEndsTheRedoTrail() {
        val h = UndoHistory<Int>()
        h.push(1, "a")
        h.undo(2)
        assertTrue(h.canRedo)
        h.push(1, "c")
        assertFalse(h.canRedo)
    }

    @Test
    fun labelsNameTheNextStep() {
        val h = UndoHistory<Int>()
        h.push(1, "photo match")
        assertEquals("photo match", h.undoLabel)
        h.undo(2)
        assertNull(h.undoLabel)
        assertEquals("photo match", h.redoLabel)
    }

    @Test
    fun oldestStepsAreDroppedBeyondTheLimit() {
        val h = UndoHistory<Int>(limit = 3)
        for (i in 1..5) h.push(i, "s$i")
        // only the 3 newest remain: 5, 4, 3
        assertEquals(5, h.undo(0)!!.snapshot)
        assertEquals(4, h.undo(0)!!.snapshot)
        assertEquals(3, h.undo(0)!!.snapshot)
        assertNull(h.undo(0))
    }

    @Test
    fun clearForgetsEverything() {
        val h = UndoHistory<Int>()
        h.push(1, "a")
        h.undo(2)
        h.clear()
        assertFalse(h.canUndo)
        assertFalse(h.canRedo)
    }
}
