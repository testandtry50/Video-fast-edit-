package com.videoslidemaker.app.logoclean

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Locale

/** The numbers behind the "clean ALL photos" progress card and its safety checks (100,000+ photos). */
class BulkMathTest {
    private val mb = 1024L * 1024L

    @Test
    fun workerCountStaysBetweenOneAndFourAndRespectsMemory() {
        assertEquals(1, BulkMath.workerCount(cores = 1, maxHeapBytes = 512 * mb))
        assertEquals(1, BulkMath.workerCount(cores = 2, maxHeapBytes = 512 * mb)) // one core stays free
        assertEquals(3, BulkMath.workerCount(cores = 8, maxHeapBytes = 512 * mb)) // memory allows 3
        assertEquals(4, BulkMath.workerCount(cores = 16, maxHeapBytes = 4096 * mb))
        assertEquals(1, BulkMath.workerCount(cores = 8, maxHeapBytes = 100 * mb)) // tiny heap: still works, one at a time
    }

    @Test
    fun percentRoundsDownSoItOnlyReadsHundredWhenFinished() {
        assertEquals(0, BulkMath.percent(0, 0))
        assertEquals(0, BulkMath.percent(5, 0))
        assertEquals(33, BulkMath.percent(1, 3))
        assertEquals(50, BulkMath.percent(50_000, 100_000))
        assertEquals(99, BulkMath.percent(99_999, 100_000))
        assertEquals(100, BulkMath.percent(100_000, 100_000))
        assertEquals(100, BulkMath.percent(120, 100)) // never above 100
    }

    @Test
    fun timeLeftNeedsEnoughProgressFirstThenFollowsTheSpeed() {
        assertEquals(-1L, BulkMath.etaSeconds(done = 2, total = 100, elapsedMs = 10_000))   // too few photos yet
        assertEquals(-1L, BulkMath.etaSeconds(done = 10, total = 110, elapsedMs = 1_000))   // too early
        assertEquals(-1L, BulkMath.etaSeconds(done = 110, total = 110, elapsedMs = 20_000)) // nothing left
        // 100 photos in 10 s = 10 per second; 1000 left -> 100 s
        assertEquals(100L, BulkMath.etaSeconds(done = 100, total = 1_100, elapsedMs = 10_000))
    }

    @Test
    fun durationsAreWrittenInPlainWords() {
        assertEquals("", BulkMath.formatDuration(-1))
        assertEquals("under a minute", BulkMath.formatDuration(10))
        assertEquals("under a minute", BulkMath.formatDuration(44))
        assertEquals("2 min", BulkMath.formatDuration(90))
        assertEquals("1 h", BulkMath.formatDuration(3_600))
        assertEquals("1 h 5 min", BulkMath.formatDuration(3_900))
        assertEquals("3 h 20 min", BulkMath.formatDuration(3 * 3600 + 20 * 60))
    }

    @Test
    fun sizesCountsAndSpeedsAreReadable() {
        val us = Locale.US
        assertEquals("500 KB", BulkMath.formatBytes(500L * 1024L, us))
        assertEquals("420 MB", BulkMath.formatBytes(420L * mb, us))
        assertEquals("1.5 GB", BulkMath.formatBytes((1.5 * 1024 * mb).toLong(), us))
        assertEquals("100,000", BulkMath.formatCount(100_000, us))
        assertEquals("38 photos/s", BulkMath.formatRate(38f, us))
        assertEquals("0.4 photos/s", BulkMath.formatRate(0.44f, us))
    }

    @Test
    fun storageEstimateScalesWithPixelsAndFormatAndIsCappedForHugePhotos() {
        val jpeg = BulkMath.estimateOutputBytes(1920, 1080, lossless = false)
        assertEquals(622_080.0, jpeg.toDouble(), 2.0)
        assertEquals(jpeg, BulkMath.estimateOutputBytes(0, 0, lossless = false)) // unknown size = a 1080p frame
        assertTrue("PNG is bigger than JPEG", BulkMath.estimateOutputBytes(1920, 1080, lossless = true) > jpeg * 3)
        // an 8192 x 6144 photo is saved at 4096 x 3072, so it is estimated at that size
        val huge = BulkMath.estimateOutputBytes(8192, 6144, lossless = false)
        val capped = BulkMath.estimateOutputBytes(4096, 3072, lossless = false)
        assertEquals(capped.toDouble(), huge.toDouble(), 4.0)
        // 100,000 frames of 1080p: tens of gigabytes, which is exactly why storage is checked first
        val total = 100_000L * jpeg
        assertTrue(total > 50L * 1024L * mb && total < 70L * 1024L * mb)
    }
}
