package com.videoslidemaker.app.export

import org.junit.Assert.assertEquals
import org.junit.Test

class TimedQueueTest {

    @Test
    fun releasesOnlyWhatIsDueAndKeepsOrder() {
        val q = TimedQueue<String>()
        for (i in 0 until 10) q.add(i * 1000L, "a$i")
        val out = ArrayList<String>()
        q.drainUpTo(3500L) { out.add(it) }
        assertEquals(listOf("a0", "a1", "a2", "a3"), out)
        assertEquals(6, q.size)
        q.drainUpTo(3500L) { out.add(it) } // nothing new is due
        assertEquals(4, out.size)
    }

    @Test
    fun drainAllEmptiesTheQueueInOrder() {
        val q = TimedQueue<Int>()
        q.add(5L, 1); q.add(6L, 2); q.add(7L, 3)
        val out = ArrayList<Int>()
        q.drainAll { out.add(it) }
        assertEquals(listOf(1, 2, 3), out)
        assertEquals(0, q.size)
    }

    /** The whole point: all the sound is queued first, yet it is written alternating with the pictures. */
    @Test
    fun soundIsWrittenInStepWithVideoInsteadOfAsOneBlockFirst() {
        val q = TimedQueue<String>()
        // 5 seconds of sound in ~23 ms frames, all encoded before any picture
        val frameUs = 23_220L
        var t = 0L
        var n = 0
        while (t < 5_000_000L) { q.add(t, "A$n"); t += frameUs; n++ }

        val written = ArrayList<String>()
        for (f in 0 until 120) { // 5 s of picture at 24 fps
            val videoUs = f * 1_000_000L / 24
            q.drainUpTo(videoUs) { written.add(it) }
            written.add("V$f")
        }
        q.drainAll { written.add(it) }

        // no long run of sound at the front: the first picture comes after at most one sound frame
        val firstVideo = written.indexOfFirst { it.startsWith("V") }
        assertEquals(true, firstVideo <= 1)
        // and no two pictures are ever separated by more than a handful of sound frames
        var run = 0; var maxRun = 0
        for (w in written) { if (w.startsWith("A")) { run++; if (run > maxRun) maxRun = run } else run = 0 }
        assertEquals(true, maxRun <= 3)
        // nothing lost, nothing duplicated
        assertEquals(n, written.count { it.startsWith("A") })
        assertEquals(120, written.count { it.startsWith("V") })
    }
}
