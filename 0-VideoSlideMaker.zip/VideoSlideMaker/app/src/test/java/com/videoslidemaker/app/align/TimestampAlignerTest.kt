package com.videoslidemaker.app.align

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Random
import kotlin.math.abs

class TimestampAlignerTest {

    /** The script's wrong timestamps: truth moved EARLIER by [error] (so the needed correction is positive). */
    private fun wrongTimestamps(s: SyntheticSpeech, error: (Long) -> Long): List<Long> {
        val out = ArrayList<Long>()
        for (i in s.startMs.indices) {
            var v = s.startMs[i] - error(s.startMs[i])
            if (out.isNotEmpty() && v <= out.last()) v = out.last() + 50
            out.add(v)
        }
        return out
    }

    private fun align(s: SyntheticSpeech, original: List<Long>, offsetMs: Long = 0L, texts: List<String> = s.texts) =
        TimestampAligner.align(s.frames, offsetMs, original, texts)

    private fun assertQuality(
        s: SyntheticSpeech,
        r: AlignmentResult,
        truthShift: Long = 0L,
        minTrusted: Double = 0.5,
        /** script line index -> index of the recorded line it really is (identity unless the script is a subset) */
        truthIndex: (Int) -> Int = { it }
    ) {
        var detected = 0
        var within200 = 0
        var trusted = 0
        for (item in r.items) {
            val d = item.detectedMs ?: continue
            detected++
            val err = abs(d - (s.startMs[truthIndex(item.index)] + truthShift))
            if (err <= 200) within200++
            if (item.status != AlignmentStatus.NEEDS_REVIEW) {
                trusted++
                // THE safety property: nothing rated trustworthy may be wrong.
                assertTrue("line ${item.index} rated ${item.status} (conf ${item.confidence}) but off by $err ms", err <= 250)
            }
        }
        assertTrue("only $within200 of $detected within 200 ms", within200 >= 0.9 * detected)
        assertTrue("only $trusted of ${r.items.size} lines trusted", trusted >= minTrusted * r.items.size)
    }

    @Test fun correctsDriftPerLineNotWithOneFixedOffset() {
        val s = SyntheticSpeech.generate(seed = 1, minutes = 4)
        // 0 s of error at the start growing to 2.1 s at the end — the kind of drift in the brief.
        val original = wrongTimestamps(s) { t -> (2100L * t) / s.totalMs }
        val r = align(s, original)
        assertQuality(s, r)

        val trusted = r.items.filter { it.status == AlignmentStatus.HIGH_CONFIDENCE || it.status == AlignmentStatus.MATCHES }
        val early = trusted.take(10).map { it.diffMs!! }.average()
        val late = trusted.takeLast(10).map { it.diffMs!! }.average()
        assertTrue("detected correction should grow from ~0 ($early) to ~2 s ($late), not stay constant", late - early > 1200.0)
    }

    @Test fun findsLargeOffsetsFarBeyondAFewSeconds() {
        // The script is 25 s too EARLY. A real script can't have negative times, so it simply
        // doesn't contain the first lines (they start before 27 s).
        val s = SyntheticSpeech.generate(seed = 2, minutes = 5)
        val keep = s.startMs.indices.filter { s.startMs[it] >= 27_000L }
        val r = TimestampAligner.align(
            s.frames, 0L,
            keep.map { s.startMs[it] - 25_000L },
            keep.map { s.texts[it] }
        )
        assertQuality(s, r, truthIndex = { keep[it] })
    }

    @Test fun findsLargeOffsetsInTheOtherDirection() {
        // The script is 25 s too LATE.
        val s = SyntheticSpeech.generate(seed = 8, minutes = 4)
        val r = align(s, wrongTimestamps(s) { -25_000L })
        assertQuality(s, r)
    }

    @Test fun findsNegativeOffsets() {
        val s = SyntheticSpeech.generate(seed = 3, minutes = 4)
        val r = align(s, wrongTimestamps(s) { -7_000L })
        assertQuality(s, r)
    }

    @Test fun jitterOnEveryLineIsStillCorrected() {
        val s = SyntheticSpeech.generate(seed = 4, minutes = 4)
        val rnd = Random(99)
        val r = align(s, wrongTimestamps(s) { t -> (1500L * t) / s.totalMs + (rnd.nextGaussian() * 400).toLong() })
        assertQuality(s, r, minTrusted = 0.2)
    }

    @Test fun reportsCorrectionsInTheShapeOfTheBrief() {
        val s = SyntheticSpeech.generate(seed = 5, minutes = 3)
        val r = align(s, wrongTimestamps(s) { 1430L })
        val item = r.items.first { it.status == AlignmentStatus.HIGH_CONFIDENCE }
        // original, detected and the signed difference all agree with each other
        assertEquals(item.detectedMs!! - item.originalMs, item.diffMs)
        assertTrue(abs(item.diffMs!! - 1430L) <= 250)
        assertTrue(AlignmentFormat.signedSeconds(item.diffMs!!).startsWith("+1."))
    }

    @Test fun honoursWhereTheAudioTrackStarts() {
        // If the audio track begins 2 s into the file, every time is 2 s later than the frame index says.
        val s = SyntheticSpeech.generate(seed = 6, minutes = 3)
        val offset = 2000L
        val original = wrongTimestamps(s) { 900L }.map { it + offset }
        val r = align(s, original, offsetMs = offset)
        assertQuality(s, r, truthShift = offset)
    }

    @Test fun estimatesWhenEachLineEnds() {
        val s = SyntheticSpeech.generate(seed = 7, minutes = 3)
        val r = align(s, wrongTimestamps(s) { 1000L })
        var checked = 0
        var good = 0
        for (item in r.items) {
            val end = item.detectedEndMs ?: continue
            if (item.status == AlignmentStatus.NEEDS_REVIEW) continue
            checked++
            if (abs(end - s.endMs[item.index]) <= 300) good++
        }
        assertTrue("no end times were found", checked > 10)
        assertTrue("only $good of $checked end times within 300 ms", good >= 0.9 * checked)
    }

    // ---------------- the dangerous cases: nothing may be rated trustworthy ----------------

    @Test fun aTranscriptThatIsNotInTheRecordingIsNeverTrusted() {
        val a = SyntheticSpeech.generate(seed = 10, minutes = 3)
        val b = SyntheticSpeech.generate(seed = 11, minutes = 3)
        val r = align(a, b.startMs.toList(), texts = b.texts)
        assertEquals(0, r.highConfidenceCount)
        assertEquals(0, r.matchesCount)
    }

    @Test fun silenceIsNeverTrusted() {
        val s = SyntheticSpeech.generate(seed = 12, minutes = 3)
        val quiet = FloatArray(6000) { -90f }
        val r = TimestampAligner.align(quiet, 0L, s.startMs.toList(), s.texts)
        assertEquals(0, r.highConfidenceCount)
        assertEquals(0, r.matchesCount)
    }

    @Test fun aSteadyToneIsNeverTreatedAsSpeech() {
        val s = SyntheticSpeech.generate(seed = 13, minutes = 3)
        val tone = FloatArray(s.frames.size) { -30f }
        val r = TimestampAligner.align(tone, 0L, s.startMs.toList(), s.texts)
        assertEquals(0, r.highConfidenceCount)
    }

    @Test fun linesWithoutTextAreNeverTrusted() {
        val s = SyntheticSpeech.generate(seed = 14, minutes = 3)
        val blank = s.texts.map { "" }
        val r = align(s, wrongTimestamps(s) { 3000L }, texts = blank)
        assertEquals(0, r.highConfidenceCount)
        assertEquals(0, r.matchesCount)
    }

    @Test fun aLineThatIsNotInTheAudioDoesNotDerailItsNeighbours() {
        val s = SyntheticSpeech.generate(seed = 15, minutes = 3)
        val texts = s.texts.toMutableList()
        val original = wrongTimestamps(s) { 1200L }.toMutableList()
        // insert a line that was never recorded, between lines 10 and 11
        texts.add(11, "This sentence was cut from the recording.")
        original.add(11, (original[10] + original[11]) / 2)
        val r = TimestampAligner.align(s.frames, 0L, original, texts)
        var wrongTrusted = 0
        for (item in r.items) {
            if (item.index == 11 || item.status == AlignmentStatus.NEEDS_REVIEW) continue
            val truth = s.startMs[if (item.index < 11) item.index else item.index - 1]
            if (abs(item.detectedMs!! - truth) > 250) wrongTrusted++
        }
        assertEquals("a missing line must not push others to wrong times", 0, wrongTrusted)
        assertTrue("the invented line should not be trusted", r.items[11].status == AlignmentStatus.NEEDS_REVIEW)
    }

    @Test fun tooShortARecordingIsReportedNotGuessed() {
        val r = TimestampAligner.align(FloatArray(100), 0L, listOf(1000L), listOf("Hello"))
        assertEquals(1, r.items.size)
        assertEquals(AlignmentStatus.NEEDS_REVIEW, r.items[0].status)
        assertEquals(null, r.items[0].detectedMs)
    }
}
