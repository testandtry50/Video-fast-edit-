package com.videoslidemaker.app.check

import com.videoslidemaker.app.data.TimestampParser
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * The same scenarios, with the same helper data and the same expected numbers, as
 * tools/accuracy-reference/run_tests.py. Change one, change the other.
 */
class AccuracyCheckerTest {

    // ------------------------------------------------------------------------------------------------ helpers

    /** Fake recognizer output: one word per item, evenly spaced. (Same formula as speak() in run_tests.py.) */
    private fun speak(text: String, startMs: Long, perWord: Long = 380L, conf: Double = 1.0, gap: Long = 0L): List<SpokenWord> {
        val out = ArrayList<SpokenWord>()
        var t = startMs
        for (w in text.split(" ", "\t", "\n").filter { it.isNotEmpty() }) {
            val d = if (w.codePointCount(0, w.length) < 6) perWord else perWord + 120L
            out.add(SpokenWord(w, t, t + d, conf))
            t += d + 40L + gap
        }
        return out
    }

    /** [(transcript, spoken)] -> transcript segments stamped at the TRUE spoken starts, and the spoken words. */
    private fun chain(lines: List<Pair<String, String>>, start: Long = 0L, gap: Long = 900L): Pair<List<CheckSegment>, List<SpokenWord>> {
        val segs = ArrayList<CheckSegment>()
        val sp = ArrayList<SpokenWord>()
        var t = start
        for ((tx, au) in lines) {
            segs.add(CheckSegment(t, tx))
            val w = speak(au, t)
            sp.addAll(w)
            t = w.last().endMs + gap
        }
        return segs to sp
    }

    private fun check(segs: List<CheckSegment>, sp: List<SpokenWord>, settings: CheckSettings = CheckSettings()) =
        AccuracyChecker.check(segs, sp, settings)

    private fun one(ts: Long, text: String, spoken: List<SpokenWord>, settings: CheckSettings = CheckSettings()): SegmentResult =
        check(listOf(CheckSegment(ts, text)), spoken, settings).segments[0]

    /** A tiny deterministic random source (Python's random cannot be reproduced here, and does not need to be). */
    private class Lcg(var seed: Long) {
        fun next(n: Int): Int {
            seed = seed * 6364136223846793005L + 1442695040888963407L
            return ((seed ushr 33) % n).toInt()
        }
    }

    private val vocab = listOf(
        "time", "people", "water", "light", "house", "world", "school", "family", "story", "music",
        "night", "paper", "green", "small", "happy", "river", "stone", "cloud", "market", "garden"
    )

    // ------------------------------------------------------------------------------------------------ the brief's examples

    @Test fun briefExample_programBecomesShow_withExactPlaceInAudio() {
        val s = one(2000, "Hello everyone, welcome to our program.", speak("Hello everyone, welcome to our show.", 2000))
        assertEquals(CheckStatus.TEXT_MISMATCH, s.status)
        assertEquals(1, s.issues.size)
        assertEquals("program", s.issues[0].transcriptText)
        assertEquals("show", s.issues[0].audioText)
        assertTrue(s.issues[0].firm)
        assertEquals(4340L, s.issues[0].audioStartMs)
        assertEquals(4720L, s.issues[0].audioEndMs)
        assertEquals(5, s.issues[0].tFrom)
        assertEquals(6, s.issues[0].tTo)
        assertFalse(s.timestamp!!.isError)
        assertEquals(4340L, s.jumpMs)
    }

    @Test fun briefExample_timestampError_5000_to_8120() {
        val s = one(5000, "This is the second part of the talk.", speak("This is the second part of the talk.", 8120))
        assertEquals(CheckStatus.TIMESTAMP_ERROR, s.status)
        assertEquals(8120L, s.timestamp!!.actualMs)
        assertEquals(3120L, s.timestamp!!.diffMs)
        assertEquals(8120L, s.timestamp!!.correctedMs)
        assertEquals("00:00:05.000", CheckFormat.clock(5000))
        assertEquals("00:00:08.120", CheckFormat.clock(s.timestamp!!.actualMs!!))
        assertEquals("+3.120 seconds", CheckFormat.signedSeconds(3120))
        assertEquals("-0.250 seconds", CheckFormat.signedSeconds(-250))
        assertEquals("0.000 seconds", CheckFormat.signedSeconds(0))
        assertEquals(8120L, s.jumpMs)
    }

    @Test fun clockMatchesTheAppsCanonicalTimestampFormat() {
        for (ms in listOf(0L, 5L, 999L, 1000L, 5000L, 8120L, 61_001L, 3_599_999L, 3_600_000L, 86_399_999L)) {
            assertEquals(TimestampParser.formatCanonical(ms), CheckFormat.clock(ms))
        }
    }

    // ------------------------------------------------------------------------------------------------ each status

    @Test fun matchMissingExtraAndMismatchInOneRun() {
        val (segs, sp) = chain(
            listOf(
                "Welcome back to the channel." to "Welcome back to the channel.",
                "Today we are looking at the new phone." to "Today we are looking at the very new phone.",
                "It has a great camera and screen." to "It has a camera and screen.",
                "The battery lasts all day long." to "The battery lasts all week long."
            )
        )
        val r = check(segs, sp)
        assertEquals(
            listOf(CheckStatus.MATCH, CheckStatus.MISSING_WORD, CheckStatus.EXTRA_WORD, CheckStatus.TEXT_MISMATCH),
            r.segments.map { it.status }
        )
        assertEquals("very", r.segments[1].issues[0].audioText)
        assertEquals("", r.segments[1].issues[0].transcriptText)
        assertEquals(6, r.segments[1].issues[0].tFrom)
        assertEquals("great", r.segments[2].issues[0].transcriptText)
        assertEquals("", r.segments[2].issues[0].audioText)
        assertEquals("day", r.segments[3].issues[0].transcriptText)
        assertEquals("week", r.segments[3].issues[0].audioText)
        assertEquals(26, r.wordTotal)
        assertEquals(24, r.wordMatched)
        assertEquals(24.0 / 26.0, r.accuracy, 1e-9)
    }

    @Test fun uncertainWhenTheRecognizerIsNotSure() {
        val sp = speak("I think the weather is nice today.", 1000).toMutableList()
        sp[3] = SpokenWord("feather", sp[3].startMs, sp[3].endMs, 0.35)
        val s = one(1000, "I think the weather is nice today.", sp)
        assertEquals(CheckStatus.UNCERTAIN, s.status)
        assertEquals(1, s.issues.size)
        assertFalse(s.issues[0].firm)
    }

    // ------------------------------------------------------------------------------------------------ things that are NOT errors

    @Test fun caseFillersNumbersYearsAndSymbolsAreNotErrors() {
        var s = one(
            0, "We sold 25 units, um, in 2020 -- Don't forget! It costs \$5 and 10% & more.",
            speak("we sold twenty five units uh in twenty twenty dont forget it costs five dollars and ten percent and more", 0)
        )
        assertEquals("issues: " + s.issues, CheckStatus.MATCH, s.status)
        s = one(0, "Born in 1984 and moved in 1905.", speak("born in nineteen eighty four and moved in nineteen oh five", 0))
        assertEquals(CheckStatus.MATCH, s.status)
        s = one(0, "There were 250 people and 3000 chairs.", speak("there were two hundred and fifty people and three thousand chairs", 0))
        assertEquals(CheckStatus.MATCH, s.status)
    }

    @Test fun aWrongNumberIsNeverAFirmError() {
        val s = one(0, "We sold 25 units today.", speak("we sold thirty units today", 0))
        assertEquals(CheckStatus.UNCERTAIN, s.status)
        assertEquals(CheckStatus.TEXT_MISMATCH, s.issues[0].kind)
        assertFalse(s.issues[0].firm)
    }

    @Test fun aStutterIsOnlyADoubtWithItsOwnReason() {
        val s = one(0, "I went to the market yesterday.", speak("I went to the the market yesterday.", 0))
        assertEquals(CheckStatus.UNCERTAIN, s.status)
        assertTrue(s.reason, s.reason.contains("stutter"))
    }

    // ------------------------------------------------------------------------------------------------ lines that are not in the audio

    @Test fun aLineNotInTheAudioAtTheEndIsUncertain() {
        val (segs0, sp) = chain(
            listOf(
                "First line here." to "First line here.",
                "Totally different words appear." to "Totally different words appear."
            )
        )
        val segs = segs0 + CheckSegment(segs0.last().timestampMs + 3000, "This sentence is never spoken.")
        val r = check(segs, sp)
        assertEquals(listOf(CheckStatus.MATCH, CheckStatus.MATCH, CheckStatus.UNCERTAIN), r.segments.map { it.status })
        assertTrue(r.segments[2].reason, r.segments[2].reason.contains("could not be found"))
    }

    @Test fun aWholeSentenceNotSpokenWithNoRoomBetweenNeighboursIsExtraWord() {
        val (segs0, sp) = chain(
            listOf("First line here today." to "First line here today.", "Last line is here now." to "Last line is here now."),
            gap = 40L
        )
        val segs = listOf(segs0[0], CheckSegment(segs0[0].timestampMs + 2000, "This sentence is never spoken."), segs0[1])
        val r = check(segs, sp)
        assertEquals(CheckStatus.EXTRA_WORD, r.segments[1].status)
        assertEquals(CheckStatus.MATCH, r.segments[0].status)
        assertEquals(CheckStatus.MATCH, r.segments[2].status)
    }

    @Test fun theSameSentenceWithPlentyOfRoomIsOnlyUncertain() {
        val (segs0, sp) = chain(
            listOf("First line here today." to "First line here today.", "Last line is here now." to "Last line is here now."),
            gap = 6000L
        )
        val segs = listOf(segs0[0], CheckSegment(segs0[0].timestampMs + 3000, "This sentence is never spoken."), segs0[1])
        val r = check(segs, sp)
        assertEquals(CheckStatus.UNCERTAIN, r.segments[1].status)
    }

    @Test fun aLineWithNoWordsAndNothingRecognised() {
        var r = check(
            listOf(CheckSegment(0, "..."), CheckSegment(2000, "Hello there friend.")),
            speak("Hello there friend.", 2000)
        )
        assertEquals(CheckStatus.UNCERTAIN, r.segments[0].status)
        assertTrue(r.segments[0].reason.contains("no words"))
        assertEquals(CheckStatus.MATCH, r.segments[1].status)

        r = check(listOf(CheckSegment(0, "Hello there friend."), CheckSegment(3000, "How are you today.")), emptyList())
        assertTrue(r.segments.all { it.status == CheckStatus.UNCERTAIN })
    }

    // ------------------------------------------------------------------------------------------------ matching details

    @Test fun repeatedPhrasesAreNotConfused() {
        val (segs, sp) = chain(
            listOf(
                "Thank you so much." to "Thank you so much.",
                "Thank you so much." to "Thank you so much.",
                "See you next time." to "See you next time."
            )
        )
        val r = check(segs, sp)
        assertTrue(r.segments.all { it.status == CheckStatus.MATCH })
        assertEquals(segs.map { it.timestampMs }, r.segments.map { it.timestamp!!.actualMs })
    }

    @Test fun hindi() {
        val text = "नमस्ते दोस्तों आज हम बात करेंगे"
        assertEquals(CheckStatus.MATCH, one(1000, text, speak(text, 1000)).status)
        val s = one(1000, text, speak("नमस्ते दोस्तों आज हम चर्चा करेंगे", 1000))
        assertEquals(CheckStatus.TEXT_MISMATCH, s.status)
        assertEquals("बात", s.issues[0].transcriptText)
        assertEquals("चर्चा", s.issues[0].audioText)
    }

    // ------------------------------------------------------------------------------------------------ timestamps

    @Test fun everyTimestampThreeSecondsEarly() {
        val (segs, sp) = chain(
            listOf(
                "Welcome back to the channel." to "Welcome back to the channel.",
                "Today we look at the new phone." to "Today we look at the new phone.",
                "It has a great camera." to "It has a great camera."
            ),
            start = 10000L
        )
        val r = check(segs.map { CheckSegment(it.timestampMs - 3000, it.text) }, sp)
        assertTrue(r.segments.all { it.status == CheckStatus.TIMESTAMP_ERROR && it.timestamp!!.diffMs == 3000L })
    }

    @Test fun wholeSecondTimestampsAllowOneSecondButNotThree() {
        val (segs, sp) = chain(
            listOf(
                "alpha beta gamma delta." to "alpha beta gamma delta.",
                "epsilon zeta eta theta." to "epsilon zeta eta theta.",
                "iota kappa lambda sigma." to "iota kappa lambda sigma."
            ),
            start = 2400L, gap = 1500L
        )
        val rounded = segs.map { CheckSegment(Math.round(it.timestampMs / 1000.0) * 1000L, it.text) }
        var r = check(rounded, sp)
        assertTrue(r.wholeSecondTimestamps)
        assertTrue(r.segments.all { it.timestamp!!.toleranceMs == 1000L })
        assertTrue(r.segments.all { it.status == CheckStatus.MATCH })
        r = check(rounded.map { CheckSegment(if (it.timestampMs >= 3000) it.timestampMs - 3000 else it.timestampMs, it.text) }, sp)
        assertTrue(r.segments.any { it.status == CheckStatus.TIMESTAMP_ERROR })
    }

    @Test fun aSegmentThatStartsWithANumberStillGetsAStartTime() {
        val s = one(3000, "2020 was a big year for everyone.", speak("twenty twenty was a big year for everyone", 3000))
        assertEquals(CheckStatus.MATCH, s.status)
        assertTrue(s.timestamp!!.verifiable)
        assertEquals(3000L, s.timestamp!!.actualMs)
    }

    @Test fun aReplacedFirstWordStillLocatesTheStart() {
        val s = one(5000, "Okay let us begin the session today.", speak("Alright let us begin the session today", 8000))
        assertEquals(CheckStatus.TEXT_MISMATCH, s.status)
        assertEquals(8000L, s.timestamp!!.actualMs)
        assertEquals(3000L, s.timestamp!!.diffMs)
    }

    @Test fun aSkippedFirstWordThatWasSpokenIsAllowedForInTheStartTime() {
        val sp = speak("Hello", 7000, conf = 0.3) + speak("everyone welcome back to the show", 7420)
        val s = one(7000, "Hello everyone welcome back to the show", sp)
        val actual = s.timestamp!!.actualMs
        assertNotNull(actual)
        assertTrue("start $actual", Math.abs(actual!! - 7000L) <= 400L)
    }

    @Test fun settingsToleranceAndConfidenceAreHonoured() {
        val text = "alpha beta gamma delta epsilon zeta"
        var s = one(5000, text, speak(text, 5300), CheckSettings(timestampToleranceMs = 200))
        assertEquals(CheckStatus.TIMESTAMP_ERROR, s.status)
        assertEquals(300L, s.timestamp!!.diffMs)
        s = one(5000, text, speak(text, 5300), CheckSettings(timestampToleranceMs = 500))
        assertEquals(CheckStatus.MATCH, s.status)
    }

    // ------------------------------------------------------------------------------------------------ unscripted speech

    @Test fun oneUnscriptedPassageStaysInOneSegment() {
        val segs = listOf(CheckSegment(4000, "Let us begin the lesson."), CheckSegment(12000, "That is all for today."))
        val sp = speak("Let us begin the lesson.", 4000) + speak("by the way subscribe to my channel please", 7000) +
            speak("That is all for today.", 12000)
        val r = check(segs, sp)
        val holders = r.segments.filter { seg -> seg.issues.any { it.kind == CheckStatus.MISSING_WORD } }
        assertEquals(1, holders.size)
        assertEquals("by the way subscribe to my channel please", holders[0].issues[0].audioText)
    }

    @Test fun aLongPauseInsideUnscriptedSpeechLetsItBeShared() {
        val segs = listOf(CheckSegment(4000, "Let us begin the lesson."), CheckSegment(20000, "That is all for today."))
        val sp = speak("Let us begin the lesson.", 4000) + speak("by the way", 7000) + speak("one more thing", 15000) +
            speak("That is all for today.", 20000)
        val r = check(segs, sp)
        assertTrue(r.segments.all { seg -> seg.issues.any { it.kind == CheckStatus.MISSING_WORD } })
    }

    @Test fun speechRightAfterTheLastLineIsReportedButSpeechFarAwayIsNot() {
        val segs = listOf(CheckSegment(1000, "That is all for today."))
        var s = check(segs, speak("That is all for today.", 1000) + speak("thank you", 3300)).segments[0]
        assertEquals(CheckStatus.MISSING_WORD, s.status)
        assertEquals("thank you", s.issues[0].audioText)
        s = check(segs, speak("That is all for today.", 1000) + speak("thank you", 30000)).segments[0]
        assertEquals(CheckStatus.MATCH, s.status)
    }

    // ------------------------------------------------------------------------------------------------ independence and scale

    @Test fun resultsDoNotDependOnEarlierCalls() {
        val (segs, sp) = chain(listOf("The help desk was closed." to "The held desk was closed."))
        val before = check(segs, sp).segments[0].issues.map { Triple(it.kind, it.transcriptText, it.audioText) }
        check(listOf(CheckSegment(0, "alpha beta")), speak("alpha gamma", 0))
        check(listOf(CheckSegment(0, "zebra yak")), speak("zebra xylophone", 0))
        val after = check(segs, sp).segments[0].issues.map { Triple(it.kind, it.transcriptText, it.audioText) }
        assertEquals(before, after)
    }

    @Test fun tokenizerDetails() {
        val text = "Don't stop-believing [music] 1,000 times!"
        assertEquals(listOf("Don't", "stop", "believing", "1,000", "times"), CheckTokenizer.splitWords(text).map { it.first })
        assertEquals(listOf("dont", "stop", "believing", "1000", "times"), CheckTokenizer.splitWords(text).map { it.second })
        assertEquals(listOf("q", "and", "a"), CheckTokenizer.splitWords("Q&A").map { it.second })
        assertEquals(
            listOf("it", "costs", "5", "dollars", "and", "10", "percent"),
            CheckTokenizer.splitWords("It costs \$5 and 10%").map { it.second }
        )
    }

    @Test fun oneHourSixHundredSegmentsTwelveWrongWords() {
        val rnd = Lcg(7)
        val lines = ArrayList<Pair<String, String>>()
        for (i in 0 until 600) {
            val n = 10 + rnd.next(11)
            val w = (0 until n).map { vocab[rnd.next(vocab.size)] + rnd.next(41) }
            val au = w.toMutableList()
            if (i % 50 == 7) au[3] = "zzz"
            lines.add(w.joinToString(" ") to au.joinToString(" "))
        }
        val (segs, sp) = chain(lines)
        val r = check(segs, sp)
        assertEquals(12, r.count(CheckStatus.TEXT_MISMATCH))
        assertEquals(588, r.count(CheckStatus.MATCH))
    }

    @Test fun bandedDpAgreesWithTheExactDp() {
        val rnd = Lcg(5)
        val words = (0 until 500).map { vocab[rnd.next(vocab.size)] + rnd.next(3001) }
        val spoken = words.mapIndexed { k, w -> if (k % 3 == 1) "zq$w" else w }       // every third word wrong: no 3-word anchors survive
        val (segs, sp) = chain((0 until 500 step 10).map { k -> words.subList(k, k + 10).joinToString(" ") to spoken.subList(k, k + 10).joinToString(" ") })
        val exact = check(segs, sp)
        val banded = AccuracyChecker.check(segs, sp, CheckSettings(), 1000L, 40, CheckAligner.MAX_BAND_CELLS)
        assertEquals(exact.segments.map { it.status }, banded.segments.map { it.status })
        assertEquals(exact.wordMatched, banded.wordMatched)
        assertTrue("matched ${exact.wordMatched}", exact.wordMatched > 300)
    }

    @Test fun aGapTooBigEvenForTheBandIsLeftUnpairedWithoutFalseAccusations() {
        val rnd = Lcg(5)
        val words = (0 until 500).map { vocab[rnd.next(vocab.size)] + rnd.next(3001) }
        val spoken = words.mapIndexed { k, w -> if (k % 3 == 1) "zq$w" else w }
        val (segs, sp) = chain((0 until 500 step 10).map { k -> words.subList(k, k + 10).joinToString(" ") to spoken.subList(k, k + 10).joinToString(" ") })
        val r = AccuracyChecker.check(segs, sp, CheckSettings(), 100L, 5, 1000L)
        assertTrue(r.segments.all { it.status == CheckStatus.UNCERTAIN || it.status == CheckStatus.EXTRA_WORD })
    }
}
