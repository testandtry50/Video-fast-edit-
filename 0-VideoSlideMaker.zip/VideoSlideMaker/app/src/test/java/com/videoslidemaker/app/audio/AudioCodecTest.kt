package com.videoslidemaker.app.audio

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AudioCodecTest {
    @Test fun roundTrip() {
        val a = AudioMixSettings(
            useCustomMain = true,
            main = listOf(AudioClip("m1", "content://a", "Voice", 30.0, 2.0, 20.0, 1.5, 1.2f, 0.5, 1.0, muted = true)),
            background = listOf(AudioClip("b1", "content://b", "Song", 100.0, loop = true, autoDuck = false, fitVideo = true)),
            smart = SmartMixSettings(autoDuck = false, duckDb = -9f, autoLevel = false, fadeAtEnd = false, limiter = false)
        )
        assertEquals(a, AudioCodec.decode(AudioCodec.encode(a)))
    }

    @Test fun damagedOrMissingDataGivesDefault() {
        assertEquals(AudioMixSettings(), AudioCodec.decode(null))
        assertEquals(AudioMixSettings(), AudioCodec.decode("{not json"))
    }

    @Test fun legacyMusicBecomesOneQuietLoopingTrack() {
        val a = AudioCodec.fromLegacyMusic("content://m", "song", 0.35f)
        val c = a.background.single()
        assertTrue(c.loop && c.isUnmeasured && !c.autoDuck)
        assertEquals(0.35f, c.volume, 1e-6f)
        assertFalse(a.smart.autoDuck || a.smart.autoLevel || a.smart.fadeAtEnd)
    }

    @Test fun mainClipsAreIgnoredUnlessCustomMainIsOn() {
        val clip = AudioClip("m", "content://a", "a", 10.0)
        assertTrue(AudioMixSettings(main = listOf(clip)).activeMain.isEmpty())
        assertEquals(1, AudioMixSettings(useCustomMain = true, main = listOf(clip)).activeMain.size)
    }
}
