package com.videoslidemaker.app.audio

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AudioCodecTest {
    @Test fun roundTrip() {
        val a = AudioMixSettings(
            useCustomMain = true,
            main = listOf(AudioClip("m1", "content://a", "Voice", 30.0, 2.0, 20.0, 1.5, 1.2f, 0.5, 1.0, muted = true)),
            background = listOf(AudioClip("b1", "content://b", "Song", 100.0, loop = true, autoDuck = false, fitVideo = true)),
            smart = SmartMixSettings(autoDuck = false, duckDb = -9f, autoLevel = false, fadeAtEnd = false, limiter = false)
        )
        assertEquals(a, AudioCodec.decode(AudioCodec.encode(a)))
    }

    @Test fun markedPartKindAndAutoAdjustValuesSurviveSaving() {
        val c = AudioClip(
            "b1", "content://b", "Beat", 180.0, srcStartSec = 72.0, srcEndSec = 76.0, startSec = 4.0, slot = "B1", rangeEndSec = 20.0,
            kind = SoundKind.BEAT, mood = SoundMood.ACTION, markEndSec = 76.0, duckAdjustDb = 3.0, levelDb = -7.0, playOnce = true, exactLoop = true
        )
        val back = AudioCodec.decode(AudioCodec.encode(AudioMixSettings(background = listOf(c)))).background.single()
        assertEquals(c, back)
    }

    @Test fun aProjectSavedBefore219LoadsWithNothingMarkedAndNoKind() {
        val old = """{"useCustomMain":false,"main":[],"background":[{"id":"a","uri":"content://a","name":"song","dur":100.0,"s0":0.0,"s1":100.0,"at":0.0,"vol":1.0,"fi":1.0,"fo":0.0,"mute":false,"loop":false,"duck":true,"fit":true}]}"""
        val c = AudioCodec.decode(old).background.single()
        assertEquals(SoundKind.UNSET, c.kind); assertEquals(SoundMood.NONE, c.mood)
        assertEquals(0.0, c.markEndSec, 0.0); assertEquals(0.0, c.duckAdjustDb, 0.0)
        assertTrue(c.levelDb == null && !c.playOnce && !c.exactLoop && !c.hasMark)
    }

    @Test fun defaultsAreNotWrittenSoAnUntouchedProjectStaysSmall() {
        val text = AudioCodec.encode(AudioMixSettings(background = listOf(AudioClip("a", "content://a", "song", 10.0))))
        for (key in listOf("\"kind\"", "\"mood\"", "\"mark\"", "\"dadj\"", "\"lvl\"", "\"once\"", "\"exact\"")) assertFalse(key, text.contains(key))
    }

    @Test fun damagedKindAndValuesFallBackToTheDefaults() {
        val bad = """{"background":[{"id":"a","uri":"content://a","name":"x","dur":10.0,"kind":"NOPE","mood":7,"mark":-3,"dadj":900,"lvl":-900}]}"""
        val c = AudioCodec.decode(bad).background.single()
        assertEquals(SoundKind.UNSET, c.kind); assertEquals(SoundMood.NONE, c.mood)
        assertEquals(0.0, c.markEndSec, 0.0)
        assertEquals(24.0, c.duckAdjustDb, 0.0)          // held inside its range
        assertEquals(-40.0, c.levelDb!!, 0.0)
    }

    @Test fun damagedOrMissingDataGivesDefault() {
        assertEquals(AudioMixSettings(), AudioCodec.decode(null))
        assertEquals(AudioMixSettings(), AudioCodec.decode("{not json"))
    }

    @Test fun legacyMusicBecomesOneQuietLoopingTrack() {
        val a = AudioCodec.fromLegacyMusic("content://m", "song", 0.35f)
        val c = a.background.single()
        assertTrue(c.loop && c.isUnmeasured && !c.autoDuck)
        assertEquals(0.35f, c.volume, 1e-6f)
        assertFalse(a.smart.autoDuck || a.smart.autoLevel || a.smart.fadeAtEnd)
    }

    @Test fun mainClipsAreIgnoredUnlessCustomMainIsOn() {
        val clip = AudioClip("m", "content://a", "a", 10.0)
        assertTrue(AudioMixSettings(main = listOf(clip)).activeMain.isEmpty())
        assertEquals(1, AudioMixSettings(useCustomMain = true, main = listOf(clip)).activeMain.size)
    }
}
