package com.videoslidemaker.app.ui

import com.videoslidemaker.app.ui.components.fastScrollFractionFor
import com.videoslidemaker.app.ui.components.fastScrollIndexFor
import org.junit.Assert.assertEquals
import org.junit.Test

/** The numbers behind the fast-scroll handle: where a finger jumps to, and where the handle sits. */
class FastScrollMathTest {

    @Test
    fun fingerAtTopAndBottomReachesFirstAndLastItem() {
        assertEquals(0, fastScrollIndexFor(0f, 640))
        assertEquals(639, fastScrollIndexFor(1f, 640))
    }

    @Test
    fun fingerInTheMiddleLandsInTheMiddle() {
        assertEquals(320, fastScrollIndexFor(0.5f, 641))
    }

    @Test
    fun outOfRangeFractionsAndEmptyListsAreSafe() {
        assertEquals(0, fastScrollIndexFor(-0.5f, 100))
        assertEquals(99, fastScrollIndexFor(1.7f, 100))
        assertEquals(0, fastScrollIndexFor(0.5f, 0))
        assertEquals(0, fastScrollIndexFor(0.5f, 1))
    }

    @Test
    fun handleFollowsTheFirstVisibleItem() {
        assertEquals(0f, fastScrollFractionFor(0, 101, atEnd = false), 0.0001f)
        assertEquals(0.5f, fastScrollFractionFor(50, 101, atEnd = false), 0.0001f)
    }

    @Test
    fun handleSitsAtTheBottomWhenTheListCannotScrollFurther() {
        // A grid's first visible item never reaches the last index, but the handle still has to.
        assertEquals(1f, fastScrollFractionFor(97, 100, atEnd = true), 0.0001f)
    }

    @Test
    fun tinyListsDoNotDivideByZero() {
        assertEquals(0f, fastScrollFractionFor(0, 1, atEnd = false), 0.0001f)
        assertEquals(0f, fastScrollFractionFor(0, 0, atEnd = false), 0.0001f)
    }
}
