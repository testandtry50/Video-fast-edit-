package com.videoslidemaker.app.audio

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ClipEditTest {
    private fun clip(id: String, start: Double = 0.0, s0: Double = 0.0, s1: Double = 10.0) =
        AudioClip(id = id, uri = "content://x/$id", name = id, sourceDurationSec = maxOf(s1, 60.0), srcStartSec = s0, srcEndSec = s1, startSec = start)

    @Test fun trimStartKeepsTimelinePlaceAndShortens() {
        val c = ClipEdit.trimStart(clip("a", s1 = 60.0), 10.0)
        assertEquals(0.0, c.startSec, 1e-9); assertEquals(50.0, c.lengthSec, 1e-9)
    }

    @Test fun trimsAreClamped() {
        val a = clip("a", s1 = 60.0)
        assertTrue(ClipEdit.trimStart(a, 999.0).lengthSec >= AudioLimits.MIN_CLIP_SEC - 1e-9)
        assertEquals(60.0, ClipEdit.trimEnd(a, 999.0).srcEndSec, 1e-9)
        assertTrue(ClipEdit.trimEnd(a, -5.0).srcEndSec >= AudioLimits.MIN_CLIP_SEC)
    }

    @Test fun splitMakesTwoClipsCoveringTheSameAudio() {
        val p = ClipEdit.split(clip("a", s1 = 60.0), 20.0, "b")
        assertEquals(2, p.size)
        assertEquals(20.0, p[0].lengthSec, 1e-9); assertEquals(40.0, p[1].lengthSec, 1e-9)
        assertEquals(20.0, p[1].startSec, 1e-9); assertEquals(20.0, p[1].srcStartSec, 1e-9)
        assertEquals(1, ClipEdit.split(clip("a", s1 = 60.0), 0.01, "b").size)
    }

    @Test fun cutCloseGapSlidesLaterClipsLeft() {
        val a = clip("a", s1 = 60.0); val b = clip("b", start = 60.0, s1 = 30.0)
        val r = ClipEdit.cutInTrack(listOf(a, b), "a", 10.0, 20.0, true, "a2")
        assertEquals(listOf("a", "a2", "b"), r.map { it.id })
        assertEquals(10.0, r[1].startSec, 1e-9); assertEquals(50.0, r[2].startSec, 1e-9)
        assertEquals(50.0, r[0].lengthSec + r[1].lengthSec, 1e-9)
    }

    @Test fun cutKeepingGapLeavesSilence() {
        val r = ClipEdit.cutInTrack(listOf(clip("a", s1 = 60.0), clip("b", start = 60.0, s1 = 30.0)), "a", 10.0, 20.0, false, "a2")
        assertEquals(20.0, r[1].startSec, 1e-9); assertEquals(60.0, r[2].startSec, 1e-9)
    }

    @Test fun cutFromTheStartKeepsTheId() {
        val r = ClipEdit.cutInTrack(listOf(clip("a", s1 = 60.0)), "a", 0.0, 20.0, true, "x")
        assertEquals(1, r.size); assertEquals("a", r[0].id); assertEquals(40.0, r[0].lengthSec, 1e-9); assertEquals(0.0, r[0].startSec, 1e-9)
    }

    @Test fun cutToTheEndAndTinyCutsAndSwappedBounds() {
        val a = clip("a", s1 = 60.0)
        assertEquals(40.0, ClipEdit.cutInTrack(listOf(a), "a", 40.0, 60.0, false, "x").single().lengthSec, 1e-9)
        assertEquals(60.0, ClipEdit.cutInTrack(listOf(a), "a", 5.0, 5.01, true, "x").single().lengthSec, 1e-9)
        assertEquals(2, ClipEdit.cutInTrack(listOf(a), "a", 20.0, 10.0, true, "x").size)
    }

    @Test fun combineJoinsInTimeOrder() {
        val c = ClipEdit.combine(listOf(clip("b", 50.0, s1 = 5.0), clip("a", 10.0, s1 = 10.0), clip("c", 200.0, s1 = 2.0)))
        assertEquals(listOf("a" to 10.0, "b" to 20.0, "c" to 25.0), c.map { it.id to it.startSec })
    }

    @Test fun swapKeepsThePairInPlace() {
        val r = ClipEdit.swapWithNeighbour(listOf(clip("a", 0.0, s1 = 4.0), clip("b", 4.0, s1 = 6.0)), "b", false)
        assertEquals(0.0, r.first { it.id == "b" }.startSec, 1e-9); assertEquals(6.0, r.first { it.id == "a" }.startSec, 1e-9)
    }

    @Test fun fitToVideoTrimsLongAndLoopsShort() {
        val long = ClipEdit.fitToVideo(clip("a", s1 = 120.0), 60.0)
        assertEquals(60.0, long.lengthSec, 1e-9); assertTrue(!long.loop); assertTrue(long.fadeOutSec > 0.0)
        assertTrue(ClipEdit.fitToVideo(clip("a", s1 = 20.0), 60.0).loop)
    }

    @Test fun fitVideoFollowsTheVideoBothWays() {
        val song = AudioClip("s", "content://s", "s", 100.0, fitVideo = true, startSec = 30.0)
        val short = ClipEdit.followVideo(song, 40.0)
        assertEquals(0.0, short.startSec, 1e-9); assertEquals(40.0, short.lengthSec, 1e-9); assertTrue(!short.loop)
        val longer = ClipEdit.followVideo(song, 300.0)
        assertTrue(longer.loop)
        // the stored clip is never changed, so growing the video again works
        assertEquals(100.0, song.lengthSec, 1e-9)
        assertEquals(song, ClipEdit.followVideo(song.copy(fitVideo = false), 40.0))
    }
}
