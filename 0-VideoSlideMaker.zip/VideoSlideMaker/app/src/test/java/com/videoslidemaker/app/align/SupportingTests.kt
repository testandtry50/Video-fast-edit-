package com.videoslidemaker.app.align

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.PI
import kotlin.math.sin

class EnergyFrameExtractorTest {

    @Test fun oneMinuteIsExactlySixThousandFramesAtAnySampleRate() {
        // 22 050 and 44 100 Hz are not multiples of 100 per frame; rounding must not accumulate.
        for (rate in listOf(8000, 16000, 22050, 44100, 48000)) {
            val e = EnergyFrameExtractor(rate)
            val chunk = FloatArray(rate) // one second of silence
            repeat(60) { e.push(chunk, chunk.size) }
            assertEquals("sample rate $rate", 6000, e.finish().size)
        }
    }

    @Test fun aToneShowsUpInTheRightFrames() {
        val rate = 22050
        val e = EnergyFrameExtractor(rate)
        val total = rate * 5
        val audio = FloatArray(total) { i ->
            val t = i.toDouble() / rate
            if (t in 2.0..3.0) (0.5 * sin(2.0 * PI * 1000.0 * t)).toFloat() else 0f
        }
        e.push(audio, audio.size)
        val frames = e.finish()
        assertEquals(500, frames.size)
        assertTrue("frame 150 should be silent", frames[150] < -80f)
        assertTrue("frame 250 should be loud", frames[250] > -15f)
        assertTrue("frame 350 should be silent", frames[350] < -80f)
        // the rise must land within a frame or two of 2.000 s
        val firstLoud = frames.indexOfFirst { it > -30f }
        assertTrue("tone starts at frame $firstLoud, expected ~200", firstLoud in 199..202)
    }

    @Test fun chunkBoundariesDoNotChangeTheResult() {
        val rate = 16000
        val audio = FloatArray(rate * 3) { i -> (0.3 * sin(2.0 * PI * 400.0 * i / rate)).toFloat() }
        val whole = EnergyFrameExtractor(rate).also { it.push(audio, audio.size) }.finish()
        val pieces = EnergyFrameExtractor(rate).also { e ->
            var pos = 0
            val sizes = listOf(1, 7, 1000, 333, 4096)
            var k = 0
            while (pos < audio.size) {
                val n = minOf(sizes[k % sizes.size], audio.size - pos)
                e.push(audio.copyOfRange(pos, pos + n), n)
                pos += n
                k++
            }
        }.finish()
        assertEquals(whole.size, pieces.size)
        for (i in whole.indices) assertEquals(whole[i], pieces[i], 1e-3f)
    }
}

class AlignmentApplierTest {

    @Test fun appliesSafeChanges() {
        val plan = AlignmentApplier.plan(longArrayOf(1000, 5000, 9000), mapOf(1 to 5500L))
        assertEquals(mapOf(1 to 5500L), plan.accepted)
        assertTrue(plan.rejected.isEmpty())
    }

    @Test fun refusesAChangeThatWouldReorderLines() {
        val plan = AlignmentApplier.plan(longArrayOf(1000, 5000, 9000), mapOf(1 to 9500L))
        assertTrue(plan.accepted.isEmpty())
        assertEquals(listOf(1), plan.rejected)
    }

    @Test fun refusesAChangeThatSquashesLinesTogether() {
        val plan = AlignmentApplier.plan(longArrayOf(1000, 5000, 9000), mapOf(1 to 8950L))
        assertTrue(plan.accepted.isEmpty())
    }

    @Test fun neighbouringChangesAreJudgedTogether() {
        // both move forward by 1 s: fine together, even though each would clash with the other's OLD time
        val plan = AlignmentApplier.plan(longArrayOf(1000, 2000, 3000), mapOf(0 to 2000L, 1 to 3000L, 2 to 4000L))
        assertEquals(3, plan.accepted.size)
    }

    @Test fun ignoresNoOpsAndBadIndexes() {
        val plan = AlignmentApplier.plan(longArrayOf(1000, 5000), mapOf(0 to 1000L, 7 to 100L, 1 to -5L))
        assertTrue(plan.accepted.isEmpty())
    }
}

class AlignmentFormatTest {
    @Test fun signedSeconds() {
        assertEquals("+1.430 s", AlignmentFormat.signedSeconds(1430))
        assertEquals("-0.250 s", AlignmentFormat.signedSeconds(-250))
        assertEquals("0.000 s", AlignmentFormat.signedSeconds(0))
        assertEquals("+12.005 s", AlignmentFormat.signedSeconds(12005))
    }

    @Test fun clockMatchesTheBriefsExample() {
        assertEquals("00:01:24.000", AlignmentFormat.clock(84_000))
        assertEquals("00:01:25.430", AlignmentFormat.clock(85_430))
    }
}

class TextUnitsTest {
    @Test fun longerTextTakesLonger() {
        assertTrue(TextUnits.of("Hello everyone, welcome to the show") > TextUnits.of("Hello"))
    }

    @Test fun neverZero() {
        assertEquals(1.0, TextUnits.of(""), 1e-9)
        assertEquals(1.0, TextUnits.of("..."), 1e-9)
    }

    @Test fun digitsCountOneUnitEach() {
        assertEquals(4.0, TextUnits.of("2024"), 1e-9)
    }

    @Test fun hasContentOnlyForRealText() {
        assertTrue(TextUnits.hasContent("Hi"))
        assertTrue(TextUnits.hasContent("आदमी"))
        assertFalse(TextUnits.hasContent("  ... "))
        assertFalse(TextUnits.hasContent(""))
    }

    @Test fun devanagariIsMeasuredToo() {
        assertTrue(TextUnits.of("आदमी ने खाना खाया") > 3.0)
    }
}
