package com.videoslidemaker.app.align

import java.util.Random
import kotlin.math.PI
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin

/**
 * Deterministic speech-like test audio with KNOWN true start/end times, so the aligner can be
 * checked against ground truth. Each line is a voiced harmonic source with a 4–5.5 Hz syllable
 * envelope (like real speech's rhythm), separated by random pauses, over a noise floor.
 */
class SyntheticSpeech(
    val texts: List<String>,
    val startMs: LongArray,
    val endMs: LongArray,
    /** 10 ms loudness frames, exactly as the app computes them from a decoded recording */
    val frames: FloatArray,
    val totalMs: Long
) {
    companion object {
        const val SAMPLE_RATE = 8000
        private val WORDS = listOf(
            "the", "quick", "brown", "fox", "jumps", "over", "lazy", "dog", "and", "then", "runs",
            "away", "from", "every", "hunter", "who", "wonders", "where", "it", "went", "today"
        )

        private fun syllables(text: String): Int {
            var count = 0
            var inGroup = false
            for (c in text) {
                if (c in "aeiouyAEIOUY") {
                    if (!inGroup) count++
                    inGroup = true
                } else inGroup = false
            }
            return max(1, count)
        }

        fun generate(seed: Long, minutes: Int, noiseDb: Double = -50.0, meanGapMs: Double = 700.0): SyntheticSpeech {
            val rnd = Random(seed)
            val texts = ArrayList<String>()
            val starts = ArrayList<Long>()
            val ends = ArrayList<Long>()
            var t = 1000L + rnd.nextInt(3000)
            val limit = minutes * 60_000L - 10_000L
            while (t < limit) {
                val k = 3 + rnd.nextInt(11)
                val words = (0 until k).map { WORDS[rnd.nextInt(WORDS.size)] }
                val text = words.joinToString(" ").replaceFirstChar { it.uppercase() } + "."
                val dur = (syllables(text) / 4.6 * (0.8 + 0.4 * rnd.nextDouble()) * 1000.0).toLong()
                texts.add(text)
                starts.add(t)
                ends.add(t + dur)
                val gap = max(250L, (-ln(1.0 - rnd.nextDouble()) * meanGapMs).toLong())
                t += dur + gap
            }
            val total = t + 5000L
            val n = (total * SAMPLE_RATE / 1000L).toInt()
            val audio = FloatArray(n)
            val noiseAmp = 10.0.pow(noiseDb / 20.0)
            for (i in 0 until n) audio[i] = (rnd.nextGaussian() * noiseAmp).toFloat()

            for (idx in texts.indices) {
                val voice = voice((ends[idx] - starts[idx]), rnd)
                val offset = (starts[idx] * SAMPLE_RATE / 1000L).toInt()
                for (i in voice.indices) {
                    if (offset + i < n) audio[offset + i] += voice[i]
                }
            }
            val extractor = EnergyFrameExtractor(SAMPLE_RATE)
            extractor.push(audio, audio.size)
            return SyntheticSpeech(texts, starts.toLongArray(), ends.toLongArray(), extractor.finish(), total)
        }

        private fun voice(durMs: Long, rnd: Random): FloatArray {
            val n = (durMs * SAMPLE_RATE / 1000L).toInt()
            val out = DoubleArray(n)
            val p0 = rnd.nextDouble() * 6.0
            val p1 = rnd.nextDouble() * 6.0
            val rate = 4.0 + 1.5 * rnd.nextDouble()
            var phase = 0.0
            var peak = 1e-9
            for (i in 0 until n) {
                val tSec = i.toDouble() / SAMPLE_RATE
                val f = 120.0 * (1.0 + 0.08 * sin(2.0 * PI * 0.7 * tSec + p0))
                phase += 2.0 * PI * f / SAMPLE_RATE
                var sig = 0.0
                for (h in 1..12) sig += sin(h * phase) / h.toDouble().pow(0.8)
                var env = 0.55 + 0.45 * sin(2.0 * PI * rate * tSec + p1)
                env = min(1.0, max(0.05, env)).pow(1.3)
                val fade = (0.02 * SAMPLE_RATE).toInt()
                val w = when {
                    i < fade -> i.toDouble() / fade
                    i >= n - fade -> (n - 1 - i).toDouble() / fade
                    else -> 1.0
                }
                out[i] = sig * env * w
                if (kotlin.math.abs(out[i]) > peak) peak = kotlin.math.abs(out[i])
            }
            val gain = 0.1 * (0.6 + 0.8 * rnd.nextDouble()) / peak
            return FloatArray(n) { (out[it] * gain).toFloat() }
        }
    }
}
