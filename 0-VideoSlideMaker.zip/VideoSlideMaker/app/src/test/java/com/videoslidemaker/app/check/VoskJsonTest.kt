package com.videoslidemaker.app.check

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class VoskJsonTest {

    private val sample = """
        {"result":[
          {"conf":0.99,"end":0.38,"start":0.00,"word":"hello"},
          {"conf":0.97,"end":0.92,"start":0.42,"word":"everyone"},
          {"conf":0.95,"end":1.46,"start":0.96,"word":"welcome"},
          {"conf":0.99,"end":1.88,"start":1.50,"word":"to"},
          {"conf":0.98,"end":2.30,"start":1.92,"word":"our"},
          {"conf":0.91,"end":2.72,"start":2.34,"word":"show"}
        ],"text":"hello everyone welcome to our show"}
    """.trimIndent()

    @Test fun readsWordsTimesAndConfidence_andAddsTheRecordingOffset() {
        val words = VoskJson.parseWords(sample, offsetMs = 2000L)
        assertEquals(6, words.size)
        assertEquals("hello", words[0].text)
        assertEquals(2000L, words[0].startMs)
        assertEquals(2380L, words[0].endMs)
        assertEquals(0.99, words[0].conf, 1e-9)
        assertEquals("show", words[5].text)
        assertEquals(4340L, words[5].startMs)
        assertEquals(4720L, words[5].endMs)
        assertEquals(0.91, words[5].conf, 1e-9)
    }

    @Test fun nothingUsableGivesNoWordsInsteadOfAnError() {
        assertTrue(VoskJson.parseWords(null, 0).isEmpty())
        assertTrue(VoskJson.parseWords("", 0).isEmpty())
        assertTrue(VoskJson.parseWords("not json at all", 0).isEmpty())
        assertTrue(VoskJson.parseWords("""{"text":""}""", 0).isEmpty())
        assertTrue(VoskJson.parseWords("""{"result":[]}""", 0).isEmpty())
    }

    @Test fun aWordWithoutConfidenceIsTrustedAndAnEndBeforeTheStartIsRepaired() {
        val words = VoskJson.parseWords("""{"result":[{"word":"hi","start":1.0,"end":0.5}]}""", 0)
        assertEquals(1, words.size)
        assertEquals(1.0, words[0].conf, 1e-9)
        assertEquals(1000L, words[0].startMs)
        assertEquals(1000L, words[0].endMs)
    }

    /** Everything except the native Vosk engine: its JSON -> words -> the checker -> the exact place in the audio. */
    @Test fun endToEnd_theBriefsProgramBecomesShow() {
        val words = VoskJson.parseWords(sample, offsetMs = 2000L)
        val r = AccuracyChecker.check(listOf(CheckSegment(2000L, "Hello everyone, welcome to our program.")), words)
        val s = r.segments[0]
        assertEquals(CheckStatus.TEXT_MISMATCH, s.status)
        assertEquals("program", s.issues[0].transcriptText)
        assertEquals("show", s.issues[0].audioText)
        assertEquals(4340L, s.issues[0].audioStartMs)
        assertEquals(4720L, s.issues[0].audioEndMs)
        assertEquals(4340L, s.jumpMs)
    }

    @Test fun endToEnd_aLateSegmentIsATimestampError() {
        val words = VoskJson.parseWords(sample, offsetMs = 8120L)
        val r = AccuracyChecker.check(listOf(CheckSegment(5000L, "Hello everyone, welcome to our show.")), words)
        val s = r.segments[0]
        assertEquals(CheckStatus.TIMESTAMP_ERROR, s.status)
        assertEquals(3120L, s.timestamp!!.diffMs)
        assertEquals(8120L, s.timestamp!!.correctedMs)
    }
}
