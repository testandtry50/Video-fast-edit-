package com.videoslidemaker.app.ui.theme

import androidx.compose.ui.graphics.Color
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ColorMathTest {

    @Test
    fun blackOnWhiteIsTwentyOneToOne() {
        assertEquals(21.0, contrastRatio(Color(0xFFFFFFFF), Color(0xFF000000)), 1e-6)
        assertEquals(1.0, contrastRatio(Color(0xFF808080), Color(0xFF808080)), 1e-9)
        assertEquals(1.0, relativeLuminance(Color(0xFFFFFFFF)), 1e-9)
        assertEquals(0.0, relativeLuminance(Color(0xFF000000)), 1e-9)
    }

    @Test
    fun hslRoundTripKeepsTheColour() {
        for (argb in listOf(0xFF86B4F2L, 0xFF2459A6L, 0xFFF29AB8L, 0xFF123456L, 0xFFFFCA5CL, 0xFF808080L)) {
            val c = Color(argb)
            val hsl = c.toHsl()
            val back = hslColor(hsl.h, hsl.s, hsl.l)
            assertEquals(c.red, back.red, 0.004f)
            assertEquals(c.green, back.green, 0.004f)
            assertEquals(c.blue, back.blue, 0.004f)
        }
    }

    @Test
    fun fitColorLeavesAGoodColourAlone() {
        val base = Color(0xFFF0F0F0)
        val dark = Color(0xFF111111)
        assertEquals(base, fitColor(base, towardLight = true, target = 4.5) { listOf(dark) })
    }

    @Test
    fun fitColorLightensUntilItReadsOnDark() {
        val base = Color(0xFF2A3A8A) // a deep blue: far too dark for a dark page
        val page = Color(0xFF131313)
        val fitted = fitColor(base, towardLight = true, target = 4.55) { listOf(page) }
        assertTrue("ratio is ${contrastRatio(fitted, page)}", contrastRatio(fitted, page) >= 4.55)
        // it is still the same blue-ish hue, only lighter
        assertEquals(base.toHsl().h, fitted.toHsl().h, 3.0)
    }

    @Test
    fun fitColorDarkensUntilItReadsOnLight() {
        val base = Color(0xFFF2E266) // a bright yellow: unreadable on a light page
        val page = Color(0xFFF4F2EE)
        val fitted = fitColor(base, towardLight = false, target = 4.55) { listOf(page) }
        assertTrue("ratio is ${contrastRatio(fitted, page)}", contrastRatio(fitted, page) >= 4.55)
        assertEquals(base.toHsl().h, fitted.toHsl().h, 3.0)
    }

    @Test
    fun fitColorCountsTheColoursOwnTintedBackground() {
        val page = Color(0xFF131313)
        val fitted = fitColor(Color(0xFF3A5FCD), towardLight = true, target = 4.55) { c ->
            listOf(page, blendOver(c, 0.15f, page))
        }
        assertTrue(contrastRatio(fitted, page) >= 4.55)
        assertTrue(contrastRatio(fitted, blendOver(fitted, 0.15f, page)) >= 4.55)
    }

    @Test
    fun readableOnPicksTheBetterTextColour() {
        val soft = Color(0xFF0E0E0E)
        // light blue: the soft black reads fine, so it is kept
        assertEquals(soft, readableOn(Color(0xFF86B4F2), soft))
        // a mid grey where soft black is too weak: white or black must be used and must read at 4.5:1
        val mid = Color(0xFF7F7F7F)
        val picked = readableOn(mid, soft)
        assertTrue("ratio ${contrastRatio(picked, mid)}", contrastRatio(picked, mid) >= 4.5)
    }
}
