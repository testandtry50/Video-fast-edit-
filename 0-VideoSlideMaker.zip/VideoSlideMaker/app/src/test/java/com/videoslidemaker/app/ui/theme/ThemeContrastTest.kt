package com.videoslidemaker.app.ui.theme

import androidx.compose.ui.graphics.Color
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.pow

/**
 * Guards readability. Builds EVERY look the app can show - each of the 7 dark styles and 6 light styles, with and
 * without high contrast, for every accent preset AND custom accents at every 15 degrees of the colour wheel - and
 * checks the WCAG contrast ratios:
 *   - text and accent colours on every background  >= 4.5:1 (>= 7:1 for text in high contrast)
 *   - status colours (green / yellow / red)         >= 4.5:1
 *   - outlines of tappable things                   >= 3:1
 *   - text on the tinted alert / badge / chip fills  >= 4.5:1
 *   - the default looks keep their original colours; light styles are never glaring white, dark text never pure white
 * If you change a value in Color.kt or Appearance.kt and one of these fails, the message tells
 * you which pair and which theme. (tools/theme-reference/palette_check.py runs the same checks in Python.)
 */
class ThemeContrastTest {

    private fun channel(c: Float): Double {
        val v = c.toDouble()
        return if (v <= 0.03928) v / 12.92 else ((v + 0.055) / 1.055).pow(2.4)
    }

    private fun luminance(c: Color): Double =
        0.2126 * channel(c.red) + 0.7152 * channel(c.green) + 0.0722 * channel(c.blue)

    private fun ratio(a: Color, b: Color): Double {
        val la = luminance(a)
        val lb = luminance(b)
        return (maxOf(la, lb) + 0.05) / (minOf(la, lb) + 0.05)
    }

    /** [fg] drawn at [alpha] on top of [bg] - how the tinted boxes actually look. */
    private fun over(fg: Color, alpha: Float, bg: Color): Color = Color(
        red = fg.red * alpha + bg.red * (1f - alpha),
        green = fg.green * alpha + bg.green * (1f - alpha),
        blue = fg.blue * alpha + bg.blue * (1f - alpha)
    )

    private fun allLooks(): List<Pair<String, AppColors>> {
        val looks = ArrayList<Pair<String, AppColors>>()
        for (highContrast in listOf(false, true)) {
            val hc = if (highContrast) "+highContrast" else ""
            for (style in DarkStyle.entries) {
                for (accent in AccentChoice.entries) {
                    val prefs = AppearancePrefs(darkStyle = style, accent = accent, highContrast = highContrast)
                    looks.add("dark/${style.label}$hc/${accent.label}" to buildAppColors(true, prefs))
                }
                for (hue in 0 until 360 step 15) {
                    val prefs = AppearancePrefs(
                        darkStyle = style, accent = AccentChoice.CUSTOM, customHue = hue, highContrast = highContrast
                    )
                    looks.add("dark/${style.label}$hc/custom$hue" to buildAppColors(true, prefs))
                }
            }
            for (style in LightStyle.entries) {
                for (accent in AccentChoice.entries) {
                    val prefs = AppearancePrefs(lightStyle = style, accent = accent, highContrast = highContrast)
                    looks.add("light/${style.label}$hc/${accent.label}" to buildAppColors(false, prefs))
                }
                for (hue in 0 until 360 step 15) {
                    val prefs = AppearancePrefs(
                        lightStyle = style, accent = AccentChoice.CUSTOM, customHue = hue, highContrast = highContrast
                    )
                    looks.add("light/${style.label}$hc/custom$hue" to buildAppColors(false, prefs))
                }
            }
        }
        return looks
    }

    private fun check(look: String, what: String, fg: Color, bg: Color, minimum: Double) {
        val r = ratio(fg, bg)
        assertTrue("$look: $what is only ${"%.2f".format(r)}:1 (needs $minimum:1)", r >= minimum)
    }

    @Test
    fun textAndAccentAreReadableOnEveryBackground() {
        for ((look, c) in allLooks()) {
            val textMin = if (look.contains("highContrast")) 7.0 else 4.5
            for ((bgName, bg) in listOf("page" to c.bg, "bar" to c.surface, "card" to c.card)) {
                check(look, "main text on $bgName", c.textMain, bg, textMin)
                check(look, "muted text on $bgName", c.muted, bg, textMin)
                check(look, "accent on $bgName", c.accent, bg, 4.5)
                check(look, "green on $bgName", c.green, bg, 4.5)
                check(look, "yellow on $bgName", c.yellow, bg, 4.5)
                check(look, "red on $bgName", c.red, bg, 4.5)
                check(look, "outline on $bgName", c.outline, bg, 3.0)
            }
        }
    }

    @Test
    fun textOnSolidFillsIsReadable() {
        for ((look, c) in allLooks()) {
            check(look, "text on accent button", c.onAccent, c.accent, 4.5)
            check(look, "tick on green", c.onStatus, c.green, 4.5)
            check(look, "disabled button text", c.muted, c.surface, 4.5)
        }
    }

    @Test
    fun textOnTintedBoxesIsReadable() {
        for ((look, c) in allLooks()) {
            check(look, "yellow warning text", c.yellow, over(c.yellow, 0.10f, c.card), 4.5)
            check(look, "green success text", c.green, over(c.green, 0.10f, c.card), 4.5)
            check(look, "info text", c.textMain, over(c.accent, 0.12f, c.card), 4.5)
            check(look, "accent time chip", c.accent, over(c.accent, 0.15f, c.card), 4.5)
            check(look, "accent badge", c.accent, over(c.accent, 0.13f, c.bg), 4.5)
            check(look, "green badge", c.green, over(c.green, 0.13f, c.bg), 4.5)
            check(look, "yellow badge", c.yellow, over(c.yellow, 0.13f, c.bg), 4.5)
            check(look, "selected chip text", c.textMain, over(c.accent, 0.22f, c.surface), 4.5)
        }
    }

    @Test
    fun theTwoPlainDarkStylesAreNeutralGreyNotPurple() {
        // The original dark theme had a blue/purple cast. Charcoal and Pure black must have equal red, green and blue
        // so there is no tint at all. (The other dark styles - Midnight, Forest, Mocha, Plum, Slate - are tinted on purpose.)
        for (style in listOf(DarkStyle.CHARCOAL, DarkStyle.BLACK)) {
            val c = buildAppColors(true, AppearancePrefs(darkStyle = style))
            for (surface in listOf(c.bg, c.surface, c.card, c.border)) {
                assertEquals(surface.red, surface.green, 0.004f)
                assertEquals(surface.green, surface.blue, 0.004f)
            }
        }
    }

    private fun hueDegrees(c: Color): Double {
        val r = c.red.toDouble()
        val g = c.green.toDouble()
        val b = c.blue.toDouble()
        val max = maxOf(r, g, b)
        val d = max - minOf(r, g, b)
        if (d < 1e-6) return 0.0
        val sector = when (max) {
            r -> ((g - b) / d) % 6.0
            g -> (b - r) / d + 2.0
            else -> (r - g) / d + 4.0
        }
        val deg = sector * 60.0
        return if (deg < 0.0) deg + 360.0 else deg
    }

    @Test
    fun theDefaultLooksKeepTheirOriginalColours() {
        // People who never open Appearance must see exactly what they saw before this upgrade.
        val dark = buildAppColors(true, AppearancePrefs())
        assertEquals(Color(0xFF131313), dark.bg)
        assertEquals(Color(0xFF222222), dark.card)
        assertEquals(Color(0xFF86B4F2), dark.accent)
        assertEquals(Color(0xFF0E0E0E), dark.onAccent)
        val light = buildAppColors(false, AppearancePrefs())
        assertEquals(Color(0xFFF4F2EE), light.bg)
        assertEquals(Color(0xFFFBFAF8), light.card)
        assertEquals(Color(0xFF2459A6), light.accent)
        assertEquals(Color(0xFFFFFFFF), light.onAccent)
    }

    @Test
    fun theOriginalFiveAccentsAreNotNudged() {
        for (choice in listOf(AccentChoice.BLUE, AccentChoice.TEAL, AccentChoice.SAGE, AccentChoice.ORANGE, AccentChoice.ROSE)) {
            assertEquals(choice.label, choice.darkTone, buildAppColors(true, AppearancePrefs(accent = choice)).accent)
            assertEquals(choice.label, choice.lightTone, buildAppColors(false, AppearancePrefs(accent = choice)).accent)
        }
    }

    @Test
    fun everyAccentPresetIsADifferentColour() {
        val presets = AccentChoice.entries.filter { it != AccentChoice.CUSTOM }
        assertTrue("there should be a full range of colours", presets.size >= 18)
        for (a in presets.indices) {
            for (b in a + 1 until presets.size) {
                assertTrue(
                    "${presets[a].label} and ${presets[b].label} look the same",
                    presets[a].darkTone != presets[b].darkTone && presets[a].lightTone != presets[b].lightTone
                )
            }
        }
    }

    @Test
    fun customAccentFollowsTheHue() {
        for (hue in listOf(0, 45, 90, 135, 180, 225, 270, 315)) {
            for (dark in listOf(true, false)) {
                val tone = customAccentTone(hue, dark)
                var diff = Math.abs(hueDegrees(tone) - hue)
                if (diff > 180.0) diff = 360.0 - diff
                assertTrue("hue $hue (dark=$dark) came out as ${"%.0f".format(hueDegrees(tone))}", diff < 3.0)
            }
        }
    }

    @Test
    fun accentsCoverTheWholeColourWheel() {
        // No gap bigger than 60 degrees between the hues of the coloured presets.
        val hues = AccentChoice.entries
            .filter { it != AccentChoice.CUSTOM && it != AccentChoice.BROWN && it != AccentChoice.SLATE }
            .map { hueDegrees(it.darkTone) }
            .sorted()
        var widest = 360.0 - hues.last() + hues.first()
        for (i in 1 until hues.size) widest = maxOf(widest, hues[i] - hues[i - 1])
        assertTrue("widest gap on the colour wheel is ${"%.0f".format(widest)} degrees", widest <= 60.0)
    }

    @Test
    fun lightPalettesAreCalmNotGlaring() {
        // Big pure-white areas and pure-black text are what tire the eyes: no light style may use either.
        for (style in LightStyle.entries) {
            val c = buildAppColors(false, AppearancePrefs(lightStyle = style))
            for ((name, surface) in listOf("page" to c.bg, "bar" to c.surface, "card" to c.card)) {
                assertTrue("${style.label}: $name must not be pure white", luminance(surface) < 0.97)
            }
            assertTrue("${style.label}: main text must not be pure black", luminance(c.textMain) > 0.005)
            assertTrue("${style.label}: main text should stay under 15:1 on the page", ratio(c.textMain, c.bg) < 15.0)
        }
    }

    @Test
    fun darkTextIsSoftNotPureWhite() {
        for (style in DarkStyle.entries) {
            val c = buildAppColors(true, AppearancePrefs(darkStyle = style))
            assertTrue("${style.label}: dark main text must not be pure white", luminance(c.textMain) < 0.9)
        }
    }

    @Test
    fun everyStyleLooksDifferentFromTheOthers() {
        val darkBgs = DarkStyle.entries.map { it.palette.bg }
        assertEquals(darkBgs.size, darkBgs.toSet().size)
        val lightBgs = LightStyle.entries.map { it.palette.bg }
        assertEquals(lightBgs.size, lightBgs.toSet().size)
        assertTrue("need several dark styles", DarkStyle.entries.size >= 5)
        assertTrue("need several light styles", LightStyle.entries.size >= 4)
    }

    @Test
    fun resolveDarkFollowsTheSystemOnlyInSystemMode() {
        assertTrue(AppearancePrefs(themeMode = ThemeMode.SYSTEM).resolveDark(systemDark = true))
        assertTrue(!AppearancePrefs(themeMode = ThemeMode.SYSTEM).resolveDark(systemDark = false))
        assertTrue(AppearancePrefs(themeMode = ThemeMode.DARK).resolveDark(systemDark = false))
        assertTrue(!AppearancePrefs(themeMode = ThemeMode.LIGHT).resolveDark(systemDark = true))
    }
}
