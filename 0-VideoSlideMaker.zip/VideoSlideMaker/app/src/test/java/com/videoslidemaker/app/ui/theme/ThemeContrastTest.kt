package com.videoslidemaker.app.ui.theme

import androidx.compose.ui.graphics.Color
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.pow

/**
 * Guards readability. Builds EVERY look the app can show (light, dark, pure-black dark, each with
 * and without high contrast, for all five accents (blue, teal, green, orange, rose)) and checks the WCAG contrast ratios:
 *   - text and accent colours on every background  >= 4.5:1 (>= 7:1 for text in high contrast)
 *   - status colours (green / yellow / red)         >= 4.5:1
 *   - outlines of tappable things                   >= 3:1
 *   - text on the tinted alert / badge / chip fills  >= 4.5:1
 *   - no purple accent, no pure-white light page / pure-black light text, neutral (tint-free) dark greys
 * If you change a value in Color.kt or Appearance.kt and one of these fails, the message tells
 * you which pair and which theme.
 */
class ThemeContrastTest {

    private fun channel(c: Float): Double {
        val v = c.toDouble()
        return if (v <= 0.03928) v / 12.92 else ((v + 0.055) / 1.055).pow(2.4)
    }

    private fun luminance(c: Color): Double =
        0.2126 * channel(c.red) + 0.7152 * channel(c.green) + 0.0722 * channel(c.blue)

    private fun ratio(a: Color, b: Color): Double {
        val la = luminance(a)
        val lb = luminance(b)
        return (maxOf(la, lb) + 0.05) / (minOf(la, lb) + 0.05)
    }

    /** [fg] drawn at [alpha] on top of [bg] - how the tinted boxes actually look. */
    private fun over(fg: Color, alpha: Float, bg: Color): Color = Color(
        red = fg.red * alpha + bg.red * (1f - alpha),
        green = fg.green * alpha + bg.green * (1f - alpha),
        blue = fg.blue * alpha + bg.blue * (1f - alpha)
    )

    private fun allLooks(): List<Pair<String, AppColors>> {
        val looks = ArrayList<Pair<String, AppColors>>()
        for (dark in listOf(true, false)) {
            for (pureBlack in listOf(false, true)) {
                if (!dark && pureBlack) continue // pure black only exists in dark
                for (highContrast in listOf(false, true)) {
                    for (accent in AccentChoice.entries) {
                        val prefs = AppearancePrefs(
                            pureBlack = pureBlack,
                            accent = accent,
                            highContrast = highContrast
                        )
                        val name = (if (dark) "dark" else "light") +
                            (if (pureBlack) "+black" else "") +
                            (if (highContrast) "+highContrast" else "") +
                            "/" + accent.label
                        looks.add(name to buildAppColors(dark, prefs))
                    }
                }
            }
        }
        return looks
    }

    private fun check(look: String, what: String, fg: Color, bg: Color, minimum: Double) {
        val r = ratio(fg, bg)
        assertTrue("$look: $what is only ${"%.2f".format(r)}:1 (needs $minimum:1)", r >= minimum)
    }

    @Test
    fun textAndAccentAreReadableOnEveryBackground() {
        for ((look, c) in allLooks()) {
            val textMin = if (look.contains("highContrast")) 7.0 else 4.5
            for ((bgName, bg) in listOf("page" to c.bg, "bar" to c.surface, "card" to c.card)) {
                check(look, "main text on $bgName", c.textMain, bg, textMin)
                check(look, "muted text on $bgName", c.muted, bg, textMin)
                check(look, "accent on $bgName", c.accent, bg, 4.5)
                check(look, "green on $bgName", c.green, bg, 4.5)
                check(look, "yellow on $bgName", c.yellow, bg, 4.5)
                check(look, "red on $bgName", c.red, bg, 4.5)
                check(look, "outline on $bgName", c.outline, bg, 3.0)
            }
        }
    }

    @Test
    fun textOnSolidFillsIsReadable() {
        for ((look, c) in allLooks()) {
            check(look, "text on accent button", c.onAccent, c.accent, 4.5)
            check(look, "tick on green", c.onStatus, c.green, 4.5)
            check(look, "disabled button text", c.muted, c.surface, 4.5)
        }
    }

    @Test
    fun textOnTintedBoxesIsReadable() {
        for ((look, c) in allLooks()) {
            check(look, "yellow warning text", c.yellow, over(c.yellow, 0.10f, c.card), 4.5)
            check(look, "green success text", c.green, over(c.green, 0.10f, c.card), 4.5)
            check(look, "info text", c.textMain, over(c.accent, 0.12f, c.card), 4.5)
            check(look, "accent time chip", c.accent, over(c.accent, 0.15f, c.card), 4.5)
            check(look, "accent badge", c.accent, over(c.accent, 0.13f, c.bg), 4.5)
            check(look, "green badge", c.green, over(c.green, 0.13f, c.bg), 4.5)
            check(look, "yellow badge", c.yellow, over(c.yellow, 0.13f, c.bg), 4.5)
            check(look, "selected chip text", c.textMain, over(c.accent, 0.22f, c.surface), 4.5)
        }
    }

    @Test
    fun darkPaletteIsNeutralGreyNotPurple() {
        // The old dark theme had a blue/purple cast (blue channel ~7-20 above red/green). The new
        // dark surfaces must have equal red, green and blue so there is no tint at all.
        for (pureBlack in listOf(false, true)) {
            val c = buildAppColors(true, AppearancePrefs(pureBlack = pureBlack))
            for (surface in listOf(c.bg, c.surface, c.card, c.border)) {
                assertEquals(surface.red, surface.green, 0.004f)
                assertEquals(surface.green, surface.blue, 0.004f)
            }
        }
    }

    private fun hueDegrees(c: Color): Double {
        val r = c.red.toDouble()
        val g = c.green.toDouble()
        val b = c.blue.toDouble()
        val max = maxOf(r, g, b)
        val d = max - minOf(r, g, b)
        if (d < 1e-6) return 0.0
        val sector = when (max) {
            r -> ((g - b) / d) % 6.0
            g -> (b - r) / d + 2.0
            else -> (r - g) / d + 4.0
        }
        val deg = sector * 60.0
        return if (deg < 0.0) deg + 360.0 else deg
    }

    @Test
    fun noAccentColourIsPurple() {
        // Purple / violet sits at roughly 255-320 degrees on the colour wheel. None of the choices may.
        for (choice in AccentChoice.entries) {
            for (tone in listOf(choice.darkTone, choice.lightTone)) {
                val hue = hueDegrees(tone)
                assertTrue("${choice.label} is purple-ish (hue ${"%.0f".format(hue)})", hue < 255.0 || hue > 320.0)
            }
        }
    }

    @Test
    fun lightPaletteIsCalmNotGlaring() {
        // Big pure-white areas and pure-black text are what tire the eyes: the light look must use neither.
        val c = buildAppColors(false, AppearancePrefs())
        for ((name, surface) in listOf("page" to c.bg, "bar" to c.surface, "card" to c.card)) {
            assertTrue("$name must not be pure white", luminance(surface) < 0.97)
        }
        assertTrue("main text must not be pure black", luminance(c.textMain) > 0.005)
        assertTrue("main text should stay under 15:1 on the page", ratio(c.textMain, c.bg) < 15.0)
    }

    @Test
    fun darkTextIsSoftNotPureWhite() {
        val c = buildAppColors(true, AppearancePrefs())
        assertTrue("dark main text must not be pure white", luminance(c.textMain) < 0.9)
    }

    @Test
    fun resolveDarkFollowsTheSystemOnlyInSystemMode() {
        assertTrue(AppearancePrefs(themeMode = ThemeMode.SYSTEM).resolveDark(systemDark = true))
        assertTrue(!AppearancePrefs(themeMode = ThemeMode.SYSTEM).resolveDark(systemDark = false))
        assertTrue(AppearancePrefs(themeMode = ThemeMode.DARK).resolveDark(systemDark = false))
        assertTrue(!AppearancePrefs(themeMode = ThemeMode.LIGHT).resolveDark(systemDark = true))
    }
}
