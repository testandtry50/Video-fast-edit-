package com.videoslidemaker.app.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** Whole scripts through [ScriptParser]: the new shapes, and proof the old ones still parse exactly as before. */
class ScriptParserFormatsTest {

    private fun parse(vararg lines: String) = ScriptParser.parseScriptDetailed(lines.joinToString("\n"))

    // ------------------------------------------------------------------ what always worked (regression)
    @Test fun theOriginalShapesAreUnchanged() {
        val r = parse("0:06 - Hello", "12 - Hi there", "0:30", "01:23:45.500 - Long", "00:00:500 - ms", "0:02.500 Plain space", "1:00: Colon after")
        assertTrue(r.issues.toString(), r.issues.isEmpty())
        assertEquals(listOf(6000L, 12000L, 30000L, 5025500L, 500L, 2500L, 60000L), r.lines.map { it.timestampMs })
        assertEquals(listOf("Hello", "Hi there", "", "Long", "ms", "Plain space", "Colon after"), r.lines.map { it.text })
    }

    @Test fun aSentenceThatStartsWithANumberAfterTheTimestampStaysIntact() {
        val r = parse("0:10 - 5 reasons to try this", "0:20 - 1,000 people came", "0:30 5m is long")
        assertEquals(listOf("5 reasons to try this", "1,000 people came", "5m is long"), r.lines.map { it.text })
    }

    @Test fun unusableLinesAreStillReportedWithTheirLineNumber() {
        val r = parse("0:06 - ok", "Hello", "1:2:3:4 bad")
        assertEquals(1, r.lines.size)
        assertEquals(listOf(2, 3), r.issues.map { it.lineNumber })
        assertTrue(r.issues[0].message.contains("doesn't start with a timestamp"))
    }

    // ------------------------------------------------------------------ the new shapes
    @Test fun srtMillisecondsAreKeptNotDroppedIntoTheText() {
        val r = parse("00:05:20,430 Hello")
        assertEquals(320430L, r.lines[0].timestampMs)
        assertEquals("Hello", r.lines[0].text)
    }

    @Test fun bracketedAndUnitShapes() {
        val r = parse("[00:05:20] Hello", "(5:20.5) - Again", "<1:00> Third", "5m20s Fourth", "1h02m03.5s Fifth", "320s Sixth")
        assertTrue(r.issues.toString(), r.issues.isEmpty())
        assertEquals(listOf(320000L, 320500L, 60000L, 320000L, 3723500L, 320000L), r.lines.map { it.timestampMs })
        assertEquals(listOf("Hello", "Again", "Third", "Fourth", "Fifth", "Sixth"), r.lines.map { it.text })
    }

    @Test fun aRangeKeepsTheStartAndIgnoresTheEnd() {
        val r = parse("00:00:01,000 --> 00:00:04,000 Hello", "00:00:05.500 --> 00:00:07.000 - World")
        assertEquals(listOf(1000L, 5500L), r.lines.map { it.timestampMs })
        assertEquals(listOf("Hello", "World"), r.lines.map { it.text })
    }

    @Test fun anSrtFileBecomesOneLinePerCueWithoutBogusIndexTimestamps() {
        val srt = "1\n00:00:01,000 --> 00:00:04,000\nHello there.\nGeneral Kenobi.\n\n2\n00:00:05,500 --> 00:00:07,000\nAnother line.\n"
        val r = ScriptParser.parseScriptDetailed(srt)
        assertTrue(r.issues.toString(), r.issues.isEmpty())
        assertEquals(listOf(1000L, 5500L), r.lines.map { it.timestampMs })
        assertEquals(listOf("Hello there. General Kenobi.", "Another line."), r.lines.map { it.text })
    }

    @Test fun aWebVttFileWorksToo() {
        val vtt = "WEBVTT\n\n00:00:01.000 --> 00:00:04.000 align:start\nHello.\n\n00:00:05.000 --> 00:00:06.000\nWorld.\n"
        val r = ScriptParser.parseScriptDetailed(vtt)
        assertEquals(listOf(1000L, 5000L), r.lines.map { it.timestampMs })
        assertEquals(listOf("Hello.", "World."), r.lines.map { it.text })
    }

    @Test fun frameBasedTimecodesAreRejectedWithAnExplanationNotGuessed() {
        val r = parse("00:05:20:12 Hello")
        assertTrue(r.lines.isEmpty())
        assertEquals(1, r.issues.size)
        assertTrue(r.issues[0].message, r.issues[0].message.contains("frame-based"))
    }
}
