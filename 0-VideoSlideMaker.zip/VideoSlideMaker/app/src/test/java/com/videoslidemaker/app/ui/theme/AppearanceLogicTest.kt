package com.videoslidemaker.app.ui.theme

import androidx.compose.ui.unit.dp
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** The non-colour choices: text sizes, layouts, and carrying the old "pure black" switch over to dark styles. */
class AppearanceLogicTest {

    @Test
    fun textSizesGoFromSmallToLargest() {
        val scales = TextSizeChoice.entries.map { it.scale }
        assertEquals("sizes must be listed smallest first", scales.sorted(), scales)
        assertTrue("Small must be smaller than the phone's own size", TextSizeChoice.SMALL.scale < 1.0f)
        assertEquals(1.0f, TextSizeChoice.DEFAULT.scale, 0.0001f)
        assertTrue("Large must be bigger", TextSizeChoice.LARGE.scale > 1.0f)
        assertTrue("Small must still be readable", TextSizeChoice.SMALL.scale >= 0.8f)
    }

    @Test
    fun anOldPureBlackSwitchBecomesTheBlackStyle() {
        assertEquals(DarkStyle.BLACK, parseDarkStyle(null, legacyPureBlack = true))
        assertEquals(DarkStyle.CHARCOAL, parseDarkStyle(null, legacyPureBlack = false))
    }

    @Test
    fun aSavedDarkStyleAlwaysWins() {
        assertEquals(DarkStyle.MIDNIGHT, parseDarkStyle("MIDNIGHT", legacyPureBlack = true))
        assertEquals(DarkStyle.CHARCOAL, parseDarkStyle("CHARCOAL", legacyPureBlack = true))
        // a name from a future / unknown version falls back like "nothing saved"
        assertEquals(DarkStyle.CHARCOAL, parseDarkStyle("NOT_A_STYLE", legacyPureBlack = false))
    }

    @Test
    fun theOriginalDefaultsAreUnchanged() {
        val p = AppearancePrefs()
        assertEquals(ThemeMode.SYSTEM, p.themeMode)
        assertEquals(DarkStyle.CHARCOAL, p.darkStyle)
        assertEquals(LightStyle.PAPER, p.lightStyle)
        assertEquals(AccentChoice.BLUE, p.accent)
        assertEquals(TextSizeChoice.DEFAULT, p.textSize)
        assertEquals(LayoutPreset.CLASSIC, p.matchingPreset())
    }

    @Test
    fun pickingALayoutPresetSetsAllThreeChoices() {
        for (preset in LayoutPreset.entries) {
            val p = AppearancePrefs().withPreset(preset)
            assertEquals(preset.navigation, p.navigation)
            assertEquals(preset.spacing, p.spacing)
            assertEquals(preset.corners, p.corners)
            assertEquals(preset, p.matchingPreset())
        }
    }

    @Test
    fun everyPresetIsADifferentCombination() {
        val combos = LayoutPreset.entries.map { Triple(it.navigation, it.spacing, it.corners) }
        assertEquals(combos.size, combos.toSet().size)
    }

    @Test
    fun layoutChoicesSetOneByOneMatchNoPreset() {
        // Classic with only the corners changed is not one of the ready-made layouts
        val p = AppearancePrefs(corners = CornerChoice.SOFT)
        assertNull(p.matchingPreset())
    }

    @Test
    fun spacingGrowsAndButtonsStayEasyToTap() {
        val compact = layoutSpecOf(SpacingChoice.COMPACT, CornerChoice.ROUNDED)
        val comfy = layoutSpecOf(SpacingChoice.COMFORTABLE, CornerChoice.ROUNDED)
        val roomy = layoutSpecOf(SpacingChoice.ROOMY, CornerChoice.ROUNDED)
        assertTrue(compact.cardPadding < comfy.cardPadding && comfy.cardPadding < roomy.cardPadding)
        assertTrue(compact.titleGap < comfy.titleGap && comfy.titleGap < roomy.titleGap)
        for (spec in listOf(compact, comfy, roomy)) {
            assertTrue("buttons must stay at least 48 dp tall", spec.buttonMinHeight >= 48.dp)
            assertTrue("headers must stay at least 48 dp tall", spec.headerMinHeight >= 48.dp)
        }
    }

    @Test
    fun cornersGetSharperFromRoundToSquare() {
        val round = layoutSpecOf(SpacingChoice.COMFORTABLE, CornerChoice.ROUNDED)
        val soft = layoutSpecOf(SpacingChoice.COMFORTABLE, CornerChoice.SOFT)
        val square = layoutSpecOf(SpacingChoice.COMFORTABLE, CornerChoice.SQUARE)
        assertTrue(round.cardRadius > soft.cardRadius && soft.cardRadius > square.cardRadius)
        assertTrue(round.controlRadius > soft.controlRadius && soft.controlRadius > square.controlRadius)
        // the classic layout must be exactly what the app used before (18 / 14 / 12 dp, 16 dp card padding)
        assertEquals(18.dp, round.cardRadius)
        assertEquals(14.dp, round.controlRadius)
        assertEquals(12.dp, round.smallRadius)
        assertEquals(16.dp, round.cardPadding)
        assertEquals(52.dp, round.buttonMinHeight)
    }
}
