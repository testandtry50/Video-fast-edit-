package com.videoslidemaker.app.audio

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** NEW (2.18): the background-audio slots made by pressing and holding a scene on the Match step. */
class BackgroundSlotsTest {
    private val none = AudioMixSettings()

    private fun withSlot(a: AudioMixSettings, id: String, start: Double, end: Double?): AudioMixSettings =
        BgSlots.add(a, id, BgSlots.nextLabel(a), start, end)

    /** A slot that already has a file of [fileSec] seconds. */
    private fun filled(id: String, label: String, start: Double, end: Double?, fileSec: Double): AudioClip =
        ClipEdit.replaceSource(BgSlots.placeholder(id, label, start, end), "content://f/$id", "$id.mp3", fileSec)

    // ---- names -----------------------------------------------------------------------------

    @Test fun firstSlotIsB1AndNamesCountUpWithoutRepeating() {
        assertEquals("B1", BgSlots.nextLabel(none))
        val a = withSlot(withSlot(none, "x", 4.0, null), "y", 9.0, null)
        assertEquals(listOf("B1", "B2"), a.background.map { it.slot })
        assertEquals("B3", BgSlots.nextLabel(a))
        // removing the FIRST one must not hand its name out again while a later one still exists
        assertEquals("B3", BgSlots.nextLabel(a.removeClip("x")))
        // ordinary clips never count
        val plain = none.copy(background = listOf(AudioClip("p", "content://p", "B9 song", 10.0)))
        assertEquals("B1", BgSlots.nextLabel(plain))
    }

    @Test fun slotsAreListedChronologically() {
        var a = withSlot(none, "late", 20.0, null)   // B1, but it starts last
        a = withSlot(a, "early", 3.0, null)          // B2, starts first
        a = withSlot(a, "tie", 3.0, null)            // B3, same start as B2
        assertEquals(listOf("B2", "B3", "B1"), BgSlots.slots(a).map { it.slot })
    }

    @Test fun openAndEmptySlotsAreTold() {
        var a = withSlot(none, "a", 4.0, null)
        a = withSlot(a, "b", 10.0, 14.0)
        assertEquals(listOf("B1"), BgSlots.openSlots(a).map { it.slot })
        assertEquals(listOf("B1", "B2"), BgSlots.emptySlots(a).map { it.slot })
        val filledB2 = a.editClip("b") { ClipEdit.replaceSource(it, "content://f", "rain.mp3", 8.0) }
        assertEquals(listOf("B1"), BgSlots.emptySlots(filledB2).map { it.slot })
    }

    // ---- an empty slot is in the project but silent ---------------------------------------------

    @Test fun anEmptySlotKeepsItsPlaceButMakesNoSound() {
        val a = withSlot(none, "a", 4.0, null)
        val c = a.background.single()
        assertTrue(c.isPlaceholder)
        assertEquals("B1", c.name)           // until a file is chosen, its name is its label
        assertEquals(4.0, c.startSec, 1e-9)
        assertTrue(a.activeBackground.isEmpty())
        assertFalse(a.hasAnySound)
        assertTrue(a.summary().contains("1 empty background slot"))
    }

    @Test fun choosingAFileKeepsTheSlotsNameAndTimesAndTakesTheFilesName() {
        val a = withSlot(none, "a", 4.0, 12.0).editClip("a") { ClipEdit.replaceSource(it, "content://f", "rain.mp3", 30.0) }
        val c = a.background.single()
        assertFalse(c.isPlaceholder)
        assertEquals("rain.mp3", c.name)
        assertEquals("B1", c.slot)
        assertEquals(4.0, c.startSec, 1e-9)
        assertEquals(12.0, c.rangeEndSec, 1e-9)
        assertEquals(1, a.activeBackground.size)
    }

    // ---- time checks -----------------------------------------------------------------------

    @Test fun timesAreCheckedAgainstTheVideo() {
        assertNull(BgSlots.checkTimes(4.0, null, 30.0))
        assertNull(BgSlots.checkTimes(4.0, 12.0, 30.0))
        assertNull(BgSlots.checkTimes(0.0, 30.0, 30.0))                 // right to the very end is fine
        assertEquals(TimeProblem.START_OUT_OF_VIDEO, BgSlots.checkTimes(-1.0, null, 30.0))
        assertEquals(TimeProblem.START_OUT_OF_VIDEO, BgSlots.checkTimes(30.0, null, 30.0))
        assertEquals(TimeProblem.END_NOT_AFTER_START, BgSlots.checkTimes(10.0, 10.0, 30.0))
        assertEquals(TimeProblem.END_NOT_AFTER_START, BgSlots.checkTimes(10.0, 5.0, 30.0))
        assertEquals(TimeProblem.END_OUT_OF_VIDEO, BgSlots.checkTimes(10.0, 31.0, 30.0))
    }

    @Test fun settingTimesChangesStartAndEndAndCanTakeTheEndAway() {
        val a = withSlot(none, "a", 4.0, null)
        val ended = BgSlots.setTimes(a, "a", 4.0, 12.5).background.single()
        assertEquals(12.5, ended.rangeEndSec, 1e-9); assertTrue(ended.hasRange)
        val moved = BgSlots.setTimes(a, "a", 6.0, 12.5).background.single()
        assertEquals(6.0, moved.startSec, 1e-9)
        val open = BgSlots.setTimes(BgSlots.setTimes(a, "a", 4.0, 12.5), "a", 4.0, null).background.single()
        assertFalse(open.hasRange); assertEquals(0.0, open.rangeEndSec, 1e-9)
        // an end that is not after the start is never stored
        assertFalse(BgSlots.setTimes(a, "a", 4.0, 3.0).background.single().hasRange)
    }

    @Test fun settingTimesLeavesOrdinaryClipsAlone() {
        val plain = AudioClip("p", "content://p", "song", 60.0, startSec = 1.0)
        val a = none.copy(background = listOf(plain))
        assertEquals(a, BgSlots.setTimes(a, "p", 9.0, 20.0))
    }

    // ---- fitting the audio to the range --------------------------------------------------------

    @Test fun aLongerFileIsCutToTheRange() {
        val c = ClipEdit.followRange(filled("a", "B1", 4.0, 12.0, fileSec = 30.0))
        assertEquals(8.0, c.lengthSec, 1e-9)
        assertEquals(0.0, c.srcStartSec, 1e-9)
        assertFalse(c.loop)
        assertEquals(12.0, c.endSec, 1e-9)           // ends exactly where the range ends
    }

    @Test fun aShorterFileRepeatsUntilTheRangeEnds() {
        val c = ClipEdit.followRange(filled("a", "B1", 4.0, 12.0, fileSec = 3.0))
        assertTrue(c.loop)
        assertEquals(3.0, c.lengthSec, 1e-9)         // one round is the whole file
        assertEquals(12.0, c.playsUntil(60.0), 1e-9) // ...and the rounds stop at the range's end
        assertEquals(12.0, c.stopsAt(60.0), 1e-9)
    }

    @Test fun aFileAsLongAsTheRangeIsUsedAsItIs() {
        val c = ClipEdit.followRange(filled("a", "B1", 4.0, 12.0, fileSec = 8.0))
        assertFalse(c.loop); assertEquals(8.0, c.lengthSec, 1e-9)
    }

    @Test fun theChosenStartInsideTheFileIsKept() {
        val base = filled("a", "B1", 4.0, 14.0, fileSec = 60.0)
        val c = ClipEdit.followRange(ClipEdit.trimStart(base, 20.0))
        assertEquals(20.0, c.srcStartSec, 1e-9); assertEquals(30.0, c.srcEndSec, 1e-9); assertFalse(c.loop)
        // 30 s file, begin 25 s in: only 5 s left, so a 10 s range repeats that
        val short = ClipEdit.followRange(ClipEdit.trimStart(filled("b", "B2", 0.0, 10.0, fileSec = 30.0), 25.0))
        assertTrue(short.loop); assertEquals(5.0, short.lengthSec, 1e-9)
    }

    @Test fun fittingNeverChangesTheStoredClipSoALaterChangeFitsAgain() {
        val stored = filled("a", "B1", 4.0, 12.0, fileSec = 30.0)
        ClipEdit.followRange(stored)
        assertEquals(30.0, stored.lengthSec, 1e-9)
        val longer = ClipEdit.followRange(stored.copy(rangeEndSec = 20.0))
        assertEquals(16.0, longer.lengthSec, 1e-9)
        val muchLonger = ClipEdit.followRange(stored.copy(rangeEndSec = 50.0))   // 46 s range, 30 s file
        assertTrue(muchLonger.loop)
    }

    @Test fun clipsThatAreNotTiedToARangeAreNotTouched() {
        val noEnd = filled("a", "B1", 4.0, null, fileSec = 30.0)
        assertEquals(noEnd, ClipEdit.followRange(noEnd))
        val empty = BgSlots.placeholder("e", "B2", 4.0, 12.0)
        assertEquals(empty, ClipEdit.followRange(empty))
        val fitVideo = filled("f", "B3", 4.0, 12.0, fileSec = 30.0).copy(fitVideo = true)
        assertEquals(fitVideo, ClipEdit.followRange(fitVideo))
        val unmeasured = filled("u", "B4", 4.0, 12.0, fileSec = 30.0).copy(sourceDurationSec = 0.0, srcEndSec = 0.0)
        assertEquals(unmeasured, ClipEdit.followRange(unmeasured))
        val ordinary = AudioClip("o", "content://o", "song", 30.0, loop = true)
        assertEquals(ordinary, ClipEdit.followRange(ordinary))
    }

    @Test fun aRepeatingClipWithoutARangeStillRunsToTheEndOfTheVideo() {
        val loop = AudioClip("o", "content://o", "song", 30.0, loop = true, startSec = 5.0)
        assertEquals(100.0, loop.stopsAt(100.0), 1e-9)
        assertEquals(100.0, loop.playsUntil(100.0), 1e-9)
        // a leftover end time never limits an "always fit the video" clip
        val fit = filled("f", "B1", 4.0, 12.0, fileSec = 3.0).copy(fitVideo = true, loop = true)
        assertEquals(100.0, fit.stopsAt(100.0), 1e-9)
    }

    @Test fun theEndIsAlwaysKeptInsideTheVideo() {
        val c = ClipEdit.followRange(filled("a", "B1", 4.0, 50.0, fileSec = 3.0))
        assertEquals(30.0, c.stopsAt(30.0), 1e-9)
    }

    @Test fun asPlayedAppliesTheVideoFitFirstAndTheRangeAfterwards() {
        val slot = filled("a", "B1", 4.0, 12.0, fileSec = 30.0)
        assertEquals(8.0, ClipEdit.asPlayed(slot, 60.0).lengthSec, 1e-9)
        val song = AudioClip("s", "content://s", "s", 100.0, fitVideo = true)
        assertEquals(40.0, ClipEdit.asPlayed(song, 40.0).lengthSec, 1e-9)
    }

    @Test fun fitIsDescribedInPlainWords() {
        assertEquals(SlotFit.Empty, BgSlots.fit(BgSlots.placeholder("a", "B1", 4.0, 12.0)))
        assertEquals(SlotFit.NoEnd(30.0), BgSlots.fit(filled("a", "B1", 4.0, null, 30.0)))
        assertEquals(SlotFit.Exact(8.0), BgSlots.fit(filled("a", "B1", 4.0, 12.0, 8.0)))
        assertEquals(SlotFit.Trimmed(30.0, 8.0), BgSlots.fit(filled("a", "B1", 4.0, 12.0, 30.0)))
        val rep = BgSlots.fit(filled("a", "B1", 4.0, 12.0, 3.0)) as SlotFit.Repeats
        assertEquals(8.0 / 3.0, rep.times, 1e-9)
        assertTrue(BgSlots.describeFit(filled("a", "B1", 4.0, 12.0, 30.0)).contains("cut to fit"))
        assertTrue(BgSlots.describeFit(filled("a", "B1", 4.0, 12.0, 3.0)).contains("repeats"))
        assertTrue(BgSlots.describeFit(filled("a", "B1", 4.0, 12.0, 3.0)).contains("2.7 times"))
        assertTrue(BgSlots.describeFit(BgSlots.placeholder("a", "B1", 4.0, null)).contains("silent"))
    }

    // ---- the tags on the scene cards -----------------------------------------------------------------

    private val scenes = listOf(SceneSpan(0.0, 4.0), SceneSpan(4.0, 8.0), SceneSpan(8.0, 12.0), SceneSpan(12.0, 16.0))

    private fun kinds(slot: AudioClip) = scenes.map { BgSlots.badgesFor(listOf(slot), it).firstOrNull()?.kind }

    @Test fun aSlotIsTaggedStartMiddleEndAcrossTheScenesItCovers() {
        val s = BgSlots.placeholder("a", "B1", 4.0, 14.0)
        assertEquals(listOf(null, BadgeKind.START, BadgeKind.MIDDLE, BadgeKind.END), kinds(s))
    }

    @Test fun aSlotThatStartsAndStopsInOneSceneIsWhole() {
        assertEquals(listOf(null, BadgeKind.WHOLE, null, null), kinds(BgSlots.placeholder("a", "B1", 4.5, 7.0)))
    }

    @Test fun aSlotWithoutAnEndIsTaggedOnlyWhereItStarts() {
        assertEquals(listOf(null, BadgeKind.START, null, null), kinds(BgSlots.placeholder("a", "B1", 5.0, null)))
    }

    @Test fun sceneEdgesBelongToTheRightScene() {
        // starting exactly where a scene begins = that scene, not the one before
        assertEquals(listOf(null, BadgeKind.START, null, null), kinds(BgSlots.placeholder("a", "B1", 4.0, null)))
        // stopping exactly where a scene ends = that scene, not the next one
        assertEquals(listOf(BadgeKind.START, BadgeKind.END, null, null), kinds(BgSlots.placeholder("a", "B1", 1.0, 8.0)))
    }

    @Test fun badgesKeepTheSlotsNamesAndWhetherTheyStillWaitForAFile() {
        val a = BgSlots.placeholder("a", "B1", 5.0, null)
        val b = filled("b", "B2", 5.0, 7.0, 3.0)
        val tags = BgSlots.badgesFor(listOf(a, b), scenes[1])
        assertEquals(listOf("B1", "B2"), tags.map { it.label })
        assertEquals(listOf(true, false), tags.map { it.waiting })
    }

    // ---- the time wheels ------------------------------------------------------------------------------

    @Test fun timesSplitAndJoinForTheWheels() {
        for (sec in listOf(0.0, 4.0, 5.7, 12.3, 59.9, 60.0, 61.1, 125.4, 3599.9)) {
            val p = BgSlots.parts(sec)
            assertEquals(sec, BgSlots.fromParts(p.minutes, p.seconds, p.tenths), 1e-9)
        }
        assertEquals(BgSlots.Parts(1, 0, 0), BgSlots.parts(59.96))   // rounds up across the minute
        assertEquals(BgSlots.Parts(0, 0, 0), BgSlots.parts(-3.0))
        assertEquals(0.4, BgSlots.fromParts(0, 0, 4), 1e-9)
        assertEquals(59.9, BgSlots.fromParts(0, 99, 99), 1e-9)       // out-of-range wheel values are held to 59 s / .9
    }

    @Test fun timesAreWrittenAsMinutesSecondsTenths() {
        assertEquals("0:04.0", BgSlots.clock(4.0))
        assertEquals("1:05.5", BgSlots.clock(65.5))
        assertEquals("0:08", BgSlots.clockShort(8.0))
        assertEquals("1:05.5", BgSlots.clockShort(65.5))
        assertEquals(0, BgSlots.maxMinutes(59.0)); assertEquals(2, BgSlots.maxMinutes(125.0))
    }

    @Test fun suggestedTimesStayInsideTheVideo() {
        val last = SceneSpan(27.0, 30.0)
        assertEquals(27.0, BgSlots.suggestStart(last, 30.0), 1e-9)
        assertEquals(29.9, BgSlots.suggestStart(SceneSpan(35.0, 38.0), 30.0), 1e-9)      // never past the end
        assertEquals(30.0, BgSlots.suggestEnd(4.0, last, 30.0), 1e-9)                      // the end of the pressed scene
        assertEquals(7.0, BgSlots.suggestEnd(4.0, SceneSpan(5.0, 7.0), 30.0), 1e-9)
        // the pressed scene is BEFORE the slot's start: a few seconds after the start instead
        assertEquals(13.0, BgSlots.suggestEnd(10.0, SceneSpan(0.0, 4.0), 30.0), 1e-9)
        // ...but not beyond the video
        assertEquals(30.0, BgSlots.suggestEnd(29.0, SceneSpan(0.0, 4.0), 30.0), 1e-9)
    }

    // ---- saved with the project -----------------------------------------------------------------------

    @Test fun slotsSurviveSavingAndLoadingIncludingEmptyOnes() {
        var a = withSlot(none, "a", 4.0, null)                                    // empty, no end yet
        a = withSlot(a, "b", 10.0, 14.0)                                          // empty, with an end
        a = a.copy(background = a.background + filled("c", "B3", 20.0, 26.0, 3.0)) // with a file
        val back = AudioCodec.decode(AudioCodec.encode(a))
        assertEquals(a, back)
        assertEquals(listOf("B1", "B2", "B3"), back.background.map { it.slot })
        assertTrue(back.background[0].isPlaceholder)
        assertEquals(14.0, back.background[1].rangeEndSec, 1e-9)
        assertEquals("c.mp3", back.background[2].name)
    }

    @Test fun projectsSavedBeforeSlotsExistedStillLoad() {
        val old = """{"useCustomMain":false,"main":[],"background":[{"id":"b1","uri":"content://b","name":"Song","dur":100.0,"s0":0.0,"s1":100.0,"at":0.0,"vol":1.0,"fi":1.0,"fo":0.0,"mute":false,"loop":false,"duck":true,"fit":true}]}"""
        val c = AudioCodec.decode(old).background.single()
        assertEquals("", c.slot); assertEquals(0.0, c.rangeEndSec, 1e-9); assertTrue(c.fitVideo)
    }

    @Test fun aClipWithNoFileAndNoSlotNameIsStillDroppedWhenLoading() {
        val bad = """{"background":[{"id":"x","uri":"","name":"broken"}]}"""
        assertTrue(AudioCodec.decode(bad).background.isEmpty())
    }

    // ---- editing never leaves two clips with the same slot name ------------------------------------------

    @Test fun splittingASlotClipDoesNotDuplicateItsNameOrRange() {
        val parts = ClipEdit.split(filled("a", "B1", 4.0, 12.0, 30.0), 3.0, "n")
        assertEquals(2, parts.size)
        assertTrue(parts.all { it.slot.isEmpty() && it.rangeEndSec == 0.0 })
    }
}
