package com.videoslidemaker.app.model

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * The numbers behind the Preview's playback-speed control: which speeds exist, how the slider maps to them,
 * how a speed is written, what it means for watch time, and what happens when a phone refuses a speed.
 *
 * The same checks run in Python in tools/previewspeed-reference/run_tests.py.
 */
class PreviewSpeedTest {
    private val eps = 0.0001f

    // photo lengths in seconds, used by the "quick photo" checks
    private val photoLengths = listOf(3.0, 0.8, 2.0, 0.5)

    @Test
    fun snapRoundsToTheNearestFiveHundredthsAndStaysInRange() {
        assertEquals(1.0f, PreviewSpeed.snap(1.02f), eps)
        assertEquals(1.05f, PreviewSpeed.snap(1.03f), eps)
        assertEquals(0.25f, PreviewSpeed.snap(0.1f), eps)
        assertEquals(4f, PreviewSpeed.snap(9f), eps)
        assertEquals(0.25f, PreviewSpeed.snap(0.25f), eps)
        assertEquals(4f, PreviewSpeed.snap(4f), eps)
        assertEquals(1f, PreviewSpeed.snap(Float.NaN), eps)
    }

    @Test
    fun sameIgnoresTinyDifferencesOnly() {
        assertTrue(PreviewSpeed.same(1f, 1.0004f))
        assertFalse(PreviewSpeed.same(1f, 1.05f))
    }

    @Test
    fun nudgeMovesInStepsAndStopsAtTheEnds() {
        assertEquals(1.05f, PreviewSpeed.nudge(1f, 0.05f), eps)
        assertEquals(0.75f, PreviewSpeed.nudge(1f, -0.25f), eps)
        assertEquals(0.25f, PreviewSpeed.nudge(0.25f, -0.25f), eps)
        assertEquals(4f, PreviewSpeed.nudge(4f, 0.25f), eps)
        assertEquals(3f, PreviewSpeed.nudge(2.95f, 0.05f), eps)
    }

    @Test
    fun theSpeedButtonStepsThroughTheCommonSpeedsAndWrapsAround() {
        assertEquals(1f, PreviewSpeed.cycle(0.5f), eps)
        assertEquals(1.5f, PreviewSpeed.cycle(1f), eps)
        assertEquals(2f, PreviewSpeed.cycle(1.5f), eps)
        assertEquals(3f, PreviewSpeed.cycle(2f), eps)
        assertEquals(0.5f, PreviewSpeed.cycle(3f), eps)
        // from a speed that is not one of the stops it goes to the next faster stop
        assertEquals(0.5f, PreviewSpeed.cycle(0.25f), eps)
        assertEquals(1f, PreviewSpeed.cycle(0.75f), eps)
        assertEquals(1.5f, PreviewSpeed.cycle(1.3f), eps)
        assertEquals(3f, PreviewSpeed.cycle(2.5f), eps)
        assertEquals(0.5f, PreviewSpeed.cycle(4f), eps)
        // five taps from any stop come back round to it
        var s = 0.5f
        for (i in 1..5) s = PreviewSpeed.cycle(s)
        assertEquals(0.5f, s, eps)
        // and every stop is also one of the one-tap speeds in the card
        for (c in PreviewSpeed.CYCLE) assertTrue(PreviewSpeed.PRESETS.contains(c))
    }

    @Test
    fun presetsAreOrderedInsideTheRangeAndIncludeNormal() {
        val presets = PreviewSpeed.PRESETS
        assertEquals(presets.sorted(), presets)
        assertTrue(presets.contains(1f))
        for (s in presets) {
            assertTrue(s >= PreviewSpeed.MIN && s <= PreviewSpeed.MAX)
            assertEquals(s, PreviewSpeed.snap(s), eps)
        }
        // every one-tap speed reads differently
        assertEquals(presets.size, presets.map { PreviewSpeed.label(it) }.toSet().size)
    }

    @Test
    fun speedsAreWrittenShortAndReadable() {
        assertEquals("1×", PreviewSpeed.label(1f))
        assertEquals("0.5×", PreviewSpeed.label(0.5f))
        assertEquals("0.25×", PreviewSpeed.label(0.25f))
        assertEquals("0.75×", PreviewSpeed.label(0.75f))
        assertEquals("1.25×", PreviewSpeed.label(1.25f))
        assertEquals("1.5×", PreviewSpeed.label(1.5f))
        assertEquals("2×", PreviewSpeed.label(2f))
        assertEquals("2.5×", PreviewSpeed.label(2.5f))
        assertEquals("3×", PreviewSpeed.label(3f))
        assertEquals("4×", PreviewSpeed.label(4f))
        assertEquals("1.05×", PreviewSpeed.label(1.05f))
    }

    @Test
    fun screenReadersGetWords() {
        assertEquals("Normal speed", PreviewSpeed.spoken(1f))
        assertEquals("2 times normal speed", PreviewSpeed.spoken(2f))
        assertEquals("0.5 times normal speed", PreviewSpeed.spoken(0.5f))
    }

    @Test
    fun sliderPutsNormalSpeedInTheMiddleOnALogScale() {
        assertEquals(0.5f, PreviewSpeed.toSlider(1f), eps)
        assertEquals(0f, PreviewSpeed.toSlider(0.25f), eps)
        assertEquals(1f, PreviewSpeed.toSlider(4f), eps)
        // every doubling is the same distance: 0.5x, 1x, 2x
        assertEquals(0.25f, PreviewSpeed.toSlider(0.5f), eps)
        assertEquals(0.75f, PreviewSpeed.toSlider(2f), eps)

        assertEquals(0.25f, PreviewSpeed.fromSlider(0f), eps)
        assertEquals(4f, PreviewSpeed.fromSlider(1f), eps)
        assertEquals(1f, PreviewSpeed.fromSlider(0.5f), eps)
        assertEquals(0.5f, PreviewSpeed.fromSlider(0.25f), eps)
        assertEquals(2f, PreviewSpeed.fromSlider(0.75f), eps)
    }

    @Test
    fun everyOneTapSpeedSitsOnTheSliderAndComesBackAsItself() {
        for (p in PreviewSpeed.PRESETS) {
            assertEquals(p, PreviewSpeed.fromSlider(PreviewSpeed.toSlider(p)), eps)
        }
    }

    @Test
    fun everyStepFromQuarterTo4xComesBackAsItselfAndTheSliderOnlyMovesRight() {
        var previous = -1f
        for (k in 5..80) {
            val speed = k / 20f
            val position = PreviewSpeed.toSlider(speed)
            assertTrue("the slider must move right as the speed rises", position > previous)
            previous = position
            assertEquals(speed, PreviewSpeed.fromSlider(position), eps)
        }
    }

    @Test
    fun draggingTheSliderAlwaysGivesAWholeStepInsideTheRange() {
        var last = 0f
        for (i in 0..200) {
            val v = PreviewSpeed.fromSlider(i / 200f)
            assertTrue("dragging right never slows it down", v >= last - eps)
            assertTrue(v >= PreviewSpeed.MIN - eps && v <= PreviewSpeed.MAX + eps)
            assertTrue("a whole 0.05 step", abs(v * 20f - (v * 20f).roundToInt()) < 0.001f)
            last = v
        }
        // nonsense positions are safe
        assertEquals(1f, PreviewSpeed.fromSlider(Float.NaN), eps)
        assertEquals(0.25f, PreviewSpeed.fromSlider(-3f), eps)
        assertEquals(4f, PreviewSpeed.fromSlider(7f), eps)
    }

    @Test
    fun watchTimeIsTheLengthDividedByTheSpeed() {
        assertEquals(300.0, PreviewSpeed.watchSeconds(600.0, 2f), 1e-9)
        assertEquals(1200.0, PreviewSpeed.watchSeconds(600.0, 0.5f), 1e-9)
        assertEquals(600.0, PreviewSpeed.watchSeconds(600.0, 1f), 1e-9)
        assertEquals(80.0, PreviewSpeed.watchSeconds(100.0, 1.25f), 1e-9)
    }

    @Test
    fun shortestPhotoIsFoundAndAnEmptyProjectIsSafe() {
        assertEquals(0.5, PreviewSpeed.shortest(photoLengths.size) { photoLengths[it] }, 1e-9)
        assertEquals(0.0, PreviewSpeed.shortest(0) { 99.0 }, 1e-9)
    }

    @Test
    fun quickPhotosAreCountedAtTheChosenSpeed() {
        // 3.0, 0.8, 2.0, 0.5 seconds: a photo is "quick" when it is on screen for under 1 real second
        assertEquals(2, PreviewSpeed.countBelow(4, 1.0, 1f) { photoLengths[it] })
        assertEquals(2, PreviewSpeed.countBelow(4, 1.0, 2f) { photoLengths[it] })
        assertEquals(3, PreviewSpeed.countBelow(4, 1.0, 3f) { photoLengths[it] })
        assertEquals(0, PreviewSpeed.countBelow(4, 1.0, 0.5f) { photoLengths[it] })
        assertEquals(0, PreviewSpeed.countBelow(0, 1.0, 2f) { 0.1 })
    }

    @Test
    fun shortTimesAreWrittenPlainly() {
        assertEquals("under 0.1 s", PreviewSpeed.formatShort(0.01))
        assertEquals("under 0.1 s", PreviewSpeed.formatShort(0.04))
        assertEquals("0.4 s", PreviewSpeed.formatShort(0.4))
        assertEquals("0.8 s", PreviewSpeed.formatShort(0.8))
        assertEquals("3 s", PreviewSpeed.formatShort(3.0))
        assertEquals("3 s", PreviewSpeed.formatShort(2.96))
        assertEquals("9.9 s", PreviewSpeed.formatShort(9.94))
        assertEquals("12 s", PreviewSpeed.formatShort(12.0))
    }

    @Test
    fun aRefusedSpeedFallsBackTowardsNormal() {
        assertEquals(listOf(1f), PreviewSpeed.fallbackLadder(1f))
        assertEquals(listOf(2f, 1.5f, 1.25f, 1f), PreviewSpeed.fallbackLadder(2f))
        assertEquals(listOf(3f, 2f, 1.5f, 1.25f, 1f), PreviewSpeed.fallbackLadder(3f))
        assertEquals(listOf(4f, 2f, 1.5f, 1.25f, 1f), PreviewSpeed.fallbackLadder(4f))
        assertEquals(listOf(1.5f, 1.25f, 1f), PreviewSpeed.fallbackLadder(1.5f))
        assertEquals(listOf(1.25f, 1f), PreviewSpeed.fallbackLadder(1.25f))
        assertEquals(listOf(0.5f, 0.75f, 1f), PreviewSpeed.fallbackLadder(0.5f))
        assertEquals(listOf(0.25f, 0.5f, 0.75f, 1f), PreviewSpeed.fallbackLadder(0.25f))
        assertEquals(listOf(0.75f, 1f), PreviewSpeed.fallbackLadder(0.75f))
    }

    @Test
    fun everyFallbackStartsAtTheWantedSpeedAndEndsAtNormalWithoutRepeats() {
        for (k in 5..80) {
            val wanted = k / 20f
            val ladder = PreviewSpeed.fallbackLadder(wanted)
            assertEquals(wanted, ladder.first(), eps)
            assertEquals(1f, ladder.last(), eps)
            assertEquals(ladder.size, ladder.toSet().size)
            // each step is nearer to normal speed than the one before
            for (i in 1 until ladder.size) {
                assertTrue(abs(ladder[i] - 1f) <= abs(ladder[i - 1] - 1f) + eps)
            }
        }
    }

    @Test
    fun thePhonesVoiceSpeaksFasterByTheSameFactorAndStaysInRange() {
        assertEquals(0.95f, PreviewSpeed.ttsRate(0.95f, 1f), eps)
        assertEquals(1.9f, PreviewSpeed.ttsRate(0.95f, 2f), eps)
        assertEquals(0.2375f, PreviewSpeed.ttsRate(0.95f, 0.25f), eps)
        assertEquals(4f, PreviewSpeed.ttsRate(1f, 4f), eps)
        assertEquals(4f, PreviewSpeed.ttsRate(2f, 4f), eps)
        assertEquals(0.1f, PreviewSpeed.ttsRate(0.1f, 0.25f), eps)
    }

    @Test
    fun photosMayDriftFromTheRecordingByTheSameAmountYouSee() {
        assertEquals(0.12, PreviewSpeed.driftToleranceSec(1f), 1e-9)
        assertEquals(0.12, PreviewSpeed.driftToleranceSec(0.5f), 1e-9)
        assertEquals(0.24, PreviewSpeed.driftToleranceSec(2f), 1e-9)
        assertEquals(0.36, PreviewSpeed.driftToleranceSec(3f), 1e-9)
        assertEquals(0.48, PreviewSpeed.driftToleranceSec(4f), 1e-9)
    }

    @Test
    fun fadesGetShorterWhenSpedUpAndLongerWhenSlowedDown() {
        assertEquals(350, PreviewSpeed.scaledMs(350, 1f))
        assertEquals(175, PreviewSpeed.scaledMs(350, 2f))
        assertEquals(700, PreviewSpeed.scaledMs(350, 0.5f))
        assertEquals(75, PreviewSpeed.scaledMs(300, 4f))
        assertEquals(50, PreviewSpeed.scaledMs(150, 3f))
        assertEquals(117, PreviewSpeed.scaledMs(350, 3f))
        // a hard cut stays a hard cut, and a fade never rounds down to nothing
        assertEquals(0, PreviewSpeed.scaledMs(0, 2f))
        assertEquals(1, PreviewSpeed.scaledMs(1, 4f))
    }

    @Test
    fun moreSlidesAreLoadedAheadWhenTheyGoByFaster() {
        assertEquals(2, PreviewSpeed.lookAhead(0.25f))
        assertEquals(2, PreviewSpeed.lookAhead(1f))
        assertEquals(4, PreviewSpeed.lookAhead(1.25f))
        assertEquals(4, PreviewSpeed.lookAhead(2f))
        assertEquals(6, PreviewSpeed.lookAhead(3f))
        assertEquals(8, PreviewSpeed.lookAhead(4f))
    }
}
