package com.videoslidemaker.app.audio

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.PI
import kotlin.math.sin

class SmartMixTest {
    private val rate = 8000

    /** 16-bit mono PCM: a modulated tone inside the given (start,end) second ranges, silence elsewhere. */
    private fun speech(bursts: List<Pair<Double, Double>>, seconds: Double): ByteArray {
        val n = (seconds * rate).toInt()
        val out = ByteArray(n * 2)
        for (i in 0 until n) {
            val t = i.toDouble() / rate
            val on = bursts.any { t >= it.first && t < it.second }
            val env = if (on) 0.5 + 0.5 * sin(2 * PI * 4 * t) else 0.0
            val v = (0.25 * env * sin(2 * PI * 180 * t) * 32767).toInt().toShort().toInt()
            out[i * 2] = (v and 0xFF).toByte(); out[i * 2 + 1] = ((v shr 8) and 0xFF).toByte()
        }
        return out
    }

    private fun rmsOf(bursts: List<Pair<Double, Double>>, seconds: Double): FloatArray {
        val m = SmartMix.EnergyMeter(rate, 1); m.push(speech(bursts, seconds)); return m.result()
    }

    private fun w(sec: Double) = (sec * 1000 / SmartMix.WINDOW_MS).toInt()

    @Test fun maskFindsSpeechNotSilence() {
        val mask = SmartMix.speechMask(rmsOf(listOf(1.0 to 2.5, 4.0 to 5.0), 7.0))
        assertTrue((w(1.2) until w(2.3)).count { mask[it] } > 0.6 * (w(2.3) - w(1.2)))
        assertFalse((w(2.8) until w(3.8)).any { mask[it] })
        assertFalse(SmartMix.speechMask(rmsOf(emptyList(), 3.0)).any { it })
        assertEquals(0, SmartMix.speechMask(FloatArray(0)).size)
    }

    @Test fun duckingLowersBeforeSpeechAndRecovers() {
        val mask = SmartMix.speechMask(rmsOf(listOf(1.0 to 2.5, 4.0 to 5.0), 7.0))
        val duck = 0.2f
        val g = SmartMix.duckGains(mask, duck)
        assertTrue(g[w(1.8)] < duck * 1.25f)
        assertTrue(g[w(3.8)] > 0.9f)
        assertTrue(g[w(1.0) - 2] < 0.9f)
        assertTrue(g.all { it > 0f && it <= 1f })
    }

    @Test fun shortPauseDoesNotPumpTheMusic() {
        val mask = BooleanArray(48) { it < 20 || it >= 28 }
        val g = SmartMix.duckGains(mask, 0.2f)
        assertTrue(g.slice(25..27).min() < 0.4f)
    }

    @Test fun autoLevelLandsOnTarget() {
        val voice = SmartMix.dbOf(0.1); val music = SmartMix.dbOf(0.3)
        for (off in listOf(-10.0, -18.0)) {
            val gain = SmartMix.autoLevelGain(voice, music, off)
            assertEquals(voice + off, music + SmartMix.dbOf(gain.toDouble()), 0.01)
        }
        assertEquals(1f, SmartMix.autoLevelGain(null, music, -10.0), 0f)
        assertEquals(6f, SmartMix.autoLevelGain(0.0, -110.0, 0.0), 0f)
    }

    @Test fun fadeCurve() {
        assertEquals(0f, SmartMix.fade(0.0, 10.0, 2.0, 2.0), 0f)
        assertEquals(1f, SmartMix.fade(5.0, 10.0, 2.0, 2.0), 0f)
        assertEquals(0f, SmartMix.fade(10.0, 10.0, 2.0, 2.0), 1e-6f)
        assertEquals(1f, SmartMix.fade(0.0, 5.0, 0.0, 0.0), 0f)
    }

    @Test fun softClipOnlyTouchesLoudPeaks() {
        assertEquals(0.5f, SmartMix.softClip(0.5f), 0f)
        assertTrue(SmartMix.softClip(1.5f) <= 1f)
        assertEquals(-SmartMix.softClip(1.2f), SmartMix.softClip(-1.2f), 1e-6f)
    }
}
