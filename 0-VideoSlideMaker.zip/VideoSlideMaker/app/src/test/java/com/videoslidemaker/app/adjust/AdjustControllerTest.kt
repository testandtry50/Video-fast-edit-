package com.videoslidemaker.app.adjust

import com.videoslidemaker.app.align.AlignmentDecision
import com.videoslidemaker.app.align.AlignmentItem
import com.videoslidemaker.app.align.AlignmentState
import com.videoslidemaker.app.align.AlignmentStatus
import com.videoslidemaker.app.model.SentenceSlide
import com.videoslidemaker.app.model.UiState
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** The whole flow on real slides: preview, apply, originals, the log, undo, and the analysis results kept in step. */
class AdjustControllerTest {

    private class Rig(slides: List<SentenceSlide>, items: List<AlignmentItem> = emptyList()) {
        var s = UiState(slides = slides, scriptLoaded = true, alignment = AlignmentState(items = items))
        var persisted = 0
        var analysed = 0
        val c = AdjustController(state = { s }, update = { f -> s = f(s) }, persist = { persisted++ }, analyse = { analysed++ })
        fun times() = s.slides.map { it.timestampSec }
        fun originals() = s.slides.map { it.originalTimestampSec }
        fun item(i: Int) = s.alignment.items[i]
    }

    private fun slides(vararg secs: Double) = secs.mapIndexed { i, t -> SentenceSlide(t, "Line ${i + 1}") }

    private fun detectedItem(i: Int, cur: Long, detected: Long?, conf: Float, status: AlignmentStatus) =
        AlignmentItem(i, "Line ${i + 1}", cur, cur, detected, null, conf, status, null)

    @Test fun theBriefsExampleEndToEnd() {
        val r = Rig(listOf(SentenceSlide(84.0, "Hello everyone"), SentenceSlide(100.0, "Second line")))
        r.c.chooseMode(AdjustMode.ENTIRE_TRANSCRIPT)
        r.c.setOffsetText("1.43")
        val p = r.c.view().preview.lines[0].proposal
        assertEquals("00:01:24 — Hello everyone", AdjustFormat.scriptLine(p.beforeMs, p.text))
        assertEquals("00:01:25.430 — Hello everyone", AdjustFormat.scriptLine(p.afterMs!!, p.text))
        assertEquals("+1.430 seconds", AdjustFormat.difference(p.diffMs!!))
        assertEquals("nothing changes before Apply", listOf(84.0, 100.0), r.times())
        r.c.applyTicked()
        assertEquals(listOf(85.43, 101.43), r.times())
        assertEquals("the originals are kept", listOf(84.0, 100.0), r.originals())
        assertEquals(1, r.s.adjustLog.size)
        assertEquals(2, r.s.adjustLog[0].changes.size)
        assertEquals(1, r.persisted)
    }

    @Test fun theOriginalSurvivesExactlyThroughAdjustAndRestore() {
        val exact = 84.123456789
        val r = Rig(listOf(SentenceSlide(exact, "A"), SentenceSlide(120.0, "B")))
        r.c.chooseMode(AdjustMode.ENTIRE_TRANSCRIPT)
        r.c.setOffsetText("2")
        r.c.applyTicked()
        assertEquals(86.123, r.times()[0], 0.0)
        assertEquals(exact, r.originals()[0]!!, 0.0)
        r.c.chooseMode(AdjustMode.UNDO)
        r.c.setUndoAction(UndoAction.RESTORE_ALL)
        r.c.applyTicked()
        assertEquals("back to the exact original value, not a rounded copy", exact, r.times()[0], 0.0)
        assertEquals(listOf(null, null), r.originals())
        assertTrue("restoring everything empties the log", r.s.adjustLog.isEmpty())
    }

    @Test fun onlyTheTickedLinesAreMoved_andEarlierWorksFromTheDirectionChip() {
        val r = Rig(slides(10.0, 20.0, 30.0))
        r.c.chooseMode(AdjustMode.SELECTED)
        r.c.setOffsetText("0.5")
        r.c.setEarlier(true)
        r.c.toggleTick(1)
        assertEquals(mapOf(1 to 19_500L), r.c.view().preview.willApply)
        r.c.applyTicked()
        assertEquals(listOf(10.0, 19.5, 30.0), r.times())
        assertEquals(listOf(null, 20.0, null), r.originals())
    }

    @Test fun applyThisOneChangesOneLineAndLeavesTheTicksOfTheOthers() {
        val r = Rig(slides(10.0, 20.0, 30.0))
        r.c.chooseMode(AdjustMode.SELECTED)
        r.c.setOffsetText("1")
        r.c.toggleTick(0); r.c.toggleTick(1)
        r.c.applyOne(1)
        assertEquals(listOf(10.0, 21.0, 30.0), r.times())
        assertEquals(setOf(0), r.c.ui.value.ticked)
    }

    @Test fun anExactTimeIsSetForTheOneTickedLine() {
        val r = Rig(slides(10.0, 20.0, 30.0))
        r.c.chooseMode(AdjustMode.SELECTED)
        r.c.setMethod(SelectedMethod.EXACT)
        r.c.setExactText("00:00:25.430")
        r.c.toggleTick(1)
        assertEquals(mapOf(1 to 25_430L), r.c.view().preview.willApply)
        r.c.applyTicked()
        assertEquals(listOf(10.0, 25.43, 30.0), r.times())
        assertEquals(20.0, r.originals()[1]!!, 0.0)
    }

    @Test fun aWholeTranscriptMoveThatCannotBeDoneChangesNothing() {
        val r = Rig(slides(3.0, 8.0, 15.0))
        r.c.chooseMode(AdjustMode.ENTIRE_TRANSCRIPT)
        r.c.setOffsetText("4")
        r.c.setEarlier(true)
        val v = r.c.view()
        assertFalse(v.canApply)
        assertTrue(v.blocked!!.contains("-3.000 seconds"))        // the earliest it can go
        r.c.applyTicked()
        assertEquals(listOf(3.0, 8.0, 15.0), r.times())
        assertTrue(r.s.adjustLog.isEmpty())
        assertEquals(0, r.persisted)
    }

    @Test fun nothingTickedAppliesNothingAndSaysSo() {
        val r = Rig(slides(10.0, 20.0))
        r.c.chooseMode(AdjustMode.SELECTED)
        r.c.setOffsetText("1")
        r.c.applyTicked()
        assertEquals(listOf(10.0, 20.0), r.times())
        assertTrue(r.c.ui.value.notice!!.startsWith("Nothing to apply"))
        assertEquals(0, r.persisted)
    }

    @Test fun detectedCorrectionsApplyOnlyTheHighConfidenceOnes_andTheAnalysisStaysInStep() {
        val items = listOf(
            detectedItem(0, 10_000L, 11_430L, 0.98f, AlignmentStatus.HIGH_CONFIDENCE),
            detectedItem(1, 20_000L, 21_100L, 0.90f, AlignmentStatus.NEEDS_REVIEW),
            detectedItem(2, 30_000L, null, 0f, AlignmentStatus.CANNOT_ALIGN)
        )
        val r = Rig(slides(10.0, 20.0, 30.0), items)
        r.c.chooseMode(AdjustMode.DETECTED)
        assertEquals("the high-confidence line is ticked for you", setOf(0), r.c.ui.value.ticked)
        r.c.applyHighConfidence()
        assertEquals(listOf(11.43, 20.0, 30.0), r.times())
        assertEquals(10.0, r.originals()[0]!!, 0.0)
        assertEquals(11_430L, r.item(0).currentMs)
        assertEquals(AlignmentDecision.APPLIED, r.item(0).decision)
        assertEquals(AlignmentDecision.PENDING, r.item(1).decision)

        r.c.chooseMode(AdjustMode.UNDO)                                  // undo what was just applied
        assertEquals(UndoAction.LAST_ADJUSTMENT, r.c.ui.value.undoAction)
        r.c.applyTicked()
        assertEquals(listOf(10.0, 20.0, 30.0), r.times())
        assertEquals(listOf(null, null, null), r.originals())
        assertEquals(10_000L, r.item(0).currentMs)
        assertEquals(AlignmentDecision.PENDING, r.item(0).decision)
        assertTrue(r.s.adjustLog.isEmpty())
    }

    @Test fun aManualShiftMarksAnAnalysedLineAsAdjusted_andPuttingItBackMakesItPendingAgain() {
        val items = listOf(detectedItem(0, 10_000L, 11_430L, 0.98f, AlignmentStatus.HIGH_CONFIDENCE), detectedItem(1, 20_000L, 21_000L, 0.97f, AlignmentStatus.HIGH_CONFIDENCE))
        val r = Rig(slides(10.0, 20.0), items)
        r.c.chooseMode(AdjustMode.SELECTED)
        r.c.setOffsetText("0.25")
        r.c.toggleTick(0)
        r.c.applyTicked()                                                 // 10.25: neither the original nor the detected 11.43
        assertEquals(AlignmentDecision.ADJUSTED, r.item(0).decision)
        assertEquals(AlignmentDecision.PENDING, r.item(1).decision)
        assertEquals(10_250L, r.item(0).currentMs)
        r.c.chooseMode(AdjustMode.UNDO)
        r.c.applyTicked()
        assertEquals(AlignmentDecision.PENDING, r.item(0).decision)
        assertEquals(10_000L, r.item(0).currentMs)
    }

    @Test fun aTickedNeedsReviewLineCanBeAppliedOnPurpose() {
        val items = listOf(detectedItem(0, 10_000L, 11_000L, 0.90f, AlignmentStatus.NEEDS_REVIEW), detectedItem(1, 20_000L, 21_000L, 0.97f, AlignmentStatus.HIGH_CONFIDENCE))
        val r = Rig(slides(10.0, 20.0), items)
        r.c.chooseMode(AdjustMode.DETECTED)
        r.c.toggleTick(0)
        r.c.applyTicked()
        assertEquals(listOf(11.0, 21.0), r.times())
    }

    @Test fun undoLastRevertsOnlyTheLatestAdjustment_thenRestoreAllGoesBackToTheOriginals() {
        val r = Rig(slides(10.0, 20.0, 30.0))
        r.c.chooseMode(AdjustMode.ENTIRE_TRANSCRIPT)
        r.c.setOffsetText("1"); r.c.applyTicked()
        r.c.setOffsetText("2"); r.c.applyTicked()
        assertEquals(listOf(13.0, 23.0, 33.0), r.times())
        assertEquals(2, r.s.adjustLog.size)
        assertEquals("the ORIGINAL is the very first time, not the intermediate one", listOf(10.0, 20.0, 30.0), r.originals())

        r.c.chooseMode(AdjustMode.UNDO)
        r.c.applyTicked()                                              // last adjustment only
        assertEquals(listOf(11.0, 21.0, 31.0), r.times())
        assertEquals(1, r.s.adjustLog.size)
        assertEquals(listOf(10.0, 20.0, 30.0), r.originals())

        r.c.setUndoAction(UndoAction.RESTORE_ALL)
        r.c.applyTicked()
        assertEquals(listOf(10.0, 20.0, 30.0), r.times())
        assertEquals(listOf(null, null, null), r.originals())
        assertTrue(r.s.adjustLog.isEmpty())
    }

    @Test fun undoLeavesAlone_aLineThatWasChangedAgainByHand() {
        val r = Rig(slides(10.0, 20.0))
        r.c.chooseMode(AdjustMode.ENTIRE_TRANSCRIPT)
        r.c.setOffsetText("1"); r.c.applyTicked()
        r.s = r.s.copy(slides = r.s.slides.toMutableList().also { it[1] = it[1].copy(timestampSec = 22.5) })   // moved by hand afterwards
        r.c.chooseMode(AdjustMode.UNDO)
        r.c.applyTicked()
        assertEquals(listOf(10.0, 22.5), r.times())
    }

    @Test fun restoreSelectedPutsBackOnlyThePickedLines() {
        val r = Rig(slides(10.0, 20.0, 30.0))
        r.c.chooseMode(AdjustMode.ENTIRE_TRANSCRIPT)
        r.c.setOffsetText("1"); r.c.applyTicked()
        r.c.chooseMode(AdjustMode.UNDO)
        r.c.setUndoAction(UndoAction.RESTORE_SELECTED)
        assertTrue("nothing is ticked until the user ticks", r.c.view().preview.willApply.isEmpty())
        r.c.toggleTick(2)
        r.c.applyTicked()
        assertEquals(listOf(11.0, 21.0, 30.0), r.times())
        assertEquals(listOf(10.0, 20.0, null), r.originals())
    }

    @Test fun startingTheAnalysisFromHereAndTickingWhenItFinishes() {
        val r = Rig(slides(10.0, 20.0))
        r.c.chooseMode(AdjustMode.AUTO_SYNC)
        assertTrue(r.c.ui.value.ticked.isEmpty())
        r.c.analyseNow()
        assertEquals(1, r.analysed)
        r.s = r.s.copy(alignment = r.s.alignment.copy(items = listOf(
            detectedItem(0, 10_000L, 11_000L, 0.97f, AlignmentStatus.HIGH_CONFIDENCE),
            detectedItem(1, 20_000L, 20_500L, 0.80f, AlignmentStatus.NEEDS_REVIEW)
        )))
        r.c.onAnalysisFinished()
        assertEquals(setOf(0), r.c.ui.value.ticked)
    }

    @Test fun nudgeCarriesItsOwnSignAndBumpsTheFieldVersion() {
        val r = Rig(slides(10.0))
        r.c.chooseMode(AdjustMode.SELECTED)
        val v0 = r.c.ui.value.textVersion
        r.c.setOffsetText("1.43")
        r.c.nudge(-100L)
        assertEquals("+1.330", r.c.ui.value.offsetText)
        assertTrue(r.c.ui.value.textVersion > v0)
        r.c.setEarlier(true)
        r.c.setOffsetText("1.43")
        r.c.nudge(1_000L)                                              // -1.43 s + 1 s
        assertEquals("-0.430", r.c.ui.value.offsetText)
        assertEquals("+0.000", AdjustController.signedText(0L))
    }

    @Test fun aTypingMistakeDoesNotApplyAnything() {
        val r = Rig(slides(10.0, 20.0))
        r.c.chooseMode(AdjustMode.ENTIRE_TRANSCRIPT)
        r.c.setOffsetText("soon")
        val v = r.c.view()
        assertFalse(v.canApply)
        assertTrue(v.hint!!.contains("seconds"))
        r.c.applyTicked()
        assertEquals(listOf(10.0, 20.0), r.times())
        assertNull(r.originals()[0])
    }
}
