package com.videoslidemaker.app.voicefx

import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertSame
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Checks the voice changer. The "matches the Python reference" test compares the Kotlin code, sample
 * for sample, with numbers produced by tools/voicefx-reference/dsp.py (run make_golden.py to regenerate),
 * which is where pitch accuracy, level, sync and breath placement were measured on a speech-like signal.
 */
class VoiceFxTest {
    private val fs = 44100

    private fun mix(i: Int): Double {
        val t = i.toDouble() / fs
        return 0.5 * sin(2.0 * PI * 220.0 * t) + 0.2 * sin(2.0 * PI * 1375.0 * t)
    }

    /** Raw processor output (no delay removed): [0] = left, [1] = right. */
    private fun render(settings: VoiceFxSettings, n: Int, signal: (Int) -> Double = { mix(it) }): Array<DoubleArray> {
        val p = VoiceProcessor(fs, settings, 0)
        val l = DoubleArray(n)
        val r = DoubleArray(n)
        val out = DoubleArray(2)
        for (i in 0 until n) {
            p.process(signal(i), out)
            l[i] = out[0]
            r[i] = out[1]
        }
        return arrayOf(l, r)
    }

    private fun rms(a: DoubleArray, from: Int, to: Int): Double {
        var acc = 0.0
        for (i in from until to) acc += a[i] * a[i]
        return sqrt(acc / (to - from))
    }

    private fun db(v: Double): Double = 20.0 * log10(max(v, 1e-12))

    // ------------------------------------------------------------------ matches the reference

    private class Golden(val name: String, val settings: VoiceFxSettings, val values: DoubleArray)

    private val golden = listOf(
        Golden("pitch +3", VoiceFxSettings(pitchSemitones = 3f),
            doubleArrayOf(0.152454803699, 0.152454803699, 0.414394347976, 0.414394347976, 0.264740051685, 0.264740051685)),
        Golden("humanize 0.5", VoiceFxSettings(humanize = 0.5f),
            doubleArrayOf(-0.056902840396, -0.083215507127, 0.140372371390, 0.144806391918, 0.226544523699, 0.236570994164)),
        Golden("aqua", VoiceFxSettings(effect = VoiceEffect.AQUA, effectAmount = 0.5f, effectSpeed = 0.5f),
            doubleArrayOf(0.524666251640, 0.310616405714, 0.063702016570, 0.311443100538, -0.143904826124, 0.412932746982)),
        Golden("revolve", VoiceFxSettings(effect = VoiceEffect.REVOLVE, effectAmount = 0.75f, effectSpeed = 0.5f),
            doubleArrayOf(-0.082054717104, -0.104514825028, -0.317859205989, -0.236267211728, -0.106777830384, -0.127825761964)),
        Golden("hall", VoiceFxSettings(effect = VoiceEffect.HALL, effectAmount = 0.5f),
            doubleArrayOf(-0.132485384971, -0.172599289788, -0.167673470997, -0.105892270581, -0.145791485470, -0.163042417522)),
        Golden("whisper", VoiceFxSettings(effect = VoiceEffect.WHISPER, effectAmount = 0.5f),
            doubleArrayOf(0.357842242789, 0.357842242789, -0.368876089889, -0.368876089889, -0.422313622958, -0.422313622958)),
        Golden("echo", VoiceFxSettings(effect = VoiceEffect.ECHO, effectAmount = 0.5f),
            doubleArrayOf(-0.152630487391, -0.152630487391, -0.116657960577, -0.116657960577, -0.167247108510, -0.167247108510)),
        Golden("megaphone", VoiceFxSettings(effect = VoiceEffect.MEGAPHONE, effectAmount = 0.5f),
            doubleArrayOf(-0.357303102993, -0.357303102993, 0.238990490578, 0.238990490578, 0.074677122367, 0.074677122367)),
        Golden("pitch + humanize + robot", VoiceFxSettings(pitchSemitones = -2.5f, humanize = 0.75f, effect = VoiceEffect.ROBOT, effectAmount = 0.5f),
            doubleArrayOf(-0.093301873843, -0.093301873843, -0.036109205572, -0.036109205572, 0.089135382795, 0.089135382795))
    )

    @Test fun noiseGeneratorMatchesReference() {
        val r = Rng(0x2545F491)
        assertEquals(0.7589328289031982, r.next(), 1e-15)
        assertEquals(0.09065103530883789, r.next(), 1e-15)
        assertEquals(-0.2118622064590454, r.next(), 1e-15)
        assertEquals(1525286, r.nextU32())
    }

    @Test fun everyStageMatchesThePythonReference() {
        val indices = intArrayOf(3000, 6000, 7999)
        for (g in golden) {
            val out = render(g.settings, 8000)
            val got = DoubleArray(6)
            for (k in indices.indices) {
                got[k * 2] = out[0][indices[k]]
                got[k * 2 + 1] = out[1][indices[k]]
            }
            assertArrayEquals("stage: ${g.name}", g.values, got, 1e-6)
        }
    }

    // ------------------------------------------------------------------ pitch

    /** Frequency of a clean tone from upward zero crossings between two times. */
    private fun frequencyOf(x: DoubleArray, fromSec: Double, toSec: Double): Double {
        val a = (fromSec * fs).toInt()
        val b = (toSec * fs).toInt()
        var crossings = 0
        var first = -1.0
        var last = -1.0
        for (i in a + 1 until b) {
            if (x[i - 1] < 0.0 && x[i] >= 0.0) {
                val frac = -x[i - 1] / (x[i] - x[i - 1])
                val pos = (i - 1) + frac
                if (first < 0) first = pos
                last = pos
                crossings++
            }
        }
        return (crossings - 1) * fs / (last - first)
    }

    @Test fun pitchIsAccurateInSmallAndLargeSteps() {
        val tone = { i: Int -> 0.5 * sin(2.0 * PI * 220.0 * i / fs) }
        for (st in listOf(-12.0f, -2.35f, -0.5f, 0.01f, 0.5f, 2.35f, 7.0f, 12.0f)) {
            val out = render(VoiceFxSettings(pitchSemitones = st), (fs * 1.6).toInt(), tone)
            val want = 220.0 * 2.0.pow(st / 12.0)
            val got = frequencyOf(out[0], 0.5, 1.4)
            val cents = 1200.0 * log10(got / want) / log10(2.0)
            assertTrue("pitch $st st: expected $want Hz, got $got Hz ($cents cents off)", abs(cents) < 5.0)
        }
    }

    @Test fun pitchKeepsTheLevel() {
        val tone = { i: Int -> 0.4 * sin(2.0 * PI * 300.0 * i / fs) }
        for (st in listOf(-5f, 3f)) {
            val out = render(VoiceFxSettings(pitchSemitones = st), fs * 2, tone)
            val change = db(rms(out[0], fs, fs * 2 - 3000) / rms(DoubleArray(fs * 2) { tone(it) }, fs, fs * 2 - 3000))
            assertTrue("level changed by $change dB at $st st", abs(change) < 1.5)
        }
    }

    // ------------------------------------------------------------------ nothing happens when everything is off

    @Test fun inactiveSettingsLeaveTheSoundUntouched() {
        val fx = VoiceFxSettings()
        assertFalse(fx.isActive)
        val pcm = ByteArray(4000) { (it % 97).toByte() }
        assertSame(pcm, VoiceFxPcm.processClip(pcm, fs, 2, fx))
        assertEquals("Off", fx.summary())
    }

    @Test fun summaryAndPitchText() {
        assertEquals("+2.35", VoiceFxSettings.formatPitch(2.35f))
        assertEquals("-0.10", VoiceFxSettings.formatPitch(-0.1f))
        assertEquals("0.00", VoiceFxSettings.formatPitch(-0.004f))
        assertEquals("-24.00", VoiceFxSettings.formatPitch(-24f))
        val fx = VoiceFxSettings(pitchSemitones = 2.35f, humanize = 0.5f, breaths = true, effect = VoiceEffect.AQUA)
        assertEquals("Pitch +2.35 · Human 50% · Breaths · Aqua", fx.summary())
    }

    // ------------------------------------------------------------------ streaming in pieces

    private fun tonePcm(frames: Int): ByteArray {
        val b = ByteArray(frames * 4)
        for (i in 0 until frames) {
            val v = (0.4 * 32767.0 * sin(2.0 * PI * 330.0 * i / fs)).toInt()
            val w = (0.3 * 32767.0 * sin(2.0 * PI * 1200.0 * i / fs)).toInt()
            b[i * 4] = (v and 0xFF).toByte(); b[i * 4 + 1] = ((v shr 8) and 0xFF).toByte()
            b[i * 4 + 2] = (w and 0xFF).toByte(); b[i * 4 + 3] = ((w shr 8) and 0xFF).toByte()
        }
        return b
    }

    @Test fun processingInOddSizedPiecesGivesTheSameSoundAndTheSameLength() {
        val fx = VoiceFxSettings(pitchSemitones = 2f, humanize = 0.5f, effect = VoiceEffect.HALL, effectAmount = 0.5f)
        val pcm = tonePcm(fs / 2)
        val tailFrames = 4000

        val whole = VoiceFxPcmStream(fx, fs, 2, 0)
        val a = whole.process(pcm) + whole.finish(tailFrames)

        val pieces = VoiceFxPcmStream(fx, fs, 2, 0)
        var b = ByteArray(0)
        var pos = 0
        val sizes = intArrayOf(4, 1000, 36, 8192, 12, 5000)
        var k = 0
        while (pos < pcm.size) {
            val n = minOf(sizes[k % sizes.size], pcm.size - pos)
            b += pieces.process(pcm.copyOfRange(pos, pos + n))
            pos += n
            k++
        }
        b += pieces.finish(tailFrames)

        assertEquals("length: the sound plus exactly the tail", pcm.size + tailFrames * 4, a.size)
        assertEquals(a.size, b.size)
        assertTrue("pieces and whole must agree", a.contentEquals(b))
    }

    @Test fun humanizeKeepsTheSoundLinedUpWithTheOriginal() {
        // The humanizer delays the sound by 2 ms inside (88 samples); the stream must remove that so the
        // words stay exactly where the timestamps put them. A single click is the sharpest way to see it.
        val pcm = ByteArray(fs * 4)
        val click = (0.8 * 32767.0).toInt()
        pcm[20000 * 4] = (click and 0xFF).toByte()
        pcm[20000 * 4 + 1] = ((click shr 8) and 0xFF).toByte()
        pcm[20000 * 4 + 2] = pcm[20000 * 4]
        pcm[20000 * 4 + 3] = pcm[20000 * 4 + 1]
        val s = VoiceFxPcmStream(VoiceFxSettings(humanize = 0.8f), fs, 2, 0)
        val out = s.process(pcm) + s.finish(0)
        assertEquals(pcm.size, out.size)
        var peakPos = 0
        var peak = -1
        for (j in 0 until fs) {
            val v = abs(((out[j * 4 + 1].toInt() shl 8) or (out[j * 4].toInt() and 0xFF)).toShort().toInt())
            if (v > peak) {
                peak = v
                peakPos = j
            }
        }
        // the slow pitch drift moves it by up to about 28 samples either way; an uncorrected delay would be at 20088
        assertTrue("click was at 20000, found at $peakPos", peakPos in 19940..20040)
    }

    // ------------------------------------------------------------------ breaths

    @Test fun aBreathOnlyAppearsInARealPause() {
        val speech = { i: Int -> 0.3 * sin(2.0 * PI * 200.0 * i / fs) }
        val first = fs               // 1 s of speech
        val pause = (fs * 1.2).toInt()
        val total = first * 2 + pause
        val sig = { i: Int -> if (i < first || i >= first + pause) speech(i) else 0.0 }
        val out = render(VoiceFxSettings(breaths = true), total, sig)[0]
        var firstExtra = -1
        var lastExtra = -1
        var peak = 0.0
        for (i in 0 until total) {
            val extra = abs(out[i] - sig(i))
            if (extra > 1e-5) {
                if (firstExtra < 0) firstExtra = i
                lastExtra = i
                peak = max(peak, extra)
            }
        }
        assertTrue("a breath should be added", firstExtra >= 0)
        assertTrue("breath must stay inside the pause ($firstExtra..$lastExtra)", firstExtra >= first && lastExtra < first + pause)
        assertTrue("breath should be quiet (peak $peak)", db(peak) < -26.0)

        // a short pause (0.15 s) is not a breath
        val shortPause = (fs * 0.15).toInt()
        val sig2 = { i: Int -> if (i < first || i >= first + shortPause) speech(i) else 0.0 }
        val out2 = render(VoiceFxSettings(breaths = true), first * 2 + shortPause, sig2)[0]
        for (i in out2.indices) assertEquals(sig2(i), out2[i], 0.0)
    }

    // ------------------------------------------------------------------ effects

    @Test fun everyEffectStaysFiniteBoundedAndAtASaneLevel() {
        val voiceLike = { i: Int ->
            val t = i.toDouble() / fs
            val env = if ((t % 0.5) < 0.3) 1.0 else 0.0
            env * (0.4 * sin(2.0 * PI * 140.0 * t) + 0.25 * sin(2.0 * PI * 700.0 * t) + 0.15 * sin(2.0 * PI * 1900.0 * t))
        }
        val n = fs * 2
        val input = DoubleArray(n) { voiceLike(it) }
        for (effect in VoiceEffect.entries) {
            if (effect == VoiceEffect.NONE) continue
            for (amount in listOf(0f, 0.6f, 1f)) {
                val out = render(VoiceFxSettings(effect = effect, effectAmount = amount, effectSpeed = 1f), n, voiceLike)
                for (ch in 0..1) {
                    for (v in out[ch]) {
                        assertTrue("$effect $amount: not finite", v.isFinite())
                        assertTrue("$effect $amount: too loud ($v)", abs(v) < 1.0)
                    }
                }
                val level = db(sqrt((rms(out[0], 0, n).pow(2) + rms(out[1], 0, n).pow(2)) / 2.0) / rms(input, 0, n))
                assertTrue("$effect $amount: level changed by $level dB", level > -8.0 && level < 6.0)
            }
        }
    }

    @Test fun revolveMovesTheVoiceBetweenTheEars() {
        val tone = { i: Int -> 0.4 * sin(2.0 * PI * 250.0 * i / fs) }
        val n = fs * 6
        val out = render(VoiceFxSettings(effect = VoiceEffect.REVOLVE, effectAmount = 1f, effectSpeed = 1f), n, tone)
        var lo = 1e9
        var hi = -1e9
        val w = fs / 2
        var i = 0
        while (i + w <= n) {
            val balance = db(rms(out[0], i, i + w)) - db(rms(out[1], i, i + w))
            lo = minOf(lo, balance)
            hi = max(hi, balance)
            i += w
        }
        assertTrue("left/right balance should swing both ways (got $lo .. $hi dB)", hi > 3.0 && lo < -3.0)
    }

    @Test fun silenceInStaysQuietWithoutHumanize() {
        for (effect in listOf(VoiceEffect.ROOM, VoiceEffect.HALL, VoiceEffect.ECHO, VoiceEffect.ROBOT, VoiceEffect.TELEPHONE, VoiceEffect.MEGAPHONE, VoiceEffect.WHISPER, VoiceEffect.REVOLVE)) {
            val out = render(VoiceFxSettings(effect = effect, effectAmount = 1f), fs) { 0.0 }
            assertTrue("$effect should be silent for silence", out[0].all { abs(it) < 1e-6 })
        }
    }
}
