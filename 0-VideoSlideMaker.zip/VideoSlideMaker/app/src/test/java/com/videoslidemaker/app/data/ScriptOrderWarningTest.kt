package com.videoslidemaker.app.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** A line whose time is earlier than the one before it is kept but reported (the "01.00 meant 1:00" mistake). */
class ScriptOrderWarningTest {

    @Test fun aTimeThatGoesBackwardsIsReportedWithItsLineNumber() {
        val r = ScriptParser.parseScriptDetailed("00.00 - a\n03.00 - b\n57.00 - c\n01.00 - d")
        assertTrue(r.issues.isEmpty())
        assertEquals(4, r.lines.size)
        assertEquals(listOf(4), r.warnings.map { it.lineNumber })
        assertTrue(r.warnings[0].message, r.warnings[0].message.contains("1:00"))
    }

    @Test fun aScriptInOrderHasNoWarnings() {
        val r = ScriptParser.parseScriptDetailed("0:00 - a\n0:03 - b\n1:00 - c")
        assertTrue(r.warnings.isEmpty())
    }
}
