package com.videoslidemaker.app.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** Runs the hand-written expectations in src/test/resources/transcript_formats.txt against [TranscriptFormats]. */
class TranscriptFormatsTest {

    private val lines: List<String> by lazy {
        javaClass.classLoader!!.getResourceAsStream("transcript_formats.txt")!!.bufferedReader(Charsets.UTF_8).use { it.readLines() }
    }

    @Test fun everyShapeIsRewrittenAsSpecifiedAndEverythingElseIsLeftAlone() {
        var n = 0
        for (l in lines) {
            if (!l.startsWith("NORM\t")) continue
            val p = l.split("\t")
            assertEquals("normalizeShape(\"${p[1]}\")", p[2], TranscriptFormats.normalizeShape(p[1]))
            n++
        }
        assertTrue("expected plenty of cases, found $n", n >= 40)
    }

    @Test fun cuesAreJoinedIndexesAndHeadersDroppedAndLineNumbersKept() {
        var i = 0
        var blocks = 0
        while (i < lines.size) {
            if (!lines[i].startsWith("LOGICAL_BEGIN ")) { i++; continue }
            val name = lines[i].removePrefix("LOGICAL_BEGIN ")
            i++
            val raw = ArrayList<String>()
            while (lines[i] != "LOGICAL_EXPECT") raw.add(lines[i++])
            i++
            val expected = ArrayList<Pair<Int, String>>()
            while (lines[i] != "LOGICAL_END") {
                val p = lines[i++].split("\t")
                expected.add(p[0].toInt() to p[1])
            }
            val got = TranscriptFormats.logicalLines(raw.joinToString("\n")).map { it.lineNumber to it.text }
            assertEquals("logical lines of '$name'", expected, got)
            blocks++
        }
        assertTrue("expected several blocks, found $blocks", blocks >= 6)
    }

    @Test fun frameBasedTimecodesAreRecognisedButNotGuessed() {
        assertTrue(TranscriptFormats.looksLikeFrameTimecode("00:05:20:12 Hello"))
        assertTrue(TranscriptFormats.looksLikeFrameTimecode("00:05:20;12 Hello"))
        assertTrue(!TranscriptFormats.looksLikeFrameTimecode("00:05:20.120 Hello"))
        assertTrue(!TranscriptFormats.looksLikeFrameTimecode("0:05:20 Hello"))
    }
}
