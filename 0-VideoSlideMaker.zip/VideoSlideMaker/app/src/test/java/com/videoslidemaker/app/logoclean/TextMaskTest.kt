package com.videoslidemaker.app.logoclean

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Tests for the subtitle / text cleaner. The synthetic scenarios are identical to
 * tools/textclean-reference/mirror_scenarios.py, which was run first - the numbers asserted here (with margins)
 * are what that Python reference measured:
 *
 *   caption white + black outline : found, r=5, 17 stroke runs, ink contrast 240, pair 1.00, every letter pixel
 *                                   covered, mask = 1.53 x the letters, nothing outside the box
 *   no text / thin line / stripes : not found
 *   faint caption (+80 grey)      : strict gate says no (ink contrast below 110), relaxed gate finds it
 *   REMOVE                        : 1.3 grey levels average error inside the letters, far pixels untouched
 *   BLUR                          : edge contrast over the letters 44.0 -> 0.5
 */
class TextMaskTest {
    private val W = 360
    private val H = 140
    private val boxX0 = 40
    private val boxY0 = 40
    private val boxX1 = 320
    private val boxY1 = 100
    private val textX = 70
    private val textY = 62
    private val scale = 3
    private val outline = 2

    private val font = mapOf(
        'H' to listOf("X...X", "X...X", "X...X", "XXXXX", "X...X", "X...X", "X...X"),
        'E' to listOf("XXXXX", "X....", "X....", "XXXX.", "X....", "X....", "XXXXX"),
        'L' to listOf("X....", "X....", "X....", "X....", "X....", "X....", "XXXXX"),
        'O' to listOf(".XXX.", "X...X", "X...X", "X...X", "X...X", "X...X", ".XXX."),
        'T' to listOf("XXXXX", "..X..", "..X..", "..X..", "..X..", "..X..", "..X.."),
        'S' to listOf(".XXXX", "X....", "X....", ".XXX.", "....X", "....X", "XXXX."),
        ' ' to List(7) { "....." }
    )

    // ------------------------------------------------------------------------------ scene helpers

    /** Smooth "scenery": a gentle ramp plus a soft wave. */
    private fun background(): FloatArray {
        val v = FloatArray(W * H)
        for (y in 0 until H) {
            for (x in 0 until W) {
                v[y * W + x] = (90.0 + 0.2 * x + 0.25 * y + 10.0 * sin(0.05 * x)).coerceIn(0.0, 255.0).toFloat()
            }
        }
        return v
    }

    private fun fillMask(text: String): BooleanArray {
        val m = BooleanArray(W * H)
        for ((i, ch) in text.withIndex()) {
            val rows = font.getValue(ch)
            for (cy in rows.indices) {
                for (cx in 0 until 5) {
                    if (rows[cy][cx] != 'X') continue
                    val x0 = textX + (i * 6 + cx) * scale
                    val y0 = textY + cy * scale
                    for (y in y0 until y0 + scale) for (x in x0 until x0 + scale) m[y * W + x] = true
                }
            }
        }
        return m
    }

    /** A caption: letters of [fill] brightness, with a black-ish outline unless [outlineValue] is null. */
    private class Scene(val values: FloatArray, val glyph: BooleanArray)

    private fun caption(text: String = "HELLO TEST", fill: Float = 250f, outlineValue: Float? = 10f): Scene {
        val v = background()
        val f = fillMask(text)
        var glyph = f
        if (outlineValue != null) {
            glyph = maxFilter(f, W, H, outline)
            for (i in v.indices) if (glyph[i]) v[i] = outlineValue
        }
        for (i in v.indices) if (f[i]) v[i] = fill
        return Scene(v, glyph)
    }

    private fun argbOf(v: FloatArray): IntArray = IntArray(v.size) {
        val g = floor(v[it] + 0.5f).toInt().coerceIn(0, 255)
        (0xFF shl 24) or (g shl 16) or (g shl 8) or g
    }

    private fun region(): BooleanArray {
        val r = BooleanArray(W * H)
        for (y in boxY0 until boxY1) for (x in boxX0 until boxX1) r[y * W + x] = true
        return r
    }

    private fun grey(argb: Int): Int = argb and 0xFF

    // ------------------------------------------------------------------------------ the finder

    @Test
    fun findsTheLettersOfACaptionAndNothingOutsideTheBox() {
        val scene = caption()
        val found = TextMask.detect(argbOf(scene.values), W, H, region(), relaxed = false)
        assertNotNull("a white caption with a black outline must be found", found)
        found!!
        assertEquals("stroke radius follows the 60 px box", 5, found.radius)
        var glyphPx = 0
        var covered = 0
        var maskPx = 0
        var outsideBox = 0
        val reg = region()
        for (i in 0 until W * H) {
            if (scene.glyph[i]) {
                glyphPx++
                if (found.mask[i]) covered++
            }
            if (found.mask[i]) {
                maskPx++
                if (!reg[i]) outsideBox++
            }
        }
        assertTrue("every letter pixel is covered (reference: 100%), got $covered of $glyphPx", covered >= 0.97 * glyphPx)
        assertTrue("the mask hugs the letters (reference 1.53x), got ${maskPx.toFloat() / glyphPx}x", maskPx <= 2.2 * glyphPx)
        assertEquals("only pixels inside the box may ever change", 0, outsideBox)
        assertTrue("it is mostly letters, not the whole 280x60 box", found.cover in 0.1f..0.4f)
    }

    @Test
    fun theBlurMaskIsTheLettersMergedIntoWords() {
        val scene = caption()
        val found = TextMask.detect(argbOf(scene.values), W, H, region(), relaxed = false)!!
        var tight = 0
        var merged = 0
        var tightNotInMerged = 0
        for (i in 0 until W * H) {
            if (found.mask[i]) tight++
            if (found.blurMask[i]) merged++
            if (found.mask[i] && !found.blurMask[i]) tightNotInMerged++
        }
        assertTrue("the blur mask covers at least the tight mask's letters (reference 1.62x the letters)", merged >= tight - tight / 20)
        assertTrue("... and fills the gaps between letters", merged > tight)
        assertTrue("every tight pixel is inside the merged shape", tightNotInMerged < tight / 20)
    }

    @Test
    fun aPictureWithoutTextIsLeftAlone() {
        val argb = argbOf(background())
        assertNull(TextMask.detect(argb, W, H, region(), relaxed = false))
        assertNull("even the relaxed gate finds nothing on smooth shading", TextMask.detect(argb, W, H, region(), relaxed = true))
    }

    @Test
    fun aThinLineIsNotText() {
        // a lip line, a wire, an eyebrow: one stroke, however dark
        val v = background()
        for (y in 69..70) for (x in 100 until 260) v[y * W + x] = 40f
        val argb = argbOf(v)
        assertNull(TextMask.detect(argb, W, H, region(), relaxed = false))
        assertNull(TextMask.detect(argb, W, H, region(), relaxed = true))
    }

    @Test
    fun aFineTextureIsNotText() {
        val v = FloatArray(W * H)
        for (y in 0 until H) {
            for (x in 0 until W) {
                v[y * W + x] = if (sin(2.0 * Math.PI * (x + y) / 6.0) >= 0.0) 198f else 58f
            }
        }
        assertNull(TextMask.detect(argbOf(v), W, H, region(), relaxed = false))
    }

    @Test
    fun aFaintCaptionNeedsTheRelaxedGate() {
        val v = background()
        val f = fillMask("HELLO")
        for (i in v.indices) if (f[i]) v[i] = v[i] + 80f
        val argb = argbOf(v)
        assertNull("only a little brighter than the picture: not clearly text", TextMask.detect(argb, W, H, region(), relaxed = false))
        val relaxed = TextMask.detect(argb, W, H, region(), relaxed = true)
        assertNotNull("'Everywhere in the box' also cleans faint text", relaxed)
        var covered = 0
        var total = 0
        for (i in 0 until W * H) {
            if (f[i]) {
                total++
                if (relaxed!!.mask[i]) covered++
            }
        }
        assertTrue("the letters are covered, got $covered of $total", covered >= 0.97 * total)
    }

    // ------------------------------------------------------------------------------ repainting

    @Test
    fun removeRepaintsOnlyTheLetters() {
        val scene = caption()
        val bg = background()
        val argb = argbOf(scene.values)
        val found = TextMask.detect(argb, W, H, region(), relaxed = false)!!
        val out = LogoPaint.paint(argb, W, H, found.mask, LogoCleanMode.REMOVE, 0.4f, found.blurMask)
        var err = 0.0
        var n = 0
        for (i in 0 until W * H) {
            if (scene.glyph[i]) {
                err += abs(grey(out[i]) - bg[i].toDouble())
                n++
            }
        }
        val mean = err / n
        assertTrue("the letters are painted back to the picture (reference 1.3 grey levels), got $mean", mean < 6.0)

        // pixels well away from the mask are exactly what they were
        val near = maxFilter(found.mask, W, H, 14)
        var changedFar = 0
        for (i in 0 until W * H) if (!near[i] && out[i] != argb[i]) changedFar++
        assertEquals("nothing far from the letters changes", 0, changedFar)
    }

    @Test
    fun blurSmudgesTheWordsSoNoLetterShapeIsLeft() {
        val scene = caption()
        val argb = argbOf(scene.values)
        val found = TextMask.detect(argb, W, H, region(), relaxed = false)!!
        val out = LogoPaint.paint(argb, W, H, found.mask, LogoCleanMode.BLUR, 0.4f, found.blurMask)
        fun edgeEnergy(p: IntArray): Double {
            var sum = 0.0
            var n = 0
            for (y in 0 until H) {
                for (x in 1 until W) {
                    if (scene.glyph[y * W + x]) {
                        sum += abs(grey(p[y * W + x]) - grey(p[y * W + x - 1]))
                        n++
                    }
                }
            }
            return sum / max(1, n)
        }
        val before = edgeEnergy(argb)
        val after = edgeEnergy(out)
        assertTrue("letters are sharp to begin with (reference 44), got $before", before > 25.0)
        assertTrue("and unreadable afterwards (reference 0.5), got $after", after < 0.3 * before)
    }

    @Test
    fun blurWithoutAnExtraMaskBehavesAsItAlwaysDid() {
        // a logo: no blurMask passed -> the same pixels as passing the mask itself
        val mask = BooleanArray(W * H)
        for (y in 50 until 90) for (x in 100 until 200) mask[y * W + x] = true
        val argb = argbOf(background())
        val a = LogoPaint.paint(argb, W, H, mask, LogoCleanMode.BLUR, 0.5f)
        val b = LogoPaint.paint(argb, W, H, mask, LogoCleanMode.BLUR, 0.5f, mask)
        assertTrue(a.contentEquals(b))
    }

    // ------------------------------------------------------------------------------ planning the window

    @Test
    fun theTextWindowIsTheBoxPlusAMargin() {
        val plan = LogoPaint.planTextRegion(1000, 600, LogoBox(0.1f, 0.7f, 0.9f, 0.9f))
        assertNotNull(plan)
        plan!!
        // box 800 x 120 at (100, 420); margin = max(24, half the shorter side = 60) = 60, cut at the photo's edge
        assertEquals(40, plan.x0)
        assertEquals(360, plan.y0)
        assertEquals(920, plan.w)
        assertEquals(240, plan.h)
        var inside = 0
        for (b in plan.mask) if (b) inside++
        assertEquals("the mask is exactly the box", 800 * 120, inside)
        assertTrue("box centre is in", plan.mask[(480 - plan.y0) * plan.w + (500 - plan.x0)])
        assertFalse("the margin is not", plan.mask[0])
    }

    @Test
    fun aTinyOrHugeTextBoxIsRefused() {
        assertNull("one pixel", LogoPaint.planTextRegion(1000, 600, LogoBox(0.5f, 0.5f, 0.501f, 0.501f)))
        assertNull("a window too big to repaint", LogoPaint.planTextRegion(6000, 4000, LogoBox(0.02f, 0.02f, 0.98f, 0.98f)))
    }

    @Test
    fun aWideSubtitleStripOnA4KPhotoStillFits() {
        // the logo window would be the whole photo (8.3 M pixels); the text window is just the strip
        val plan = LogoPaint.planTextRegion(3840, 2160, CleanTarget.SUBTITLE_BOX)
        assertNotNull(plan)
        assertTrue(plan!!.w.toLong() * plan.h < 3_000_000L)
    }

    // ------------------------------------------------------------------------------ building blocks

    @Test
    fun strokeRadiusFollowsTheBoxHeight() {
        assertEquals(3, TextMask.strokeRadius(30))
        assertEquals(5, TextMask.strokeRadius(60))
        assertEquals(9, TextMask.strokeRadius(100))
        assertEquals("capped", 14, TextMask.strokeRadius(400))
        assertEquals("never zero", 2, TextMask.strokeRadius(4))
    }

    @Test
    fun theMinMaxFilterMatchesABruteForceSearch() {
        val w = 17
        val h = 11
        var seed = 12345L
        val v = FloatArray(w * h) {
            seed = (seed * 1103515245L + 12345L) and 0x7fffffffL
            (seed % 256).toFloat()
        }
        for (r in intArrayOf(1, 2, 5, 9)) {
            for (takeMin in booleanArrayOf(true, false)) {
                val fast = TextMask.extreme2d(v, w, h, r, takeMin)
                for (y in 0 until h) {
                    for (x in 0 until w) {
                        var best = if (takeMin) Float.MAX_VALUE else -Float.MAX_VALUE
                        for (yy in max(0, y - r)..min(h - 1, y + r)) {
                            for (xx in max(0, x - r)..min(w - 1, x + r)) {
                                val p = v[yy * w + xx]
                                best = if (takeMin) min(best, p) else max(best, p)
                            }
                        }
                        assertEquals("r=$r min=$takeMin at ($x,$y)", best, fast[y * w + x], 0f)
                    }
                }
            }
        }
    }

    @Test
    fun closingBridgesASmallGapAndNotABigOne() {
        val w = 14
        val h = 9
        val near = BooleanArray(w * h)
        near[4 * w + 3] = true
        near[4 * w + 8] = true
        val merged = TextMask.closeRect(near, w, h, 3, 1)
        for (x in 3..8) assertTrue("gap bridged at x=$x", merged[4 * w + x])
        assertFalse(merged[0 * w + 5])
        assertFalse(merged[3 * w + 5])

        val w2 = 30
        val far = BooleanArray(w2 * h)
        far[4 * w2 + 3] = true
        far[4 * w2 + 20] = true
        val kept = TextMask.closeRect(far, w2, h, 3, 1)
        for (x in 8..15) assertFalse("a 17 px gap stays open at x=$x", kept[4 * w2 + x])
    }

    @Test
    fun maxFilterRectGrowsByTheGivenWidthAndHeight() {
        val w = 12
        val h = 12
        val one = BooleanArray(w * h)
        one[5 * w + 5] = true
        val grown = TextMask.maxFilterRect(one, w, h, 2, 1)
        var count = 0
        for (y in 0 until h) {
            for (x in 0 until w) {
                val expected = x in 3..7 && y in 4..6
                assertEquals("($x,$y)", expected, grown[y * w + x])
                if (grown[y * w + x]) count++
            }
        }
        assertEquals(15, count)
    }

    @Test
    fun theInsideOfARingIsFilledButAnOpenShapeIsNot() {
        val w = 9
        val h = 9
        val ring = BooleanArray(w * h)
        for (y in 2..6) for (x in 2..6) ring[y * w + x] = true
        for (y in 3..5) for (x in 3..5) ring[y * w + x] = false
        val filled = TextMask.fillHoles(ring, w, h)
        assertTrue(filled[4 * w + 4])
        assertFalse(filled[0])

        val open = ring.copyOf()
        open[2 * w + 4] = false // a gap in the wall: the inside is connected to the outside
        assertFalse(TextMask.fillHoles(open, w, h)[4 * w + 4])
    }

    @Test
    fun theHistogramPercentileReadsTheRightBin() {
        val v = floatArrayOf(0.5f, 1.2f, 1.9f, 10.3f, 255.7f, 300f)
        val all = BooleanArray(v.size) { true }
        assertEquals(1, TextMask.histPercentile(v, all, true, 50))
        assertEquals(255, TextMask.histPercentile(v, all, true, 92))
        assertEquals(1, TextMask.histPercentile(v, all, true, 20))
        val some = booleanArrayOf(true, true, true, false, false, false)
        assertEquals("only the selected ones count", 1, TextMask.histPercentile(v, some, true, 50))
        assertEquals("the others", 255, TextMask.histPercentile(v, some, false, 50))
        assertEquals("nothing selected", 0, TextMask.histPercentile(v, BooleanArray(v.size), true, 50))
    }

    @Test
    fun rowRunsCountsStrokesAndIgnoresOneNoisyRow() {
        fun grid(vararg rows: String): BooleanArray {
            val w = rows[0].length
            return BooleanArray(rows.size * w) { rows[it / w][it % w] == 'X' }
        }
        val text = grid("X.X.X.X.", "X.X.X.X.", "X.X.X.X.", "XX..XX..")
        assertEquals(4, TextMask.rowRuns(text, BooleanArray(text.size) { true }, 8, 4))

        val noisy = grid("X.X.X.X.X.X.X.X.X.", "XXXXXXXXXXXXXXXXXX", "XXXXXXXXXXXXXXXXXX", "XXXXXXXXXXXXXXXXXX")
        assertEquals("one busy row among solid ones is ignored", 1, TextMask.rowRuns(noisy, BooleanArray(noisy.size) { true }, 18, 4))

        val m = grid("X.X.X.X.", "XX..XX..", "XXXXXXXX", "........")
        val onlyTop = BooleanArray(m.size) { it / 8 < 2 }
        assertEquals("rows outside the box do not count", 2, TextMask.rowRuns(m, onlyTop, 8, 4))
    }

    // ------------------------------------------------------------------------------ what was cleaned

    @Test
    fun theCleaningRecordRoundTripsAndKeepsItsOrder() {
        val log = linkedMapOf(CleanTarget.LOGO to LogoCleanMode.REMOVE, CleanTarget.SUBTITLE to LogoCleanMode.BLUR)
        val text = CleanLog.encode(log)
        assertEquals("LOGO:REMOVE,SUBTITLE:BLUR", text)
        assertEquals(log, CleanLog.decode(text))
        assertEquals(listOf(CleanTarget.LOGO, CleanTarget.SUBTITLE), CleanLog.decode(text).keys.toList())
    }

    @Test
    fun aDamagedOrEmptyRecordIsReadSafely() {
        assertTrue(CleanLog.decode(null).isEmpty())
        assertTrue(CleanLog.decode("").isEmpty())
        assertTrue(CleanLog.decode("garbage").isEmpty())
        assertEquals(
            "unknown pieces are skipped, good ones kept",
            mapOf(CleanTarget.SUBTITLE to LogoCleanMode.BOTH),
            CleanLog.decode("LOGO:NOPE,FOO:BLUR,SUBTITLE:BOTH,TEXT")
        )
    }

    @Test
    fun theTickLabelNamesEverythingThatWasCleaned() {
        assertEquals("", CleanLog.label(emptyMap()))
        assertEquals("\u2714 logo removed", CleanLog.label(mapOf(CleanTarget.LOGO to LogoCleanMode.REMOVE)))
        assertEquals(
            "\u2714 logo removed \u00B7 subtitle blurred",
            CleanLog.label(linkedMapOf(CleanTarget.LOGO to LogoCleanMode.REMOVE, CleanTarget.SUBTITLE to LogoCleanMode.BLUR))
        )
        assertEquals("\u2714 text removed + blurred", CleanLog.label(mapOf(CleanTarget.TEXT to LogoCleanMode.BOTH)))
    }

    @Test
    fun targetsKnowWhichOnesAreFoundPhotoByPhoto() {
        assertEquals(3, CleanTarget.entries.size)
        assertFalse(CleanTarget.LOGO.isText)
        assertTrue(CleanTarget.SUBTITLE.isText)
        assertTrue(CleanTarget.TEXT.isText)
        val b = CleanTarget.SUBTITLE_BOX
        assertTrue("a wide strip in the lower part of the picture", b.width > 0.7f && b.top > 0.6f && b.bottom <= 1f && b.left >= 0f)
        assertFalse("and not where a logo box starts", b.near(LogoBox.DEFAULT, 0.02f))
    }
}
