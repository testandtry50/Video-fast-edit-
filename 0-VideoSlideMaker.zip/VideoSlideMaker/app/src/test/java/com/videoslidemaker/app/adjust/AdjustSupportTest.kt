package com.videoslidemaker.app.adjust

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class AdjustSupportTest {

    // ------------------------------------------------------------------------------------------------ the saved log
    @Test fun theLogSurvivesBeingSavedAndLoaded() {
        val log = listOf(
            AdjustBatch(1, "Moved the whole transcript by +1.430 seconds", 1_700_000_000_000L, listOf(AppliedLine(0, 123, 84_000L, 85_430L), AppliedLine(5, -77, 100_000L, 101_430L))),
            AdjustBatch(2, "Applied detected corrections (0 lines)", 1_700_000_100_000L, emptyList())
        )
        assertEquals(log, AdjustLogCodec.decode(AdjustLogCodec.encode(log)))
        assertEquals(emptyList<AdjustBatch>(), AdjustLogCodec.decode(AdjustLogCodec.encode(emptyList())))
    }

    @Test fun aLabelCanNotBreakTheFormat() {
        val log = listOf(AdjustBatch(1, "a|b\nc\rd", 5L, listOf(AppliedLine(0, 1, 2L, 3L))))
        val back = AdjustLogCodec.decode(AdjustLogCodec.encode(log))
        assertEquals(1, back.size)
        assertEquals("a b c d", back[0].label)
        assertEquals(log[0].changes, back[0].changes)
    }

    @Test fun damagedPiecesAreSkippedNeverFatal() {
        val text = listOf(
            "1|10|good|0:1:2:3",
            "not a batch at all",
            "x|10|bad id|0:1:2:3",
            "2|10|bad change|0:1:2",          // too few parts
            "3|10|bad number|a:1:2:3",
            "4|10|empty|",
            "5|10|good too|1:2:3:4,2:3:4:5"
        ).joinToString("\n")
        val back = AdjustLogCodec.decode(text)
        assertEquals(listOf(1L, 4L, 5L), back.map { it.id })
        assertEquals(2, back[2].changes.size)
        assertEquals(emptyList<AdjustBatch>(), AdjustLogCodec.decode(null))
        assertEquals(emptyList<AdjustBatch>(), AdjustLogCodec.decode("   "))
    }

    @Test fun aHugeLogIsCappedWhenLoaded() {
        val log = (1..(AdjustLog.MAX_BATCHES + 10)).map { AdjustBatch(it.toLong(), "b", 0L, emptyList()) }
        val back = AdjustLogCodec.decode(AdjustLogCodec.encode(log))
        assertEquals(AdjustLog.MAX_BATCHES, back.size)
        assertEquals((AdjustLog.MAX_BATCHES + 10).toLong(), back.last().id)
    }

    // ------------------------------------------------------------------------------------------------ slide <-> adjuster
    @Test fun aSlideBecomesALineWithItsOriginalInMilliseconds() {
        val l = SlideTimes.toLine(3, "Hi", 85.43, 84.0)
        assertEquals(AdjustLine(3, "Hi", 85_430L, 84_000L), l)
        assertNull(SlideTimes.toLine(0, "x", 1.0, null).scriptMs)
    }

    @Test fun writeBackKeepsTheFirstOriginalAsTheExactDouble() {
        // first adjustment of a line: its current time becomes the original
        val first = SlideTimes.writeBack(84.123456789, null, AdjustLine(0, "x", 86_123L, 84_123L))
        assertEquals(86.123, first.first, 0.0)
        assertEquals(84.123456789, first.second!!, 0.0)
        // a second adjustment: the original is still the first one
        val second = SlideTimes.writeBack(86.123, 84.123456789, AdjustLine(0, "x", 90_000L, 84_123L))
        assertEquals(90.0, second.first, 0.0)
        assertEquals(84.123456789, second.second!!, 0.0)
        // back at the original time: the marker is cleared and the time is the original Double itself
        val back = SlideTimes.writeBack(90.0, 84.123456789, AdjustLine(0, "x", 84_123L, null))
        assertEquals(84.123456789, back.first, 0.0)
        assertNull(back.second)
    }

    @Test fun writeBackWithoutAnyOriginalJustUsesTheNewTime() {
        val r = SlideTimes.writeBack(10.0, null, AdjustLine(0, "x", 11_500L, null))
        assertEquals(11.5, r.first, 0.0)
        assertNull(r.second)
        assertTrue(SlideTimes.toMs(-3.0) == 0L)
    }
}
