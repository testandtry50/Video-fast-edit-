package com.videoslidemaker.app.adjust

import com.videoslidemaker.app.align.AlignmentItem
import com.videoslidemaker.app.align.AlignmentStatus
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class TimestampAdjusterTest {

    private fun lines(vararg ms: Long, texts: List<String>? = null) =
        ms.mapIndexed { i, t -> AdjustLine(i, texts?.get(i) ?: "Line ${i + 1}", t) }

    private fun all(n: Int): Set<Int> = (0 until n).toSet()

    private class Lcg(var seed: Long) {
        fun next(n: Int): Int {
            seed = seed * 6364136223846793005L + 1442695040888963407L
            return ((seed ushr 33) % n).toInt()
        }
    }

    // ------------------------------------------------------------------------------------------------ the brief's example
    @Test fun theExampleFromTheBrief_beforeAfterAndDifference() {
        val l = listOf(AdjustLine(0, "Hello everyone", 84_000L))               // 00:01:24
        val p = TimestampAdjuster.entire(l, 1_430L)
        val view = TimestampAdjuster.preview(l, p, all(1))
        assertEquals("00:01:24 — Hello everyone", AdjustFormat.scriptLine(p[0].beforeMs, p[0].text))
        assertEquals("00:01:25.430 — Hello everyone", AdjustFormat.scriptLine(p[0].afterMs!!, p[0].text))
        assertEquals("+1.430 seconds", AdjustFormat.difference(p[0].diffMs!!))
        assertEquals(Outcome.WILL_APPLY, view.lines[0].outcome)
        assertEquals(mapOf(0 to 85_430L), view.willApply)
    }

    @Test fun clockShowsMillisecondsOnlyWhenThereAreSome() {
        assertEquals("00:01:24", AdjustFormat.clock(84_000L))
        assertEquals("00:01:24.500", AdjustFormat.clock(84_500L))
        assertEquals("00:00:00", AdjustFormat.clock(0L))
        assertEquals("01:02:03.007", AdjustFormat.clock(3_723_007L))
        assertEquals("-0.250 seconds", AdjustFormat.difference(-250L))
    }

    // ------------------------------------------------------------------------------------------------ 1. entire transcript
    @Test fun entireTranscriptMovesEveryLineAndKeepsTheSpacing() {
        val l = lines(5_000L, 9_000L, 20_000L)
        val r = TimestampAdjuster.apply(l, TimestampAdjuster.preview(l, TimestampAdjuster.entire(l, 2_500L), all(3)).willApply)
        assertEquals(listOf(7_500L, 11_500L, 22_500L), r.lines.map { it.currentMs })
        assertEquals(listOf(5_000L, 9_000L, 20_000L), r.lines.map { it.scriptMs })        // originals preserved
        assertTrue(r.refused.isEmpty())
    }

    @Test fun shiftingEarlierThanTheFirstLineAllowsIsBlockedNotHalfDone() {
        val l = lines(3_000L, 8_000L, 15_000L)
        assertEquals(-3_000L, TimestampAdjuster.minimumOffset(l))
        val view = TimestampAdjuster.preview(l, TimestampAdjuster.entire(l, -4_000L), all(3))
        assertFalse("not clean: the first line would start before 0", view.isClean)
        assertEquals(Outcome.REFUSED, view.lines[0].outcome)
        assertTrue(view.lines[0].reason!!.contains("before 00:00:00"))
        // exactly the limit is fine
        assertTrue(TimestampAdjuster.preview(l, TimestampAdjuster.entire(l, -3_000L), all(3)).isClean)
    }

    @Test fun stretchingKeepsTheFirstLineAnchoredAndTheOrder() {
        val l = lines(10_000L, 110_000L, 1_010_000L)
        val p = TimestampAdjuster.entire(l, 0L, 0.1)             // 0.1 % longer
        assertEquals(10_000L, p[0].afterMs)
        assertEquals(110_100L, p[1].afterMs)
        assertEquals(1_011_000L, p[2].afterMs)
        assertTrue(p[0].afterMs!! < p[1].afterMs!! && p[1].afterMs!! < p[2].afterMs!!)
        val both = TimestampAdjuster.entire(l, 500L, -1.0)
        assertEquals(10_500L, both[0].afterMs)
        assertEquals(10_500L + 99_000L, both[1].afterMs)
    }

    // ------------------------------------------------------------------------------------------------ 3. selected
    @Test fun onlyTickedLinesChange() {
        val l = lines(0L, 5_000L, 10_000L, 15_000L)
        val v = TimestampAdjuster.preview(l, TimestampAdjuster.selectedShift(l, 1_000L), setOf(1, 3))
        assertEquals(mapOf(1 to 6_000L, 3 to 16_000L), v.willApply)
        assertEquals(Outcome.NOT_SELECTED, v.lines[0].outcome)
        assertEquals(Outcome.WILL_APPLY, v.lines[1].outcome)
    }

    @Test fun aSelectedLineThatWouldRunIntoItsNeighbourIsRefusedAndExplained() {
        val l = lines(0L, 1_000L, 2_000L, 3_000L)
        val v = TimestampAdjuster.preview(l, TimestampAdjuster.selectedShift(l, 950L), setOf(1, 2))
        assertTrue(v.willApply.isEmpty())
        assertEquals(listOf(Outcome.NOT_SELECTED, Outcome.REFUSED, Outcome.REFUSED, Outcome.NOT_SELECTED), v.lines.map { it.outcome })
        assertTrue(v.lines[1].reason!!.contains("overlap"))
        // ticking the whole tail together keeps the spacing, so it is fine
        assertEquals(setOf(1, 2, 3), TimestampAdjuster.preview(l, TimestampAdjuster.selectedShift(l, 950L), setOf(1, 2, 3)).willApply.keys)
    }

    @Test fun anExactTimeIsSetForOneLineOnly() {
        val l = lines(0L, 5_000L, 10_000L)
        val v = TimestampAdjuster.preview(l, TimestampAdjuster.exact(l, 1, 6_250L), setOf(1))
        assertEquals(mapOf(1 to 6_250L), v.willApply)
        assertEquals(Outcome.NOT_SELECTED, v.lines[0].outcome)
        assertNull(v.lines[0].proposal.afterMs)
    }

    @Test fun aLineThatAlreadyHasTheProposedTimeIsNoChange() {
        val l = lines(0L, 5_000L)
        val v = TimestampAdjuster.preview(l, TimestampAdjuster.selectedShift(l, 0L), all(2))
        assertTrue(v.lines.all { it.outcome == Outcome.NO_CHANGE })
        assertTrue(v.willApply.isEmpty())
    }

    // ------------------------------------------------------------------------------------------------ 4. detected corrections
    private fun item(i: Int, text: String, cur: Long, detected: Long?, conf: Float, status: AlignmentStatus, reason: String? = null) =
        AlignmentItem(i, text, cur, cur, detected, null, conf, status, reason)

    @Test fun detectedCorrectionsShowTheirConfidenceAndOnlyHighOnesCountAsHigh() {
        val l = lines(10_000L, 20_000L, 30_000L, 40_000L, 50_000L)
        val items = listOf(
            item(0, "Line 1", 10_000L, 11_430L, 0.98f, AlignmentStatus.HIGH_CONFIDENCE),
            item(1, "Line 2", 20_000L, 21_120L, 0.96f, AlignmentStatus.HIGH_CONFIDENCE),
            item(2, "Line 3", 30_000L, 31_840L, 0.91f, AlignmentStatus.NEEDS_REVIEW, "Not sure."),
            item(3, "Line 4", 40_000L, null, 0f, AlignmentStatus.CANNOT_ALIGN, "No matching speech was found."),
            item(4, "Line 5", 50_000L, 50_040L, 0.99f, AlignmentStatus.MATCHES)
        )
        val p = TimestampAdjuster.detected(l, items)
        assertEquals(setOf(0, 1), TimestampAdjuster.highConfidence(p))
        assertEquals(0.91f, p[2].confidence)
        assertEquals("No matching speech was found.", p[3].unavailable)
        val v = TimestampAdjuster.preview(l, p, TimestampAdjuster.highConfidence(p))
        assertEquals(mapOf(0 to 11_430L, 1 to 21_120L), v.willApply)
        assertEquals(Outcome.UNAVAILABLE, v.lines[3].outcome)
    }

    @Test fun detectedCorrectionsAreRefusedWhenTheScriptChangedSinceTheAnalysis() {
        val l = listOf(AdjustLine(0, "Edited text", 10_000L), AdjustLine(1, "Line 2", 21_000L))
        val items = listOf(
            item(0, "Original text", 10_000L, 11_000L, 0.97f, AlignmentStatus.HIGH_CONFIDENCE),
            item(1, "Line 2", 20_000L, 22_000L, 0.97f, AlignmentStatus.HIGH_CONFIDENCE)       // its time was moved since
        )
        val p = TimestampAdjuster.detected(l, items)
        assertTrue(p.all { it.unavailable != null })
        assertTrue(TimestampAdjuster.highConfidence(p).isEmpty())
    }

    // ------------------------------------------------------------------------------------------------ original preservation
    @Test fun theFirstOriginalIsNeverOverwritten() {
        var cur = lines(10_000L, 20_000L)
        cur = TimestampAdjuster.apply(cur, mapOf(0 to 11_000L)).lines
        assertEquals(10_000L, cur[0].scriptMs)
        cur = TimestampAdjuster.apply(cur, mapOf(0 to 12_500L)).lines          // a second adjustment on top
        assertEquals(12_500L, cur[0].currentMs)
        assertEquals("the ORIGINAL is still the very first time", 10_000L, cur[0].scriptMs)
        assertEquals(10_000L, cur[0].originalMs)
        assertNull(cur[1].scriptMs)
    }

    @Test fun adjustingBackToTheOriginalTimeClearsTheMarker() {
        var cur = lines(10_000L, 20_000L)
        cur = TimestampAdjuster.apply(cur, mapOf(0 to 11_000L)).lines
        assertTrue(cur[0].isAdjusted)
        cur = TimestampAdjuster.apply(cur, mapOf(0 to 10_000L)).lines
        assertNull(cur[0].scriptMs)
        assertFalse(cur[0].isAdjusted)
    }

    @Test fun applyNeverChangesAnythingExceptWhatWasAccepted() {
        val l = lines(0L, 1_000L, 2_000L)
        val r = TimestampAdjuster.apply(l, mapOf(1 to 1_950L, 2 to 2_000L))     // line 1 collides with line 2's time? 1950 vs 2000 -> yes
        assertEquals(listOf(0L, 1_000L, 2_000L), r.lines.map { it.currentMs })
        assertEquals(listOf(1), r.refused)
        assertTrue(r.applied.isEmpty())
    }

    // ------------------------------------------------------------------------------------------------ 5. undo
    @Test fun undoLastRestoresTheTimesBeforeThatAdjustment() {
        var cur = lines(10_000L, 20_000L, 30_000L)
        val first = TimestampAdjuster.apply(cur, mapOf(0 to 11_000L, 1 to 21_000L))
        cur = first.lines
        val batch = AdjustBatch(1, "test", 0L, first.applied)
        val p = TimestampAdjuster.undoLast(cur, batch)
        assertEquals(2, p.size)
        val v = TimestampAdjuster.preview(cur, p, all(3))
        val back = TimestampAdjuster.apply(cur, v.willApply).lines
        assertEquals(listOf(10_000L, 20_000L, 30_000L), back.map { it.currentMs })
        assertTrue("markers cleared: back to the script's own times", back.all { it.scriptMs == null })
    }

    @Test fun undoLastLeavesLinesAlone_thatWereChangedAgainOrEdited() {
        var cur = lines(10_000L, 20_000L, 30_000L)
        val first = TimestampAdjuster.apply(cur, mapOf(0 to 11_000L, 1 to 21_000L, 2 to 31_000L))
        cur = first.lines
        val batch = AdjustBatch(1, "test", 0L, first.applied)
        cur = TimestampAdjuster.apply(cur, mapOf(1 to 22_222L)).lines                          // moved again afterwards
        cur = cur.toMutableList().also { it[2] = it[2].copy(text = "Edited") }                 // edited afterwards
        val p = TimestampAdjuster.undoLast(cur, batch)
        assertEquals(10_000L, p[0].afterMs)
        assertNull(p[1].afterMs); assertTrue(p[1].unavailable!!.contains("changed again"))
        assertNull(p[2].afterMs); assertTrue(p[2].unavailable!!.contains("edited"))
    }

    @Test fun undoWithNoHistoryProposesNothing() {
        assertTrue(TimestampAdjuster.undoLast(lines(1_000L), null).isEmpty())
    }

    @Test fun restoreOriginalsListsOnlyAdjustedLinesAndRestoresThemExactly() {
        var cur = lines(10_000L, 20_000L, 30_000L)
        cur = TimestampAdjuster.apply(cur, mapOf(0 to 11_234L, 2 to 33_333L)).lines
        val p = TimestampAdjuster.restoreOriginals(cur)
        assertEquals(listOf(0, 2), p.map { it.index })
        val back = TimestampAdjuster.apply(cur, TimestampAdjuster.preview(cur, p, setOf(0, 2)).willApply).lines
        assertEquals(listOf(10_000L, 20_000L, 30_000L), back.map { it.currentMs })
        assertTrue(back.all { it.scriptMs == null })
        // restoring only one
        val one = TimestampAdjuster.apply(cur, TimestampAdjuster.preview(cur, p, setOf(2)).willApply).lines
        assertEquals(listOf(11_234L, 20_000L, 30_000L), one.map { it.currentMs })
        assertEquals(10_000L, one[0].scriptMs)
    }

    @Test fun aMarkerThatEqualsTheCurrentTimeIsNotAnAdjustment() {
        // Can arrive from a saved draft or the older alignment code: the original is remembered but nothing differs.
        val l = listOf(AdjustLine(0, "A", 5_000L, 5_000L), AdjustLine(1, "B", 9_000L, 8_000L))
        assertFalse(l[0].isAdjusted)
        assertTrue(l[1].isAdjusted)
        assertEquals(listOf(1), TimestampAdjuster.restoreOriginals(l).map { it.index })
    }

    // ------------------------------------------------------------------------------------------------ properties
    @Test fun anySequenceOfAdjustmentsCanBeFullyRestoredToTheOriginals() {
        val rnd = Lcg(11)
        repeat(60) { trial ->
            val n = 5 + rnd.next(25)
            var t = 2_000L + rnd.next(3_000)
            val orig = LongArray(n) { t.also { t += 400L + rnd.next(6_000) } }
            var cur = orig.mapIndexed { i, ms -> AdjustLine(i, "Sentence number $i of trial $trial", ms) }
            repeat(1 + rnd.next(6)) {
                val prop = when (rnd.next(3)) {
                    0 -> TimestampAdjuster.entire(cur, (rnd.next(4_001) - 1_500).toLong(), (rnd.next(21) - 10) / 10.0)
                    1 -> TimestampAdjuster.selectedShift(cur, (rnd.next(3_001) - 1_000).toLong())
                    else -> TimestampAdjuster.exact(cur, rnd.next(n), (500 + rnd.next(60_000)).toLong())
                }
                val ticked = (0 until n).filter { rnd.next(3) != 0 }.toSet()
                val v = TimestampAdjuster.preview(cur, prop, ticked)
                val r = TimestampAdjuster.apply(cur, v.willApply)
                // the preview promised exactly what apply did
                assertEquals(v.willApply.keys, r.applied.map { it.index }.toSet())
                for (a in r.applied) assertEquals(v.willApply[a.index], a.afterMs)
                // the timeline is still strictly increasing with room between lines
                for (i in 1 until n) assertTrue("order broken in trial $trial", r.lines[i].currentMs - r.lines[i - 1].currentMs >= 100L)
                cur = r.lines
            }
            // every adjusted line remembers the very first time it had
            for (i in 0 until n) assertEquals(orig[i], cur[i].originalMs)
            val restore = TimestampAdjuster.restoreOriginals(cur)
            val back = TimestampAdjuster.apply(cur, TimestampAdjuster.preview(cur, restore, restore.map { it.index }.toSet()).willApply).lines
            assertEquals("trial $trial", orig.toList(), back.map { it.currentMs })
            assertTrue(back.all { it.scriptMs == null })
        }
    }

    @Test fun undoingEachAdjustmentInReverseOrderWalksBackToTheOriginals() {
        val rnd = Lcg(5)
        repeat(30) {
            val n = 6 + rnd.next(10)
            var t = 3_000L
            val orig = LongArray(n) { t.also { t += 1_000L + rnd.next(4_000) } }
            var cur = orig.mapIndexed { i, ms -> AdjustLine(i, "S$i", ms) }
            var log = emptyList<AdjustBatch>()
            val states = ArrayList<List<AdjustLine>>()
            repeat(1 + rnd.next(5)) { k ->
                states.add(cur)
                val prop = TimestampAdjuster.selectedShift(cur, (rnd.next(2_001) - 700).toLong())
                val ticked = (0 until n).filter { rnd.next(2) == 0 }.toSet()
                val r = TimestampAdjuster.apply(cur, TimestampAdjuster.preview(cur, prop, ticked).willApply)
                cur = r.lines
                log = AdjustLog.push(log, AdjustBatch(k.toLong(), "b$k", 0L, r.applied))
            }
            while (log.isNotEmpty()) {
                val before = states.removeAt(states.size - 1)
                val p = TimestampAdjuster.undoLast(cur, log.last())
                cur = TimestampAdjuster.apply(cur, TimestampAdjuster.preview(cur, p, p.map { it.index }.toSet()).willApply).lines
                log = AdjustLog.dropLast(log)
                assertEquals(before.map { it.currentMs }, cur.map { it.currentMs })
                assertEquals(before.map { it.scriptMs }, cur.map { it.scriptMs })
            }
            assertEquals(orig.toList(), cur.map { it.currentMs })
        }
    }

    @Test fun theLogKeepsOnlyTheNewestBatches() {
        var log = emptyList<AdjustBatch>()
        for (i in 1..(AdjustLog.MAX_BATCHES + 5)) log = AdjustLog.push(log, AdjustBatch(i.toLong(), "b$i", 0L, emptyList()))
        assertEquals(AdjustLog.MAX_BATCHES, log.size)
        assertEquals(6L, log.first().id)
        assertEquals((AdjustLog.MAX_BATCHES + 5).toLong(), log.last().id)
        assertTrue(AdjustLog.dropLast(emptyList()).isEmpty())
    }

    // ------------------------------------------------------------------------------------------------ typed amounts
    @Test fun typedAmountsAreReadInEveryReasonableShape() {
        val cases = mapOf(
            "1.43" to 1_430L, "+1.43" to 1_430L, "-0.25" to -250L, "\u22120.25" to -250L, ".5" to 500L, "1,43" to 1_430L,
            "430ms" to 430L, "-430 ms" to -430L, "1.43s" to 1_430L, "2" to 2_000L, "0" to 0L, "  3.5  " to 3_500L,
            "1:23.5" to 83_500L, "1:02:03" to 3_723_000L, "0:05" to 5_000L, "1.2345" to 1_235L, "0.0004" to 0L
        )
        for ((text, ms) in cases) assertEquals("parseSigned(\"$text\")", ms, AdjustFormat.parseSigned(text))
        for (bad in listOf("", "+", "-", "abc", "1.2.3", "1:90", "1:2:3:4", "12:", ":30", "5m", "1e3", "ms", "s", "1:30ms", "999999999"))
            assertNull("parseSigned(\"$bad\") should be rejected", AdjustFormat.parseSigned(bad))
    }

    @Test fun aTypedSignWinsOtherwiseTheDirectionDecides() {
        assertEquals(1_430L, AdjustFormat.resolveOffset("1.43", earlier = false))
        assertEquals(-1_430L, AdjustFormat.resolveOffset("1.43", earlier = true))
        assertEquals(-250L, AdjustFormat.resolveOffset("-0.25", earlier = false))
        assertEquals(250L, AdjustFormat.resolveOffset("+0.25", earlier = true))
        assertNull(AdjustFormat.resolveOffset("soon", earlier = false))
    }
}
