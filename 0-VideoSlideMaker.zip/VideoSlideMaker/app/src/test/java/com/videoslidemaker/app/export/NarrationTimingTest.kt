package com.videoslidemaker.app.export

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertSame
import org.junit.Assert.assertTrue
import org.junit.Test

class NarrationTimingTest {
    private val rate = 44100

    private fun constantStereo(frames: Int, value: Int): ByteArray {
        val b = ByteArray(frames * 4)
        for (i in 0 until frames * 2) { b[i * 2] = (value and 0xFF).toByte(); b[i * 2 + 1] = ((value shr 8) and 0xFF).toByte() }
        return b
    }

    private fun sampleAt(b: ByteArray, frame: Int, ch: Int = 0): Int {
        val k = (frame * 2 + ch) * 2
        return ((b[k + 1].toInt() shl 8) or (b[k].toInt() and 0xFF)).toShort().toInt()
    }

    @Test
    fun lastSentenceHasNoLimit() {
        assertNull(NarrationTiming.slotFrames(10.0, null, rate))
    }

    @Test
    fun slotIsTheGapToTheNextSentencePlusAShortGrace() {
        val frames = NarrationTiming.slotFrames(10.0, 14.0, rate)!!
        assertEquals(((4.0 + NarrationTiming.GRACE_SEC) * rate).toLong(), frames)
    }

    @Test
    fun nearlyEqualTimestampsDoNotSqueezeASentenceIntoAClick() {
        val frames = NarrationTiming.slotFrames(10.0, 10.05, rate)!!
        assertTrue(frames >= (NarrationTiming.MIN_SLOT_SEC * rate).toLong())
    }

    @Test
    fun aSentenceThatFitsIsReturnedUntouched() {
        val pcm = constantStereo(rate * 2, 8000)
        val out = NarrationTiming.fitToSlot(pcm, 2, rate, (3.0 * rate).toLong())
        assertSame(pcm, out)
        assertSame(pcm, NarrationTiming.fitToSlot(pcm, 2, rate, null))
    }

    @Test
    fun aSentenceThatRunsLongIsCutAtTheNextOneWithAFadeAndNeverPlaysPastIt() {
        val pcm = constantStereo(rate * 6, 8000) // 6 s of sound
        val slot = (3.0 * rate).toLong()
        val out = NarrationTiming.fitToSlot(pcm, 2, rate, slot)
        assertEquals(slot.toInt() * 4, out.size)
        assertEquals(8000, sampleAt(out, 100))               // the start is untouched
        assertEquals(8000, sampleAt(out, slot.toInt() - (NarrationTiming.FADE_SEC * rate).toInt() - 10)) // just before the fade
        assertTrue(Math.abs(sampleAt(out, slot.toInt() - 1)) < 200) // ends at (almost) silence: no click
        assertTrue(Math.abs(sampleAt(out, slot.toInt() - 1, 1)) < 200)
        // the fade only ever goes down
        var prev = Int.MAX_VALUE
        for (f in slot.toInt() - (NarrationTiming.FADE_SEC * rate).toInt() until slot.toInt()) {
            val v = sampleAt(out, f); assertTrue(v <= prev); prev = v
        }
    }

    /** Two sentences laid on a timeline the way the export does: before the fix they overlapped, now they do not. */
    @Test
    fun twoSentencesNoLongerSoundAtTheSameTime() {
        val a = constantStereo(rate * 5, 1000) // spoken for 5 s but only 3 s are available before sentence B
        val b = constantStereo(rate * 2, 20000)
        val startB = 3.0
        val fittedA = NarrationTiming.fitToSlot(a, 2, rate, NarrationTiming.slotFrames(0.0, startB, rate))
        val overlapFramesBefore = a.size / 4 - (startB * rate).toInt()
        val overlapFramesAfter = fittedA.size / 4 - (startB * rate).toInt()
        assertTrue(overlapFramesBefore >= 2 * rate)                        // used to talk over B for 2 s
        assertTrue(overlapFramesAfter <= (NarrationTiming.GRACE_SEC * rate).toInt() + 1) // now at most the short grace
        assertEquals(2 * rate, b.size / 4)
    }
}
