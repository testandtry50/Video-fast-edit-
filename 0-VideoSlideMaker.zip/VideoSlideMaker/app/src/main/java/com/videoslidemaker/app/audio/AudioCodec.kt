package com.videoslidemaker.app.audio

import org.json.JSONArray
import org.json.JSONObject

/** NEW (2.17): saves and loads the audio edits inside a project. Unknown or damaged data gives the plain default, never a crash. */
object AudioCodec {

    fun encode(a: AudioMixSettings): String {
        val root = JSONObject()
        root.put("useCustomMain", a.useCustomMain)
        root.put("main", clipsToJson(a.main))
        root.put("background", clipsToJson(a.background))
        val s = a.smart
        val smart = JSONObject()
        smart.put("autoDuck", s.autoDuck)
        smart.put("duckDb", s.duckDb.toDouble())
        smart.put("autoLevel", s.autoLevel)
        smart.put("fadeAtEnd", s.fadeAtEnd)
        smart.put("limiter", s.limiter)
        root.put("smart", smart)
        return root.toString()
    }

    fun decode(text: String?): AudioMixSettings {
        if (text.isNullOrBlank()) return AudioMixSettings()
        return try {
            val root = JSONObject(text)
            val s = root.optJSONObject("smart")
            val defaults = SmartMixSettings()
            AudioMixSettings(
                useCustomMain = root.optBoolean("useCustomMain", false),
                main = clipsFromJson(root.optJSONArray("main")),
                background = clipsFromJson(root.optJSONArray("background")),
                smart = if (s == null) defaults else SmartMixSettings(
                    autoDuck = s.optBoolean("autoDuck", defaults.autoDuck),
                    duckDb = s.optDouble("duckDb", defaults.duckDb.toDouble()).toFloat()
                        .coerceIn(SmartMixSettings.MIN_DUCK_DB, SmartMixSettings.MAX_DUCK_DB),
                    autoLevel = s.optBoolean("autoLevel", defaults.autoLevel),
                    fadeAtEnd = s.optBoolean("fadeAtEnd", defaults.fadeAtEnd),
                    limiter = s.optBoolean("limiter", defaults.limiter)
                )
            )
        } catch (_: Exception) {
            AudioMixSettings()
        }
    }

    /**
     * A project saved before 2.17 had one music file with one volume slider that looped over the whole video, with
     * nothing automatic. It becomes one looping background track with every smart switch off, so it sounds as it did.
     */
    fun fromLegacyMusic(uri: String, name: String?, volume: Float): AudioMixSettings = AudioMixSettings(
        background = listOf(
            AudioClip(
                id = "legacy-music",
                uri = uri,
                name = name ?: "Background music",
                sourceDurationSec = 0.0,
                srcEndSec = 0.0,
                volume = volume.coerceIn(0f, AudioLimits.MAX_VOLUME),
                loop = true,
                autoDuck = false
            )
        ),
        smart = SmartMixSettings.ALL_OFF
    )

    private fun clipsToJson(clips: List<AudioClip>): JSONArray {
        val arr = JSONArray()
        for (c in clips) {
            val o = JSONObject()
            o.put("id", c.id)
            o.put("uri", c.uri)
            o.put("name", c.name)
            o.put("dur", c.sourceDurationSec)
            o.put("s0", c.srcStartSec)
            o.put("s1", c.srcEndSec)
            o.put("at", c.startSec)
            o.put("vol", c.volume.toDouble())
            o.put("fi", c.fadeInSec)
            o.put("fo", c.fadeOutSec)
            o.put("mute", c.muted)
            o.put("loop", c.loop)
            o.put("duck", c.autoDuck)
            o.put("fit", c.fitVideo)
            // NEW (2.18): a background-audio slot's name ("B1") and where its time range ends (0 = no end yet)
            o.put("slot", c.slot)
            o.put("re", c.rangeEndSec)
            // NEW (2.19): what kind of sound it is, the marked part of the original, and the automatic-adjust values.
            // Written only when they differ from the default, so a project that never uses them stays exactly as small as before.
            if (c.kind != SoundKind.UNSET) o.put("kind", c.kind.name)
            if (c.mood != SoundMood.NONE) o.put("mood", c.mood.name)
            if (c.markEndSec > 0.0) o.put("mark", c.markEndSec)
            if (c.duckAdjustDb != 0.0) o.put("dadj", c.duckAdjustDb)
            val level = c.levelDb
            if (level != null) o.put("lvl", level)
            if (c.playOnce) o.put("once", true)
            if (c.exactLoop) o.put("exact", true)
            arr.put(o)
        }
        return arr
    }

    private fun clipsFromJson(arr: JSONArray?): List<AudioClip> {
        if (arr == null) return emptyList()
        val out = ArrayList<AudioClip>(arr.length())
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val id = o.optString("id", "")
            val uri = o.optString("uri", "")
            val slot = o.optString("slot", "")
            // A clip needs a file - except a background-audio slot (2.18), which may still be waiting for its file.
            if (id.isBlank() || (uri.isBlank() && slot.isBlank())) continue
            val dur = o.optDouble("dur", 0.0).takeIf { !it.isNaN() && it >= 0.0 } ?: 0.0
            out.add(
                AudioClip(
                    id = id,
                    uri = uri,
                    name = o.optString("name", "Audio"),
                    sourceDurationSec = dur,
                    srcStartSec = o.optDouble("s0", 0.0).coerceAtLeast(0.0),
                    srcEndSec = o.optDouble("s1", dur).coerceAtLeast(0.0),
                    startSec = o.optDouble("at", 0.0).coerceAtLeast(0.0),
                    volume = o.optDouble("vol", 1.0).toFloat().coerceIn(0f, AudioLimits.MAX_VOLUME),
                    fadeInSec = o.optDouble("fi", 0.0).coerceIn(0.0, AudioLimits.MAX_FADE_SEC),
                    fadeOutSec = o.optDouble("fo", 0.0).coerceIn(0.0, AudioLimits.MAX_FADE_SEC),
                    muted = o.optBoolean("mute", false),
                    loop = o.optBoolean("loop", false),
                    autoDuck = o.optBoolean("duck", true),
                    fitVideo = o.optBoolean("fit", false),
                    slot = slot,
                    rangeEndSec = o.optDouble("re", 0.0).takeIf { !it.isNaN() && it > 0.0 } ?: 0.0,
                    kind = SoundKind.fromName(o.optString("kind", "")),
                    mood = SoundMood.fromName(o.optString("mood", "")),
                    markEndSec = o.optDouble("mark", 0.0).takeIf { !it.isNaN() && it > 0.0 } ?: 0.0,
                    duckAdjustDb = o.optDouble("dadj", 0.0).takeIf { !it.isNaN() }?.coerceIn(-24.0, 24.0) ?: 0.0,
                    levelDb = if (o.has("lvl")) o.optDouble("lvl", Double.NaN).takeIf { !it.isNaN() }?.coerceIn(-40.0, 6.0) else null,
                    playOnce = o.optBoolean("once", false),
                    exactLoop = o.optBoolean("exact", false)
                )
            )
        }
        return out
    }
}
