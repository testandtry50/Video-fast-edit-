package com.videoslidemaker.app.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import com.videoslidemaker.app.check.CheckFormat
import com.videoslidemaker.app.check.CheckStatus
import com.videoslidemaker.app.check.SegmentResult
import com.videoslidemaker.app.check.TimestampCheck
import com.videoslidemaker.app.check.WordIssue
import com.videoslidemaker.app.model.UiState
import com.videoslidemaker.app.ui.components.AlertBox
import com.videoslidemaker.app.ui.components.AlertStyle
import com.videoslidemaker.app.ui.components.AppProgressBar
import com.videoslidemaker.app.ui.components.JumpPlayer
import com.videoslidemaker.app.ui.components.MediaJumper
import com.videoslidemaker.app.ui.components.PrimaryButton
import com.videoslidemaker.app.ui.components.SecondaryButton
import com.videoslidemaker.app.ui.components.SectionCard
import com.videoslidemaker.app.ui.components.rememberMediaJumper
import com.videoslidemaker.app.ui.theme.Accent
import com.videoslidemaker.app.ui.theme.Bg
import com.videoslidemaker.app.ui.theme.BorderColor
import com.videoslidemaker.app.ui.theme.CardBg
import com.videoslidemaker.app.ui.theme.Green
import com.videoslidemaker.app.ui.theme.Muted
import com.videoslidemaker.app.ui.theme.OnAccent
import com.videoslidemaker.app.ui.theme.Outline
import com.videoslidemaker.app.ui.theme.Red
import com.videoslidemaker.app.ui.theme.TextMain
import com.videoslidemaker.app.ui.theme.Yellow
import com.videoslidemaker.app.viewmodel.AppViewModel
import kotlin.math.roundToInt

// ---------------------------------------------------------------------------------------------------------------
// Status look. The coloured circle is drawn (not the emoji) so it looks the same on every phone: the green and yellow
// circle emoji do not exist on Android 9 and older. The words are always shown beside it, so colour is never the only cue.
// ---------------------------------------------------------------------------------------------------------------

private fun CheckStatus.isProblem(): Boolean = this != CheckStatus.MATCH && this != CheckStatus.UNCERTAIN

@Composable
private fun statusColor(status: CheckStatus): Color = when (status) {
    CheckStatus.MATCH -> Green
    CheckStatus.TIMESTAMP_ERROR -> Yellow
    CheckStatus.TEXT_MISMATCH, CheckStatus.MISSING_WORD, CheckStatus.EXTRA_WORD -> Red
    CheckStatus.UNCERTAIN -> Muted
}

@Composable
private fun StatusDot(status: CheckStatus) {
    val color = statusColor(status)
    Box(
        Modifier
            .size(14.dp)
            .clip(CircleShape)
            .background(if (status == CheckStatus.UNCERTAIN) Color.White else color)
            .border(2.dp, color, CircleShape)
    )
}

private enum class AccuracyFilter(val label: String, val accepts: (SegmentResult) -> Boolean) {
    ALL("All", { true }),
    PROBLEMS("Problems", { it.status.isProblem() }),
    TEXT("Text", { it.status == CheckStatus.TEXT_MISMATCH }),
    MISSING("Missing", { it.status == CheckStatus.MISSING_WORD }),
    EXTRA("Extra", { it.status == CheckStatus.EXTRA_WORD }),
    TIMESTAMP("Timestamp", { it.status == CheckStatus.TIMESTAMP_ERROR || it.hasTimestampError }),
    UNCERTAIN("Uncertain", { it.status == CheckStatus.UNCERTAIN }),
    MATCH("Match", { it.status == CheckStatus.MATCH })
}

private val TOLERANCES = listOf(250L to "0.25 s", 500L to "0.5 s", 1000L to "1 s", 2000L to "2 s")

// ---------------------------------------------------------------------------------------------------------------
// The card on the Script screen
// ---------------------------------------------------------------------------------------------------------------

@Composable
fun AccuracyCard(state: UiState, viewModel: AppViewModel, onPickRecording: () -> Unit, onPickSpeechModel: () -> Unit) {
    val controller = viewModel.accuracy
    val ui by controller.ui.collectAsState()
    val hasScript = state.scriptLoaded && state.slides.isNotEmpty()
    val hasRecording = state.alignment.recordingUri != null
    val hasModel = ui.modelName != null
    val result = ui.result
    val stale = remember(ui.result, ui.checked, state.slides) { controller.isStale(ui) }

    SectionCard(title = "Check the words against the audio", modifier = Modifier.padding(bottom = 12.dp)) {
        Text(
            "The recording is the truth. The app listens to it on your phone (no internet needed), compares every word with your script, " +
                "and shows wrong, missing and extra words and wrong timestamps, each with the exact place in the audio to tap and hear.",
            style = MaterialTheme.typography.bodySmall,
            color = Muted,
            modifier = Modifier.padding(bottom = 10.dp)
        )

        // 1. the speech model
        if (!hasModel) {
            AlertBox(
                "One-time setup: choose a speech model for the language of the recording. Download the .zip of a \"Vosk\" model from " +
                    "alphacephei.com/vosk/models (for example the small English or small Hindi one, about 40 MB) and pick it here.",
                AlertStyle.INFO,
                Modifier.padding(bottom = 8.dp)
            )
        }
        if (ui.installing) {
            Text("Installing the speech model… ${ui.installPercent}%", color = TextMain, style = MaterialTheme.typography.bodySmall)
            AppProgressBar(ui.installPercent / 100f, Modifier.padding(vertical = 8.dp))
        } else {
            SecondaryButton(
                text = if (hasModel) "Speech model: ${ui.modelName} (change)" else "Choose the speech model (.zip)",
                icon = Icons.Filled.Mic,
                enabled = !ui.running,
                onClick = onPickSpeechModel
            )
        }

        // 2. the recording (chosen in the alignment card above; the same one is used here)
        if (!hasRecording) {
            SecondaryButton(text = "Choose the recording", onClick = onPickRecording)
        } else {
            Text(
                "Recording: ${state.alignment.recordingName ?: "chosen"}",
                color = TextMain,
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.padding(vertical = 6.dp)
            )
        }
        if (!hasScript) {
            AlertBox("Load a script first — there is no transcript to check yet.", AlertStyle.INFO, Modifier.padding(vertical = 6.dp))
        }

        // 3. run
        if (ui.running) {
            Text(ui.stage.ifEmpty { "Working…" } + " ${ui.percent}%", color = TextMain, style = MaterialTheme.typography.bodySmall)
            AppProgressBar(ui.percent / 100f, Modifier.padding(vertical = 8.dp))
            SecondaryButton(text = "Stop", onClick = controller::cancel)
        } else {
            PrimaryButton(
                text = if (result == null) "Check the transcript" else "Listen and check again",
                enabled = hasScript && hasRecording && hasModel && !ui.installing,
                onClick = { controller.run(listenAgain = true) }
            )
        }

        ui.error?.let { AlertBox(it, AlertStyle.WARNING, Modifier.padding(top = 6.dp)) }
        ui.notice?.let { AlertBox(it, AlertStyle.INFO, Modifier.padding(top = 6.dp)) }

        // 4. result
        if (result != null && !ui.running) {
            val problems = result.segments.count { it.status.isProblem() }
            val uncertain = result.count(CheckStatus.UNCERTAIN)
            AlertBox(
                (if (problems == 0) "No problems found" else "$problems of ${result.segments.size} lines have a problem") +
                    (if (uncertain > 0) " · $uncertain uncertain" else "") +
                    " · ${(result.accuracy * 100).roundToInt()}% of the words confirmed by the audio.",
                if (problems == 0) AlertStyle.SUCCESS else AlertStyle.WARNING,
                Modifier.padding(top = 8.dp)
            )
            if (stale) {
                AlertBox("The script changed since this check. Check again to update it (the recording is not listened to again).", AlertStyle.WARNING, Modifier.padding(top = 6.dp))
                SecondaryButton(text = "Check again", onClick = { controller.run(listenAgain = false) })
            }
            PrimaryButton(text = "Open the results", onClick = { controller.openScreen(true) })
        }
    }
}

// ---------------------------------------------------------------------------------------------------------------
// The results screen: the player on top, the findings below. Tapping a finding jumps the player to it.
// ---------------------------------------------------------------------------------------------------------------

@Composable
fun AccuracyScreen(state: UiState, viewModel: AppViewModel) {
    val controller = viewModel.accuracy
    BackHandler { controller.openScreen(false) }
    val ui by controller.ui.collectAsState()
    val result = ui.result
    val uri = state.alignment.recordingUri
    val jumper = rememberMediaJumper()
    var filter by remember { mutableStateOf(AccuracyFilter.ALL) }
    val stale = remember(ui.result, ui.checked, state.slides) { controller.isStale(ui) }

    Column(Modifier.fillMaxSize().background(Bg)) {
        Row(
            Modifier.fillMaxWidth().padding(start = 4.dp, end = 12.dp, top = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(onClick = { controller.openScreen(false) }) { Text("← Back", color = Accent) }
            Text(
                "Transcript check",
                style = MaterialTheme.typography.titleMedium,
                color = TextMain,
                fontWeight = FontWeight.Bold
            )
        }

        if (uri != null) {
            key(uri) { JumpPlayer(uri, jumper) }
        } else {
            AlertBox("Choose the recording to be able to play it here.", AlertStyle.WARNING, Modifier.padding(horizontal = 16.dp))
        }

        if (result == null) {
            AlertBox("There is no result yet. Go back and tap \"Check the transcript\".", AlertStyle.INFO, Modifier.padding(16.dp))
        } else {
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                for (f in AccuracyFilter.entries) {
                    val count = result.segments.count { f.accepts(it) }
                    if (count == 0 && f != AccuracyFilter.ALL) continue
                    val selected = f == filter
                    Box(
                        Modifier
                            .heightIn(min = 44.dp)
                            .clip(RoundedCornerShape(22.dp))
                            .background(if (selected) Accent else CardBg)
                            .border(1.dp, if (selected) Accent else Outline, RoundedCornerShape(22.dp))
                            .selectable(selected = selected, role = Role.RadioButton, onClick = { filter = f })
                            .padding(horizontal = 16.dp, vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            (if (selected) "✓ " else "") + "${f.label} ($count)",
                            color = if (selected) OnAccent else TextMain,
                            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }
            val shown = remember(result, filter) { result.segments.filter { filter.accepts(it) } }
            LazyColumn(
                Modifier.weight(1f),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item(key = "summary") {
                    Column(Modifier.fillMaxWidth()) {
                        if (stale) {
                            AlertBox("The script changed since this check.", AlertStyle.WARNING, Modifier.padding(bottom = 6.dp))
                            SecondaryButton(text = "Check again", enabled = !ui.running, onClick = { controller.run(listenAgain = false) })
                        }
                        if (ui.running) AppProgressBar(ui.percent / 100f, Modifier.padding(vertical = 6.dp))
                        Text(
                            "${(result.accuracy * 100).roundToInt()}% of the words confirmed by the audio " +
                                "(${result.wordMatched} of ${result.wordTotal}). The recognizer heard ${ui.heardWords} words.",
                            color = TextMain,
                            style = MaterialTheme.typography.bodySmall
                        )
                        Column(Modifier.padding(vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            for (s in CheckStatus.entries) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    StatusDot(s)
                                    Spacer(Modifier.width(8.dp))
                                    Text(s.label, color = statusColor(s), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
                                    Text("${result.count(s)}", color = TextMain, style = MaterialTheme.typography.bodySmall)
                                }
                            }
                        }
                        Text("A timestamp counts as wrong when it is more than this far from where the line is spoken:", color = Muted, style = MaterialTheme.typography.bodySmall)
                        Row(
                            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(vertical = 6.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            for ((ms, label) in TOLERANCES) {
                                val selected = ui.settings.timestampToleranceMs == ms
                                Box(
                                    Modifier
                                        .heightIn(min = 44.dp)
                                        .clip(RoundedCornerShape(22.dp))
                                        .background(if (selected) Accent else CardBg)
                                        .border(1.dp, if (selected) Accent else Outline, RoundedCornerShape(22.dp))
                                        .selectable(selected = selected, role = Role.RadioButton, enabled = !ui.running, onClick = { controller.setTimestampTolerance(ms) })
                                        .padding(horizontal = 16.dp, vertical = 8.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        (if (selected) "✓ " else "") + label,
                                        color = if (selected) OnAccent else TextMain,
                                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                                        style = MaterialTheme.typography.bodySmall
                                    )
                                }
                            }
                        }
                        if (result.wholeSecondTimestamps) {
                            Text("Your timestamps are whole seconds, so up to 1 s off is always allowed.", color = Muted, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
                items(shown, key = { it.index }) { seg -> SegmentCard(seg, jumper) }
            }
        }
    }
}

// ---------------------------------------------------------------------------------------------------------------
// One line of the transcript
// ---------------------------------------------------------------------------------------------------------------

@Composable
private fun SegmentCard(seg: SegmentResult, jumper: MediaJumper) {
    val shape = RoundedCornerShape(16.dp)
    val color = statusColor(seg.status)
    val jump = seg.jumpMs
    Column(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(CardBg)
            .border(1.dp, if (seg.status == CheckStatus.MATCH) BorderColor else color.copy(alpha = 0.6f), shape)
            .clickable(enabled = jump != null, onClickLabel = "Play this place in the audio", role = Role.Button) {
                jump?.let { jumper.jumpTo(it, "line ${seg.index + 1}") }
            }
            .padding(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            StatusDot(seg.status)
            Spacer(Modifier.width(8.dp))
            Text(seg.status.label, color = color, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Text(
                "Line ${seg.index + 1} · ${CheckFormat.clock(seg.timestampMs)}",
                color = Muted,
                style = MaterialTheme.typography.bodySmall,
                fontFamily = FontFamily.Monospace
            )
        }
        if (seg.hasTimestampError && seg.status != CheckStatus.TIMESTAMP_ERROR) {
            Text("Also: the timestamp is wrong (see below)", color = Yellow, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 2.dp))
        }
        Text(
            transcriptWithMarks(seg, Red, Muted),
            color = TextMain,
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.padding(top = 8.dp)
        )
        if (seg.reason.isNotEmpty()) {
            Text(seg.reason, color = Muted, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 4.dp))
        }
        for (issue in seg.issues) IssueBlock(issue, jumper)
        val ts = seg.timestamp
        if (ts != null && ts.isError) TimestampBlock(ts, jumper)
        if (jump != null) {
            Text("▶ Tap anywhere on this card to hear it", color = Accent, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 10.dp))
        }
    }
}

/** The transcript's words, with the wrong ones underlined, and spoken words the transcript lacks shown as [+ word]. */
private fun transcriptWithMarks(seg: SegmentResult, firmColor: Color, softColor: Color): AnnotatedString = buildAnnotatedString {
    val inserted = seg.issues.filter { it.kind == CheckStatus.MISSING_WORD }
    val replaced = seg.issues.filter { it.kind != CheckStatus.MISSING_WORD }
    for (i in 0..seg.words.size) {
        for (m in inserted) {
            if (m.tFrom == i) {
                withStyle(SpanStyle(color = if (m.firm) firmColor else softColor, fontWeight = FontWeight.Bold)) { append("[+ " + m.audioText + "]") }
                append(" ")
            }
        }
        if (i == seg.words.size) break
        val hit = replaced.firstOrNull { i >= it.tFrom && i < it.tTo }
        if (hit == null) {
            append(seg.words[i])
        } else {
            withStyle(
                SpanStyle(
                    color = if (hit.firm) firmColor else softColor,
                    fontWeight = FontWeight.Bold,
                    textDecoration = TextDecoration.Underline
                )
            ) { append(seg.words[i]) }
        }
        if (i < seg.words.size - 1) append(" ")
    }
}

// ---------------------------------------------------------------------------------------------------------------
// One problem inside a line
// ---------------------------------------------------------------------------------------------------------------

@Composable
private fun IssueBlock(issue: WordIssue, jumper: MediaJumper) {
    val color = if (issue.firm) statusColor(issue.kind) else Muted
    val shape = RoundedCornerShape(12.dp)
    Column(
        Modifier
            .fillMaxWidth()
            .padding(top = 10.dp)
            .clip(shape)
            .background(color.copy(alpha = 0.08f))
            .border(1.dp, color.copy(alpha = 0.35f), shape)
            .padding(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            StatusDot(if (issue.firm) issue.kind else CheckStatus.UNCERTAIN)
            Spacer(Modifier.width(8.dp))
            Text((if (issue.firm) "" else "POSSIBLE ") + issue.kind.label, color = color, fontWeight = FontWeight.Bold)
        }
        Text(
            when (issue.kind) {
                CheckStatus.TEXT_MISMATCH -> "The audio says something different from the transcript."
                CheckStatus.MISSING_WORD -> "This is spoken in the audio but is missing from the transcript."
                else -> "The transcript has this, but it is not spoken in the audio."
            },
            color = Muted,
            style = MaterialTheme.typography.bodySmall,
            modifier = Modifier.padding(top = 4.dp, bottom = 6.dp)
        )
        Labeled("Transcript:", issue.transcriptText.ifEmpty { "(nothing)" })
        Labeled("Audio:", issue.audioText.ifEmpty { "(nothing)" })
        if (issue.note.isNotEmpty()) {
            Text(issue.note, color = Muted, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 6.dp))
        }
        val start = issue.audioStartMs
        if (start != null) {
            val end = issue.audioEndMs
            val where = if (end != null && end != start) "${CheckFormat.clock(start)} – ${CheckFormat.clock(end)}" else CheckFormat.clock(start)
            Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Labeled(if (issue.kind == CheckStatus.EXTRA_WORD) "It would be at:" else "Exact audio location:", where, mono = true)
                }
                JumpButton("▶ Jump") { jumper.jumpTo(start, issue.kind.label.lowercase()) }
            }
        }
    }
}

@Composable
private fun TimestampBlock(ts: TimestampCheck, jumper: MediaJumper) {
    val actual = ts.actualMs ?: return
    val diff = ts.diffMs ?: return
    val corrected = ts.correctedMs ?: return
    val color = Yellow
    val shape = RoundedCornerShape(12.dp)
    Column(
        Modifier
            .fillMaxWidth()
            .padding(top = 10.dp)
            .clip(shape)
            .background(color.copy(alpha = 0.08f))
            .border(1.dp, color.copy(alpha = 0.35f), shape)
            .padding(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            StatusDot(CheckStatus.TIMESTAMP_ERROR)
            Spacer(Modifier.width(8.dp))
            Text(CheckStatus.TIMESTAMP_ERROR.label, color = color, fontWeight = FontWeight.Bold)
        }
        Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) { Labeled("Transcript timestamp:", CheckFormat.clock(ts.transcriptMs), mono = true) }
            JumpButton("▶ Hear it") { jumper.jumpTo(ts.transcriptMs, "transcript timestamp") }
        }
        Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) { Labeled("Actual speech:", CheckFormat.clock(actual), mono = true) }
            JumpButton("▶ Jump") { jumper.jumpTo(actual, "actual speech") }
        }
        Column(Modifier.padding(top = 8.dp)) { Labeled("Difference:", CheckFormat.signedSeconds(diff)) }
        Column(Modifier.padding(top = 8.dp)) { Labeled("Corrected timestamp:", CheckFormat.clock(corrected), mono = true) }
    }
}

@Composable
private fun Labeled(label: String, value: String, mono: Boolean = false) {
    Column(Modifier.padding(top = 2.dp)) {
        Text(label, color = Muted, style = MaterialTheme.typography.bodySmall)
        Text(
            value,
            color = TextMain,
            fontWeight = FontWeight.Bold,
            style = MaterialTheme.typography.bodyMedium,
            fontFamily = if (mono) FontFamily.Monospace else null
        )
    }
}

@Composable
private fun JumpButton(text: String, onClick: () -> Unit) {
    OutlinedButton(
        onClick = onClick,
        modifier = Modifier.heightIn(min = 48.dp),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, Accent),
        colors = ButtonDefaults.outlinedButtonColors(contentColor = Accent)
    ) {
        Text(text, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall)
    }
}
