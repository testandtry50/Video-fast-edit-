package com.videoslidemaker.app.data

import android.content.ContentResolver
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import android.os.Build
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import com.videoslidemaker.app.model.PoolImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID

/** One image file found while listing a picked folder. [sortKey] is "subfolder/name" so photos
 *  from different sub-folders stay grouped together, in folder order. */
private class FolderEntry(val uri: Uri, val name: String, val sortKey: String, val modifiedMs: Long = 0L)

/**
 * NEW: the order photos from a picked folder are added in.
 * [NAME] is the original behaviour (by folder, then by file name, "frame2" before "frame10").
 * [OLDEST_FIRST] / [NEWEST_FIRST] go by the file's date - the same date the phone's file manager shows and sorts by
 * - across the whole folder and its sub-folders. A photo whose date the storage doesn't report goes last.
 */
enum class FolderSort { NAME, OLDEST_FIRST, NEWEST_FIRST }

private val IMAGE_EXTENSIONS = setOf("jpg", "jpeg", "png", "webp", "heic", "heif", "bmp", "gif", "avif")

/**
 * Decides whether a file in a picked folder is a photo. Normally the storage provider says so
 * ("image/jpeg"), but some providers report an empty or generic type for perfectly normal
 * photos - those are accepted by file extension instead of being silently left out.
 */
private fun looksLikeImage(mime: String?, name: String): Boolean {
    if (mime != null && mime.startsWith("image/")) return !mime.equals("image/svg+xml", ignoreCase = true)
    if (mime.isNullOrEmpty() || mime == "application/octet-stream") {
        return name.substringAfterLast('.', "").lowercase() in IMAGE_EXTENSIONS
    }
    return false
}

/** "frame2" sorts before "frame10" (plain alphabetical order would put 10 first). */
private fun naturalCompare(a: String, b: String): Int {
    var i = 0
    var j = 0
    while (i < a.length && j < b.length) {
        val ca = a[i]
        val cb = b[j]
        if (ca.isDigit() && cb.isDigit()) {
            var ei = i
            while (ei < a.length && a[ei].isDigit()) ei++
            var ej = j
            while (ej < b.length && b[ej].isDigit()) ej++
            val na = a.substring(i, ei).trimStart('0')
            val nb = b.substring(j, ej).trimStart('0')
            if (na.length != nb.length) return na.length - nb.length
            val c = na.compareTo(nb)
            if (c != 0) return c
            i = ei
            j = ej
        } else {
            val c = ca.lowercaseChar().compareTo(cb.lowercaseChar())
            if (c != 0) return c
            i++
            j++
        }
    }
    return (a.length - i) - (b.length - j)
}

/** Photos read, then shown on screen, per step of a big import. */
private const val IMPORT_CHUNK_SIZE = 200

/** Photos read at the same moment. Enough to be fast, few enough not to choke the phone's
 *  file providers. */
private const val IMPORT_READ_PARALLELISM = 6

/**
 * This is the key fix for "handle large file work properly": the original web app read every
 * uploaded photo into memory as a base64 string (via FileReader.readAsDataURL) and kept every
 * one of them there for the whole session. That works for a handful of small images but falls
 * over — slow UI, huge memory use, possible crashes — with many phone-camera photos.
 *
 * Here, a photo is only ever a content Uri plus its true pixel dimensions (read from the file
 * header, never the pixels). Thumbnails are decoded downsampled to whatever size is actually
 * needed on screen, and full resolution is only decoded one photo at a time, right before that
 * photo's frames are rendered during export.
 *
 * BIG IMPORTS (thousands of photos): both import functions below work through the photos in
 * small chunks, read a few photos at the same time, and hand every finished chunk straight back
 * to the caller. That means (1) the list on screen grows while the import runs, (2) a progress
 * bar can be shown, (3) the import can be stopped half-way without losing what is already in,
 * and (4) one unreadable file is skipped instead of failing the whole import.
 */
class ImageStore(private val context: Context) {

    private val readers = Semaphore(IMPORT_READ_PARALLELISM)

    /**
     * Imports photos picked one-by-one in the system picker.
     *
     * [onBatch] is called after every chunk with (photos just read, photos handled so far,
     * total photos). Returns how many photos had to be skipped because they couldn't be opened.
     */
    suspend fun importFiles(
        uris: List<Uri>,
        onBatch: (List<PoolImage>, Int, Int) -> Unit
    ): Int = withContext(Dispatchers.IO) {
        val resolver = context.contentResolver
        val total = uris.size
        var processed = 0
        var skipped = 0
        var grantAttempts = 0
        val grantLimit = maxPersistedGrants()

        for (chunk in uris.chunked(IMPORT_CHUNK_SIZE)) {
            ensureActive()

            // Ask Android to remember access across app restarts - but only for as many photos
            // as Android can actually remember (a few hundred in total). Asking for the rest
            // would just push earlier photos out again, and costs one system call per photo.
            val asked = HashSet<Uri>()
            for (uri in chunk) {
                if (grantAttempts >= grantLimit) break
                grantAttempts++
                try {
                    resolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    asked.add(uri)
                } catch (_: Exception) {
                    // Some providers don't allow long-term access. The photo still works for
                    // this session, it just won't survive an app restart.
                }
            }
            // One lookup per chunk (not one per photo) to confirm what was really remembered.
            val remembered: Set<Uri> = if (asked.isEmpty()) emptySet() else persistedReadUris(resolver)

            val batch = coroutineScope {
                chunk.map { uri ->
                    async { readers.withPermit { describe(uri, null, uri in remembered) } }
                }.awaitAll()
            }.filterNotNull()

            skipped += chunk.size - batch.size
            processed += chunk.size
            onBatch(batch, processed, total)
        }
        skipped
    }

    /**
     * Imports every photo inside a picked folder, INCLUDING all of its sub-folders, in one go -
     * the real fix for "thousands of photos / 10 GB+". Picking files individually gives each one
     * its OWN persisted permission grant, and Android's per-app ceiling on those is a few
     * hundred at most. A folder (tree) grant is different: ONE persisted grant covers the whole
     * folder and everything under it, with no per-file limit.
     *
     * Only each photo's header is read (never its pixels), so the total size of the folder
     * (10 GB, 100 GB...) doesn't matter - only how many files there are.
     *
     * [onScan] reports how many photos have been found so far while the folders are being
     * listed. [onBatch] works like in [importFiles]; it is also called once with an empty list
     * right after listing, so the progress bar can show the real total early.
     * Returns how many photos had to be skipped because they couldn't be opened. Throws (with a
     * readable message) if the folder itself couldn't be read at all.
     */
    suspend fun importFolder(
        treeUri: Uri,
        onBatch: (List<PoolImage>, Int, Int) -> Unit,
        onScan: (Int) -> Unit = {},
        sort: FolderSort = FolderSort.NAME
    ): Int = withContext(Dispatchers.IO) {
        val resolver = context.contentResolver
        try {
            resolver.takePersistableUriPermission(treeUri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (_: SecurityException) {
            // Even without a persisted grant, a freshly-picked tree Uri still works for the
            // rest of this session, so still attempt the import rather than bailing out here.
        }

        val rootDocId = try {
            DocumentsContract.getTreeDocumentId(treeUri)
        } catch (_: Exception) {
            throw IllegalStateException("Android didn't give the app access to that folder. Please pick it again.")
        }

        // Step 1: list the folder and every sub-folder (breadth-first). One quick query per
        // folder, no photo is opened yet. A sub-folder that can't be read is skipped and
        // counted - it never aborts the rest of the scan.
        val entries = ArrayList<FolderEntry>()
        val folders = ArrayList<Pair<String, String>>() // (document id, path shown for sorting)
        folders.add(rootDocId to "")
        val seenFolders = HashSet<String>()
        var unreadableFolders = 0
        var reportedAt = 0
        var head = 0
        while (head < folders.size) {
            ensureActive()
            val (parentId, parentPath) = folders[head]
            head++
            if (!seenFolders.add(parentId)) continue
            try {
                val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, parentId)
                val cursor = resolver.query(
                    childrenUri,
                    arrayOf(
                        DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                        DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                        DocumentsContract.Document.COLUMN_MIME_TYPE,
                        DocumentsContract.Document.COLUMN_LAST_MODIFIED
                    ),
                    null, null, null
                )
                if (cursor == null) {
                    unreadableFolders++
                } else {
                    cursor.use {
                        val idIdx = it.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DOCUMENT_ID)
                        val nameIdx = it.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DISPLAY_NAME)
                        val mimeIdx = it.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_MIME_TYPE)
                        // optional: not every storage provider reports a date
                        val modIdx = it.getColumnIndex(DocumentsContract.Document.COLUMN_LAST_MODIFIED)
                        while (it.moveToNext()) {
                            val docId = it.getString(idIdx) ?: continue
                            val name = it.getString(nameIdx) ?: docId
                            val mime = it.getString(mimeIdx)
                            if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                                folders.add(docId to "$parentPath$name/")
                            } else if (looksLikeImage(mime, name)) {
                                entries.add(
                                    FolderEntry(
                                        DocumentsContract.buildDocumentUriUsingTree(treeUri, docId),
                                        name,
                                        "$parentPath$name",
                                        if (modIdx >= 0 && !it.isNull(modIdx)) it.getLong(modIdx) else 0L
                                    )
                                )
                            }
                        }
                    }
                }
            } catch (_: Exception) {
                unreadableFolders++
            }
            if (entries.size - reportedAt >= 100) {
                reportedAt = entries.size
                onScan(entries.size)
            }
        }
        onScan(entries.size)

        if (entries.isEmpty() && unreadableFolders > 0) {
            throw IllegalStateException(
                "Android wouldn't let the app read that folder. Try a folder inside it " +
                    "(for example a sub-folder of Pictures, DCIM or Documents)."
            )
        }
        // NEW: by name (the original order) or by file date, oldest or newest first. Ties (and photos with no date,
        // which always go last) fall back to the name order so the result is always the same for the same folder.
        val byName = Comparator<FolderEntry> { a, b -> naturalCompare(a.sortKey, b.sortKey) }
        when (sort) {
            FolderSort.NAME -> entries.sortWith(byName)
            FolderSort.OLDEST_FIRST, FolderSort.NEWEST_FIRST -> {
                val newestFirst = sort == FolderSort.NEWEST_FIRST
                entries.sortWith(Comparator { a, b ->
                    val aKnown = a.modifiedMs > 0L
                    val bKnown = b.modifiedMs > 0L
                    when {
                        aKnown && !bKnown -> -1
                        !aKnown && bKnown -> 1
                        aKnown && bKnown && a.modifiedMs != b.modifiedMs ->
                            if (newestFirst) b.modifiedMs.compareTo(a.modifiedMs) else a.modifiedMs.compareTo(b.modifiedMs)
                        else -> byName.compare(a, b)
                    }
                })
            }
        }

        val total = entries.size
        onBatch(emptyList(), 0, total)

        // Step 2: read each photo's size, chunk by chunk, a few at a time.
        var processed = 0
        var skipped = 0
        for (chunk in entries.chunked(IMPORT_CHUNK_SIZE)) {
            ensureActive()
            val batch = coroutineScope {
                chunk.map { entry ->
                    // persistedAccess = true: inherited from the one tree-level grant above.
                    async { readers.withPermit { describe(entry.uri, entry.name, true) } }
                }.awaitAll()
            }.filterNotNull()

            skipped += chunk.size - batch.size
            processed += chunk.size
            onBatch(batch, processed, total)
        }
        skipped
    }

    /**
     * Reads one photo's name and true size. Returns null if the file can't be opened at all, so
     * the caller can skip it - one bad file must never take the whole import down with it.
     */
    private fun describe(uri: Uri, knownName: String?, persisted: Boolean): PoolImage? {
        return try {
            val resolver = context.contentResolver
            val bounds = decodeBoundsRespectingExif(resolver, uri)
            if (bounds == null) {
                // FIXED: a photo whose header can't be read (unsupported format on this phone, a cloud-only
                // file that isn't downloaded, a provider that refuses access) used to be added anyway with a
                // size of 0x0 - it then showed blank in the Preview and as a black slot in the exported video.
                // One last real decode decides: if even that fails, the photo is skipped (and counted in the
                // "couldn't be added" note) instead of being added as a blank picture.
                val probe = try { decodeSampled(uri, 64) } catch (_: Exception) { null }
                if (probe == null) return null
                probe.recycle()
            }
            val (w, h) = bounds ?: (0 to 0)
            val name = if (knownName != null) {
                knownName
            } else {
                val queried: String? = try {
                    queryDisplayName(resolver, uri)
                } catch (_: Exception) {
                    null
                }
                queried ?: uri.lastPathSegment ?: "photo"
            }
            // FIXED: a photo Android would NOT remember access to (more than ~500 single photos, or a source that
            // refuses long-term access) stopped opening after the app was closed or the project was reopened -
            // blank in the Preview, black in the export. Such photos are now copied (byte for byte, no
            // re-encoding) into the app's own storage, which can never expire. Photos that ARE remembered, and
            // whole-folder imports, are untouched (no copy, so a huge import stays fast and small).
            var finalUri = uri
            var finalPersisted = persisted
            if (!persisted) {
                val pinned = copyToPrivateStorage(uri, name)
                if (pinned != null) {
                    finalUri = pinned
                    finalPersisted = true
                }
            }
            PoolImage(
                id = UUID.randomUUID().toString(),
                uri = finalUri,
                displayName = name,
                widthPx = w,
                heightPx = h,
                persistedAccess = finalPersisted
            )
        } catch (_: Exception) {
            null
        } catch (_: OutOfMemoryError) {
            // A corrupt file claiming an absurd size must not take the whole app down.
            null
        }
    }

    /**
     * NEW: copies one photo, unchanged, into the app's private storage and returns the new file's Uri
     * (null if it could not be copied - the caller then keeps the original Uri). Nothing is re-encoded, so
     * quality and the photo's rotation information stay exactly as they were.
     */
    private fun copyToPrivateStorage(uri: Uri, displayName: String): Uri? {
        var target: File? = null
        return try {
            val dir = File(context.filesDir, "photos").apply { mkdirs() }
            val ext = displayName.substringAfterLast('.', "").lowercase()
                .takeIf { it.length in 1..5 && it.all { c -> c.isLetterOrDigit() } } ?: "jpg"
            val file = File(dir, "${UUID.randomUUID()}.$ext")
            target = file
            val input = context.contentResolver.openInputStream(uri) ?: return null
            input.use { src -> file.outputStream().use { dst -> src.copyTo(dst) } }
            if (file.length() <= 0L) {
                file.delete()
                null
            } else {
                Uri.fromFile(file)
            }
        } catch (_: Exception) {
            try { target?.delete() } catch (_: Exception) {}
            null
        }
    }

    /**
     * NEW: a quick check (header only, no pixels) that a photo can really be opened right now. Used before an export
     * and by the Preview so a photo that has lost its access is reported by name instead of silently turning blank.
     */
    suspend fun canOpen(uri: Uri): Boolean = withContext(Dispatchers.IO) {
        try {
            val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            val stream = context.contentResolver.openInputStream(uri) ?: return@withContext false
            stream.use { BitmapFactory.decodeStream(it, null, options) }
            options.outWidth > 0 && options.outHeight > 0
        } catch (_: Exception) {
            false
        } catch (_: OutOfMemoryError) {
            false
        }
    }

    /** How many long-term photo grants Android keeps per app: 512 on Android 11+, 128 before. */
    private fun maxPersistedGrants(): Int =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) 500 else 120

    private fun persistedReadUris(resolver: ContentResolver): Set<Uri> {
        return try {
            resolver.persistedUriPermissions.filter { it.isReadPermission }.mapTo(HashSet<Uri>()) { it.uri }
        } catch (_: Exception) {
            emptySet()
        }
    }

    private fun queryDisplayName(resolver: ContentResolver, uri: Uri): String? {
        resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (idx >= 0) return cursor.getString(idx)
            }
        }
        return null
    }

    /** Reads only the image header (no pixel data) to get true, EXIF-corrected dimensions. */
    private fun decodeBoundsRespectingExif(resolver: ContentResolver, uri: Uri): Pair<Int, Int>? {
        val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        // NOTE: with inJustDecodeBounds = true, BitmapFactory.decodeStream() is *guaranteed* by
        // the Android API contract to return null on every call, no matter what — it only has
        // the side effect of filling in options.outWidth/outHeight. That's not a failure signal,
        // so the "did the stream actually open" check has to happen on its own, separately —
        // chaining it with ?: on the decode call's result was treating an always-null return as
        // an always-failed stream, which silently broke this for every photo, every time.
        val boundsStream = resolver.openInputStream(uri) ?: return null
        boundsStream.use { BitmapFactory.decodeStream(it, null, options) }
        var w = options.outWidth
        var h = options.outHeight
        if (w <= 0 || h <= 0) return null

        val rotation = readExifRotation(resolver, uri)
        if (rotation == 90 || rotation == 270) {
            val tmp = w; w = h; h = tmp
        }
        return w to h
    }

    private fun readExifRotation(resolver: ContentResolver, uri: Uri): Int = try {
        resolver.openInputStream(uri)?.use { stream ->
            val exif = ExifInterface(stream)
            when (exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90
                ExifInterface.ORIENTATION_ROTATE_180 -> 180
                ExifInterface.ORIENTATION_ROTATE_270 -> 270
                else -> 0
            }
        } ?: 0
    } catch (_: Exception) {
        0
    }

    /** Downsampled bitmap safe for thumbnails/lists — never loads full resolution. */
    suspend fun decodeThumbnail(uri: Uri, targetLongEdge: Int = 400): Bitmap? =
        withContext(Dispatchers.IO) { decodeSampled(uri, targetLongEdge) }

    /** Highest-quality decode used at export time, still capped so one huge photo can't OOM the app. */
    suspend fun decodeForExport(uri: Uri, maxLongEdge: Int): Bitmap? =
        withContext(Dispatchers.IO) { decodeSampled(uri, maxLongEdge) }

    private fun decodeSampled(uri: Uri, targetLongEdge: Int): Bitmap? {
        val resolver = context.contentResolver
        val boundsOptions = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        // Same fix as decodeBoundsRespectingExif above: this bounds-only call always returns
        // null by design, so the stream-opened check has to be separate from it.
        val boundsStream = resolver.openInputStream(uri) ?: return null
        boundsStream.use { BitmapFactory.decodeStream(it, null, boundsOptions) }

        var sample = 1
        val longEdge = maxOf(boundsOptions.outWidth, boundsOptions.outHeight)
        while (longEdge / (sample * 2) >= targetLongEdge) sample *= 2

        val decodeOptions = BitmapFactory.Options().apply {
            inSampleSize = sample
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }
        // This second decode call is a REAL pixel decode (inJustDecodeBounds isn't set), so a
        // null return here is a genuine failure and the ?: return null is correct as-is.
        val raw = resolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, decodeOptions)
        } ?: return null

        return applyExifRotation(raw, readExifRotation(resolver, uri))
    }

    /**
     * Decodes a photo at the biggest size that does NOT exceed [maxLongEdge] on its long side (full size
     * for any photo that is already smaller). Unlike [decodeForExport], which may overshoot by up to 2x,
     * this guarantees a ceiling - the logo cleaner needs that so a huge photo can't run the phone out of
     * memory while it is being repainted.
     */
    suspend fun decodeAtMost(uri: Uri, maxLongEdge: Int): Bitmap? = withContext(Dispatchers.IO) {
        val resolver = context.contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        val boundsStream = resolver.openInputStream(uri) ?: return@withContext null
        boundsStream.use { BitmapFactory.decodeStream(it, null, bounds) }
        val longEdge = maxOf(bounds.outWidth, bounds.outHeight)
        if (longEdge <= 0) return@withContext null
        var sample = 1
        while (longEdge / sample > maxLongEdge) sample *= 2
        val options = BitmapFactory.Options().apply {
            inSampleSize = sample
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }
        val raw = resolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, options)
        } ?: return@withContext null
        applyExifRotation(raw, readExifRotation(resolver, uri))
    }

    private fun applyExifRotation(bitmap: Bitmap, degrees: Int): Bitmap {
        if (degrees == 0) return bitmap
        val matrix = Matrix().apply { postRotate(degrees.toFloat()) }
        val rotated = Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
        if (rotated !== bitmap) bitmap.recycle()
        return rotated
    }
}
