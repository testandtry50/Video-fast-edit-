package com.videoslidemaker.app.ui.components

import android.content.Context
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import coil.imageLoader
import coil.request.ImageRequest
import coil.size.Scale
import com.videoslidemaker.app.model.PoolImage
import com.videoslidemaker.app.ui.theme.Accent
import com.videoslidemaker.app.ui.theme.Green
import com.videoslidemaker.app.ui.theme.OverlayIcon
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

/** One request definition, so the photo being viewed and the ones pre-loaded next to it share a cache entry. */
private fun fullPhotoRequest(context: Context, uri: Uri): ImageRequest =
    ImageRequest.Builder(context).data(uri).size(2400, 2400).scale(Scale.FIT).build()

/**
 * NEW: the fast way to look at photos at full size. Open ONE photo and then just swipe left / right
 * to go through ALL of them - no closing and re-opening for each one.
 *
 *  - every photo is shown whole (never cropped), as large as the screen allows
 *  - pinch or double-tap to zoom in on detail; while zoomed, dragging moves the photo, and once
 *    you zoom back out swiping changes photo again
 *  - the slider at the bottom is a scrubber: drag it to jump across hundreds of photos at once
 *  - the sentence you are matching stays at the top, and the button at the bottom uses the photo
 *    that is on screen. The viewer stays open, so you can pick, swipe, pick, swipe.
 *  - the photos on either side are loaded in advance so swiping is instant
 *
 * [images] is the list as it was when the viewer opened (it won't shift under your finger).
 */
@Composable
fun PhotoPagerDialog(
    images: List<PoolImage>,
    startIndex: Int,
    usedOn: Map<String, Int>,
    currentImageId: String?,
    sentenceLabel: String,
    timeLabel: String,
    sentenceText: String,
    onPick: (PoolImage) -> Unit,
    onDismiss: () -> Unit
) {
    if (images.isEmpty()) {
        LaunchedEffect(Unit) { onDismiss() }
        return
    }

    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val lastIndex = images.size - 1
    val pagerState = rememberPagerState(initialPage = startIndex.coerceIn(0, lastIndex)) { images.size }
    var zoomed by remember { mutableStateOf(false) }
    val page = pagerState.currentPage.coerceIn(0, lastIndex)
    val image = images[page]

    LaunchedEffect(pagerState.currentPage) {
        zoomed = false
        // Pre-load the neighbours (next one first, since that is the usual direction).
        val p = pagerState.currentPage
        for (d in intArrayOf(1, -1, 2, -2)) {
            val neighbour = images.getOrNull(p + d) ?: continue
            context.imageLoader.enqueue(fullPhotoRequest(context, neighbour.uri))
        }
    }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(
            Modifier
                .fillMaxSize()
                .background(Color.Black)
                .safeDrawingPadding()
        ) {
            // --- Top: close, position, and the sentence being matched ---
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(start = 4.dp, end = 16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Filled.Close, contentDescription = "Close full-size viewer", tint = OverlayIcon)
                }
                Column(Modifier.weight(1f)) {
                    Text(
                        "${page + 1} / ${images.size} · ${image.displayName}",
                        color = OverlayIcon,
                        style = MaterialTheme.typography.titleSmall,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        "$sentenceLabel · $timeLabel",
                        color = Accent,
                        style = MaterialTheme.typography.labelMedium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
            if (sentenceText.isNotBlank()) {
                Text(
                    sentenceText,
                    color = OverlayIcon,
                    style = MaterialTheme.typography.bodySmall,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(start = 16.dp, end = 16.dp, bottom = 6.dp)
                )
            }

            // --- The photos: swipe sideways ---
            HorizontalPager(
                state = pagerState,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                userScrollEnabled = !zoomed,
                pageSpacing = 12.dp,
                key = { index -> images[index].id }
            ) { index ->
                ZoomablePhoto(
                    image = images[index],
                    active = index == pagerState.currentPage,
                    onZoomedChange = { isZoomed -> if (index == pagerState.currentPage) zoomed = isZoomed }
                )
            }

            // --- Bottom: where this photo is used, scrubber, and the Use button ---
            val usedNumber = usedOn[image.id]
            val isCurrent = image.id == currentImageId
            Text(
                when {
                    isCurrent -> "✓ This photo is on this sentence"
                    usedNumber != null -> "Used on sentence #$usedNumber"
                    else -> "Not used yet"
                },
                color = if (isCurrent) Accent else if (usedNumber != null) Green else OverlayIcon,
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp)
            )

            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { scope.launch { pagerState.scrollToPage((page - 1).coerceAtLeast(0)) } },
                    enabled = page > 0
                ) {
                    Icon(
                        Icons.Filled.ChevronLeft,
                        contentDescription = "Previous photo",
                        tint = if (page > 0) OverlayIcon else OverlayIcon.copy(alpha = 0.3f)
                    )
                }
                if (images.size > 1) {
                    Slider(
                        value = page.toFloat(),
                        onValueChange = { v -> scope.launch { pagerState.scrollToPage(v.roundToInt().coerceIn(0, lastIndex)) } },
                        valueRange = 0f..lastIndex.toFloat(),
                        colors = appSliderColors(),
                        modifier = Modifier.weight(1f)
                    )
                } else {
                    Box(Modifier.weight(1f))
                }
                IconButton(
                    onClick = { scope.launch { pagerState.scrollToPage((page + 1).coerceAtMost(lastIndex)) } },
                    enabled = page < lastIndex
                ) {
                    Icon(
                        Icons.Filled.ChevronRight,
                        contentDescription = "Next photo",
                        tint = if (page < lastIndex) OverlayIcon else OverlayIcon.copy(alpha = 0.3f)
                    )
                }
            }

            Column(Modifier.padding(horizontal = 16.dp, vertical = 4.dp)) {
                Text(
                    "Swipe for next photo · pinch or double-tap to zoom",
                    color = OverlayIcon.copy(alpha = 0.7f),
                    style = MaterialTheme.typography.bodySmall,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
                PrimaryButton(
                    if (isCurrent) "✓ Already on this sentence" else "Use this photo for this sentence",
                    modifier = Modifier.padding(top = 4.dp, bottom = 8.dp),
                    enabled = !isCurrent,
                    onClick = { onPick(image) }
                )
            }
        }
    }
}

/**
 * One page of the viewer: the whole photo, with pinch / double-tap zoom.
 *
 * The gesture code only takes over when it should: with one finger on an un-zoomed photo it does
 * NOT consume the drag, so the pager's swipe works. Once two fingers are down, or the photo is
 * zoomed in, it consumes the drag and moves / scales the photo instead.
 */
@Composable
private fun ZoomablePhoto(
    image: PoolImage,
    active: Boolean,
    onZoomedChange: (Boolean) -> Unit
) {
    val context = LocalContext.current
    var scale by remember { mutableFloatStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }
    var area by remember { mutableStateOf(IntSize.Zero) }
    val request = remember(image.uri) { fullPhotoRequest(context, image.uri) }
    val reportZoomed by rememberUpdatedState(onZoomedChange)

    // Swiping away from a zoomed photo puts it back to normal for next time.
    LaunchedEffect(active) {
        if (!active) {
            scale = 1f
            offset = Offset.Zero
        }
    }

    Box(
        Modifier
            .fillMaxSize()
            .clipToBounds()
            .onSizeChanged { area = it }
            .pointerInput(Unit) {
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false)
                    do {
                        val event = awaitPointerEvent()
                        val twoFingers = event.changes.size > 1
                        if (twoFingers || scale > 1f) {
                            val zoom = event.calculateZoom()
                            val pan = event.calculatePan()
                            val newScale = (scale * zoom).coerceIn(1f, 6f)
                            // Never let the photo be dragged completely out of view.
                            val maxX = area.width * (newScale - 1f) / 2f
                            val maxY = area.height * (newScale - 1f) / 2f
                            scale = newScale
                            offset = if (newScale <= 1f) {
                                Offset.Zero
                            } else {
                                Offset(
                                    (offset.x + pan.x).coerceIn(-maxX, maxX),
                                    (offset.y + pan.y).coerceIn(-maxY, maxY)
                                )
                            }
                            reportZoomed(newScale > 1f)
                            event.changes.forEach { change ->
                                if (change.positionChanged()) change.consume()
                            }
                        }
                    } while (event.changes.any { it.pressed })
                }
            }
            .pointerInput(Unit) {
                detectTapGestures(
                    onDoubleTap = {
                        if (scale > 1f) {
                            scale = 1f
                            offset = Offset.Zero
                            reportZoomed(false)
                        } else {
                            scale = 2.5f
                            reportZoomed(true)
                        }
                    }
                )
            }
    ) {
        AsyncImage(
            model = request,
            contentDescription = image.displayName,
            contentScale = ContentScale.Fit,
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer {
                    scaleX = scale
                    scaleY = scale
                    translationX = offset.x
                    translationY = offset.y
                }
        )
    }
}
