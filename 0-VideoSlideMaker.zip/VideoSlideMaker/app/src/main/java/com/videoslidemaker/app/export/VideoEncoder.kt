package com.videoslidemaker.app.export

import android.graphics.Bitmap
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaCodecList
import android.media.MediaFormat

/**
 * Native H.264 encoder driven frame-by-frame from rendered bitmaps. This replaces the original
 * app's approach of capturing a <canvas> through MediaRecorder — which depends on whatever
 * codec the phone's browser happens to support and paces frames with plain setTimeout — with
 * Android's real hardware/software encoder pipeline and exact per-frame timestamps, so output
 * is reliable and doesn't drop or duplicate frames under load.
 */
class VideoEncoder(
    private val width: Int,
    private val height: Int,
    private val fps: Int,
    bitrateBps: Int,
    private val muxer: MuxerHolder
) {
    private val mimeType = MediaFormat.MIMETYPE_VIDEO_AVC
    private val codec: MediaCodec = MediaCodec.createEncoderByType(mimeType)
    private val bufferInfo = MediaCodec.BufferInfo()
    private var trackIndex = -1
    private var frameIndex = 0L
    private var released = false

    init {
        val format = MediaFormat.createVideoFormat(mimeType, width, height).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, chooseColorFormat())
            setInteger(MediaFormat.KEY_BIT_RATE, bitrateBps)
            setInteger(MediaFormat.KEY_FRAME_RATE, fps)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 2)
        }
        codec.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        codec.start()
    }

    private fun chooseColorFormat(): Int {
        val flexible = MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible
        try {
            val list = MediaCodecList(MediaCodecList.REGULAR_CODECS)
            val encoderName = list.findEncoderForFormat(MediaFormat.createVideoFormat(mimeType, width, height))
            val info = list.codecInfos.firstOrNull { it.name == encoderName } ?: return flexible
            val supported = info.getCapabilitiesForType(mimeType).colorFormats.toSet()
            return when {
                flexible in supported -> flexible
                MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420SemiPlanar in supported ->
                    MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420SemiPlanar
                else -> flexible
            }
        } catch (_: Exception) {
            return flexible
        }
    }

    /** Encodes one bitmap as the next frame in the sequence. */
    fun encodeFrame(bitmap: Bitmap) {
        var inputIndex = codec.dequeueInputBuffer(TIMEOUT_US)
        // If the encoder is briefly full (common at 4K), drain its output and try again. Before, the
        // frame was silently thrown away here, which made the video shorter than its sound track.
        var waitedMs = 0L
        while (inputIndex < 0) {
            drainEncoder(false)
            waitedMs += TIMEOUT_US / 1000
            if (waitedMs > STALL_LIMIT_MS) {
                throw IllegalStateException("The phone's video encoder stopped responding.")
            }
            inputIndex = codec.dequeueInputBuffer(TIMEOUT_US)
        }
        if (inputIndex >= 0) {
            // Fetch the raw buffer first so we always have a handle to it regardless of which
            // path below ends up writing the pixel data.
            val rawBuffer = codec.getInputBuffer(inputIndex)
            val image = try {
                codec.getInputImage(inputIndex)
            } catch (_: Exception) {
                null
            }
            val size: Int
            if (image != null) {
                Yuv420Writer.writeBitmapToImage(bitmap, image)
                // IMPORTANT: don't submit a hand-computed width*height*3/2 here. Real hardware
                // encoders very commonly pad each row to their own stride — e.g. a width/height
                // of 1080 (a completely standard "1080p"/"Reels" dimension) typically gets
                // padded to 1088 internally. writeBitmapToImage already writes every plane
                // using its *actual* rowStride/pixelStride, so the buffer that's really been
                // populated is bigger than the naive tight-packed math. Submitting the smaller,
                // wrong size here truncates/misaligns the chroma planes the encoder reads back
                // — which is exactly what renders as a solid green/garbled frame. The buffer's
                // own capacity already reflects the correct, device-specific padded layout.
                size = (rawBuffer?.capacity() ?: (width * height * 3 / 2)).coerceAtLeast(width * height * 3 / 2)
            } else {
                size = width * height * 3 / 2
                rawBuffer?.let { buffer -> Yuv420Writer.writeBitmapToNv12(bitmap, buffer, width, height) }
            }
            val ptsUs = frameIndex * 1_000_000L / fps
            codec.queueInputBuffer(inputIndex, 0, size, ptsUs, 0)
            frameIndex++
        }
        drainEncoder(false)
    }

    fun finish() {
        // The end-of-stream marker MUST get into the encoder. A single attempt used to be made, and
        // if the input queue was full at that instant the marker was skipped and the drain below
        // waited forever for an end that never came (the export would sit at ~95%).
        var waitedMs = 0L
        var queued = false
        while (!queued) {
            val inputIndex = codec.dequeueInputBuffer(TIMEOUT_US)
            if (inputIndex >= 0) {
                codec.queueInputBuffer(inputIndex, 0, 0, frameIndex * 1_000_000L / fps, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                queued = true
            } else {
                drainEncoder(false) // frees up queue space
                waitedMs += TIMEOUT_US / 1000
                if (waitedMs > STALL_LIMIT_MS) {
                    throw IllegalStateException("The phone's video encoder stopped responding while finishing the video.")
                }
            }
        }
        drainEncoder(true)
        release()
    }

    /** Safe to call any number of times, and after a failure or cancel — frees the hardware codec
     *  so an aborted export can't leave it allocated and break the next one. */
    fun release() {
        if (released) return
        released = true
        try { codec.stop() } catch (_: Throwable) {}
        try { codec.release() } catch (_: Throwable) {}
    }

    private fun drainEncoder(endOfStream: Boolean) {
        var idleMs = 0L
        while (true) {
            // Only block while waiting for the very last frames; while encoding, never wait here
            // (waiting 10 ms after every frame added minutes to a long video).
            val outputIndex = codec.dequeueOutputBuffer(bufferInfo, if (endOfStream) TIMEOUT_US else 0L)
            when {
                outputIndex == MediaCodec.INFO_TRY_AGAIN_LATER -> {
                    if (!endOfStream) return
                    idleMs += TIMEOUT_US / 1000
                    if (idleMs > STALL_LIMIT_MS) {
                        throw IllegalStateException("The phone's video encoder stopped responding while finishing the video.")
                    }
                }
                outputIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                    trackIndex = muxer.addVideoTrack(codec.outputFormat)
                    idleMs = 0L
                }
                outputIndex >= 0 -> {
                    idleMs = 0L
                    val encodedData = codec.getOutputBuffer(outputIndex)
                    if (encodedData != null && bufferInfo.size > 0 &&
                        (bufferInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0
                    ) {
                        encodedData.position(bufferInfo.offset)
                        encodedData.limit(bufferInfo.offset + bufferInfo.size)
                        muxer.writeVideoSample(trackIndex, encodedData, bufferInfo)
                    }
                    codec.releaseOutputBuffer(outputIndex, false)
                    if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) return
                }
            }
        }
    }

    companion object {
        private const val TIMEOUT_US = 10_000L
        private const val STALL_LIMIT_MS = 30_000L
    }
}
