package com.videoslidemaker.app.adjust

import com.videoslidemaker.app.check.CheckFormat

/** How the preview shows times, and how typed amounts are read. */
object AdjustFormat {

    /**
     * `00:01:24` or `00:01:25.430`: always hours:minutes:seconds, and milliseconds only when there are some, so a script that
     * wrote `00:01:24` is shown as it was written and `...25.430` is exact.
     */
    fun clock(ms: Long): String = CheckFormat.clock(ms).removeSuffix(".000")

    /** `00:01:24 — Hello everyone` (the script's own line shape). */
    fun scriptLine(ms: Long, text: String): String = "${clock(ms)} — $text"

    /** `+1.430 seconds`, `-0.250 seconds`, `0.000 seconds`. */
    fun difference(ms: Long): String = CheckFormat.signedSeconds(ms)

    private const val MAX_AMOUNT_MS = 24L * 3_600_000L

    /**
     * An amount of time typed by the user, in milliseconds, with an optional sign: `1.43`, `+1.43`, `-0.25`, `.5`, `1,43`,
     * `430ms`, `1.43s`, `1:23.5`, `1:02:03`. Null when it is not a time. A clock form needs minutes and seconds under 60.
     */
    fun parseSigned(input: String): Long? {
        var s = input.trim()
        if (s.isEmpty()) return null
        var sign = 1L
        val c = s[0]
        if (c == '+' || c == '-' || c == '\u2212' || c == '\u2013') {
            if (c != '+') sign = -1L
            s = s.substring(1).trim()
        }
        if (s.isEmpty()) return null
        var scale = 1000L                       // how many ms one unit of the number is
        if (s.endsWith("ms", ignoreCase = true)) {
            scale = 1L
            s = s.substring(0, s.length - 2).trim()
        } else if (s.endsWith("s", ignoreCase = true)) {
            s = s.substring(0, s.length - 1).trim()
        }
        if (s.isEmpty()) return null
        val ms: Long
        if (s.contains(':')) {
            if (scale != 1000L) return null
            val parts = s.split(':')
            if (parts.size !in 2..3) return null
            val last = decimalValueTimes1000(parts.last()) ?: return null
            var total = last
            val whole = parts.dropLast(1)
            val mult = longArrayOf(60_000L, 3_600_000L)
            for ((k, p) in whole.asReversed().withIndex()) {
                if (p.isEmpty() || !p.all { it in '0'..'9' }) return null
                val v = p.toLongOrNull() ?: return null
                if (k == 0 && whole.size == 2 && v >= 60) return null      // minutes inside an hours form
                total += v * mult[k]
            }
            if (last >= 60_000L) return null                              // seconds under 60 in a clock form
            ms = total
        } else {
            val v = decimalValueTimes1000(s) ?: return null      // value * 1000: milliseconds when the number is seconds
            // "430ms": the digits ARE milliseconds, so undo the *1000 (a fraction of a millisecond is rounded)
            ms = if (scale == 1L) (v + 500L) / 1000L else v
        }
        if (ms > MAX_AMOUNT_MS) return null
        return sign * ms
    }

    /** Digits with an optional `.`/`,` fraction -> value * 1000, half-up rounded to a whole number. */
    private fun decimalValueTimes1000(s: String): Long? {
        val t = s.replace(',', '.')
        val dot = t.indexOf('.')
        val whole = if (dot < 0) t else t.substring(0, dot)
        val frac = if (dot < 0) "" else t.substring(dot + 1)
        if (whole.isEmpty() && frac.isEmpty()) return null
        if (!whole.all { it in '0'..'9' } || !frac.all { it in '0'..'9' }) return null
        if (whole.length > 9) return null
        val w = if (whole.isEmpty()) 0L else whole.toLong()
        val f3 = (frac + "000").substring(0, 3).toLong()
        val round = if (frac.length > 3 && frac[3] >= '5') 1L else 0L
        return w * 1000L + f3 + round
    }

    /**
     * The offset the user means. A typed sign wins (`-0.25` is earlier, `+0.25` later); otherwise [earlier] decides, so a
     * phone's number keyboard (which often has no minus) can still move a transcript earlier.
     */
    fun resolveOffset(text: String, earlier: Boolean): Long? {
        val t = text.trim()
        val signed = parseSigned(t) ?: return null
        val explicit = t.isNotEmpty() && (t[0] == '+' || t[0] == '-' || t[0] == '\u2212' || t[0] == '\u2013')
        return if (explicit) signed else if (earlier) -signed else signed
    }
}
