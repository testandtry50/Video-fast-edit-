package com.videoslidemaker.app.ui.components

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.snapping.rememberSnapFlingBehavior
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.semantics.CustomAccessibilityAction
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.customActions
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.videoslidemaker.app.ui.theme.Accent
import com.videoslidemaker.app.ui.theme.BorderColor
import com.videoslidemaker.app.ui.theme.CardBg
import com.videoslidemaker.app.ui.theme.Muted
import com.videoslidemaker.app.ui.theme.Outline
import com.videoslidemaker.app.ui.theme.TextMain
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * NEW (2.18): a drum-roll "wheel" picker, the kind of control a phone's alarm clock uses.
 *
 * - It flings and always comes to rest with one row exactly in the middle (that row is the chosen one).
 * - Rows tilt, shrink and fade towards the top and bottom edge, so the middle row clearly stands out.
 * - Every row that passes the middle gives a tiny tick of haptic feedback.
 * - Tapping a row rolls the wheel to it; tapping the row that is already in the middle calls [onCenterTap].
 *
 * The wheel owns its position while a finger is on it. The parent can still move it - for a "Scene start" shortcut, say -
 * by changing [selectedIndex] AND [syncToken] together; the wheel then rolls to [selectedIndex] smoothly. (The token is
 * what says "do move it now", so the parent merely learning where the wheel stopped never makes it jump.)
 *
 * @param onChange called live as the middle row changes (while scrolling).
 * @param onSettled called once when the wheel has come to rest, with the row it rests on.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun WheelPicker(
    labels: List<String>,
    selectedIndex: Int,
    modifier: Modifier = Modifier,
    syncToken: Int = 0,
    visibleCount: Int = 5,
    itemHeight: Dp = 44.dp,
    description: String = "",
    onChange: (Int) -> Unit = {},
    onSettled: (Int) -> Unit = {},
    onCenterTap: () -> Unit = {}
) {
    val count = labels.size
    if (count == 0) {
        Box(modifier.height(itemHeight * visibleCount))
        return
    }
    // Blank rows before and after the real ones let the first and last real row reach the middle.
    val half = visibleCount / 2
    val start = selectedIndex.coerceIn(0, count - 1)
    val listState = rememberLazyListState(initialFirstVisibleItemIndex = start)
    val itemPx = with(LocalDensity.current) { itemHeight.toPx() }
    val screenDensity = LocalDensity.current.density
    val fling = rememberSnapFlingBehavior(listState)
    val scope = rememberCoroutineScope()
    val haptic = LocalHapticFeedback.current

    val latestSelected by rememberUpdatedState(selectedIndex)
    val latestChange by rememberUpdatedState(onChange)
    val latestSettled by rememberUpdatedState(onSettled)
    val latestCenterTap by rememberUpdatedState(onCenterTap)
    // true while the PARENT is rolling the wheel (so that is not reported back as if the finger had done it)
    val silent = remember { BooleanArray(1) }
    var spoken by remember { mutableIntStateOf(start) }

    val accent = Accent
    val cardBg = CardBg
    val textMain = TextMain

    // 1. report the row in the middle as it changes (with a tick for each one)
    LaunchedEffect(listState, count) {
        var last = centerRow(listState, itemPx, count)
        snapshotFlow { centerRow(listState, itemPx, count) }.collect { row ->
            if (row != last) {
                last = row
                spoken = row
                if (!silent[0]) {
                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    latestChange(row)
                }
            }
        }
    }
    // 2. tell the parent when the wheel has come to rest
    LaunchedEffect(listState, count) {
        var first = true
        snapshotFlow { listState.isScrollInProgress }.collect { moving ->
            if (first) { first = false; return@collect }
            if (!moving && !silent[0]) latestSettled(centerRow(listState, itemPx, count))
        }
    }
    // 3. the parent asks for a move
    LaunchedEffect(syncToken) {
        val target = latestSelected.coerceIn(0, count - 1)
        if (centerRow(listState, itemPx, count) != target) {
            silent[0] = true
            try {
                listState.animateScrollToItem(target)
            } finally {
                silent[0] = false
            }
            spoken = target
        }
    }

    Box(
        modifier
            .height(itemHeight * visibleCount)
            .semantics {
                contentDescription = description
                stateDescription = labels[spoken.coerceIn(0, count - 1)]
                customActions = listOf(
                    CustomAccessibilityAction("Next value") {
                        scope.launch { listState.animateScrollToItem((centerRow(listState, itemPx, count) + 1).coerceAtMost(count - 1)) }
                        true
                    },
                    CustomAccessibilityAction("Previous value") {
                        scope.launch { listState.animateScrollToItem((centerRow(listState, itemPx, count) - 1).coerceAtLeast(0)) }
                        true
                    }
                )
            },
        contentAlignment = Alignment.Center
    ) {
        // the band behind the middle row
        Box(
            Modifier
                .fillMaxWidth()
                .height(itemHeight)
                .clip(RoundedCornerShape(10.dp))
                .background(accent.copy(alpha = 0.14f))
                .border(1.dp, accent.copy(alpha = 0.55f), RoundedCornerShape(10.dp))
        )
        LazyColumn(
            state = listState,
            flingBehavior = fling,
            modifier = Modifier.fillMaxSize()
        ) {
            items(count + half * 2) { j ->
                val row = j - half
                val real = row in 0 until count
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(itemHeight)
                        .graphicsLayer {
                            if (real) {
                                // how far this row is from the middle, in rows (read here so the wheel never recomposes while rolling)
                                val d = row - (listState.firstVisibleItemIndex + listState.firstVisibleItemScrollOffset / itemPx)
                                val a = abs(d)
                                alpha = (1f - 0.30f * a).coerceIn(0.14f, 1f)
                                val s = (1f - 0.07f * a).coerceIn(0.72f, 1f)
                                scaleX = s
                                scaleY = s
                                rotationX = (-d * 22f).coerceIn(-55f, 55f)
                                cameraDistance = 14f * screenDensity
                            }
                        }
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null,
                            enabled = real
                        ) {
                            if (row == centerRow(listState, itemPx, count)) latestCenterTap()
                            else scope.launch { listState.animateScrollToItem(row) }
                        },
                    contentAlignment = Alignment.Center
                ) {
                    if (real) {
                        Text(
                            labels[row],
                            style = MaterialTheme.typography.titleMedium,
                            color = textMain,
                            textAlign = TextAlign.Center,
                            maxLines = 1
                        )
                    }
                }
            }
        }
        // soft fade at the top and bottom edge (touches go straight through it)
        Box(
            Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        0f to cardBg,
                        0.34f to Color.Transparent,
                        0.66f to Color.Transparent,
                        1f to cardBg
                    )
                )
        )
    }
}

/** The row (0 = the first real one) that is in the middle of the wheel right now. */
private fun centerRow(state: LazyListState, itemPx: Float, count: Int): Int {
    val pos = state.firstVisibleItemIndex + state.firstVisibleItemScrollOffset / itemPx
    return pos.roundToInt().coerceIn(0, count - 1)
}

/** How many rows a wheel shows: 5 normally, 3 on a short (landscape) screen so everything still fits. */
@Composable
fun wheelRows(): Int = if (LocalConfiguration.current.screenHeightDp < 520) 3 else 5

/**
 * NEW (2.18): the bottom sheet the wheels live in. It slides over the screen with a dimmed background; tapping outside
 * it (or Back) closes it. On a short screen the content scrolls instead of being cut off.
 */
@Composable
fun WheelSheet(
    title: String,
    subtitle: String? = null,
    onDismiss: () -> Unit,
    content: @Composable ColumnScope.() -> Unit
) {
    val shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
    val noRipple = remember { MutableInteractionSource() }
    val noRipple2 = remember { MutableInteractionSource() }
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(
            Modifier
                .fillMaxSize()
                .clickable(interactionSource = noRipple, indication = null, onClick = onDismiss),
            contentAlignment = Alignment.BottomCenter
        ) {
            Column(
                Modifier
                    .widthIn(max = 520.dp)
                    .fillMaxWidth()
                    .clip(shape)
                    .background(CardBg)
                    .border(1.dp, BorderColor, shape)
                    // swallow taps so touching the sheet itself does not close it
                    .clickable(interactionSource = noRipple2, indication = null, onClick = {})
                    .navigationBarsPadding()
                    .verticalScroll(rememberScrollState())
                    .padding(start = 16.dp, end = 16.dp, top = 10.dp, bottom = 12.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    Modifier
                        .padding(bottom = 10.dp)
                        .width(36.dp)
                        .height(4.dp)
                        .clip(RoundedCornerShape(2.dp))
                        .background(Outline)
                )
                Text(
                    title,
                    style = MaterialTheme.typography.titleMedium,
                    color = TextMain,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
                if (subtitle != null) {
                    Text(
                        subtitle,
                        style = MaterialTheme.typography.bodySmall,
                        color = Muted,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth().padding(top = 2.dp, bottom = 4.dp)
                    )
                }
                content()
            }
        }
    }
}
