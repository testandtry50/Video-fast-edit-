package com.videoslidemaker.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.videoslidemaker.app.audio.BgSlots
import com.videoslidemaker.app.audio.SceneSpan
import com.videoslidemaker.app.audio.TimeProblem
import com.videoslidemaker.app.ui.theme.Accent
import com.videoslidemaker.app.ui.theme.Muted
import com.videoslidemaker.app.ui.theme.Outline
import com.videoslidemaker.app.ui.theme.Red
import com.videoslidemaker.app.ui.theme.Surface
import com.videoslidemaker.app.ui.theme.TextMain
import kotlin.math.abs

/**
 * NEW (2.18): a sheet with ONE wheel of choices - used for the menu that opens when a scene is pressed and held, and for
 * "which background audio?" when there is more than one. Roll to a row and press the button (or tap the middle row).
 */
@Composable
fun WheelChoiceSheet(
    title: String,
    subtitle: String?,
    labels: List<String>,
    initialIndex: Int = 0,
    confirmText: String,
    hint: String? = null,
    onConfirm: (Int) -> Unit,
    onDismiss: () -> Unit
) {
    var index by remember { mutableIntStateOf(initialIndex.coerceIn(0, (labels.size - 1).coerceAtLeast(0))) }
    WheelSheet(title = title, subtitle = subtitle, onDismiss = onDismiss) {
        WheelPicker(
            labels = labels,
            selectedIndex = index,
            modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
            visibleCount = wheelRows(),
            itemHeight = 48.dp,
            description = title,
            onChange = { index = it },
            onSettled = { index = it },
            onCenterTap = { onConfirm(index) }
        )
        if (hint != null) {
            Text(
                hint,
                style = MaterialTheme.typography.bodySmall,
                color = Muted,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth().padding(top = 6.dp)
            )
        }
        Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            SecondaryButton("Cancel", modifier = Modifier.weight(1f), onClick = onDismiss)
            PrimaryButton(confirmText, modifier = Modifier.weight(1f), onClick = { onConfirm(index) })
        }
    }
}

/** Which of the two times the wheels are changing. */
enum class TimeField { START, END }

/**
 * NEW (2.18): the time wheels - minutes, seconds and tenths of a second - for the START and the END of a background audio.
 *
 * Two boxes at the top show the start and the end; the one that is lit is the one the wheels change (tap the other one
 * to switch). "Scene start / Scene end / Video end" roll the wheels to those exact moments. The end is optional: leave it
 * "not set yet" and set it later from the scene where the audio should stop. The button stays off while the times can not
 * be used (end before start, or past the end of the video) and says why.
 *
 * @param totalSec the length of the whole video
 * @param scene the scene that was pressed (its start and end are the shortcuts)
 */
@Composable
fun BgTimeSheet(
    title: String,
    subtitle: String?,
    totalSec: Double,
    scene: SceneSpan,
    initialStartSec: Double,
    initialEndSec: Double?,
    initialField: TimeField,
    confirmText: String,
    onConfirm: (startSec: Double, endSec: Double?) -> Unit,
    onDismiss: () -> Unit
) {
    var start by remember { mutableDoubleStateOf(initialStartSec) }
    var end by remember { mutableStateOf(initialEndSec) }
    var field by remember { mutableStateOf(initialField) }
    // bumped whenever the CODE (not a finger) changes the time, so the wheels roll to it
    var token by remember { mutableIntStateOf(0) }

    val isStart = field == TimeField.START
    val shown = if (isStart) start else (end ?: BgSlots.suggestEnd(start, scene, totalSec))
    val parts = BgSlots.parts(shown)
    val setShown: (Double) -> Unit = { v -> if (isStart) start = v else end = v }

    val minuteLabels = remember(totalSec) { (0..BgSlots.maxMinutes(totalSec)).map { it.toString() } }
    val secondLabels = remember { (0..59).map { it.toString().padStart(2, '0') } }
    val tenthLabels = remember { (0..9).map { it.toString() } }

    // After the wheels stop: keep the time inside the video (the wheels then roll back to it).
    val keepInside: () -> Unit = {
        val fixed = BgSlots.clampToVideo(shown, totalSec, isStart)
        if (abs(fixed - shown) > 1e-6) {
            setShown(fixed)
            token++
        }
    }

    val problem = BgSlots.checkTimes(start, end, totalSec)

    WheelSheet(title = title, subtitle = subtitle, onDismiss = onDismiss) {
        Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            TimeFieldBox("Start", BgSlots.clock(start), isStart, Modifier.weight(1f)) {
                field = TimeField.START
                token++
            }
            TimeFieldBox("End", end?.let { BgSlots.clock(it) } ?: "not set yet", !isStart, Modifier.weight(1f)) {
                if (end == null) end = BgSlots.suggestEnd(start, scene, totalSec)
                field = TimeField.END
                token++
            }
        }

        Row(
            Modifier.fillMaxWidth().padding(top = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            val rows = wheelRows()
            CaptionedWheel("min", minuteLabels, parts.minutes, token, rows, 1f,
                onChange = { setShown(BgSlots.fromParts(it, parts.seconds, parts.tenths)) }, onSettled = keepInside)
            WheelSeparator(":")
            CaptionedWheel("sec", secondLabels, parts.seconds, token, rows, 1f,
                onChange = { setShown(BgSlots.fromParts(parts.minutes, it, parts.tenths)) }, onSettled = keepInside)
            WheelSeparator(".")
            CaptionedWheel("1/10", tenthLabels, parts.tenths, token, rows, 0.8f,
                onChange = { setShown(BgSlots.fromParts(parts.minutes, parts.seconds, it)) }, onSettled = keepInside)
        }

        // exact moments to roll to
        Row(
            Modifier.fillMaxWidth().padding(top = 8.dp).horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val jump: (Double) -> Unit = { v ->
                setShown(BgSlots.clampToVideo(v, totalSec, isStart))
                token++
            }
            TimeChip("Scene start · ${BgSlots.clockShort(scene.startSec)}") { jump(scene.startSec) }
            TimeChip("Scene end · ${BgSlots.clockShort(scene.endSec)}") { jump(scene.endSec) }
            if (!isStart) TimeChip("Video end · ${BgSlots.clockShort(totalSec)}") { jump(totalSec) }
            if (!isStart && end != null) {
                TextButton(onClick = {
                    end = null
                    field = TimeField.START
                    token++
                }) { Text("No end", color = Muted) }
            }
        }

        val note = when {
            problem != null -> problem.message + when (problem) {
                TimeProblem.END_NOT_AFTER_START -> " (it starts at ${BgSlots.clockShort(start)})"
                TimeProblem.END_OUT_OF_VIDEO,
                TimeProblem.START_OUT_OF_VIDEO -> " (the video is ${BgSlots.clockShort(totalSec)} long)"
            }
            end != null -> "Plays for ${BgSlots.clockShort(end!! - start)}. A longer file is cut to fit, a shorter one repeats."
            else -> "No end yet - you can set it later: press and hold the scene where it should stop."
        }
        Text(
            note,
            style = MaterialTheme.typography.bodySmall,
            color = if (problem != null) Red else Muted,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
        )

        Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            SecondaryButton("Cancel", modifier = Modifier.weight(1f), onClick = onDismiss)
            PrimaryButton(confirmText, modifier = Modifier.weight(1f), enabled = problem == null, onClick = { onConfirm(start, end) })
        }
    }
}

@Composable
private fun RowScope.CaptionedWheel(
    caption: String,
    labels: List<String>,
    index: Int,
    token: Int,
    rows: Int,
    weight: Float,
    onChange: (Int) -> Unit,
    onSettled: () -> Unit
) {
    Column(Modifier.weight(weight), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(caption, style = MaterialTheme.typography.labelSmall, color = Muted)
        WheelPicker(
            labels = labels,
            selectedIndex = index,
            modifier = Modifier.fillMaxWidth(),
            syncToken = token,
            visibleCount = rows,
            description = caption,
            onChange = onChange,
            onSettled = { onSettled() }
        )
    }
}

@Composable
private fun WheelSeparator(text: String) {
    // lifted a little so it lines up with the middle row (the captions above the wheels push the row down)
    Text(text, style = MaterialTheme.typography.titleLarge, color = TextMain, modifier = Modifier.padding(horizontal = 2.dp).padding(bottom = 16.dp))
}

@Composable
private fun TimeFieldBox(label: String, value: String, active: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val accent = Accent
    val shape = RoundedCornerShape(12.dp)
    Column(
        modifier
            .clip(shape)
            .background(if (active) accent.copy(alpha = 0.14f) else Surface)
            .border(if (active) 2.dp else 1.dp, if (active) accent else Outline, shape)
            .semantics { selected = active }
            .clickable(role = Role.Button, onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 8.dp)
    ) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = if (active) accent else Muted)
        Text(value, style = MaterialTheme.typography.titleMedium, color = TextMain, maxLines = 1)
    }
}

@Composable
private fun TimeChip(text: String, onClick: () -> Unit) {
    val shape = RoundedCornerShape(20.dp)
    Box(
        Modifier
            .heightIn(min = 40.dp)
            .clip(shape)
            .border(1.dp, Outline, shape)
            .clickable(role = Role.Button, onClick = onClick)
            .padding(horizontal = 12.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, style = MaterialTheme.typography.labelMedium, color = TextMain, maxLines = 1)
    }
}
