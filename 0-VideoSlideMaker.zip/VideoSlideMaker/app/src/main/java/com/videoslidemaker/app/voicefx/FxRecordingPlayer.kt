package com.videoslidemaker.app.voicefx

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import com.videoslidemaker.app.align.PlaybackSpeed
import com.videoslidemaker.app.export.StreamingPcmConverter
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.math.max

/**
 * Plays the user's ORIGINAL recording through the voice changer, live, while the Preview runs.
 * (PreviewRecordingPlayer plays the untouched file with MediaPlayer, which cannot change the sound;
 * this one decodes the file itself, runs it through [VoiceFxPcmStream] and plays it with AudioTrack.)
 *
 * Same contract as PreviewRecordingPlayer: [playFrom] starts at a point on the recording's own clock,
 * [positionMs] is where the sound really is (the Preview uses it as the master clock), [pause] stops.
 * Pausing closes the session; the next [playFrom] opens it again at the new position.
 *
 * Decoding, processing and playing happen on one background thread. Pass [VoiceFxSettings] that are
 * not active to play the recording untouched through the same path (used to compare "before / after").
 */
class FxRecordingPlayer(private val context: Context) {
    private val lock = Any()
    private var session: Session? = null

    /**
     * Returns null when playing, or a short plain-language problem. [endMs] stops the sound on its
     * own at that point on the recording's clock (used for the short "hear a sample" playback).
     * [speed] (1 = normal) plays it faster or slower without changing the pitch - see [appliedSpeed].
     */
    suspend fun playFrom(
        uri: Uri,
        startMs: Long,
        fx: VoiceFxSettings,
        endMs: Long = Long.MAX_VALUE,
        speed: Float = 1f
    ): String? {
        val s = Session(context, uri, startMs, endMs, fx, speed)
        synchronized(lock) {
            session?.stop()
            session = s
        }
        s.start()
        val result = try {
            withTimeoutOrNull(START_TIMEOUT_MS) { s.started.await() }
        } catch (e: CancellationException) {
            s.stop()
            throw e
        }
        if (result == null) {
            s.stop()
            return "Couldn't play your recording. Choose it again on the Script screen."
        }
        return if (result.isEmpty()) null else result
    }

    fun pause() {
        synchronized(lock) {
            session?.stop()
            session = null
        }
    }

    /** Position in the recording in ms, or -1 when nothing is playing. */
    fun positionMs(): Long = synchronized(lock) { session }?.positionMs() ?: -1L

    /**
     * NEW (2.8): the speed the current playback really runs at - the one asked for, or the nearest one this
     * phone accepts. Only meaningful once [playFrom] has returned.
     */
    val appliedSpeed: Float
        get() = synchronized(lock) { session }?.appliedSpeed ?: 1f

    fun release() = pause()

    private class Session(
        private val context: Context,
        private val uri: Uri,
        private val startMs: Long,
        private val endMs: Long,
        private val fx: VoiceFxSettings,
        private val speed: Float
    ) {
        /** "" = playing; anything else = the problem to show. */
        val started = CompletableDeferred<String>()

        /** The speed the sound really runs at (set before [started] completes). */
        @Volatile var appliedSpeed = 1f

        @Volatile private var stopped = false
        @Volatile private var finished = false
        @Volatile private var playing = false
        @Volatile private var track: AudioTrack? = null
        @Volatile private var baseMs = startMs
        @Volatile private var framesWritten = 0L

        fun start() {
            val t = Thread({ playLoop() }, "FxRecordingPlayer")
            t.isDaemon = true
            t.start()
        }

        fun stop() {
            stopped = true
            val t = track
            if (t != null) {
                runCatching { t.pause() }
                runCatching { t.flush() }
            }
            started.complete("")
        }

        fun positionMs(): Long {
            val t = track ?: return -1L
            if (!playing || stopped) return -1L
            val head = try {
                t.playbackHeadPosition.toLong() and 0xFFFFFFFFL
            } catch (_: Exception) {
                return -1L
            }
            if (finished && head >= framesWritten) return -1L
            return baseMs + head * 1000L / SAMPLE_RATE
        }

        private fun playLoop() {
            // Decoding + the voice changer run live on this thread. At normal priority a busy phone can make it
            // late, the speaker runs dry for a moment and you hear crackle / fuzz. Audio priority prevents that.
            runCatching { android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_URGENT_AUDIO) }
            var extractor: MediaExtractor? = null
            var decoder: MediaCodec? = null
            var audioTrack: AudioTrack? = null
            try {
                val ex = MediaExtractor()
                extractor = ex
                val pfd = context.contentResolver.openFileDescriptor(uri, "r")
                if (pfd == null) {
                    started.complete("Couldn't open your recording. Choose it again on the Script screen.")
                    return
                }
                pfd.use { ex.setDataSource(it.fileDescriptor) }

                var trackIndex = -1
                var found: MediaFormat? = null
                for (i in 0 until ex.trackCount) {
                    val f = ex.getTrackFormat(i)
                    val m = f.getString(MediaFormat.KEY_MIME) ?: continue
                    if (m.startsWith("audio/")) {
                        trackIndex = i
                        found = f
                        break
                    }
                }
                val format = found
                if (trackIndex < 0 || format == null) {
                    started.complete("There is no sound in this file.")
                    return
                }
                ex.selectTrack(trackIndex)
                val mime = format.getString(MediaFormat.KEY_MIME) ?: return
                var rate = format.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                var channels = format.getInteger(MediaFormat.KEY_CHANNEL_COUNT)

                val startUs = startMs * 1000L
                ex.seekTo(startUs, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)
                val firstSampleUs = ex.sampleTime
                if (firstSampleUs < 0) {
                    started.complete("Your recording ends before this point, so there is no original sound here.")
                    return
                }
                // The seek lands on or before the wanted point; the sound in between is skipped below.
                var skipBytes = 0L
                if (startUs > firstSampleUs) {
                    skipBytes = ((startUs - firstSampleUs) * SAMPLE_RATE / 1_000_000L) * FRAME_BYTES
                } else {
                    baseMs = firstSampleUs / 1000L
                }
                val maxBytes = if (endMs == Long.MAX_VALUE) {
                    Long.MAX_VALUE
                } else {
                    ((endMs - baseMs).coerceAtLeast(0L) * SAMPLE_RATE / 1000L) * FRAME_BYTES
                }

                val codec = MediaCodec.createDecoderByType(mime)
                decoder = codec
                codec.configure(format, null, null, 0)
                codec.start()

                val minBuf = AudioTrack.getMinBufferSize(SAMPLE_RATE, AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_16BIT)
                val bufferBytes = max(minBuf * 2, SAMPLE_RATE * FRAME_BYTES) // at least one second of cushion against crackle
                val at = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(SAMPLE_RATE)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
                            .build()
                    )
                    .setBufferSizeInBytes(bufferBytes)
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .build()
                audioTrack = at
                track = at
                // faster / slower without changing the pitch; at normal speed nothing is touched
                appliedSpeed = if (speed == 1f) 1f else PlaybackSpeed.setOn(at, speed)

                var converter = StreamingPcmConverter(rate, channels, SAMPLE_RATE, 2)
                val fxStream: VoiceFxPcmStream? = if (fx.isActive) VoiceFxPcmStream(fx, SAMPLE_RATE, 2, 0) else null

                val info = MediaCodec.BufferInfo()
                var inputDone = false
                var outputDone = false
                var writtenBytes = 0L
                var playStarted = false
                val startThresholdBytes = (SAMPLE_RATE * 3 / 10) * FRAME_BYTES // 0.3 s buffered before the sound starts

                // Writes bytes to the track (blocking), never past [maxBytes]; returns false once the end is reached.
                fun emit(data: ByteArray): Boolean {
                    if (data.isEmpty()) return true
                    val room = maxBytes - writtenBytes
                    val n = if (room < data.size) room.toInt().coerceAtLeast(0) else data.size
                    var off = 0
                    while (off < n && !stopped) {
                        val w = at.write(data, off, n - off)
                        if (w < 0) throw IllegalStateException("AudioTrack write failed ($w)")
                        if (w == 0) Thread.sleep(5)
                        off += w
                    }
                    writtenBytes += off
                    framesWritten = writtenBytes / FRAME_BYTES
                    if (!playStarted && writtenBytes >= startThresholdBytes && !stopped) {
                        at.play()
                        playing = true
                        playStarted = true
                        started.complete("")
                    }
                    return off == data.size
                }

                var reachedEnd = false
                while (!outputDone && !stopped && !reachedEnd) {
                    if (!inputDone) {
                        val inputIndex = codec.dequeueInputBuffer(10_000)
                        if (inputIndex >= 0) {
                            val buffer = codec.getInputBuffer(inputIndex)!!
                            val sampleSize = ex.readSampleData(buffer, 0)
                            if (sampleSize < 0) {
                                codec.queueInputBuffer(inputIndex, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                                inputDone = true
                            } else {
                                codec.queueInputBuffer(inputIndex, 0, sampleSize, ex.sampleTime, 0)
                                ex.advance()
                            }
                        }
                    }

                    val outputIndex = codec.dequeueOutputBuffer(info, 10_000)
                    if (outputIndex >= 0) {
                        if (info.size > 0) {
                            val outBuffer = codec.getOutputBuffer(outputIndex)!!
                            outBuffer.position(info.offset)
                            outBuffer.limit(info.offset + info.size)
                            val chunk = ByteArray(info.size)
                            outBuffer.get(chunk)
                            var pcm = converter.convert(chunk)
                            if (skipBytes > 0L) {
                                if (pcm.size <= skipBytes) {
                                    skipBytes -= pcm.size
                                    pcm = ByteArray(0)
                                } else {
                                    pcm = pcm.copyOfRange(skipBytes.toInt(), pcm.size)
                                    skipBytes = 0L
                                }
                            }
                            if (pcm.isNotEmpty()) {
                                val processed = if (fxStream != null) fxStream.process(pcm) else pcm
                                if (!emit(processed)) reachedEnd = true
                            }
                        }
                        codec.releaseOutputBuffer(outputIndex, false)
                        if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outputDone = true
                    } else if (outputIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                        // trust what the decoder really outputs over what the file header says
                        val outFormat = codec.outputFormat
                        val newRate = if (outFormat.containsKey(MediaFormat.KEY_SAMPLE_RATE)) outFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE) else rate
                        val newChannels = if (outFormat.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) outFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT) else channels
                        if (newRate != rate || newChannels != channels) {
                            rate = newRate
                            channels = newChannels
                            converter = StreamingPcmConverter(rate, channels, SAMPLE_RATE, 2)
                        }
                    }
                }

                // the last bit still inside the filters, and the echo / reverb tail
                if (fxStream != null && !stopped && !reachedEnd) {
                    val tailFrames = (fx.tailSeconds * SAMPLE_RATE).toInt()
                    emit(fxStream.finish(tailFrames))
                }
                if (!playStarted && !stopped) {
                    at.play() // very short sound: it never reached the "start" threshold
                    playing = true
                    playStarted = true
                    started.complete("")
                }
                finished = true

                // let what is buffered finish playing before the track is released
                val drainUntil = System.currentTimeMillis() + bufferBytes / FRAME_BYTES * 1000L / SAMPLE_RATE + 500L
                while (!stopped && System.currentTimeMillis() < drainUntil) {
                    val head = at.playbackHeadPosition.toLong() and 0xFFFFFFFFL
                    if (head >= framesWritten) break
                    Thread.sleep(20)
                }
            } catch (e: Exception) {
                started.complete("Couldn't play your recording. Choose it again on the Script screen.")
            } finally {
                finished = true
                track = null
                runCatching { audioTrack?.stop() }
                runCatching { audioTrack?.release() }
                runCatching { decoder?.stop() }
                runCatching { decoder?.release() }
                runCatching { extractor?.release() }
                started.complete("")
            }
        }
    }

    private companion object {
        const val SAMPLE_RATE = 44100
        const val FRAME_BYTES = 4 // 16-bit stereo
        const val START_TIMEOUT_MS = 6000L
    }
}
