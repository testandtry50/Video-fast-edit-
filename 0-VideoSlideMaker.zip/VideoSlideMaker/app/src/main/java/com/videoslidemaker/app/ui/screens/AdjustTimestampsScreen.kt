package com.videoslidemaker.app.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.videoslidemaker.app.adjust.AdjustController
import com.videoslidemaker.app.adjust.AdjustFormat
import com.videoslidemaker.app.adjust.AdjustMode
import com.videoslidemaker.app.adjust.AdjustUi
import com.videoslidemaker.app.adjust.AdjustView
import com.videoslidemaker.app.adjust.Outcome
import com.videoslidemaker.app.adjust.PreviewFilter
import com.videoslidemaker.app.adjust.PreviewLine
import com.videoslidemaker.app.adjust.SelectedMethod
import com.videoslidemaker.app.adjust.UndoAction
import com.videoslidemaker.app.align.AlignmentFormat
import com.videoslidemaker.app.align.AlignmentStatus
import com.videoslidemaker.app.model.UiState
import com.videoslidemaker.app.ui.components.AlertBox
import com.videoslidemaker.app.ui.components.AlertStyle
import com.videoslidemaker.app.ui.components.AppProgressBar
import com.videoslidemaker.app.ui.components.PrimaryButton
import com.videoslidemaker.app.ui.components.SecondaryButton
import com.videoslidemaker.app.ui.components.SectionCard
import com.videoslidemaker.app.ui.theme.Accent
import com.videoslidemaker.app.ui.theme.Bg
import com.videoslidemaker.app.ui.theme.BorderColor
import com.videoslidemaker.app.ui.theme.CardBg
import com.videoslidemaker.app.ui.theme.Green
import com.videoslidemaker.app.ui.theme.Muted
import com.videoslidemaker.app.ui.theme.OnAccent
import com.videoslidemaker.app.ui.theme.Outline
import com.videoslidemaker.app.ui.theme.Red
import com.videoslidemaker.app.ui.theme.Surface
import com.videoslidemaker.app.ui.theme.TextMain
import com.videoslidemaker.app.ui.theme.Yellow
import com.videoslidemaker.app.viewmodel.AppViewModel
import java.text.DateFormat
import java.util.Date

// ---------------------------------------------------------------------------------------------------------------
// The card on the Script screen
// ---------------------------------------------------------------------------------------------------------------

@Composable
fun AdjustCard(state: UiState, viewModel: AppViewModel) {
    val adjusted = remember(state.slides) { AdjustController.toLines(state.slides).count { it.isAdjusted } }
    SectionCard(title = "Adjust timestamps", modifier = Modifier.padding(bottom = 12.dp)) {
        Text(
            "Move the whole transcript, synchronize it with the recording, adjust only some lines, apply the corrections that were " +
                "found, or take them back. You always see a preview first (BEFORE, AFTER and the difference), and your original " +
                "timestamps are always kept, so nothing is ever lost.",
            style = MaterialTheme.typography.bodySmall,
            color = Muted,
            modifier = Modifier.padding(bottom = 10.dp)
        )
        if (adjusted > 0) {
            Text(
                if (adjusted == 1) "1 timestamp is currently adjusted. Its original is kept." else "$adjusted timestamps are currently adjusted. Their originals are kept.",
                style = MaterialTheme.typography.bodySmall,
                color = Accent,
                modifier = Modifier.padding(bottom = 8.dp)
            )
        }
        PrimaryButton(text = "Adjust timestamps", enabled = state.slides.isNotEmpty(), onClick = { viewModel.adjust.open() })
        if (state.slides.isEmpty()) {
            Text("Load a script first.", style = MaterialTheme.typography.bodySmall, color = Muted, modifier = Modifier.padding(top = 6.dp))
        }
    }
}

// ---------------------------------------------------------------------------------------------------------------
// The screen
// ---------------------------------------------------------------------------------------------------------------

@Composable
fun AdjustTimestampsScreen(state: UiState, viewModel: AppViewModel, onPickRecording: () -> Unit) {
    val controller = viewModel.adjust
    val ui by controller.ui.collectAsState()
    BackHandler { if (ui.mode != null) controller.backToMenu() else controller.close() }
    val view = remember(state.slides, state.alignment.items, state.adjustLog, ui) { AdjustController.view(state, ui) }

    Column(Modifier.fillMaxSize().background(Bg)) {
        Row(
            Modifier.fillMaxWidth().padding(start = 4.dp, end = 12.dp, top = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(onClick = { if (ui.mode != null) controller.backToMenu() else controller.close() }) {
                Text(if (ui.mode != null) "← Options" else "← Back", color = Accent)
            }
            Text(
                modeTitle(ui.mode) ?: "Adjust timestamps",
                style = MaterialTheme.typography.titleMedium,
                color = TextMain,
                fontWeight = FontWeight.Bold,
                maxLines = 2
            )
        }
        ui.notice?.let { AlertBox(it, AlertStyle.SUCCESS, Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) }

        if (ui.mode == null) {
            MenuContent(state, view, controller::chooseMode, Modifier.weight(1f))
        } else {
            Workspace(state, ui, view, viewModel, onPickRecording, Modifier.weight(1f))
        }
    }
}

private fun modeTitle(mode: AdjustMode?): String? = when (mode) {
    null -> null
    AdjustMode.ENTIRE_TRANSCRIPT -> "Adjust entire transcript"
    AdjustMode.AUTO_SYNC -> "Automatically synchronize entire transcript"
    AdjustMode.SELECTED -> "Adjust selected timestamps"
    AdjustMode.DETECTED -> "Apply detected corrections"
    AdjustMode.UNDO -> "Undo corrections"
}

// ---------------------------------------------------------------------------------------------------------------
// The menu: the five options
// ---------------------------------------------------------------------------------------------------------------

@Composable
private fun MenuContent(state: UiState, view: AdjustView, onChoose: (AdjustMode) -> Unit, modifier: Modifier) {
    val hasRecording = state.alignment.recordingUri != null
    val canUndo = state.adjustLog.isNotEmpty() || view.adjustedCount > 0
    val found = state.alignment.items.count { it.detectedMs != null }
    Column(
        modifier.verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        OptionCard(
            "1", "Adjust entire transcript",
            "Move every timestamp earlier or later by the same amount (and optionally stretch the spacing). It moves all lines, or none.",
            true, null
        ) { onChoose(AdjustMode.ENTIRE_TRANSCRIPT) }
        OptionCard(
            "2", "Automatically synchronize entire transcript",
            "Listen to the recording and find where every line is really spoken. You preview the result before anything changes.",
            hasRecording, "Choose the recording first."
        ) { onChoose(AdjustMode.AUTO_SYNC) }
        OptionCard(
            "3", "Adjust selected timestamps",
            "Tick some lines and move them by an amount, or give one line an exact time.",
            true, null
        ) { onChoose(AdjustMode.SELECTED) }
        OptionCard(
            "4", "Apply detected corrections",
            if (found > 0) "The last analysis found times for $found lines. Preview and apply one, some or all high-confidence corrections."
            else "Preview and apply the corrections an analysis found. (No analysis has been run yet; you can start one there.)",
            hasRecording, "Choose the recording first."
        ) { onChoose(AdjustMode.DETECTED) }
        OptionCard(
            "5", "Undo corrections",
            "Take back the last adjustment, or put the original timestamps back for every line or only some.",
            canUndo, "Nothing has been adjusted yet."
        ) { onChoose(AdjustMode.UNDO) }
        Text(
            "Your original timestamps are always kept. Nothing changes until you have looked at the preview and tapped Apply." +
                (if (view.adjustedCount > 0) " ${view.adjustedCount} line(s) currently have an adjusted timestamp." else ""),
            style = MaterialTheme.typography.bodySmall,
            color = Muted,
            modifier = Modifier.padding(top = 4.dp, bottom = 16.dp)
        )
    }
}

@Composable
private fun OptionCard(number: String, title: String, description: String, enabled: Boolean, disabledReason: String?, onClick: () -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    Row(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(CardBg)
            .border(1.dp, if (enabled) Accent.copy(alpha = 0.6f) else BorderColor, shape)
            .clickable(enabled = enabled, role = Role.Button, onClick = onClick)
            .padding(14.dp),
        verticalAlignment = Alignment.Top
    ) {
        Box(
            Modifier.size(28.dp).clip(RoundedCornerShape(14.dp)).background(if (enabled) Accent else Outline),
            contentAlignment = Alignment.Center
        ) { Text(number, color = if (enabled) OnAccent else Muted, fontWeight = FontWeight.Bold) }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = if (enabled) TextMain else Muted, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyLarge)
            Text(
                if (!enabled && disabledReason != null) "$description\n$disabledReason" else description,
                color = Muted,
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.padding(top = 2.dp)
            )
        }
    }
}

// ---------------------------------------------------------------------------------------------------------------
// The workspace of one option: its form, the preview, and the apply buttons
// ---------------------------------------------------------------------------------------------------------------

@Composable
private fun Workspace(state: UiState, ui: AdjustUi, view: AdjustView, viewModel: AppViewModel, onPickRecording: () -> Unit, modifier: Modifier) {
    val controller = viewModel.adjust
    val mode = ui.mode ?: return
    val selectable = !view.atomic && !(mode == AdjustMode.UNDO && ui.undoAction != UndoAction.RESTORE_SELECTED)
    val rows = remember(view, ui.filter) {
        view.preview.lines.filter {
            when (ui.filter) {
                PreviewFilter.ALL -> true
                PreviewFilter.CHANGES -> it.proposal.afterMs != null && it.proposal.unavailable == null && it.proposal.afterMs != it.proposal.beforeMs
                PreviewFilter.PROBLEMS -> it.outcome == Outcome.REFUSED || it.outcome == Outcome.UNAVAILABLE
            }
        }
    }

    Column(modifier) {
        LazyColumn(
            Modifier.weight(1f),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item(key = "form") {
                Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    when (mode) {
                        AdjustMode.ENTIRE_TRANSCRIPT -> AmountForm(ui, controller, withStretch = true)
                        AdjustMode.SELECTED -> SelectedForm(ui, view, controller)
                        AdjustMode.AUTO_SYNC, AdjustMode.DETECTED -> DetectedForm(state, ui, view, viewModel, onPickRecording)
                        AdjustMode.UNDO -> UndoForm(ui, view, controller)
                    }
                    view.hint?.let { AlertBox(it, AlertStyle.INFO) }
                    view.blocked?.takeIf { it != view.hint }?.let { AlertBox(it, AlertStyle.WARNING) }
                }
            }
            if (view.preview.lines.isNotEmpty()) {
                item(key = "summary") { SummaryAndFilters(ui, view, controller) }
            }
            items(rows, key = { it.proposal.index }) { row ->
                PreviewRow(
                    row = row,
                    selectable = selectable,
                    showAfterWhenUnticked = mode == AdjustMode.AUTO_SYNC || mode == AdjustMode.DETECTED || mode == AdjustMode.UNDO,
                    canApplyOne = !view.atomic,
                    onToggle = { controller.toggleTick(row.proposal.index) },
                    onApplyOne = { controller.applyOne(row.proposal.index) }
                )
            }
        }
        ApplyBar(ui, view, controller)
    }
}

@Composable
private fun SummaryAndFilters(ui: AdjustUi, view: AdjustView, controller: AdjustController) {
    val p = view.preview
    val willChange = p.willApplyCount
    val left = p.refusedCount
    val cannot = p.lines.count { it.outcome == Outcome.UNAVAILABLE }
    Column(Modifier.fillMaxWidth()) {
        Text(
            buildList {
                add("$willChange will change")
                if (left > 0) add("$left left alone (would break the order)")
                if (cannot > 0) add("$cannot can't be adjusted")
            }.joinToString("  ·  "),
            color = TextMain,
            style = MaterialTheme.typography.bodySmall,
            fontWeight = FontWeight.Medium
        )
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            for ((f, label) in listOf(PreviewFilter.ALL to "All", PreviewFilter.CHANGES to "With a new time", PreviewFilter.PROBLEMS to "Problems")) {
                Chip(label, ui.filter == f) { controller.setFilter(f) }
            }
        }
    }
}

// ---------------------------------------------------------------------------------------------------------------
// Forms
// ---------------------------------------------------------------------------------------------------------------

@Composable
private fun AmountForm(ui: AdjustUi, controller: AdjustController, withStretch: Boolean) {
    Text("Move by", color = Muted, style = MaterialTheme.typography.bodySmall)
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Field(ui.offsetText, ui.textVersion, controller::setOffsetText, "1.43", KeyboardType.Decimal, Modifier.weight(1f))
        Text("seconds", color = TextMain, style = MaterialTheme.typography.bodyMedium)
    }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Chip("Later", !ui.earlier) { controller.setEarlier(false) }
        Chip("Earlier", ui.earlier) { controller.setEarlier(true) }
    }
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        for ((label, d) in listOf("−1 s" to -1000L, "−0.1 s" to -100L, "+0.1 s" to 100L, "+1 s" to 1000L)) Chip(label, false) { controller.nudge(d) }
    }
    Text(
        "You can also type a sign: -0.25 is earlier, +0.25 is later. Milliseconds are kept: 1.43 is 1 s 430 ms.",
        color = Muted,
        style = MaterialTheme.typography.bodySmall
    )
    if (withStretch) {
        Text("Stretch (optional)", color = Muted, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 4.dp))
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Field(ui.stretchText, ui.textVersion, controller::setStretchText, "0", KeyboardType.Text, Modifier.weight(1f))
            Text("%", color = TextMain, style = MaterialTheme.typography.bodyMedium)
        }
        Text(
            "For a recording that was sped up or slowed down: 0.1 makes the transcript 0.1% longer, -0.1 shorter. The first line stays where it is.",
            color = Muted,
            style = MaterialTheme.typography.bodySmall
        )
    }
}

@Composable
private fun SelectedForm(ui: AdjustUi, view: AdjustView, controller: AdjustController) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Chip("Move by an amount", ui.method == SelectedMethod.SHIFT) { controller.setMethod(SelectedMethod.SHIFT) }
        Chip("Set an exact time", ui.method == SelectedMethod.EXACT) { controller.setMethod(SelectedMethod.EXACT) }
    }
    if (ui.method == SelectedMethod.SHIFT) {
        AmountForm(ui, controller, withStretch = false)
    } else {
        Text("New time for the ticked line", color = Muted, style = MaterialTheme.typography.bodySmall)
        Field(ui.exactText, ui.textVersion, controller::setExactText, "00:01:25.430", KeyboardType.Text, Modifier.fillMaxWidth())
    }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Chip("Tick all", false) { controller.tickAll() }
        Chip("Tick none", false) { controller.tickNone() }
    }
    Text("${view.ticked.size} line(s) ticked. Tap a line below to tick it.", color = Muted, style = MaterialTheme.typography.bodySmall)
}

@Composable
private fun DetectedForm(state: UiState, ui: AdjustUi, view: AdjustView, viewModel: AppViewModel, onPickRecording: () -> Unit) {
    val controller = viewModel.adjust
    val a = state.alignment
    val hasRecording = a.recordingUri != null
    when {
        a.running -> {
            Text("${a.stage.ifEmpty { "Analysing the recording…" }} ${a.percent}%", color = TextMain, style = MaterialTheme.typography.bodySmall)
            AppProgressBar(a.percent / 100f, Modifier.padding(vertical = 6.dp))
            SecondaryButton(text = "Stop", onClick = { viewModel.cancelAlignment() })
        }
        !hasRecording -> {
            AlertBox("Choose the recording to analyse it.", AlertStyle.INFO)
            SecondaryButton(text = "Choose the recording", onClick = onPickRecording)
        }
        a.items.isEmpty() -> {
            AlertBox(
                if (ui.mode == AdjustMode.AUTO_SYNC) "The recording is listened to, and the detected times are shown here for you to check. Nothing is applied automatically."
                else "No analysis has been run yet.",
                AlertStyle.INFO
            )
            PrimaryButton(text = "Analyse the recording", onClick = { controller.analyseNow() })
        }
        else -> {
            val high = view.highConfidence.size
            val review = a.items.count { it.status == AlignmentStatus.NEEDS_REVIEW || it.status == AlignmentStatus.ESTIMATED }
            val cannot = a.items.count { it.status == AlignmentStatus.CANNOT_ALIGN }
            Text(
                "$high high-confidence correction(s), $review that need review, $cannot that can't be aligned. " +
                    "Only the high-confidence ones are ticked for you; tick others if you want to apply them.",
                color = TextMain,
                style = MaterialTheme.typography.bodySmall
            )
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Chip("Tick high-confidence ($high)", false) { controller.tickHighConfidence() }
                Chip("Tick all that change", false) { controller.tickApplicable() }
                Chip("Tick none", false) { controller.tickNone() }
            }
            SecondaryButton(text = "Analyse again", onClick = { controller.analyseNow() })
        }
    }
}

@Composable
private fun UndoForm(ui: AdjustUi, view: AdjustView, controller: AdjustController) {
    val last = view.lastBatch
    ChoiceRow(
        selected = ui.undoAction == UndoAction.LAST_ADJUSTMENT,
        enabled = last != null,
        title = "Undo the last adjustment",
        subtitle = if (last != null) "${last.label}  ·  ${last.changes.size} line(s)  ·  ${DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(Date(last.atEpochMs))}"
        else "There is no adjustment to undo."
    ) { controller.setUndoAction(UndoAction.LAST_ADJUSTMENT) }
    ChoiceRow(
        selected = ui.undoAction == UndoAction.RESTORE_ALL,
        enabled = view.adjustedCount > 0,
        title = "Restore the original timestamps",
        subtitle = if (view.adjustedCount > 0) "Put all ${view.adjustedCount} adjusted line(s) back to the time the script gave them." else "Every line already has its original timestamp."
    ) { controller.setUndoAction(UndoAction.RESTORE_ALL) }
    ChoiceRow(
        selected = ui.undoAction == UndoAction.RESTORE_SELECTED,
        enabled = view.adjustedCount > 0,
        title = "Restore only the lines I pick",
        subtitle = "Tick the lines below to put just those back."
    ) { controller.setUndoAction(UndoAction.RESTORE_SELECTED) }
    if (ui.undoAction == UndoAction.RESTORE_SELECTED && view.adjustedCount > 0) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Chip("Tick all", false) { controller.tickApplicable() }
            Chip("Tick none", false) { controller.tickNone() }
        }
    }
}

// ---------------------------------------------------------------------------------------------------------------
// One previewed line: BEFORE, AFTER, Difference
// ---------------------------------------------------------------------------------------------------------------

@Composable
private fun PreviewRow(
    row: PreviewLine,
    selectable: Boolean,
    showAfterWhenUnticked: Boolean,
    canApplyOne: Boolean,
    onToggle: () -> Unit,
    onApplyOne: () -> Unit
) {
    val p = row.proposal
    val after = p.afterMs
    val outcomeColor = when (row.outcome) {
        Outcome.WILL_APPLY -> Green
        Outcome.REFUSED -> Yellow
        Outcome.UNAVAILABLE -> Red
        else -> Muted
    }
    val shape = RoundedCornerShape(14.dp)
    val showAfter = after != null && p.unavailable == null && (row.outcome != Outcome.NOT_SELECTED || showAfterWhenUnticked)
    val changes = after != null && after != p.beforeMs && p.unavailable == null
    Column(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(CardBg)
            .border(1.dp, if (row.outcome == Outcome.WILL_APPLY) Green.copy(alpha = 0.6f) else BorderColor, shape)
            .padding(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (selectable) {
                TickBox(row.checked, enabled = changes || row.checked, onChange = onToggle)
                Spacer(Modifier.width(8.dp))
            }
            Text("Line ${p.index + 1}", color = TextMain, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            val c = p.confidence
            if (c != null && p.status != null && p.status != AlignmentStatus.CANNOT_ALIGN && after != null) {
                Text(
                    "${AlignmentFormat.percent(c)}% sure" + (if (p.status == AlignmentStatus.ESTIMATED) " (estimate)" else ""),
                    color = Muted,
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
        Text("BEFORE", color = Muted, style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(top = 8.dp))
        Text(
            AdjustFormat.scriptLine(p.beforeMs, p.text),
            color = TextMain,
            style = MaterialTheme.typography.bodyMedium,
            fontFamily = FontFamily.Monospace,
            maxLines = 3,
            overflow = TextOverflow.Ellipsis
        )
        if (showAfter && after != null) {
            Text("AFTER", color = Muted, style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(top = 6.dp))
            Text(
                AdjustFormat.scriptLine(after, p.text),
                color = if (changes) Green else Muted,
                style = MaterialTheme.typography.bodyMedium,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                maxLines = 3,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                "Difference: " + AdjustFormat.difference(after - p.beforeMs),
                color = TextMain,
                style = MaterialTheme.typography.bodySmall,
                fontWeight = FontWeight.Medium,
                modifier = Modifier.padding(top = 2.dp)
            )
        }
        val note = row.reason ?: p.note
        if (row.outcome == Outcome.NO_CHANGE) {
            Text("It already has this time.", color = Muted, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 4.dp))
        } else if (note != null && (row.outcome == Outcome.REFUSED || row.outcome == Outcome.UNAVAILABLE || p.note != null)) {
            Text(
                (if (row.outcome == Outcome.REFUSED) "Left alone: " else "") + note,
                color = if (row.outcome == Outcome.NOT_SELECTED) Muted else outcomeColor,
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.padding(top = 4.dp)
            )
        }
        if (canApplyOne && changes && row.outcome != Outcome.REFUSED) {
            SecondaryButton(text = "Apply this one", onClick = onApplyOne, modifier = Modifier.padding(top = 8.dp))
        }
    }
}

// ---------------------------------------------------------------------------------------------------------------
// The apply bar
// ---------------------------------------------------------------------------------------------------------------

@Composable
private fun ApplyBar(ui: AdjustUi, view: AdjustView, controller: AdjustController) {
    val mode = ui.mode ?: return
    val n = view.preview.willApplyCount
    Column(
        Modifier.fillMaxWidth().background(CardBg).border(1.dp, BorderColor).padding(horizontal = 16.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        when (mode) {
            AdjustMode.ENTIRE_TRANSCRIPT ->
                PrimaryButton(text = "Apply to all ${view.lines.size} lines", enabled = view.canApply, onClick = { controller.applyTicked() })
            AdjustMode.SELECTED ->
                PrimaryButton(text = "Apply to $n selected line(s)", enabled = view.canApply, onClick = { controller.applyTicked() })
            AdjustMode.AUTO_SYNC, AdjustMode.DETECTED -> {
                PrimaryButton(text = "Apply selected ($n)", enabled = view.canApply, onClick = { controller.applyTicked() })
                val hc = view.preview.lines.count { it.proposal.index in view.highConfidence }
                SecondaryButton(
                    text = "Apply all high-confidence corrections ($hc)",
                    enabled = hc > 0,
                    onClick = { controller.applyHighConfidence() }
                )
            }
            AdjustMode.UNDO ->
                PrimaryButton(
                    text = if (ui.undoAction == UndoAction.LAST_ADJUSTMENT) "Undo the last adjustment ($n line(s))" else "Put back $n timestamp(s)",
                    enabled = view.canApply || (ui.undoAction == UndoAction.LAST_ADJUSTMENT && view.lastBatch != null),
                    onClick = { controller.applyTicked() }
                )
        }
        Text(
            "Your original timestamps are always kept.",
            color = Muted,
            style = MaterialTheme.typography.bodySmall
        )
    }
}

// ---------------------------------------------------------------------------------------------------------------
// Small pieces
// ---------------------------------------------------------------------------------------------------------------

@Composable
private fun Chip(label: String, selected: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(22.dp)
    Box(
        Modifier
            .heightIn(min = 44.dp)
            .clip(shape)
            .background(if (selected) Accent else CardBg)
            .border(1.dp, if (selected) Accent else Outline, shape)
            .selectable(selected = selected, role = Role.RadioButton, onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            (if (selected) "✓ " else "") + label,
            color = if (selected) OnAccent else TextMain,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
            style = MaterialTheme.typography.bodySmall
        )
    }
}

@Composable
private fun ChoiceRow(selected: Boolean, enabled: Boolean, title: String, subtitle: String, onClick: () -> Unit) {
    val shape = RoundedCornerShape(14.dp)
    Column(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(if (selected) Accent.copy(alpha = 0.12f) else CardBg)
            .border(1.dp, if (selected) Accent else Outline, shape)
            .selectable(selected = selected, enabled = enabled, role = Role.RadioButton, onClick = onClick)
            .padding(12.dp)
    ) {
        Text((if (selected) "✓ " else "") + title, color = if (enabled) TextMain else Muted, fontWeight = FontWeight.Bold)
        Text(subtitle, color = Muted, style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
private fun TickBox(checked: Boolean, enabled: Boolean, onChange: () -> Unit) {
    Box(
        Modifier
            .size(44.dp)
            .toggleable(value = checked, enabled = enabled, role = Role.Checkbox, onValueChange = { onChange() }),
        contentAlignment = Alignment.Center
    ) {
        Box(
            Modifier
                .size(24.dp)
                .clip(RoundedCornerShape(6.dp))
                .background(if (checked) Accent else Color.Transparent)
                .border(2.dp, if (enabled) (if (checked) Accent else Outline) else BorderColor, RoundedCornerShape(6.dp)),
            contentAlignment = Alignment.Center
        ) { if (checked) Text("✓", color = OnAccent, fontWeight = FontWeight.Bold) }
    }
}

/**
 * A text field that keeps what is being typed in its OWN state. The controller's copy is only pulled in when [version] changes
 * (the nudge buttons), so a fast edit can never be overwritten by a stale value coming back through the state flow.
 */
@Composable
private fun Field(value: String, version: Int, onChange: (String) -> Unit, placeholder: String, keyboard: KeyboardType, modifier: Modifier) {
    var text by remember(version) { mutableStateOf(TextFieldValue(value, TextRange(value.length))) }
    BasicTextField(
        value = text,
        onValueChange = {
            text = it
            onChange(it.text)
        },
        singleLine = true,
        textStyle = TextStyle(color = TextMain, fontSize = MaterialTheme.typography.bodyLarge.fontSize),
        cursorBrush = SolidColor(Accent),
        keyboardOptions = KeyboardOptions(keyboardType = keyboard),
        modifier = modifier
            .heightIn(min = 48.dp)
            .background(Surface, RoundedCornerShape(10.dp))
            .border(1.dp, Outline, RoundedCornerShape(10.dp))
            .padding(12.dp),
        decorationBox = { inner ->
            Box(contentAlignment = Alignment.CenterStart) {
                if (text.text.isEmpty()) Text(placeholder, color = Muted, style = MaterialTheme.typography.bodyLarge)
                inner()
            }
        }
    )
}
