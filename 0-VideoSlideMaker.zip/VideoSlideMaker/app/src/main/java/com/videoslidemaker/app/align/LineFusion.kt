package com.videoslidemaker.app.align

import com.videoslidemaker.app.check.SpokenWord
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min

/*
 * Fusion of the two independent kinds of evidence about where each script line really starts:
 *
 *   AUDIO  ([TimestampAligner])  speech / pause structure: millisecond-exact onsets, but it cannot tell WHICH sentence it hears.
 *   WORDS  ([LexicalAnchors])    what the recognizer heard, matched to the line's text: knows WHICH sentence, at ANY offset,
 *                                but its word times are only good to about ±50-150 ms.
 *
 * Words choose the line, the audio chooses the millisecond - except inside continuous speech, where the audio has only a
 * weak loudness dip to offer and the words time the line better. All of this was measured on simulated recordings with
 * known ground truth (tools/alignment-reference/README); every number below comes from there.
 *
 * Port of tools/alignment-reference/fusion.py and pipeline.py. Everything here is on the audio engine's internal clock
 * (recording time minus the audio track's start); the recognizer's times are shifted into it once, in [SpokenIndex] and
 * [LineFusion.fuse].
 */

/** What the audio engine decided for one line. */
internal class AudioPick(val tMs: Int, val conf: Double, val kind: Int, val ev: Double)

/** The boundaries the audio engine chose from, ascending by time. kind 0 = start of a speech run, 1 = a dip inside speech. */
internal class BoundarySet(val times: IntArray, val kinds: IntArray, val ev: DoubleArray)

/** Which kind of evidence produced the answer for a line. */
internal enum class FusionClass { AUDIO, BOTH, DISAGREE, DIP, WORDDIP, SNAP, WORDS, NONE }

/** The recognized words, indexed so "how many start in [a, b) and how sure were they" is a binary search. */
internal class SpokenIndex(words: List<SpokenWord>, clockOffsetMs: Long) {
    private val starts: LongArray
    private val prefix: DoubleArray

    init {
        val sorted = words.sortedBy { it.startMs }
        starts = LongArray(sorted.size) { sorted[it].startMs - clockOffsetMs }
        prefix = DoubleArray(sorted.size + 1)
        for (i in sorted.indices) prefix[i + 1] = prefix[i] + sorted[i].conf
    }

    val isEmpty: Boolean get() = starts.isEmpty()

    private fun lowerBound(v: Long): Int {
        var lo = 0
        var hi = starts.size
        while (lo < hi) {
            val mid = (lo + hi) ushr 1
            if (starts[mid] < v) lo = mid + 1 else hi = mid
        }
        return lo
    }

    /** Number of words that start in [a, b). */
    fun count(a: Long, b: Long): Int = max(0, lowerBound(b) - lowerBound(a))

    /** Mean recognizer confidence of the words that start in [a, b) (0 when there are none). */
    fun meanConf(a: Long, b: Long): Double {
        val lo = lowerBound(a)
        val hi = lowerBound(b)
        return if (hi <= lo) 0.0 else (prefix[hi] - prefix[lo]) / (hi - lo)
    }
}

/** One line after fusion, before calibration. [finalMs] is on the internal clock. */
internal class FusedLine(
    val cls: FusionClass,
    val finalMs: Int?,
    val pick: AudioPick?,
    val strongWords: Boolean,
    /** Where the words put the line (internal clock), when they are strong. */
    val wordsMs: Int?,
    val mfrac: Double,
    val anchorConf: Double,
    /** Confident words are heard right here that are not this line's text. */
    val contradiction: Boolean,
    /** |audio − words| when both exist. */
    val gapMs: Int?,
    /** Boundary evidence of the pick the answer is based on. */
    val ev: Double
)

/** The final word on one line. [detectedMs] is on the internal clock. */
internal class LineVerdict(
    val detectedMs: Int?,
    val confidence: Double,
    val precisionMs: Int?,
    val evidence: AlignmentEvidence,
    val status: AlignmentStatus,
    val reason: String?
)

internal object LineFusion {
    const val AGREE_MS = 300         // words and audio agree if their starts are this close
    const val CONFLICT_MS = 1500     // ... and they flatly disagree beyond this
    private const val SNAP_MS = 150  // words-only lines are snapped to a pause onset at most this far away
    private const val LEAD_MS = 200L // recognized words within [start - LEAD, start + max(1.5 s, expected length)] belong to a line

    /** A correction is applied automatically only at or above this. Calibrated: see [Calibration]. */
    const val HIGH = 0.95
    const val MATCH_TOLERANCE_MS = 100

    // ------------------------------------------------------------------------------------------------------------
    // Decisions per line
    // ------------------------------------------------------------------------------------------------------------

    /** The boundary closest to [t] within [within] ms; a dip must be clearly nearer than a pause onset to win. Index or -1. */
    private fun nearestBoundary(b: BoundarySet, t: Int, within: Int): Int {
        var lo = 0
        var hi = b.times.size
        while (lo < hi) {
            val mid = (lo + hi) ushr 1
            if (b.times[mid] < t - within) lo = mid + 1 else hi = mid
        }
        var best = -1
        var bestD = Int.MAX_VALUE
        var j = lo
        while (j < b.times.size && b.times[j] <= t + within) {
            val d = abs(b.times[j] - t) + (if (b.kinds[j] == 0) 0 else 60)
            if (d < bestD) {
                bestD = d
                best = j
            }
            j++
        }
        return best
    }

    /**
     * One decision per line. Words choose WHICH line it is; the audio chooses the millisecond - except in continuous speech.
     *   AUDIO     pause onset, the words have nothing to say         -> audio time
     *   BOTH      pause onset and the words agree (<= 300 ms)         -> audio time
     *   DISAGREE  pause onset, but the words put the line elsewhere   -> audio time, confidence drops
     *   DIP       a dip in continuous speech, no words                -> audio time (imprecise)
     *   WORDDIP   a dip in continuous speech and the words           -> WORD time
     *   SNAP      the audio found nothing, the words did             -> nearest pause onset within 150 ms, else the word time
     *   NONE      no evidence.
     */
    fun fuse(
        picks: Array<AudioPick?>,
        lex: List<LexicalLine?>?,
        spoken: SpokenIndex?,
        bounds: BoundarySet,
        units: DoubleArray,
        clockOffsetMs: Long
    ): List<FusedLine> {
        val out = ArrayList<FusedLine>(picks.size)
        for (i in picks.indices) {
            val r = picks[i]
            val l = lex?.get(i)
            val strong = l != null && l.isStrong
            val tL: Int? = if (l != null) (l.startMs - clockOffsetMs).toInt() else null
            val mfrac = if (l != null) l.matched.toDouble() / l.n else 0.0
            var contra = false
            if (r != null && spoken != null && !spoken.isEmpty) {
                val span = max(1500, (units[i] / TextUnits.RATE0 * 1000.0).toInt())
                // how many of THIS line's words are heard near where the audio puts it (a match somewhere else is no help)
                var near = 0.0
                if (l != null) {
                    var c = 0
                    val a = r.tMs - 300L
                    val b = r.tMs + span + 300L
                    for (tm in l.timesMs) {
                        val t = tm - clockOffsetMs
                        if (t >= a && t < b) c++
                    }
                    near = c.toDouble() / l.n
                }
                val nW = spoken.count(r.tMs - LEAD_MS, r.tMs + span.toLong())
                val mc = spoken.meanConf(r.tMs - LEAD_MS, r.tMs + span.toLong())
                if (nW >= 3 && mc >= 0.5 && near < 0.34) contra = true
            }
            val anchorConf = if (strong && l != null) l.anchorConf else 0.0
            var cls = FusionClass.NONE
            var fin: Int? = null
            var gap: Int? = null
            var ev = r?.ev ?: 0.0
            if (r != null) {
                gap = if (strong && tL != null) abs(r.tMs - tL) else null
                if (r.kind == 1) {
                    if (strong && tL != null) {
                        cls = FusionClass.WORDDIP
                        fin = tL
                    } else {
                        cls = FusionClass.DIP
                        fin = r.tMs
                    }
                } else if (!strong || gap == null) {
                    cls = FusionClass.AUDIO
                    fin = r.tMs
                } else if (gap <= AGREE_MS) {
                    cls = FusionClass.BOTH
                    fin = r.tMs
                } else {
                    cls = FusionClass.DISAGREE
                    fin = r.tMs
                }
            } else if (strong && tL != null) {
                val b = nearestBoundary(bounds, tL, SNAP_MS)
                if (b >= 0 && bounds.kinds[b] == 0) {
                    cls = FusionClass.SNAP
                    fin = bounds.times[b]
                    ev = bounds.ev[b]
                } else {
                    cls = FusionClass.WORDS
                    fin = tL
                }
            }
            out.add(FusedLine(cls, fin, r, strong, if (strong) tL else null, mfrac, anchorConf, contra, gap, ev))
        }
        return out
    }

    // ------------------------------------------------------------------------------------------------------------
    // Calibrated confidence
    // ------------------------------------------------------------------------------------------------------------

    /**
     * P(the detected start is within 250 ms of the truth), fitted by logistic regression on simulated recordings with known
     * ground truth (tools/alignment-reference/calibrate.py): about 12,000 lines over 10 kinds of audio, 4 kinds of timestamp
     * error and 5 recognizer qualities, checked on lines from recordings the fit never saw. Capped below 100 %: nothing here
     * can be verified.
     *
     * The curve alone is NOT trusted in the tail it rarely saw, so hard gates (measured to hold) sit on top of it.
     */
    object Calibration {
        /** Over: cA, strongWords, mfrac, anchorConf, gap>300, gap>1500, contradiction, ev, clarity, 7 class flags, bias. */
        val W = doubleArrayOf(
            6.687, 0.764, 0.315, -0.094, -1.785, -1.582, -0.674, 0.770, 5.473,
            -0.353, -0.175, -1.039, -0.411, -0.347, 0.000, 2.325,
            -1.366
        )
        const val CAP_BOTH = 0.99        // two independent kinds of evidence agree
        const val CAP_ONE = 0.97         // one kind only: never more
        const val CAP_ESTIMATE = 0.70    // inferred from neighbours: never "high"
        const val GATE_AUDIO = 0.80      // audio-led evidence below this audio score is never "high"
        const val GATE_FLOOR = 0.50      // ... and below this it is at most 0.60

        private val CLASS_ORDER = arrayOf(
            FusionClass.AUDIO, FusionClass.BOTH, FusionClass.DISAGREE, FusionClass.DIP,
            FusionClass.WORDDIP, FusionClass.SNAP, FusionClass.WORDS
        )

        fun probability(d: FusedLine, clarity: Double): Double {
            if (d.finalMs == null) return 0.0
            val gap = d.gapMs ?: 0
            val x = DoubleArray(W.size)
            x[0] = d.pick?.conf ?: 0.0
            x[1] = if (d.strongWords) 1.0 else 0.0
            x[2] = d.mfrac
            x[3] = d.anchorConf
            x[4] = if (gap > AGREE_MS) 1.0 else 0.0
            x[5] = if (gap > CONFLICT_MS) 1.0 else 0.0
            x[6] = if (d.contradiction) 1.0 else 0.0
            x[7] = d.ev
            x[8] = clarity
            for ((k, c) in CLASS_ORDER.withIndex()) x[9 + k] = if (d.cls == c) 1.0 else 0.0
            x[16] = 1.0
            var z = 0.0
            for (k in W.indices) z += W[k] * x[k]
            var p = 1.0 / (1.0 + exp(-z))
            p = min(p, if (d.cls == FusionClass.BOTH) CAP_BOTH else CAP_ONE)
            val cA = d.pick?.conf ?: 0.0
            if ((d.cls == FusionClass.AUDIO || d.cls == FusionClass.DIP || d.cls == FusionClass.DISAGREE) && cA < GATE_AUDIO) p = min(p, 0.90)
            if (d.pick != null && cA < GATE_FLOOR) p = min(p, 0.60)
            // Flat contradictions are never a score: confident words here that are not this line's, or this line's words
            // found strongly at a quite different place (out of order, or its timestamp is far off).
            if (d.contradiction) p = min(p, 0.40)
            if (d.strongWords && d.gapMs != null && d.gapMs > CONFLICT_MS) p = min(p, 0.50)
            return p
        }

        /** Speech-vs-background level difference of the recording (dB) -> 0..1. Below ~9 dB the engine decides nothing at all. */
        fun clarity(rangeDb: Double): Double = min(1.0, max(0.0, (rangeDb - 9.0) / 30.0))

        /** 90th-percentile absolute error (ms), clear / noisy recording, per class (measured). */
        fun precisionMs(cls: FusionClass, clarity: Double): Int {
            val lo: Int
            val hi: Int
            when (cls) {
                FusionClass.AUDIO, FusionClass.BOTH -> { lo = 40; hi = 120 }
                FusionClass.DISAGREE -> { lo = 60; hi = 150 }
                FusionClass.DIP -> { lo = 320; hi = 400 }
                FusionClass.WORDDIP -> { lo = 150; hi = 250 }
                FusionClass.SNAP -> { lo = 150; hi = 250 }
                FusionClass.WORDS -> { lo = 250; hi = 350 }
                FusionClass.NONE -> { lo = 0; hi = 0 }
            }
            return Math.rint(lo + (hi - lo) * (1.0 - clarity)).toInt()
        }
    }

    // ------------------------------------------------------------------------------------------------------------
    // Lines with no evidence of their own
    // ------------------------------------------------------------------------------------------------------------

    class Anchor(val tMs: Int, val shiftMs: Int)

    class Estimate(val shiftMs: Double, val confidence: Double, val precisionMs: Int)

    /**
     * A line with no evidence of its own, placed from its confident neighbours (anchors, ascending by time). Measured by
     * pretending lines had no evidence: 84% within 250 ms when both neighbours agree, 60% when they only roughly agree,
     * 65% with one neighbour. Stated lower than that, because real "no evidence" lines sit in harder stretches.
     * Null when the neighbours disagree about the offset (a step: the line could be on either side) or none is near.
     */
    fun estimate(t: Int, anchors: List<Anchor>): Estimate? {
        var left: Anchor? = null
        var right: Anchor? = null
        for (a in anchors) {
            if (a.tMs <= t) {
                if (t - a.tMs <= 60000) left = a
            } else if (right == null && a.tMs - t <= 60000) {
                right = a
            }
        }
        val l = left
        val r = right
        if (l != null && r != null) {
            val gap = abs(l.shiftMs - r.shiftMs)
            val lerp = l.shiftMs + (r.shiftMs - l.shiftMs).toDouble() * (t - l.tMs) / max(1, r.tMs - l.tMs)
            if (gap <= 250) return Estimate(lerp, 0.70, max(250, gap + 150))
            if (gap <= 1000) return Estimate(lerp, 0.50, gap + 250)
            return null
        }
        val one = l ?: r
        if (one != null && abs(one.tMs - t) <= 20000) return Estimate(one.shiftMs.toDouble(), 0.50, 600)
        return null
    }

    // ------------------------------------------------------------------------------------------------------------
    // The verdict
    // ------------------------------------------------------------------------------------------------------------

    private fun evidenceOf(cls: FusionClass): AlignmentEvidence = when (cls) {
        FusionClass.AUDIO, FusionClass.DIP -> AlignmentEvidence.AUDIO
        FusionClass.BOTH, FusionClass.DISAGREE -> AlignmentEvidence.AUDIO_AND_WORDS
        FusionClass.WORDDIP, FusionClass.SNAP, FusionClass.WORDS -> AlignmentEvidence.WORDS
        FusionClass.NONE -> AlignmentEvidence.NONE
    }

    private fun reasonFor(d: FusedLine, clarity: Double): String = when {
        d.contradiction -> "The words spoken here do not match this line's text."
        d.strongWords && d.gapMs != null && d.gapMs > CONFLICT_MS ->
            "This line's words are heard about ${d.gapMs / 1000} s away, at a different place in the recording: the line may be out of order, or its timestamp is far off."
        d.cls == FusionClass.DISAGREE -> "The audio and the speech recognizer disagree about where this line starts."
        d.cls == FusionClass.DIP || d.cls == FusionClass.WORDDIP || d.cls == FusionClass.WORDS || d.cls == FusionClass.SNAP ->
            "No clear pause before this line (continuous speech), so its exact start is less certain."
        clarity < 0.35 -> "The recording is noisy, so the start is less certain."
        else -> "Not enough evidence to be sure of this line."
    }

    /**
     * Calibrated confidence, estimates for lines with no evidence, and a status with its reason, for every line.
     * [originalMs] is the script's timestamps on the internal clock.
     */
    fun judge(fused: List<FusedLine>, originalMs: IntArray, clarity: Double): List<LineVerdict> {
        val n = fused.size
        val detected = arrayOfNulls<Int>(n)
        val conf = DoubleArray(n)
        val prec = arrayOfNulls<Int>(n)
        val evid = Array(n) { evidenceOf(fused[it].cls) }
        for (i in 0 until n) {
            detected[i] = fused[i].finalMs
            conf[i] = Calibration.probability(fused[i], clarity)
            if (fused[i].finalMs != null) prec[i] = Calibration.precisionMs(fused[i].cls, clarity)
        }
        val anchors = ArrayList<Anchor>()
        for (i in 0 until n) {
            val dt = detected[i]
            if (dt != null && conf[i] >= HIGH) anchors.add(Anchor(originalMs[i], dt - originalMs[i]))
        }
        val estimated = BooleanArray(n)
        if (anchors.isNotEmpty()) {
            for (i in 0 until n) {
                if (detected[i] != null) continue
                val e = estimate(originalMs[i], anchors) ?: continue
                detected[i] = Math.rint(originalMs[i] + e.shiftMs).toInt()
                conf[i] = min(e.confidence, Calibration.CAP_ESTIMATE)
                prec[i] = e.precisionMs
                evid[i] = AlignmentEvidence.ESTIMATE
                estimated[i] = true
            }
        }
        val out = ArrayList<LineVerdict>(n)
        for (i in 0 until n) {
            val dt = detected[i]
            val status: AlignmentStatus
            var reason: String? = null
            if (dt == null) {
                status = AlignmentStatus.CANNOT_ALIGN
                reason = "No matching speech was found for this line, so its timestamp was left alone."
            } else if (estimated[i]) {
                status = AlignmentStatus.ESTIMATED
                reason = "No speech evidence for this line: placed from the neighbouring lines."
            } else if (conf[i] >= HIGH) {
                status = if (abs(dt - originalMs[i]) <= MATCH_TOLERANCE_MS) AlignmentStatus.MATCHES else AlignmentStatus.HIGH_CONFIDENCE
            } else {
                status = AlignmentStatus.NEEDS_REVIEW
                reason = reasonFor(fused[i], clarity)
            }
            out.add(LineVerdict(dt, conf[i], prec[i], evid[i], status, reason))
        }
        return out
    }
}

/** Stretches of consecutive lines that could not be aligned with confidence: first, last, and the most serious status. */
internal object AlignmentSections {
    class Found(val first: Int, val last: Int, val worst: AlignmentStatus)

    private fun isBad(s: AlignmentStatus) =
        s == AlignmentStatus.NEEDS_REVIEW || s == AlignmentStatus.ESTIMATED || s == AlignmentStatus.CANNOT_ALIGN

    /** A stretch counts when it has [minLines] lines or contains a line that could not be aligned at all. */
    fun find(statuses: List<AlignmentStatus>, minLines: Int = 2): List<Found> {
        val out = ArrayList<Found>()
        var i = 0
        val n = statuses.size
        while (i < n) {
            if (!isBad(statuses[i])) {
                i++
                continue
            }
            var j = i
            while (j + 1 < n && isBad(statuses[j + 1])) j++
            var cannot = false
            var review = false
            for (k in i..j) {
                if (statuses[k] == AlignmentStatus.CANNOT_ALIGN) cannot = true
                if (statuses[k] == AlignmentStatus.NEEDS_REVIEW) review = true
            }
            if (j - i + 1 >= minLines || cannot) {
                out.add(Found(i, j, if (cannot) AlignmentStatus.CANNOT_ALIGN else if (review) AlignmentStatus.NEEDS_REVIEW else AlignmentStatus.ESTIMATED))
            }
            i = j + 1
        }
        return out
    }
}
