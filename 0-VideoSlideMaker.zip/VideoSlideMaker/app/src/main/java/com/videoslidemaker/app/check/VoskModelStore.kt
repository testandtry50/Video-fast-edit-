package com.videoslidemaker.app.check

import android.content.Context
import android.net.Uri
import android.os.ParcelFileDescriptor
import java.io.File
import java.io.FilterInputStream
import java.io.InputStream
import java.util.concurrent.CancellationException
import java.util.zip.ZipInputStream

/**
 * Keeps ONE Vosk speech model (the language the recordings are in) inside the app's own storage.
 *
 * The app deliberately has no internet permission, so the model is not downloaded: the user picks the model's .zip
 * (from alphacephei.com/vosk/models) once with the system file picker, and it is unpacked here.
 */
class VoskModelStore(context: Context) {
    private val appContext = context.applicationContext
    private val root = File(appContext.filesDir, "vosk")
    private val modelFolder = File(root, "model")
    private val nameFile = File(root, "model.name")

    /** The folder Vosk should load (the one that contains `am` and `conf`), or null when no model is installed. */
    fun modelDir(): File? = if (modelFolder.isDirectory) findModelRoot(modelFolder) else null

    fun modelName(): String? = if (modelDir() != null) runCatching { nameFile.readText().trim() }.getOrNull()?.ifEmpty { null } else null

    fun remove() {
        modelFolder.deleteRecursively()
        nameFile.delete()
    }

    /** Unpacks the model zip at [zipUri]. Returns the model's name. Throws [RecognizerException] with a message the user can act on. */
    fun install(zipUri: Uri, onProgress: (Int) -> Unit, isCancelled: () -> Boolean): String {
        root.mkdirs()
        val incoming = File(root, "incoming")
        incoming.deleteRecursively()
        incoming.mkdirs()
        try {
            val pfd = appContext.contentResolver.openFileDescriptor(zipUri, "r")
                ?: throw RecognizerException("Couldn't open that file.")
            val total = pfd.statSize.coerceAtLeast(1L)
            val destRoot = incoming.canonicalFile
            var topName: String? = null
            var written = 0L
            // AutoCloseInputStream owns the descriptor, so closing the zip stream closes it exactly once.
            val counting = CountingInputStream(ParcelFileDescriptor.AutoCloseInputStream(pfd))
            ZipInputStream(counting.buffered()).use { zip ->
                var lastPct = -1
                val buffer = ByteArray(64 * 1024)
                while (true) {
                    if (isCancelled()) throw CancellationException()
                    val entry = zip.nextEntry ?: break
                    val target = File(destRoot, entry.name).canonicalFile
                    // never let an entry write outside the folder (zip-slip)
                    if (target.path != destRoot.path && !target.path.startsWith(destRoot.path + File.separator)) {
                        throw RecognizerException("That zip file isn't a valid speech model.")
                    }
                    if (topName == null) topName = entry.name.substringBefore('/')
                    if (entry.isDirectory) {
                        target.mkdirs()
                    } else {
                        target.parentFile?.mkdirs()
                        target.outputStream().use { out ->
                            while (true) {
                                val n = zip.read(buffer)
                                if (n < 0) break
                                out.write(buffer, 0, n)
                                written += n
                                if (written > MAX_UNPACKED_BYTES) throw RecognizerException("That zip file is unreasonably large for a speech model.")
                            }
                        }
                    }
                    val pct = (counting.count * 100L / total).toInt().coerceIn(0, 99)
                    if (pct != lastPct) {
                        lastPct = pct
                        onProgress(pct)
                    }
                }
            }
            findModelRoot(incoming)
                ?: throw RecognizerException("That doesn't look like a Vosk speech model (it has no \"am\" and \"conf\" folders). Download one from alphacephei.com/vosk/models.")
            modelFolder.deleteRecursively()
            if (!incoming.renameTo(modelFolder)) throw RecognizerException("Couldn't store the speech model.")
            val name = (topName?.takeIf { it.isNotBlank() } ?: "speech model")
            nameFile.writeText(name)
            onProgress(100)
            return name
        } catch (e: java.util.zip.ZipException) {
            throw RecognizerException("That file isn't a readable .zip.")
        } catch (e: java.io.IOException) {
            throw RecognizerException("Couldn't unpack the speech model: " + (e.message ?: "storage error") + ". Is there enough free space?")
        } finally {
            if (incoming.exists()) incoming.deleteRecursively()
        }
    }

    /** The folder with `am` and `conf` inside [dir], looking up to two levels down (zips usually hold one top folder). */
    private fun findModelRoot(dir: File, depth: Int = 0): File? {
        if (File(dir, "am").isDirectory && File(dir, "conf").isDirectory) return dir
        if (depth >= 2) return null
        val children = dir.listFiles { f -> f.isDirectory } ?: return null
        for (c in children.sortedBy { it.name }) findModelRoot(c, depth + 1)?.let { return it }
        return null
    }

    private class CountingInputStream(source: InputStream) : FilterInputStream(source) {
        var count = 0L
        override fun read(): Int = super.read().also { if (it >= 0) count++ }
        override fun read(b: ByteArray, off: Int, len: Int): Int = super.read(b, off, len).also { if (it > 0) count += it }
    }

    private companion object {
        const val MAX_UNPACKED_BYTES = 4L * 1024 * 1024 * 1024
    }
}
