package com.videoslidemaker.app.model

/**
 * NEW (2.20): the rule behind the Match screen's "Move photos along" buttons.
 *
 * The photos are right, but from some sentence on they sit ONE sentence too early or too late. Instead of fixing them
 * one by one, the photo on the current sentence moves one sentence forward (or back) and the photos RIGHT AFTER IT follow.
 * The sentences themselves (their text and times) never move - only which photo is on which sentence.
 *
 * Only the photos that stand together move: starting at the current photo, the group goes on for as long as the next
 * sentence also has a photo, and ends at the first sentence that has none. Photos beyond that empty sentence are already
 * placed, so they stay exactly where they are. Think of the sentences as a row of slots:
 *
 *  - FORWARD  = the group moves one slot on, and the current sentence is left empty. The empty sentence at the end of
 *               the group takes up the move - nothing is lost, and nothing after it is touched. If the group runs
 *               right to the last sentence there is no empty one to use: the photo on the last sentence has nowhere
 *               to go and drops off the timeline (it stays in the photo list).
 *  - BACK     = the group moves one slot back: the current photo goes onto the previous sentence (covering the photo
 *               that was there, if any - an empty previous sentence simply takes it) and the last sentence of the group
 *               is left empty. Special case: when the current sentence has NO photo, the group is the photos right after
 *               it, and they come back by one to fill that gap (nothing is covered).
 *
 * Plain Kotlin on photo ids (no Android classes), so it can be tested on its own. The caller
 * ([com.videoslidemaker.app.viewmodel.AppViewModel.shiftPhotosFromCurrent]) turns the answer into one undoable change.
 */
object PhotoShift {

    /** What a shift does (or did), with the facts the screen reports. */
    data class Result(
        /** The photo id for every sentence after the shift, in the same order as the sentences (null = no photo). */
        val assignments: List<String?>,
        /** True = moved toward later sentences; false = moved toward earlier ones. */
        val forward: Boolean,
        /** The sentence (0-based) the buttons were used on. */
        val sentence: Int,
        /** True when the current sentence had no photo and the shift just pulled the photos after it back over that gap. */
        val closedGap: Boolean,
        /** How many photos moved to another sentence. */
        val movedPhotos: Int,
        /** How many sentences have a different photo than before. */
        val changed: Int,
        /** The photo that ended up on no sentence at all (it is still in the pool); null when none was lost. */
        val lostPhotoId: String?,
        /** The sentence (0-based) that photo was on before. Only meaningful when [lostPhotoId] is not null. */
        val lostSentence: Int,
        /** The sentence (0-based) that is left without a photo by the move. */
        val emptySentence: Int,
        /** Forward only: the empty sentence (0-based) that took up the move, so the photos after it stayed where they
         *  were; null when the group ran to the last sentence (or for a move back). */
        val stoppedAt: Int?
    ) {
        /** One or two short, plain sentences for the screen. */
        fun message(): String {
            if (changed == 0 || movedPhotos == 0) return "Nothing changed - there was no photo to move."
            val photos = if (movedPhotos == 1) "1 photo" else "$movedPhotos photos"
            val text = StringBuilder()
            when {
                forward -> {
                    text.append("$photos moved one sentence forward. Sentence ${emptySentence + 1} is now empty - pick a photo for it.")
                    if (stoppedAt != null) {
                        text.append(" The move stopped at sentence ${stoppedAt + 1}, which was empty, so everything after it stayed as it was.")
                    }
                }
                closedGap ->
                    text.append("The empty spot on sentence ${sentence + 1} is closed: $photos moved one sentence back. Sentence ${emptySentence + 1} is now empty.")
                else ->
                    text.append("$photos moved one sentence back. Sentence ${emptySentence + 1} is now empty.")
            }
            if (lostPhotoId != null) {
                text.append(
                    if (forward) " The photo that was on sentence ${lostSentence + 1} had no sentence left, so it is off the timeline"
                    else " The photo that was on sentence ${lostSentence + 1} was covered, so it is off the timeline"
                )
                text.append(" (it is still in your photo list).")
            }
            return text.toString()
        }
    }

    /**
     * Whether the buttons can do anything on sentence [index].
     *  - forward: this sentence needs a photo to move, and a later sentence to move it to.
     *  - back: this sentence needs a photo and an earlier sentence to move it into - or, on an EMPTY sentence, a photo
     *    right after it that can be pulled back over the gap.
     */
    fun canShift(current: List<String?>, index: Int, forward: Boolean): Boolean {
        val n = current.size
        if (index < 0 || index >= n) return false
        if (forward) return current[index] != null && index < n - 1
        val start = if (current[index] == null) index + 1 else index
        return start >= 1 && start < n && current[start] != null
    }

    /**
     * @param current the photo each sentence has now (null = none), in the order the sentences are kept in.
     * @param index the sentence the person is on (0-based).
     * @param forward true = move this photo and the group right after it one sentence later; false = one sentence earlier.
     * @return what was done; null when it cannot be done here (see [canShift]).
     */
    fun plan(current: List<String?>, index: Int, forward: Boolean): Result? {
        if (!canShift(current, index, forward)) return null
        val n = current.size

        val closeGap = !forward && current[index] == null
        // The group that moves: photos on consecutive sentences, start .. end. It stops at the first sentence without a photo.
        val start = if (closeGap) index + 1 else index
        var end = start
        while (end + 1 < n && current[end + 1] != null) end++

        // One slot goes away and one empty slot appears; everything in between moves by exactly one place.
        val removeAt: Int
        val insertAt: Int
        if (forward) {
            removeAt = minOf(end + 1, n - 1)   // the empty sentence after the group (or, with none, the last slot is squeezed out) ...
            insertAt = index                   // ... and the empty slot opens HERE
        } else {
            removeAt = start - 1               // the slot before the group closes (covered, or the empty current one) ...
            insertAt = end                     // ... and the empty slot opens where the group ended
        }
        val out = ArrayList<String?>(current)
        val removed = out.removeAt(removeAt)
        out.add(insertAt, null)

        val moved = if (forward) removeAt - index else end - start + 1

        var changed = 0
        for (i in 0 until n) if (out[i] != current[i]) changed++

        // a photo only counts as lost when no other sentence still uses it
        val lost = removed?.takeIf { id -> id !in out }
        return Result(
            assignments = out,
            forward = forward,
            sentence = index,
            closedGap = closeGap,
            movedPhotos = moved,
            changed = changed,
            lostPhotoId = lost,
            lostSentence = removeAt,
            emptySentence = insertAt,
            stoppedAt = if (forward && end < n - 1) end + 1 else null
        )
    }
}
