package com.videoslidemaker.app.logoclean

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min

/*
 * Finds logos / watermarks. Port of tools/logoclean-reference/logoclean.py - read that file's header
 * for the idea in plain words:
 *   1. a watermark is the one thing that sits at the SAME place in many photos -> stack the photos'
 *      edge maps; edges that appear in (almost) all of them are the logo;
 *   2. the logo is remembered as edge points with directions; to see whether another photo has it
 *      (and where, if it moved) those points are slid over that photo's edges;
 *   3. a solid mask of the logo's own shape is made so only its pixels are touched.
 */

/** Edge map of one photo at analysis size. [dir] (0..7, 22.5 degrees each) is only meaningful on edge pixels. */
internal class EdgeData(val w: Int, val h: Int, val edge: BooleanArray, val dir: ByteArray)

/** The stacked edge maps of several same-sized photos. */
internal class Consistency(
    val w: Int,
    val h: Int,
    /** How many photos were stacked. */
    val n: Int,
    /** Per pixel: in how many photos is there an edge within 1 px. */
    val cnt: IntArray,
    /** Per pixel: in how many photos is this exact pixel an edge. */
    val raw: IntArray,
    /** Per direction, per pixel: how many photos have an edge of that direction here. */
    val votes: Array<IntArray>
)

/** A logo-shaped group of consistent edges, in analysis pixels (r/b exclusive). */
internal class Blob(
    val l: Int, val t: Int, val r: Int, val b: Int,
    val score: Float,
    val support: Float,
    val coreX: IntArray, val coreY: IntArray, val coreDir: IntArray,
    val quietX: IntArray, val quietY: IntArray
)

/** Best place the logo template was found in a photo. dx/dy are in that photo's analysis pixels. */
internal class Match(val score: Float, val dx: Int, val dy: Int)

internal object LogoDetector {
    const val L_ANALYSIS = 640        // long edge of the analysis picture
    const val MIN_COUNT = 3           // a pixel must be an edge in at least this many photos
    const val TAU_PERCENT = 70        // ... and in at least this share of them
    const val LINK_R = 3              // blobs closer than this are joined
    const val MIN_BLOB_PX = 30
    const val MAX_AREA_FRAC = 0.08f   // a logo covers less than 8 % of the photo
    const val MIN_AREA_FRAC = 0.0002f
    const val MAX_ASPECT = 12f
    const val MAX_QUIET = 400
    const val MAX_MATCH_PTS = 400
    const val N_ORI = 8
    const val FIXED_SEARCH_R = 6      // "same place" tolerance in analysis px
    const val MATCH_FIXED = 0.65f     // score needed when the logo is expected at the same place
    const val MATCH_FOLLOW = 0.82f    // score needed when the whole photo was searched
    const val OFF_GUARD = 0.60f

    /** Analysis pixels per photo pixel (never enlarges small photos). */
    fun analysisScale(w: Int, h: Int): Float = min(1f, L_ANALYSIS.toFloat() / max(w, h).coerceAtLeast(1))

    fun luma(argb: IntArray): FloatArray = FloatArray(argb.size) {
        val p = argb[it]
        ((p shr 16) and 0xFF) * 0.299f + ((p shr 8) and 0xFF) * 0.587f + (p and 0xFF) * 0.114f
    }

    // ------------------------------------------------------------------------------ edges

    fun computeEdges(l: FloatArray, w: Int, h: Int): EdgeData {
        val mag = FloatArray(w * h)
        val gxA = FloatArray(w * h)
        val gyA = FloatArray(w * h)
        for (y in 1 until h - 1) {
            for (x in 1 until w - 1) {
                val i = y * w + x
                val a = l[i - w - 1]; val b = l[i - w]; val c = l[i - w + 1]
                val d = l[i - 1]; val f = l[i + 1]
                val g = l[i + w - 1]; val hh = l[i + w]; val k = l[i + w + 1]
                val gx = (c + 2f * f + k) - (a + 2f * d + g)
                val gy = (g + 2f * hh + k) - (a + 2f * b + c)
                gxA[i] = gx
                gyA[i] = gy
                mag[i] = (abs(gx) + abs(gy)) / 4f
            }
        }
        // threshold adapts to the photo: 35 % of its 98th-percentile edge strength, kept in 10..40
        val hist = IntArray(256)
        for (v in mag) hist[min(255, v.toInt())]++
        val target = 0.98 * w * h
        var cum = 0L
        var p98 = 255
        for (v in 0..255) {
            cum += hist[v]
            if (cum >= target) { p98 = v; break }
        }
        val thr = min(40f, max(10f, 0.35f * p98))
        val edge = BooleanArray(w * h)
        val dir = ByteArray(w * h)
        for (i in 0 until w * h) {
            if (mag[i] > thr) {
                edge[i] = true
                var th = atan2(gyA[i].toDouble(), gxA[i].toDouble())
                if (th < 0) th += PI
                dir[i] = (floor(th / PI * N_ORI).toInt() % N_ORI).toByte()
            }
        }
        return EdgeData(w, h, edge, dir)
    }

    // ------------------------------------------------------------------------------ consistency

    /** Stacks same-sized edge maps (maps of another size are ignored). Null if there is nothing to stack. */
    fun consistency(maps: List<EdgeData>): Consistency? {
        if (maps.isEmpty()) return null
        val w = maps[0].w
        val h = maps[0].h
        val cnt = IntArray(w * h)
        val raw = IntArray(w * h)
        val votes = Array(N_ORI) { IntArray(w * h) }
        var used = 0
        for (m in maps) {
            if (m.w != w || m.h != h) continue
            used++
            val dil = maxFilter(m.edge, w, h, 1)
            for (i in 0 until w * h) {
                if (dil[i]) cnt[i]++
                if (m.edge[i]) {
                    raw[i]++
                    votes[m.dir[i].toInt()][i]++
                }
            }
        }
        return Consistency(w, h, used, cnt, raw, votes)
    }

    private fun needCount(n: Int): Int = max(MIN_COUNT, (TAU_PERCENT * n + 99) / 100)

    /** Logo-like blobs that repeat at the same place, best first. Empty when nothing repeats. */
    fun findBlobs(c: Consistency, maxCandidates: Int = 3): List<Blob> {
        if (c.n < MIN_COUNT) return emptyList()
        val w = c.w
        val h = c.h
        val need = needCount(c.n)
        val hi = BooleanArray(w * h) { c.cnt[it] >= need }
        val linked = maxFilter(hi, w, h, LINK_R)
        val lab = label4(linked, w, h)
        val k = lab.count
        if (k == 0) return emptyList()
        val minX = IntArray(k + 1) { Int.MAX_VALUE }
        val maxX = IntArray(k + 1) { -1 }
        val minY = IntArray(k + 1) { Int.MAX_VALUE }
        val maxY = IntArray(k + 1) { -1 }
        val pix = IntArray(k + 1)
        val sumCnt = LongArray(k + 1)
        for (y in 0 until h) {
            for (x in 0 until w) {
                val i = y * w + x
                val id = lab.data[i]
                if (id > 0 && hi[i]) {
                    if (x < minX[id]) minX[id] = x
                    if (x > maxX[id]) maxX[id] = x
                    if (y < minY[id]) minY[id] = y
                    if (y > maxY[id]) maxY[id] = y
                    pix[id]++
                    sumCnt[id] += c.cnt[i].toLong()
                }
            }
        }
        val out = ArrayList<Blob>()
        for (id in 1..k) {
            val count = pix[id]
            if (count < MIN_BLOB_PX) continue
            // the stacked maps are dilated by 1 px and the edge filter adds ~1 px: shrink by 1 for the real extent
            val l = minX[id] + 1
            val r = maxX[id]
            val t = minY[id] + 1
            val b = maxY[id]
            val bw = r - l
            val bh = b - t
            if (bw < 1 || bh < 1) continue
            val area = bw.toFloat() * bh / (w.toFloat() * h)
            if (area > MAX_AREA_FRAC || area < MIN_AREA_FRAC) continue
            val aspect = max(bw, bh).toFloat() / max(1, min(bw, bh))
            if (aspect > MAX_ASPECT) continue
            if (l <= 1 || t <= 1 || r >= w - 1 || b >= h - 1) continue // touches the border: letter-box / frame line
            val xs = IntArray(count)
            val ys = IntArray(count)
            var q = 0
            for (y in minY[id]..maxY[id]) {
                for (x in minX[id]..maxX[id]) {
                    val i = y * w + x
                    if (lab.data[i] == id && hi[i]) { xs[q] = x; ys[q] = y; q++ }
                }
            }
            val support = (sumCnt[id].toFloat() / count) / c.n
            out.add(makeBlob(c, xs, ys, count, l, t, r, b, count * support, support))
        }
        out.sortByDescending { it.score }
        return if (out.size > maxCandidates) out.subList(0, maxCandidates).toList() else out
    }

    /**
     * For a box the user drew: the repeating edges inside it, as a logo. Null when nothing inside
     * that box repeats across the photos (so there is no logo to look for in the other photos).
     */
    fun blobInBox(c: Consistency, left: Int, top: Int, right: Int, bottom: Int): Blob? {
        if (c.n < MIN_COUNT) return null
        val w = c.w
        val h = c.h
        val need = needCount(c.n)
        val x0 = left.coerceIn(0, w - 1)
        val x1 = right.coerceIn(x0 + 1, w)
        val y0 = top.coerceIn(0, h - 1)
        val y1 = bottom.coerceIn(y0 + 1, h)
        var count = 0
        for (y in y0 until y1) for (x in x0 until x1) if (c.cnt[y * w + x] >= need) count++
        if (count < 25) return null
        val xs = IntArray(count)
        val ys = IntArray(count)
        var q = 0
        var sum = 0L
        var minX = Int.MAX_VALUE; var maxX = -1; var minY = Int.MAX_VALUE; var maxY = -1
        for (y in y0 until y1) {
            for (x in x0 until x1) {
                val i = y * w + x
                if (c.cnt[i] >= need) {
                    xs[q] = x; ys[q] = y; q++
                    sum += c.cnt[i]
                    if (x < minX) minX = x
                    if (x > maxX) maxX = x
                    if (y < minY) minY = y
                    if (y > maxY) maxY = y
                }
            }
        }
        var l = minX + 1; var r = maxX; var t = minY + 1; var b = maxY
        if (r - l < 1) { l = minX; r = maxX + 1 }
        if (b - t < 1) { t = minY; b = maxY + 1 }
        val support = (sum.toFloat() / count) / c.n
        return makeBlob(c, xs, ys, count, l, t, r, b, count * support, support)
    }

    private fun evenIndices(n: Int, cap: Int): IntArray {
        if (n <= cap) return IntArray(n) { it }
        return IntArray(cap) { ((it.toLong() * (n - 1)) / (cap - 1)).toInt() }
    }

    private fun makeBlob(
        c: Consistency, xs: IntArray, ys: IntArray, count: Int,
        l: Int, t: Int, r: Int, b: Int, score: Float, support: Float
    ): Blob {
        val w = c.w
        val h = c.h
        val n = c.n
        // thin core of the logo: pixels that are an exact edge in at least half of the photos
        val needRaw = max(2, (n + 1) / 2)
        var coreN = 0
        for (i in 0 until count) if (c.raw[ys[i] * w + xs[i]] >= needRaw) coreN++
        val cx: IntArray
        val cy: IntArray
        if (coreN >= 40) {
            cx = IntArray(coreN)
            cy = IntArray(coreN)
            var q = 0
            for (i in 0 until count) {
                if (c.raw[ys[i] * w + xs[i]] >= needRaw) { cx[q] = xs[i]; cy[q] = ys[i]; q++ }
            }
        } else { // very soft logo: use every consistent pixel
            cx = xs.copyOf(count)
            cy = ys.copyOf(count)
        }
        // the logo's own edge direction at each core pixel = the most common direction among the photos
        val cd = IntArray(cx.size) { i ->
            val pi = cy[i] * w + cx[i]
            var best = 0
            var bestV = -1
            for (o in 0 until N_ORI) {
                if (c.votes[o][pi] > bestV) { bestV = c.votes[o][pi]; best = o }
            }
            best
        }
        // quiet points: inside the box, almost never an edge, and >= 3 px away from the logo's lines
        val coreMask = BooleanArray(w * h)
        for (i in cx.indices) coreMask[cy[i] * w + cx[i]] = true
        val near = maxFilter(coreMask, w, h, 3)
        val lowRaw = n / 10
        var qn = 0
        for (y in t until b) for (x in l until r) {
            val i = y * w + x
            if (c.raw[i] <= lowRaw && !near[i]) qn++
        }
        val allQx = IntArray(qn)
        val allQy = IntArray(qn)
        var q = 0
        for (y in t until b) for (x in l until r) {
            val i = y * w + x
            if (c.raw[i] <= lowRaw && !near[i]) { allQx[q] = x; allQy[q] = y; q++ }
        }
        val sel = evenIndices(qn, MAX_QUIET)
        val qx = IntArray(sel.size) { allQx[sel[it]] }
        val qy = IntArray(sel.size) { allQy[sel[it]] }
        return Blob(l, t, r, b, score, support, cx, cy, cd, qx, qy)
    }

    // ------------------------------------------------------------------------------ template

    private fun closeRows(a: BooleanArray, w: Int, h: Int, gap: Int): BooleanArray {
        val o = a.copyOf()
        for (y in 0 until h) {
            var last = -1
            for (x in 0 until w) {
                if (a[y * w + x]) {
                    if (last >= 0 && x - last <= gap) for (k in last + 1 until x) o[y * w + k] = true
                    last = x
                }
            }
        }
        return o
    }

    private fun closeCols(a: BooleanArray, w: Int, h: Int, gap: Int): BooleanArray {
        val o = a.copyOf()
        for (x in 0 until w) {
            var last = -1
            for (y in 0 until h) {
                if (a[y * w + x]) {
                    if (last >= 0 && y - last <= gap) for (k in last + 1 until y) o[k * w + x] = true
                    last = y
                }
            }
        }
        return o
    }

    /** Turns a blob into what is remembered about the logo (all relative to the photo size). */
    fun toTemplate(blob: Blob, c: Consistency): LogoTemplate {
        val fw = c.w.toFloat()
        val fh = c.h.toFloat()
        val sel = evenIndices(blob.coreX.size, MAX_MATCH_PTS)
        val ptsX = FloatArray(sel.size) { (blob.coreX[sel[it]] + 0.5f) / fw }
        val ptsY = FloatArray(sel.size) { (blob.coreY[sel[it]] + 0.5f) / fh }
        val ptsD = IntArray(sel.size) { blob.coreDir[sel[it]] }
        val quietX = FloatArray(blob.quietX.size) { (blob.quietX[it] + 0.5f) / fw }
        val quietY = FloatArray(blob.quietY.size) { (blob.quietY[it] + 0.5f) / fh }

        // solid mask of the logo's shape: join the edge pixels along rows and columns, then grow by 1 px
        val ml = max(0, blob.l - 3)
        val mt = max(0, blob.t - 3)
        val mr = min(c.w, blob.r + 3)
        val mb = min(c.h, blob.b + 3)
        val ww = mr - ml
        val wh = mb - mt
        val m = BooleanArray(ww * wh)
        for (i in blob.coreX.indices) {
            val x = blob.coreX[i] - ml
            val y = blob.coreY[i] - mt
            if (x in 0 until ww && y in 0 until wh) m[y * ww + x] = true
        }
        val rows = closeRows(m, ww, wh, 12)
        val cols = closeCols(rows, ww, wh, 4)
        val mask = maxFilter(cols, ww, wh, 1)
        return LogoTemplate(
            box = LogoBox(blob.l / fw, blob.t / fh, blob.r / fw, blob.b / fh),
            ptsX = ptsX, ptsY = ptsY, ptsDir = ptsD,
            quietX = quietX, quietY = quietY,
            mask = mask, maskW = ww, maskH = wh,
            maskRect = LogoBox(ml / fw, mt / fh, mr / fw, mb / fh)
        )
    }

    // ------------------------------------------------------------------------------ matching

    /**
     * Slides the logo template over a photo's edge map and returns the best place and its score (0..1).
     * [searchR] < 0 searches the whole photo, otherwise +-searchR analysis px around "same place".
     *   on  = share of the logo's edge points that land on an edge of the SAME direction (1 px tolerance)
     *   off = share of the logo's quiet points that are really quiet in the photo
     *   score = on, scaled down if off < OFF_GUARD (a very busy spot is not the logo)
     */
    fun match(target: EdgeData, tpl: LogoTemplate, searchR: Int): Match {
        val w = target.w
        val h = target.h
        val p = tpl.ptsX.size
        if (p == 0) return Match(0f, 0, 0)
        val px = IntArray(p) { Math.round(tpl.ptsX[it] * w - 0.5f) }
        val py = IntArray(p) { Math.round(tpl.ptsY[it] * h - 0.5f) }
        val qn = tpl.quietX.size
        val qx = IntArray(qn) { Math.round(tpl.quietX[it] * w - 0.5f) }
        val qy = IntArray(qn) { Math.round(tpl.quietY[it] * h - 0.5f) }

        var minX = Int.MAX_VALUE; var maxX = Int.MIN_VALUE; var minY = Int.MAX_VALUE; var maxY = Int.MIN_VALUE
        for (i in 0 until p) {
            minX = min(minX, px[i]); maxX = max(maxX, px[i]); minY = min(minY, py[i]); maxY = max(maxY, py[i])
        }
        for (i in 0 until qn) {
            minX = min(minX, qx[i]); maxX = max(maxX, qx[i]); minY = min(minY, qy[i]); maxY = max(maxY, qy[i])
        }
        // every point has to stay inside the photo
        var dxLo = -minX
        var dxHi = w - 1 - maxX
        var dyLo = -minY
        var dyHi = h - 1 - maxY
        if (searchR >= 0) {
            dxLo = max(dxLo, -searchR); dxHi = min(dxHi, searchR)
            dyLo = max(dyLo, -searchR); dyHi = min(dyHi, searchR)
        }
        if (dxHi < dxLo || dyHi < dyLo) return Match(0f, 0, 0)

        // one map per edge direction; a direction also accepts its two neighbours (22.5 degree jitter)
        val dil = Array(N_ORI) { k ->
            maxFilter(BooleanArray(w * h) { target.edge[it] && target.dir[it].toInt() == k }, w, h, 1)
        }
        val accept = Array(N_ORI) { k ->
            val a = dil[(k + N_ORI - 1) % N_ORI]
            val b = dil[k]
            val c = dil[(k + 1) % N_ORI]
            BooleanArray(w * h) { a[it] || b[it] || c[it] }
        }
        val maps = Array(p) { accept[tpl.ptsDir[it].coerceIn(0, N_ORI - 1)] }
        val off = IntArray(p) { py[it] * w + px[it] }

        var best = -1
        var bestDx = 0
        var bestDy = 0

        fun hitsAt(dx: Int, dy: Int, beatThis: Int): Int {
            val base = dy * w + dx
            var hits = 0
            var k = 0
            while (k < p) {
                if (maps[k][off[k] + base]) hits++
                k++
                // give up on this position as soon as it can no longer beat the best one so far
                if ((k and 31) == 0 && hits + (p - k) <= beatThis) return -1
            }
            return hits
        }

        // look at "same place" first: it sets a high bar, so most other positions are dropped early
        val firstDx = 0.coerceIn(dxLo, dxHi)
        val firstDy = 0.coerceIn(dyLo, dyHi)
        best = hitsAt(firstDx, firstDy, -1)
        bestDx = firstDx
        bestDy = firstDy
        for (dy in dyLo..dyHi) {
            for (dx in dxLo..dxHi) {
                val hits = hitsAt(dx, dy, best)
                if (hits > best) { best = hits; bestDx = dx; bestDy = dy }
            }
        }
        val on = best.toFloat() / p
        var offScore = 1f
        if (qn > 0) {
            var busy = 0
            for (i in 0 until qn) if (target.edge[(qy[i] + bestDy) * w + qx[i] + bestDx]) busy++
            offScore = 1f - busy.toFloat() / qn
        }
        val score = on * min(1f, offScore / OFF_GUARD)
        return Match(score, bestDx, bestDy)
    }
}
