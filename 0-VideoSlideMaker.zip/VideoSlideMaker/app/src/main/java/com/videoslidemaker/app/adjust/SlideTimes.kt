package com.videoslidemaker.app.adjust

import com.videoslidemaker.app.data.ScriptParser

/**
 * The bridge between a slide's timestamps (seconds as Double: `timestampSec` and the preserved `originalTimestampSec`) and the
 * adjuster's whole milliseconds. Pure, so the one property that matters is testable: the original survives EXACTLY.
 */
object SlideTimes {

    fun toMs(seconds: Double): Long = ScriptParser.secondsToMillis(seconds)

    fun toLine(index: Int, text: String, timestampSec: Double, originalSec: Double?): AdjustLine =
        AdjustLine(index, text, toMs(timestampSec), originalSec?.let { toMs(it) })

    /**
     * What to store on the slide after the adjuster changed [line]: (timestampSec, originalTimestampSec).
     *  - While an adjustment is in place the preserved original is the slide's first one, as the exact Double it always was
     *    (a line adjusted for the first time keeps the time it had; a line adjusted before keeps its old original).
     *  - Back at its original time the marker is cleared, and the time is the original Double itself, not a rounded copy.
     */
    fun writeBack(oldTimestampSec: Double, oldOriginalSec: Double?, line: AdjustLine): Pair<Double, Double?> {
        val newOriginal: Double? = if (line.scriptMs == null) null else (oldOriginalSec ?: oldTimestampSec)
        val newTimestamp: Double = if (line.scriptMs == null && oldOriginalSec != null) oldOriginalSec else line.currentMs / 1000.0
        return newTimestamp to newOriginal
    }
}
