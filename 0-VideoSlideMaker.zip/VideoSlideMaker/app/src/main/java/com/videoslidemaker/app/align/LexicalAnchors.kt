package com.videoslidemaker.app.align

import com.videoslidemaker.app.check.CheckAligner
import com.videoslidemaker.app.check.CheckSegment
import com.videoslidemaker.app.check.CheckSettings
import com.videoslidemaker.app.check.CheckTokenizer
import com.videoslidemaker.app.check.SpokenWord
import kotlin.math.min
import kotlin.math.roundToLong

/**
 * What the recognizer heard says WHERE each script line is spoken - at ANY offset, because the match uses the words only,
 * never the script's timestamps. Its word times are only good to about ±50-150 ms, so this identifies the line but does
 * not decide the millisecond (see [LineFusion]).
 *
 * Reuses the accuracy checker's tokenizer and global transcript-to-speech aligner, so "twenty five" = "25", case and
 * punctuation never matter. Port of tools/alignment-reference/lexical.py.
 */
internal class LexicalLine(
    /** Estimated start of the line's speech, recording clock (ms). */
    val startMs: Long,
    /** Estimated end of the line's speech (ms). */
    val endMs: Long,
    /** Words in the line. */
    val n: Int,
    /** Words of the line the recognizer confirmed (anywhere in the recording). */
    val matched: Int,
    /** Index of the first confirmed word (0 = the line's first word). */
    val first: Int,
    /** Recognizer confidence of the word the start was read from. */
    val anchorConf: Double,
    val meanConf: Double,
    /** Start times of the confirmed words (ms). */
    val timesMs: LongArray
) {
    /** Enough confirmed words, early enough in the line, with a believable recognizer confidence, to place the line. */
    val isStrong: Boolean
        get() {
            val need = min(3, n)
            return matched >= need && first <= 3 && anchorConf >= 0.5 && matched.toDouble() / n >= 0.4
        }
}

internal object LexicalAnchors {

    private fun wordMs(len: Int): Long = 80L + 45L * len

    /** One entry per script line: null when none of its words was heard. */
    fun compute(texts: List<String>, spoken: List<SpokenWord>): List<LexicalLine?> {
        if (texts.isEmpty()) return emptyList()
        val settings = CheckSettings()
        val (tokens, ranges) = CheckTokenizer.tokenizeTranscript(texts.map { CheckSegment(0L, it) }, settings)
        val heard = CheckTokenizer.tokenizeSpoken(spoken, settings)
        val intern = HashMap<String, Int>()
        for (x in tokens) x.nid = intern.getOrPut(x.norm) { intern.size }
        for (x in heard) x.nid = intern.getOrPut(x.norm) { intern.size }
        val pairT = CheckAligner(tokens, heard, CheckAligner.MAX_CELLS, CheckAligner.BAND, CheckAligner.MAX_BAND_CELLS).pairT

        val out = ArrayList<LexicalLine?>(texts.size)
        for (k in texts.indices) {
            val t0 = ranges[k][0]
            val t1 = ranges[k][1]
            val n = t1 - t0
            val eq = ArrayList<Int>()
            for (i in t0 until t1) if (pairT[i] >= 0 && heard[pairT[i]].nid == tokens[i].nid) eq.add(i)
            if (n == 0 || eq.isEmpty()) {
                out.add(null)
                continue
            }
            val f = eq.first()
            val sw = heard[pairT[f]]
            var before = 0L                       // words before it that were not heard: they were spoken too
            for (x in t0 until f) before += wordMs(tokens[x].len)
            val last = eq.last()
            val ew = heard[pairT[last]]
            var after = 0L
            for (x in last + 1 until t1) after += wordMs(tokens[x].len)
            var confSum = 0.0
            val times = LongArray(eq.size)
            for ((x, i) in eq.withIndex()) {
                confSum += heard[pairT[i]].conf
                times[x] = heard[pairT[i]].start
            }
            out.add(
                LexicalLine(
                    startMs = sw.start - before,
                    endMs = (ew.end + after).toDouble().roundToLong(),
                    n = n, matched = eq.size, first = f - t0,
                    anchorConf = sw.conf, meanConf = confSum / eq.size, timesMs = times
                )
            )
        }
        return out
    }
}
