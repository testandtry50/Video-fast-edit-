package com.videoslidemaker.app.ui.screens

import com.videoslidemaker.app.ui.theme.Outline
import com.videoslidemaker.app.ui.components.AppProgressBar
import androidx.compose.ui.semantics.Role
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.videoslidemaker.app.align.AlignmentFormat
import com.videoslidemaker.app.data.ScriptParser
import com.videoslidemaker.app.model.UiState
import com.videoslidemaker.app.ui.components.PrimaryButton
import com.videoslidemaker.app.ui.components.SecondaryButton
import com.videoslidemaker.app.ui.components.SectionCard
import com.videoslidemaker.app.ui.theme.Accent
import com.videoslidemaker.app.ui.theme.BorderColor
import com.videoslidemaker.app.ui.theme.Muted
import com.videoslidemaker.app.ui.theme.Red
import com.videoslidemaker.app.ui.theme.Surface
import com.videoslidemaker.app.ui.theme.TextMain
import com.videoslidemaker.app.ui.theme.Yellow
import com.videoslidemaker.app.viewmodel.AppViewModel

/** The step buttons, in milliseconds, with the text each one shows. */
private val NUDGES = listOf(
    -1000L to "−1",
    -500L to "−0.5",
    -100L to "−0.1",
    100L to "+0.1",
    500L to "+0.5",
    1000L to "+1"
)

/**
 * Match screen: hear the part of YOUR recording that belongs to the current sentence, and nudge
 * its start or end earlier/later until it lines up with the words.
 *
 * Nothing is cut out of the recording — it is opened once and played from the sentence's
 * timestamp to the next sentence's timestamp, so every sentence is its own "part" automatically.
 */
@Composable
fun OriginalAudioPanel(
    state: UiState,
    viewModel: AppViewModel,
    index: Int,
    onPickRecording: () -> Unit,
    modifier: Modifier = Modifier
) {
    val slide = state.slides.getOrNull(index) ?: return
    val next = state.slides.getOrNull(index + 1)
    val a = state.alignment
    val startMs = ScriptParser.secondsToMillis(slide.timestampSec)
    val endMs = next?.let { ScriptParser.secondsToMillis(it.timestampSec) }
        ?: (startMs + state.settings.defaultDurationSec * 1000L)

    // Never leave a clip playing after moving to another sentence or another screen.
    DisposableEffect(index) { onDispose { viewModel.stopOriginalClip() } }

    var message by remember(index) { mutableStateOf<String?>(null) }

    SectionCard(title = "🎧 Original recording", modifier = modifier) {
        if (a.recordingUri == null) {
            Text(
                "Choose the recording this script was made from, and you can hear its original sound for each sentence here and fix the timing.",
                style = MaterialTheme.typography.bodySmall,
                color = Muted,
                modifier = Modifier.padding(bottom = 8.dp)
            )
            SecondaryButton("🎙️ Choose the recording", onClick = onPickRecording)
            return@SectionCard
        }

        a.recordingName?.let {
            Text(it, style = MaterialTheme.typography.bodySmall, color = Muted, maxLines = 1, modifier = Modifier.padding(bottom = 6.dp))
        }

        PlayRow(viewModel = viewModel, startMs = startMs, endMs = endMs)

        message?.let {
            Text(it, color = Yellow, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 6.dp))
        }

        Text(
            "Listen, then nudge in seconds until the sentence starts and ends where the words do. It replays after every nudge.",
            style = MaterialTheme.typography.bodySmall,
            color = Muted,
            modifier = Modifier.padding(top = 10.dp)
        )

        NudgeRow(
            label = "Starts",
            valueMs = startMs,
            onNudge = { delta -> message = viewModel.nudgeTimestamp(index, delta) }
        )
        if (next != null) {
            NudgeRow(
                label = "Ends",
                valueMs = endMs,
                onNudge = { delta -> message = viewModel.nudgeTimestamp(index + 1, delta) }
            )
            Text(
                "A sentence ends where the next one starts, so “Ends” moves the next sentence's start.",
                style = MaterialTheme.typography.bodySmall,
                color = Muted,
                modifier = Modifier.padding(top = 4.dp)
            )
        } else {
            Text(
                "Ends ${AlignmentFormat.clock(endMs)} — the last sentence lasts for your default duration.",
                style = MaterialTheme.typography.bodySmall,
                color = Muted,
                modifier = Modifier.padding(top = 10.dp)
            )
        }

        // What the automatic analysis (Script screen) found, if it has been run for this sentence.
        val item = a.items.firstOrNull { it.index == index && it.text == slide.text }
        val detected = item?.detectedMs
        if (item != null && detected != null && detected != startMs) {
            val end = item.detectedEndMs?.let { ", speech ends about ${AlignmentFormat.clock(it)}" } ?: ""
            Text(
                "The analysis found it starts at ${AlignmentFormat.clock(detected)} " +
                    "(${AlignmentFormat.signedSeconds(detected - startMs)} from now)$end.",
                style = MaterialTheme.typography.bodySmall,
                color = Muted,
                modifier = Modifier.padding(top = 10.dp)
            )
            SecondaryButton("Use the detected start", onClick = {
                viewModel.applyAlignmentCorrection(index)
                viewModel.playCurrentOriginal()
                message = null
            })
        }

        slide.originalTimestampSec?.let { original ->
            SecondaryButton("↩ Reset start to ${AlignmentFormat.clock(ScriptParser.secondsToMillis(original))}", onClick = {
                message = viewModel.restoreOriginalTime(index)
            })
        }

        Text(
            "Your script's original timestamps are always kept. “Restore all original timestamps” on the Script screen puts everything back.",
            style = MaterialTheme.typography.bodySmall,
            color = Muted,
            modifier = Modifier.padding(top = 8.dp)
        )
    }
}

/** Play / stop plus a progress line. Split out because it is the only part that changes while a clip plays. */
@Composable
private fun PlayRow(viewModel: AppViewModel, startMs: Long, endMs: Long) {
    val clip by viewModel.clip.collectAsState()
    val busy = clip.playing || clip.loading
    val seconds = (endMs - startMs).coerceAtLeast(0L) / 1000.0

    PrimaryButton(
        if (busy) "⏹ Stop" else "▶ Play original (${"%.1f".format(seconds)} s)",
        onClick = { if (busy) viewModel.stopOriginalClip() else viewModel.playCurrentOriginal() }
    )
    if (clip.playing) {
        val span = (clip.endMs - clip.startMs).coerceAtLeast(1L)
        val fraction = ((clip.positionMs - clip.startMs).toFloat() / span).coerceIn(0f, 1f)
        AppProgressBar(fraction, Modifier.padding(top = 6.dp))
        Text(
            "${AlignmentFormat.clock(clip.positionMs)}  of  ${AlignmentFormat.clock(clip.endMs)}",
            style = MaterialTheme.typography.bodySmall,
            color = Muted,
            fontFamily = FontFamily.Monospace,
            modifier = Modifier.padding(top = 4.dp)
        )
    }
    clip.error?.let {
        Text(it, color = Red, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 6.dp))
    }
}

@Composable
private fun NudgeRow(label: String, valueMs: Long, onNudge: (Long) -> Unit) {
    Column(Modifier.fillMaxWidth().padding(top = 10.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(label, color = TextMain, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
            Text(AlignmentFormat.clock(valueMs), color = TextMain, style = MaterialTheme.typography.bodyMedium, fontFamily = FontFamily.Monospace)
        }
        Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            for ((delta, text) in NUDGES) NudgeButton(text, onClick = { onNudge(delta) })
        }
    }
}

/** A small step button. Built from a Box (not Button) so six of them always fit side by side on a phone. */
@Composable
private fun RowScope.NudgeButton(text: String, onClick: () -> Unit) {
    Box(
        Modifier
            .weight(1f)
            .heightIn(min = 48.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(Surface)
            .border(1.dp, Outline, RoundedCornerShape(10.dp))
            .clickable(role = Role.Button, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = TextMain, style = MaterialTheme.typography.labelMedium, maxLines = 1)
    }
}
