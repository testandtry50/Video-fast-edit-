package com.videoslidemaker.app.align

import java.util.concurrent.CancellationException
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Corrects script timestamps against the real audio. The audio is the source of truth.
 *
 * ## How it works (all times are integer milliseconds)
 * 1. **Speech map.** [SpeechAnalysis] marks where speech is in the recording, finds each onset
 *    (the foot of the rise out of the background, not the late threshold crossing), and also
 *    finds loudness dips inside continuous speech as weaker "maybe a new line starts here" points.
 * 2. **Coarse drift search.** [CoarseDrift] estimates, window by window over the WHOLE recording
 *    and over ±40 s, how far the script is from the audio. Nothing assumes the error is small or
 *    constant; the lag is free to change from window to window, which is what drift is.
 * 3. **Per-line alignment.** Each script line independently chooses one candidate boundary near
 *    its expected place. A dynamic program picks the combination that best explains the audio:
 *    onsets that follow real pauses are preferred; consecutive lines must be in order; the
 *    audio between two onsets must contain about as much speech as the text of the earlier line
 *    would take to say; and neighbouring lines should have similar errors (but only mildly — a
 *    line may differ from its neighbours when the audio says so). Lines with no matching speech
 *    (or speech with no line) can be skipped at a price, so one bad line can't derail the rest.
 * 4. **Re-centre and repeat.** Confident anchors give a local drift curve, which re-centres each
 *    line's search window, and the speaking rate is re-estimated. Two repeats.
 * 5. **Confidence.** Every line gets a score from how much worse the best *different* answer is,
 *    how clear the pause before it was, how well the speech length matches the text, how clean the
 *    recording is, and whether the fine result agrees with the independent coarse drift estimate.
 *    A line is only [HIGH_CONFIDENCE] if all of those are good.
 *
 * ## What it can NOT do
 * It does not recognise words. It checks pause structure and how long the speech lasts against
 * how long the text should take. If the recording and script are different content but happen to
 * have similar rhythm, it can't tell. Wrong-looking results are therefore flagged, never forced.
 */
object TimestampAligner {

    /** Confidence at or above this is "high": safe to apply automatically. */
    const val HIGH_CONFIDENCE = 0.80f

    /** A timestamp within this of the detected time is reported as already matching. */
    const val MATCH_TOLERANCE_MS = 100L

    private const val INF = 1e18
    private const val SKIP_COST = 6.0
    private const val MAX_SKIP = 2
    private const val MAX_CANDS = 64
    private const val RADIUS_MS = 2500
    private const val PASSES = 3
    private const val MIN_ONSET_GAP_MS = 150.0
    private const val MIN_FRAMES = 300

    // ------------------------------------------------------------------------------------
    // Public entry point
    // ------------------------------------------------------------------------------------

    /**
     * @param frames        10 ms energy frames of the recording ([EnergyFrameExtractor]).
     * @param timeOffsetMs  recording time of frame 0 (where the audio track starts), usually 0.
     * @param originalMs    the script's timestamps, in script order.
     * @param texts         the script's sentences, same order.
     */
    fun align(
        frames: FloatArray,
        timeOffsetMs: Long,
        originalMs: List<Long>,
        texts: List<String>,
        onStage: (String) -> Unit = {},
        isCancelled: () -> Boolean = { false }
    ): AlignmentResult {
        require(originalMs.size == texts.size) { "Every timestamp needs its text." }
        val n = originalMs.size
        if (n == 0) return AlignmentResult(emptyList(), 0f, emptyList())
        if (frames.size < MIN_FRAMES) {
            return noResult(originalMs, texts, 0f, "The recording is too short to analyse.")
        }

        onStage("Finding speech…")
        val speech = SpeechAnalysis.detect(frames)
        val runs = SpeechAnalysis.refineEdges(SpeechAnalysis.runs(speech.mask), frames, speech.noiseDb)
        val dips = SpeechAnalysis.dips(frames, runs)
        if (isCancelled()) throw CancellationException()

        val hop = EnergyFrameExtractor.HOP_MS
        val prefix = IntArray(speech.mask.size + 1)
        for (i in speech.mask.indices) prefix[i + 1] = prefix[i] + (if (speech.mask[i]) 1 else 0)

        // ---- boundaries: run starts (strong) and dips (weak), sorted by time
        val bounds = ArrayList<Bound>()
        var prevEnd = 0
        for (r in runs) {
            val pauseMs = (r[0] - prevEnd) * hop
            val ev = min(1.0, pauseMs / 350.0)
            bounds.add(Bound(r[0] * hop, 0, ev, 3.0 * (1.0 - ev), r[0]))
            prevEnd = r[1]
        }
        for (d in dips) {
            val depth = min(1.0, d.depthDb / 12.0)
            bounds.add(Bound(d.frame * hop, 1, 0.55 * depth, 4.5 - 1.5 * depth, d.frame))
        }
        bounds.sortWith(compareBy<Bound>({ it.timeMs }, { it.kind }))

        val nb = bounds.size
        val m = Model(
            t = IntArray(n) { (originalMs[it] - timeOffsetMs).toInt() },
            u = DoubleArray(n) { TextUnits.of(texts[it]) },
            bt = IntArray(nb) { bounds[it].timeMs },
            kind = IntArray(nb) { bounds[it].kind },
            ev = DoubleArray(nb) { bounds[it].evidence },
            bc = DoubleArray(nb) { bounds[it].cost },
            sArr = DoubleArray(nb) { prefix[min(bounds[it].frame, speech.mask.size)] * hop.toDouble() }
        )

        onStage("Measuring drift…")
        val coarse = CoarseDrift.estimate(m.t, m.u, speech.mask)
        if (isCancelled()) throw CancellationException()
        val coarseShift = arrayOfNulls<CoarseShift>(n)
        var centers = IntArray(n)
        for (i in 0 until n) {
            val s = CoarseDrift.shiftAt(coarse, m.t[i])
            coarseShift[i] = s
            centers[i] = if (s == null) m.t[i] else m.t[i] + s.ms.roundToInt()
        }

        onStage("Aligning lines…")
        var rho = 1.0
        var dp = runDp(m, centers, RADIUS_MS, rho, isCancelled)
        var finalCenters = centers
        for (pass in 1 until PASSES) {
            val tsList = ArrayList<Int>()
            val shList = ArrayList<Int>()
            for (i in 0 until n) {
                val k = dp.best[i]
                if (k < 0) continue
                val j = dp.cands[i][k]
                if (m.kind[j] == 0 && m.ev[j] >= 0.7 &&
                    margin(m, dp.cands[i], dp.marg[i]!!, k, dp.skipM[i]) >= 3.0
                ) {
                    tsList.add(m.t[i])
                    shList.add(m.bt[j] - m.t[i])
                }
            }
            if (shList.size < 3) break
            val ts = tsList.toIntArray()
            val sh = shList.toIntArray()
            centers = IntArray(n) { i -> m.t[i] + driftAt(ts, sh, m.t[i]).roundToInt() }
            rho = estimateRho(m, dp, rho)
            dp = runDp(m, centers, RADIUS_MS, rho, isCancelled)
            finalCenters = centers
        }

        onStage("Scoring confidence…")
        val clarity = speech.clarityDb.toDouble()
        val conf = confidence(m, dp, rho, clarity, coarse, coarseShift, finalCenters, texts)

        // ---- speech end for each matched line
        val runStart = IntArray(runs.size) { runs[it][0] * hop }
        val runEnd = IntArray(runs.size) { runs[it][1] * hop }
        val matched = (0 until n).filter { dp.best[it] >= 0 }
        val nextMatchedStart = HashMap<Int, Int>()
        for (x in matched.indices) {
            val i = matched[x]
            if (x + 1 < matched.size) {
                val q = matched[x + 1]
                nextMatchedStart[i] = m.bt[dp.cands[q][dp.best[q]]]
            }
        }

        val items = ArrayList<AlignmentItem>(n)
        for (i in 0 until n) {
            val k = dp.best[i]
            if (k < 0) {
                items.add(unmatchedItem(i, texts[i], originalMs[i]))
                continue
            }
            val startInternal = m.bt[dp.cands[i][k]]
            val detected = startInternal.toLong() + timeOffsetMs
            val limit = nextMatchedStart[i] ?: (startInternal + 30000)
            val expectedMs = m.u[i] / TextUnits.RATE0 * rho * 1000.0
            val endInternal = findEnd(runStart, runEnd, startInternal, limit, expectedMs)
            val c = conf[i]!!
            val confF = c.value.toFloat()
            val diff = detected - originalMs[i]
            val status = when {
                confF >= HIGH_CONFIDENCE && abs(diff) <= MATCH_TOLERANCE_MS -> AlignmentStatus.MATCHES
                confF >= HIGH_CONFIDENCE -> AlignmentStatus.HIGH_CONFIDENCE
                else -> AlignmentStatus.NEEDS_REVIEW
            }
            items.add(
                AlignmentItem(
                    index = i,
                    text = texts[i],
                    originalMs = originalMs[i],
                    currentMs = originalMs[i],
                    detectedMs = detected,
                    detectedEndMs = endInternal?.let { it.toLong() + timeOffsetMs },
                    confidence = confF,
                    status = status,
                    reason = if (status == AlignmentStatus.NEEDS_REVIEW) (c.reason ?: "Not confident enough.") else null
                )
            )
        }

        return AlignmentResult(items, speech.clarityDb, driftCurve(coarse, items, timeOffsetMs))
    }

    // ------------------------------------------------------------------------------------
    // Model
    // ------------------------------------------------------------------------------------

    /** A candidate line-start in the audio. [frame] is its 10 ms frame index (for the speech-mass lookup). */
    private class Bound(val timeMs: Int, val kind: Int, val evidence: Double, val cost: Double, val frame: Int)

    private class Model(
        /** the script's timestamps on the recording's clock (original − offset) */
        val t: IntArray,
        /** how long each line takes to say, in syllable-like units */
        val u: DoubleArray,
        /** candidate boundary times, ascending */
        val bt: IntArray,
        /** 0 = start of a speech run, 1 = loudness dip inside speech */
        val kind: IntArray,
        /** how clearly the boundary stands out (0..1) */
        val ev: DoubleArray,
        /** how costly it is to pick this boundary (lower = more likely a real line start) */
        val bc: DoubleArray,
        /** milliseconds of speech between time 0 and this boundary */
        val sArr: DoubleArray
    ) {
        val n: Int get() = t.size
    }

    private class DpResult(
        val cands: Array<IntArray>,
        /** index INTO cands[i] of the chosen boundary, or -1 if line i is unmatched */
        val best: IntArray,
        /** best total path cost forced through each candidate of line i */
        val marg: Array<DoubleArray?>,
        /** best total path cost if line i were skipped (unmatched) */
        val skipM: DoubleArray
    )

    private class Confidence(val value: Double, val reason: String?)

    // ------------------------------------------------------------------------------------
    // Dynamic program
    // ------------------------------------------------------------------------------------

    private fun lowerBound(a: IntArray, v: Int): Int {
        var lo = 0
        var hi = a.size
        while (lo < hi) {
            val mid = (lo + hi) ushr 1
            if (a[mid] < v) lo = mid + 1 else hi = mid
        }
        return lo
    }

    private fun upperBound(a: IntArray, v: Int): Int {
        var lo = 0
        var hi = a.size
        while (lo < hi) {
            val mid = (lo + hi) ushr 1
            if (a[mid] <= v) lo = mid + 1 else hi = mid
        }
        return lo
    }

    private fun candidatesFor(m: Model, center: Int, radius: Int): IntArray {
        val lo = lowerBound(m.bt, center - radius)
        val hi = upperBound(m.bt, center + radius)
        if (hi <= lo) return IntArray(0)
        if (hi - lo <= MAX_CANDS) return IntArray(hi - lo) { lo + it }
        val nearest = (lo until hi).sortedBy { abs(m.bt[it] - center) }.take(MAX_CANDS).sorted()
        return nearest.toIntArray()
    }

    /**
     * Cost of line [p] starting at candidate a and line [j] (j > p) starting at candidate b, for
     * every (a, b): similar error to the neighbour (weak), and the audio between the two onsets
     * must contain about as much speech as line p's text needs. Written into [tot] and the
     * mass-only part into [cm], both laid out as [a * cb.size + b].
     */
    private fun edgeCost(
        m: Model, p: Int, j: Int, ca: IntArray, cb: IntArray, rho: Double,
        tot: DoubleArray, cm: DoubleArray
    ) {
        val nb = cb.size
        val expected = m.u[p] / TextUnits.RATE0 * rho
        val tj = m.t[j].toDouble()
        val tp = m.t[p].toDouble()
        val skipCost = SKIP_COST * (j - p - 1)
        for (a in ca.indices) {
            val ta = m.bt[ca[a]].toDouble()
            val sa = m.sArr[ca[a]]
            for (b in 0 until nb) {
                val tb = m.bt[cb[b]].toDouble()
                val dshift = (tb - tj) - (ta - tp)
                val cd = min(abs(dshift) / 1000.0, 2.0) / 1.5
                val mass = (m.sArr[cb[b]] - sa) / 1000.0
                val c = massCost(mass, expected)
                cm[a * nb + b] = c
                tot[a * nb + b] = if (tb - ta < MIN_ONSET_GAP_MS) INF else cd + c + skipCost
            }
        }
    }

    /** How badly [massSec] of speech matches [expectedSec] (log-ratio, capped so one bad pair can't dominate). */
    private fun massCost(massSec: Double, expectedSec: Double): Double {
        val lr = ln((max(massSec, 0.0) + 0.3) / (expectedSec + 0.3))
        return min(lr * lr / (2.0 * 0.45 * 0.45), 4.0)
    }

    private fun runDp(m: Model, centers: IntArray, radius: Int, rho: Double, isCancelled: () -> Boolean): DpResult {
        val n = m.n
        val cands = Array(n) { candidatesFor(m, centers[it], radius) }
        val has = BooleanArray(n) { cands[it].isNotEmpty() }
        val hasBefore = IntArray(n + 1)
        for (i in 0 until n) hasBefore[i + 1] = hasBefore[i] + (if (has[i]) 1 else 0)
        val totalHas = hasBefore[n]

        // unary cost: how line-start-like the boundary is, plus a gentle pull towards the expected place
        val un = Array(n) { i ->
            if (!has[i]) DoubleArray(0)
            else DoubleArray(cands[i].size) { a ->
                val j = cands[i][a]
                m.bc[j] + 0.5 * min(abs(m.bt[j] - centers[i]).toDouble(), 4000.0) / 4000.0
            }
        }

        // predecessors: the nearest earlier lines that have candidates (so a line can be skipped)
        val preds = Array(n) { IntArray(0) }
        for (j in 0 until n) {
            if (!has[j]) continue
            val list = ArrayList<Int>(MAX_SKIP + 1)
            var skippedWithCands = 0
            var p = j - 1
            while (p >= 0 && skippedWithCands <= MAX_SKIP) {
                if (has[p]) {
                    list.add(p)
                    skippedWithCands++
                }
                p--
            }
            preds[j] = list.toIntArray()
        }

        val tot = DoubleArray(MAX_CANDS * MAX_CANDS)
        val cm = DoubleArray(MAX_CANDS * MAX_CANDS)

        // ---- forward pass
        val f = arrayOfNulls<DoubleArray>(n)
        val ptrSeg = arrayOfNulls<IntArray>(n)
        val ptrIdx = arrayOfNulls<IntArray>(n)
        for (j in 0 until n) {
            if (!has[j]) continue
            if ((j and 63) == 0 && isCancelled()) throw CancellationException()
            val cj = cands[j]
            val nbj = cj.size
            val lead = if (hasBefore[j] <= MAX_SKIP) SKIP_COST * j else INF
            val fj = DoubleArray(nbj) { b -> un[j][b] + lead }
            val ps = IntArray(nbj) { -1 }
            val pa = IntArray(nbj) { -1 }
            for (p in preds[j]) {
                val ca = cands[p]
                edgeCost(m, p, j, ca, cj, rho, tot, cm)
                val fp = f[p]!!
                for (b in 0 until nbj) {
                    var bestV = INF
                    var bestA = -1
                    for (a in ca.indices) {
                        val v = fp[a] + tot[a * nbj + b]
                        if (v < bestV) {
                            bestV = v
                            bestA = a
                        }
                    }
                    if (bestA < 0) continue
                    val vb = bestV + un[j][b]
                    if (vb < fj[b]) {
                        fj[b] = vb
                        ps[b] = p
                        pa[b] = bestA
                    }
                }
            }
            f[j] = fj
            ptrSeg[j] = ps
            ptrIdx[j] = pa
        }

        // ---- backward pass, also gathering "what if line s were skipped" costs
        val succs = Array(n) { ArrayList<Int>() }
        for (j in 0 until n) for (p in preds[j]) succs[p].add(j)
        val bk = arrayOfNulls<DoubleArray>(n)
        val skipM = DoubleArray(n) { INF }
        for (i in n - 1 downTo 0) {
            if (!has[i]) continue
            val ci = cands[i]
            val hasAfter = totalHas - hasBefore[i + 1]
            val trail = if (hasAfter <= MAX_SKIP) SKIP_COST * (n - 1 - i) else INF
            val cur = DoubleArray(ci.size) { trail }
            val fi = f[i]!!
            for (j in succs[i]) {
                val cj = cands[j]
                val nbj = cj.size
                edgeCost(m, i, j, ci, cj, rho, tot, cm)
                val bj = bk[j]!!
                val uj = un[j]
                var skipBest = INF
                for (a in ci.indices) {
                    var mn = INF
                    for (b in 0 until nbj) {
                        val v = tot[a * nbj + b] + uj[b] + bj[b]
                        if (v < mn) mn = v
                    }
                    if (mn < cur[a]) cur[a] = mn
                    if (j - i >= 2) {
                        val w = fi[a] + mn
                        if (w < skipBest) skipBest = w
                    }
                }
                if (j - i >= 2) {
                    for (s in i + 1 until j) if (skipBest < skipM[s]) skipM[s] = skipBest
                }
            }
            bk[i] = cur
        }

        // ---- best path
        val best = IntArray(n) { -1 }
        var bestTotal = 2 * INF
        var bi = -1
        var ba = -1
        for (i in 0 until n) {
            if (!has[i]) continue
            val hasAfter = totalHas - hasBefore[i + 1]
            val endCost = if (hasAfter <= MAX_SKIP) SKIP_COST * (n - 1 - i) else INF
            val fi = f[i]!!
            for (a in fi.indices) {
                val v = fi[a] + endCost
                if (v < bestTotal) {
                    bestTotal = v
                    bi = i
                    ba = a
                }
            }
        }
        val marg = arrayOfNulls<DoubleArray>(n)
        if (bi >= 0) {
            var i = bi
            var a = ba
            while (true) {
                best[i] = a
                val ps = ptrSeg[i]!![a]
                if (ps < 0) break
                val pa = ptrIdx[i]!![a]
                i = ps
                a = pa
            }
            for (x in 0 until n) {
                if (!has[x]) continue
                val fx = f[x]!!
                val bx = bk[x]!!
                marg[x] = DoubleArray(fx.size) { fx[it] + bx[it] }
            }
        }
        return DpResult(cands, best, marg, skipM)
    }

    /** Nats by which the best DIFFERENT answer (≥ 250 ms away, or skipping the line) is worse; capped at 6. */
    private fun margin(m: Model, cands: IntArray, marg: DoubleArray, k: Int, skipVal: Double): Double {
        val chosen = m.bt[cands[k]]
        var bestOther = INF
        for (a in cands.indices) {
            if (abs(m.bt[cands[a]] - chosen) < 250) continue
            val v = marg[a] - marg[k]
            if (v < bestOther) bestOther = v
        }
        val sv = skipVal - marg[k]
        var result = 6.0
        if (bestOther < INF / 2) result = min(result, bestOther)
        if (sv < INF / 2) result = min(result, sv)
        return result
    }

    // ------------------------------------------------------------------------------------
    // Drift & speaking-rate refinement
    // ------------------------------------------------------------------------------------

    /** Robust local shift: median of confident anchors within ±120 s, else of the 3 nearest anchors. */
    private fun driftAt(ts: IntArray, shifts: IntArray, t: Int): Double {
        val inside = ArrayList<Int>()
        for (x in ts.indices) if (abs(ts[x] - t) <= 120000) inside.add(shifts[x])
        if (inside.size >= 3) return medianOf(inside)
        val order = ts.indices.sortedBy { abs(ts[it] - t) }.take(3)
        return medianOf(order.map { shifts[it] })
    }

    private fun medianOf(values: List<Int>): Double {
        val sorted = values.sorted()
        val n = sorted.size
        return if (n % 2 == 1) sorted[n / 2].toDouble() else (sorted[n / 2 - 1] + sorted[n / 2]) / 2.0
    }

    /** Observed speech per unit of text between confident adjacent onsets, relative to the assumed rate. */
    private fun estimateRho(m: Model, dp: DpResult, current: Double): Double {
        val ratios = ArrayList<Double>()
        var prev = -1
        for (i in 0 until m.n) {
            if (dp.best[i] < 0) continue
            if (prev >= 0 && i - prev == 1) {
                val jp = dp.cands[prev][dp.best[prev]]
                val jq = dp.cands[i][dp.best[i]]
                if (m.ev[jp] >= 0.7 && m.ev[jq] >= 0.7 && m.kind[jp] == 0 && m.kind[jq] == 0) {
                    ratios.add((m.sArr[jq] - m.sArr[jp]) / 1000.0 / (m.u[prev] / TextUnits.RATE0))
                }
            }
            prev = i
        }
        if (ratios.size < 3) return current
        ratios.sort()
        val n = ratios.size
        val med = if (n % 2 == 1) ratios[n / 2] else (ratios[n / 2 - 1] + ratios[n / 2]) / 2.0
        return min(2.0, max(0.5, med))
    }

    // ------------------------------------------------------------------------------------
    // Confidence
    // ------------------------------------------------------------------------------------

    private fun confidence(
        m: Model, dp: DpResult, rho: Double, clarityDb: Double,
        coarse: List<CoarseWindow>, coarseShift: Array<CoarseShift?>,
        centers: IntArray, texts: List<String>
    ): Array<Confidence?> {
        val n = m.n
        val out = arrayOfNulls<Confidence>(n)
        // mass cost of each matched line's own span (onset → next matched onset)
        val spanCost = DoubleArray(n)
        val prevOf = IntArray(n) { -1 }
        var prev = -1
        for (i in 0 until n) {
            if (dp.best[i] < 0) continue
            if (prev >= 0) {
                prevOf[i] = prev
                if (i - prev - 1 <= MAX_SKIP + 20) {
                    val ja = dp.cands[prev][dp.best[prev]]
                    val jb = dp.cands[i][dp.best[i]]
                    val mass = (m.sArr[jb] - m.sArr[ja]) / 1000.0
                    spanCost[prev] = massCost(mass, m.u[prev] / TextUnits.RATE0 * rho)
                }
            }
            prev = i
        }
        val clarityCap = 0.6 + 0.4 * min(1.0, max(0.0, (clarityDb - 9.0) / 12.0))

        for (i in 0 until n) {
            val k = dp.best[i]
            if (k < 0) continue
            val j = dp.cands[i][k]
            val mg = margin(m, dp.cands[i], dp.marg[i]!!, k, dp.skipM[i])
            val cMargin = 1.0 - exp(-mg / 1.2)
            val f = 0.4 + 0.6 * m.ev[j]
            val neighbourCost = spanCost[i] + (if (prevOf[i] >= 0) spanCost[prevOf[i]] else 0.0)
            val q = exp(-neighbourCost / 8.0)

            var conf = cMargin * f * q
            val hasText = TextUnits.hasContent(texts[i])
            val noisy = clarityCap < HIGH_CONFIDENCE
            conf = min(conf, clarityCap)

            val edge = abs(m.bt[j] - centers[i]).toDouble() / RADIUS_MS >= 0.75
            if (edge) conf = min(conf, 0.5)

            val cs = coarseShift[i]
            val coarseMissing = cs == null || !cs.reliable
            var coarseDisagrees = false
            if (cs != null && cs.reliable) {
                coarseDisagrees = abs((m.bt[j] - m.t[i]) - cs.ms) > 1500.0
            }
            if (coarseMissing || coarseDisagrees) conf = min(conf, 0.5)
            if (!hasText) conf = min(conf, 0.5)

            val reason: String? = if (conf >= HIGH_CONFIDENCE) null else when {
                !hasText -> "This line has no text, so there is nothing to compare with the audio."
                noisy -> "The recording is noisy or unclear, so speech is hard to separate from the background."
                coarseMissing -> "Couldn't confirm this against the recording's overall timing."
                coarseDisagrees -> "Disagrees with the timing pattern of the rest of the recording."
                edge -> "The best match is at the edge of the search range."
                cMargin < 0.8 -> "Another moment in the audio fits almost as well."
                q < 0.6 -> "How long the speech lasts doesn't match how long the text should take."
                f < 0.7 -> "There is no clear pause before this line, so its start is hard to pinpoint."
                else -> "Not confident enough."
            }
            out[i] = Confidence(conf, reason)
        }
        return out
    }

    // ------------------------------------------------------------------------------------
    // Speech end
    // ------------------------------------------------------------------------------------

    /**
     * Where the line that starts at [startMs] stops being spoken: the end of the speech run it
     * starts in, extended through following runs separated by under 600 ms, but never past the
     * next line's start ([limitMs]) or past what the text could plausibly take.
     */
    private fun findEnd(runStart: IntArray, runEnd: IntArray, startMs: Int, limitMs: Int, expectedMs: Double): Int? {
        // first run that ends after startMs
        var lo = 0
        var hi = runEnd.size
        while (lo < hi) {
            val mid = (lo + hi) ushr 1
            if (runEnd[mid] <= startMs) lo = mid + 1 else hi = mid
        }
        if (lo >= runStart.size) return null
        if (runStart[lo] > startMs + 200) return null
        var cur = lo
        var end = min(runEnd[cur], limitMs)
        while (true) {
            val nx = cur + 1
            if (nx >= runStart.size || runStart[nx] >= limitMs) break
            if (runStart[nx] - runEnd[cur] > 600) break
            if (runEnd[nx] - startMs > 2.2 * expectedMs + 1500.0) break
            cur = nx
            end = min(runEnd[nx], limitMs)
        }
        return end
    }

    // ------------------------------------------------------------------------------------
    // Output helpers
    // ------------------------------------------------------------------------------------

    private fun unmatchedItem(index: Int, text: String, originalMs: Long) = AlignmentItem(
        index = index,
        text = text,
        originalMs = originalMs,
        currentMs = originalMs,
        detectedMs = null,
        detectedEndMs = null,
        confidence = 0f,
        status = AlignmentStatus.NEEDS_REVIEW,
        reason = "No matching speech was found for this line, so its timestamp was left alone."
    )

    private fun noResult(originalMs: List<Long>, texts: List<String>, clarity: Float, why: String): AlignmentResult {
        val items = originalMs.indices.map { i ->
            unmatchedItem(i, texts[i], originalMs[i]).copy(reason = why)
        }
        return AlignmentResult(items, clarity, emptyList())
    }

    /**
     * The drift curve to show the user: for each trustworthy coarse window, the median fine
     * shift of the confident lines inside it (the coarse lag is only ±100 ms, so it is not shown).
     */
    private fun driftCurve(coarse: List<CoarseWindow>, items: List<AlignmentItem>, offsetMs: Long): List<DriftPoint> {
        val usable = items.filter {
            (it.status == AlignmentStatus.HIGH_CONFIDENCE || it.status == AlignmentStatus.MATCHES) && it.diffMs != null
        }
        if (usable.isEmpty()) return emptyList()
        val points = ArrayList<DriftPoint>()
        for (w in coarse) {
            if (!w.ok) continue
            val centerOriginal = w.centerMs.toLong() + offsetMs
            val near = usable.filter { abs(it.originalMs - centerOriginal) <= 45000 }.map { it.diffMs!!.toInt() }
            if (near.size < 3) continue
            points.add(DriftPoint(centerOriginal, medianOf(near).roundToInt().toLong()))
        }
        return points
    }
}
