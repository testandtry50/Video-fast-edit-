package com.videoslidemaker.app.voicefx

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.tanh

/**
 * Makes a too-clean synthetic voice (text-to-speech, ElevenLabs and similar AI voices) feel like a
 * person in a room with a microphone:
 *  - a tiny, slow, irregular pitch drift (at most about +-10 cents, far below what sounds out of tune),
 *  - a warm low end and a slightly softer top,
 *  - gentle dynamics (a light compressor + soft saturation),
 *  - a very faint room tone (about -51 dBFS at 100%) and a few short room reflections,
 *  - optionally a soft breath in real pauses between phrases ([breaths]).
 *
 * [h] is the strength, 0..1. At 0 (with breaths off) nothing at all is added.
 * Output is stereo (the reflections differ a little between the ears).
 */
class Humanizer(private val fs: Int, private val h: Double, private val breaths: Boolean, seed: Int) {
    private val rng = Rng(seed)
    private val wobbleOn = h > 0.001
    private val base: Int = Math.round(BASE_DELAY_S * fs).toInt()

    /** Delay added by the pitch-drift line; the caller removes it. */
    val latencyFrames: Int = if (wobbleOn) base else 0

    private val depth = 0.0008 * h * fs
    private val dly = DelayLine(base + depth.toInt() + 8)
    private val ph = doubleArrayOf(0.0, 1.3, 4.1)
    private val inc = doubleArrayOf(TWO_PI * 0.37 / fs, TWO_PI * 1.13 / fs, TWO_PI * 3.7 / fs)
    private val low = Biquad().lowShelf(fs, 180.0, 2.2 * h)
    private val high = Biquad().highShelf(fs, 7000.0, -3.0 * h)

    // compressor / saturation
    private val thr = 0.07
    private val ratio = 1.0 + 1.4 * h
    private val att = exp(-1.0 / (0.006 * fs))
    private val rel = exp(-1.0 / (0.160 * fs))
    private var env = 0.0
    private val makeup = 10.0.pow(6.0 * (1.0 - 1.0 / ratio) / 20.0)
    private val drive = 1.0 + 0.8 * h

    // room tone
    private val toneLp = OnePole(fs, 3500.0)
    private val toneHp = Biquad().highpass(fs, 90.0, 0.7)
    private val toneGain = 10.0.pow((-64.0 + 12.0 * h) / 20.0) * NOISE_NORM
    private var tonePh = 0.0
    private val toneInc = TWO_PI * 0.23 / fs

    // room reflections
    private val taps = intArrayOf(
        Math.round(7.0 * 0.001 * fs).toInt(),
        Math.round(13.0 * 0.001 * fs).toInt(),
        Math.round(19.0 * 0.001 * fs).toInt(),
        Math.round(29.0 * 0.001 * fs).toInt()
    )
    private val tapGain = doubleArrayOf(0.22 * h, 0.16 * h, 0.12 * h, 0.08 * h)
    private val refl = DelayLine(taps[3] + 4)

    // breaths
    private var bEnv = 0.0
    private var bSilence = 0
    private var bSpeech = 0
    private var bArmed = false
    private var bPos = -1
    private var bLen = 0
    private var bAmp = 0.0
    private var bGain = 1.0
    private var bLevel = 0.0
    private val bBp = Biquad().bandpass(fs, 1400.0, 0.7)
    private val bAtt = exp(-1.0 / (0.003 * fs))
    private val bRel = exp(-1.0 / (0.080 * fs))

    private fun breath(x: Double): Double {
        val ax = abs(x)
        val c = if (ax > bEnv) bAtt else bRel
        bEnv = c * bEnv + (1.0 - c) * ax
        val voiced = bEnv > 0.004
        if (voiced) {
            bSpeech++
            bSilence = 0
            if (bEnv > bLevel) bLevel = bEnv
            if (bSpeech > (0.4 * fs).toInt()) bArmed = true
        } else {
            bSpeech = 0
            bSilence++
            bLevel *= 0.99999
            // a breath only after real speech, and only once the pause has lasted 0.2 s
            if (bArmed && bPos < 0 && bSilence >= (0.20 * fs).toInt()) {
                bArmed = false
                bPos = 0
                bLen = ((0.30 + 0.12 * rng.unit()) * fs).toInt()
                bAmp = Math.min(0.012, Math.max(0.001, 0.03 * bLevel))
                bGain = 1.0
            }
        }
        if (bPos < 0) return 0.0
        if (voiced) bGain *= 0.997 // speech resumed: fade the breath out quickly
        val noise = rng.next()
        val shape = sin(PI * bPos / bLen)
        val y = bBp.process(noise) * BREATH_NORM * shape * shape * bAmp * bGain
        bPos++
        if (bPos >= bLen || bGain < 0.001) bPos = -1
        return y
    }

    fun process(x: Double, out: DoubleArray) {
        val breathSample = if (breaths) breath(x) else 0.0
        var y = x
        if (wobbleOn) {
            for (i in 0 until 3) {
                ph[i] += inc[i]
                if (ph[i] > TWO_PI) ph[i] -= TWO_PI
            }
            val m = (sin(ph[0]) + 0.6 * sin(ph[1]) + 0.35 * sin(ph[2])) / 1.95
            dly.write(x)
            y = dly.read(base + depth * m)
            y = high.process(low.process(y))
            // light compressor
            val ay = abs(y)
            val c = if (ay > env) att else rel
            env = c * env + (1.0 - c) * ay
            var g = 1.0
            if (env > thr) g = (env / thr).pow(-(1.0 - 1.0 / ratio))
            y = y * g * makeup
            y = tanh(drive * y) / drive
            // room tone
            tonePh += toneInc
            if (tonePh > TWO_PI) tonePh -= TWO_PI
            val n = toneHp.process(toneLp.process(rng.next()))
            y += n * toneGain * (1.0 + 0.15 * sin(tonePh))
        }
        y += breathSample
        if (!wobbleOn) {
            out[0] = y
            out[1] = y
            return
        }
        refl.write(y)
        out[0] = y + tapGain[0] * refl.readInt(taps[0]) + tapGain[2] * refl.readInt(taps[2])
        out[1] = y + tapGain[1] * refl.readInt(taps[1]) + tapGain[3] * refl.readInt(taps[3])
    }

    private companion object {
        const val BASE_DELAY_S = 0.002

        /** Makes the room-tone chain (noise -> 3.5 kHz low-pass -> 90 Hz high-pass) unit RMS. */
        const val NOISE_NORM = 3.55

        /** Makes the breath chain (noise -> band-pass 1.4 kHz) unit RMS. */
        const val BREATH_NORM = 4.95
    }
}
