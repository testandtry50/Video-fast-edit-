package com.videoslidemaker.app.ui.screens

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.videoslidemaker.app.audio.AiMusicPrompt
import com.videoslidemaker.app.audio.AudioClip
import com.videoslidemaker.app.audio.AudioLimits
import com.videoslidemaker.app.audio.AudioMixSettings
import com.videoslidemaker.app.audio.BgSlots
import com.videoslidemaker.app.audio.SlotFit
import com.videoslidemaker.app.audio.ClipEdit
import com.videoslidemaker.app.audio.ClipTrack
import com.videoslidemaker.app.audio.SmartMixSettings
import com.videoslidemaker.app.audio.SoundProfiles
import com.videoslidemaker.app.model.AppStep
import com.videoslidemaker.app.model.UiState
import com.videoslidemaker.app.ui.components.AlertBox
import com.videoslidemaker.app.ui.components.AlertStyle
import com.videoslidemaker.app.ui.components.CompactButton
import com.videoslidemaker.app.ui.components.PrimaryButton
import com.videoslidemaker.app.ui.components.ScreenTitle
import com.videoslidemaker.app.ui.components.SecondaryButton
import com.videoslidemaker.app.ui.components.SectionCard
import com.videoslidemaker.app.ui.components.SettingToggleRow
import com.videoslidemaker.app.ui.components.appSliderColors
import com.videoslidemaker.app.ui.theme.Accent
import com.videoslidemaker.app.ui.theme.BorderColor
import com.videoslidemaker.app.ui.theme.CardBg
import com.videoslidemaker.app.ui.theme.Green
import com.videoslidemaker.app.ui.theme.Muted
import com.videoslidemaker.app.ui.theme.OnAccent
import com.videoslidemaker.app.ui.theme.Outline
import com.videoslidemaker.app.ui.theme.Red
import com.videoslidemaker.app.ui.theme.Surface
import com.videoslidemaker.app.ui.theme.TextMain
import com.videoslidemaker.app.viewmodel.AppViewModel
import java.util.Locale
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * NEW (2.17): the Audio step. Edit the video's main sound (add, replace, cut, split, remove, join), add any number of
 * background tracks, let the smart mix balance them, and listen to the real mix before exporting.
 */
@Composable
fun AudioScreen(
    state: UiState,
    viewModel: AppViewModel,
    onPickMain: () -> Unit,
    onPickBackground: () -> Unit,
    onPickReplace: (clipId: String) -> Unit
) {
    val audio = state.settings.audio
    val ui by viewModel.audioUi.collectAsState()
    val total = state.totalDurationSec
    val selected = audio.clip(ui.selectedId)
    var listenFrom by remember { mutableStateOf(0f) }

    // Older projects: measure any music whose length was never measured. And never leave a mix playing behind another screen.
    LaunchedEffect(state.projectId) { viewModel.audioReset(); viewModel.audioCheckFiles() }
    LaunchedEffect(selected?.uri) { if (selected != null) viewModel.audioSelect(selected.id) }
    DisposableEffect(Unit) { onDispose { viewModel.audioStopAudition() } }

    Column(
        Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        ScreenTitle(
            "Audio",
            "Edit your main sound, add background music, and let the app mix it so the voice stays clear."
        )

        ui.note?.let { note ->
            AlertBox(note, AlertStyle.INFO, Modifier.padding(bottom = 4.dp))
            SecondaryButton("OK", modifier = Modifier.padding(bottom = 8.dp), onClick = viewModel::audioDismissNote)
        }

        SectionCard(title = "Timeline", modifier = Modifier.padding(bottom = 12.dp)) {
            TimelineOverview(
                // asPlayed = the way the mixer will really play it: "fit the video" tracks stretched over the video and
                // background audio with a start-to-end time cut or repeated to that range. Empty B1 / B2 slots have no sound to draw.
                audio = audio.copy(background = audio.background.filter { !it.isPlaceholder }.map { ClipEdit.asPlayed(it, total) }),
                total = total,
                selectedId = ui.selectedId,
                playhead = if (ui.playing || ui.building) ui.playheadSec else null,
                onSelect = viewModel::audioSelect
            )
            Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("0:00", style = MaterialTheme.typography.labelSmall, color = Muted)
                Text("Tap a bar to edit it", style = MaterialTheme.typography.labelSmall, color = Muted)
                Text(clock(total), style = MaterialTheme.typography.labelSmall, color = Muted)
            }
            Row(Modifier.padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.width(14.dp).height(14.dp).clip(RoundedCornerShape(3.dp)).background(Accent))
                Text("  Main sound      ", style = MaterialTheme.typography.labelMedium, color = TextMain)
                Box(Modifier.width(14.dp).height(14.dp).clip(RoundedCornerShape(3.dp)).background(Green))
                Text("  Background", style = MaterialTheme.typography.labelMedium, color = TextMain)
            }
        }

        SectionCard(title = "Hear the mix", modifier = Modifier.padding(bottom = 12.dp)) {
            Text(
                "Plays 30 seconds of the real result - voice, your edited audio, background music and the automatic lowering.",
                style = MaterialTheme.typography.bodySmall,
                color = Muted
            )
            if (total > 1.0) {
                LabeledSlider("Start at", clock(listenFrom.toDouble()), listenFrom, 0f..(total.toFloat() - 1f)) { listenFrom = it }
            }
            when {
                ui.building -> PrimaryButton("Building the mix…", enabled = false, onClick = {})
                ui.playing -> {
                    Text(
                        "Playing ${clock(ui.playheadSec)}",
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.padding(vertical = 4.dp)
                    )
                    SecondaryButton("■ Stop", onClick = viewModel::audioStopAudition)
                }
                else -> PrimaryButton("▶ Hear 30 seconds", enabled = total > 1.0, onClick = { viewModel.audioAudition(listenFrom.toDouble()) })
            }
        }

        MainSoundCard(audio, ui.selectedId, ui.unreadable, state.alignment.recordingUri?.toString(), viewModel, onPickMain)

        BackgroundCard(audio, ui.selectedId, ui.unreadable, viewModel, onPickBackground)

        if (selected != null && !selected.isPlaceholder && audio.trackOf(selected.id) == ClipTrack.BACKGROUND) {
            // NEW (2.19): mark the part of the ORIGINAL to keep, say what kind of sound it is, and give it to the video or to B1, B2...
            MarkPartCard(selected, ui.peaks[selected.uri], ui, viewModel)
            SoundTypeCard(selected, viewModel)
            if (!BgSlots.isSlot(selected)) AssignCard(selected, audio, viewModel)
        }

        if (selected != null && selected.isPlaceholder) {
            // NEW (2.18): a background slot that is still waiting for its audio file (nothing to edit yet)
            SlotWaitingCard(selected, onChoose = { onPickReplace(selected.id) }, viewModel = viewModel)
        } else if (selected != null) {
            ClipEditorCard(
                clip = selected,
                isMain = audio.trackOf(selected.id) == ClipTrack.MAIN,
                total = total,
                peaks = ui.peaks[selected.uri],
                viewModel = viewModel,
                onReplace = { onPickReplace(selected.id) }
            )
        }

        SmartMixCard(audio, viewModel)

        AiMusicCard(total)

        PrimaryButton("Next — Preview →", modifier = Modifier.padding(top = 8.dp), onClick = { viewModel.goStep(AppStep.PREVIEW) })
        SecondaryButton("← Back to Text", onClick = { viewModel.goStep(AppStep.TEXT) })
    }

    // NEW (2.19): opens when a sound is assigned to B1, B2... (or from the "Kind of sound" card)
    val askClip = audio.clip(ui.askKindFor)
    if (askClip != null && !askClip.isPlaceholder) {
        SoundKindSheet(
            clip = askClip,
            onApply = { k, m -> viewModel.audioSetKind(askClip.id, k, m) },
            onSkip = { viewModel.audioAskKind(null) }
        )
    }
}

// ---------------------------------------------------------------------------------------------
// Main sound and background lists
// ---------------------------------------------------------------------------------------------

@Composable
private fun MainSoundCard(
    audio: AudioMixSettings,
    selectedId: String?,
    unreadable: Set<String>,
    recordingUri: String?,
    viewModel: AppViewModel,
    onPickMain: () -> Unit
) {
    SectionCard(title = "Main sound", modifier = Modifier.padding(bottom = 12.dp)) {
        Text(
            "What the video plays as its main sound: the voice or recording from the Script step, or your own edited audio.",
            style = MaterialTheme.typography.bodySmall,
            color = Muted,
            modifier = Modifier.padding(bottom = 8.dp)
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ModeChip("Script voice", !audio.useCustomMain, Modifier.weight(1f)) { viewModel.audioSetUseCustomMain(false) }
            ModeChip("My edited audio", audio.useCustomMain, Modifier.weight(1f)) { viewModel.audioSetUseCustomMain(true) }
        }
        Spacer(Modifier.height(8.dp))
        SecondaryButton("＋ Add an audio file", onClick = onPickMain)
        if (recordingUri != null && audio.main.none { it.uri == recordingUri }) {
            SecondaryButton("Bring in my Script recording to edit", onClick = viewModel::audioAddRecordingAsMain)
        }
        if (audio.main.size >= 2) {
            SecondaryButton("Join all clips end to end", onClick = viewModel::audioCombineMain)
        }
        if (audio.main.isEmpty()) {
            Text(
                "No clips yet. Add a file to cut, replace or rearrange it. (The voice changer applies to the Script voice and recording only.)",
                style = MaterialTheme.typography.bodySmall,
                color = Muted,
                modifier = Modifier.padding(top = 4.dp)
            )
        } else {
            if (!audio.useCustomMain) {
                Text(
                    "These clips are not used until \"My edited audio\" is chosen above.",
                    style = MaterialTheme.typography.bodySmall,
                    color = Muted,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
            audio.main.sortedBy { it.startSec }.forEach { clip ->
                ClipRow(clip, clip.id == selectedId, clip.id in unreadable) { viewModel.audioSelect(clip.id) }
            }
        }
    }
}

@Composable
private fun BackgroundCard(audio: AudioMixSettings, selectedId: String?, unreadable: Set<String>, viewModel: AppViewModel, onPickBackground: () -> Unit) {
    SectionCard(title = "Background audio", modifier = Modifier.padding(bottom = 12.dp)) {
        Text(
            "Music, ambience or sound effects under the main sound. Add as many tracks as you like. " +
                "To play one only between two moments, press and hold a scene on the Match step and choose \"Add background audio\" - " +
                "it gets a name (B1, B2...) and is cut or repeated to fit. Tap any sound below to see its original, mark just the part you want, " +
                "say what kind of sound it is, and assign it.",
            style = MaterialTheme.typography.bodySmall,
            color = Muted,
            modifier = Modifier.padding(bottom = 8.dp)
        )
        SecondaryButton("＋ Add music or background audio", onClick = onPickBackground)
        // NEW (2.19): the scene audio with its names first (B1, B2...), then every other background sound
        val slots = BgSlots.slots(audio)
        val others = audio.background.filter { !BgSlots.isSlot(it) }.sortedBy { it.startSec }
        if (slots.isNotEmpty()) {
            Text("Scene audio (B1, B2…)", style = MaterialTheme.typography.titleSmall, color = TextMain, modifier = Modifier.padding(top = 8.dp))
            slots.forEach { clip -> ClipRow(clip, clip.id == selectedId, clip.id in unreadable) { viewModel.audioSelect(clip.id) } }
        }
        if (others.isNotEmpty()) {
            Text(
                if (slots.isEmpty()) "Background sounds" else "Other background sounds",
                style = MaterialTheme.typography.titleSmall,
                color = TextMain,
                modifier = Modifier.padding(top = 8.dp)
            )
            others.forEach { clip -> ClipRow(clip, clip.id == selectedId, clip.id in unreadable) { viewModel.audioSelect(clip.id) } }
        }
    }
}

@Composable
private fun ClipRow(clip: AudioClip, selected: Boolean, problem: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(10.dp)
    Column(
        Modifier
            .fillMaxWidth()
            .padding(top = 8.dp)
            .clip(shape)
            .background(if (selected) Accent.copy(alpha = 0.12f) else Surface)
            .border(if (selected) 2.dp else 1.dp, if (selected) Accent else BorderColor, shape)
            .selectable(selected = selected, role = Role.Tab, onClick = onClick)
            .heightIn(min = 56.dp)
            .padding(horizontal = 12.dp, vertical = 8.dp)
    ) {
        // NEW (2.18): a background slot shows its tag first ("B1 · rain.mp3") - or "B1 · no audio file yet"
        val tag = if (clip.slot.isNotBlank()) clip.slot + " · " else ""
        Text(
            (if (selected) "✓ " else "") + tag + (if (clip.isPlaceholder) "no audio file yet" else clip.name) + if (clip.muted) "  (muted)" else "",
            style = MaterialTheme.typography.bodyMedium,
            color = TextMain,
            fontWeight = FontWeight.Medium,
            maxLines = 1
        )
        val where = "starts ${clock(clip.startSec)}"
        val detail = when {
            clip.isPlaceholder ->
                "$where · " + (if (clip.hasRange) "ends ${clock(clip.rangeEndSec)}" else "no end yet") + " · silent until you choose a file"
            clip.hasRange && !clip.fitVideo -> {
                val how = when {
                    clip.isUnmeasured -> "measuring…"
                    BgSlots.fit(clip) is SlotFit.Repeats -> "repeats to fit"
                    BgSlots.fit(clip) is SlotFit.Trimmed -> "cut to fit"
                    else -> "fits exactly"
                }
                "$where · ends ${clock(clip.rangeEndSec)} · $how"
            }
            clip.isUnmeasured -> "$where · measuring…"
            else -> "$where · ${clock(clip.lengthSec)} long" + if (clip.loop) " · repeats" else ""
        }
        // NEW (2.19): what kind of sound it was set as, and whether only a marked part of the original is used
        val kindTag = SoundProfiles.tag(clip)
        val marked = if (clip.hasMark) "marked ${clock(clip.srcStartSec)} – ${clock(clip.markEndSec)} of the original" else ""
        val extra = listOf(kindTag, marked).filter { it.isNotEmpty() }.joinToString(" · ")
        Text(detail + if (extra.isEmpty()) "" else " · $extra", style = MaterialTheme.typography.bodySmall, color = Muted)
        if (problem) {
            Text(
                "⚠ This file can't be opened any more (moved or deleted). It is skipped in the export - open it and tap Replace.",
                style = MaterialTheme.typography.bodySmall,
                color = Red
            )
        }
    }
}

// ---------------------------------------------------------------------------------------------
// The editor for the selected clip
// ---------------------------------------------------------------------------------------------

@Composable
private fun ClipEditorCard(
    clip: AudioClip,
    isMain: Boolean,
    total: Double,
    peaks: FloatArray?,
    viewModel: AppViewModel,
    onReplace: () -> Unit
) {
    val len = clip.lengthSec
    var cutFrom by remember(clip.id) { mutableStateOf((len * 0.3).toFloat()) }
    var cutTo by remember(clip.id) { mutableStateOf((len * 0.5).toFloat()) }
    var closeGap by remember(clip.id) { mutableStateOf(true) }
    val from = cutFrom.coerceIn(0f, len.toFloat())
    val to = cutTo.coerceIn(0f, len.toFloat())
    val lo = minOf(from, to)
    val hi = max(from, to)
    // NEW (2.18): a background slot (B1, B2...) is one audio tied to a start and end time that are set on the Match step
    val isSlot = !isMain && clip.slot.isNotBlank()
    val rangeLocked = isSlot && clip.hasRange && !clip.fitVideo
    // the part of the file that really plays: when it has a time range, the file is cut or repeated to fit it
    val played = if (rangeLocked) ClipEdit.followRange(clip) else clip

    SectionCard(title = "Edit: " + (if (isSlot) clip.slot + " · " else "") + clip.name, modifier = Modifier.padding(bottom = 12.dp)) {
        if (isSlot) {
            Text(
                BgSlots.describeFit(clip) +
                    if (rangeLocked) " Its start and end time are set on the Match step: press and hold a scene there and choose \"Change start / end time\"."
                    else " Press and hold the scene where it should stop on the Match step to give it an end time.",
                style = MaterialTheme.typography.bodySmall,
                color = Muted,
                modifier = Modifier.padding(bottom = 8.dp)
            )
        }
        val fileLength = if (clip.sourceDurationSec > 0.0) clip.sourceDurationSec else clip.srcEndSec
        Waveform(
            peaks = peaks,
            durationSec = fileLength,
            keepFrom = played.srcStartSec,
            keepTo = played.srcEndSec,
            cutFrom = if (len > 0.3) clip.srcStartSec + lo else null,
            cutTo = if (len > 0.3) clip.srcStartSec + hi else null
        )
        Text(
            if (peaks == null) "Drawing the sound…" else "Bright = the part that plays. Red = the part the cut below would remove.",
            style = MaterialTheme.typography.labelSmall,
            color = Muted,
            modifier = Modifier.padding(top = 4.dp)
        )

        SettingToggleRow("Mute this clip", null, clip.muted) { on -> viewModel.audioEdit(clip.id) { it.copy(muted = on) } }

        // ---- trim the ends
        if (clip.sourceDurationSec > 0.0) {
            Text("Trim the ends", style = MaterialTheme.typography.titleSmall, color = TextMain, modifier = Modifier.padding(top = 8.dp))
            val startHi = (clip.srcEndSec - AudioLimits.MIN_CLIP_SEC).toFloat()
            if (startHi > 0.05f) {
                LabeledSlider("Start of the part used", clock(clip.srcStartSec), clip.srcStartSec.toFloat(), 0f..startHi) { v ->
                    viewModel.audioEdit(clip.id) { ClipEdit.trimStart(it, v.toDouble()) }
                }
            }
            val endLo = (clip.srcStartSec + AudioLimits.MIN_CLIP_SEC).toFloat()
            // (not for a background audio with a time range: its end is the range, the file is cut or repeated to it)
            if (!clip.fitVideo && !rangeLocked && clip.sourceDurationSec.toFloat() > endLo + 0.05f) {
                LabeledSlider("End of the part used", clock(clip.srcEndSec), clip.srcEndSec.toFloat(), endLo..clip.sourceDurationSec.toFloat()) { v ->
                    viewModel.audioEdit(clip.id) { ClipEdit.trimEnd(it, v.toDouble()) }
                }
            }
        }

        // ---- cut a part out of the middle / split (not for a background slot: it is one audio with one time range)
        if (len > 0.5 && !isSlot) {
            Text("Cut a part out", style = MaterialTheme.typography.titleSmall, color = TextMain, modifier = Modifier.padding(top = 12.dp))
            LabeledSlider("From", clock(lo.toDouble()), from, 0f..len.toFloat()) { cutFrom = it }
            LabeledSlider("To", clock(hi.toDouble()), to, 0f..len.toFloat()) { cutTo = it }
            SettingToggleRow("Close the gap", "Everything after the cut moves earlier to fill it.", closeGap) { closeGap = it }
            SecondaryButton("✂ Cut out this part", enabled = hi - lo >= AudioLimits.MIN_CLIP_SEC, onClick = {
                viewModel.audioCut(clip.id, lo.toDouble(), hi.toDouble(), closeGap)
            })
            SecondaryButton("Split in two at \"From\"", onClick = { viewModel.audioSplit(clip.id, lo.toDouble()) })
        }

        // ---- where it plays
        Text("Position and loudness", style = MaterialTheme.typography.titleSmall, color = TextMain, modifier = Modifier.padding(top = 12.dp))
        if (clip.fitVideo) {
            Text(
                "Starts at 0:00 and always covers the whole video, even if you add or remove photos later.",
                style = MaterialTheme.typography.bodySmall,
                color = Muted
            )
        } else if (rangeLocked) {
            Text(
                "Plays from ${clock(clip.startSec)} to ${clock(clip.rangeEndSec)}.",
                style = MaterialTheme.typography.bodySmall,
                color = Muted
            )
        } else {
            val maxStart = max(total, clip.startSec).toFloat().coerceAtLeast(1f)
            LabeledSlider("Starts at", clock(clip.startSec), clip.startSec.toFloat().coerceIn(0f, maxStart), 0f..maxStart) { v ->
                viewModel.audioEdit(clip.id) { it.copy(startSec = v.toDouble().coerceAtLeast(0.0)) }
            }
            Row(Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                CompactButton("−1s", onClick = { viewModel.audioEdit(clip.id) { it.copy(startSec = (it.startSec - 1.0).coerceAtLeast(0.0)) } })
                CompactButton("−0.1", onClick = { viewModel.audioEdit(clip.id) { it.copy(startSec = (it.startSec - 0.1).coerceAtLeast(0.0)) } })
                CompactButton("+0.1", onClick = { viewModel.audioEdit(clip.id) { it.copy(startSec = it.startSec + 0.1) } })
                CompactButton("+1s", onClick = { viewModel.audioEdit(clip.id) { it.copy(startSec = it.startSec + 1.0) } })
            }
        }
        LabeledSlider("Volume", "${(clip.volume * 100).roundToInt()}%", clip.volume, 0f..AudioLimits.MAX_VOLUME) { v ->
            viewModel.audioEdit(clip.id) { it.copy(volume = v) }
        }
        LabeledSlider("Fade in", "${tenth(clip.fadeInSec)} s", clip.fadeInSec.toFloat(), 0f..10f) { v ->
            viewModel.audioEdit(clip.id) { it.copy(fadeInSec = v.toDouble()) }
        }
        LabeledSlider("Fade out", "${tenth(clip.fadeOutSec)} s", clip.fadeOutSec.toFloat(), 0f..10f) { v ->
            viewModel.audioEdit(clip.id) { it.copy(fadeOutSec = v.toDouble()) }
        }

        // ---- background-only switches
        if (!isMain) {
            // (a background slot is fitted to ITS time range instead - see the note at the top)
            if (!isSlot) {
                SettingToggleRow("Always fit the video's length", "Follows the video when photos or timing change: cut at the end if too long, repeated if too short.", clip.fitVideo) {
                    viewModel.audioToggleFitVideo(clip.id)
                }
            }
            if (!clip.fitVideo && !rangeLocked) {
                SettingToggleRow("Repeat to fill the video", "Loops with a smooth join until the video ends.", clip.loop) { on ->
                    viewModel.audioEdit(clip.id) { it.copy(loop = on) }
                }
            }
            SettingToggleRow("Lower under the voice", "Part of the smart mix (see below).", clip.autoDuck) { on ->
                viewModel.audioEdit(clip.id) { it.copy(autoDuck = on) }
            }
        }

        Spacer(Modifier.height(8.dp))
        SecondaryButton("Replace with another file", onClick = onReplace)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            CompactButton("Duplicate", onClick = { viewModel.audioDuplicate(clip.id) })
            if (isMain) {
                CompactButton("◀ Earlier", onClick = { viewModel.audioMove(clip.id, later = false) })
                CompactButton("Later ▶", onClick = { viewModel.audioMove(clip.id, later = true) })
            }
        }
        SecondaryButton("Remove this clip", onClick = { viewModel.audioRemoveClip(clip.id) })
    }
}

/**
 * NEW (2.18): a background slot (B1, B2...) that has its name and time but no audio file yet. It plays nothing until a
 * file is chosen; the file then takes the slot's place and is cut or repeated to the slot's time range.
 */
@Composable
private fun SlotWaitingCard(clip: AudioClip, onChoose: () -> Unit, viewModel: AppViewModel) {
    SectionCard(title = "${clip.slot}: waiting for its audio file", modifier = Modifier.padding(bottom = 12.dp)) {
        val times = if (clip.hasRange) "from ${clock(clip.startSec)} to ${clock(clip.rangeEndSec)}" else "from ${clock(clip.startSec)}, no end time yet"
        Text(
            "${clip.slot} is reserved $times. It stays silent until you choose a music or sound-effect file - " +
                "then it keeps this place and number, and the file is cut or repeated to fit.",
            style = MaterialTheme.typography.bodySmall,
            color = Muted,
            modifier = Modifier.padding(bottom = 8.dp)
        )
        PrimaryButton("📂 Choose the audio file", onClick = onChoose)
        Text(
            "To change the times or give it an end, press and hold a scene on the Match step.",
            style = MaterialTheme.typography.labelSmall,
            color = Muted,
            modifier = Modifier.padding(top = 4.dp)
        )
        SecondaryButton("Remove ${clip.slot}", onClick = { viewModel.audioRemoveClip(clip.id) })
    }
}

// ---------------------------------------------------------------------------------------------
// Smart mix
// ---------------------------------------------------------------------------------------------

@Composable
private fun SmartMixCard(audio: AudioMixSettings, viewModel: AppViewModel) {
    val smart = audio.smart
    SectionCard(title = "Smart mix - free, on your phone", modifier = Modifier.padding(bottom = 12.dp)) {
        Text(
            "No account, no internet and no AI service needed: the app listens to the voice and balances the background audio for you.",
            style = MaterialTheme.typography.bodySmall,
            color = Muted,
            modifier = Modifier.padding(bottom = 8.dp)
        )
        PrimaryButton("✨ Auto-mix everything", enabled = audio.background.isNotEmpty(), onClick = viewModel::audioAutoMix)
        Text(
            "Turns every switch below on and sets each background track to always fit the video (a background audio with its own start and end time, B1, B2..., keeps its range).",
            style = MaterialTheme.typography.labelSmall,
            color = Muted
        )
        SettingToggleRow("Lower music under the voice", "The music dips while someone speaks and swells back in the gaps.", smart.autoDuck) { on ->
            viewModel.audioSmart { it.copy(autoDuck = on) }
        }
        if (smart.autoDuck) {
            val depth = -smart.duckDb
            LabeledSlider("How much it lowers", "${depth.roundToInt()} dB", depth, 3f..30f) { v ->
                viewModel.audioSmart { it.copy(duckDb = (-v).coerceIn(SmartMixSettings.MIN_DUCK_DB, SmartMixSettings.MAX_DUCK_DB)) }
            }
        }
        SettingToggleRow("Match the music's loudness to the voice", "So it never drowns the speech or disappears. Each track's Volume then fine-tunes it.", smart.autoLevel) { on ->
            viewModel.audioSmart { it.copy(autoLevel = on) }
        }
        SettingToggleRow("Fade out at the end", "The last 3 seconds of music fade away.", smart.fadeAtEnd) { on ->
            viewModel.audioSmart { it.copy(fadeAtEnd = on) }
        }
        SettingToggleRow("Protect against crackle", "Softly rounds off peaks where voice and music add up.", smart.limiter) { on ->
            viewModel.audioSmart { it.copy(limiter = on) }
        }
    }
}

// ---------------------------------------------------------------------------------------------
// Where to get music (including free AI)
// ---------------------------------------------------------------------------------------------

private data class MusicLink(val name: String, val note: String, val url: String)

private val AI_MUSIC_SITES = listOf(
    MusicLink("Suno", "Type a request, get a track in about a minute. Free daily credits.", "https://suno.com"),
    MusicLink("ElevenLabs Music", "Text to music. Has a free plan with limits.", "https://elevenlabs.io/music"),
    MusicLink("Stable Audio", "Instrumental music and sound effects from a text request.", "https://stableaudio.com"),
    MusicLink("Beatoven.ai", "Made for background music that fits a video. Limited free plan.", "https://www.beatoven.ai"),
    MusicLink("Soundraw", "Royalty-free instrumentals you can adjust. Free trial.", "https://soundraw.io")
)

private val FREE_LIBRARIES = listOf(
    MusicLink("Pixabay Music", "Free tracks, no sign-in needed to download.", "https://pixabay.com/music/"),
    MusicLink("YouTube Audio Library", "Free music for videos. Needs a Google account.", "https://www.youtube.com/audiolibrary"),
    MusicLink("Free Music Archive", "Large library with a licence shown on every track.", "https://freemusicarchive.org")
)

@Composable
private fun AiMusicCard(total: Double) {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    var mood by remember { mutableStateOf(AiMusicPrompt.MOODS.first()) }
    val prompt = AiMusicPrompt.build(mood, total)

    SectionCard(title = "Get background music", modifier = Modifier.padding(bottom = 12.dp)) {
        Text(
            "Two ways: pick any file from your phone (＋ Add music above), or make new music with a free AI site and then add the file it gives you.",
            style = MaterialTheme.typography.bodySmall,
            color = Muted,
            modifier = Modifier.padding(bottom = 8.dp)
        )
        Text("1. Choose a mood and copy the request", style = MaterialTheme.typography.titleSmall, color = TextMain)
        Row(
            Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            AiMusicPrompt.MOODS.forEach { m -> ModeChip(m, m == mood) { mood = m } }
        }
        Text(
            prompt,
            style = MaterialTheme.typography.bodySmall,
            color = TextMain,
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(Surface)
                .border(1.dp, BorderColor, RoundedCornerShape(8.dp))
                .padding(10.dp)
        )
        SecondaryButton("Copy this request", onClick = {
            clipboard.setText(AnnotatedString(prompt))
            Toast.makeText(context, "Copied. Paste it into the AI site.", Toast.LENGTH_SHORT).show()
        })

        Text("2. Make the music with a free AI site", style = MaterialTheme.typography.titleSmall, color = TextMain, modifier = Modifier.padding(top = 8.dp))
        AI_MUSIC_SITES.forEach { LinkRow(it) { openLink(context, it.url) } }

        Text("Or use a free music library (no AI)", style = MaterialTheme.typography.titleSmall, color = TextMain, modifier = Modifier.padding(top = 12.dp))
        FREE_LIBRARIES.forEach { LinkRow(it) { openLink(context, it.url) } }

        Text("3. Download the track, come back and tap ＋ Add music.", style = MaterialTheme.typography.bodyMedium, color = TextMain, modifier = Modifier.padding(top = 12.dp))
        AlertBox(
            "Free plans change often, and many free AI plans do not allow the music in videos you publish or sell. Check the licence of every track before you post.",
            AlertStyle.WARNING,
            Modifier.padding(top = 8.dp)
        )
    }
}

@Composable
private fun LinkRow(link: MusicLink, onClick: () -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .heightIn(min = 56.dp)
            .clickable(role = Role.Button, onClick = onClick)
            .padding(vertical = 8.dp)
    ) {
        Text("${link.name}  ↗", style = MaterialTheme.typography.bodyMedium, color = Accent, fontWeight = FontWeight.SemiBold)
        Text(link.note, style = MaterialTheme.typography.bodySmall, color = Muted)
    }
}

private fun openLink(context: android.content.Context, url: String) {
    try {
        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (_: ActivityNotFoundException) {
        Toast.makeText(context, "No web browser found on this phone.", Toast.LENGTH_SHORT).show()
    }
}

// ---------------------------------------------------------------------------------------------
// Small building blocks
// ---------------------------------------------------------------------------------------------

@Composable
private fun LabeledSlider(label: String, valueText: String, value: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit) {
    Column(Modifier.padding(top = 8.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, style = MaterialTheme.typography.bodyMedium, color = TextMain)
            Text(valueText, style = MaterialTheme.typography.bodySmall, color = Muted)
        }
        Slider(
            value = value.coerceIn(range.start, range.endInclusive),
            onValueChange = onChange,
            valueRange = range,
            colors = appSliderColors(),
            modifier = Modifier.semantics { contentDescription = "$label, $valueText" }
        )
    }
}

@Composable
private fun ModeChip(label: String, selected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Box(
        modifier
            .heightIn(min = 44.dp)
            .clip(RoundedCornerShape(22.dp))
            .background(if (selected) Accent else CardBg)
            .border(1.dp, if (selected) Accent else Outline, RoundedCornerShape(22.dp))
            .selectable(selected = selected, role = Role.RadioButton, onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        // The tick means "chosen" even for people who can't tell the two colours apart.
        Text(
            if (selected) "✓ $label" else label,
            color = if (selected) OnAccent else TextMain,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
            style = MaterialTheme.typography.labelMedium
        )
    }
}

/** The sound drawn as bars; the part that plays is bright, the rest dim, and a red band shows what a cut would remove. */
@Composable
private fun Waveform(
    peaks: FloatArray?,
    durationSec: Double,
    keepFrom: Double,
    keepTo: Double,
    cutFrom: Double?,
    cutTo: Double?
) {
    val keepColor = Accent
    val dimColor = Outline
    val cutColor = Red
    val back = Surface
    Canvas(
        Modifier
            .fillMaxWidth()
            .height(72.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(back)
            .semantics { contentDescription = "Picture of the sound" }
    ) {
        val w = size.width
        val h = size.height
        val d = durationSec.coerceAtLeast(0.001)
        if (peaks == null || peaks.isEmpty()) {
            drawRect(color = dimColor, topLeft = Offset(0f, h / 2 - 1f), size = Size(w, 2f))
        } else {
            val n = peaks.size
            val barW = w / n
            for (i in 0 until n) {
                val t = (i + 0.5) / n * d
                val inKeep = t >= keepFrom && t <= keepTo
                val bh = max(3f, peaks[i] * (h - 8f))
                drawRect(
                    color = if (inKeep) keepColor else dimColor,
                    topLeft = Offset(i * barW, (h - bh) / 2f),
                    size = Size(max(1f, barW - 1f), bh)
                )
            }
        }
        if (cutFrom != null && cutTo != null && cutTo > cutFrom) {
            drawRect(
                color = cutColor.copy(alpha = 0.35f),
                topLeft = Offset((cutFrom / d * w).toFloat(), 0f),
                size = Size(((cutTo - cutFrom) / d * w).toFloat(), h)
            )
        }
    }
}

/** Two lanes - main sound on top, background below - showing where every clip sits in the video. Tap a bar to select it. */
@Composable
private fun TimelineOverview(
    audio: AudioMixSettings,
    total: Double,
    selectedId: String?,
    playhead: Double?,
    onSelect: (String?) -> Unit
) {
    val mainColor = Accent
    val bgColor = Green
    val laneColor = Surface
    val outline = Outline
    val selectColor = TextMain
    val headColor = Red
    val span = max(1.0, max(total, max(ClipEdit.laneEnd(audio.main), ClipEdit.laneEnd(audio.background.filter { !it.loop }))))

    Canvas(
        Modifier
            .fillMaxWidth()
            .height(112.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(laneColor)
            .semantics { contentDescription = "Timeline of the audio clips" }
            .pointerInput(audio, span) {
                detectTapGestures { pos ->
                    val t = pos.x / size.width * span
                    val lane = if (pos.y < size.height / 2f) audio.main else audio.background
                    onSelect(lane.firstOrNull { t >= it.startSec && t <= it.playsUntil(span) }?.id)
                }
            }
    ) {
        val w = size.width
        val h = size.height
        val laneH = (h - 12f) / 2f
        fun x(sec: Double): Float = (sec / span * w).toFloat()

        // the end of the video, when clips run past it
        if (span > total + 0.01) {
            drawRect(color = outline.copy(alpha = 0.25f), topLeft = Offset(x(total), 0f), size = Size(w - x(total), h))
        }

        fun lane(clips: List<AudioClip>, top: Float, color: androidx.compose.ui.graphics.Color, active: Boolean) {
            drawRect(color = outline.copy(alpha = 0.15f), topLeft = Offset(0f, top), size = Size(w, laneH))
            for (c in clips) {
                val left = x(c.startSec)
                val right = x(c.playsUntil(span))
                val alpha = if (!active || c.muted) 0.3f else 0.9f
                drawRect(color = color.copy(alpha = alpha), topLeft = Offset(left, top + 3f), size = Size(max(3f, right - left), laneH - 6f))
                if (c.id == selectedId) {
                    drawRect(
                        color = selectColor,
                        topLeft = Offset(left, top + 3f),
                        size = Size(max(3f, right - left), laneH - 6f),
                        style = androidx.compose.ui.graphics.drawscope.Stroke(width = 4f)
                    )
                }
            }
        }
        lane(audio.main, 4f, mainColor, audio.useCustomMain)
        lane(audio.background, 8f + laneH, bgColor, true)

        if (playhead != null) {
            val px = x(playhead.coerceIn(0.0, span))
            drawRect(color = headColor, topLeft = Offset(px - 1.5f, 0f), size = Size(3f, h))
        }
    }
}

/** m:ss.t - one decimal, because cuts are made to a tenth of a second. */
private fun clock(sec: Double): String {
    val tenths = (sec.coerceAtLeast(0.0) * 10).roundToInt()
    val whole = tenths / 10
    return String.format(Locale.US, "%d:%02d.%d", whole / 60, whole % 60, tenths % 10)
}

private fun tenth(sec: Double): String = String.format(Locale.US, "%.1f", sec)
