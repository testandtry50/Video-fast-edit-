package com.videoslidemaker.app.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.selection.selectableGroup
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.SettingsBrightness
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.videoslidemaker.app.ui.components.AlertStyle
import com.videoslidemaker.app.ui.components.BadgeChip
import com.videoslidemaker.app.ui.components.PrimaryButton
import com.videoslidemaker.app.ui.components.SecondaryButton
import com.videoslidemaker.app.ui.components.SectionCard
import com.videoslidemaker.app.ui.components.SettingToggleRow
import com.videoslidemaker.app.ui.theme.Accent
import com.videoslidemaker.app.ui.theme.AccentChoice
import com.videoslidemaker.app.ui.theme.AppColors
import com.videoslidemaker.app.ui.theme.AppearancePrefs
import com.videoslidemaker.app.ui.theme.Bg
import com.videoslidemaker.app.ui.theme.CornerChoice
import com.videoslidemaker.app.ui.theme.DarkStyle
import com.videoslidemaker.app.ui.theme.IsDark
import com.videoslidemaker.app.ui.theme.LayoutPreset
import com.videoslidemaker.app.ui.theme.LightStyle
import com.videoslidemaker.app.ui.theme.Muted
import com.videoslidemaker.app.ui.theme.NavPosition
import com.videoslidemaker.app.ui.theme.OnAccent
import com.videoslidemaker.app.ui.theme.Outline
import com.videoslidemaker.app.ui.theme.SpacingChoice
import com.videoslidemaker.app.ui.theme.Surface
import com.videoslidemaker.app.ui.theme.TextMain
import com.videoslidemaker.app.ui.theme.TextSizeChoice
import com.videoslidemaker.app.ui.theme.ThemeMode
import com.videoslidemaker.app.ui.theme.buildAppColors
import com.videoslidemaker.app.ui.theme.customAccentTone
import com.videoslidemaker.app.ui.theme.hslColor
import com.videoslidemaker.app.ui.theme.matchingPreset
import com.videoslidemaker.app.ui.theme.readableOn
import com.videoslidemaker.app.ui.theme.withPreset

/**
 * One page for everything about how the app looks and reads. Every change applies instantly (the page itself
 * re-colours / re-sizes as you tap, and the preview at the top shows the result) and is remembered between launches.
 *
 * Order = what people change most first: light / dark, accent colour, text size - then the background styles for
 * dark and light mode, then the layout (where the step bar sits, spacing, corners), then high contrast.
 */
@Composable
fun AppearanceScreen(
    prefs: AppearancePrefs,
    onChange: ((AppearancePrefs) -> AppearancePrefs) -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler(onBack = onClose)
    val isDark = IsDark

    Column(
        modifier
            .fillMaxSize()
            .background(Bg)
            // Android 15+ draws apps edge to edge: keep the page clear of the status / navigation bars.
            .safeDrawingPadding()
            // This page sits on top of the app; swallow taps so nothing underneath reacts.
            .pointerInput(Unit) { detectTapGestures { } }
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .background(Surface)
                .padding(start = 4.dp, end = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onClose) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Close settings", tint = TextMain)
            }
            Text(
                "Appearance & layout",
                style = MaterialTheme.typography.titleMedium,
                color = TextMain,
                modifier = Modifier.semantics { heading() }
            )
        }

        Column(
            Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            // ---- live preview --------------------------------------------------------------------------------
            SectionCard(title = "Preview", modifier = Modifier.padding(bottom = 12.dp)) {
                Text(
                    "Your slideshow, your style",
                    style = MaterialTheme.typography.titleMedium,
                    color = TextMain
                )
                Text(
                    "This is how text, buttons and cards look with your choices. Everything below changes it straight away.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Muted,
                    modifier = Modifier.padding(top = 4.dp, bottom = 10.dp)
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    BadgeChip("Done", AlertStyle.SUCCESS)
                    BadgeChip("Accent", AlertStyle.INFO)
                }
                PrimaryButton("Sample button", modifier = Modifier.padding(top = 8.dp), onClick = {})
            }

            // ---- light / dark ---------------------------------------------------------------------------------
            SectionCard(title = "Light or dark", modifier = Modifier.padding(bottom = 12.dp)) {
                Row(
                    Modifier.fillMaxWidth().selectableGroup(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    ThemeTile(ThemeMode.SYSTEM, Icons.Filled.SettingsBrightness, prefs.themeMode == ThemeMode.SYSTEM) {
                        onChange { it.copy(themeMode = ThemeMode.SYSTEM) }
                    }
                    ThemeTile(ThemeMode.LIGHT, Icons.Filled.LightMode, prefs.themeMode == ThemeMode.LIGHT) {
                        onChange { it.copy(themeMode = ThemeMode.LIGHT) }
                    }
                    ThemeTile(ThemeMode.DARK, Icons.Filled.DarkMode, prefs.themeMode == ThemeMode.DARK) {
                        onChange { it.copy(themeMode = ThemeMode.DARK) }
                    }
                }
                Text(
                    "System follows your phone's light / dark setting. Each mode has its own background style - see below.",
                    style = MaterialTheme.typography.bodySmall,
                    color = Muted,
                    modifier = Modifier.padding(top = 10.dp)
                )
            }

            // ---- accent colour --------------------------------------------------------------------------------
            SectionCard(title = "Accent colour", modifier = Modifier.padding(bottom = 12.dp)) {
                TileGrid(AccentChoice.entries, perRow = 6) { choice ->
                    val tone = if (choice == AccentChoice.CUSTOM) {
                        customAccentTone(prefs.customHue, isDark)
                    } else {
                        if (isDark) choice.darkTone else choice.lightTone
                    }
                    AccentDot(choice, tone, prefs.accent == choice) {
                        onChange { it.copy(accent = choice) }
                    }
                }
                val picked = if (prefs.accent == AccentChoice.CUSTOM) "Custom colour" else prefs.accent.label
                Text(
                    "Selected: $picked",
                    style = MaterialTheme.typography.bodySmall,
                    color = Muted,
                    modifier = Modifier.padding(top = 4.dp)
                )
                if (prefs.accent == AccentChoice.CUSTOM) {
                    HueSlider(hue = prefs.customHue) { hue ->
                        onChange { it.copy(accent = AccentChoice.CUSTOM, customHue = hue) }
                    }
                } else {
                    Text(
                        "Want a different shade? Tap the rainbow circle and slide to any colour.",
                        style = MaterialTheme.typography.bodySmall,
                        color = Muted,
                        modifier = Modifier.padding(top = 2.dp)
                    )
                }
            }

            // ---- text size ------------------------------------------------------------------------------------
            SectionCard(title = "Text size", modifier = Modifier.padding(bottom = 12.dp)) {
                Column(Modifier.fillMaxWidth().selectableGroup()) {
                    TextSizeChoice.entries.forEach { choice ->
                        TextSizeRow(choice, prefs.textSize) {
                            onChange { it.copy(textSize = choice) }
                        }
                    }
                }
                Text(
                    "Added on top of your phone's own font size, so nothing you set there is lost.",
                    style = MaterialTheme.typography.bodySmall,
                    color = Muted,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }

            // ---- background styles ----------------------------------------------------------------------------
            SectionCard(title = "Dark mode style", modifier = Modifier.padding(bottom = 12.dp)) {
                TileGrid(DarkStyle.entries, perRow = 3) { style ->
                    val colors = remember(style, prefs.accent, prefs.customHue) {
                        buildAppColors(true, prefs.copy(darkStyle = style, highContrast = false))
                    }
                    StyleTile(style.label, colors, prefs.darkStyle == style) {
                        onChange { it.copy(darkStyle = style) }
                    }
                }
                Text(
                    "Used whenever dark mode is on.",
                    style = MaterialTheme.typography.bodySmall,
                    color = Muted,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }

            SectionCard(title = "Light mode style", modifier = Modifier.padding(bottom = 12.dp)) {
                TileGrid(LightStyle.entries, perRow = 3) { style ->
                    val colors = remember(style, prefs.accent, prefs.customHue) {
                        buildAppColors(false, prefs.copy(lightStyle = style, highContrast = false))
                    }
                    StyleTile(style.label, colors, prefs.lightStyle == style) {
                        onChange { it.copy(lightStyle = style) }
                    }
                }
                Text(
                    "Used whenever light mode is on.",
                    style = MaterialTheme.typography.bodySmall,
                    color = Muted,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }

            // ---- layout ---------------------------------------------------------------------------------------
            SectionCard(title = "Layout", modifier = Modifier.padding(bottom = 12.dp)) {
                TileGrid(LayoutPreset.entries, perRow = 2) { preset ->
                    PresetTile(preset, prefs.matchingPreset() == preset) {
                        onChange { it.withPreset(preset) }
                    }
                }
                FieldLabel("Step bar")
                SegmentedRow(NavPosition.entries, prefs.navigation, { it.label }) { value ->
                    onChange { it.copy(navigation = value) }
                }
                Text(
                    "At the bottom the steps are within reach of your thumb.",
                    style = MaterialTheme.typography.bodySmall,
                    color = Muted,
                    modifier = Modifier.padding(top = 6.dp)
                )
                FieldLabel("Spacing")
                SegmentedRow(SpacingChoice.entries, prefs.spacing, { it.label }) { value ->
                    onChange { it.copy(spacing = value) }
                }
                FieldLabel("Corners")
                SegmentedRow(CornerChoice.entries, prefs.corners, { it.label }) { value ->
                    onChange { it.copy(corners = value) }
                }
            }

            // ---- contrast -------------------------------------------------------------------------------------
            SectionCard(title = "Contrast", modifier = Modifier.padding(bottom = 16.dp)) {
                SettingToggleRow(
                    label = "High contrast",
                    hint = "Pure black or white text, brighter outlines on buttons and fields.",
                    checked = prefs.highContrast,
                    onCheckedChange = { value -> onChange { it.copy(highContrast = value) } }
                )
            }

            SecondaryButton("Reset to defaults", onClick = { onChange { AppearancePrefs() } })

            Text(
                "Your choices are saved on this device.",
                style = MaterialTheme.typography.bodySmall,
                color = Muted,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp, bottom = 16.dp)
            )
        }
    }
}

/** Lays [items] out in rows of [perRow] equal tiles (the last row is padded so the tiles keep the same width). */
@Composable
private fun <T> TileGrid(items: List<T>, perRow: Int, tile: @Composable RowScope.(T) -> Unit) {
    Column(
        Modifier.fillMaxWidth().selectableGroup(),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items.chunked(perRow).forEach { rowItems ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                rowItems.forEach { item -> tile(item) }
                repeat(perRow - rowItems.size) { Spacer(Modifier.weight(1f)) }
            }
        }
    }
}

@Composable
private fun FieldLabel(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.labelLarge,
        color = TextMain,
        fontWeight = FontWeight.SemiBold,
        modifier = Modifier.padding(top = 14.dp, bottom = 6.dp)
    )
}

@Composable
private fun RowScope.ThemeTile(mode: ThemeMode, icon: ImageVector, selected: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(14.dp)
    Box(
        Modifier
            .weight(1f)
            .heightIn(min = 84.dp)
            .clip(shape)
            .background(if (selected) Accent.copy(alpha = 0.14f) else Surface)
            .border(if (selected) 2.dp else 1.dp, if (selected) Accent else Outline, shape)
            .selectable(selected = selected, role = Role.RadioButton, onClick = onClick)
            .padding(8.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(icon, contentDescription = null, tint = if (selected) Accent else TextMain, modifier = Modifier.size(28.dp))
            Text(
                mode.label,
                style = MaterialTheme.typography.labelLarge,
                color = TextMain,
                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                modifier = Modifier.padding(top = 6.dp)
            )
        }
        if (selected) {
            Icon(
                Icons.Filled.Check,
                contentDescription = null,
                tint = Accent,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .size(18.dp)
            )
        }
    }
}

/** A round colour swatch. The CUSTOM one shows a rainbow until it is chosen. */
@Composable
private fun RowScope.AccentDot(choice: AccentChoice, tone: Color, selected: Boolean, onClick: () -> Unit) {
    val rainbow = remember { Brush.sweepGradient((0..6).map { hslColor(it * 60.0, 0.85, 0.55) }) }
    Box(
        Modifier
            .weight(1f)
            .heightIn(min = 52.dp)
            .selectable(selected = selected, role = Role.RadioButton, onClick = onClick)
            .semantics { contentDescription = choice.label },
        contentAlignment = Alignment.Center
    ) {
        val dot = Modifier
            .size(40.dp)
            .clip(CircleShape)
        Box(
            (if (choice == AccentChoice.CUSTOM && !selected) dot.background(rainbow) else dot.background(tone))
                .border(if (selected) 3.dp else 1.dp, if (selected) TextMain else Outline, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            if (selected) {
                Icon(
                    Icons.Filled.Check,
                    contentDescription = null,
                    tint = readableOn(tone, Color(0xFF0E0E0E)),
                    modifier = Modifier.size(22.dp)
                )
            }
        }
    }
}

/** A rainbow strip with a draggable thumb: any colour on the wheel. */
@Composable
private fun HueSlider(hue: Int, onHueChange: (Int) -> Unit) {
    val strip = remember { Brush.horizontalGradient((0..12).map { hslColor(it * 30.0, 0.85, 0.55) }) }
    Text(
        "Slide to pick any colour",
        style = MaterialTheme.typography.labelLarge,
        color = TextMain,
        fontWeight = FontWeight.SemiBold,
        modifier = Modifier.padding(top = 10.dp)
    )
    Box(Modifier.fillMaxWidth().height(48.dp), contentAlignment = Alignment.Center) {
        Box(
            Modifier
                .fillMaxWidth()
                .height(16.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(strip)
        )
        Slider(
            value = hue.toFloat(),
            onValueChange = { v -> onHueChange(v.toInt().coerceIn(0, 359)) },
            valueRange = 0f..359f,
            colors = SliderDefaults.colors(
                thumbColor = TextMain,
                activeTrackColor = Color.Transparent,
                inactiveTrackColor = Color.Transparent
            ),
            modifier = Modifier
                .fillMaxWidth()
                .semantics { contentDescription = "Custom accent colour" }
        )
    }
}

/** A mini picture of one background style: its page, a card with two lines of text, and the accent as it will look on it. */
@Composable
private fun RowScope.StyleTile(label: String, colors: AppColors, selected: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(12.dp)
    Column(
        Modifier
            .weight(1f)
            .clip(shape)
            .selectable(selected = selected, role = Role.RadioButton, onClick = onClick)
            .padding(2.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .height(68.dp)
                .clip(shape)
                .background(colors.bg)
                .border(if (selected) 3.dp else 1.dp, if (selected) Accent else Outline, shape)
        ) {
            Box(
                Modifier
                    .align(Alignment.Center)
                    .fillMaxWidth(0.8f)
                    .height(42.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(colors.card)
                    .border(1.dp, colors.border, RoundedCornerShape(8.dp))
            ) {
                Column(Modifier.align(Alignment.CenterStart).padding(start = 8.dp)) {
                    Box(Modifier.width(32.dp).height(6.dp).clip(RoundedCornerShape(3.dp)).background(colors.textMain))
                    Spacer(Modifier.height(6.dp))
                    Box(Modifier.width(20.dp).height(6.dp).clip(RoundedCornerShape(3.dp)).background(colors.muted))
                }
                Box(
                    Modifier
                        .align(Alignment.CenterEnd)
                        .padding(end = 8.dp)
                        .size(14.dp)
                        .clip(CircleShape)
                        .background(colors.accent)
                )
            }
            if (selected) {
                Box(
                    Modifier
                        .align(Alignment.TopEnd)
                        .padding(4.dp)
                        .size(20.dp)
                        .clip(CircleShape)
                        .background(Accent),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Filled.Check, contentDescription = null, tint = OnAccent, modifier = Modifier.size(14.dp))
                }
            }
        }
        Text(
            label,
            style = MaterialTheme.typography.labelMedium,
            color = TextMain,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
            maxLines = 1,
            modifier = Modifier.padding(top = 4.dp, bottom = 2.dp)
        )
    }
}

@Composable
private fun RowScope.PresetTile(preset: LayoutPreset, selected: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(14.dp)
    Column(
        Modifier
            .weight(1f)
            .heightIn(min = 76.dp)
            .clip(shape)
            .background(if (selected) Accent.copy(alpha = 0.14f) else Surface)
            .border(if (selected) 2.dp else 1.dp, if (selected) Accent else Outline, shape)
            .selectable(selected = selected, role = Role.RadioButton, onClick = onClick)
            .padding(10.dp)
    ) {
        Text(
            preset.label,
            style = MaterialTheme.typography.labelLarge,
            color = TextMain,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.SemiBold
        )
        Text(
            preset.hint,
            style = MaterialTheme.typography.bodySmall,
            color = Muted,
            modifier = Modifier.padding(top = 2.dp)
        )
    }
}

/** A row of equal-width choices, exactly one of them selected. */
@Composable
private fun <T> SegmentedRow(options: List<T>, selected: T, label: (T) -> String, onSelect: (T) -> Unit) {
    val shape = RoundedCornerShape(12.dp)
    Row(
        Modifier.fillMaxWidth().selectableGroup(),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        options.forEach { option ->
            val isSelected = option == selected
            Box(
                Modifier
                    .weight(1f)
                    .heightIn(min = 48.dp)
                    .clip(shape)
                    .background(if (isSelected) Accent.copy(alpha = 0.14f) else Surface)
                    .border(if (isSelected) 2.dp else 1.dp, if (isSelected) Accent else Outline, shape)
                    .selectable(selected = isSelected, role = Role.RadioButton, onClick = { onSelect(option) })
                    .padding(horizontal = 4.dp, vertical = 8.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    label(option),
                    style = MaterialTheme.typography.labelLarge,
                    color = TextMain,
                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}

@Composable
private fun TextSizeRow(choice: TextSizeChoice, current: TextSizeChoice, onClick: () -> Unit) {
    val selected = choice == current
    Row(
        Modifier
            .fillMaxWidth()
            .heightIn(min = 56.dp)
            .selectable(selected = selected, role = Role.RadioButton, onClick = onClick),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RadioButton(
            selected = selected,
            onClick = null,
            colors = RadioButtonDefaults.colors(selectedColor = Accent, unselectedColor = Outline)
        )
        Text(
            choice.label,
            style = MaterialTheme.typography.bodyLarge,
            color = TextMain,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
            modifier = Modifier
                .weight(1f)
                .padding(start = 8.dp)
        )
        // The whole page is already drawn at the CURRENT size, so scale the sample relative to it:
        // each "Aa" shows how big that option will really look.
        Text(
            "Aa",
            fontSize = (18f * choice.scale / current.scale).sp,
            color = TextMain,
            fontWeight = FontWeight.Medium,
            modifier = Modifier.padding(end = 12.dp)
        )
    }
}
