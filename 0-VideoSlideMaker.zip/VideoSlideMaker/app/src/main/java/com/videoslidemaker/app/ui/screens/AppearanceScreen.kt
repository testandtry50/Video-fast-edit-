package com.videoslidemaker.app.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.selection.selectableGroup
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.SettingsBrightness
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.videoslidemaker.app.ui.components.SecondaryButton
import com.videoslidemaker.app.ui.components.SectionCard
import com.videoslidemaker.app.ui.components.SettingToggleRow
import com.videoslidemaker.app.ui.theme.Accent
import com.videoslidemaker.app.ui.theme.AccentChoice
import com.videoslidemaker.app.ui.theme.AppearancePrefs
import com.videoslidemaker.app.ui.theme.Bg
import com.videoslidemaker.app.ui.theme.IsDark
import com.videoslidemaker.app.ui.theme.Muted
import com.videoslidemaker.app.ui.theme.OnAccent
import com.videoslidemaker.app.ui.theme.Outline
import com.videoslidemaker.app.ui.theme.Surface
import com.videoslidemaker.app.ui.theme.TextMain
import com.videoslidemaker.app.ui.theme.TextSizeChoice
import com.videoslidemaker.app.ui.theme.ThemeMode

/**
 * One page for everything about how the app looks and reads. Every change applies instantly (the
 * page itself re-colours / re-sizes as you tap) and is remembered between launches.
 */
@Composable
fun AppearanceScreen(
    prefs: AppearancePrefs,
    onChange: ((AppearancePrefs) -> AppearancePrefs) -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler(onBack = onClose)
    val isDark = IsDark

    Column(
        modifier
            .fillMaxSize()
            .background(Bg)
            // Android 15+ draws apps edge to edge: keep the page clear of the status / navigation bars.
            .safeDrawingPadding()
            // This page sits on top of the app; swallow taps so nothing underneath reacts.
            .pointerInput(Unit) { detectTapGestures { } }
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .background(Surface)
                .padding(start = 4.dp, end = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onClose) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Close settings", tint = TextMain)
            }
            Text(
                "Appearance & accessibility",
                style = MaterialTheme.typography.titleMedium,
                color = TextMain,
                modifier = Modifier.semantics { heading() }
            )
        }

        Column(
            Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            SectionCard(title = "Theme", modifier = Modifier.padding(bottom = 12.dp)) {
                Row(
                    Modifier.fillMaxWidth().selectableGroup(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    ThemeTile(ThemeMode.SYSTEM, Icons.Filled.SettingsBrightness, prefs.themeMode == ThemeMode.SYSTEM) {
                        onChange { it.copy(themeMode = ThemeMode.SYSTEM) }
                    }
                    ThemeTile(ThemeMode.LIGHT, Icons.Filled.LightMode, prefs.themeMode == ThemeMode.LIGHT) {
                        onChange { it.copy(themeMode = ThemeMode.LIGHT) }
                    }
                    ThemeTile(ThemeMode.DARK, Icons.Filled.DarkMode, prefs.themeMode == ThemeMode.DARK) {
                        onChange { it.copy(themeMode = ThemeMode.DARK) }
                    }
                }
                Text(
                    "System follows your phone's light / dark setting.",
                    style = MaterialTheme.typography.bodySmall,
                    color = Muted,
                    modifier = Modifier.padding(top = 10.dp)
                )
                if (isDark) {
                    SettingToggleRow(
                        label = "Pure black background",
                        hint = "Saves battery on OLED screens and gives the deepest contrast.",
                        checked = prefs.pureBlack,
                        onCheckedChange = { value -> onChange { it.copy(pureBlack = value) } }
                    )
                }
            }

            SectionCard(title = "Accent colour", modifier = Modifier.padding(bottom = 12.dp)) {
                Row(
                    Modifier.fillMaxWidth().selectableGroup(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    AccentChoice.entries.forEach { choice ->
                        AccentSwatch(choice, isDark, prefs.accent == choice) {
                            onChange { it.copy(accent = choice) }
                        }
                    }
                }
            }

            SectionCard(title = "Text size", modifier = Modifier.padding(bottom = 12.dp)) {
                Column(Modifier.fillMaxWidth().selectableGroup()) {
                    TextSizeChoice.entries.forEach { choice ->
                        TextSizeRow(choice, prefs.textSize) {
                            onChange { it.copy(textSize = choice) }
                        }
                    }
                }
                Text(
                    "Added on top of your phone's own font size, so nothing you set there is lost.",
                    style = MaterialTheme.typography.bodySmall,
                    color = Muted,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }

            SectionCard(title = "Contrast", modifier = Modifier.padding(bottom = 16.dp)) {
                SettingToggleRow(
                    label = "High contrast",
                    hint = "Pure black or white text, brighter outlines on buttons and fields.",
                    checked = prefs.highContrast,
                    onCheckedChange = { value -> onChange { it.copy(highContrast = value) } }
                )
            }

            SecondaryButton("Reset to defaults", onClick = { onChange { AppearancePrefs() } })

            Text(
                "Your choices are saved on this device.",
                style = MaterialTheme.typography.bodySmall,
                color = Muted,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp, bottom = 16.dp)
            )
        }
    }
}

@Composable
private fun RowScope.ThemeTile(mode: ThemeMode, icon: ImageVector, selected: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(14.dp)
    Box(
        Modifier
            .weight(1f)
            .heightIn(min = 84.dp)
            .clip(shape)
            .background(if (selected) Accent.copy(alpha = 0.14f) else Surface)
            .border(if (selected) 2.dp else 1.dp, if (selected) Accent else Outline, shape)
            .selectable(selected = selected, role = Role.RadioButton, onClick = onClick)
            .padding(8.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(icon, contentDescription = null, tint = if (selected) Accent else TextMain, modifier = Modifier.size(28.dp))
            Text(
                mode.label,
                style = MaterialTheme.typography.labelLarge,
                color = TextMain,
                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                modifier = Modifier.padding(top = 6.dp)
            )
        }
        if (selected) {
            Icon(
                Icons.Filled.Check,
                contentDescription = null,
                tint = Accent,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .size(18.dp)
            )
        }
    }
}

@Composable
private fun RowScope.AccentSwatch(choice: AccentChoice, isDark: Boolean, selected: Boolean, onClick: () -> Unit) {
    val tone = if (isDark) choice.darkTone else choice.lightTone
    Column(
        Modifier
            .weight(1f)
            .heightIn(min = 76.dp)
            .selectable(selected = selected, role = Role.RadioButton, onClick = onClick)
            .padding(vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            Modifier
                .size(44.dp)
                .clip(CircleShape)
                .background(tone)
                .border(if (selected) 3.dp else 1.dp, if (selected) TextMain else Outline, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            if (selected) {
                Icon(Icons.Filled.Check, contentDescription = null, tint = OnAccent, modifier = Modifier.size(24.dp))
            }
        }
        Text(
            choice.label,
            style = MaterialTheme.typography.labelSmall,
            color = TextMain,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
            maxLines = 1,
            modifier = Modifier.padding(top = 6.dp)
        )
    }
}

@Composable
private fun TextSizeRow(choice: TextSizeChoice, current: TextSizeChoice, onClick: () -> Unit) {
    val selected = choice == current
    Row(
        Modifier
            .fillMaxWidth()
            .heightIn(min = 56.dp)
            .selectable(selected = selected, role = Role.RadioButton, onClick = onClick),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RadioButton(
            selected = selected,
            onClick = null,
            colors = RadioButtonDefaults.colors(selectedColor = Accent, unselectedColor = Outline)
        )
        Text(
            choice.label,
            style = MaterialTheme.typography.bodyLarge,
            color = TextMain,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
            modifier = Modifier
                .weight(1f)
                .padding(start = 8.dp)
        )
        // The whole page is already drawn at the CURRENT size, so scale the sample relative to it:
        // each "Aa" shows how big that option will really look.
        Text(
            "Aa",
            fontSize = (18f * choice.scale / current.scale).sp,
            color = TextMain,
            fontWeight = FontWeight.Medium,
            modifier = Modifier.padding(end = 12.dp)
        )
    }
}
