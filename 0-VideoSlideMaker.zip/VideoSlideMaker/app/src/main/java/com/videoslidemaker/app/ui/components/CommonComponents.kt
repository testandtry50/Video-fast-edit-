package com.videoslidemaker.app.ui.components

import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.semantics.stateDescription

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.SliderColors
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.videoslidemaker.app.ui.theme.Accent
import com.videoslidemaker.app.ui.theme.BorderColor
import com.videoslidemaker.app.ui.theme.CardBg
import com.videoslidemaker.app.ui.theme.Green
import com.videoslidemaker.app.ui.theme.Muted
import com.videoslidemaker.app.ui.theme.OnAccent
import com.videoslidemaker.app.ui.theme.Outline
import com.videoslidemaker.app.ui.theme.OverlayIcon
import com.videoslidemaker.app.ui.theme.OverlayScrim
import com.videoslidemaker.app.ui.theme.Red
import com.videoslidemaker.app.ui.theme.Surface
import com.videoslidemaker.app.ui.theme.TextMain
import com.videoslidemaker.app.ui.theme.Yellow

/** Every tappable control is at least this tall, which is Android's recommended touch size. */
private val MinTouch = 48.dp

@Composable
fun ScreenTitle(title: String, subtitle: String? = null) {
    Column(Modifier.padding(bottom = 20.dp)) {
        Text(
            title,
            style = MaterialTheme.typography.headlineSmall,
            color = TextMain,
            modifier = Modifier.semantics { heading() }
        )
        if (subtitle != null) {
            Text(
                subtitle,
                style = MaterialTheme.typography.bodyMedium,
                color = Muted,
                modifier = Modifier.padding(top = 4.dp)
            )
        }
    }
}

@Composable
fun SectionCard(title: String? = null, modifier: Modifier = Modifier, content: ColumnScopeContent) {
    Column(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(CardBg)
            .border(1.dp, BorderColor, RoundedCornerShape(18.dp))
            .padding(16.dp)
    ) {
        if (title != null) {
            Text(
                title,
                style = MaterialTheme.typography.titleSmall,
                color = TextMain,
                modifier = Modifier
                    .padding(bottom = 12.dp)
                    .semantics { heading() }
            )
        }
        content()
    }
}

typealias ColumnScopeContent = @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit

/**
 * A card whose body can be folded away, so a screen shows what matters first and the detail only when asked for.
 * The header always shows a one-line [summary] of what is inside, so nothing is "hidden" - you can see the current
 * values without opening it. The whole header is the tap target, and screen readers hear "Expanded" / "Collapsed".
 */
@Composable
fun CollapsibleCard(
    title: String,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    summary: String? = null,
    initiallyExpanded: Boolean = false,
    content: ColumnScopeContent
) {
    var expanded by rememberSaveable { mutableStateOf(initiallyExpanded) }
    val shape = RoundedCornerShape(18.dp)
    Column(
        modifier
            .fillMaxWidth()
            .clip(shape)
            .background(CardBg)
            .border(1.dp, BorderColor, shape)
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .heightIn(min = 60.dp)
                .clickable(
                    onClickLabel = if (expanded) "Hide $title" else "Show $title",
                    role = Role.Button
                ) { expanded = !expanded }
                .semantics { stateDescription = if (expanded) "Expanded" else "Collapsed" }
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (icon != null) {
                Icon(icon, contentDescription = null, tint = Accent, modifier = Modifier.size(22.dp))
                Spacer(Modifier.width(12.dp))
            }
            Column(Modifier.weight(1f)) {
                Text(
                    title,
                    style = MaterialTheme.typography.titleSmall,
                    color = TextMain,
                    modifier = Modifier.semantics { heading() }
                )
                if (summary != null) {
                    Text(
                        summary,
                        style = MaterialTheme.typography.bodySmall,
                        color = Muted,
                        modifier = Modifier.padding(top = 2.dp)
                    )
                }
            }
            Icon(
                if (expanded) Icons.Filled.KeyboardArrowUp else Icons.Filled.KeyboardArrowDown,
                contentDescription = null,
                tint = Muted,
                modifier = Modifier.size(26.dp)
            )
        }
        if (expanded) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .padding(start = 16.dp, end = 16.dp, bottom = 16.dp)
            ) { content() }
        }
    }
}

@Composable
fun SettingRow(label: String, hint: String? = null, control: @Composable () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .heightIn(min = MinTouch)
            .padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f).padding(end = 12.dp)) {
            Text(label, style = MaterialTheme.typography.bodyLarge, color = TextMain, fontWeight = FontWeight.Medium)
            if (hint != null) {
                Text(hint, style = MaterialTheme.typography.bodySmall, color = Muted, modifier = Modifier.padding(top = 2.dp))
            }
        }
        control()
    }
}

@Composable
private fun appSwitchColors() = SwitchDefaults.colors(
    checkedThumbColor = OnAccent,
    checkedTrackColor = Accent,
    checkedBorderColor = Accent,
    uncheckedThumbColor = Outline,
    uncheckedTrackColor = Surface,
    uncheckedBorderColor = Outline
)

/**
 * A label + hint + switch where the WHOLE row is the tap target and a screen reader announces it
 * as one "switch" with its name (a bare switch next to a separate label has no name for TalkBack).
 */
@Composable
fun SettingToggleRow(label: String, hint: String?, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .heightIn(min = 56.dp)
            .toggleable(value = checked, role = Role.Switch, onValueChange = onCheckedChange)
            .padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f).padding(end = 12.dp)) {
            Text(label, style = MaterialTheme.typography.bodyLarge, color = TextMain, fontWeight = FontWeight.Medium)
            if (hint != null) {
                Text(hint, style = MaterialTheme.typography.bodySmall, color = Muted, modifier = Modifier.padding(top = 2.dp))
            }
        }
        Switch(checked = checked, onCheckedChange = null, colors = appSwitchColors())
    }
}

/** Kept for any caller that places its own label; prefer [SettingToggleRow]. */
@Composable
fun ToggleSwitch(on: Boolean, onToggle: (Boolean) -> Unit, modifier: Modifier = Modifier) {
    Switch(checked = on, onCheckedChange = onToggle, modifier = modifier, colors = appSwitchColors())
}

@Composable
fun PrimaryButton(
    text: String,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    icon: ImageVector? = null,
    onClick: () -> Unit
) {
    Button(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .heightIn(min = 52.dp),
        shape = RoundedCornerShape(14.dp),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = Accent,
            contentColor = OnAccent,
            disabledContainerColor = Surface,
            disabledContentColor = Muted
        ),
        border = if (enabled) null else BorderStroke(1.dp, BorderColor),
        elevation = null
    ) {
        ButtonLabel(text, icon)
    }
}

/** The text of a big button, with an optional small icon in front of it. */
@Composable
private fun ButtonLabel(text: String, icon: ImageVector?) {
    if (icon != null) {
        Icon(icon, contentDescription = null, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(8.dp))
    }
    Text(text, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
}

@Composable
fun SecondaryButton(text: String, modifier: Modifier = Modifier, enabled: Boolean = true, icon: ImageVector? = null, onClick: () -> Unit) {
    OutlinedButton(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .heightIn(min = 52.dp),
        shape = RoundedCornerShape(14.dp),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
        border = BorderStroke(1.dp, if (enabled) Outline else BorderColor),
        colors = ButtonDefaults.outlinedButtonColors(contentColor = TextMain, disabledContentColor = Muted)
    ) {
        ButtonLabel(text, icon)
    }
}

@Composable
fun RowScope.CompactButton(text: String, onClick: () -> Unit, enabled: Boolean = true) {
    OutlinedButton(
        onClick = onClick,
        enabled = enabled,
        modifier = Modifier
            .weight(1f)
            .heightIn(min = MinTouch),
        shape = RoundedCornerShape(10.dp),
        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 8.dp),
        border = BorderStroke(1.dp, if (enabled) Outline else BorderColor),
        colors = ButtonDefaults.outlinedButtonColors(contentColor = TextMain, disabledContentColor = Muted)
    ) {
        Text(text, textAlign = TextAlign.Center)
    }
}

enum class AlertStyle { INFO, WARNING, SUCCESS }

/**
 * A message box. The meaning is never carried by colour alone: every style also has its own icon
 * (and a spoken label for screen readers).
 */
@Composable
fun AlertBox(text: String, style: AlertStyle = AlertStyle.INFO, modifier: Modifier = Modifier) {
    val (bg, border, fg) = when (style) {
        AlertStyle.INFO -> Triple(Accent.copy(alpha = 0.12f), Accent.copy(alpha = 0.35f), TextMain)
        AlertStyle.WARNING -> Triple(Yellow.copy(alpha = 0.10f), Yellow.copy(alpha = 0.40f), Yellow)
        AlertStyle.SUCCESS -> Triple(Green.copy(alpha = 0.10f), Green.copy(alpha = 0.40f), Green)
    }
    val iconTint = when (style) {
        AlertStyle.INFO -> Accent
        AlertStyle.WARNING -> Yellow
        AlertStyle.SUCCESS -> Green
    }
    val icon = when (style) {
        AlertStyle.INFO -> Icons.Filled.Info
        AlertStyle.WARNING -> Icons.Filled.Warning
        AlertStyle.SUCCESS -> Icons.Filled.CheckCircle
    }
    val iconLabel = when (style) {
        AlertStyle.INFO -> "Note"
        AlertStyle.WARNING -> "Warning"
        AlertStyle.SUCCESS -> "Success"
    }
    val shape = RoundedCornerShape(12.dp)
    Row(
        modifier
            .fillMaxWidth()
            .clip(shape)
            .background(bg)
            .border(1.dp, border, shape)
            .padding(horizontal = 14.dp, vertical = 11.dp)
            .semantics(mergeDescendants = true) {},
        verticalAlignment = Alignment.Top
    ) {
        Icon(icon, contentDescription = iconLabel, tint = iconTint, modifier = Modifier.size(20.dp))
        Text(
            text,
            style = MaterialTheme.typography.bodyMedium,
            color = fg,
            modifier = Modifier
                .weight(1f)
                .padding(start = 10.dp)
        )
    }
}

@Composable
fun BadgeChip(text: String, style: AlertStyle, modifier: Modifier = Modifier, icon: ImageVector? = null) {
    val (bg, fg) = when (style) {
        AlertStyle.SUCCESS -> Green.copy(alpha = 0.13f) to Green
        AlertStyle.WARNING -> Yellow.copy(alpha = 0.13f) to Yellow
        AlertStyle.INFO -> Accent.copy(alpha = 0.13f) to Accent
    }
    Row(
        modifier
            .clip(RoundedCornerShape(20.dp))
            .background(bg)
            .padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (icon != null) {
            Icon(icon, contentDescription = null, tint = fg, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(6.dp))
        }
        Text(text, style = MaterialTheme.typography.labelMedium, color = fg)
    }
}

@Composable
fun StatChip(value: String, label: String, modifier: Modifier = Modifier) {
    Column(
        modifier
            .clip(RoundedCornerShape(12.dp))
            .background(CardBg)
            .border(1.dp, BorderColor, RoundedCornerShape(12.dp))
            .padding(10.dp)
            .semantics(mergeDescendants = true) {},
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(value, style = MaterialTheme.typography.titleMedium, color = Accent)
        Text(label, style = MaterialTheme.typography.labelSmall, color = Muted, modifier = Modifier.padding(top = 2.dp))
    }
}

/** A progress line in the theme's colours. Screen readers get its percentage automatically. */
@Composable
fun AppProgressBar(fraction: Float, modifier: Modifier = Modifier) {
    LinearProgressIndicator(
        progress = { fraction.coerceIn(0f, 1f) },
        modifier = modifier
            .fillMaxWidth()
            .height(8.dp)
            .clip(RoundedCornerShape(4.dp)),
        color = Accent,
        trackColor = BorderColor
    )
}

/** Slider colours that follow the theme (the stock ones bring back Material's purple). */
@Composable
fun appSliderColors(): SliderColors = SliderDefaults.colors(
    thumbColor = Accent,
    activeTrackColor = Accent,
    inactiveTrackColor = Outline
)

/**
 * A small round button that sits on top of a photo thumbnail (remove, enlarge...). Large enough to
 * tap (30dp plus the thumbnail's own padding), and has a spoken name. Colours are fixed on purpose -
 * they have to read on any photo, in any theme.
 */
@Composable
fun OverlayIconButton(icon: ImageVector, description: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Box(
        modifier
            .size(30.dp)
            .clip(CircleShape)
            .background(OverlayScrim)
            .clickable(onClickLabel = description, role = Role.Button, onClick = onClick)
            .semantics { contentDescription = description },
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, contentDescription = null, tint = OverlayIcon, modifier = Modifier.size(16.dp))
    }
}

@Composable
fun OverlayCloseButton(description: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    OverlayIconButton(Icons.Filled.Close, description, onClick, modifier)
}

/**
 * NEW: slim bar shown above every screen while a big photo import is running, so the app never
 * looks frozen or black while thousands of photos are being read. [total] == 0 means the photos
 * are still being counted. Tapping Stop keeps whatever has been added so far.
 */
@Composable
fun ImportProgressCard(done: Int, total: Int, onStop: () -> Unit, modifier: Modifier = Modifier, scanned: Int = 0) {
    val fraction = if (total > 0) (done.toFloat() / total.toFloat()).coerceIn(0f, 1f) else 0f
    Column(
        modifier
            .fillMaxWidth()
            .background(CardBg)
            .padding(start = 16.dp, end = 8.dp, top = 8.dp, bottom = 12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(
                    when {
                        total > 0 -> "Adding photos… $done of $total"
                        scanned > 0 -> "Looking through folders… $scanned photos found"
                        else -> "Looking through your photos…"
                    },
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextMain,
                    fontWeight = FontWeight.Medium
                )
                Text(
                    "The list fills in as photos are read",
                    style = MaterialTheme.typography.bodySmall,
                    color = Muted
                )
            }
            TextButton(onClick = onStop) { Text("Stop", color = Red, fontWeight = FontWeight.Bold) }
        }
        AppProgressBar(fraction, Modifier.padding(top = 8.dp, end = 8.dp))
    }
}
