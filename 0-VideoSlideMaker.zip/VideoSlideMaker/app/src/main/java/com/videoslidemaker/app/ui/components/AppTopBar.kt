package com.videoslidemaker.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Redo
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import com.videoslidemaker.app.ui.theme.Surface
import com.videoslidemaker.app.ui.theme.TextMain

/**
 * Always-visible top bar. Two one-tap controls live here so changing how the app looks never
 * means hunting through menus:
 *  - the sun / moon button flips between light and dark right away,
 *  - the sliders button opens the full Appearance & accessibility page.
 */
@Composable
fun AppTopBar(
    isDark: Boolean,
    onToggleTheme: () -> Unit,
    onOpenAppearance: () -> Unit,
    canUndo: Boolean = false,
    canRedo: Boolean = false,
    undoLabel: String? = null,
    redoLabel: String? = null,
    onUndo: () -> Unit = {},
    onRedo: () -> Unit = {}
) {
    Row(
        Modifier
            .fillMaxWidth()
            .background(Surface)
            .padding(start = 16.dp, end = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            "VideoSlide Maker",
            style = MaterialTheme.typography.titleMedium,
            color = TextMain,
            maxLines = 1,
            modifier = Modifier
                .weight(1f)
                .semantics { heading() }
        )
        // NEW: Undo / Redo for every change in the app, visible on every screen.
        IconButton(onClick = onUndo, enabled = canUndo) {
            Icon(
                Icons.AutoMirrored.Filled.Undo,
                contentDescription = if (canUndo) "Undo: ${undoLabel ?: "last change"}" else "Nothing to undo",
                tint = TextMain.copy(alpha = if (canUndo) 1f else 0.35f)
            )
        }
        IconButton(onClick = onRedo, enabled = canRedo) {
            Icon(
                Icons.AutoMirrored.Filled.Redo,
                contentDescription = if (canRedo) "Redo: ${redoLabel ?: "last change"}" else "Nothing to redo",
                tint = TextMain.copy(alpha = if (canRedo) 1f else 0.35f)
            )
        }
        IconButton(onClick = onToggleTheme) {
            Icon(
                if (isDark) Icons.Filled.LightMode else Icons.Filled.DarkMode,
                contentDescription = if (isDark) "Switch to light mode" else "Switch to dark mode",
                tint = TextMain
            )
        }
        IconButton(onClick = onOpenAppearance) {
            Icon(
                Icons.Filled.Tune,
                contentDescription = "Appearance and accessibility settings",
                tint = TextMain
            )
        }
    }
}
