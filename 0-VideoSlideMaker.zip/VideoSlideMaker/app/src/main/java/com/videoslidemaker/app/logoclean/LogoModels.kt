package com.videoslidemaker.app.logoclean

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * What to do with the logo.
 * [doneLabel] is the little tick text shown on a cleaned photo; [verb] completes "Logo ___ 5 photos".
 */
enum class LogoCleanMode(val label: String, val doneLabel: String, val verb: String) {
    /** Paint the area out so it looks like the logo was never there. */
    REMOVE("Remove", "\u2714 logo removed", "removed from"),

    /** Blur just the logo so it can't be read. */
    BLUR("Blur", "\u2714 logo blurred", "blurred in"),

    /** Both: paint the logo out, then softly blur the repaired spot so no seam or leftover edge shows. */
    BOTH("Remove + Blur", "\u2714 logo removed + blurred", "removed and blurred in")
}

/**
 * A rectangle given as FRACTIONS (0..1) of a photo's width and height, so the same box fits a
 * photo at any resolution - and the preview, the cleaned file and the export all agree on it.
 */
data class LogoBox(val left: Float, val top: Float, val right: Float, val bottom: Float) {
    val width: Float get() = right - left
    val height: Float get() = bottom - top

    /** Keeps the box inside the photo, the right way round, and at least [MIN_SIZE] big. */
    fun coerced(): LogoBox {
        var l = min(left, right).coerceIn(0f, 1f)
        var r = max(left, right).coerceIn(0f, 1f)
        var t = min(top, bottom).coerceIn(0f, 1f)
        var b = max(top, bottom).coerceIn(0f, 1f)
        if (r - l < MIN_SIZE) {
            if (l + MIN_SIZE <= 1f) r = l + MIN_SIZE else l = r - MIN_SIZE
        }
        if (b - t < MIN_SIZE) {
            if (t + MIN_SIZE <= 1f) b = t + MIN_SIZE else t = b - MIN_SIZE
        }
        return LogoBox(l, t, r, b)
    }

    fun shifted(dx: Float, dy: Float) = LogoBox(left + dx, top + dy, right + dx, bottom + dy)

    /** True when [other] is (almost) the same rectangle. */
    fun near(other: LogoBox, tolerance: Float = 0.004f): Boolean =
        abs(left - other.left) <= tolerance && abs(top - other.top) <= tolerance &&
            abs(right - other.right) <= tolerance && abs(bottom - other.bottom) <= tolerance

    companion object {
        const val MIN_SIZE = 0.01f
        val DEFAULT = LogoBox(0.38f, 0.42f, 0.62f, 0.58f)
    }
}

/**
 * Everything remembered about one logo, all relative to the photo size so it can be looked for in
 * photos of other sizes:
 *  - the logo's edge points with their direction (what a photo needs to contain to "have" the logo),
 *  - a few points where the logo is quiet (a busy, textured area is not the logo),
 *  - a solid mask of the logo's shape, so only the logo's own pixels are changed, not a whole box.
 */
class LogoTemplate(
    val box: LogoBox,
    val ptsX: FloatArray,
    val ptsY: FloatArray,
    val ptsDir: IntArray,
    val quietX: FloatArray,
    val quietY: FloatArray,
    val mask: BooleanArray,
    val maskW: Int,
    val maskH: Int,
    /** Where the mask grid sits in the photo, as fractions. */
    val maskRect: LogoBox
)

/** A logo found by the automatic scan. [support] = share of the scanned photos that contain it (0..1). */
class LogoCandidate(val template: LogoTemplate, val support: Float, val photos: Int) {
    val box: LogoBox get() = template.box
}

/**
 * What kind of thing is being cleaned. A LOGO (or icon, or watermark) is the same in many photos, so it can be found
 * by itself. A SUBTITLE or other TEXT is different in every photo, so it is found photo by photo inside the box the
 * user draws (see [TextMask]).
 */
enum class CleanTarget(val label: String, val noun: String) {
    LOGO("Logo / icon", "logo"),
    SUBTITLE("Subtitle", "subtitle"),
    TEXT("Other text", "text");

    /** True for the targets that are found photo by photo inside the box. */
    val isText: Boolean get() = this != LOGO

    companion object {
        /** Where subtitles usually are: a wide strip near the bottom. Used when the user picks "Subtitle". */
        val SUBTITLE_BOX = LogoBox(0.06f, 0.78f, 0.94f, 0.93f)
    }
}

/** "removed", "blurred" or "removed + blurred": the finished-tick wording for a mode. */
fun LogoCleanMode.past(): String = when (this) {
    LogoCleanMode.REMOVE -> "removed"
    LogoCleanMode.BLUR -> "blurred"
    LogoCleanMode.BOTH -> "removed + blurred"
}

/**
 * One step the cleaner can show and work on: a photo, or a segment of the video (a line of the script) with the
 * photo it shows. [imageId] says which photo gets cleaned; [label] is what the screen calls it.
 */
class CleanUnit(val imageId: String, val label: String)

/**
 * What has been done to one photo, per target: logo removed AND subtitle blurred can both be true. Saved with the
 * project as one short text, "LOGO:REMOVE,SUBTITLE:BLUR".
 */
object CleanLog {
    fun encode(log: Map<CleanTarget, LogoCleanMode>): String =
        log.entries.joinToString(",") { it.key.name + ":" + it.value.name }

    /** Reads what [encode] wrote. Unknown or damaged pieces are skipped. */
    fun decode(text: String?): Map<CleanTarget, LogoCleanMode> {
        if (text.isNullOrBlank()) return emptyMap()
        val out = LinkedHashMap<CleanTarget, LogoCleanMode>()
        for (piece in text.split(",")) {
            val parts = piece.split(":")
            if (parts.size != 2) continue
            val target = CleanTarget.entries.firstOrNull { it.name == parts[0].trim() } ?: continue
            val mode = LogoCleanMode.entries.firstOrNull { it.name == parts[1].trim() } ?: continue
            out[target] = mode
        }
        return out
    }

    /** "\u2714 logo removed" or "\u2714 logo removed \u00B7 subtitle blurred"; empty when nothing was cleaned. */
    fun label(log: Map<CleanTarget, LogoCleanMode>): String =
        if (log.isEmpty()) "" else "\u2714 " + log.entries.joinToString(" \u00B7 ") { it.key.noun + " " + it.value.past() }
}
