package com.videoslidemaker.app.export

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.provider.MediaStore
import com.videoslidemaker.app.data.ImageStore
import com.videoslidemaker.app.data.ScriptParser
import com.videoslidemaker.app.model.AspectRatioOption
import com.videoslidemaker.app.model.EffectStyle
import com.videoslidemaker.app.model.ExportSettings
import com.videoslidemaker.app.model.PoolImage
import com.videoslidemaker.app.model.QualityOption
import com.videoslidemaker.app.model.SentenceSlide
import com.videoslidemaker.app.model.TextOverlay
import com.videoslidemaker.app.model.TransitionStyle
import com.videoslidemaker.app.tts.NarrationTts
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

data class ExportResult(val success: Boolean, val outputUri: Uri?, val error: String? = null)

/**
 * Renders the final matched sequence of photos into a real MP4: H.264 video with Ken Burns
 * zoom and fade transitions (matching the original canvas math exactly) muxed together with a
 * synced narration + background-music audio track. Runs entirely off the main thread and
 * reports progress via [onProgress] so it can be driven safely from a foreground service.
 */
class VideoExportEngine(
    private val context: Context,
    private val imageStore: ImageStore,
    private val tts: NarrationTts
) {
    private val fps = 24
    private val MAX_ORIGINAL_EDGE = 3840 // ~4K ceiling for "Original" quality; see computeOutputSize

    suspend fun export(
        slides: List<SentenceSlide>,
        images: List<PoolImage>,
        settings: ExportSettings,
        textOverlays: List<TextOverlay> = emptyList(),
        onProgress: (percent: Int, message: String) -> Unit
    ): ExportResult = withContext(Dispatchers.Default) {
        if (slides.isEmpty()) return@withContext ExportResult(false, null, "Nothing to export yet.")

        val (outputWidth, outputHeight) = computeOutputSize(images, settings)
        val sequence = buildFinalSequence(slides, images, settings.defaultDurationSec)
        val totalDuration = totalDurationSeconds(slides, images, settings.defaultDurationSec)

        val cacheDir = File(context.cacheDir, "export").apply { mkdirs() }
        // Leftovers from an earlier export that was cancelled, crashed or got stuck (a half-built
        // audio timeline alone can be 200MB+) would otherwise eat the free space checked just below.
        // This folder only ever holds this app's own temporary export files.
        cacheDir.listFiles()?.forEach { runCatching { it.delete() } }
        val outputFile = File(cacheDir, "export_${System.currentTimeMillis()}.mp4")

        // A long or high-resolution export can genuinely need real disk space — both for the
        // temporary narration+music file and the output video itself. Running out mid-export
        // produces a confusing low-level I/O error instead of a clear reason, so estimate what's
        // needed up front and fail fast, before any expensive work, if there isn't room. This
        // isn't exact (final size depends on actual encoder behavior), so it includes a margin.
        val estimatedVideoBytes = (bitrateFor(outputWidth, outputHeight) / 8.0 * totalDuration).toLong()
        val estimatedPcmBytes = (totalDuration * AUDIO_SAMPLE_RATE).toLong() * AUDIO_CHANNELS * 2
        val estimatedNeededBytes = maxOf(estimatedVideoBytes, estimatedPcmBytes) + 200L * 1024 * 1024
        val availableBytes = try {
            StatFs(cacheDir.absolutePath).availableBytes
        } catch (_: Exception) {
            Long.MAX_VALUE // if we can't check for some reason, don't block the export over it
        }
        if (availableBytes < estimatedNeededBytes) {
            val neededMb = estimatedNeededBytes / (1024 * 1024)
            val availableMb = availableBytes / (1024 * 1024)
            return@withContext ExportResult(
                false, null,
                "Not enough free storage for a video this long/large — it needs roughly ${neededMb}MB " +
                    "free and this device only has about ${availableMb}MB. Free up some space (or export " +
                    "a shorter video / lower quality) and try again."
            )
        }

        val hasNarrationText = settings.narration.enabled && (
            if (settings.narration.source == com.videoslidemaker.app.model.AudioSource.ORIGINAL) {
                settings.narration.originalUri != null
            } else {
                slides.any { it.text.isNotBlank() }
            }
        )
        val hasMusic = settings.music.uri != null
        val hasAudio = hasNarrationText || hasMusic

        val muxer = MuxerHolder(outputFile.absolutePath, expectAudioTrack = hasAudio)

        // Kept outside the try so the failure/cancel paths below can always release them: a hardware
        // codec left allocated after an aborted export can make the NEXT export fail or hang.
        var activeAudioEncoder: AudioEncoder? = null
        var activeVideoEncoder: VideoEncoder? = null
        fun cleanUpAfterFailure() {
            try { activeAudioEncoder?.release() } catch (_: Throwable) {}
            try { activeVideoEncoder?.release() } catch (_: Throwable) {}
            try { muxer.release() } catch (_: Throwable) {}
            outputFile.delete()
        }

        // The audio is built and encoded BEFORE the pictures. That used to show a flat "2%" for the
        // whole stage — minutes on a long video — so it looked frozen. It now owns the first 20% of
        // the bar (voice 1-15%, encoding 15-20%), and the picture rendering gets the rest.
        val videoStartPercent = if (hasAudio) 20 else 3

        try {
            if (hasAudio) {
                onProgress(1, "Preparing narration…")
                val pcmAudio = NarrationAudioBuilder(context, tts).build(slides, totalDuration, settings, cacheDir) { fraction, msg ->
                    onProgress(1 + (fraction.coerceIn(0f, 1f) * 14).roundToInt(), msg)
                }
                try {
                    val audioEncoder = AudioEncoder(
                        sampleRate = pcmAudio.sampleRate,
                        channelCount = pcmAudio.channelCount,
                        bitrateBps = 128_000,
                        muxer = muxer
                    )
                    activeAudioEncoder = audioEncoder
                    onProgress(15, "Encoding audio…")
                    audioEncoder.feedPcmFile(
                        pcmAudio.file,
                        pcmAudio.totalBytes,
                        checkCancelled = { ensureActive() },
                        onProgress = { fraction ->
                            onProgress(15 + (fraction * 5).roundToInt(), "Encoding audio… ${(fraction * 100).roundToInt()}%")
                        }
                    )
                    audioEncoder.finish(checkCancelled = { ensureActive() })
                } finally {
                    pcmAudio.file.delete()
                }
            }

            onProgress(videoStartPercent, "Starting video render…")
            val bitrate = bitrateFor(outputWidth, outputHeight)
            val videoEncoder = VideoEncoder(outputWidth, outputHeight, fps, bitrate, muxer)
            activeVideoEncoder = videoEncoder
            val renderer = FrameRenderer(outputWidth, outputHeight)
            val frameBitmap = Bitmap.createBitmap(outputWidth, outputHeight, Bitmap.Config.ARGB_8888)
            val maxSourceEdge = max(outputWidth, outputHeight)
            val fadeSeconds = 0.4f

            var successCount = 0
            var firstFailureReason: String? = null

            for (i in sequence.indices) {
                val item = sequence[i]
                val totalFrames = max(1, (item.durationSec * fps).roundToInt())
                ensureActive() // lets Cancel Export stop the render straight away
                onProgress(
                    videoStartPercent + ((i.toFloat() / sequence.size) * (95 - videoStartPercent)).roundToInt(),
                    "Image ${i + 1} of ${sequence.size} — ${ScriptParser.formatTime(item.startSec)}"
                )

                val sourceBitmap = if (item.image == null) {
                    if (firstFailureReason == null) {
                        firstFailureReason = "one of your sentences has no photo assigned and none left to fall back to"
                    }
                    null
                } else {
                    try {
                        val bmp = imageStore.decodeForExport(item.image.uri, maxSourceEdge)
                        if (bmp == null && firstFailureReason == null) {
                            firstFailureReason = "a photo (\"${item.image.displayName}\") couldn't be opened — " +
                                "its file may have moved or been deleted, or its access permission may have expired"
                        }
                        bmp
                    } catch (e: CancellationException) {
                        throw e // Cancel Export must stop the export, not be counted as a "bad photo"
                    } catch (e: SecurityException) {
                        if (firstFailureReason == null) {
                            firstFailureReason = "a photo's (\"${item.image.displayName}\") access permission has expired"
                        }
                        null
                    } catch (e: Exception) {
                        if (firstFailureReason == null) {
                            firstFailureReason = "a photo (\"${item.image.displayName}\") failed to decode: ${e.message ?: e.javaClass.simpleName}"
                        }
                        null
                    }
                }

                if (sourceBitmap != null) {
                    successCount++
                    val usesFadeBlack = settings.transitionStyle == TransitionStyle.FADE_BLACK
                    val fadeFraction = if (usesFadeBlack) min(0.5f, fadeSeconds / item.durationSec.toFloat()) else 0f

                    // Crossfade/Slide need the INCOMING photo on screen too, unlike a fade to
                    // black — decoded fresh here (rather than threaded across loop iterations)
                    // so each iteration stays fully self-contained: simpler and safer, at the
                    // minor cost of occasionally decoding a photo twice.
                    val usesBlendTransition = settings.transitionStyle == TransitionStyle.CROSSFADE ||
                        settings.transitionStyle == TransitionStyle.SLIDE
                    val nextItem = sequence.getOrNull(i + 1)
                    val nextBitmapForTransition: Bitmap? = if (usesBlendTransition && nextItem?.image != null) {
                        try { imageStore.decodeForExport(nextItem.image.uri, maxSourceEdge) } catch (e: CancellationException) { throw e } catch (e: Exception) { null }
                    } else null

                    val transitionFrames = if (nextBitmapForTransition != null) {
                        min(totalFrames / 3, (fadeSeconds * fps).roundToInt()).coerceAtLeast(0)
                    } else 0
                    val steadyFrames = totalFrames - transitionFrames

                    for (f in 0 until steadyFrames) {
                        ensureActive()
                        val progress = f / totalFrames.toFloat()
                        val frameTimeSec = item.startSec + f.toDouble() / fps
                        renderer.renderFrame(frameBitmap, sourceBitmap, progress, settings.effectStyle, fadeFraction, fadeFraction)
                        renderer.drawTextOverlays(frameBitmap, overlaysActiveAt(frameTimeSec, textOverlays))
                        videoEncoder.encodeFrame(frameBitmap)
                    }
                    if (transitionFrames > 0 && nextBitmapForTransition != null) {
                        for (f in 0 until transitionFrames) {
                            ensureActive()
                            val t = (f + 1) / transitionFrames.toFloat()
                            val frameTimeSec = item.startSec + (steadyFrames + f).toDouble() / fps
                            renderer.renderTransitionFrame(frameBitmap, sourceBitmap, nextBitmapForTransition, t, settings.transitionStyle)
                            renderer.drawTextOverlays(frameBitmap, overlaysActiveAt(frameTimeSec, textOverlays))
                            videoEncoder.encodeFrame(frameBitmap)
                        }
                    }
                    sourceBitmap.recycle()
                    nextBitmapForTransition?.recycle()
                } else {
                    // Missing/unreadable photo: hold the slot with black frames instead of
                    // collapsing the timeline out of sync with the audio track.
                    for (f in 0 until totalFrames) {
                        ensureActive()
                        val frameTimeSec = item.startSec + f.toDouble() / fps
                        val blackCanvas = Canvas(frameBitmap)
                        blackCanvas.drawColor(Color.BLACK)
                        renderer.drawTextOverlays(frameBitmap, overlaysActiveAt(frameTimeSec, textOverlays))
                        videoEncoder.encodeFrame(frameBitmap)
                    }
                }
            }

            if (successCount == 0 && sequence.isNotEmpty()) {
                // Every single slide fell back to a black frame — a "successful" export with
                // nothing in it is worse than telling you plainly what's wrong. This is exactly
                // what was happening silently before.
                throw IllegalStateException(
                    "None of your photos could be loaded, so there was nothing to put in the video" +
                        (firstFailureReason?.let { " ($it)" } ?: "") +
                        ". Try removing and re-adding your photos on the Photos step, then export again."
                )
            }

            videoEncoder.finish()
            frameBitmap.recycle()
        } catch (e: CancellationException) {
            // Cancel Export: clean up fully, then let the cancellation continue — it must not be
            // turned into an "Export failed" message.
            cleanUpAfterFailure()
            throw e
        } catch (e: OutOfMemoryError) {
            // An Error, not an Exception — a plain "catch (e: Exception)" never sees this at
            // all, so it used to escape uncaught and crash past this whole error-reporting path
            // entirely, which is exactly what produced a blank "something went wrong with no
            // message" failure instead of a real explanation.
            cleanUpAfterFailure()
            return@withContext ExportResult(
                false, null,
                "Ran out of memory during export — this usually happens with very high-resolution " +
                    "photos at \"Original\" quality. Try a lower quality setting (720p or 1080p) and export again."
            )
        } catch (e: Throwable) {
            cleanUpAfterFailure()
            return@withContext ExportResult(false, null, e.message ?: "Export failed (${e.javaClass.simpleName}).")
        }

        muxer.release()

        onProgress(97, "Saving to your gallery…")
        val savedUri = saveToGallery(outputFile)
        outputFile.delete()
        onProgress(100, "Done")

        if (savedUri != null) ExportResult(true, savedUri)
        else ExportResult(false, null, "Could not save the finished video to your device storage.")
    }

    private data class SequenceItem(val image: PoolImage?, val startSec: Double, val durationSec: Double)

    private fun buildFinalSequence(
        slides: List<SentenceSlide>,
        images: List<PoolImage>,
        defaultDurationSec: Int
    ): List<SequenceItem> {
        val imageById = images.associateBy { it.id } // O(1) lookups: thousands of photos stay fast
        val usedFallbacks = HashSet<String>()
        var fallbackPointer = 0
        fun nextFallback(): PoolImage? {
            while (fallbackPointer < images.size && images[fallbackPointer].id in usedFallbacks) fallbackPointer++
            return images.getOrNull(fallbackPointer)
        }

        return slides.mapIndexed { index, slide ->
            val start = slide.timestampSec
            val assigned = slide.assignedImageId?.let { id -> imageById[id] }

            // For the last slide there's no "next timestamp" to derive a length from, so fall
            // back to that specific photo's own time box if it has one (simple/no-script mode),
            // and only then to the global default (matches the original script-mode behavior).
            val end = slides.getOrNull(index + 1)?.timestampSec
                ?: (start + (assigned?.durationOverrideSec ?: defaultDurationSec.toDouble()))
            val duration = max(0.1, end - start)

            val image = assigned ?: run {
                val fallback = nextFallback()
                if (fallback != null) usedFallbacks.add(fallback.id)
                fallback ?: images.firstOrNull()
            }
            SequenceItem(image, start, duration)
        }
    }

    private fun totalDurationSeconds(slides: List<SentenceSlide>, images: List<PoolImage>, defaultDurationSec: Int): Double {
        if (slides.isEmpty()) return 0.0
        val last = slides.last()
        val lastImage = last.assignedImageId?.let { id -> images.firstOrNull { it.id == id } }
        return last.timestampSec + max(0.1, lastImage?.durationOverrideSec ?: defaultDurationSec.toDouble())
    }

    private fun computeOutputSize(images: List<PoolImage>, settings: ExportSettings): Pair<Int, Int> {
        val ratio = settings.aspectRatio
        if (settings.quality == QualityOption.ORIGINAL) {
            val largest = images.maxByOrNull { it.widthPx.toLong() * it.heightPx.toLong() }
            val maxW = largest?.widthPx?.takeIf { it > 0 } ?: 1920
            val maxH = largest?.heightPx?.takeIf { it > 0 } ?: 1080
            val base = max(maxW, maxH)
            var w: Int
            var h: Int
            if (ratio.w >= ratio.h) {
                h = base * ratio.h / ratio.w
                w = base
                if (w < maxW) { w = maxW; h = (w.toLong() * ratio.h / ratio.w).toInt() }
            } else {
                w = base * ratio.w / ratio.h
                h = base
                if (h < maxH) { h = maxH; w = (h.toLong() * ratio.w / ratio.h).toInt() }
            }
            // "Original" should still track the photo's real resolution, but a truly enormous
            // sensor output (48MP+ is now common even on mid-range phones) risks
            // OutOfMemoryError well before it adds anything visible for a slideshow-style video
            // — most platforms cap well below this anyway. Scale down proportionally if needed,
            // never up.
            val longestEdge = max(w, h)
            if (longestEdge > MAX_ORIGINAL_EDGE) {
                val factor = MAX_ORIGINAL_EDGE.toDouble() / longestEdge
                w = (w * factor).toInt().coerceAtLeast(2)
                h = (h * factor).toInt().coerceAtLeast(2)
            }
            return align16(w) to align16(h)
        }
        return capped(ratio, settings.quality.basePx ?: 720)
    }

    private fun capped(ratio: AspectRatioOption, base: Int): Pair<Int, Int> {
        val w: Int
        val h: Int
        if (ratio.w >= ratio.h) {
            h = base
            w = (base.toLong() * ratio.w / ratio.h).toInt()
        } else {
            w = base
            h = (base.toLong() * ratio.h / ratio.w).toInt()
        }
        return align16(w) to align16(h)
    }

    /**
     * Rounds up to the nearest multiple of 16 — the standard H.264 macroblock size — instead of
     * merely making the value even. Landing exactly on a 16-boundary means most real encoders
     * won't need to pad rows internally at all, so this sidesteps the whole stride-padding class
     * of bug (see the size comment in VideoEncoder.encodeFrame) for the common case, on top of
     * that fix already handling it correctly when padding does still happen.
     */
    private fun align16(v: Int): Int {
        val remainder = v % 16
        return if (remainder == 0) v else v + (16 - remainder)
    }

    /** Mirrors UiState.overlaysActiveAt exactly, so export and the live Preview screen compute
     *  overlay visibility/fade identically — kept as its own local copy rather than a shared
     *  call so the export engine doesn't need to depend on the UI-layer UiState class. */
    private fun overlaysActiveAt(positionSec: Double, overlays: List<TextOverlay>): List<Pair<TextOverlay, Float>> {
        val fadeSec = 0.35
        return overlays.mapNotNull { overlay ->
            val end = overlay.startSec + overlay.durationSec
            if (positionSec < overlay.startSec || positionSec >= end) return@mapNotNull null
            val sinceStart = positionSec - overlay.startSec
            val untilEnd = end - positionSec
            val alpha = minOf(1.0, sinceStart / fadeSec, untilEnd / fadeSec).coerceIn(0.0, 1.0)
            overlay to alpha.toFloat()
        }
    }

    private fun bitrateFor(width: Int, height: Int): Int {
        val pixels = width.toLong() * height.toLong()
        return when {
            pixels >= 3840L * 2160L -> 20_000_000
            pixels >= 1920L * 1080L -> 8_000_000
            pixels >= 1280L * 720L -> 4_500_000
            else -> 2_500_000
        }
    }

    private fun saveToGallery(sourceFile: File): Uri? {
        val displayName = "VideoSlideMaker_${System.currentTimeMillis()}.mp4"
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, displayName)
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/VideoSlideMaker")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
            val resolver = context.contentResolver
            val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values) ?: return null
            resolver.openOutputStream(uri)?.use { out -> sourceFile.inputStream().use { it.copyTo(out) } }
            values.clear()
            values.put(MediaStore.Video.Media.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
            uri
        } else {
            @Suppress("DEPRECATION")
            val moviesDir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES), "VideoSlideMaker")
            if (!moviesDir.exists()) moviesDir.mkdirs()
            val destFile = File(moviesDir, displayName)
            sourceFile.inputStream().use { input -> FileOutputStream(destFile).use { output -> input.copyTo(output) } }
            android.media.MediaScannerConnection.scanFile(context, arrayOf(destFile.absolutePath), arrayOf("video/mp4"), null)
            Uri.fromFile(destFile)
        }
    }
}
