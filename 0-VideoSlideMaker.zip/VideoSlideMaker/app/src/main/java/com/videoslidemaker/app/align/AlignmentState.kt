package com.videoslidemaker.app.align

import android.net.Uri

/** Everything the UI needs about the timestamp-alignment feature. Part of [com.videoslidemaker.app.model.UiState]. */
data class AlignmentState(
    val recordingUri: Uri? = null,
    val recordingName: String? = null,
    val running: Boolean = false,
    val percent: Int = 0,
    val stage: String = "",
    val error: String? = null,
    /** One result per script line, from the last analysis. Empty until analysed. */
    val items: List<AlignmentItem> = emptyList(),
    val clarityDb: Float = 0f,
    val drift: List<DriftPoint> = emptyList(),
    /** Apply high-confidence corrections as soon as an analysis finishes. Off unless the user turns it on. */
    val autoApply: Boolean = false,
    val reviewOpen: Boolean = false,
    /** One-line note about the last apply/restore (for example how many were skipped and why). */
    val notice: String? = null,
    /** Stretches of lines that could not be aligned confidently, from the last analysis. */
    val sections: List<AlignmentSection> = emptyList(),
    /** Also use the words a speech recognizer hears (needs the speech model; slower, but more accurate and works at any offset). */
    val useWords: Boolean = true,
    /** The last analysis really used the words (false = audio only, whatever the setting). */
    val usedWords: Boolean = false
)
