package com.videoslidemaker.app.tts

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull
import java.io.File
import java.util.Locale
import java.util.UUID
import kotlin.coroutines.resume

/**
 * Wraps Android's built-in TextToSpeech engine for two jobs:
 *  1. Live "🔊 listen" playback while matching a sentence to a photo — same role the original
 *     app's browser speechSynthesis call played.
 *  2. NEW: synthesizing narration to a WAV file at export time so it can be muxed into the
 *     final MP4 as a real audio track, which the original app never did.
 */
class NarrationTts(context: Context) {
    // Written by the engine's init callback (main thread), read from the export thread.
    @Volatile private var ready = false
    @Volatile private var initFinished = false
    private val engine = TextToSpeech(context.applicationContext) { status ->
        ready = status == TextToSpeech.SUCCESS
        initFinished = true
    }

    // Setting the language/rate on every sentence makes the engine reload its voice, which can
    // freeze the preview for a moment each time a new slide starts. Only change them when they
    // actually differ from what is already set.
    private var appliedLocaleTag: String? = null
    private var appliedRate: Float = -1f

    private fun applyVoice(localeTag: String, rate: Float) {
        if (appliedLocaleTag != localeTag) {
            engine.language = Locale.forLanguageTag(localeTag)
            appliedLocaleTag = localeTag
        }
        if (appliedRate != rate) {
            engine.setSpeechRate(rate)
            appliedRate = rate
        }
    }

    fun speak(text: String, localeTag: String, rate: Float = 0.95f) {
        if (!ready || text.isBlank()) return
        applyVoice(localeTag, rate)
        engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, UUID.randomUUID().toString())
    }

    fun stop() {
        engine.stop()
    }

    /**
     * Returns true if synthesis completed and [outFile] contains a playable WAV.
     *
     * Never waits forever: if the engine goes silent for a sentence (no "done", no "error" — this
     * does happen with some voice engines) the sentence is given up on after a time limit that
     * scales with its length, instead of freezing the whole export on one line.
     */
    suspend fun synthesizeToFile(text: String, localeTag: String, rate: Float, outFile: File): Boolean {
        if (text.isBlank()) return false

        // A brand-new engine needs a moment to start up. Exporting used to begin immediately and
        // quietly skip the first sentences until it was ready.
        var waitedMs = 0L
        while (!initFinished && waitedMs < INIT_WAIT_LIMIT_MS) {
            delay(100)
            waitedMs += 100
        }
        if (!ready) return false

        applyVoice(localeTag, rate)

        // Engines reject (or silently stall on) text longer than their own maximum.
        val maxLen = try { TextToSpeech.getMaxSpeechInputLength() } catch (_: Throwable) { 4000 }
        val safeText = if (text.length > maxLen) text.substring(0, maxLen) else text

        if (outFile.exists()) outFile.delete()
        val utteranceId = UUID.randomUUID().toString()
        val timeoutMs = SYNTH_BASE_TIMEOUT_MS + safeText.length * SYNTH_PER_CHAR_TIMEOUT_MS

        val result: Boolean? = withTimeoutOrNull(timeoutMs) {
            suspendCancellableCoroutine<Boolean> { cont ->
                // Several callbacks can race (e.g. an error followed by a stop); only the first counts.
                fun finishWith(value: Boolean) {
                    if (cont.isActive) {
                        try { cont.resume(value) } catch (_: IllegalStateException) {}
                    }
                }
                cont.invokeOnCancellation {
                    try { engine.stop() } catch (_: Throwable) {}
                }
                engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}

                    override fun onDone(id: String?) {
                        if (id == utteranceId) finishWith(true)
                    }

                    @Deprecated("Deprecated in Java", ReplaceWith(""))
                    override fun onError(id: String?) {
                        if (id == utteranceId) finishWith(false)
                    }

                    override fun onError(id: String?, errorCode: Int) {
                        if (id == utteranceId) finishWith(false)
                    }

                    // If the engine is told to stop (or drops the line) it reports "stopped" and
                    // NEVER "done" or "error" — which used to leave the export waiting forever.
                    override fun onStop(id: String?, interrupted: Boolean) {
                        if (id == utteranceId) finishWith(false)
                    }
                })
                val queued = engine.synthesizeToFile(safeText, null, outFile, utteranceId)
                if (queued != TextToSpeech.SUCCESS) finishWith(false)
            }
        }

        if (result == null) {
            // Timed out: reset the engine so the next sentence starts from a clean state.
            try { engine.stop() } catch (_: Throwable) {}
            return false
        }
        return result
    }

    fun isLanguageAvailable(localeTag: String): Boolean = try {
        engine.isLanguageAvailable(Locale.forLanguageTag(localeTag)) >= TextToSpeech.LANG_AVAILABLE
    } catch (_: Exception) {
        false
    }

    fun shutdown() {
        engine.stop()
        engine.shutdown()
    }

    companion object {
        private const val INIT_WAIT_LIMIT_MS = 10_000L
        private const val SYNTH_BASE_TIMEOUT_MS = 20_000L
        private const val SYNTH_PER_CHAR_TIMEOUT_MS = 50L
    }
}
