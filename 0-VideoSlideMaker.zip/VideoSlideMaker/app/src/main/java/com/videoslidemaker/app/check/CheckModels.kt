package com.videoslidemaker.app.check

/*
 * Audio-transcript accuracy checker: the models.
 *
 * The AUDIO is the source of truth. The checker is given the transcript's timestamped segments and the words a speech
 * recognizer heard (each with start / end in ms on the recording's clock and a 0..1 confidence), and returns one verdict
 * per segment. Nothing in this package touches Android, so all of it runs in plain JVM unit tests.
 *
 * This is a port of tools/accuracy-reference/checker.py, which was designed and tested first. Keep the two in step:
 * AccuracyCheckerTest.kt runs the same scenarios as tools/accuracy-reference/run_tests.py.
 */

/** What is wrong (or not) with one transcript segment. Always from the transcript's point of view. */
enum class CheckStatus(val label: String, val emoji: String) {
    /** Nothing wrong found. */
    MATCH("MATCH", "\uD83D\uDFE2"),

    /** The words are right, but the segment starts at a different time than its timestamp says. */
    TIMESTAMP_ERROR("TIMESTAMP ERROR", "\uD83D\uDFE1"),

    /** A transcript word was replaced by a different spoken word. */
    TEXT_MISMATCH("TEXT MISMATCH", "\uD83D\uDD34"),

    /** A word is spoken in the audio but is NOT in the transcript (the transcript is missing it). */
    MISSING_WORD("MISSING WORD", "\uD83D\uDD34"),

    /** A word is in the transcript but is NOT spoken in the audio (the transcript has one too many). */
    EXTRA_WORD("EXTRA WORD", "\uD83D\uDD34"),

    /** The recognizer is not sure enough to accuse the transcript. */
    UNCERTAIN("UNCERTAIN", "\u26AA")
}

data class CheckSettings(
    /** How far a timestamp may be from the real start before it is an error. */
    val timestampToleranceMs: Long = 500L,
    /** Below this a recognized word is "not sure": shown, but never counted as an error. */
    val minWordConfidence: Double = 0.60,
    /** um / uh / hmm are ignored on both sides. */
    val ignoreFillers: Boolean = true
)

/** One transcript segment: the timestamp it claims and its text. */
data class CheckSegment(val timestampMs: Long, val text: String)

/** One word heard by the recognizer. [startMs] / [endMs] are on the recording's own clock. */
data class SpokenWord(val text: String, val startMs: Long, val endMs: Long, val conf: Double = 1.0)

/**
 * One problem inside a segment.
 *
 * @property firm       false = "possible": it is shown, but it is not counted as an error and cannot make the segment red.
 * @property transcriptText the transcript's words ("" for [CheckStatus.MISSING_WORD]).
 * @property audioText      the spoken words ("" for [CheckStatus.EXTRA_WORD]).
 * @property audioStartMs   where in the audio it happens. For EXTRA_WORD: where the word would have to be (the gap).
 * @property tFrom          the issue is about the segment's words [tFrom, tTo) (for MISSING_WORD both are the position it goes in).
 */
data class WordIssue(
    val kind: CheckStatus,
    val firm: Boolean,
    val transcriptText: String,
    val audioText: String,
    val audioStartMs: Long?,
    val audioEndMs: Long?,
    val tFrom: Int,
    val tTo: Int,
    val note: String = ""
)

/** Whether a segment's timestamp agrees with where its words are really spoken. */
data class TimestampCheck(
    val transcriptMs: Long,
    /** Where the segment's speech really starts, or null when that could not be pinned down. */
    val actualMs: Long?,
    val toleranceMs: Long,
    val verifiable: Boolean
) {
    /** actual − transcript. Positive = the transcript's timestamp is too early. */
    val diffMs: Long? get() = actualMs?.let { it - transcriptMs }

    val isError: Boolean get() = verifiable && actualMs != null && kotlin.math.abs(actualMs - transcriptMs) > toleranceMs

    /** The timestamp to use instead, only when there is an error. */
    val correctedMs: Long? get() = if (isError) actualMs else null
}

data class SegmentResult(
    val index: Int,
    val timestampMs: Long,
    val text: String,
    val words: List<String>,
    val status: CheckStatus,
    val issues: List<WordIssue>,
    val timestamp: TimestampCheck?,
    /** What the audio says for this segment, in the recognizer's words. */
    val spokenText: String,
    val audioStartMs: Long?,
    val audioEndMs: Long?,
    val matchedWords: Int,
    val reason: String = ""
) {
    val firmIssues: List<WordIssue> get() = issues.filter { it.firm }

    /** The timestamp is wrong even though the status shown is a (higher-priority) text problem. */
    val hasTimestampError: Boolean get() = timestamp?.isError == true

    /** Where a tap on this segment should jump: the first real problem, else where the speech starts. */
    val jumpMs: Long?
        get() = firmIssues.firstOrNull { it.audioStartMs != null }?.audioStartMs
            ?: timestamp?.actualMs
            ?: audioStartMs
}

data class CheckResult(
    val segments: List<SegmentResult>,
    val wordTotal: Int,
    val wordMatched: Int,
    /** Nearly every timestamp is a whole second, so the tolerance was widened to +-1 s. */
    val wholeSecondTimestamps: Boolean
) {
    fun count(status: CheckStatus): Int = segments.count { it.status == status }

    /** Share of the transcript's words that the audio confirms. */
    val accuracy: Double get() = if (wordTotal == 0) 1.0 else wordMatched.toDouble() / wordTotal
}

/** The text the screen shows. Same formats as tools/accuracy-reference/checker.py (and [com.videoslidemaker.app.data.TimestampParser.formatCanonical]). */
object CheckFormat {
    /** `00:00:05.000`. */
    fun clock(ms: Long): String {
        val t = if (ms < 0) 0L else ms
        fun two(n: Long) = n.toString().padStart(2, '0')
        return "${two(t / 3_600_000)}:${two((t / 60_000) % 60)}:${two((t / 1000) % 60)}.${(t % 1000).toString().padStart(3, '0')}"
    }

    /** `+3.120 seconds`, `-0.250 seconds`, `0.000 seconds`. */
    fun signedSeconds(ms: Long): String {
        val sign = if (ms > 0) "+" else if (ms < 0) "-" else ""
        val a = if (ms < 0) -ms else ms
        return "$sign${a / 1000}.${(a % 1000).toString().padStart(3, '0')} seconds"
    }
}
