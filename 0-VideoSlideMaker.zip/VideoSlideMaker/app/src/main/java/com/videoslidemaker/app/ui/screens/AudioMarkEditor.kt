package com.videoslidemaker.app.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.videoslidemaker.app.audio.AudioClip
import com.videoslidemaker.app.audio.AudioEditUi
import com.videoslidemaker.app.audio.AudioLimits
import com.videoslidemaker.app.audio.AudioMixSettings
import com.videoslidemaker.app.audio.BgSlots
import com.videoslidemaker.app.audio.MarkMath
import com.videoslidemaker.app.audio.SoundKind
import com.videoslidemaker.app.audio.SoundMood
import com.videoslidemaker.app.audio.SoundProfiles
import com.videoslidemaker.app.ui.components.AlertBox
import com.videoslidemaker.app.ui.components.AlertStyle
import com.videoslidemaker.app.ui.components.CompactButton
import com.videoslidemaker.app.ui.components.PrimaryButton
import com.videoslidemaker.app.ui.components.SecondaryButton
import com.videoslidemaker.app.ui.components.SectionCard
import com.videoslidemaker.app.ui.components.SettingToggleRow
import com.videoslidemaker.app.ui.components.WheelSheet
import com.videoslidemaker.app.ui.theme.Accent
import com.videoslidemaker.app.ui.theme.BorderColor
import com.videoslidemaker.app.ui.theme.CardBg
import com.videoslidemaker.app.ui.theme.Muted
import com.videoslidemaker.app.ui.theme.OnAccent
import com.videoslidemaker.app.ui.theme.Outline
import com.videoslidemaker.app.ui.theme.Red
import com.videoslidemaker.app.ui.theme.Surface
import com.videoslidemaker.app.ui.theme.TextMain
import com.videoslidemaker.app.viewmodel.AppViewModel
import kotlin.math.ceil
import kotlin.math.max

/*
 * NEW (2.19): the Audio step's editor for ONE background sound, in the order a person uses it:
 *
 *   1. MarkPartCard   - see the ORIGINAL file, mark the part wanted (drag, type the times, or listen and tap "mark here"),
 *                       and keep only that part. Everything else is set aside; "whole original" brings it back.
 *   2. SoundTypeCard  - what kind of sound it is (music, beat, ambience, a sound effect...) - the app then adjusts it.
 *   3. AssignCard     - give it to the whole video, or to B1, B2... (a scene or a time range).
 *
 * The maths of the marks lives in audio/MarkMath.kt (tested); this file is only the screen.
 */

private fun fmt(sec: Double): String = MarkMath.format(sec)

// ---------------------------------------------------------------------------------------------
// 1. Mark the part to keep
// ---------------------------------------------------------------------------------------------

@Composable
internal fun MarkPartCard(clip: AudioClip, peaks: FloatArray?, ui: AudioEditUi, viewModel: AppViewModel) {
    val fileLen = clip.sourceDurationSec
    SectionCard(title = "Mark the part to keep", modifier = Modifier.padding(bottom = 12.dp)) {
        if (fileLen <= 0.0) {
            Text("Measuring the original sound…", style = MaterialTheme.typography.bodySmall, color = Muted)
        } else {
            MarkPartBody(clip, fileLen, peaks, ui, viewModel)
        }
    }
}

@Composable
private fun androidx.compose.foundation.layout.ColumnScope.MarkPartBody(
    clip: AudioClip,
    fileLen: Double,
    peaks: FloatArray?,
    ui: AudioEditUi,
    viewModel: AppViewModel
) {
    // Where the marks start: the part that is used now (the whole file when nothing was marked).
    val startNow = clip.srcStartSec
    val endNow = when {
        clip.hasMark -> clip.markEndSec
        clip.srcEndSec > clip.srcStartSec + AudioLimits.MIN_CLIP_SEC -> clip.srcEndSec
        else -> fileLen
    }
    var markA by remember(clip.id, startNow, endNow, fileLen) { mutableStateOf(startNow) }
    var markB by remember(clip.id, startNow, endNow, fileLen) { mutableStateOf(endNow) }
    var problem by remember(clip.id) { mutableStateOf<String?>(null) }
    val len = MarkMath.lengthSec(markA, markB)
    val listening = ui.listenId == clip.id && (ui.listenPlaying || ui.listenBuilding)

    fun setMarks(p: Pair<Double, Double>) {
        markA = p.first
        markB = p.second
        problem = null
    }

    Text(
        "This is the ORIGINAL sound, however it was cut or stretched before. Drag on the picture (the nearer mark moves), " +
            "type the exact times, or listen and tap \"Mark here\". The red parts are set aside; only the part between the marks stays - " +
            "and only that part repeats or stretches over the video or a scene.",
        style = MaterialTheme.typography.bodySmall,
        color = Muted,
        modifier = Modifier.padding(bottom = 8.dp)
    )
    MarkWaveform(
        peaks = peaks,
        durationSec = fileLen,
        start = markA,
        end = markB,
        playhead = if (listening) ui.listenPosSec else null,
        onMark = { a, b -> setMarks(a to b) }
    )
    Row(Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text("0:00.0", style = MaterialTheme.typography.labelSmall, color = Muted)
        Text("Original: ${fmt(fileLen)} long", style = MaterialTheme.typography.labelSmall, color = TextMain)
        Text(fmt(fileLen), style = MaterialTheme.typography.labelSmall, color = Muted)
    }

    // ---- exact times, typed
    var typedA by remember(fmt(markA)) { mutableStateOf(fmt(markA)) }
    var typedB by remember(fmt(markB)) { mutableStateOf(fmt(markB)) }
    Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.Bottom) {
        TimeBox("Start", fmt(markA), Modifier.weight(1f)) { typedA = it }
        TimeBox("End", fmt(markB), Modifier.weight(1f)) { typedB = it }
    }
    SecondaryButton("Set these times", onClick = {
        val a = MarkMath.parseTime(typedA)
        val b = MarkMath.parseTime(typedB)
        if (a == null || b == null) {
            problem = "Type a time like 72.5 or 1:12.5 (minutes:seconds) in both boxes."
        } else {
            setMarks(MarkMath.fix(a, b, fileLen))
        }
    })
    problem?.let { AlertBox(it, AlertStyle.WARNING, Modifier.padding(bottom = 4.dp)) }
    Text(
        "Marked: ${fmt(markA)} → ${fmt(markB)}  ·  ${fmt(len)} long",
        style = MaterialTheme.typography.bodyMedium,
        color = TextMain,
        fontWeight = FontWeight.Medium,
        modifier = Modifier.padding(top = 4.dp)
    )

    // ---- fine nudges
    Text("Move the start", style = MaterialTheme.typography.labelMedium, color = Muted, modifier = Modifier.padding(top = 8.dp))
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        CompactButton("−1s", onClick = { setMarks(MarkMath.withStart(markA, markB, markA - 1.0, fileLen)) })
        CompactButton("−0.1", onClick = { setMarks(MarkMath.withStart(markA, markB, markA - 0.1, fileLen)) })
        CompactButton("+0.1", onClick = { setMarks(MarkMath.withStart(markA, markB, markA + 0.1, fileLen)) })
        CompactButton("+1s", onClick = { setMarks(MarkMath.withStart(markA, markB, markA + 1.0, fileLen)) })
    }
    Text("Move the end", style = MaterialTheme.typography.labelMedium, color = Muted, modifier = Modifier.padding(top = 4.dp))
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        CompactButton("−1s", onClick = { setMarks(MarkMath.withEnd(markA, markB, markB - 1.0, fileLen)) })
        CompactButton("−0.1", onClick = { setMarks(MarkMath.withEnd(markA, markB, markB - 0.1, fileLen)) })
        CompactButton("+0.1", onClick = { setMarks(MarkMath.withEnd(markA, markB, markB + 0.1, fileLen)) })
        CompactButton("+1s", onClick = { setMarks(MarkMath.withEnd(markA, markB, markB + 1.0, fileLen)) })
    }
    Text("Move both (keeps the length)", style = MaterialTheme.typography.labelMedium, color = Muted, modifier = Modifier.padding(top = 4.dp))
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        CompactButton("◀ 1s", onClick = { setMarks(MarkMath.shift(markA, markB, -1.0, fileLen)) })
        CompactButton("◀ len", onClick = { setMarks(MarkMath.shift(markA, markB, -len, fileLen)) })
        CompactButton("len ▶", onClick = { setMarks(MarkMath.shift(markA, markB, len, fileLen)) })
        CompactButton("1s ▶", onClick = { setMarks(MarkMath.shift(markA, markB, 1.0, fileLen)) })
    }

    // ---- listen
    Text("Listen", style = MaterialTheme.typography.titleSmall, color = TextMain, modifier = Modifier.padding(top = 12.dp))
    when {
        ui.listenId == clip.id && ui.listenBuilding ->
            SecondaryButton("Getting the sound ready…", enabled = false, onClick = {})
        listening -> {
            Text(
                "Playing the original at ${fmt(ui.listenPosSec)}. Tap when you hear where the part begins or ends.",
                style = MaterialTheme.typography.bodySmall,
                color = TextMain
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                CompactButton("📍 Mark start here", onClick = { setMarks(MarkMath.withStart(markA, markB, ui.listenPosSec, fileLen)) })
                CompactButton("📍 Mark end here", onClick = { setMarks(MarkMath.withEnd(markA, markB, ui.listenPosSec, fileLen)) })
            }
            SecondaryButton("■ Stop", onClick = viewModel::audioStopListen)
        }
        else -> {
            SecondaryButton("▶ Listen to the original from the start mark", onClick = {
                viewModel.audioListen(clip.id, markA, minOf(markA + 30.0, fileLen), 1)
            })
            SecondaryButton("▶ Hear only the marked part, repeated", enabled = len >= AudioLimits.MIN_CLIP_SEC, onClick = {
                // enough rounds to hear about 12 seconds, so the repeat can be judged
                val rounds = if (len <= 0.0) 1 else ceil(12.0 / len).toInt().coerceIn(2, 8)
                viewModel.audioListen(clip.id, markA, markB, rounds)
            })
        }
    }

    // ---- keep / bring back
    Text(
        if (clip.hasMark) "Now kept: ${fmt(clip.srcStartSec)} → ${fmt(clip.markEndSec)} (${fmt(clip.lengthSec)} long). The rest of the original is set aside."
        else if (clip.usesPartOfFile) "Now used: ${fmt(clip.srcStartSec)} → ${fmt(clip.srcEndSec)}."
        else "Now the whole original is used.",
        style = MaterialTheme.typography.bodySmall,
        color = Muted,
        modifier = Modifier.padding(top = 12.dp)
    )
    PrimaryButton("✂ Keep only the marked part", enabled = len >= AudioLimits.MIN_CLIP_SEC, onClick = { viewModel.audioKeepOnly(clip.id, markA, markB) })
    SecondaryButton("↺ Use the whole original again", enabled = clip.usesPartOfFile, onClick = { viewModel.audioUseWholeFile(clip.id) })
    SettingToggleRow(
        "Repeat exactly (best for a beat)",
        "Every round is the same length and the join is not blended, so the rhythm stays on the beat. A part of ${AudioLimits.EXACT_LOOP_AUTO_MAX_SEC.toInt()} seconds or less turns this on by itself.",
        clip.exactLoop
    ) { on -> viewModel.audioEdit(clip.id) { it.copy(exactLoop = on) } }
}

/** A small text box for a time, with its own label. Its text is reset whenever [value] changes (a mark moved). */
@Composable
private fun TimeBox(label: String, value: String, modifier: Modifier, onTyped: (String) -> Unit) {
    var text by remember(value) { mutableStateOf(TextFieldValue(value, TextRange(value.length))) }
    androidx.compose.foundation.layout.Column(modifier) {
        Text(label, style = MaterialTheme.typography.labelMedium, color = Muted)
        BasicTextField(
            value = text,
            onValueChange = {
                text = it
                onTyped(it.text)
            },
            singleLine = true,
            textStyle = TextStyle(color = TextMain, fontSize = MaterialTheme.typography.bodyLarge.fontSize),
            cursorBrush = SolidColor(Accent),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text),
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = 48.dp)
                .background(Surface, RoundedCornerShape(10.dp))
                .border(1.dp, Outline, RoundedCornerShape(10.dp))
                .padding(12.dp)
                .semantics { contentDescription = "$label time of the part to keep" }
        )
    }
}

/**
 * The ORIGINAL sound drawn as bars with two marks. Inside the marks is bright, outside is dim and red-tinted (it will be set
 * aside). Touch or drag anywhere: the nearer mark follows the finger. Only sideways drags are taken, so the page still scrolls
 * up and down when the picture is touched.
 */
@Composable
private fun MarkWaveform(
    peaks: FloatArray?,
    durationSec: Double,
    start: Double,
    end: Double,
    playhead: Double?,
    onMark: (Double, Double) -> Unit
) {
    val keepColor = Accent
    val dimColor = Outline
    val setAside = Red
    val handle = TextMain
    val head = Red
    val d = durationSec.coerceAtLeast(0.001)
    val curStart by rememberUpdatedState(start)
    val curEnd by rememberUpdatedState(end)
    val curMark by rememberUpdatedState(onMark)

    Canvas(
        Modifier
            .fillMaxWidth()
            .height(110.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(Surface)
            .semantics { contentDescription = "Picture of the original sound. Drag to move the start or the end mark." }
            .pointerInput(d) {
                detectTapGestures { pos ->
                    val t = (pos.x / size.width * d).coerceIn(0.0, d)
                    val p = if (MarkMath.nearestIsStart(curStart, curEnd, t)) MarkMath.withStart(curStart, curEnd, t, d)
                    else MarkMath.withEnd(curStart, curEnd, t, d)
                    curMark(p.first, p.second)
                }
            }
            .pointerInput(d) {
                var grabStart = true
                detectHorizontalDragGestures(
                    onDragStart = { pos ->
                        val t = (pos.x / size.width * d).coerceIn(0.0, d)
                        grabStart = MarkMath.nearestIsStart(curStart, curEnd, t)
                    },
                    onHorizontalDrag = { change, _ ->
                        change.consume()
                        val t = (change.position.x / size.width * d).coerceIn(0.0, d)
                        val p = if (grabStart) MarkMath.withStart(curStart, curEnd, t, d) else MarkMath.withEnd(curStart, curEnd, t, d)
                        curMark(p.first, p.second)
                    }
                )
            }
    ) {
        val w = size.width
        val h = size.height
        if (peaks == null || peaks.isEmpty()) {
            drawRect(color = dimColor, topLeft = Offset(0f, h / 2 - 1f), size = Size(w, 2f))
        } else {
            val n = peaks.size
            val barW = w / n
            for (i in 0 until n) {
                val t = (i + 0.5) / n * d
                val inside = t >= start && t <= end
                val bh = max(3f, peaks[i] * (h - 8f))
                drawRect(
                    color = if (inside) keepColor else dimColor,
                    topLeft = Offset(i * barW, (h - bh) / 2f),
                    size = Size(max(1f, barW - 1f), bh)
                )
            }
        }
        val xa = (start / d * w).toFloat()
        val xb = (end / d * w).toFloat()
        // what will be set aside
        drawRect(color = setAside.copy(alpha = 0.28f), topLeft = Offset(0f, 0f), size = Size(max(0f, xa), h))
        drawRect(color = setAside.copy(alpha = 0.28f), topLeft = Offset(xb, 0f), size = Size(max(0f, w - xb), h))
        // the two marks, each with a small flag so they can be told apart (start: top, end: bottom)
        drawRect(color = handle, topLeft = Offset(xa - 1.5f, 0f), size = Size(3f, h))
        drawRect(color = handle, topLeft = Offset(xb - 1.5f, 0f), size = Size(3f, h))
        drawRect(color = handle, topLeft = Offset(xa - 1.5f, 0f), size = Size(16f, 8f))
        drawRect(color = handle, topLeft = Offset(xb - 14.5f, h - 8f), size = Size(16f, 8f))
        if (playhead != null) {
            val px = (playhead.coerceIn(0.0, d) / d * w).toFloat()
            drawRect(color = head, topLeft = Offset(px - 1.5f, 0f), size = Size(3f, h))
        }
    }
}

// ---------------------------------------------------------------------------------------------
// 2. What kind of sound is it?
// ---------------------------------------------------------------------------------------------

/** Shows what the sound was set as and what the app does because of it; the button opens [SoundKindSheet]. */
@Composable
internal fun SoundTypeCard(clip: AudioClip, viewModel: AppViewModel) {
    SectionCard(title = "Kind of sound", modifier = Modifier.padding(bottom = 12.dp)) {
        val tag = SoundProfiles.tag(clip)
        if (tag.isEmpty()) {
            Text(
                "Not chosen yet. Say what this sound is (music, a beat, background noise, a sound effect…) and the app adjusts it " +
                    "to the voice and to the video by itself.",
                style = MaterialTheme.typography.bodySmall,
                color = Muted
            )
        } else {
            Text(tag, style = MaterialTheme.typography.titleSmall, color = TextMain)
            Text(
                SoundProfiles.describe(clip.kind, clip.mood),
                style = MaterialTheme.typography.bodySmall,
                color = Muted,
                modifier = Modifier.padding(top = 2.dp)
            )
        }
        SecondaryButton(
            if (tag.isEmpty()) "Choose the kind of sound" else "Change the kind of sound",
            modifier = Modifier.padding(top = 4.dp),
            onClick = { viewModel.audioAskKind(clip.id) }
        )
    }
}

/**
 * The sheet that asks "What kind of sound is B1?" - opened when a sound is assigned to a slot, or from [SoundTypeCard].
 * Choosing applies the kind's mixing choices at once (see [SoundProfiles]); "Skip" leaves the sound as it is.
 */
@Composable
internal fun SoundKindSheet(clip: AudioClip, onApply: (SoundKind, SoundMood) -> Unit, onSkip: () -> Unit) {
    var kind by remember(clip.id) { mutableStateOf(if (clip.kind == SoundKind.UNSET) SoundKind.MUSIC else clip.kind) }
    var mood by remember(clip.id) { mutableStateOf(clip.mood) }
    val label = if (clip.slot.isNotBlank()) clip.slot else clip.name
    WheelSheet(
        title = "What kind of sound is $label?",
        subtitle = "The app lowers it under the voice, sets its loudness and fits it to the video by itself - the right way for what it is.",
        onDismiss = onSkip
    ) {
        Text(
            "Kind of sound",
            style = MaterialTheme.typography.titleSmall,
            color = TextMain,
            modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
        )
        SoundKind.choices.chunked(2).forEach { pair ->
            Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                for (k in pair) {
                    KindChip(k.label, k == kind, Modifier.weight(1f)) {
                        kind = k
                        if (!k.musicLike) mood = SoundMood.NONE
                    }
                }
                if (pair.size == 1) Spacer(Modifier.weight(1f))
            }
        }
        Text(
            kind.hint,
            style = MaterialTheme.typography.bodySmall,
            color = Muted,
            textAlign = TextAlign.Start,
            modifier = Modifier.fillMaxWidth().padding(top = 6.dp)
        )

        if (kind.musicLike) {
            Text(
                "Feeling of the music",
                style = MaterialTheme.typography.titleSmall,
                color = TextMain,
                modifier = Modifier.fillMaxWidth().padding(top = 12.dp)
            )
            SoundMood.values().toList().chunked(2).forEach { pair ->
                Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    for (m in pair) KindChip(m.label, m == mood, Modifier.weight(1f)) { mood = m }
                    if (pair.size == 1) Spacer(Modifier.weight(1f))
                }
            }
        }

        val shownMood = if (kind.musicLike) mood else SoundMood.NONE
        Text(
            "What the app will do: " + SoundProfiles.describe(kind, shownMood),
            style = MaterialTheme.typography.bodySmall,
            color = TextMain,
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 12.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(Surface)
                .border(1.dp, BorderColor, RoundedCornerShape(8.dp))
                .padding(10.dp)
        )
        PrimaryButton("Apply", modifier = Modifier.padding(top = 8.dp), onClick = { onApply(kind, shownMood) })
        SecondaryButton("Skip - keep it as it is", onClick = onSkip)
    }
}

@Composable
private fun KindChip(label: String, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Box(
        modifier
            .heightIn(min = 48.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(if (selected) Accent else CardBg)
            .border(1.dp, if (selected) Accent else Outline, RoundedCornerShape(14.dp))
            .selectable(selected = selected, role = Role.RadioButton, onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 6.dp),
        contentAlignment = Alignment.Center
    ) {
        // the tick says "chosen" even for people who can't tell the two colours apart
        Text(
            if (selected) "✓ $label" else label,
            color = if (selected) OnAccent else TextMain,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
            style = MaterialTheme.typography.labelMedium,
            textAlign = TextAlign.Center
        )
    }
}

// ---------------------------------------------------------------------------------------------
// 3. Where should it play? (the whole video, or B1, B2...)
// ---------------------------------------------------------------------------------------------

@Composable
internal fun AssignCard(clip: AudioClip, audio: AudioMixSettings, viewModel: AppViewModel) {
    val slots = BgSlots.slots(audio)
    SectionCard(title = "Where should it play?", modifier = Modifier.padding(bottom = 12.dp)) {
        Text(
            if (clip.fitVideo) "Now: across the whole video" + (if (clip.playOnce) " (once, at the start)." else ", repeated or cut to the video's length.")
            else "Now: it starts at ${fmt(clip.startSec)}" + (if (clip.loop) " and repeats until the video ends." else "."),
            style = MaterialTheme.typography.bodyMedium,
            color = TextMain
        )
        if (!clip.fitVideo) {
            SecondaryButton("🎬 Use it across the whole video", modifier = Modifier.padding(top = 4.dp), onClick = { viewModel.audioUseForWholeVideo(clip.id) })
        }
        Text(
            "Or give it to one scene or time range:",
            style = MaterialTheme.typography.titleSmall,
            color = TextMain,
            modifier = Modifier.padding(top = 12.dp)
        )
        if (slots.isEmpty()) {
            Text(
                "There is no B1, B2… yet. Press and hold a scene on the Match step and choose “Add background audio” to make one - " +
                    "then come back and assign this sound to it.",
                style = MaterialTheme.typography.bodySmall,
                color = Muted
            )
        } else {
            Text(
                "It moves into the slot and keeps the slot's name and times. The marked part is cut or repeated to fit them.",
                style = MaterialTheme.typography.bodySmall,
                color = Muted
            )
            for (s in slots) {
                val times = if (s.hasRange) "${BgSlots.clockShort(s.startSec)} → ${BgSlots.clockShort(s.rangeEndSec)}" else "from ${BgSlots.clockShort(s.startSec)}"
                val what = if (s.isPlaceholder) "empty" else "${s.name} (will be replaced)"
                SecondaryButton("Assign to ${s.slot}  ·  $what  ·  $times", onClick = { viewModel.audioAssignToSlot(clip.id, s.id) })
            }
        }
    }
}
