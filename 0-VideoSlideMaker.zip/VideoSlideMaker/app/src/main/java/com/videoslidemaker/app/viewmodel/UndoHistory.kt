package com.videoslidemaker.app.viewmodel

/**
 * NEW: the undo / redo stacks behind the Undo and Redo buttons.
 *
 * It only stores snapshots and moves them between two stacks - it knows nothing about photos or
 * Android - so it is simple to test. A snapshot is the whole project data at one moment; the
 * project data is immutable, so a snapshot is just a few references and costs almost no memory,
 * even with thousands of photos.
 *
 * [push] is called with the snapshot from BEFORE a change. [undo] and [redo] are given the
 * snapshot of the project as it is NOW, and hand back the one to go to.
 */
class UndoHistory<S>(private val limit: Int = 60) {

    /** One step: the project as it was before the change, and a few words naming the change. */
    data class Entry<S>(val snapshot: S, val label: String)

    private val undoStack = ArrayDeque<Entry<S>>()
    private val redoStack = ArrayDeque<Entry<S>>()

    val canUndo: Boolean get() = undoStack.isNotEmpty()
    val canRedo: Boolean get() = redoStack.isNotEmpty()

    /** What Undo would take back right now (for example "photo removed"), or null. */
    val undoLabel: String? get() = undoStack.lastOrNull()?.label

    /** What Redo would put back right now, or null. */
    val redoLabel: String? get() = redoStack.lastOrNull()?.label

    /** A new change was made: remember how things were before it. A new change ends the redo trail. */
    fun push(before: S, label: String) {
        undoStack.addLast(Entry(before, label))
        while (undoStack.size > limit) undoStack.removeFirst()
        redoStack.clear()
    }

    /** Goes one step back. [current] is the project now (so Redo can return to it). Null if nothing to undo. */
    fun undo(current: S): Entry<S>? {
        val entry = undoStack.removeLastOrNull() ?: return null
        redoStack.addLast(Entry(current, entry.label))
        return entry
    }

    /** Goes one step forward again. [current] is the project now (so Undo can return to it). Null if nothing to redo. */
    fun redo(current: S): Entry<S>? {
        val entry = redoStack.removeLastOrNull() ?: return null
        undoStack.addLast(Entry(current, entry.label))
        while (undoStack.size > limit) undoStack.removeFirst()
        return entry
    }

    fun clear() {
        undoStack.clear()
        redoStack.clear()
    }
}

/** What the Undo / Redo buttons in the top bar need to know. */
data class UndoUi(
    val canUndo: Boolean = false,
    val canRedo: Boolean = false,
    /** For example "photo match" - shown as "Undo: photo match". */
    val undoLabel: String? = null,
    val redoLabel: String? = null
)
