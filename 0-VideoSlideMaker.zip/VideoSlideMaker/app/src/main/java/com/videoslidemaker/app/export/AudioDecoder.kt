package com.videoslidemaker.app.export

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import com.videoslidemaker.app.voicefx.VoiceFxPcmStream
import com.videoslidemaker.app.voicefx.VoiceFxSettings
import java.io.ByteArrayOutputStream
import java.io.RandomAccessFile
import kotlinx.coroutines.CancellationException

/** Decodes a music file (any format the device's codecs support) to raw 16-bit PCM. */
object AudioDecoder {

    /** m:ss for the position [bytes] into a 16-bit PCM stream. */
    private fun clockOf(bytes: Long, rate: Int, channels: Int): String {
        val sec = (bytes / (2.0 * channels * rate)).toInt().coerceAtLeast(0)
        return "${sec / 60}:${(sec % 60).toString().padStart(2, '0')}"
    }

    /**
     * NEW: decodes the audio of [uri] - an audio file OR a video file's sound - and writes it straight
     * into [raf] (the export's audio timeline) in small pieces, so even a multi-hour recording never
     * sits in memory. The sound is placed where it sits on the recording's own clock (its first
     * sample's time), which is the same clock the script's timestamps use. Nothing past
     * [limitBytes] (the end of the video) is decoded. Returns true if any sound was written.
     *
     * NEW: when [fx] is active the voice changer (pitch, "make it sound human", effects) is applied to
     * the sound on its way into the file, still piece by piece, so long recordings stay fine.
     */
    fun decodeIntoFile(
        context: Context,
        uri: Uri,
        raf: RandomAccessFile,
        limitBytes: Long,
        targetSampleRate: Int,
        targetChannels: Int,
        fx: VoiceFxSettings = VoiceFxSettings()
    ): Boolean {
        val extractor = MediaExtractor()
        var decoder: MediaCodec? = null
        var wrote = false
        var writePos = 0L // hoisted so a failure can say how far the sound had got
        try {
            context.contentResolver.openFileDescriptor(uri, "r")?.use { pfd ->
                extractor.setDataSource(pfd.fileDescriptor)
            } ?: return false

            var trackIndex = -1
            var format: MediaFormat? = null
            for (i in 0 until extractor.trackCount) {
                val f = extractor.getTrackFormat(i)
                val mime = f.getString(MediaFormat.KEY_MIME) ?: continue
                if (mime.startsWith("audio/")) {
                    trackIndex = i
                    format = f
                    break
                }
            }
            if (trackIndex < 0 || format == null) return false
            extractor.selectTrack(trackIndex)

            val mime = format.getString(MediaFormat.KEY_MIME)!!
            var rate = format.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            var channels = format.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            var converter = StreamingPcmConverter(rate, channels, targetSampleRate, targetChannels)
            val fxStream: VoiceFxPcmStream? =
                if (fx.isActive && targetChannels in 1..2) VoiceFxPcmStream(fx, targetSampleRate, targetChannels, 0) else null

            val frameBytes = targetChannels * 2
            val firstSampleUs = extractor.sampleTime.coerceAtLeast(0L)
            writePos = (firstSampleUs / 1_000_000.0 * targetSampleRate).toLong() * frameBytes
            if (writePos >= limitBytes) return false

            val codec = MediaCodec.createDecoderByType(mime)
            decoder = codec
            codec.configure(format, null, null, 0)
            codec.start()

            val bufferInfo = MediaCodec.BufferInfo()
            var inputDone = false
            var outputDone = false

            while (!outputDone && writePos < limitBytes) {
                if (!inputDone) {
                    val inputIndex = codec.dequeueInputBuffer(10_000)
                    if (inputIndex >= 0) {
                        val buffer = codec.getInputBuffer(inputIndex)!!
                        val sampleSize = extractor.readSampleData(buffer, 0)
                        if (sampleSize < 0) {
                            codec.queueInputBuffer(inputIndex, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            codec.queueInputBuffer(inputIndex, 0, sampleSize, extractor.sampleTime, 0)
                            extractor.advance()
                        }
                    }
                }

                val outputIndex = codec.dequeueOutputBuffer(bufferInfo, 10_000)
                if (outputIndex >= 0) {
                    if (bufferInfo.size > 0) {
                        val outBuffer = codec.getOutputBuffer(outputIndex)!!
                        outBuffer.position(bufferInfo.offset)
                        outBuffer.limit(bufferInfo.offset + bufferInfo.size)
                        val chunk = ByteArray(bufferInfo.size)
                        outBuffer.get(chunk)
                        val convertedRaw = converter.convert(chunk)
                        val converted = if (fxStream != null) fxStream.process(convertedRaw) else convertedRaw
                        if (converted.isNotEmpty()) {
                            val room = (limitBytes - writePos).coerceAtLeast(0L)
                            val n = minOf(converted.size.toLong(), room).toInt()
                            if (n > 0) {
                                raf.seek(writePos)
                                raf.write(converted, 0, n)
                                writePos += n
                                wrote = true
                            }
                        }
                    }
                    codec.releaseOutputBuffer(outputIndex, false)
                    if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                        outputDone = true
                    }
                } else if (outputIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    // The decoder reports what it REALLY outputs (some AAC files decode at twice the
                    // rate their header says), so trust this over the file's header.
                    val outFormat = codec.outputFormat
                    val newRate = if (outFormat.containsKey(MediaFormat.KEY_SAMPLE_RATE)) outFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE) else rate
                    val newChannels = if (outFormat.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) outFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT) else channels
                    if (newRate != rate || newChannels != channels) {
                        rate = newRate
                        channels = newChannels
                        converter = StreamingPcmConverter(rate, channels, targetSampleRate, targetChannels)
                    }
                }
            }
            // the last part still inside the voice changer's filters, plus an echo / reverb tail
            if (fxStream != null && writePos < limitBytes) {
                val tail = fxStream.finish((fx.tailSeconds * targetSampleRate).toInt())
                val n = minOf(tail.size.toLong(), limitBytes - writePos).toInt()
                if (n > 0) {
                    raf.seek(writePos)
                    raf.write(tail, 0, n)
                    wrote = true
                }
            }
            return wrote
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            // FIXED: this used to return quietly with "whatever was already written", so a recording the phone's decoder
            // could not read past, say, the first few seconds produced an export with those few seconds of sound and
            // then silence, and nothing said why. Now the export stops and says where the sound ended.
            if (!wrote) return false
            throw IllegalStateException(
                "The sound of your recording stopped being readable about ${clockOf(writePos, targetSampleRate, targetChannels)} in " +
                    "(${e.message ?: e.javaClass.simpleName}), so the rest of the video would have had no sound. " +
                    "Try converting the recording to MP3 or M4A and adding it again.", e
            )
        } finally {
            runCatching { decoder?.stop() }
            runCatching { decoder?.release() }
            extractor.release()
        }
    }

    fun decodeToPcm(context: Context, uri: Uri, targetSampleRate: Int, targetChannels: Int): ByteArray? {
        val extractor = MediaExtractor()
        try {
            context.contentResolver.openFileDescriptor(uri, "r")?.use { pfd ->
                extractor.setDataSource(pfd.fileDescriptor)
            } ?: return null

            var trackIndex = -1
            var format: MediaFormat? = null
            for (i in 0 until extractor.trackCount) {
                val f = extractor.getTrackFormat(i)
                val mime = f.getString(MediaFormat.KEY_MIME) ?: continue
                if (mime.startsWith("audio/")) {
                    trackIndex = i
                    format = f
                    break
                }
            }
            if (trackIndex < 0 || format == null) return null
            extractor.selectTrack(trackIndex)

            val mime = format.getString(MediaFormat.KEY_MIME)!!
            val sourceSampleRate = format.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            val sourceChannels = format.getInteger(MediaFormat.KEY_CHANNEL_COUNT)

            val decoder = MediaCodec.createDecoderByType(mime)
            decoder.configure(format, null, null, 0)
            decoder.start()

            val output = ByteArrayOutputStream()
            val bufferInfo = MediaCodec.BufferInfo()
            var inputDone = false
            var outputDone = false

            while (!outputDone) {
                if (!inputDone) {
                    val inputIndex = decoder.dequeueInputBuffer(10_000)
                    if (inputIndex >= 0) {
                        val buffer = decoder.getInputBuffer(inputIndex)!!
                        val sampleSize = extractor.readSampleData(buffer, 0)
                        if (sampleSize < 0) {
                            decoder.queueInputBuffer(inputIndex, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            decoder.queueInputBuffer(inputIndex, 0, sampleSize, extractor.sampleTime, 0)
                            extractor.advance()
                        }
                    }
                }

                val outputIndex = decoder.dequeueOutputBuffer(bufferInfo, 10_000)
                if (outputIndex >= 0) {
                    if (bufferInfo.size > 0) {
                        val outBuffer = decoder.getOutputBuffer(outputIndex)!!
                        outBuffer.position(bufferInfo.offset)
                        outBuffer.limit(bufferInfo.offset + bufferInfo.size)
                        val chunk = ByteArray(bufferInfo.size)
                        outBuffer.get(chunk)
                        output.write(chunk)
                    }
                    decoder.releaseOutputBuffer(outputIndex, false)
                    if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                        outputDone = true
                    }
                }
            }

            decoder.stop()
            decoder.release()

            return PcmResampler.convert(output.toByteArray(), sourceSampleRate, sourceChannels, targetSampleRate, targetChannels)
        } catch (e: Exception) {
            return null
        } finally {
            extractor.release()
        }
    }

    /**
     * NEW (2.17): decodes the stretch [startSec]..[endSec] of the sound of [uri] (an audio file, or a video's sound) and
     * hands it over in small pieces of 16-bit PCM in the target format, exactly trimmed to that stretch. Nothing is kept
     * in memory, so it works on a recording of any length. [onChunk] returns false to stop early. Returns false when the
     * file has no readable sound. A Cancel (CancellationException thrown from [onChunk]) passes straight through.
     */
    fun streamSegment(
        context: Context,
        uri: Uri,
        startSec: Double,
        endSec: Double,
        targetSampleRate: Int,
        targetChannels: Int,
        // NEW: told when decoding fails (the exception, and how many bytes of sound had already been handed over), so the
        // caller can stop with a clear message instead of carrying on with a cut-short sound. Null = same as before.
        onFailure: ((Exception, Long) -> Unit)? = null,
        onChunk: (ByteArray) -> Boolean
    ): Boolean {
        val extractor = MediaExtractor()
        var decoder: MediaCodec? = null
        var deliveredBytes = 0L
        try {
            context.contentResolver.openFileDescriptor(uri, "r")?.use { pfd ->
                extractor.setDataSource(pfd.fileDescriptor)
            } ?: return false

            var trackIndex = -1
            var format: MediaFormat? = null
            for (i in 0 until extractor.trackCount) {
                val f = extractor.getTrackFormat(i)
                val mime = f.getString(MediaFormat.KEY_MIME) ?: continue
                if (mime.startsWith("audio/")) {
                    trackIndex = i
                    format = f
                    break
                }
            }
            if (trackIndex < 0 || format == null) return false
            extractor.selectTrack(trackIndex)

            val mime = format.getString(MediaFormat.KEY_MIME)!!
            var rate = format.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            var channels = format.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            var converter = StreamingPcmConverter(rate, channels, targetSampleRate, targetChannels)

            val frameBytes = targetChannels * 2
            val startUs = (startSec.coerceAtLeast(0.0) * 1_000_000.0).toLong()
            if (startUs > 0L) extractor.seekTo(startUs, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)
            var remainingBytes = ((endSec - startSec).coerceAtLeast(0.0) * targetSampleRate).toLong() * frameBytes
            if (remainingBytes <= 0L) return true
            // The first sound that comes out may start a little BEFORE the wanted time (decoding starts at a key
            // point); that lead-in is dropped so the clip starts exactly where it was cut.
            var skipBytes = -1L

            val codec = MediaCodec.createDecoderByType(mime)
            decoder = codec
            codec.configure(format, null, null, 0)
            codec.start()

            val bufferInfo = MediaCodec.BufferInfo()
            var inputDone = false
            var outputDone = false
            while (!outputDone && remainingBytes > 0L) {
                if (!inputDone) {
                    val inputIndex = codec.dequeueInputBuffer(10_000)
                    if (inputIndex >= 0) {
                        val buffer = codec.getInputBuffer(inputIndex)!!
                        val sampleSize = extractor.readSampleData(buffer, 0)
                        if (sampleSize < 0) {
                            codec.queueInputBuffer(inputIndex, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            codec.queueInputBuffer(inputIndex, 0, sampleSize, extractor.sampleTime, 0)
                            extractor.advance()
                        }
                    }
                }

                val outputIndex = codec.dequeueOutputBuffer(bufferInfo, 10_000)
                if (outputIndex >= 0) {
                    if (bufferInfo.size > 0) {
                        val outBuffer = codec.getOutputBuffer(outputIndex)!!
                        outBuffer.position(bufferInfo.offset)
                        outBuffer.limit(bufferInfo.offset + bufferInfo.size)
                        val chunk = ByteArray(bufferInfo.size)
                        outBuffer.get(chunk)
                        if (skipBytes < 0L) {
                            val leadUs = (startUs - bufferInfo.presentationTimeUs).coerceAtLeast(0L)
                            skipBytes = (leadUs / 1_000_000.0 * targetSampleRate).toLong() * frameBytes
                        }
                        var data = converter.convert(chunk)
                        if (skipBytes > 0L && data.isNotEmpty()) {
                            val drop = minOf(skipBytes, data.size.toLong()).toInt()
                            skipBytes -= drop
                            data = if (drop >= data.size) ByteArray(0) else data.copyOfRange(drop, data.size)
                        }
                        if (data.isNotEmpty()) {
                            val take = minOf(data.size.toLong(), remainingBytes).toInt()
                            if (take < data.size) data = data.copyOf(take)
                            remainingBytes -= take
                            deliveredBytes += data.size
                            if (!onChunk(data)) outputDone = true
                        }
                    }
                    codec.releaseOutputBuffer(outputIndex, false)
                    if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outputDone = true
                } else if (outputIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val outFormat = codec.outputFormat
                    val newRate = if (outFormat.containsKey(MediaFormat.KEY_SAMPLE_RATE)) outFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE) else rate
                    val newChannels = if (outFormat.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) outFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT) else channels
                    if (newRate != rate || newChannels != channels) {
                        rate = newRate
                        channels = newChannels
                        converter = StreamingPcmConverter(rate, channels, targetSampleRate, targetChannels)
                    }
                }
            }
            return true
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            onFailure?.invoke(e, deliveredBytes)
            return false
        } finally {
            runCatching { decoder?.stop() }
            runCatching { decoder?.release() }
            extractor.release()
        }
    }
}
