package com.videoslidemaker.app.export

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import com.videoslidemaker.app.voicefx.VoiceFxPcmStream
import com.videoslidemaker.app.voicefx.VoiceFxSettings
import java.io.ByteArrayOutputStream
import java.io.RandomAccessFile

/** Decodes a music file (any format the device's codecs support) to raw 16-bit PCM. */
object AudioDecoder {

    /**
     * NEW: decodes the audio of [uri] - an audio file OR a video file's sound - and writes it straight
     * into [raf] (the export's audio timeline) in small pieces, so even a multi-hour recording never
     * sits in memory. The sound is placed where it sits on the recording's own clock (its first
     * sample's time), which is the same clock the script's timestamps use. Nothing past
     * [limitBytes] (the end of the video) is decoded. Returns true if any sound was written.
     *
     * NEW: when [fx] is active the voice changer (pitch, "make it sound human", effects) is applied to
     * the sound on its way into the file, still piece by piece, so long recordings stay fine.
     */
    fun decodeIntoFile(
        context: Context,
        uri: Uri,
        raf: RandomAccessFile,
        limitBytes: Long,
        targetSampleRate: Int,
        targetChannels: Int,
        fx: VoiceFxSettings = VoiceFxSettings()
    ): Boolean {
        val extractor = MediaExtractor()
        var decoder: MediaCodec? = null
        var wrote = false
        try {
            context.contentResolver.openFileDescriptor(uri, "r")?.use { pfd ->
                extractor.setDataSource(pfd.fileDescriptor)
            } ?: return false

            var trackIndex = -1
            var format: MediaFormat? = null
            for (i in 0 until extractor.trackCount) {
                val f = extractor.getTrackFormat(i)
                val mime = f.getString(MediaFormat.KEY_MIME) ?: continue
                if (mime.startsWith("audio/")) {
                    trackIndex = i
                    format = f
                    break
                }
            }
            if (trackIndex < 0 || format == null) return false
            extractor.selectTrack(trackIndex)

            val mime = format.getString(MediaFormat.KEY_MIME)!!
            var rate = format.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            var channels = format.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            var converter = StreamingPcmConverter(rate, channels, targetSampleRate, targetChannels)
            val fxStream: VoiceFxPcmStream? =
                if (fx.isActive && targetChannels in 1..2) VoiceFxPcmStream(fx, targetSampleRate, targetChannels, 0) else null

            val frameBytes = targetChannels * 2
            val firstSampleUs = extractor.sampleTime.coerceAtLeast(0L)
            var writePos = (firstSampleUs / 1_000_000.0 * targetSampleRate).toLong() * frameBytes
            if (writePos >= limitBytes) return false

            val codec = MediaCodec.createDecoderByType(mime)
            decoder = codec
            codec.configure(format, null, null, 0)
            codec.start()

            val bufferInfo = MediaCodec.BufferInfo()
            var inputDone = false
            var outputDone = false

            while (!outputDone && writePos < limitBytes) {
                if (!inputDone) {
                    val inputIndex = codec.dequeueInputBuffer(10_000)
                    if (inputIndex >= 0) {
                        val buffer = codec.getInputBuffer(inputIndex)!!
                        val sampleSize = extractor.readSampleData(buffer, 0)
                        if (sampleSize < 0) {
                            codec.queueInputBuffer(inputIndex, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            codec.queueInputBuffer(inputIndex, 0, sampleSize, extractor.sampleTime, 0)
                            extractor.advance()
                        }
                    }
                }

                val outputIndex = codec.dequeueOutputBuffer(bufferInfo, 10_000)
                if (outputIndex >= 0) {
                    if (bufferInfo.size > 0) {
                        val outBuffer = codec.getOutputBuffer(outputIndex)!!
                        outBuffer.position(bufferInfo.offset)
                        outBuffer.limit(bufferInfo.offset + bufferInfo.size)
                        val chunk = ByteArray(bufferInfo.size)
                        outBuffer.get(chunk)
                        val convertedRaw = converter.convert(chunk)
                        val converted = if (fxStream != null) fxStream.process(convertedRaw) else convertedRaw
                        if (converted.isNotEmpty()) {
                            val room = (limitBytes - writePos).coerceAtLeast(0L)
                            val n = minOf(converted.size.toLong(), room).toInt()
                            if (n > 0) {
                                raf.seek(writePos)
                                raf.write(converted, 0, n)
                                writePos += n
                                wrote = true
                            }
                        }
                    }
                    codec.releaseOutputBuffer(outputIndex, false)
                    if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                        outputDone = true
                    }
                } else if (outputIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    // The decoder reports what it REALLY outputs (some AAC files decode at twice the
                    // rate their header says), so trust this over the file's header.
                    val outFormat = codec.outputFormat
                    val newRate = if (outFormat.containsKey(MediaFormat.KEY_SAMPLE_RATE)) outFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE) else rate
                    val newChannels = if (outFormat.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) outFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT) else channels
                    if (newRate != rate || newChannels != channels) {
                        rate = newRate
                        channels = newChannels
                        converter = StreamingPcmConverter(rate, channels, targetSampleRate, targetChannels)
                    }
                }
            }
            // the last part still inside the voice changer's filters, plus an echo / reverb tail
            if (fxStream != null && writePos < limitBytes) {
                val tail = fxStream.finish((fx.tailSeconds * targetSampleRate).toInt())
                val n = minOf(tail.size.toLong(), limitBytes - writePos).toInt()
                if (n > 0) {
                    raf.seek(writePos)
                    raf.write(tail, 0, n)
                    wrote = true
                }
            }
            return wrote
        } catch (e: Exception) {
            return wrote // keep whatever was already written
        } finally {
            runCatching { decoder?.stop() }
            runCatching { decoder?.release() }
            extractor.release()
        }
    }

    fun decodeToPcm(context: Context, uri: Uri, targetSampleRate: Int, targetChannels: Int): ByteArray? {
        val extractor = MediaExtractor()
        try {
            context.contentResolver.openFileDescriptor(uri, "r")?.use { pfd ->
                extractor.setDataSource(pfd.fileDescriptor)
            } ?: return null

            var trackIndex = -1
            var format: MediaFormat? = null
            for (i in 0 until extractor.trackCount) {
                val f = extractor.getTrackFormat(i)
                val mime = f.getString(MediaFormat.KEY_MIME) ?: continue
                if (mime.startsWith("audio/")) {
                    trackIndex = i
                    format = f
                    break
                }
            }
            if (trackIndex < 0 || format == null) return null
            extractor.selectTrack(trackIndex)

            val mime = format.getString(MediaFormat.KEY_MIME)!!
            val sourceSampleRate = format.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            val sourceChannels = format.getInteger(MediaFormat.KEY_CHANNEL_COUNT)

            val decoder = MediaCodec.createDecoderByType(mime)
            decoder.configure(format, null, null, 0)
            decoder.start()

            val output = ByteArrayOutputStream()
            val bufferInfo = MediaCodec.BufferInfo()
            var inputDone = false
            var outputDone = false

            while (!outputDone) {
                if (!inputDone) {
                    val inputIndex = decoder.dequeueInputBuffer(10_000)
                    if (inputIndex >= 0) {
                        val buffer = decoder.getInputBuffer(inputIndex)!!
                        val sampleSize = extractor.readSampleData(buffer, 0)
                        if (sampleSize < 0) {
                            decoder.queueInputBuffer(inputIndex, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            decoder.queueInputBuffer(inputIndex, 0, sampleSize, extractor.sampleTime, 0)
                            extractor.advance()
                        }
                    }
                }

                val outputIndex = decoder.dequeueOutputBuffer(bufferInfo, 10_000)
                if (outputIndex >= 0) {
                    if (bufferInfo.size > 0) {
                        val outBuffer = decoder.getOutputBuffer(outputIndex)!!
                        outBuffer.position(bufferInfo.offset)
                        outBuffer.limit(bufferInfo.offset + bufferInfo.size)
                        val chunk = ByteArray(bufferInfo.size)
                        outBuffer.get(chunk)
                        output.write(chunk)
                    }
                    decoder.releaseOutputBuffer(outputIndex, false)
                    if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                        outputDone = true
                    }
                }
            }

            decoder.stop()
            decoder.release()

            return PcmResampler.convert(output.toByteArray(), sourceSampleRate, sourceChannels, targetSampleRate, targetChannels)
        } catch (e: Exception) {
            return null
        } finally {
            extractor.release()
        }
    }
}
