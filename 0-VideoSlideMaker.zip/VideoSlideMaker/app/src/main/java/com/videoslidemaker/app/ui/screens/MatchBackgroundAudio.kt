package com.videoslidemaker.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.videoslidemaker.app.audio.AudioClip
import com.videoslidemaker.app.audio.AudioMixSettings
import com.videoslidemaker.app.audio.BadgeKind
import com.videoslidemaker.app.audio.BgSlots
import com.videoslidemaker.app.audio.SceneBadge
import com.videoslidemaker.app.audio.SceneSpan
import com.videoslidemaker.app.audio.SoundProfiles
import com.videoslidemaker.app.data.ScriptParser
import com.videoslidemaker.app.ui.components.AlertBox
import com.videoslidemaker.app.ui.components.AlertStyle
import com.videoslidemaker.app.ui.components.BadgeChip
import com.videoslidemaker.app.ui.components.BgTimeSheet
import com.videoslidemaker.app.ui.components.CompactButton
import com.videoslidemaker.app.ui.components.SectionCard
import com.videoslidemaker.app.ui.components.TimeField
import com.videoslidemaker.app.ui.components.WheelChoiceSheet
import com.videoslidemaker.app.ui.theme.BorderColor
import com.videoslidemaker.app.ui.theme.Green
import com.videoslidemaker.app.ui.theme.Muted
import com.videoslidemaker.app.ui.theme.Surface
import com.videoslidemaker.app.ui.theme.TextMain
import com.videoslidemaker.app.ui.theme.Yellow
import com.videoslidemaker.app.viewmodel.AppViewModel

/*
 * NEW (2.18): background audio on the Match step.
 *
 * Press and hold a scene in the "All segments" strip and a wheel menu opens. "Add background audio" opens the time wheels
 * for where it STARTS; the new slot is named at once (B1, B2, ...) even though no audio file is chosen yet. Press and hold
 * the scene where it should STOP, choose "End background audio" and roll the wheels to the end time. The audio file can
 * be chosen at any moment (from the wheel menu or from the panel below the strip): the slot keeps its place and its
 * number, takes the file's name, and the file is cut or repeated to fit the start-to-end range (see BgSlots / ClipEdit).
 */

/** Where the user is in the background-audio wheels. [scene] is the index of the scene that was pressed. */
internal sealed interface BgStep {
    /** The wheel menu that opens on press-and-hold. */
    data class Menu(val scene: Int) : BgStep
    /** The time wheels for a NEW slot's start. */
    data class AddTime(val scene: Int) : BgStep
    /** The wheel that asks WHICH slot, before [purpose] is carried out. */
    data class PickSlot(val scene: Int, val purpose: SlotPurpose) : BgStep
    /** The time wheels for the END of an existing slot. */
    data class EndTime(val scene: Int, val slotId: String) : BgStep
    /** The time wheels for both times of an existing slot. */
    data class ChangeTimes(val scene: Int, val slotId: String) : BgStep
}

internal enum class SlotPurpose { END, FILE, TIMES, REMOVE }

private enum class MenuAction(val label: String) {
    ADD("🎵  Add background audio"),
    END("⏹  End a background audio here"),
    FILE("📂  Choose the audio file"),
    TIMES("🕒  Change start / end time"),
    REMOVE("🗑  Remove a background audio")
}

private fun mmss(sec: Double): String = ScriptParser.formatTime(sec)

private fun sceneTitle(index: Int, scene: SceneSpan) = "Scene ${index + 1}  ·  ${mmss(scene.startSec)} – ${mmss(scene.endSec)}"

/** One row of the "which one?" wheel: "B1 · rain.mp3 · 0:04 → 0:12". */
private fun slotRowLabel(c: AudioClip): String {
    val what = if (c.isPlaceholder) "no audio yet" else c.name
    val to = if (c.hasRange) BgSlots.clockShort(c.rangeEndSec) else "no end"
    return "${c.slot}  ·  $what  ·  ${BgSlots.clockShort(c.startSec)} → $to"
}

/** What the user is told after a slot's times were set. */
private fun timesDoneMessage(c: AudioClip, startSec: Double, endSec: Double?): String {
    val moved = c.copy(startSec = startSec, rangeEndSec = endSec ?: 0.0)
    val span = if (endSec == null) "from ${BgSlots.clockShort(startSec)}, no end yet" else "from ${BgSlots.clockShort(startSec)} to ${BgSlots.clockShort(endSec)}"
    val next = when {
        moved.isPlaceholder && endSec == null -> " Next: press and hold the scene where it should stop, and choose the audio file."
        moved.isPlaceholder -> " Next: choose its audio file."
        else -> " " + BgSlots.describeFit(moved)
    }
    return "${c.slot} now plays $span.$next"
}

/**
 * All the sheets of the flow. Shows nothing when [step] is null. Every sheet closes the flow ([onStep] null) when it is
 * done or cancelled; [onMessage] shows a line about what just happened in the panel below the strip.
 */
@Composable
internal fun BackgroundAudioFlow(
    step: BgStep?,
    onStep: (BgStep?) -> Unit,
    sceneOf: (Int) -> SceneSpan,
    audio: AudioMixSettings,
    totalSec: Double,
    viewModel: AppViewModel,
    onPickSlotAudio: (String) -> Unit,
    onMessage: (String?) -> Unit
) {
    val slots = BgSlots.slots(audio)
    val videoLen = "the video is ${BgSlots.clockShort(totalSec)} long"
    when (step) {
        null -> Unit

        is BgStep.Menu -> {
            val scene = sceneOf(step.scene)
            val open = BgSlots.openSlots(audio)
            val actions = buildList {
                add(MenuAction.ADD)
                if (open.isNotEmpty()) add(MenuAction.END)
                if (slots.isNotEmpty()) {
                    add(MenuAction.FILE)
                    add(MenuAction.TIMES)
                    add(MenuAction.REMOVE)
                }
            }
            WheelChoiceSheet(
                title = sceneTitle(step.scene, scene),
                subtitle = "Background audio – music or a sound effect",
                labels = actions.map { it.label },
                confirmText = "Select",
                hint = "Roll the wheel, then tap Select (or tap the middle row).",
                onConfirm = { i ->
                    when (actions[i]) {
                        MenuAction.ADD -> onStep(BgStep.AddTime(step.scene))
                        MenuAction.END ->
                            if (open.size == 1) onStep(BgStep.EndTime(step.scene, open[0].id))
                            else onStep(BgStep.PickSlot(step.scene, SlotPurpose.END))
                        MenuAction.FILE ->
                            if (slots.size == 1) {
                                onStep(null)
                                onPickSlotAudio(slots[0].id)
                            } else onStep(BgStep.PickSlot(step.scene, SlotPurpose.FILE))
                        MenuAction.TIMES ->
                            if (slots.size == 1) onStep(BgStep.ChangeTimes(step.scene, slots[0].id))
                            else onStep(BgStep.PickSlot(step.scene, SlotPurpose.TIMES))
                        MenuAction.REMOVE -> onStep(BgStep.PickSlot(step.scene, SlotPurpose.REMOVE))
                    }
                },
                onDismiss = { onStep(null) }
            )
        }

        is BgStep.AddTime -> {
            val scene = sceneOf(step.scene)
            val label = BgSlots.nextLabel(audio)
            BgTimeSheet(
                title = "Start background audio ($label)",
                subtitle = "${sceneTitle(step.scene, scene)}  ·  $videoLen",
                totalSec = totalSec,
                scene = scene,
                initialStartSec = BgSlots.suggestStart(scene, totalSec),
                initialEndSec = null,
                initialField = TimeField.START,
                confirmText = "Add $label",
                onConfirm = { s, e ->
                    val made = viewModel.bgSlotAdd(s, e)
                    onStep(null)
                    if (made != null) {
                        onMessage(
                            if (e == null) "$made added: it starts at ${BgSlots.clockShort(s)}. It has its name already, but no audio file yet. " +
                                "Next: press and hold the scene where it should stop and choose “End a background audio here”, then choose the audio file."
                            else "$made added: ${BgSlots.clockShort(s)} to ${BgSlots.clockShort(e)}. Now choose its audio file – it is cut or repeated to fit."
                        )
                    }
                },
                onDismiss = { onStep(null) }
            )
        }

        is BgStep.PickSlot -> {
            val list = if (step.purpose == SlotPurpose.END) BgSlots.openSlots(audio) else slots
            if (list.isEmpty()) {
                LaunchedEffect(step) { onStep(null) }
            } else {
                val scene = sceneOf(step.scene)
                WheelChoiceSheet(
                    title = when (step.purpose) {
                        SlotPurpose.END -> "Which background audio ends here?"
                        SlotPurpose.FILE -> "Choose the audio file for…"
                        SlotPurpose.TIMES -> "Change the times of…"
                        SlotPurpose.REMOVE -> "Remove which background audio?"
                    },
                    subtitle = sceneTitle(step.scene, scene),
                    labels = list.map { slotRowLabel(it) },
                    initialIndex = if (step.purpose == SlotPurpose.FILE) list.indexOfFirst { it.isPlaceholder }.coerceAtLeast(0) else 0,
                    confirmText = when (step.purpose) {
                        SlotPurpose.END, SlotPurpose.TIMES -> "Next"
                        SlotPurpose.FILE -> "Choose file"
                        SlotPurpose.REMOVE -> "Remove"
                    },
                    onConfirm = { i ->
                        val c = list[i]
                        when (step.purpose) {
                            SlotPurpose.END -> onStep(BgStep.EndTime(step.scene, c.id))
                            SlotPurpose.TIMES -> onStep(BgStep.ChangeTimes(step.scene, c.id))
                            SlotPurpose.FILE -> {
                                onStep(null)
                                onPickSlotAudio(c.id)
                            }
                            SlotPurpose.REMOVE -> {
                                viewModel.bgSlotRemove(c.id)
                                onStep(null)
                                onMessage("${c.slot} removed. Undo (at the top) brings it back.")
                            }
                        }
                    },
                    onDismiss = { onStep(null) }
                )
            }
        }

        is BgStep.EndTime -> {
            val c = audio.clip(step.slotId)
            if (c == null) {
                LaunchedEffect(step) { onStep(null) }
            } else {
                val scene = sceneOf(step.scene)
                BgTimeSheet(
                    title = "End background audio (${c.slot})",
                    subtitle = "${c.slot} starts at ${BgSlots.clockShort(c.startSec)}  ·  ${sceneTitle(step.scene, scene)}  ·  $videoLen",
                    totalSec = totalSec,
                    scene = scene,
                    initialStartSec = c.startSec,
                    initialEndSec = BgSlots.suggestEnd(c.startSec, scene, totalSec),
                    initialField = TimeField.END,
                    confirmText = "Set end",
                    onConfirm = { s, e ->
                        val problem = viewModel.bgSlotSetTimes(c.id, s, e)
                        onStep(null)
                        onMessage(problem ?: timesDoneMessage(c, s, e))
                    },
                    onDismiss = { onStep(null) }
                )
            }
        }

        is BgStep.ChangeTimes -> {
            val c = audio.clip(step.slotId)
            if (c == null) {
                LaunchedEffect(step) { onStep(null) }
            } else {
                val scene = sceneOf(step.scene)
                BgTimeSheet(
                    title = "Change times (${c.slot})",
                    subtitle = "${sceneTitle(step.scene, scene)}  ·  $videoLen",
                    totalSec = totalSec,
                    scene = scene,
                    initialStartSec = c.startSec,
                    initialEndSec = if (c.hasRange) c.rangeEndSec else null,
                    initialField = TimeField.START,
                    confirmText = "Save",
                    onConfirm = { s, e ->
                        val problem = viewModel.bgSlotSetTimes(c.id, s, e)
                        onStep(null)
                        onMessage(problem ?: timesDoneMessage(c, s, e))
                    },
                    onDismiss = { onStep(null) }
                )
            }
        }
    }
}

/**
 * The list of every background audio of the project, in time order, under the scene strip: its name, its times, whether
 * it still waits for an audio file, how the file fits - and the buttons to choose the file, change the times or remove it.
 */
@Composable
internal fun BackgroundAudioPanel(
    slots: List<AudioClip>,
    note: String?,
    onDismissNote: () -> Unit,
    onChooseFile: (AudioClip) -> Unit,
    onChangeTimes: (AudioClip) -> Unit,
    onRemove: (AudioClip) -> Unit,
    modifier: Modifier = Modifier
) {
    SectionCard(title = "🎵 Background audio (music or sound effects)", modifier = modifier) {
        Text(
            "Press and hold any scene in the strip above and choose “Add background audio”. It gets a name (B1, B2…) right away, " +
                "even before you pick a sound. Later press and hold the scene where it should stop. " +
                "A longer sound is cut to fit; a shorter one repeats.",
            style = MaterialTheme.typography.bodySmall,
            color = Muted
        )
        if (note != null) {
            AlertBox(note, AlertStyle.INFO, Modifier.padding(top = 8.dp))
            TextButton(onClick = onDismissNote) { Text("OK") }
        }
        if (slots.isEmpty()) {
            Text(
                "No background audio yet.",
                style = MaterialTheme.typography.bodyMedium,
                color = Muted,
                modifier = Modifier.padding(top = 8.dp)
            )
        }
        for (c in slots) {
            val shape = RoundedCornerShape(12.dp)
            val waiting = c.isPlaceholder
            Column(
                Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp)
                    .clip(shape)
                    .background(Surface)
                    .border(1.dp, if (waiting) Yellow else BorderColor, shape)
                    .padding(12.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    BadgeChip(c.slot, if (waiting) AlertStyle.WARNING else AlertStyle.SUCCESS)
                    Text(
                        if (waiting) "No audio file yet" else c.name,
                        style = MaterialTheme.typography.titleSmall,
                        color = TextMain,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(start = 8.dp)
                    )
                }
                val times = if (c.hasRange)
                    "${BgSlots.clock(c.startSec)} → ${BgSlots.clock(c.rangeEndSec)}  ·  ${BgSlots.clockShort(c.rangeEndSec - c.startSec)} long"
                else "From ${BgSlots.clock(c.startSec)}  ·  no end yet"
                Text(times, style = MaterialTheme.typography.bodyMedium, color = TextMain, modifier = Modifier.padding(top = 6.dp))
                Text(BgSlots.describeFit(c), style = MaterialTheme.typography.bodySmall, color = Muted, modifier = Modifier.padding(top = 2.dp))
                // NEW (2.19): what kind of sound it was set as (set on the Audio step, or when the file was chosen)
                val kindTag = SoundProfiles.tag(c)
                if (kindTag.isNotEmpty()) Text("Kind: $kindTag", style = MaterialTheme.typography.bodySmall, color = Muted, modifier = Modifier.padding(top = 2.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 8.dp)) {
                    CompactButton(if (waiting) "📂 Choose audio" else "📂 Change audio", onClick = { onChooseFile(c) })
                    CompactButton("🕒 Times", onClick = { onChangeTimes(c) })
                    CompactButton("🗑 Remove", onClick = { onRemove(c) })
                }
            }
        }
    }
}

/**
 * The little tags at the bottom of a scene card: which background audio starts (▶), is playing, or stops (■) in
 * this scene. Green = has its audio file, yellow = still waiting for one. When any background audio exists, every card
 * keeps the same-height row for them so the strip stays level.
 */
@Composable
internal fun SceneBadgeRow(badges: List<SceneBadge>, reserveRow: Boolean) {
    if (!reserveRow && badges.isEmpty()) return
    val shape = RoundedCornerShape(5.dp)
    Row(
        Modifier.fillMaxWidth().height(18.dp).padding(top = 3.dp),
        horizontalArrangement = Arrangement.spacedBy(2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        for (b in badges.take(2)) {
            val tint = if (b.waiting) Yellow else Green
            val text = when (b.kind) {
                BadgeKind.START -> "▶${b.label}"
                BadgeKind.MIDDLE -> b.label
                BadgeKind.END -> "${b.label}■"
                BadgeKind.WHOLE -> "▶${b.label}■"
            }
            Text(
                text,
                // small, so two tags fit under a 76dp-wide scene card
                style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp),
                color = TextMain,
                maxLines = 1,
                softWrap = false,
                modifier = Modifier
                    .clip(shape)
                    .background(tint.copy(alpha = 0.22f))
                    .border(1.dp, tint, shape)
                    .padding(horizontal = 3.dp)
            )
        }
        if (badges.size > 2) {
            Text("+${badges.size - 2}", style = MaterialTheme.typography.labelSmall, color = Muted, maxLines = 1)
        }
    }
}
