package com.videoslidemaker.app.model

/**
 * NEW (2.21): the rule behind the Match screen's "Move a series of photos" buttons.
 *
 * "Move photos along" ([PhotoShift]) only carries the photos that stand TOGETHER and stops at the first empty sentence.
 * This is the other tool: you choose a series of sentences - a start and an end - and EVERYTHING in it slides by one
 * sentence, empty sentences included. So the pattern of photos and gaps inside the series stays exactly as it was; it just
 * sits one sentence later (or earlier). The sentences themselves (their text and times) never move - only which photo
 * is on which sentence.
 *
 *     sentences 1..6 before :  A  -  B  C  D  -        (- = no photo)
 *     series = 1..5, FORWARD:  -  A  -  B  C  D        (D went onto sentence 6, just outside the series)
 *
 *  - FORWARD = every sentence of the series gives its photo (or its gap) to the NEXT sentence, and the first sentence of
 *              the series is left empty. The photo on the series' last sentence goes onto the sentence right after the
 *              series. A gap never covers a photo: if the series ends on an empty sentence, the sentence after it is left alone.
 *  - BACK    = the same the other way round: the last sentence of the series is left empty, and the photo on the series'
 *              first sentence goes onto the sentence right before it.
 *
 * Nothing is lost unless the photo that moves out of the series lands on a sentence that already has a different photo
 * (that one is covered) or there is no sentence left at all (the very first / very last one). Such a photo only leaves
 * the timeline - it stays in the photo list - and the result says so; Undo brings it back.
 *
 * After a move the SAME photos are still selected ([Result.newStart] .. [Result.newEnd]), so pressing the button again
 * carries the same series one more sentence, without having to select it again.
 *
 * Plain Kotlin on photo ids (no Android classes), so it can be tested on its own. The caller
 * ([com.videoslidemaker.app.viewmodel.AppViewModel.shiftPhotoRange]) turns the answer into one undoable change.
 */
object PhotoRangeShift {

    /** What a move does (or did), with the facts the screen reports. */
    data class Result(
        /** The photo id for every sentence after the move, in the same order as the sentences (null = no photo). */
        val assignments: List<String?>,
        /** True = moved toward later sentences; false = moved toward earlier ones. */
        val forward: Boolean,
        /** The series that was moved (0-based, both included). */
        val start: Int,
        val end: Int,
        /** Where the same photos stand after the move (0-based, both included); both -1 when none of them is left on the timeline. */
        val newStart: Int,
        val newEnd: Int,
        /** How many photos went to another sentence. */
        val movedPhotos: Int,
        /** How many sentences have a different photo than before. */
        val changed: Int,
        /** The sentence (0-based) of the series that was left empty by the move. */
        val emptySentence: Int,
        /** The sentence OUTSIDE the series that received the series' end photo (forward: the one after, back: the one before); null when none did. */
        val spilledTo: Int?,
        /** The photo that ended up on no sentence at all (it is still in the pool); null when none was lost. */
        val lostPhotoId: String?,
        /** The sentence (0-based) that photo was on before. Only meaningful when [lostPhotoId] is not null. */
        val lostSentence: Int,
        /** True = that photo had no sentence left to go to; false = it was covered by the photo moving onto its sentence. */
        val lostFellOffTimeline: Boolean
    ) {
        /** "Heads up" line (or null) - used before the button is pressed, and again in the result. */
        fun warning(): String? {
            if (lostPhotoId == null) return null
            return if (lostFellOffTimeline) {
                "The photo on sentence ${lostSentence + 1} has no sentence left to go to, so it comes off the timeline (it stays in your photo list)."
            } else {
                "The photo on sentence ${lostSentence + 1} gets covered, so it comes off the timeline (it stays in your photo list)."
            }
        }

        /** One to three short, plain sentences for the screen. */
        fun message(): String {
            if (changed == 0) return "Nothing changed - there was no photo to move."
            // the series held a single photo and it had no sentence left to go to
            if (movedPhotos == 0) return "No photo could move ${if (forward) "forward" else "back"}. ${warning() ?: ""}".trim()
            val photos = if (movedPhotos == 1) "1 photo" else "$movedPhotos photos"
            val text = StringBuilder()
            text.append(
                if (forward) "$photos moved one sentence forward (series ${start + 1} - ${end + 1}). Sentence ${emptySentence + 1} is now empty."
                else "$photos moved one sentence back (series ${start + 1} - ${end + 1}). Sentence ${emptySentence + 1} is now empty."
            )
            if (spilledTo != null) {
                text.append(" The ${if (forward) "last" else "first"} photo went onto sentence ${spilledTo + 1}, just outside the series.")
            }
            warning()?.let { text.append(' ').append(it) }
            return text.toString()
        }
    }

    /** True when there is a series to move: a valid start .. end that holds at least one photo. */
    fun canShift(current: List<String?>, start: Int, end: Int): Boolean {
        if (start < 0 || end >= current.size || start > end) return false
        for (i in start..end) if (current[i] != null) return true
        return false
    }

    /**
     * @param current the photo each sentence has now (null = none), in the order the sentences are kept in.
     * @param start the first sentence of the series (0-based).
     * @param end the last sentence of the series (0-based, included).
     * @param forward true = everything one sentence later; false = one sentence earlier.
     * @return what was done; null when it cannot be done (see [canShift]).
     */
    fun plan(current: List<String?>, start: Int, end: Int, forward: Boolean): Result? {
        if (!canShift(current, start, end)) return null
        val n = current.size
        val out = ArrayList<String?>(current)

        var photosInSeries = 0
        for (i in start..end) if (current[i] != null) photosInSeries++

        var spilledTo: Int? = null
        var lostId: String? = null
        var lostAt = -1
        var fellOff = false
        val newStart: Int
        val newEnd: Int
        val emptyAt: Int

        if (forward) {
            val tail = current[end]
            // every sentence gives its photo (or gap) to the next one: end-1 -> end, ..., start -> start+1
            for (i in end downTo start + 1) out[i] = current[i - 1]
            out[start] = null
            emptyAt = start
            if (tail != null) {
                if (end + 1 < n) {
                    // the series' last photo lands just after it, covering whatever is there
                    lostId = current[end + 1]
                    lostAt = end + 1
                    out[end + 1] = tail
                    spilledTo = end + 1
                } else {
                    lostId = tail
                    lostAt = end
                    fellOff = true
                }
            }
            newStart = start + 1
            newEnd = if (tail != null && end + 1 < n) end + 1 else end
        } else {
            val head = current[start]
            // every sentence gives its photo (or gap) to the previous one: start+1 -> start, ..., end -> end-1
            for (i in start until end) out[i] = current[i + 1]
            out[end] = null
            emptyAt = end
            if (head != null) {
                if (start >= 1) {
                    lostId = current[start - 1]
                    lostAt = start - 1
                    out[start - 1] = head
                    spilledTo = start - 1
                } else {
                    lostId = head
                    lostAt = start
                    fellOff = true
                }
            }
            newStart = if (head != null && start >= 1) start - 1 else start
            newEnd = end - 1
        }

        var changed = 0
        for (i in 0 until n) if (out[i] != current[i]) changed++

        // a photo only counts as lost when no other sentence still uses it
        val lost = lostId?.takeIf { id -> id !in out }
        val seriesLeft = newStart <= newEnd
        return Result(
            assignments = out,
            forward = forward,
            start = start,
            end = end,
            newStart = if (seriesLeft) newStart else -1,
            newEnd = if (seriesLeft) newEnd else -1,
            movedPhotos = photosInSeries - (if (fellOff) 1 else 0),
            changed = changed,
            emptySentence = emptyAt,
            spilledTo = spilledTo,
            lostPhotoId = lost,
            lostSentence = lostAt,
            lostFellOffTimeline = fellOff
        )
    }
}
