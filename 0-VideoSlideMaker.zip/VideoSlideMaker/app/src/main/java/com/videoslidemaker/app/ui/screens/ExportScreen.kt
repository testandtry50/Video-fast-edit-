package com.videoslidemaker.app.ui.screens

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Share

import com.videoslidemaker.app.ui.components.AppProgressBar
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import android.content.Intent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.videoslidemaker.app.data.ScriptParser
import com.videoslidemaker.app.model.AppStep
import com.videoslidemaker.app.model.QualityOption
import com.videoslidemaker.app.model.UiState
import com.videoslidemaker.app.ui.components.AlertBox
import com.videoslidemaker.app.ui.components.AlertStyle
import com.videoslidemaker.app.ui.components.PrimaryButton
import com.videoslidemaker.app.ui.components.ScreenTitle
import com.videoslidemaker.app.ui.components.SecondaryButton
import com.videoslidemaker.app.ui.components.SectionCard
import com.videoslidemaker.app.ui.theme.Accent
import com.videoslidemaker.app.ui.theme.Muted
import com.videoslidemaker.app.viewmodel.AppViewModel

@Composable
fun ExportScreen(state: UiState, viewModel: AppViewModel) {
    val context = LocalContext.current
    val progress = state.exportProgress

    Column(
        Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        ScreenTitle("Create Your Video", "Review the details below, then create your finished video.")

        SectionCard(title = "Video Details", modifier = Modifier.padding(bottom = 12.dp)) {
            DetailRow("Photos in sequence", "${state.effectiveSlides.size}")
            DetailRow("Total duration", ScriptParser.formatTime(state.totalDurationSec))
            DetailRow("Photo effect", state.settings.effectStyle.label)
            DetailRow("Transition", state.settings.transitionStyle.label)
            DetailRow(
                "Sound in video",
                when {
                    state.settings.audio.useCustomMain -> "Your edited audio"
                    !state.settings.narration.enabled -> "Off"
                    state.settings.narration.source == com.videoslidemaker.app.model.AudioSource.ORIGINAL ->
                        if (state.alignment.recordingUri != null) "Your original recording" else "Original recording (none chosen - no voice)"
                    else -> "Voice (text-to-speech)"
                }
            )
            if (!state.settings.audio.useCustomMain && state.settings.narration.enabled && state.settings.narration.voiceFx.isActive) {
                DetailRow("Voice changer", state.settings.narration.voiceFx.summary())
            }
        }

        // NEW (2.17): music and every other sound edit now live in the Audio step; this is its summary.
        SectionCard(title = "Audio", modifier = Modifier.padding(bottom = 12.dp)) {
            val summary = state.settings.audio.summary()
            Text(
                if (summary.isEmpty()) "No extra audio. Add background music or edit your main sound in the Audio step." else summary,
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.padding(bottom = 8.dp)
            )
            SecondaryButton("Open the Audio step", onClick = { viewModel.goStep(AppStep.AUDIO) })
        }

        if (state.settings.audio.useCustomMain && state.settings.audio.activeMain.isEmpty()) {
            AlertBox(
                "\"My edited audio\" is the main sound, but it has no clips, so the main sound will be silent. Add a clip in the Audio step, or switch back to the Script voice.",
                style = AlertStyle.WARNING,
                modifier = Modifier.padding(bottom = 12.dp)
            )
        }

        if (state.settings.quality == QualityOption.P2160 || state.settings.quality == QualityOption.ORIGINAL) {
            AlertBox(
                "High resolution exports take longer and use more battery and storage. The export keeps running in the background even if you switch apps.",
                style = AlertStyle.WARNING,
                modifier = Modifier.padding(bottom = 12.dp)
            )
        }

        when {
            progress.running -> {
                SectionCard(modifier = Modifier.padding(bottom = 12.dp)) {
                    Text(progress.message, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(bottom = 8.dp))
                    AppProgressBar(progress.percent / 100f)
                    Text("${progress.percent}%", style = MaterialTheme.typography.labelMedium, color = Muted, modifier = Modifier.padding(top = 6.dp))
                }
                SecondaryButton("Cancel Export", onClick = viewModel::cancelExport)
            }
            progress.done && progress.outputUri != null -> {
                AlertBox("Your video was saved to Movies/VideoSlideMaker.", style = AlertStyle.SUCCESS, modifier = Modifier.padding(bottom = 12.dp))
                PrimaryButton("Share video", icon = Icons.Filled.Share, onClick = {
                    val shareIntent = Intent(Intent.ACTION_SEND).apply {
                        type = "video/mp4"
                        putExtra(Intent.EXTRA_STREAM, progress.outputUri)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    context.startActivity(Intent.createChooser(shareIntent, "Share video"))
                })
                SecondaryButton("Export it again", onClick = viewModel::startExport)
            }
            progress.done && progress.error != null -> {
                AlertBox("${progress.error}", style = AlertStyle.WARNING, modifier = Modifier.padding(bottom = 12.dp))
                PrimaryButton("Try Again", onClick = viewModel::startExport)
            }
            else -> {
                PrimaryButton("Create & save video", icon = Icons.Filled.Movie, onClick = viewModel::startExport)
            }
        }

        SecondaryButton("← Back to Preview", modifier = Modifier.padding(top = 12.dp), onClick = { viewModel.goStep(AppStep.PREVIEW) })
    }
}

@Composable
private fun DetailRow(label: String, value: String) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, style = MaterialTheme.typography.bodyMedium, color = Muted)
        Text(value, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurface)
    }
}
