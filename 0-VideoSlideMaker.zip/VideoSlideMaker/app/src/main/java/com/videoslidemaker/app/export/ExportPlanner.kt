package com.videoslidemaker.app.export

import kotlin.math.ceil
import kotlin.math.max

/** How the finished video is written. */
enum class ContainerMode {
    /** Android's own MP4 muxer, into the cache, then copied to the gallery. Proven, but limited to about 4 GB. */
    PLATFORM_MP4,

    /** Our streaming (fragmented) MP4 writer, straight to the destination: any size, and playable if interrupted. */
    STREAMING_FRAGMENTED
}

/** What is known about the storage the export will use. A null free-space figure means "could not be determined". */
data class StorageInfo(
    val cacheFreeBytes: Long?,
    val destinationFreeBytes: Long?,
    /** Cache and destination share one volume, so their needs add up. */
    val sameVolume: Boolean,
    /** The biggest single file the destination's file system can hold, when that is known and limited (FAT32). */
    val destinationMaxFileBytes: Long? = null
)

data class PlanInput(
    val durationSec: Double,
    val videoBitrateBps: Long,
    val hasAudio: Boolean,
    val audioBitrateBps: Long,
    /** The temporary raw audio the narration is built into before it is encoded. */
    val pcmBytes: Long,
    val storage: StorageInfo,
    /** For tests and an explicit user choice; normally the planner decides from the size. */
    val forceMode: ContainerMode? = null
)

enum class SpaceVerdict {
    /** Enough room, as far as it can be measured. */
    OK,

    /** Known to be too little. The export must not start. */
    TOO_SMALL,

    /** The free space could not be read, so nothing is claimed either way. */
    UNKNOWN,

    /** The destination's file system cannot hold a file this large. */
    FILE_TOO_LARGE
}

data class ExportPlan(
    val mode: ContainerMode,
    val estimatedBytes: Long,
    val destinationNeedBytes: Long,
    val cacheNeedBytes: Long,
    /** When cache and destination share a volume: what that one volume needs at the busiest moment. */
    val combinedNeedBytes: Long?,
    val verdict: SpaceVerdict,
    /** How much more space is needed, when it is known to be short. */
    val shortfallBytes: Long?,
    /** A sentence for the heading of the storage check. */
    val headline: String,
    /** Plain lines for the export screen, in order. */
    val lines: List<String>
) {
    /** False only when the export is KNOWN not to fit; "unknown" may still be tried (it stops safely if it runs out). */
    val canStart: Boolean get() = verdict == SpaceVerdict.OK || verdict == SpaceVerdict.UNKNOWN
}

/**
 * Works out how big the export will be and whether the storage can take it, from what the export really does:
 *
 *  - Android's MP4 muxer ([ContainerMode.PLATFORM_MP4]) writes the whole file into the cache and then COPIES it to the
 *    destination, so at the end both copies exist. It also cannot go much beyond 4 GB.
 *  - The streaming writer ([ContainerMode.STREAMING_FRAGMENTED]) writes straight to the destination, so one copy exists, plus
 *    the encoded audio waiting on disk to be interleaved.
 *
 * Nothing here imposes a size limit. The only limits are the ones the storage itself has, and when they cannot be read the
 * answer is [SpaceVerdict.UNKNOWN], never a made-up "OK".
 */
object ExportPlanner {
    /** Android's platform MP4 muxer stops near 4 GiB (32-bit file offsets); stay clear of it. */
    const val PLATFORM_MUXER_SAFE_BYTES = 3_500_000_000L

    /** Left free on top of the file itself, for the system and the app's other work. */
    const val RESERVE_BYTES = 250_000_000L

    /** Index, fragment headers and the like. */
    private const val CONTAINER_OVERHEAD = 1.01

    /** What FAT32 can hold in one file (4 GiB - 1 byte). */
    const val FAT32_MAX_FILE_BYTES = 4_294_967_295L

    fun estimateBytes(durationSec: Double, videoBps: Long, audioBps: Long, hasAudio: Boolean): Long {
        val seconds = max(0.0, durationSec)
        val video = videoBps.toDouble() * seconds / 8.0
        val audio = if (hasAudio) audioBps.toDouble() * seconds / 8.0 else 0.0
        return ceil((video + audio) * CONTAINER_OVERHEAD).toLong() + 65_536L
    }

    fun plan(input: PlanInput): ExportPlan {
        val estimated = estimateBytes(input.durationSec, input.videoBitrateBps, input.audioBitrateBps, input.hasAudio)
        val audioBytes = if (input.hasAudio) ceil(input.audioBitrateBps.toDouble() * max(0.0, input.durationSec) / 8.0).toLong() else 0L
        val mode = input.forceMode ?: if (estimated > PLATFORM_MUXER_SAFE_BYTES) ContainerMode.STREAMING_FRAGMENTED else ContainerMode.PLATFORM_MP4
        val st = input.storage

        // what each place must hold at its busiest moment
        val stage1 = input.pcmBytes + audioBytes                  // building and encoding the audio
        val destNeed: Long
        val cacheNeed: Long
        val combined: Long
        if (mode == ContainerMode.PLATFORM_MP4) {
            cacheNeed = max(stage1, estimated) + RESERVE_BYTES    // the whole file is built here ...
            destNeed = estimated + RESERVE_BYTES                  // ... and copied to the destination
            combined = max(stage1, 2L * estimated) + RESERVE_BYTES // both copies exist at the end
        } else {
            cacheNeed = stage1 + RESERVE_BYTES                    // audio waiting to be interleaved (the raw audio is gone by then)
            destNeed = estimated + RESERVE_BYTES
            combined = max(stage1, estimated + audioBytes) + RESERVE_BYTES
        }

        val lines = ArrayList<String>()
        lines.add("Estimated export size: ${ByteSize.format(estimated)}")
        if (mode == ContainerMode.STREAMING_FRAGMENTED) {
            lines.add("Large export: it is saved as a streaming MP4, so it can be larger than 4 GB, and the part already exported stays playable if the export is interrupted.")
        }

        var verdict = SpaceVerdict.OK
        var shortfall: Long? = null
        val fsMax = st.destinationMaxFileBytes
        if (fsMax != null && estimated > fsMax) {
            verdict = SpaceVerdict.FILE_TOO_LARGE
            lines.add("This storage can't hold a single file larger than ${ByteSize.format(fsMax)} (its file system limit), so an export this size can't be saved there.")
        } else if (st.sameVolume) {
            val free = st.destinationFreeBytes ?: st.cacheFreeBytes
            if (free == null) {
                verdict = SpaceVerdict.UNKNOWN
            } else if (free < combined) {
                verdict = SpaceVerdict.TOO_SMALL
                shortfall = combined - free
                lines.add("Free space: ${ByteSize.format(free)}. About ${ByteSize.format(combined)} is needed while exporting.")
            } else {
                lines.add("Free space: ${ByteSize.format(free)} (about ${ByteSize.format(combined)} is needed while exporting).")
            }
        } else {
            val destFree = st.destinationFreeBytes
            val cacheFree = st.cacheFreeBytes
            var unknown = false
            var worst = 0L
            if (destFree == null) unknown = true
            else if (destFree < destNeed) {
                verdict = SpaceVerdict.TOO_SMALL
                worst = max(worst, destNeed - destFree)
                lines.add("Where the video is saved: ${ByteSize.format(destFree)} free, about ${ByteSize.format(destNeed)} needed.")
            } else lines.add("Where the video is saved: ${ByteSize.format(destFree)} free (about ${ByteSize.format(destNeed)} needed).")
            if (cacheFree == null) unknown = true
            else if (cacheFree < cacheNeed) {
                verdict = SpaceVerdict.TOO_SMALL
                worst = max(worst, cacheNeed - cacheFree)
                lines.add("Temporary space: ${ByteSize.format(cacheFree)} free, about ${ByteSize.format(cacheNeed)} needed.")
            } else lines.add("Temporary space: ${ByteSize.format(cacheFree)} free (about ${ByteSize.format(cacheNeed)} needed).")
            if (verdict == SpaceVerdict.TOO_SMALL) shortfall = worst
            else if (unknown) verdict = SpaceVerdict.UNKNOWN
        }

        val headline = when (verdict) {
            SpaceVerdict.OK -> "There is enough free space for this export."
            SpaceVerdict.TOO_SMALL -> "There isn't enough free space for this export: ${ByteSize.format(shortfall ?: 0L)} more is needed."
            SpaceVerdict.UNKNOWN -> "The free space on this storage couldn't be checked, so it can't be promised that the export fits."
            SpaceVerdict.FILE_TOO_LARGE -> "This storage can't hold a file this large."
        }
        if (verdict == SpaceVerdict.UNKNOWN) {
            lines.add("The export stops safely, keeping what it has finished, if the storage runs out.")
        }
        return ExportPlan(mode, estimated, destNeed, cacheNeed, combined, verdict, shortfall, headline, lines)
    }
}
