package com.videoslidemaker.app.export

import kotlin.math.roundToInt

/** Lightweight PCM helpers: band-limited resampling (see SincResampler.kt) and additive mixing. */
object PcmResampler {

    /** Converts 16-bit little-endian PCM from [srcRate]/[srcChannels] to [dstRate]/[dstChannels]. */
    fun convert(src: ByteArray, srcRate: Int, srcChannels: Int, dstRate: Int, dstChannels: Int): ByteArray {
        if (src.isEmpty() || srcChannels <= 0) return ByteArray(0)
        val srcSamples = toChannelSamples(src, srcChannels)
        val resampled = if (srcRate == dstRate) srcSamples else resample(srcSamples, srcRate, dstRate)
        val remapped = remapChannels(resampled, srcChannels, dstChannels)
        return fromChannelSamples(remapped)
    }

    private fun toChannelSamples(pcm: ByteArray, channels: Int): Array<FloatArray> {
        val frameCount = pcm.size / (2 * channels)
        val out = Array(channels) { FloatArray(frameCount) }
        var idx = 0
        for (f in 0 until frameCount) {
            for (c in 0 until channels) {
                val lo = pcm[idx].toInt() and 0xFF
                val hi = pcm[idx + 1].toInt()
                out[c][f] = ((hi shl 8) or lo).toShort() / 32768f
                idx += 2
            }
        }
        return out
    }

    private fun fromChannelSamples(channelSamples: Array<FloatArray>): ByteArray {
        val channels = channelSamples.size
        val frameCount = if (channels > 0) channelSamples[0].size else 0
        val out = ByteArray(frameCount * channels * 2)
        var idx = 0
        for (f in 0 until frameCount) {
            for (c in 0 until channels) {
                val s = (channelSamples[c][f].coerceIn(-1f, 1f) * 32767f).roundToInt().toShort()
                out[idx] = (s.toInt() and 0xFF).toByte()
                out[idx + 1] = ((s.toInt() shr 8) and 0xFF).toByte()
                idx += 2
            }
        }
        return out
    }

    /** Band-limited conversion of every channel. The result has exactly round(length * ratio) frames. */
    private fun resample(channels: Array<FloatArray>, srcRate: Int, dstRate: Int): Array<FloatArray> {
        val srcLen = if (channels.isNotEmpty()) channels[0].size else 0
        if (srcLen == 0) return channels
        val dstLen = (srcLen * (dstRate.toDouble() / srcRate.toDouble())).roundToInt()
        val plan = ResamplePlan.of(srcRate, dstRate)
        return Array(channels.size) { c ->
            val src = channels[c]
            val resampler = ChannelResampler(plan)
            val out = FloatArray(dstLen)
            var written = 0
            // in blocks, so the working copy stays small however long the sound is
            var pos = 0
            while (pos < srcLen && written < dstLen) {
                val n = minOf(BLOCK_FRAMES, srcLen - pos)
                val piece = resampler.push(src, pos, n)
                val take = minOf(piece.size, dstLen - written)
                System.arraycopy(piece, 0, out, written, take)
                written += take
                pos += n
            }
            if (written < dstLen) {
                val rest = resampler.finish()
                val take = minOf(rest.size, dstLen - written)
                System.arraycopy(rest, 0, out, written, take)
            }
            out
        }
    }

    private const val BLOCK_FRAMES = 65536

    private fun remapChannels(channels: Array<FloatArray>, srcChannels: Int, dstChannels: Int): Array<FloatArray> {
        if (srcChannels == dstChannels || channels.isEmpty()) return channels
        val frameCount = channels[0].size
        return when {
            srcChannels == 1 && dstChannels == 2 -> arrayOf(channels[0], channels[0])
            srcChannels >= 2 && dstChannels == 1 -> {
                val mono = FloatArray(frameCount) { i -> (channels[0][i] + channels[1][i]) / 2f }
                arrayOf(mono)
            }
            srcChannels >= 2 && dstChannels == 2 -> arrayOf(channels[0], channels[1])
            else -> channels
        }
    }

    /** Adds [addition] onto [base] starting at [offsetBytes] (may be negative or run past the end), scaled by [gain]. */
    fun mixInto(base: ByteArray, addition: ByteArray, offsetBytes: Int, gain: Float) {
        var b = offsetBytes
        var a = 0
        while (a + 1 < addition.size && b + 1 < base.size) {
            if (b >= 0) {
                val baseSample = (((base[b + 1].toInt()) shl 8) or (base[b].toInt() and 0xFF)).toShort().toInt()
                val addSample = (((addition[a + 1].toInt()) shl 8) or (addition[a].toInt() and 0xFF)).toShort().toInt()
                val mixed = (baseSample + addSample * gain).roundToInt().coerceIn(-32768, 32767)
                base[b] = (mixed and 0xFF).toByte()
                base[b + 1] = ((mixed shr 8) and 0xFF).toByte()
            }
            a += 2
            b += 2
        }
    }
}
