package com.videoslidemaker.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.staggeredgrid.LazyVerticalStaggeredGrid
import androidx.compose.foundation.lazy.staggeredgrid.StaggeredGridCells
import androidx.compose.foundation.lazy.staggeredgrid.itemsIndexed
import androidx.compose.foundation.lazy.staggeredgrid.rememberLazyStaggeredGridState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ZoomIn
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.TextButton
import com.videoslidemaker.app.model.MultiPhotoApply
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import kotlinx.coroutines.launch
import com.videoslidemaker.app.model.PoolImage
import com.videoslidemaker.app.ui.theme.Accent
import com.videoslidemaker.app.ui.theme.Bg
import com.videoslidemaker.app.ui.theme.BorderColor
import com.videoslidemaker.app.ui.theme.CardBg
import com.videoslidemaker.app.ui.theme.Green
import com.videoslidemaker.app.ui.theme.Muted
import com.videoslidemaker.app.ui.theme.OnAccent
import com.videoslidemaker.app.ui.theme.OnStatus
import com.videoslidemaker.app.ui.theme.Yellow
import com.videoslidemaker.app.ui.theme.Outline
import com.videoslidemaker.app.ui.theme.OverlayIcon
import com.videoslidemaker.app.ui.theme.OverlayScrim
import com.videoslidemaker.app.ui.theme.Surface
import com.videoslidemaker.app.ui.theme.TextMain

/** How big the photos are drawn in the browser. */
private enum class BrowserSize(val label: String, val columns: Int) {
    LARGE("Large", 1),
    MEDIUM("Medium", 2),
    SMALL("Small", 3)
}

/**
 * NEW (2.22): what the browser needs for "Select multiple photos -> Apply to sentences". Passed only by the Match screen;
 * without it the browser looks and works exactly as before.
 */
class MultiApplyHooks(
    /** What applying these photos (in selection order) WOULD do - shown live under the photos. */
    val preview: (List<String>) -> MultiPhotoApply.Result,
    /** Does it (one undoable change). Returns what was done. */
    val applyNow: (List<String>) -> MultiPhotoApply.Result?
)

/**
 * NEW: full-screen photo browser for the Match screen - the fast way to choose a photo.
 *
 * Why it exists: the little tile grid on the Match screen is small and sits at the bottom of a
 * long page, so judging each photo meant opening the viewer one at a time. Here you just scroll:
 *  - every photo is drawn WHOLE (never cropped), at its real shape, so subtitles and faces are
 *    readable straight away. "Large" shows one photo per row at full width; "Medium"/"Small" fit
 *    2 or 3 per row when you want to scan lots of photos quickly.
 *  - the sentence you are matching stays pinned at the top, so you never lose what you are
 *    choosing for. The arrows move to the previous / next sentence without leaving the browser.
 *  - tap a photo to use it. The browser STAYS OPEN, so with auto-advance on you can go
 *    photo -> next sentence -> photo -> next sentence without ever going back to the page.
 *  - "Unused only" hides photos you already placed, so the list gets shorter as you work.
 *  - the magnifier on a photo opens the pinch-to-zoom viewer for a closer look.
 *
 * Nothing here changes data by itself: [onPick] is the same action as tapping a tile.
 */
@Composable
fun PhotoBrowserDialog(
    images: List<PoolImage>,
    /** Photo id -> number (1-based) of the first sentence that already uses it. */
    usedOn: Map<String, Int>,
    currentImageId: String?,
    sentenceLabel: String,
    timeLabel: String,
    sentenceText: String,
    canPrev: Boolean,
    canNext: Boolean,
    onPrev: () -> Unit,
    onNext: () -> Unit,
    onPick: (PoolImage) -> Unit,
    onDismiss: () -> Unit,
    /** NEW: when given, the browser reopens at the same photo and the same size you left it on. */
    scrollMemory: ScrollMemory? = null,
    /** NEW (2.22): when given, a 🔊 button in the header reads the sentence aloud, so you can listen while you choose photos. */
    onListen: (() -> Unit)? = null,
    /** NEW (2.22): when given, "Select multiple" appears: pick many photos in order, then apply them to the sentences. */
    multiApply: MultiApplyHooks? = null,
    /** NEW (2.24): anything shown right under the sentence header - the Match screen puts a small "original recording + nudge" panel here. */
    topPanel: (@Composable () -> Unit)? = null
) {
    var size by remember {
        mutableStateOf(
            scrollMemory?.get("browser_size")?.index?.let { BrowserSize.values().getOrNull(it) } ?: BrowserSize.LARGE
        )
    }
    var unusedOnly by remember { mutableStateOf(false) }
    // The swipe-through viewer: the list as it was when it opened + which photo to start on.
    var viewer by remember { mutableStateOf<Pair<List<PoolImage>, Int>?>(null) }
    val scope = rememberCoroutineScope()

    // NEW (2.22): multi-select. [selected] keeps the photos in the order they were tapped (1st, 2nd, 3rd ...).
    var selectMode by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf<List<String>>(emptyList()) }
    var multiNote by remember { mutableStateOf<String?>(null) }
    var confirmApply by remember { mutableStateOf(false) }
    val selectedOrder = remember(selected) { selected.withIndex().associate { it.value to it.index + 1 } }
    val validSelected = remember(selected, images) {
        val inPool = images.mapTo(HashSet()) { it.id }
        selected.filter { it in inPool }
    }
    val toggleSelected: (PoolImage) -> Unit = { img ->
        multiNote = null
        selected = if (img.id in selectedOrder) selected - img.id else selected + img.id
    }
    val doApply: () -> Unit = {
        val r = multiApply?.applyNow?.invoke(validSelected)
        multiNote = r?.message() ?: "Nothing changed."
        selected = emptyList()
        confirmApply = false
    }

    val unusedCount = remember(images, usedOn) { images.count { it.id !in usedOn } }
    val shown = remember(images, usedOn, unusedOnly, currentImageId) {
        // The photo on the current sentence always stays in the list, so it never vanishes
        // from under your finger the moment you pick it.
        if (unusedOnly) images.filter { it.id !in usedOn || it.id == currentImageId } else images
    }
    val gridState = rememberSavedStaggeredGridState(scrollMemory, "browser_pool", shown.size)

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(
            Modifier
                .fillMaxSize()
                .background(Bg)
                .safeDrawingPadding()
        ) {
            // --- Pinned header: which sentence am I choosing for? ---
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(start = 4.dp, end = 4.dp, top = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Filled.Close, contentDescription = "Close photo browser", tint = TextMain)
                }
                Column(Modifier.weight(1f)) {
                    Text(
                        "$sentenceLabel · $timeLabel",
                        style = MaterialTheme.typography.labelMedium,
                        color = Accent,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        sentenceText.ifBlank { "(no text)" },
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextMain,
                        maxLines = 3,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                if (onListen != null) {
                    IconButton(onClick = onListen) {
                        Text("🔊", style = MaterialTheme.typography.titleMedium, modifier = Modifier.semantics { contentDescription = "Listen to this sentence" })
                    }
                }
                IconButton(onClick = onPrev, enabled = canPrev) {
                    Icon(
                        Icons.Filled.ChevronLeft,
                        contentDescription = "Previous sentence",
                        tint = if (canPrev) TextMain else Muted
                    )
                }
                IconButton(onClick = onNext, enabled = canNext) {
                    Icon(
                        Icons.Filled.ChevronRight,
                        contentDescription = "Next sentence",
                        tint = if (canNext) TextMain else Muted
                    )
                }
            }

            if (topPanel != null) {
                Box(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp)) { topPanel() }
            }

            // --- Size + filter ---
            Row(
                Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                BrowserSize.values().forEach { option ->
                    BrowserChip(
                        text = option.label,
                        selected = size == option,
                        role = Role.RadioButton,
                        onClick = {
                            size = option
                            scrollMemory?.set("browser_size", ScrollPos(option.ordinal, 0))
                        }
                    )
                }
                BrowserChip(
                    text = "Unused only · $unusedCount",
                    selected = unusedOnly,
                    role = Role.Checkbox,
                    onClick = { unusedOnly = !unusedOnly }
                )
                if (multiApply != null) {
                    BrowserChip(
                        text = "☑ Select multiple",
                        selected = selectMode,
                        role = Role.Checkbox,
                        onClick = {
                            selectMode = !selectMode
                            if (!selectMode) selected = emptyList()
                            multiNote = null
                        }
                    )
                    if (selectMode) {
                        BrowserChip(
                            text = "Select all shown · ${shown.size}",
                            selected = false,
                            role = Role.Button,
                            onClick = { multiNote = null; selected = shown.map { it.id } }
                        )
                    }
                }
            }
            Text(
                if (selectMode) "Tap photos in the order you want them · tap again to unselect · 🔍 or press and hold to see full size"
                else "Tap a photo to use it · 🔍 or press and hold to swipe through full size · drag the right edge to scroll fast",
                style = MaterialTheme.typography.labelSmall,
                color = Muted,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 2.dp)
            )

            // --- The photos ---
            if (shown.isEmpty()) {
                Box(Modifier.weight(1f).fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
                    Text(
                        if (images.isEmpty()) "No photos yet — add some from the Photos screen."
                        else "Every photo is already used. Turn off “Unused only” to see them all.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Muted,
                        textAlign = TextAlign.Center
                    )
                }
            } else {
                val scrollerOn = shown.size >= FastScrollMinItems
                Box(Modifier.weight(1f).fillMaxWidth()) {
                    LazyVerticalStaggeredGrid(
                        columns = StaggeredGridCells.Fixed(size.columns),
                        state = gridState,
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(
                            start = 8.dp,
                            end = if (scrollerOn) FastScrollGutter else 8.dp,
                            top = 8.dp,
                            bottom = 32.dp
                        ),
                        verticalItemSpacing = 8.dp,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        itemsIndexed(shown, key = { _, image -> image.id }) { index, image ->
                            PhotoBrowserCard(
                                image = image,
                                positionLabel = "${index + 1}/${shown.size}",
                                usedOnSentence = usedOn[image.id],
                                isCurrent = image.id == currentImageId,
                                showPosition = size != BrowserSize.SMALL,
                                compact = size == BrowserSize.SMALL,
                                onPick = { if (selectMode) toggleSelected(image) else onPick(image) },
                                onZoom = { viewer = shown to index },
                                selectMode = selectMode,
                                selectionNumber = selectedOrder[image.id]
                            )
                        }
                    }
                    // Drag the handle on the right edge to fly through all the photos.
                    FastScroller(
                        itemCount = shown.size,
                        firstVisibleIndex = gridState.firstVisibleItemIndex,
                        atEnd = !gridState.canScrollForward,
                        isScrolling = gridState.isScrollInProgress,
                        onJumpTo = { i -> scope.launch { gridState.scrollToItem(i) } },
                        label = { i -> "Photo ${i + 1} / ${shown.size}" },
                        modifier = Modifier.fillMaxSize()
                    )
                    // NEW: one-tap jump to the start, the middle or the end.
                    if (shown.size >= 3) {
                        val lastShown = shown.size - 1
                        val jumpTo: (Int) -> Unit = { i -> scope.launch { gridState.scrollToItem(i.coerceIn(0, lastShown)) } }
                        JumpBar(
                            onTop = { jumpTo(0) },
                            onMiddle = { jumpTo(lastShown / 2) },
                            onBottom = { jumpTo(lastShown) },
                            modifier = Modifier
                                .align(Alignment.BottomCenter)
                                .padding(bottom = 16.dp, end = if (scrollerOn) FastScrollGutter else 0.dp)
                        )
                    }
                }
            }

            // --- NEW (2.22): the multi-select bar ---
            if (multiApply != null) {
                multiNote?.let { note ->
                    Text(
                        note,
                        style = MaterialTheme.typography.labelMedium,
                        color = Green,
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp)
                    )
                }
                if (selectMode) {
                    val plan = remember(validSelected, multiApply) { multiApply.preview(validSelected) }
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .background(CardBg)
                            .border(1.dp, BorderColor)
                            .padding(horizontal = 12.dp, vertical = 8.dp)
                    ) {
                        Text(
                            "${validSelected.size} selected",
                            style = MaterialTheme.typography.labelLarge,
                            color = Accent,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            plan.preview(validSelected.size),
                            style = MaterialTheme.typography.bodySmall,
                            color = TextMain,
                            modifier = Modifier.padding(top = 2.dp)
                        )
                        Row(
                            Modifier.fillMaxWidth().padding(top = 8.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            BrowserChip(
                                text = "Clear",
                                selected = false,
                                role = Role.Button,
                                onClick = { selected = emptyList(); multiNote = null }
                            )
                            BrowserChip(
                                text = "Apply to sentences",
                                selected = plan.applied > 0,
                                role = Role.Button,
                                onClick = { if (plan.applied > 0) { if (plan.replaced > 0) confirmApply = true else doApply() } }
                            )
                        }
                    }
                }
            }
        }
    }

    if (confirmApply && multiApply != null) {
        val plan = multiApply.preview(validSelected)
        AlertDialog(
            onDismissRequest = { confirmApply = false },
            title = { Text("Replace existing photos?") },
            text = { Text(plan.preview(validSelected.size), style = MaterialTheme.typography.bodyMedium) },
            confirmButton = { TextButton(onClick = doApply) { Text("Apply") } },
            dismissButton = { TextButton(onClick = { confirmApply = false }) { Text("Cancel") } }
        )
    }

    viewer?.let { (list, start) ->
        PhotoPagerDialog(
            images = list,
            startIndex = start,
            usedOn = usedOn,
            currentImageId = currentImageId,
            sentenceLabel = sentenceLabel,
            timeLabel = timeLabel,
            sentenceText = sentenceText,
            onPick = onPick,
            onDismiss = { viewer = null }
        )
    }
}

/**
 * One photo tile, drawn whole at its real shape. Shared by the full-screen browser and the photo
 * pool on the Match screen. [compact] is for 3-per-row tiles (shorter tags, smaller zoom button);
 * [onDelete] adds the ✕ that removes the photo from the pool (only the Match screen passes it).
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
internal fun PhotoBrowserCard(
    image: PoolImage,
    positionLabel: String,
    usedOnSentence: Int?,
    isCurrent: Boolean,
    showPosition: Boolean,
    onPick: () -> Unit,
    onZoom: () -> Unit,
    compact: Boolean = false,
    onDelete: (() -> Unit)? = null,
    /** NEW: this is the photo somebody just double-tapped in the "All segments" strip to find - shown in yellow. */
    isLocated: Boolean = false,
    /** NEW (2.22): the browser is in "Select multiple" mode: a tap selects instead of using the photo. */
    selectMode: Boolean = false,
    /** NEW (2.22): this photo's place in the selection (1 = tapped first), null = not selected. */
    selectionNumber: Int? = null
) {
    // The card takes the photo's real shape, so the whole picture fills it with no empty bars.
    // Sizes come from the import (already corrected for phone rotation); 16:9 if unknown.
    val ratio = if (image.widthPx > 0 && image.heightPx > 0) {
        (image.widthPx.toFloat() / image.heightPx.toFloat()).coerceIn(0.4f, 3f)
    } else {
        16f / 9f
    }
    val shape = RoundedCornerShape(10.dp)
    Box(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(CardBg)
            .border(
                if (isLocated) 4.dp else if (selectionNumber != null) 4.dp else if (isCurrent) 3.dp else 1.dp,
                if (isLocated) Yellow else if (selectionNumber != null) Green else if (isCurrent) Accent else BorderColor,
                shape
            )
            .combinedClickable(
                onClickLabel = if (selectMode) "Select or unselect this photo" else "Use this photo for the current sentence",
                role = Role.Button,
                onLongClickLabel = "View photos full size",
                onLongClick = onZoom,
                onClick = onPick
            )
    ) {
        AsyncImage(
            model = image.uri,
            contentDescription = image.displayName,
            contentScale = ContentScale.Fit,
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(ratio)
        )

        // Status tag: state is shown in words, not colour alone.
        when {
            isLocated -> StatusTag(if (compact) "\uD83D\uDCCD" else "\uD83D\uDCCD Found it", Yellow, OnStatus, Modifier.align(Alignment.TopEnd).padding(6.dp))
            isCurrent -> StatusTag(if (compact) "✓" else "✓ This sentence", Accent, OnAccent, Modifier.align(Alignment.TopEnd).padding(6.dp))
            usedOnSentence != null -> StatusTag(if (compact) "#$usedOnSentence" else "Used · #$usedOnSentence", Green, OnStatus, Modifier.align(Alignment.TopEnd).padding(6.dp))
        }

        if (selectMode) {
            // the number is the order the photos will go onto the sentences
            Text(
                selectionNumber?.toString() ?: "○",
                style = MaterialTheme.typography.labelLarge,
                color = if (selectionNumber != null) OnStatus else OverlayIcon,
                fontWeight = FontWeight.Bold,
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(6.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(if (selectionNumber != null) Green else OverlayScrim)
                    .padding(horizontal = 10.dp, vertical = 4.dp)
            )
        }

        if (onDelete != null) {
            OverlayCloseButton(
                description = "Remove ${image.displayName} from pool",
                onClick = onDelete,
                modifier = Modifier.align(Alignment.TopStart).padding(6.dp)
            )
        }

        if (showPosition) {
            Text(
                positionLabel,
                style = MaterialTheme.typography.labelSmall,
                color = OverlayIcon,
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(6.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(OverlayScrim)
                    .padding(horizontal = 8.dp, vertical = 3.dp)
            )
        }

        // A bigger target than the shared 30dp overlay button: it sits on top of a card that is
        // itself tappable, so a near-miss would pick the photo instead of zooming it.
        Box(
            Modifier
                .align(Alignment.BottomEnd)
                .padding(6.dp)
                .size(if (compact) 36.dp else 44.dp)
                .clip(CircleShape)
                .background(OverlayScrim)
                .combinedClickable(onClickLabel = "View ${image.displayName} zoomed in", role = Role.Button, onClick = onZoom)
                .semantics { contentDescription = "Zoom in on ${image.displayName}" },
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Filled.ZoomIn, contentDescription = null, tint = OverlayIcon, modifier = Modifier.size(if (compact) 20.dp else 24.dp))
        }
    }
}

@Composable
private fun StatusTag(text: String, bg: Color, fg: Color, modifier: Modifier = Modifier) {
    Text(
        text,
        style = MaterialTheme.typography.labelMedium,
        color = fg,
        fontWeight = FontWeight.Bold,
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(bg)
            .padding(horizontal = 8.dp, vertical = 4.dp)
    )
}

@Composable
private fun BrowserChip(text: String, selected: Boolean, role: Role, onClick: () -> Unit) {
    val shape = RoundedCornerShape(20.dp)
    Box(
        Modifier
            .heightIn(min = 44.dp)
            .clip(shape)
            .background(if (selected) Accent else Surface)
            .border(1.dp, if (selected) Accent else Outline, shape)
            .selectable(selected = selected, role = role, onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text,
            style = MaterialTheme.typography.labelLarge,
            color = if (selected) OnAccent else TextMain,
            fontWeight = FontWeight.Bold,
            maxLines = 1
        )
    }
}
