package com.videoslidemaker.app.audio

import kotlin.math.roundToInt

/** NEW (2.17): a ready-made text to paste into a free AI music site, so asking for the right kind of background music is one tap. */
object AiMusicPrompt {
    val MOODS = listOf("Calm", "Cinematic", "Upbeat", "Emotional", "Mystery", "Epic", "Happy", "Dark")

    fun build(mood: String, videoSec: Double): String {
        val minutes = (videoSec / 60.0).roundToInt()
        val length = when {
            videoSec <= 0.0 -> "about 2 minutes"
            videoSec < 60.0 -> "about ${(videoSec.toInt() / 5 * 5).coerceAtLeast(15)} seconds"
            minutes <= 1 -> "about 1 minute"
            else -> "about $minutes minutes"
        }
        return "Instrumental background music for a video, ${mood.lowercase()} mood, $length long. " +
            "No vocals, no lyrics. Soft and steady so a person can speak over it, gentle intro and a smooth ending, " +
            "no sudden loud parts."
    }
}
