package com.videoslidemaker.app.model

import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * NEW (2.8): the numbers behind the Preview's playback-speed control - the same idea as the speed
 * menu on YouTube, so you can see and hear how your video comes across to people who watch it
 * faster or slower than normal.
 *
 * Pure maths only (no Android), so it is checked by PreviewSpeedTest on a plain JVM.
 *
 * Speed is a Float where 1 is normal, 0.5 is half speed and 2 is double speed. It only ever
 * changes the PREVIEW: it is not saved with the project, it is not part of Undo, and the exported
 * video is always made at normal speed (viewers pick their own speed on YouTube).
 */
object PreviewSpeed {
    const val MIN = 0.25f
    const val MAX = 4f
    const val NORMAL = 1f

    /** The one-tap choices. The slider and the +/- buttons reach everything in between, up to [MAX]. */
    val PRESETS: List<Float> = listOf(0.25f, 0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f, 3f)

    /** What the speed button next to play steps through, one tap at a time (then it starts again at the slowest). */
    val CYCLE: List<Float> = listOf(0.5f, 1f, 1.5f, 2f, 3f)

    /** The slider is on a log scale: [MIN] to [MAX] is a factor of 16, which is exactly four doublings. */
    private val LOG_RANGE: Float = ln(MAX / MIN)

    /** The nearest 0.05, kept between [MIN] and [MAX]. Anything that is not a number becomes normal speed. */
    fun snap(speed: Float): Float {
        if (speed.isNaN()) return NORMAL
        val clamped = speed.coerceIn(MIN, MAX)
        return (clamped * 20f).roundToInt() / 20f
    }

    /** True when the two speeds are the same choice (ignores tiny floating-point differences). */
    fun same(a: Float, b: Float): Boolean = abs(a - b) < 0.001f

    /** [speed] moved by [delta] (for the small -0.25 / -0.05 / +0.05 / +0.25 buttons). */
    fun nudge(speed: Float, delta: Float): Float = snap(speed + delta)

    /**
     * The next speed for the speed button: the first one in [CYCLE] that is faster than [speed], or the slowest
     * again after the fastest. Works from any speed (from 1.3x the next stop is 1.5x).
     */
    fun cycle(speed: Float): Float {
        val s = snap(speed)
        for (c in CYCLE) {
            if (c > s + 0.001f) return c
        }
        return CYCLE.first()
    }

    // ---------------------------------------------------------------------------------------------
    // How a speed is written
    // ---------------------------------------------------------------------------------------------

    /** The number without the sign: "1", "0.5", "1.25", "2.5". */
    fun number(speed: Float): String {
        val hundredths = (snap(speed) * 100f).roundToInt()
        val whole = hundredths / 100
        val fraction = hundredths % 100
        return when {
            fraction == 0 -> "$whole"
            fraction % 10 == 0 -> "$whole.${fraction / 10}"
            else -> "$whole.${fraction.toString().padStart(2, '0')}"
        }
    }

    /** "1×", "0.5×", "1.25×", "2.5×". */
    fun label(speed: Float): String = number(speed) + "×"

    /** For screen readers: "Normal speed", "2 times normal speed". */
    fun spoken(speed: Float): String =
        if (same(snap(speed), NORMAL)) "Normal speed" else number(speed) + " times normal speed"

    // ---------------------------------------------------------------------------------------------
    // The slider (log scale, so "normal" sits in the middle and every doubling is the same width)
    // ---------------------------------------------------------------------------------------------

    /** Where [speed] sits on the slider, 0 (slowest) to 1 (fastest). Normal speed is 0.5. */
    fun toSlider(speed: Float): Float {
        val s = if (speed.isNaN()) NORMAL else speed.coerceIn(MIN, MAX)
        return (ln(s / MIN) / LOG_RANGE).coerceIn(0f, 1f)
    }

    /** The speed for a slider position 0..1, rounded to the nearest 0.05. */
    fun fromSlider(position: Float): Float {
        val t = if (position.isNaN()) 0.5f else position.coerceIn(0f, 1f)
        return snap(MIN * exp(t * LOG_RANGE))
    }

    // ---------------------------------------------------------------------------------------------
    // What a speed means for the video
    // ---------------------------------------------------------------------------------------------

    /** How many seconds it takes to watch [mediaSec] seconds of video at [speed]. */
    fun watchSeconds(mediaSec: Double, speed: Float): Double =
        mediaSec / snap(speed).toDouble()

    /** The shortest of [count] photo durations (seconds), or 0 when there are none. */
    fun shortest(count: Int, durationOf: (Int) -> Double): Double {
        if (count <= 0) return 0.0
        var best = Double.MAX_VALUE
        for (i in 0 until count) {
            val d = durationOf(i)
            if (d < best) best = d
        }
        return best
    }

    /** How many of [count] photos would be on screen for less than [thresholdSec] (real seconds) at [speed]. */
    fun countBelow(count: Int, thresholdSec: Double, speed: Float, durationOf: (Int) -> Double): Int {
        val s = snap(speed).toDouble()
        var n = 0
        for (i in 0 until count) {
            if (durationOf(i) / s < thresholdSec) n++
        }
        return n
    }

    /** A short length of time: "under 0.1 s", "0.4 s", "3 s", "12 s". (Longer times are written by the screen as m:ss.) */
    fun formatShort(seconds: Double): String {
        if (seconds < 0.05) return "under 0.1 s"
        val tenths = (seconds * 10.0).roundToInt()
        val whole = tenths / 10
        val fraction = tenths % 10
        return if (fraction == 0) "$whole s" else "$whole.$fraction s"
    }

    // ---------------------------------------------------------------------------------------------
    // Keeping the sound and the pictures together
    // ---------------------------------------------------------------------------------------------

    /**
     * Speeds to try, best first, when a phone's sound player refuses [wanted]: the wanted speed, then
     * simpler ones closer to normal, ending at normal. (Most phones accept everything; a few stop at 2x.)
     */
    fun fallbackLadder(wanted: Float): List<Float> {
        val w = snap(wanted)
        val out = ArrayList<Float>()
        out.add(w)
        if (w > NORMAL) {
            for (s in listOf(2f, 1.5f, 1.25f)) {
                if (s < w) out.add(s)
            }
            out.add(NORMAL)
        } else if (w < NORMAL) {
            for (s in listOf(0.5f, 0.75f)) {
                if (s > w) out.add(s)
            }
            out.add(NORMAL)
        }
        return out
    }

    /**
     * The phone's voice speed while previewing: the voice speed you chose times the preview speed, kept
     * inside the range speech engines accept. (Slides come round [speed] times as fast, so the words must too.)
     */
    fun ttsRate(baseRate: Float, speed: Float): Float =
        (baseRate * snap(speed)).coerceIn(0.1f, 4f)

    /**
     * How far the photos may drift from the recording before they are pulled back into line, in seconds of
     * the recording. 0.12 s at normal speed; wider when sped up, so it is still 0.12 s of what you SEE.
     */
    fun driftToleranceSec(speed: Float): Double = 0.12 * max(1.0, speed.toDouble())

    /**
     * A fade that lasts [ms] at normal speed. At 2x it lasts half as long, exactly as it does when a viewer
     * speeds the video up. Zero stays zero (a hard cut).
     */
    fun scaledMs(ms: Int, speed: Float): Int =
        if (ms <= 0) 0 else (ms / snap(speed)).roundToInt().coerceAtLeast(1)

    /** How many photos to load ahead of the one on screen: more when the slides go by faster. */
    fun lookAhead(speed: Float): Int = (2f * ceil(snap(speed))).toInt().coerceIn(2, 8)
}
