package com.videoslidemaker.app.ui.screens

import com.videoslidemaker.app.ui.components.OverlayIconButton
import com.videoslidemaker.app.ui.components.FastScrollGutter
import com.videoslidemaker.app.ui.components.FastScrollMinItems
import com.videoslidemaker.app.ui.components.FastScroller
import com.videoslidemaker.app.ui.components.JumpBar
import com.videoslidemaker.app.ui.components.ScrollPos
import com.videoslidemaker.app.ui.components.rememberSavedScrollState
import com.videoslidemaker.app.ui.components.rememberSavedStaggeredGridState
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import com.videoslidemaker.app.ui.components.PhotoBrowserCard
import com.videoslidemaker.app.ui.components.PhotoBrowserDialog
import com.videoslidemaker.app.ui.components.PhotoPagerDialog
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.lazy.staggeredgrid.LazyVerticalStaggeredGrid
import androidx.compose.foundation.lazy.staggeredgrid.StaggeredGridCells
import androidx.compose.foundation.lazy.staggeredgrid.itemsIndexed
import androidx.compose.foundation.lazy.staggeredgrid.rememberLazyStaggeredGridState
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.platform.LocalConfiguration
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import androidx.compose.foundation.relocation.BringIntoViewRequester
import androidx.compose.foundation.relocation.bringIntoViewRequester
import androidx.compose.ui.semantics.CustomAccessibilityAction
import androidx.compose.ui.semantics.customActions
import androidx.compose.runtime.mutableLongStateOf
import com.videoslidemaker.app.ui.theme.Yellow
import com.videoslidemaker.app.model.PoolImage
import androidx.compose.material.icons.filled.ZoomIn
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.ExperimentalFoundationApi
import com.videoslidemaker.app.ui.theme.Outline
import com.videoslidemaker.app.ui.theme.OnStatus
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import android.net.Uri
import coil.compose.AsyncImage
import com.videoslidemaker.app.data.ScriptParser
import com.videoslidemaker.app.model.AppStep
import com.videoslidemaker.app.logoclean.CleanUnit
import com.videoslidemaker.app.model.UiState
import com.videoslidemaker.app.ui.components.AlertStyle
import com.videoslidemaker.app.ui.components.BadgeChip
import com.videoslidemaker.app.ui.components.CompactButton
import com.videoslidemaker.app.ui.components.LogoCleanerDialog
import com.videoslidemaker.app.ui.components.PrimaryButton
import com.videoslidemaker.app.ui.components.ScreenTitle
import com.videoslidemaker.app.ui.components.SectionCard
import com.videoslidemaker.app.ui.components.SecondaryButton
import com.videoslidemaker.app.ui.components.SettingRow
import com.videoslidemaker.app.ui.components.SettingToggleRow
import com.videoslidemaker.app.ui.components.OverlayCloseButton
import com.videoslidemaker.app.ui.theme.Accent
import com.videoslidemaker.app.ui.theme.BorderColor
import com.videoslidemaker.app.ui.theme.CardBg
import com.videoslidemaker.app.ui.theme.Green
import com.videoslidemaker.app.ui.theme.Muted
import com.videoslidemaker.app.ui.theme.Red
import com.videoslidemaker.app.ui.theme.Surface
import com.videoslidemaker.app.ui.theme.TextMain
import com.videoslidemaker.app.viewmodel.AppViewModel

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun MatchScreen(state: UiState, viewModel: AppViewModel, onPickImages: () -> Unit, onPickRecording: () -> Unit) {
    if (!state.scriptLoaded) {
        Column(Modifier.fillMaxWidth().padding(16.dp)) {
            ScreenTitle("Match Photos to Sentences")
            SectionCard {
                Text(
                    "You're using simple mode — no script loaded, so there's nothing to match. " +
                        "Each photo already plays in order with the time you set for it.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Muted
                )
            }
            PrimaryButton("Skip to Text/Preview →", modifier = Modifier.padding(top = 16.dp), onClick = { viewModel.goStep(AppStep.TEXT) })
            SecondaryButton("← Back to Photos", onClick = { viewModel.goStep(AppStep.PHOTOS) })
        }
        return
    }

    val idx = state.curMatchIndex
    val slide = state.slides.getOrNull(idx)
    val nextSlide = state.slides.getOrNull(idx + 1)

    if (slide == null) {
        Column(Modifier.fillMaxWidth().padding(16.dp)) {
            Text("No sentences to match yet.", color = Muted)
        }
        return
    }

    var textValue by remember(idx) { mutableStateOf(TextFieldValue(slide.text)) }
    // NEW: Undo / Redo can change this sentence's text from outside the box - show it right away.
    // (While you type, the two are already equal, so nothing happens.)
    LaunchedEffect(slide.text) {
        if (textValue.text != slide.text) {
            textValue = TextFieldValue(slide.text, androidx.compose.ui.text.TextRange(slide.text.length))
        }
    }
    var showSplitPanel by remember(idx) { mutableStateOf(false) }
    // The swipe-through full-size viewer (null = closed): the photo list as it was when it opened,
    // and which photo to start on. Swiping inside it moves through ALL photos.
    var viewer by remember { mutableStateOf<Pair<List<PoolImage>, Int>?>(null) }
    val openViewer: (PoolImage) -> Unit = { img ->
        val list = state.images
        viewer = list to list.indexOfFirst { it.id == img.id }.coerceAtLeast(0)
    }
    // Which sentence (1-based) first uses each photo - drives the green "Used · #N" tags.
    val usedOn = remember(state.slides) {
        val map = HashMap<String, Int>()
        state.slides.forEachIndexed { i, s ->
            val id = s.assignedImageId
            if (id != null && id !in map) map[id] = i + 1
        }
        map
    }
    // How many photos per row in the photo pool below (1 = biggest, 3 = most photos on screen).
    // NEW: remembered too, so coming back from Preview shows the same size you chose.
    val scrollMemory = viewModel.scrollMemory
    var poolColumns by remember {
        mutableIntStateOf(scrollMemory.get("match_columns").index.takeIf { it in 1..3 } ?: 2)
    }
    // NEW: the pool (and the page around it) keep their scroll position when you go to Preview /
    // Text / another screen and come back, and across closing the app.
    val poolState = rememberSavedStaggeredGridState(scrollMemory, "match_pool", state.images.size)
    val pageScroll = rememberSavedScrollState(scrollMemory, "match_page")
    // The sentence you are on is remembered too, so reopening the app doesn't send you back to #1.
    LaunchedEffect(idx) { scrollMemory.set("match_index", ScrollPos(idx, 0)) }
    val poolScope = rememberCoroutineScope()

    // NEW: double-tap a segment in the "All segments" strip to FIND its photo in the photo list below: the list
    // scrolls to it, the page scrolls so the list is on screen, and the photo is shown in yellow for a few seconds.
    var locatedId by remember { mutableStateOf<String?>(null) }
    var locatedNote by remember { mutableStateOf<String?>(null) }
    var locateTick by remember { mutableIntStateOf(0) }
    val poolInView = remember { BringIntoViewRequester() }
    LaunchedEffect(locateTick) {
        if (locateTick > 0) {
            delay(LOCATE_SHOW_MS)
            locatedId = null
            locatedNote = null
        }
    }
    val locateSegment: (Int) -> Unit = { segmentIndex ->
        // the photo the video really shows for that segment (its own pick, or the one that covers it)
        val photo = state.finalSequence().getOrNull(segmentIndex)
        val at = if (photo == null) -1 else state.images.indexOfFirst { it.id == photo.id }
        locateTick++
        if (photo == null || at < 0) {
            locatedId = null
            locatedNote = if (state.images.isEmpty()) "There are no photos in your pool yet."
            else "Segment ${segmentIndex + 1} has no photo in your pool (it may have been removed)."
        } else {
            locatedId = photo.id
            locatedNote = "\uD83D\uDCCD Segment ${segmentIndex + 1}'s photo is photo ${at + 1} of ${state.images.size}"
            poolScope.launch {
                poolState.scrollToItem(at)
                poolInView.bringIntoView()
            }
        }
    }
    // The full-screen photo browser. Deliberately NOT keyed to the sentence: it stays open while
    // auto-advance moves to the next sentence, so photos can be picked back to back.
    var showBrowser by remember { mutableStateOf(false) }
    // NEW (2.9): remove / blur a logo, icon, subtitle or text in THIS segment, a range of segments, or all of them.
    var showCleaner by remember { mutableStateOf(false) }
    if (showCleaner) {
        val cleanUi by viewModel.logoClean.ui.collectAsState()
        // one step per segment: the photo it shows (explicitly matched, or the fallback the video really uses)
        // (keyed on the NUMBER of photos, not the list: during a big run the list is replaced every few seconds,
        // but which photo a segment shows never changes while this window is open)
        val steps = remember(state.slides, state.images.size) {
            val photos = state.finalSequence()
            val list = ArrayList<CleanUnit>(photos.size)
            for (i in photos.indices) {
                // a segment only has no photo when there are no photos at all, and then this screen offers no button
                val photo = photos[i] ?: continue
                val slideAt = state.slides[i]
                val slotEndAt = state.slides.getOrNull(i + 1)?.timestampSec ?: (slideAt.timestampSec + state.settings.defaultDurationSec)
                val words = slideAt.text.trim().take(48)
                list.add(
                    CleanUnit(
                        photo.id,
                        ScriptParser.formatTime(slideAt.timestampSec) + " – " + ScriptParser.formatTime(slotEndAt) +
                            (if (words.isEmpty()) "" else " · $words")
                    )
                )
            }
            list
        }
        LogoCleanerDialog(
            images = state.images,
            ui = cleanUi,
            controller = viewModel.logoClean,
            onDismiss = { showCleaner = false },
            units = steps,
            unitWord = "segment",
            startUnit = idx
        )
    }

    Column(
        Modifier
            .fillMaxWidth()
            .verticalScroll(pageScroll)
            .padding(16.dp)
    ) {
        ScreenTitle("Match Photos to Sentences")
        BadgeChip("Sentence ${idx + 1} of ${state.slides.size}", AlertStyle.INFO, Modifier.padding(bottom = 12.dp))

        Text(
            "All segments — tap to jump · tap twice to find its photo in the list below · ✕ removes a photo and lets the next one cover that time",
            style = MaterialTheme.typography.bodySmall,
            color = Muted,
            modifier = Modifier.padding(bottom = 8.dp)
        )
        // Lazy, so only the segments on screen are built - with thousands of segments a plain
        // Row would create (and load a thumbnail for) every single one of them.
        val imageById = remember(state.images) { state.images.associateBy { it.id } }
        LazyRow(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            itemsIndexed(state.slides) { i, s ->
                val img = s.assignedImageId?.let { id -> imageById[id] }
                val slotEndI = state.slides.getOrNull(i + 1)?.timestampSec ?: (s.timestampSec + state.settings.defaultDurationSec)
                TimelineCard(
                    startLabel = ScriptParser.formatTime(s.timestampSec),
                    endLabel = ScriptParser.formatTime(slotEndI),
                    imageUri = img?.uri,
                    isCurrent = i == idx,
                    onClick = { viewModel.goToMatchIndex(i) },
                    onLocate = { locateSegment(i) },
                    onRemove = { viewModel.removePhotoAndCloseGap(i) }
                )
            }
        }
        // only when the photo could NOT be found (when it is found the note is shown on the photo list itself)
        if (locatedId == null) {
            locatedNote?.let { note ->
                Text(note, style = MaterialTheme.typography.labelMedium, color = Muted, modifier = Modifier.padding(bottom = 12.dp))
            }
        }

        SectionCard(modifier = Modifier.padding(bottom = 12.dp)) {
            val slotEnd = nextSlide?.timestampSec ?: (slide.timestampSec + state.settings.defaultDurationSec)
            Text(
                "${ScriptParser.formatTime(slide.timestampSec)} – ${ScriptParser.formatTime(slotEnd)}",
                style = MaterialTheme.typography.labelMedium,
                color = Accent
            )
            BasicTextField(
                value = textValue,
                onValueChange = {
                    textValue = it
                    viewModel.editSentenceText(idx, it.text)
                },
                onTextLayout = {},
                textStyle = TextStyle(color = TextMain, fontSize = MaterialTheme.typography.bodyLarge.fontSize),
                // The default cursor is black - invisible on a dark background - so it follows the accent.
                cursorBrush = SolidColor(Accent),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 10.dp)
                    .semantics { contentDescription = "Sentence text" }
                    .background(Surface, RoundedCornerShape(10.dp))
                    .border(1.dp, Outline, RoundedCornerShape(10.dp))
                    .padding(12.dp)
            )

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 4.dp)) {
                CompactButton("🔊 Listen", onClick = { viewModel.speakCurrentSentence() })
                CompactButton("✂️ Split", onClick = { showSplitPanel = !showSplitPanel })
                CompactButton("🔗 Merge ↓", enabled = nextSlide != null, onClick = { viewModel.mergeCurrentWithNext() })
            }

            if (showSplitPanel) {
                val text = textValue.text
                val slotTooShort = (slotEnd - slide.timestampSec) < 0.5
                Column(Modifier.padding(top = 12.dp)) {
                    if (slotTooShort) {
                        Text("This moment is too short to split.", style = MaterialTheme.typography.bodySmall, color = Muted)
                    } else {
                        val cursor = textValue.selection.start.coerceIn(0, text.length)
                        // NEW: the split time is DERIVED from where the cursor sits in the text
                        // (proportionally across this segment's time range) instead of a separate,
                        // disconnected time slider — tap inside the sentence above and both
                        // resulting halves plus the exact time appear here automatically. The old
                        // design let the cursor and the slider disagree with each other silently;
                        // this can't, since there's only one thing to set.
                        val part1 = text.substring(0, cursor).trim()
                        val part2 = text.substring(cursor).trim()
                        val validSplit = part1.isNotBlank() && part2.isNotBlank()
                        if (validSplit) {
                            val computedSplitTime = slide.timestampSec +
                                (slotEnd - slide.timestampSec) * (cursor.toDouble() / text.length.coerceAtLeast(1))
                            Text("Splits at ${ScriptParser.formatTime(computedSplitTime)}:", style = MaterialTheme.typography.labelMedium, color = Accent)
                            Text("① $part1", style = MaterialTheme.typography.bodySmall, color = TextMain, modifier = Modifier.padding(top = 4.dp))
                            Text("② $part2", style = MaterialTheme.typography.bodySmall, color = TextMain, modifier = Modifier.padding(top = 2.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 10.dp)) {
                                CompactButton("Cancel", onClick = { showSplitPanel = false })
                                CompactButton("Confirm Split", onClick = {
                                    if (viewModel.splitCurrentSentence(cursor, computedSplitTime)) {
                                        showSplitPanel = false
                                    }
                                })
                            }
                        } else {
                            Text(
                                "Tap inside the sentence above, right where you want it to split — the two halves and the exact time will show here.",
                                style = MaterialTheme.typography.bodySmall,
                                color = Muted
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 8.dp)) {
                                CompactButton("Cancel", onClick = { showSplitPanel = false })
                            }
                        }
                    }
                }
            }

            if (nextSlide != null) {
                Text(
                    "Next: ${nextSlide.text.ifBlank { "(no text)" }}",
                    style = MaterialTheme.typography.bodySmall,
                    color = Muted,
                    maxLines = 1,
                    modifier = Modifier.padding(top = 10.dp)
                )
            }
        }

        PrimaryButton(
            "🖼 Browse all photos — full size",
            modifier = Modifier.padding(bottom = 12.dp),
            enabled = state.images.isNotEmpty(),
            onClick = { showBrowser = true }
        )

        SecondaryButton(
            "🧽 Remove or blur logo, icon, subtitle or text — this segment, a range, or all",
            modifier = Modifier.padding(bottom = 12.dp),
            enabled = state.images.isNotEmpty(),
            onClick = { showCleaner = true }
        )

        OriginalAudioPanel(
            state = state,
            viewModel = viewModel,
            index = idx,
            onPickRecording = onPickRecording,
            modifier = Modifier.padding(bottom = 12.dp)
        )

        SettingToggleRow(
            "Auto-advance",
            "Move to next sentence after picking a photo",
            state.autoAdvance,
            viewModel::setAutoAdvance
        )

        Text("Currently assigned", style = MaterialTheme.typography.labelMedium, color = Muted, modifier = Modifier.padding(top = 8.dp, bottom = 8.dp))
        val assignedImage = slide.assignedImageId?.let { id -> state.images.firstOrNull { it.id == id } }
        Box(
            Modifier
                .fillMaxWidth()
                .height(200.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(CardBg)
                .border(1.dp, BorderColor, RoundedCornerShape(12.dp))
                .clickable(
                    enabled = assignedImage != null,
                    onClickLabel = "View photo full size",
                    role = Role.Button
                ) { assignedImage?.let(openViewer) },
            contentAlignment = Alignment.Center
        ) {
            if (assignedImage != null) {
                AsyncImage(model = assignedImage.uri, contentDescription = "Photo assigned to this sentence: ${assignedImage.displayName}", modifier = Modifier.fillMaxWidth().height(200.dp))
            } else {
                Text("No photo assigned yet", color = Muted, style = MaterialTheme.typography.bodySmall)
            }
        }
        if (assignedImage != null) {
            Text(
                "Tap the photo to see it full size",
                style = MaterialTheme.typography.labelMedium,
                color = Muted,
                modifier = Modifier.padding(top = 6.dp)
            )
            Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                CompactButton("✕ Remove Photo", onClick = { viewModel.removePhotoAndCloseGap(idx) })
            }
            Text(
                "Removing folds this slot into the next photo's time range (or the previous one, if this is the last slide).",
                style = MaterialTheme.typography.bodySmall,
                color = Muted,
                modifier = Modifier.padding(top = 4.dp)
            )
        }

        SecondaryButton("+ Add More Photos", modifier = Modifier.padding(top = 16.dp), enabled = state.importProgress == null, onClick = onPickImages)

        Text(
            "Tap a photo to use it · 🔍 or press and hold to see it full size and swipe through all · ✕ removes it from your pool · drag the right edge to scroll fast",
            style = MaterialTheme.typography.labelMedium,
            color = Muted,
            modifier = Modifier.padding(top = 12.dp, bottom = 8.dp)
        )
        Row(Modifier.padding(bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            CompactButton("▦ $poolColumns per row", onClick = {
                poolColumns = poolColumns % 3 + 1
                scrollMemory.set("match_columns", ScrollPos(poolColumns, 0))
            })
            CompactButton("⛶ Full screen", enabled = state.images.isNotEmpty(), onClick = { showBrowser = true })
        }
        if (state.images.isEmpty()) {
            Text("No photos in your pool yet — tap “Add More Photos” above.", style = MaterialTheme.typography.bodySmall, color = Muted)
        } else {
            // A tall window onto the pool (most of the screen, not a small strip), so you see several
            // WHOLE photos at once. Photos keep their real shape - nothing is cropped.
            val poolHeight = (LocalConfiguration.current.screenHeightDp * 0.8f).dp
            val scrollerOn = state.images.size >= FastScrollMinItems
            Box(Modifier.fillMaxWidth().height(poolHeight).bringIntoViewRequester(poolInView)) {
                LazyVerticalStaggeredGrid(
                    columns = StaggeredGridCells.Fixed(poolColumns),
                    state = poolState,
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(end = if (scrollerOn) FastScrollGutter else 0.dp, bottom = 8.dp),
                    verticalItemSpacing = 8.dp,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    itemsIndexed(state.images, key = { _, image -> image.id }) { index, image ->
                        PhotoBrowserCard(
                            image = image,
                            positionLabel = "${index + 1}/${state.images.size}",
                            usedOnSentence = usedOn[image.id],
                            isCurrent = image.id == slide.assignedImageId,
                            showPosition = poolColumns < 3,
                            compact = poolColumns == 3,
                            onPick = { viewModel.pickImage(image.id) },
                            onZoom = { openViewer(image) },
                            onDelete = { viewModel.deleteImage(image.id) },
                            isLocated = image.id == locatedId
                        )
                    }
                }
                if (locatedId != null) {
                    locatedNote?.let { note ->
                        Text(
                            note,
                            style = MaterialTheme.typography.labelMedium,
                            color = OnStatus,
                            modifier = Modifier
                                .align(Alignment.TopCenter)
                                .padding(top = 8.dp, end = if (scrollerOn) FastScrollGutter else 0.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(Yellow)
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                        )
                    }
                }
                FastScroller(
                    itemCount = state.images.size,
                    firstVisibleIndex = poolState.firstVisibleItemIndex,
                    atEnd = !poolState.canScrollForward,
                    isScrolling = poolState.isScrollInProgress,
                    onJumpTo = { i -> poolScope.launch { poolState.scrollToItem(i) } },
                    label = { i -> "Photo ${i + 1} / ${state.images.size}" },
                    modifier = Modifier.fillMaxSize()
                )
                // NEW: one-tap jump to the start, the middle or the end of the photo pool.
                if (state.images.size >= 3) {
                    val lastPhoto = state.images.size - 1
                    val jumpTo: (Int) -> Unit = { i -> poolScope.launch { poolState.scrollToItem(i.coerceIn(0, lastPhoto)) } }
                    JumpBar(
                        onTop = { jumpTo(0) },
                        onMiddle = { jumpTo(lastPhoto / 2) },
                        onBottom = { jumpTo(lastPhoto) },
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .padding(bottom = 12.dp, end = if (scrollerOn) FastScrollGutter else 0.dp)
                    )
                }
            }
        }

        Row(Modifier.padding(top = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            CompactButton("← Prev", onClick = viewModel::matchPrev, enabled = idx > 0)
            CompactButton("Skip →", onClick = viewModel::matchSkip, enabled = idx < state.slides.size - 1)
        }

        PrimaryButton(
            "Next — Add Text →",
            modifier = Modifier.padding(top = 12.dp),
            onClick = { viewModel.goStep(AppStep.TEXT) }
        )
        SecondaryButton("← Back to Photos", onClick = { viewModel.goStep(AppStep.PHOTOS) })
    }

    if (showBrowser) {
        val browserSlotEnd = nextSlide?.timestampSec ?: (slide.timestampSec + state.settings.defaultDurationSec)
        PhotoBrowserDialog(
            images = state.images,
            usedOn = usedOn,
            currentImageId = slide.assignedImageId,
            sentenceLabel = "Sentence ${idx + 1} of ${state.slides.size}",
            timeLabel = "${ScriptParser.formatTime(slide.timestampSec)} – ${ScriptParser.formatTime(browserSlotEnd)}",
            sentenceText = slide.text,
            canPrev = idx > 0,
            canNext = idx < state.slides.size - 1,
            onPrev = viewModel::matchPrev,
            onNext = viewModel::matchSkip,
            onPick = { viewModel.pickImage(it.id) },
            onDismiss = { showBrowser = false },
            scrollMemory = scrollMemory
        )
    }

    viewer?.let { (list, start) ->
        val viewerSlotEnd = nextSlide?.timestampSec ?: (slide.timestampSec + state.settings.defaultDurationSec)
        PhotoPagerDialog(
            images = list,
            startIndex = start,
            usedOn = usedOn,
            currentImageId = slide.assignedImageId,
            sentenceLabel = "Sentence ${idx + 1} of ${state.slides.size}",
            timeLabel = "${ScriptParser.formatTime(slide.timestampSec)} – ${ScriptParser.formatTime(viewerSlotEnd)}",
            sentenceText = slide.text,
            onPick = { viewModel.pickImage(it.id) },
            onDismiss = { viewer = null }
        )
    }
}

@Composable
private fun TimelineCard(
    startLabel: String,
    endLabel: String,
    imageUri: Uri?,
    isCurrent: Boolean,
    onClick: () -> Unit,
    onLocate: () -> Unit,
    onRemove: () -> Unit
) {
    // A tap jumps to this segment AT ONCE (no waiting to see whether a second tap follows); a second tap within
    // a moment means "find this photo in the list below".
    var lastTapAt by remember { mutableLongStateOf(0L) }
    Column(
        Modifier
            .width(76.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(CardBg)
            .border(if (isCurrent) 3.dp else 1.dp, if (isCurrent) Accent else BorderColor, RoundedCornerShape(10.dp))
            // for screen readers, where a quick second tap is not possible: the same thing as a menu action
            .semantics {
                customActions = listOf(CustomAccessibilityAction("Find this photo in the photo list") {
                    onLocate()
                    true
                })
            }
            .clickable(role = Role.Button) {
                val now = System.currentTimeMillis()
                if (lastTapAt != 0L && now - lastTapAt <= DOUBLE_TAP_MS) {
                    lastTapAt = 0L
                    onLocate()
                } else {
                    lastTapAt = now
                    onClick()
                }
            }
            .padding(4.dp)
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .height(64.dp)
                .clip(RoundedCornerShape(6.dp))
                .background(Surface)
        ) {
            if (imageUri != null) {
                AsyncImage(
                    model = imageUri,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxWidth().fillMaxHeight()
                )
                OverlayCloseButton(
                    description = "Remove photo from this part of the timeline",
                    onClick = onRemove,
                    modifier = Modifier.align(Alignment.TopEnd).padding(2.dp)
                )
            } else {
                Text("no photo", color = Muted, style = MaterialTheme.typography.labelSmall, modifier = Modifier.align(Alignment.Center))
            }
        }
        Text(
            "$startLabel–$endLabel",
            style = MaterialTheme.typography.labelSmall,
            color = if (isCurrent) Accent else Muted,
            maxLines = 1,
            modifier = Modifier.padding(top = 4.dp)
        )
    }
}

/** Two taps on a segment closer together than this (milliseconds) count as a double-tap. */
private const val DOUBLE_TAP_MS = 400L

/** How long the found photo stays highlighted (milliseconds). */
private const val LOCATE_SHOW_MS = 6000L
