package com.videoslidemaker.app.logoclean

import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min

/*
 * Finds the pixels of TEXT (a subtitle, a title, a name tag) inside a box, in ONE photo.
 * Port of tools/textclean-reference/textmask.py - same steps, same constants; read that file's header for the idea
 * in plain words. Pure maths, no Android classes, so it runs (and is unit-tested) on a plain JVM.
 *
 * The logo finder cannot do this: a watermark is the same in every photo, a subtitle is different in every photo.
 * What IS the same about text is its look - thin strokes, much brighter or darker than what is right around them,
 * flat in colour, many of them side by side along a line - so every photo is looked at on its own.
 */

/** What the finder found in one photo's box. Both masks cover the whole window, not just the box. */
internal class TextFound(
    /** The letters themselves (a little grown): what Remove and Remove + Blur repaint. */
    val mask: BooleanArray,
    /** The letters merged into words and lines: what Blur smudges, so it reads as one smear, not ghost letters. */
    val blurMask: BooleanArray,
    /** Share of the box that is letter (0..1). */
    val cover: Float,
    /** Stroke radius that was used, in pixels. */
    val radius: Int
)

/** How much a box has to look like text before it is treated as text. */
internal class TextGate(val minRuns: Int, val minInk: Int, val minPair: Float, val tScale: Float)

internal object TextMask {
    const val R_FRAC = 0.085       // stroke radius as a share of the box height ...
    const val R_MIN = 2            // ... clamped to this range (pixels)
    const val R_MAX = 14
    const val T_STRONG = 46f       // a letter pixel differs from its surroundings by at least this much (0..255)
    const val T_WEAK_FRAC = 0.45f  // ... and its anti-aliased fringe by at least this share of it
    const val RING_PERCENTILE = 92 // "how busy is the picture" = this percentile of the response OUTSIDE the box
    const val RING_MIN_PX = 200
    const val BUSY_GAIN = 1.5f     // strong threshold = max(T_STRONG, BUSY_GAIN * busy)
    const val WEAK_BUSY_GAIN = 1.1f
    const val MIN_STRONG_PX = 12
    const val MAX_COVER = 0.75f    // more than 75 % ink is a texture, not text
    const val MIN_COVER = 0.004f
    const val GROW_FRAC = 0.30     // the tight mask grows by this share of the radius
    const val GAP_FRAC_X = 1.6     // blur mask: letters closer than this many radii are merged (sideways) ...
    const val GAP_FRAC_Y = 0.8     // ... and (up / down)
    const val PAIR_R = 3           // "next to" = within this many pixels

    /** "Only where text is found": a box counts as text only when it clearly looks like text. */
    val NORMAL = TextGate(minRuns = 6, minInk = 110, minPair = 0.45f, tScale = 1.0f)

    /**
     * "Everywhere in the box": short or faint captions too, at the price of sometimes repainting texture. Measured
     * (tools/textclean-reference/tune_relaxed.py): 96 % of captions found; 5.8 % of the very hardest text-free boxes
     * (stars, gravel, stripes) trigger. The first, looser setting triggered on 37.7 % of them.
     */
    val RELAXED = TextGate(minRuns = 3, minInk = 70, minPair = 0.3f, tScale = 0.7f)

    fun strokeRadius(boxHeightPx: Int): Int =
        min(R_MAX, max(R_MIN, floor(R_FRAC * boxHeightPx + 0.5).toInt()))

    /**
     * Looks for text in the part of a window that [region] marks (the user's box). [argb] is the window
     * (w x h pixels); everything outside [region] is only READ: to learn how busy the picture is.
     * Returns null when the box does not look like it holds text - the photo should then be left alone.
     */
    fun detect(argb: IntArray, w: Int, h: Int, region: BooleanArray, relaxed: Boolean): TextFound? {
        val n = w * h
        var regionPx = 0
        var minY = h
        var maxY = -1
        for (y in 0 until h) {
            for (x in 0 until w) {
                if (region[y * w + x]) {
                    regionPx++
                    if (y < minY) minY = y
                    if (y > maxY) maxY = y
                }
            }
        }
        if (regionPx == 0) return null
        val gate = if (relaxed) RELAXED else NORMAL
        val r = strokeRadius(maxY - minY + 1)

        val luma = LogoDetector.luma(argb)
        val bright = FloatArray(n)
        val dark = FloatArray(n)
        thinResponse(luma, w, h, r, bright, dark)
        val resp = FloatArray(n)
        for (i in 0 until n) resp[i] = if (bright[i] > dark[i]) bright[i] else dark[i]

        val ringPx = n - regionPx
        val busy = if (ringPx >= RING_MIN_PX) histPercentile(resp, region, false, RING_PERCENTILE)
        else histPercentile(resp, region, true, 20)
        for (i in 0 until n) if (!region[i]) resp[i] = 0f

        val tStrong = max(T_STRONG * gate.tScale, BUSY_GAIN * busy)
        val tWeak = max(T_WEAK_FRAC * tStrong, WEAK_BUSY_GAIN * busy)
        var nStrong = 0
        for (i in 0 until n) if (resp[i] >= tStrong) nStrong++
        if (nStrong < MIN_STRONG_PX) return null

        // hysteresis: a weak pixel is kept only when its blob also holds a strong pixel
        val weak = BooleanArray(n) { resp[it] >= tWeak }
        val lab = label4(weak, w, h)
        val keep = BooleanArray(lab.count + 1)
        for (i in 0 until n) {
            if (resp[i] >= tStrong && lab.data[i] != 0) keep[lab.data[i]] = true
        }
        var ink = BooleanArray(n) { lab.data[it] != 0 && keep[lab.data[it]] && region[it] }
        ink = fillHoles(ink, w, h)
        for (i in 0 until n) if (!region[i]) ink[i] = false

        var inkPx = 0
        for (i in 0 until n) if (ink[i]) inkPx++
        val cover = inkPx.toFloat() / regionPx.toFloat()
        if (cover < MIN_COVER || cover > MAX_COVER) return null

        val strongBright = BooleanArray(n) { ink[it] && bright[it] >= tStrong }
        val strongDark = BooleanArray(n) { ink[it] && dark[it] >= tStrong }
        val runs = max(rowRuns(strongBright, region, w, h), rowRuns(strongDark, region, w, h))
        if (runs < gate.minRuns) return null

        val inkMed = if (inkPx > 0) histPercentile(resp, ink, true, 50) else 0
        if (inkMed < gate.minInk) return null

        val nearDark = maxFilter(strongDark, w, h, PAIR_R)
        val nearBright = maxFilter(strongBright, w, h, PAIR_R)
        var nb = 0
        var nd = 0
        var bPaired = 0
        var dPaired = 0
        for (i in 0 until n) {
            if (strongBright[i]) {
                nb++
                if (nearDark[i]) bPaired++
            }
            if (strongDark[i]) {
                nd++
                if (nearBright[i]) dPaired++
            }
        }
        val pair = max(bPaired.toFloat() / max(1, nb), dPaired.toFloat() / max(1, nd))
        if (pair < gate.minPair) return null

        val grow = max(1, floor(GROW_FRAC * r + 0.5).toInt())
        val tightGrown = maxFilter(ink, w, h, grow)
        val tight = BooleanArray(n) { tightGrown[it] && region[it] }

        val gx = max(1, floor(GAP_FRAC_X * r + 0.5).toInt())
        val gy = max(1, floor(GAP_FRAC_Y * r + 0.5).toInt())
        val merged = closeRect(ink, w, h, gx, gy)
        for (i in 0 until n) if (!region[i]) merged[i] = false
        val mergedGrown = maxFilter(merged, w, h, grow)
        val blur = BooleanArray(n) { mergedGrown[it] && region[it] }
        return TextFound(tight, blur, cover, r)
    }

    // ------------------------------------------------------------------------------ thin strokes

    /**
     * [bright]: how much each pixel is a thin BRIGHT stroke (white letters); [dark]: a thin DARK stroke (an outline,
     * black letters). Both are 0 on smooth areas and on anything wider than 2r+1.
     */
    internal fun thinResponse(luma: FloatArray, w: Int, h: Int, r: Int, bright: FloatArray, dark: FloatArray) {
        val eroded = extreme2d(luma, w, h, r, true)
        val opened = extreme2d(eroded, w, h, r, false)
        val dilated = extreme2d(luma, w, h, r, false)
        val closed = extreme2d(dilated, w, h, r, true)
        for (i in 0 until w * h) {
            val b = luma[i] - opened[i]
            val d = closed[i] - luma[i]
            bright[i] = if (b > 0f) b else 0f
            dark[i] = if (d > 0f) d else 0f
        }
    }

    private fun pick(a: Float, b: Float, takeMin: Boolean): Float =
        if (takeMin) (if (a < b) a else b) else (if (a > b) a else b)

    /**
     * Min (or max) over a (2r+1) x (2r+1) square, border repeating. van Herk / Gil-Werman on rows then columns:
     * the work per pixel does not depend on r.
     */
    internal fun extreme2d(src: FloatArray, w: Int, h: Int, r: Int, takeMin: Boolean): FloatArray {
        if (r <= 0) return src.copyOf()
        val k = 2 * r + 1
        val longest = max(w, h) + 2 * r
        val p = FloatArray(longest)
        val g = FloatArray(longest)
        val hh = FloatArray(longest)
        val line = FloatArray(max(w, h))
        val tmp = FloatArray(w * h)
        for (y in 0 until h) {
            val m = w + 2 * r
            val row = y * w
            for (j in 0 until m) p[j] = src[row + (j - r).coerceIn(0, w - 1)]
            extremeLine(p, m, w, k, takeMin, g, hh, line)
            for (x in 0 until w) tmp[row + x] = line[x]
        }
        val out = FloatArray(w * h)
        for (x in 0 until w) {
            val m = h + 2 * r
            for (j in 0 until m) p[j] = tmp[(j - r).coerceIn(0, h - 1) * w + x]
            extremeLine(p, m, h, k, takeMin, g, hh, line)
            for (y in 0 until h) out[y * w + x] = line[y]
        }
        return out
    }

    /** One line: [p] is the line padded by r on both sides (length m = n + 2r); writes n results to [out]. */
    private fun extremeLine(
        p: FloatArray, m: Int, n: Int, k: Int, takeMin: Boolean,
        g: FloatArray, hh: FloatArray, out: FloatArray
    ) {
        var s = 0
        while (s < m) {
            val e = min(s + k, m)
            g[s] = p[s]
            for (j in s + 1 until e) g[j] = pick(g[j - 1], p[j], takeMin)
            hh[e - 1] = p[e - 1]
            for (j in e - 2 downTo s) hh[j] = pick(hh[j + 1], p[j], takeMin)
            s += k
        }
        for (i in 0 until n) out[i] = pick(hh[i], g[i + k - 1], takeMin)
    }

    // ------------------------------------------------------------------------------ shapes

    /** "Any pixel set" filter on a (2rx+1) x (2ry+1) rectangle. Two cheap passes; the border does not count. */
    internal fun maxFilterRect(src: BooleanArray, w: Int, h: Int, rx: Int, ry: Int): BooleanArray {
        val tmp = BooleanArray(w * h)
        if (rx <= 0) {
            System.arraycopy(src, 0, tmp, 0, w * h)
        } else {
            for (y in 0 until h) {
                val row = y * w
                var count = 0
                for (x in 0..min(rx, w - 1)) if (src[row + x]) count++
                for (x in 0 until w) {
                    tmp[row + x] = count > 0
                    val add = x + rx + 1
                    val rem = x - rx
                    if (add < w && src[row + add]) count++
                    if (rem >= 0 && src[row + rem]) count--
                }
            }
        }
        if (ry <= 0) return tmp
        val out = BooleanArray(w * h)
        for (x in 0 until w) {
            var count = 0
            for (y in 0..min(ry, h - 1)) if (tmp[y * w + x]) count++
            for (y in 0 until h) {
                out[y * w + x] = count > 0
                val add = y + ry + 1
                val rem = y - ry
                if (add < h && tmp[add * w + x]) count++
                if (rem >= 0 && tmp[rem * w + x]) count--
            }
        }
        return out
    }

    /** Grow by (rx, ry), then shrink by the same: merges things that are closer than that, keeps the outer shape. */
    internal fun closeRect(b: BooleanArray, w: Int, h: Int, rx: Int, ry: Int): BooleanArray {
        val grown = maxFilterRect(b, w, h, rx, ry)
        val inverted = BooleanArray(b.size) { !grown[it] }
        val shrunkInverted = maxFilterRect(inverted, w, h, rx, ry)
        return BooleanArray(b.size) { !shrunkInverted[it] }
    }

    /** Everything that cannot be reached from the border through empty pixels becomes set (inside of letters). */
    internal fun fillHoles(b: BooleanArray, w: Int, h: Int): BooleanArray {
        val empty = BooleanArray(b.size) { !b[it] }
        val lab = label4(empty, w, h)
        val outside = BooleanArray(lab.count + 1)
        for (x in 0 until w) {
            outside[lab.data[x]] = true
            outside[lab.data[(h - 1) * w + x]] = true
        }
        for (y in 0 until h) {
            outside[lab.data[y * w]] = true
            outside[lab.data[y * w + w - 1]] = true
        }
        val out = b.copyOf()
        for (i in 0 until w * h) {
            val l = lab.data[i]
            if (l != 0 && !outside[l]) out[i] = true
        }
        return out
    }

    // ------------------------------------------------------------------------------ statistics

    /**
     * Percentile of the non-negative [values] where [sel] == [want], read from a 256-bin histogram (the value cut to
     * a whole number, capped at 255): the first bin whose running count reaches ceil(pct/100 * n).
     */
    internal fun histPercentile(values: FloatArray, sel: BooleanArray, want: Boolean, pct: Int): Int {
        val hist = IntArray(256)
        var n = 0
        for (i in values.indices) {
            if (sel[i] != want) continue
            hist[min(255, floor(values[i].toDouble()).toInt())]++
            n++
        }
        if (n == 0) return 0
        val need = max(1, ceil(pct / 100.0 * n).toInt())
        var cum = 0
        for (b in 0 until 256) {
            cum += hist[b]
            if (cum >= need) return b
        }
        return 255
    }

    /**
     * How many separate stretches the busiest rows of [m] have (the 3rd busiest, so one noisy row is ignored). A
     * line of text crosses many strokes in one row; a lip line, a wire or an eyebrow crosses one or two.
     */
    internal fun rowRuns(m: BooleanArray, region: BooleanArray, w: Int, h: Int): Int {
        val counts = ArrayList<Int>()
        for (y in 0 until h) {
            var inRegion = false
            var runs = 0
            var prev = false
            for (x in 0 until w) {
                val i = y * w + x
                if (region[i]) inRegion = true
                val cur = m[i]
                if (cur && !prev) runs++
                prev = cur
            }
            if (inRegion) counts.add(runs)
        }
        if (counts.isEmpty()) return 0
        counts.sort()
        val k = min(3, counts.size)
        return counts[counts.size - k]
    }
}
