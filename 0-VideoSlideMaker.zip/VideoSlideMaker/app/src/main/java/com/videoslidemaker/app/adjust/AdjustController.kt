package com.videoslidemaker.app.adjust

import com.videoslidemaker.app.align.AlignmentDecision
import com.videoslidemaker.app.align.AlignmentItem
import com.videoslidemaker.app.data.TimestampParser
import com.videoslidemaker.app.model.SentenceSlide
import com.videoslidemaker.app.model.UiState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlin.math.abs

/** Which preview rows are shown. */
enum class PreviewFilter { ALL, CHANGES, PROBLEMS }

/** Everything the "Adjust timestamps" screen remembers. The script itself lives in [UiState]; this is only the form. */
data class AdjustUi(
    val screenOpen: Boolean = false,
    /** null = the menu of the five options. */
    val mode: AdjustMode? = null,
    val undoAction: UndoAction = UndoAction.LAST_ADJUSTMENT,
    val method: SelectedMethod = SelectedMethod.SHIFT,
    val offsetText: String = "",
    val earlier: Boolean = false,
    val stretchText: String = "",
    val exactText: String = "",
    /** Lines the user ticked (the lines that will be changed). */
    val ticked: Set<Int> = emptySet(),
    val filter: PreviewFilter = PreviewFilter.ALL,
    val notice: String? = null,
    /** Bumped when the code (not the user's typing) changes a text field, so the field knows to take the new text. */
    val textVersion: Int = 0
)

/** What the screen shows, worked out from the live script every time, so it can never be out of date. */
class AdjustView(
    val lines: List<AdjustLine>,
    val proposals: List<Proposal>,
    /** The lines that count as ticked in this mode (everything, for all-or-nothing and undo modes). */
    val ticked: Set<Int>,
    val preview: Preview,
    /** All-or-nothing (the entire transcript moves, or nothing does). */
    val atomic: Boolean,
    /** A hint about what to type / do next, when the form is not complete. */
    val hint: String?,
    /** Why applying is not possible right now, if it is not. */
    val blocked: String?,
    val highConfidence: Set<Int>,
    val lastBatch: AdjustBatch?,
    val adjustedCount: Int
) {
    val canApply: Boolean get() = blocked == null && preview.willApplyCount > 0
}

/**
 * Orchestrates "Adjust timestamps". All decisions are made by the pure [TimestampAdjuster]; this class reads the live script,
 * writes the result back (always keeping the originals), keeps the log of adjustments, and keeps the analysis results in step.
 *
 * Nothing here applies anything without the preview having been computed from exactly the same inputs: every action
 * recomputes the preview from the current script first.
 */
class AdjustController(
    private val state: () -> UiState,
    private val update: ((UiState) -> UiState) -> Unit,
    private val persist: () -> Unit,
    /** Starts the analysis of the recording WITHOUT applying anything (the user previews first). */
    private val analyse: () -> Unit
) {
    private val _ui = MutableStateFlow(AdjustUi())
    val ui: StateFlow<AdjustUi> = _ui.asStateFlow()

    // ---------------------------------------------------------------------------------------------------------
    // The derived view
    // ---------------------------------------------------------------------------------------------------------

    fun view(): AdjustView = view(state(), _ui.value)

    private enum class LogKind { PUSH, DROP_LAST, CLEAR, NONE }

    companion object {
        fun toLines(slides: List<SentenceSlide>): List<AdjustLine> =
            slides.mapIndexed { i, s -> SlideTimes.toLine(i, s.text, s.timestampSec, s.originalTimestampSec) }

        private fun noProposal(lines: List<AdjustLine>): List<Proposal> = lines.map { Proposal(it.index, it.text, it.currentMs, null) }

        private fun parsePercent(text: String): Double? = text.replace(',', '.').toDoubleOrNull()?.takeIf { abs(it) <= 50.0 }

        /** `+1.430` / `-0.250`: a typed amount that carries its own sign. */
        fun signedText(ms: Long): String {
            val a = abs(ms)
            return (if (ms < 0) "-" else "+") + "${a / 1000}." + (a % 1000).toString().padStart(3, '0')
        }

        fun view(s: UiState, u: AdjustUi): AdjustView {
            val lines = toLines(s.slides)
            val items = s.alignment.items
            val log = s.adjustLog
            var hint: String? = null
            var atomic = false
            val proposals: List<Proposal>
            val ticked: Set<Int>
            when (u.mode) {
                null -> {
                    proposals = emptyList()
                    ticked = emptySet()
                }
                AdjustMode.ENTIRE_TRANSCRIPT -> {
                    atomic = true
                    val amount = u.offsetText.trim()
                    val stretch = u.stretchText.trim()
                    val offset = if (amount.isEmpty()) 0L else AdjustFormat.resolveOffset(amount, u.earlier)
                    val pct = if (stretch.isEmpty()) 0.0 else parsePercent(stretch)
                    proposals = when {
                        offset == null -> {
                            hint = "Type how far to move the transcript, in seconds. For example 1.43."
                            noProposal(lines)
                        }
                        pct == null -> {
                            hint = "The stretch must be a percentage such as 0.1 or -0.05."
                            noProposal(lines)
                        }
                        else -> TimestampAdjuster.entire(lines, offset, pct)
                    }
                    ticked = lines.indices.toSet()
                }
                AdjustMode.AUTO_SYNC, AdjustMode.DETECTED -> {
                    proposals = TimestampAdjuster.detected(lines, items)
                    ticked = u.ticked
                    if (items.isEmpty()) hint = "The recording has not been analysed yet."
                }
                AdjustMode.SELECTED -> {
                    ticked = u.ticked
                    if (u.method == SelectedMethod.SHIFT) {
                        val amount = u.offsetText.trim()
                        val offset = if (amount.isEmpty()) null else AdjustFormat.resolveOffset(amount, u.earlier)
                        proposals = if (offset == null) {
                            hint = if (amount.isEmpty()) "Tick the lines to move, then type how far." else "Type the amount in seconds, for example 1.43."
                            noProposal(lines)
                        } else {
                            TimestampAdjuster.selectedShift(lines, offset)
                        }
                    } else {
                        val target = (TimestampParser.parse(u.exactText.trim()) as? TimestampParser.Result.Ok)?.millis
                        proposals = when {
                            ticked.size != 1 -> {
                                hint = "Tick exactly one line to give it an exact time."
                                noProposal(lines)
                            }
                            target == null -> {
                                hint = "Type the new time, for example 00:01:25.430 or 1:25.43."
                                noProposal(lines)
                            }
                            else -> TimestampAdjuster.exact(lines, ticked.first(), target)
                        }
                    }
                }
                AdjustMode.UNDO -> when (u.undoAction) {
                    UndoAction.LAST_ADJUSTMENT -> {
                        proposals = TimestampAdjuster.undoLast(lines, log.lastOrNull())
                        ticked = proposals.filter { it.afterMs != null }.map { it.index }.toSet()
                        if (log.isEmpty()) hint = "There is no adjustment to undo."
                    }
                    UndoAction.RESTORE_ALL -> {
                        proposals = TimestampAdjuster.restoreOriginals(lines)
                        ticked = proposals.map { it.index }.toSet()
                        if (proposals.isEmpty()) hint = "No timestamp has been adjusted: every line still has the script's own time."
                    }
                    UndoAction.RESTORE_SELECTED -> {
                        proposals = TimestampAdjuster.restoreOriginals(lines)
                        val adjusted = proposals.map { it.index }.toSet()
                        ticked = u.ticked.filter { it in adjusted }.toSet()
                        hint = if (proposals.isEmpty()) "No timestamp has been adjusted: every line still has the script's own time."
                        else "Tick the lines to put back to their original time."
                    }
                }
            }
            val preview = TimestampAdjuster.preview(lines, proposals, ticked)
            var blocked: String? = null
            if (atomic) {
                blocked = hint ?: if (!preview.isClean) {
                    val min = TimestampAdjuster.minimumOffset(lines)
                    "Nothing was changed: ${preview.refusedCount} line(s) would break the timeline, and a whole-transcript move is all or nothing." +
                        (if (u.mode == AdjustMode.ENTIRE_TRANSCRIPT && lines.isNotEmpty()) " The earliest you can move it is ${AdjustFormat.difference(min)}." else "")
                } else null
            }
            return AdjustView(
                lines, proposals, ticked, preview, atomic, hint, blocked,
                TimestampAdjuster.highConfidence(proposals), log.lastOrNull(), lines.count { it.isAdjusted }
            )
        }
    }

    // ---------------------------------------------------------------------------------------------------------
    // Navigation and the form
    // ---------------------------------------------------------------------------------------------------------

    private fun mutate(f: (AdjustUi) -> AdjustUi) = _ui.update(f)

    fun open() = mutate { it.copy(screenOpen = true, mode = null, notice = null) }

    fun close() = mutate { it.copy(screenOpen = false, mode = null, notice = null) }

    /** NEW (2.14): another project was opened - the form (ticked lines, typed offsets, the open screen) belonged to the last one. */
    fun reset() = mutate { AdjustUi() }

    fun backToMenu() = mutate { it.copy(mode = null, notice = null, ticked = emptySet()) }

    /** Opens one of the five options with a fresh form. */
    fun chooseMode(mode: AdjustMode) {
        val log = state().adjustLog
        mutate {
            AdjustUi(
                screenOpen = true, mode = mode,
                undoAction = if (log.isNotEmpty()) UndoAction.LAST_ADJUSTMENT else UndoAction.RESTORE_ALL
            )
        }
        when (mode) {
            AdjustMode.DETECTED -> tickHighConfidence()
            AdjustMode.AUTO_SYNC -> if (state().alignment.items.isNotEmpty()) tickHighConfidence()
            else -> Unit
        }
    }

    fun setOffsetText(t: String) = mutate { it.copy(offsetText = t, notice = null) }
    fun setEarlier(e: Boolean) = mutate { it.copy(earlier = e, notice = null) }
    fun setStretchText(t: String) = mutate { it.copy(stretchText = t, notice = null) }
    fun setExactText(t: String) = mutate { it.copy(exactText = t, notice = null) }
    fun setMethod(m: SelectedMethod) = mutate { it.copy(method = m, notice = null) }
    fun setFilter(f: PreviewFilter) = mutate { it.copy(filter = f) }
    fun setUndoAction(a: UndoAction) = mutate { it.copy(undoAction = a, ticked = emptySet(), notice = null) }

    /** Moves the typed amount by [deltaMs] (the -1 s / -0.1 s / +0.1 s / +1 s buttons). The result carries its own sign. */
    fun nudge(deltaMs: Long) {
        val u = _ui.value
        val text = u.offsetText.trim()
        val now = if (text.isEmpty()) 0L else AdjustFormat.resolveOffset(text, u.earlier) ?: 0L
        mutate { it.copy(offsetText = signedText(now + deltaMs), textVersion = it.textVersion + 1, notice = null) }
    }

    fun toggleTick(index: Int) = mutate { it.copy(ticked = if (index in it.ticked) it.ticked - index else it.ticked + index, notice = null) }
    fun tickNone() = mutate { it.copy(ticked = emptySet()) }
    fun tickAll() = mutate { it.copy(ticked = state().slides.indices.toSet()) }

    /** Ticks every line the analysis was sure about. */
    fun tickHighConfidence() {
        val hc = view(state(), _ui.value.copy(mode = _ui.value.mode ?: AdjustMode.DETECTED)).highConfidence
        mutate { it.copy(ticked = hc) }
    }

    /** Ticks every line that has a new time that would change something (including those that need review). */
    fun tickApplicable() {
        val v = view()
        mutate { u -> u.copy(ticked = v.proposals.filter { it.unavailable == null && it.afterMs != null && it.afterMs != it.beforeMs }.map { it.index }.toSet()) }
    }

    /** The analysis (started from here) finished: pre-tick the lines it was sure about. */
    fun onAnalysisFinished() {
        val m = _ui.value.mode
        if (m == AdjustMode.AUTO_SYNC || m == AdjustMode.DETECTED) tickHighConfidence()
    }

    fun analyseNow() = analyse()

    // ---------------------------------------------------------------------------------------------------------
    // Applying
    // ---------------------------------------------------------------------------------------------------------

    private fun plural(n: Int, one: String, many: String) = if (n == 1) "1 $one" else "$n $many"

    private fun labelFor(v: AdjustView, u: AdjustUi, count: Int): String = when (u.mode) {
        AdjustMode.ENTIRE_TRANSCRIPT -> {
            val off = if (u.offsetText.isBlank()) 0L else AdjustFormat.resolveOffset(u.offsetText, u.earlier) ?: 0L
            "Moved the whole transcript by ${AdjustFormat.difference(off)}" + (if (u.stretchText.isNotBlank()) " (stretched ${u.stretchText.trim()}%)" else "")
        }
        AdjustMode.AUTO_SYNC -> "Synchronized with the recording (${plural(count, "line", "lines")})"
        AdjustMode.DETECTED -> "Applied detected corrections (${plural(count, "line", "lines")})"
        AdjustMode.SELECTED ->
            if (u.method == SelectedMethod.EXACT) "Set a line to an exact time"
            else "Moved ${plural(count, "selected line", "selected lines")} by ${AdjustFormat.difference(
                if (u.offsetText.isBlank()) 0L else AdjustFormat.resolveOffset(u.offsetText, u.earlier) ?: 0L
            )}"
        else -> "Adjusted timestamps"
    }

    private fun logKindFor(u: AdjustUi): LogKind = when {
        u.mode != AdjustMode.UNDO -> LogKind.PUSH
        u.undoAction == UndoAction.LAST_ADJUSTMENT -> LogKind.DROP_LAST
        u.undoAction == UndoAction.RESTORE_ALL -> LogKind.CLEAR
        else -> LogKind.NONE
    }

    /** Apply every ticked line the preview says is safe. */
    fun applyTicked() {
        val v = view()
        if (v.atomic && v.blocked != null) return
        commit(v, v.preview.willApply, "ticked")
    }

    /** Apply one line only (its own "Apply" button). */
    fun applyOne(index: Int) {
        val v = view()
        if (v.atomic) return
        val one = TimestampAdjuster.preview(v.lines, v.proposals, setOf(index))
        commit(v, one.willApply, "one")
    }

    /** "Apply all high-confidence corrections": the lines the analysis was sure about, whatever is ticked. */
    fun applyHighConfidence() {
        val v = view()
        val hc = TimestampAdjuster.preview(v.lines, v.proposals, v.highConfidence)
        commit(v, hc.willApply, "high")
    }

    private class Counts(var applied: Int = 0, var refused: Int = 0)

    /** The new state after applying [wanted]: the slides (originals preserved), the log, and the analysis results in step. */
    private fun changed(st: UiState, wanted: Map<Int, Long>, u: AdjustUi, v: AdjustView, counts: Counts): UiState {
        val res = TimestampAdjuster.apply(toLines(st.slides), wanted)
        counts.applied = res.applied.size
        counts.refused = res.refused.size
        var kind = logKindFor(u)
        if (kind == LogKind.CLEAR && res.refused.isNotEmpty()) kind = LogKind.NONE
        if (res.applied.isEmpty()) {
            // nothing to write; only "undo the last adjustment" still discards that (now useless) log entry
            return if (kind == LogKind.DROP_LAST) st.copy(adjustLog = AdjustLog.dropLast(st.adjustLog)) else st
        }
        val newSlides = st.slides.toMutableList()
        for (a in res.applied) {
            val sl = newSlides[a.index]
            val (ts, orig) = SlideTimes.writeBack(sl.timestampSec, sl.originalTimestampSec, res.lines[a.index])
            newSlides[a.index] = sl.copy(timestampSec = ts, originalTimestampSec = orig)
        }
        val now = System.currentTimeMillis()
        val newLog = when (kind) {
            LogKind.PUSH -> AdjustLog.push(st.adjustLog, AdjustBatch(now, labelFor(v, u, res.applied.size), now, res.applied))
            LogKind.DROP_LAST -> AdjustLog.dropLast(st.adjustLog)
            LogKind.CLEAR -> emptyList()
            LogKind.NONE -> st.adjustLog
        }
        return st.copy(slides = newSlides, adjustLog = newLog, alignment = st.alignment.copy(items = syncItems(st.alignment.items, newSlides)))
    }

    private fun commit(v: AdjustView, wanted: Map<Int, Long>, how: String) {
        val u = _ui.value
        val undoingLast = u.mode == AdjustMode.UNDO && u.undoAction == UndoAction.LAST_ADJUSTMENT && v.lastBatch != null
        if (wanted.isEmpty() && !undoingLast) {
            mutate { it.copy(notice = "Nothing to apply: no ticked line can be changed safely.") }
            return
        }
        val counts = Counts()
        update { st -> changed(st, wanted, u, v, counts) }
        val undoing = u.mode == AdjustMode.UNDO
        val base = if (counts.applied == 0) "Nothing was changed."
        else if (undoing) plural(counts.applied, "timestamp was", "timestamps were") + " put back."
        else plural(counts.applied, "timestamp was", "timestamps were") + " adjusted. The originals are kept, so you can undo this."
        val left = if (counts.refused > 0) {
            " " + plural(counts.refused, "line was", "lines were") + " left alone because " +
                (if (counts.refused == 1) "it" else "they") + " would overlap a neighbour."
        } else ""
        mutate { it.copy(notice = base + left, ticked = if (how == "one") it.ticked - wanted.keys else emptySet()) }
        if (counts.applied > 0 || undoing) persist()
    }

    /**
     * Keeps the analysis results in step with the script: each line's current time, and whether the detected time is what the
     * line now has. (A line put back to its original time is simply pending again.)
     */
    private fun syncItems(items: List<AlignmentItem>, slides: List<SentenceSlide>): List<AlignmentItem> =
        items.map { item ->
            val sl = slides.getOrNull(item.index)
            if (sl == null || sl.text != item.text) item
            else {
                val cur = SlideTimes.toMs(sl.timestampSec)
                // an adjustment is in place when the preserved original differs from the current time
                val adjusted = sl.originalTimestampSec?.let { SlideTimes.toMs(it) != cur } == true
                val decision = when {
                    adjusted && item.detectedMs != null && cur == item.detectedMs -> AlignmentDecision.APPLIED
                    adjusted -> AlignmentDecision.ADJUSTED                        // moved, but not to the detected time
                    item.decision == AlignmentDecision.APPLIED || item.decision == AlignmentDecision.ADJUSTED -> AlignmentDecision.PENDING
                    else -> item.decision                                         // put back: undecided again
                }
                item.copy(currentMs = cur, decision = decision)
            }
        }
}
