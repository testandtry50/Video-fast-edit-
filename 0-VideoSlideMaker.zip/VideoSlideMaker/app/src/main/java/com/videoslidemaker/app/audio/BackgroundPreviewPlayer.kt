package com.videoslidemaker.app.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.media.PlaybackParams
import com.videoslidemaker.app.export.AUDIO_CHANNELS
import com.videoslidemaker.app.export.AUDIO_SAMPLE_RATE
import com.videoslidemaker.app.export.PcmAudioFile
import com.videoslidemaker.app.model.ExportSettings
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File
import java.io.RandomAccessFile
import kotlin.math.max
import kotlin.math.min

/**
 * NEW: plays the Audio step's BACKGROUND music while the Preview plays, so it can be heard together with the photos.
 *
 * The Preview used to say "Background music is not played in this preview". Here the real background mix (the same
 * AudioMixRenderer the export uses: looping, fades, per-track volume, time ranges) is built a window at a time and
 * streamed into ONE AudioTrack. The next window is built while the current one plays, so there is no gap and nothing
 * large is ever held in memory - it works for any video length.
 *
 * Only the music is built here (no voice), so it is not lowered under the voice. The Audio step's "Hear the mix" is
 * still the way to hear the exact final mix.
 */
class BackgroundPreviewPlayer {

    @Volatile private var track: AudioTrack? = null

    /** The speed the phone really plays the music at (1 when it refuses to change it). Valid once [play] has primed. */
    @Volatile var appliedSpeed: Float = 1f
        private set

    /**
     * Streams the background music from [startSec] to the end of the video.
     *
     * [build] makes one window of music: (window start in video seconds, window length) -> PCM file, or null when
     * there is nothing to play. [primed] is completed with true as soon as the first window is built and queued in the
     * sound device (false if nothing can be played); the caller then starts its photo clock and completes [go] at that
     * very moment, which starts the sound - so music and pictures start together. Returns when finished or cancelled.
     */
    suspend fun play(
        startSec: Double,
        totalSec: Double,
        speed: Float,
        windowSec: Double,
        build: suspend (winStartSec: Double, winLenSec: Double) -> PcmAudioFile?,
        primed: CompletableDeferred<Boolean>,
        go: CompletableDeferred<Unit>
    ) {
        withContext(Dispatchers.IO) {
            val bytesPerFrame = AUDIO_CHANNELS * 2
            var audioTrack: AudioTrack? = null
            var next: Deferred<PcmAudioFile?>? = null
            var current: PcmAudioFile? = null
            try {
                var winStart = startSec.coerceAtLeast(0.0)
                val firstLen = min(windowSec, totalSec - winStart)
                if (firstLen <= 0.05) {
                    primed.complete(false)
                    return@withContext
                }
                val first = build(winStart, firstLen)
                if (first == null) {
                    primed.complete(false)
                    return@withContext
                }
                current = first

                val mask = if (AUDIO_CHANNELS == 1) AudioFormat.CHANNEL_OUT_MONO else AudioFormat.CHANNEL_OUT_STEREO
                val minBuffer = AudioTrack.getMinBufferSize(AUDIO_SAMPLE_RATE, mask, AudioFormat.ENCODING_PCM_16BIT)
                val bufferSize = max(minBuffer, AUDIO_SAMPLE_RATE * bytesPerFrame / 2)
                val t = AudioTrack.Builder()
                    .setAudioAttributes(
                        CallAudio.attributes(AudioAttributes.USAGE_MEDIA, AudioAttributes.CONTENT_TYPE_MUSIC)
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(AUDIO_SAMPLE_RATE)
                            .setChannelMask(mask)
                            .build()
                    )
                    .setBufferSizeInBytes(bufferSize)
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .build()
                audioTrack = t
                track = t

                appliedSpeed = 1f
                if (kotlin.math.abs(speed - 1f) > 0.01f) {
                    try {
                        t.playbackParams = PlaybackParams().setSpeed(speed).setPitch(1f)
                        appliedSpeed = speed
                    } catch (_: Exception) {
                        // this phone can't change the music's speed: it plays at normal speed (the caller says so)
                    }
                }

                val buf = ByteArray(bytesPerFrame * 4096)
                var offset = 0L
                // Prime: fill the (empty) device buffer BEFORE play(), which can never block, so the sound starts
                // the instant [go] arrives.
                RandomAccessFile(first.file, "r").use { raf ->
                    val primeBytes = min(bufferSize.toLong(), first.totalBytes)
                    while (offset < primeBytes) {
                        val n = raf.read(buf, 0, min(buf.size.toLong(), primeBytes - offset).toInt())
                        if (n <= 0) break
                        t.write(buf, 0, n)
                        offset += n
                    }
                }
                primed.complete(true)
                go.await()
                ensureActive()
                t.play()

                while (true) {
                    ensureActive()
                    val cur = current ?: break
                    val curSec = cur.totalBytes.toDouble() / bytesPerFrame / AUDIO_SAMPLE_RATE
                    val nextStart = winStart + curSec
                    val hasMore = nextStart < totalSec - 0.05
                    if (hasMore && next == null) {
                        val len = min(windowSec, totalSec - nextStart)
                        next = async { build(nextStart, len) }
                    }
                    RandomAccessFile(cur.file, "r").use { raf ->
                        raf.seek(offset)
                        while (offset < cur.totalBytes) {
                            ensureActive()
                            val n = raf.read(buf, 0, min(buf.size.toLong(), cur.totalBytes - offset).toInt())
                            if (n <= 0) break
                            t.write(buf, 0, n)
                            offset += n
                        }
                    }
                    runCatching { cur.file.delete() }
                    current = null
                    if (!hasMore) break
                    val built = next?.await()
                    next = null
                    if (built == null) break
                    current = built
                    winStart = nextStart
                    offset = 0L
                }
                // Everything is handed over; give what is still queued in the device a moment to be heard.
                val queuedSec = bufferSize.toDouble() / bytesPerFrame / AUDIO_SAMPLE_RATE
                delay((queuedSec / max(appliedSpeed, 0.25f) * 1000).toLong() + 300L)
            } finally {
                val toStop = audioTrack
                track = null
                if (toStop != null) {
                    runCatching { toStop.pause() }
                    runCatching { toStop.flush() }
                    runCatching { toStop.stop() }
                    runCatching { toStop.release() }
                }
                current?.let { runCatching { it.file.delete() } }
                if (!primed.isCompleted) primed.complete(false)
            }
        }
    }

    /** Silences the music at once (pause / seek / leave), without waiting for the playing coroutine to wind down. */
    fun silenceNow() {
        val t = track ?: return
        runCatching { t.pause() }
        runCatching { t.flush() }
    }

    companion object {
        /** Seconds of music built per step. Long enough to be efficient, short enough to start quickly. */
        const val WINDOW_SEC = 40.0

        /**
         * Builds [lengthSec] seconds of ONLY the background music, starting at [winStartSec] of the video, as 16-bit
         * PCM in a file inside [cacheDir]. Returns null when there is no background music to play.
         */
        suspend fun buildWindow(
            context: Context,
            settings: ExportSettings,
            winStartSec: Double,
            lengthSec: Double,
            videoTotalSec: Double,
            cacheDir: File
        ): PcmAudioFile? = withContext(Dispatchers.IO) {
            val background = settings.audio.activeBackground
            if (background.isEmpty() || lengthSec <= 0.0) return@withContext null
            val totalBytes = (lengthSec * AUDIO_SAMPLE_RATE).toLong().coerceAtLeast(1) * AUDIO_CHANNELS * 2
            val file = File(cacheDir, "bgprev_${System.nanoTime()}.pcm")
            try {
                RandomAccessFile(file, "rw").use { raf ->
                    raf.setLength(totalBytes)
                    val totalFrames = totalBytes / (AUDIO_CHANNELS * 2)
                    AudioMixRenderer.mixBackground(
                        context, raf, totalFrames, background, winStartSec, videoTotalSec,
                        settings.audio.smart, cacheDir, { ensureActive() }
                    )
                }
            } catch (t: Throwable) {
                runCatching { file.delete() }
                throw t
            }
            PcmAudioFile(AUDIO_SAMPLE_RATE, AUDIO_CHANNELS, file, totalBytes)
        }
    }
}
