package com.videoslidemaker.app.export

/** Why an export stopped, in terms a person can act on. */
enum class FailureKind { CANCELLED, STORAGE_FULL, FILE_TOO_LARGE, OUT_OF_MEMORY, CODEC, PERMISSION, SOURCE_MISSING, UNKNOWN }

object ExportFailures {

    /** Looks through the whole cause chain, because the useful error (ENOSPC, ...) is usually wrapped. */
    fun classify(error: Throwable): FailureKind {
        var t: Throwable? = error
        var depth = 0
        var kind = FailureKind.UNKNOWN
        while (t != null && depth < 8) {
            val name = t.javaClass.simpleName
            val msg = (t.message ?: "").lowercase()
            val k = when {
                name.contains("CancellationException") -> FailureKind.CANCELLED
                t is OutOfMemoryError -> FailureKind.OUT_OF_MEMORY
                msg.contains("enospc") || msg.contains("no space left") || msg.contains("disk quota") || msg.contains("edquot") ->
                    FailureKind.STORAGE_FULL
                msg.contains("efbig") || msg.contains("file too large") -> FailureKind.FILE_TOO_LARGE
                t is SecurityException || msg.contains("eacces") || msg.contains("permission denied") || msg.contains("eperm") ->
                    FailureKind.PERMISSION
                name.contains("CodecException") || msg.contains("mediacodec") || msg.contains("codec") -> FailureKind.CODEC
                t is java.io.FileNotFoundException -> FailureKind.SOURCE_MISSING
                else -> FailureKind.UNKNOWN
            }
            // the most specific wins: keep the first non-UNKNOWN, but a storage/cancel cause beats a vague wrapper
            if (k != FailureKind.UNKNOWN && (kind == FailureKind.UNKNOWN || k == FailureKind.STORAGE_FULL || k == FailureKind.CANCELLED)) kind = k
            t = t.cause
            depth++
        }
        return kind
    }

    fun message(kind: FailureKind, partial: Boolean): String {
        val saved = if (partial) " What was exported so far was saved and can be played." else ""
        return when (kind) {
            FailureKind.CANCELLED -> "The export was cancelled.$saved"
            FailureKind.STORAGE_FULL -> "The storage ran out of space.$saved Free some space and export again."
            FailureKind.FILE_TOO_LARGE -> "The storage can't hold a file this large.$saved Choose a different location or a lower quality."
            FailureKind.OUT_OF_MEMORY -> "The phone ran out of memory.$saved Close other apps, or choose a lower quality, and export again."
            FailureKind.CODEC -> "The phone's video encoder failed.$saved Try a lower quality or resolution."
            FailureKind.PERMISSION -> "The app isn't allowed to write there.$saved Check the storage permission and try again."
            FailureKind.SOURCE_MISSING -> "A picture or audio file used by the video can't be found any more.$saved Re-add it and export again."
            FailureKind.UNKNOWN -> "The export failed unexpectedly.$saved"
        }
    }
}
