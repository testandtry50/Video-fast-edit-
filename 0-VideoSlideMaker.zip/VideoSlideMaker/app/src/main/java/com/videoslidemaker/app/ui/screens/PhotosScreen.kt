package com.videoslidemaker.app.ui.screens

import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.PhotoLibrary

import com.videoslidemaker.app.ui.components.ImagePreviewDialog
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.videoslidemaker.app.data.ScriptParser
import com.videoslidemaker.app.data.TimestampParser
import com.videoslidemaker.app.model.AppStep
import com.videoslidemaker.app.model.PoolImage
import com.videoslidemaker.app.logoclean.CleanLog
import com.videoslidemaker.app.model.UiState
import com.videoslidemaker.app.ui.components.AlertBox
import com.videoslidemaker.app.ui.components.AlertStyle
import com.videoslidemaker.app.ui.components.FastScrollGutter
import com.videoslidemaker.app.ui.components.FastScrollMinItems
import com.videoslidemaker.app.ui.components.FastScroller
import com.videoslidemaker.app.ui.components.JumpBar
import com.videoslidemaker.app.ui.components.rememberSavedLazyListState
import com.videoslidemaker.app.ui.components.LogoCleanerDialog
import com.videoslidemaker.app.ui.components.PrimaryButton
import com.videoslidemaker.app.ui.components.ScreenTitle
import com.videoslidemaker.app.ui.components.SecondaryButton
import com.videoslidemaker.app.ui.components.StatChip
import com.videoslidemaker.app.ui.theme.Accent
import com.videoslidemaker.app.ui.theme.BorderColor
import com.videoslidemaker.app.ui.theme.CardBg
import com.videoslidemaker.app.ui.theme.Green
import com.videoslidemaker.app.ui.theme.Muted
import com.videoslidemaker.app.ui.theme.Red
import com.videoslidemaker.app.ui.theme.TextMain
import com.videoslidemaker.app.viewmodel.AppViewModel
import kotlinx.coroutines.launch

@Composable
fun PhotosScreen(state: UiState, viewModel: AppViewModel, onPickImages: () -> Unit, onPickFolder: () -> Unit) {
    val importing = state.importProgress != null

    // Drag-to-reorder state. currentImages always reflects the latest list even though the
    // drag gesture below is set up once per row (keyed by that row's stable id) — without
    // this, the gesture would keep using whatever index existed when the drag first started.
    val currentImages = rememberUpdatedState(state.images)
    var draggingId by remember { mutableStateOf<String?>(null) }
    var dragOffsetPx by remember { mutableStateOf(0f) }
    val density = LocalDensity.current
    // How far a row has to be dragged to swap with its neighbour: the row's real measured height
    // plus the gap between rows. Measured (not guessed) because rows get taller with larger text.
    var measuredRowPx by remember { mutableStateOf(0f) }
    val gapPx = with(density) { 8.dp.toPx() }
    val fallbackRowPx = with(density) { 104.dp.toPx() }

    // Logo, icon, subtitle & text cleaner (blur / remove them in one photo, a range, or all of them)
    var showCleaner by remember { mutableStateOf(false) }
    if (showCleaner) {
        val cleanUi by viewModel.logoClean.ui.collectAsState()
        LogoCleanerDialog(
            images = state.images,
            ui = cleanUi,
            controller = viewModel.logoClean,
            onDismiss = { showCleaner = false }
        )
    }

    // The WHOLE screen is one scrolling list (header, photos, then the buttons). Before, the header
    // and the buttons took a fixed share of the screen and the photo list only got what was left -
    // which on a normal phone was almost nothing once a few alerts were showing.
    // NEW: remembers where you were in the photo list when you leave this screen and come back.
    val listState = rememberSavedLazyListState(viewModel.scrollMemory, "photos_list", state.images.size)
    val listScope = rememberCoroutineScope()
    // Drag the handle on the right edge to jump through hundreds / thousands of photos at once.
    val scrollerOn = state.images.size >= FastScrollMinItems
    Box(Modifier.fillMaxSize()) {
    LazyColumn(
        Modifier.fillMaxSize(),
        state = listState,
        contentPadding = PaddingValues(
            start = 16.dp,
            top = 16.dp,
            end = if (scrollerOn) FastScrollGutter else 16.dp,
            bottom = 16.dp
        ),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item(key = "header") {
            Column(Modifier.fillMaxWidth()) {
                ScreenTitle(
                    "Add Your Photos",
                    if (state.scriptLoaded) "Add all the photos you'll need. You'll match them to sentences in the next step."
                    else "Add your photos, then tap the time on each one to set how long it shows."
                )

                UploadZone(
                    done = state.images.isNotEmpty(),
                    icon = Icons.Filled.PhotoLibrary,
                    title = "Tap to add photos",
                    hint = "A few hundred at once is fine — for thousands (or 10 GB+), use the folder button below",
                    onClick = { if (!importing) onPickImages() }
                )

                SecondaryButton(
                    "Add a whole folder + sub-folders (best for 100+ photos)",
                    modifier = Modifier.padding(top = 8.dp),
                    enabled = !importing,
                    icon = Icons.Filled.Folder,
                    onClick = onPickFolder
                )

                Row(Modifier.fillMaxWidth().padding(vertical = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    StatChip("${state.images.size}", "Photos", Modifier.weight(1f))
                    if (state.scriptLoaded) {
                        StatChip("${state.slides.size}", "Sentences", Modifier.weight(1f))
                    } else {
                        StatChip("Simple", "Mode", Modifier.weight(1f))
                    }
                    StatChip(ScriptParser.formatTime(state.totalDurationSec), "Total length", Modifier.weight(1f))
                }

                if (!state.scriptLoaded && state.images.isNotEmpty()) {
                    AlertBox(
                        "Tap the ⏱ time on any photo to change how long it shows — great for a long video.",
                        style = AlertStyle.INFO,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )
                }

                state.importNote?.let { note ->
                    AlertBox(note, style = AlertStyle.WARNING, modifier = Modifier.padding(bottom = 12.dp))
                }

                val unpersistedCount = state.images.count { !it.persistedAccess && it.originalUri == null }
                if (unpersistedCount > 0) {
                    AlertBox(
                        if (unpersistedCount == 1) "1 photo may stop working if you close the app before exporting — its source doesn't grant long-term access. Export soon, or remove and re-add it from your regular gallery."
                        else "$unpersistedCount photos may stop working if you close the app before exporting — their source doesn't grant long-term access. Export soon, or remove and re-add them — picking a whole folder (above) avoids this entirely.",
                        style = AlertStyle.WARNING,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )
                }

                if (state.images.isNotEmpty()) {
                    val cleanedCount = state.images.count { it.originalUri != null }
                    SecondaryButton(
                        "🧽 Remove or blur a logo, icon, subtitle or text",
                        modifier = Modifier.padding(bottom = 4.dp),
                        enabled = !importing,
                        onClick = { showCleaner = true }
                    )
                    if (cleanedCount > 0) {
                        Text(
                            "✔ $cleanedCount photo${if (cleanedCount == 1) "" else "s"} cleaned",
                            style = MaterialTheme.typography.labelMedium,
                            color = Green,
                            modifier = Modifier.padding(bottom = 8.dp)
                        )
                    }
                    SecondaryButton("Clear All Photos", modifier = Modifier.padding(bottom = 8.dp), onClick = viewModel::clearAllImages)
                    Text(
                        "Tap a photo to see it full size · drag ☰ to reorder, or use the arrows",
                        style = MaterialTheme.typography.labelMedium,
                        color = Muted
                    )
                }
            }
        }

        itemsIndexed(state.images, key = { _, image -> image.id }) { index, image ->
            val isDragging = draggingId == image.id
            PhotoRow(
                image = image,
                index = index,
                total = state.images.size,
                showTimeControl = !state.scriptLoaded,
                durationSec = image.durationOverrideSec ?: state.settings.defaultDurationSec.toDouble(),
                isDragging = isDragging,
                dragOffsetPx = if (isDragging) dragOffsetPx else 0f,
                onMeasured = { heightPx -> if (heightPx > 0) measuredRowPx = heightPx.toFloat() },
                onDragStart = { draggingId = image.id; dragOffsetPx = 0f },
                onDragEnd = { draggingId = null; dragOffsetPx = 0f },
                onDragBy = { deltaY ->
                    dragOffsetPx += deltaY
                    val slotPx = (if (measuredRowPx > 0f) measuredRowPx else fallbackRowPx) + gapPx
                    val list = currentImages.value
                    val currentIndex = list.indexOfFirst { it.id == image.id }
                    if (currentIndex >= 0) {
                        val moveSteps = (dragOffsetPx / slotPx).toInt()
                        if (moveSteps != 0) {
                            val targetIndex = (currentIndex + moveSteps).coerceIn(0, list.size - 1)
                            if (targetIndex != currentIndex) {
                                viewModel.moveImage(currentIndex, targetIndex)
                                dragOffsetPx -= moveSteps * slotPx
                            }
                        }
                    }
                },
                onMoveUp = { viewModel.moveImageUp(index) },
                onMoveDown = { viewModel.moveImageDown(index) },
                onDelete = { viewModel.deleteImage(image.id) },
                onDurationChange = { seconds -> viewModel.setPhotoDuration(image.id, seconds) }
            )
        }

        item(key = "footer") {
            Column(Modifier.fillMaxWidth()) {
                PrimaryButton(
                    if (state.scriptLoaded) "Next — Match Photos →" else "Next — Add Text →",
                    enabled = state.images.isNotEmpty(),
                    modifier = Modifier.padding(top = 8.dp),
                    onClick = { viewModel.goNextFromPhotos() }
                )
                SecondaryButton("← Back", onClick = { viewModel.goStep(AppStep.SCRIPT) })
            }
        }
    }
    if (scrollerOn) {
        val photoCount = state.images.size
        FastScroller(
            // +2 for the header and footer items around the photos.
            itemCount = photoCount + 2,
            firstVisibleIndex = listState.firstVisibleItemIndex,
            atEnd = !listState.canScrollForward,
            isScrolling = listState.isScrollInProgress,
            onJumpTo = { i -> listScope.launch { listState.scrollToItem(i) } },
            label = { i ->
                when {
                    i <= 0 -> "Top"
                    i > photoCount -> "Bottom"
                    else -> "Photo $i / $photoCount"
                }
            },
            modifier = Modifier.fillMaxSize()
        )
        // NEW: one-tap jump to the start, the middle or the end of the list.
        if (photoCount >= 3) {
            val lastItem = photoCount + 1
            val jumpTo: (Int) -> Unit = { i -> listScope.launch { listState.scrollToItem(i.coerceIn(0, lastItem)) } }
            JumpBar(
                onTop = { jumpTo(0) },
                onMiddle = { jumpTo(photoCount / 2 + 1) },
                onBottom = { jumpTo(lastItem) },
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 12.dp, end = FastScrollGutter)
            )
        }
    }
    }
}

@Composable
private fun PhotoRow(
    image: PoolImage,
    index: Int,
    total: Int,
    showTimeControl: Boolean,
    durationSec: Double,
    isDragging: Boolean,
    dragOffsetPx: Float,
    onMeasured: (Int) -> Unit,
    onDragStart: () -> Unit,
    onDragEnd: () -> Unit,
    onDragBy: (Float) -> Unit,
    onMoveUp: () -> Unit,
    onMoveDown: () -> Unit,
    onDelete: () -> Unit,
    onDurationChange: (Double) -> Unit
) {
    var showDialog by remember { mutableStateOf(false) }
    var showFullSize by remember { mutableStateOf(false) }
    val density = LocalDensity.current
    val offsetDp: Dp = with(density) { dragOffsetPx.toDp() }
    val shape = RoundedCornerShape(12.dp)
    val position = index + 1

    Row(
        Modifier
            .fillMaxWidth()
            .offset(y = offsetDp)
            .onSizeChanged { onMeasured(it.height) }
            .clip(shape)
            .background(CardBg)
            .border(if (isDragging) 2.dp else 1.dp, if (isDragging) Accent else BorderColor, shape)
            .padding(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Dedicated drag handle — a plain text glyph rather than an icon resource, so reordering
        // doesn't depend on guessing whether a specific icon name exists. Starting the gesture
        // here (not on the whole row) means it never competes with the list's own scroll
        // gesture or the row's other tap targets (time chip, delete). It is hidden from screen
        // readers (dragging isn't possible for them) - the Move up / Move down buttons next to it
        // do the same job and are fully labelled.
        Box(
            Modifier
                .size(width = 36.dp, height = 48.dp)
                .clearAndSetSemantics { }
                .pointerInput(image.id) {
                    detectDragGestures(
                        onDragStart = { onDragStart() },
                        onDragEnd = { onDragEnd() },
                        onDragCancel = { onDragEnd() }
                    ) { change, dragAmount ->
                        change.consume()
                        onDragBy(dragAmount.y)
                    }
                },
            contentAlignment = Alignment.Center
        ) {
            Text(
                "☰",
                color = if (isDragging) Accent else Muted,
                style = MaterialTheme.typography.titleMedium
            )
        }
        Column {
            IconButton(onClick = onMoveUp, enabled = index > 0, modifier = Modifier.size(40.dp)) {
                Icon(
                    Icons.Filled.KeyboardArrowUp,
                    contentDescription = "Move photo $position up",
                    tint = if (index > 0) TextMain else Muted.copy(alpha = 0.4f)
                )
            }
            IconButton(onClick = onMoveDown, enabled = index < total - 1, modifier = Modifier.size(40.dp)) {
                Icon(
                    Icons.Filled.KeyboardArrowDown,
                    contentDescription = "Move photo $position down",
                    tint = if (index < total - 1) TextMain else Muted.copy(alpha = 0.4f)
                )
            }
        }
        AsyncImage(
            model = image.uri,
            contentDescription = image.displayName,
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .size(56.dp)
                .clip(RoundedCornerShape(8.dp))
                .clickable(onClickLabel = "View photo $position full size", role = Role.Button) { showFullSize = true }
        )
        Column(Modifier.weight(1f).padding(horizontal = 10.dp)) {
            Text(
                "#$position ${image.displayName}",
                style = MaterialTheme.typography.bodyMedium,
                color = TextMain,
                fontWeight = FontWeight.Medium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            if (image.widthPx > 0) {
                Text("${image.widthPx}×${image.heightPx}", style = MaterialTheme.typography.bodySmall, color = Muted)
            }
            if (image.cleanMode != null) {
                Text(
                    // 2.9: "✔ logo removed · subtitle blurred" - everything that was cleaned in this photo
                    CleanLog.label(image.cleanLog).ifEmpty { image.cleanMode?.doneLabel ?: "" },
                    style = MaterialTheme.typography.labelSmall,
                    color = Green
                )
            }
            if (showTimeControl) {
                Row(
                    Modifier
                        .padding(top = 4.dp)
                        .heightIn(min = 40.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(Accent.copy(alpha = 0.15f))
                        .clickable(onClickLabel = "Change how long photo $position shows", role = Role.Button) { showDialog = true }
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("⏱ ${ScriptParser.formatTime(durationSec)}", style = MaterialTheme.typography.labelMedium, color = Accent)
                }
            }
        }
        IconButton(onClick = onDelete) {
            Icon(Icons.Filled.Close, contentDescription = "Delete photo $position", tint = Red)
        }
    }

    if (showFullSize) {
        ImagePreviewDialog(
            uri = image.uri,
            title = "#$position ${image.displayName}",
            onDismiss = { showFullSize = false }
        )
    }

    if (showDialog) {
        TimeEditDialog(
            initialSeconds = durationSec,
            onConfirm = { seconds -> onDurationChange(seconds); showDialog = false },
            onDismiss = { showDialog = false }
        )
    }
}

@Composable
private fun TimeEditDialog(initialSeconds: Double, onConfirm: (Double) -> Unit, onDismiss: () -> Unit) {
    var text by remember { mutableStateOf(ScriptParser.formatTime(initialSeconds)) }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("How long should this photo show?") },
        text = {
            Column {
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it; error = null },
                    placeholder = { Text("e.g. 0:03, 2:30 or 0:02.500", color = Muted) },
                    isError = error != null,
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                val errorText = error
                if (errorText != null) {
                    Text(
                        errorText,
                        color = Red,
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
                Text(
                    "Any style works: 0:03, 2:30, 1:05:00 or 0:02.500. For a long photo, try 3:00 for 3 minutes.",
                    style = MaterialTheme.typography.bodySmall,
                    color = Muted,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }
        },
        confirmButton = {
            TextButton(onClick = {
                when (val result = ScriptParser.parseTimeResult(text)) {
                    is TimestampParser.Result.Error -> error = result.message
                    is TimestampParser.Result.Ok ->
                        if (result.millis > 0) onConfirm(result.millis / 1000.0)
                        else error = "The time must be greater than 0."
                }
            }) { Text("Save") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
