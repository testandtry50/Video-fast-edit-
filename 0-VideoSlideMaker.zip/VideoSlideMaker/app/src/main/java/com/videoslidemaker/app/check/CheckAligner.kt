package com.videoslidemaker.app.check

/**
 * Lines the transcript's words up with the spoken words, like a diff.
 *
 *  1. Find word triples that occur exactly once on each side and keep the longest in-order chain of them (the anchors).
 *     Those pin the two texts together even across hours of speech, so the expensive part only runs between anchors.
 *  2. Between anchors, an edit-distance DP pairs words: equal words cost 0, similar words (a different spelling of the
 *     same sound, or a near miss) cost less than a full replacement, a transcript word with no spoken partner costs
 *     [GAP_T], a spoken word with no transcript partner costs 0.6 + 0.4 * confidence (doubtful words are cheaper to skip).
 *  3. A gap too big for the exact DP gets a band around the straight line; one too big even for the band is left unpaired
 *     (the segments in it end up UNCERTAIN) instead of risking the phone's memory.
 *
 * One instance per check: the word-pair cost cache is only valid for one set of word ids.
 */
internal class CheckAligner(
    private val t: List<Tok>,
    private val s: List<Tok>,
    private val maxCells: Long = MAX_CELLS,
    private val band: Int = BAND,
    private val maxBandCells: Long = MAX_BAND_CELLS
) {
    /** For each transcript word the index of its spoken partner, or -1. */
    val pairT = IntArray(t.size) { -1 }

    /** For each spoken word the index of its transcript partner, or -1. */
    val pairS = IntArray(s.size) { -1 }

    private val subCache = HashMap<Long, Double>()

    private fun gapS(x: Tok): Double = 0.6 + 0.4 * x.conf

    private fun lev(a: IntArray, b: IntArray): Int {
        var prev = IntArray(b.size + 1) { it }
        for (i in 1..a.size) {
            val cur = IntArray(b.size + 1)
            cur[0] = i
            for (j in 1..b.size) {
                cur[j] = minOf(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (if (a[i - 1] != b[j - 1]) 1 else 0))
            }
            prev = cur
        }
        return prev[b.size]
    }

    private fun subCost(x: Tok, y: Tok): Double {
        if (x.nid == y.nid) return 0.0
        val key = (x.nid.toLong() shl 32) or (y.nid.toLong() and 0xFFFFFFFFL)
        val cached = subCache[key]
        if (cached != null) return cached
        val m = maxOf(x.len, y.len)
        val sim = if (Math.abs(x.len - y.len) > m * 0.5) 0.0 else maxOf(0.0, 1.0 - lev(x.cps, y.cps).toDouble() / m)
        val v = if (sim >= 0.5) 1.0 - 0.6 * ((sim - 0.5) / 0.5) else 1.0
        subCache[key] = v
        return v
    }

    private data class Tri(val a: Int, val b: Int, val c: Int)

    /** Word triples that occur exactly once on each side; the longest in-order chain of them, as word pairs. */
    private fun findAnchors(n: Int = 3): List<IntArray> {
        if (t.size < n || s.size < n) return emptyList()

        fun grams(x: List<Tok>): HashMap<Tri, IntArray> {          // triple -> [first position, how many times]
            val d = HashMap<Tri, IntArray>()
            for (i in 0..x.size - n) {
                val key = Tri(x[i].nid, x[i + 1].nid, x[i + 2].nid)
                val e = d[key]
                if (e == null) d[key] = intArrayOf(i, 1) else e[1]++
            }
            return d
        }

        val gt = grams(t)
        val gs = grams(s)
        val cand = ArrayList<IntArray>()                            // [position in transcript, position in speech]
        for ((k, v) in gt) {
            if (v[1] != 1) continue
            val w = gs[k] ?: continue
            if (w[1] == 1) cand.add(intArrayOf(v[0], w[0]))
        }
        if (cand.isEmpty()) return emptyList()
        cand.sortBy { it[0] }

        // longest strictly increasing subsequence of the speech positions (patience sorting)
        val tails = IntArray(cand.size)
        val tailIdx = IntArray(cand.size)
        val prev = IntArray(cand.size) { -1 }
        var len = 0
        for (ci in cand.indices) {
            val sj = cand[ci][1]
            var lo = 0
            var hi = len
            while (lo < hi) {
                val mid = (lo + hi) ushr 1
                if (tails[mid] < sj) lo = mid + 1 else hi = mid
            }
            if (lo == len) {
                tails[len] = sj
                tailIdx[len] = ci
                len++
            } else {
                tails[lo] = sj
                tailIdx[lo] = ci
            }
            prev[ci] = if (lo > 0) tailIdx[lo - 1] else -1
        }
        val chain = ArrayList<IntArray>()
        var ci = tailIdx[len - 1]
        while (ci >= 0) {
            chain.add(cand[ci])
            ci = prev[ci]
        }
        chain.reverse()

        val out = ArrayList<IntArray>()
        var lastT = -1
        var lastS = -1
        for (c in chain) {
            for (k in 0 until n) {
                if (c[0] + k > lastT && c[1] + k > lastS) {
                    out.add(intArrayOf(c[0] + k, c[1] + k))
                    lastT = c[0] + k
                    lastS = c[1] + k
                }
            }
        }
        return out
    }

    private fun dpGap(ia: Int, ib: Int, ja: Int, jb: Int) {
        val n = ib - ia
        val m = jb - ja
        if (n == 0 || m == 0) return
        val full = n.toLong() * m <= maxCells
        if (!full && n.toLong() * (2L * band + 1) > maxBandCells) return   // hopelessly big: leave it unpaired

        fun loOf(i: Int): Int = if (full) 0 else maxOf(0, Math.rint(i.toDouble() * m / n).toInt() - band)
        fun hiOf(i: Int): Int = if (full) m else minOf(m, Math.rint(i.toDouble() * m / n).toInt() + band)

        val inf = Double.POSITIVE_INFINITY
        var lo = loOf(0)
        var hi = hiOf(0)
        var prev = DoubleArray(hi - lo + 1)
        var acc = 0.0
        for (j in 1..hi) {
            acc += gapS(s[ja + j - 1])
            prev[j] = acc
        }
        val arrowLo = IntArray(n + 1)
        val arrows = arrayOfNulls<ByteArray>(n + 1)       // 0 = pair the two words, 1 = transcript word unmatched, 2 = spoken word unmatched
        arrowLo[0] = lo
        arrows[0] = ByteArray(hi - lo + 1) { 2 }
        var pLo = lo
        for (i in 1..n) {
            lo = loOf(i)
            hi = hiOf(i)
            val cur = DoubleArray(hi - lo + 1) { inf }
            val b = ByteArray(hi - lo + 1)
            val tw = t[ia + i - 1]
            val pHi = pLo + prev.size - 1
            for (j in lo..hi) {
                var best = inf
                var arrow = 0
                if (j >= 1 && j - 1 >= pLo && j - 1 <= pHi) {
                    best = prev[j - 1 - pLo] + subCost(tw, s[ja + j - 1])
                }
                if (j >= pLo && j <= pHi) {
                    val c = prev[j - pLo] + GAP_T
                    if (c < best) {
                        best = c
                        arrow = 1
                    }
                }
                if (j - 1 >= lo) {
                    val c = cur[j - 1 - lo] + gapS(s[ja + j - 1])
                    if (c < best) {
                        best = c
                        arrow = 2
                    }
                }
                cur[j - lo] = best
                b[j - lo] = arrow.toByte()
            }
            arrowLo[i] = lo
            arrows[i] = b
            pLo = lo
            prev = cur
        }
        if (m < pLo || m > pLo + prev.size - 1 || prev[m - pLo] == inf) return   // the band never reached the corner

        var i = n
        var j = m
        while (i > 0 || j > 0) {
            val a: Int
            if (i == 0) {
                a = 2
            } else {
                val idx = j - arrowLo[i]
                val row = arrows[i]!!
                if (idx < 0 || idx >= row.size) return                            // cannot happen; never loop or crash if it does
                a = row[idx].toInt()
            }
            when (a) {
                0 -> {
                    pairT[ia + i - 1] = ja + j - 1
                    pairS[ja + j - 1] = ia + i - 1
                    i--
                    j--
                }
                1 -> i--
                else -> j--
            }
        }
    }

    init {
        val anchors = findAnchors()
        for (a in anchors) {
            pairT[a[0]] = a[1]
            pairS[a[1]] = a[0]
        }
        var pt = 0
        var ps = 0
        for (a in anchors + listOf(intArrayOf(t.size, s.size))) {
            dpGap(pt, a[0], ps, a[1])
            pt = a[0] + 1
            ps = a[1] + 1
        }
    }

    companion object {
        /** A gap between anchors up to this many cells gets the exact DP. */
        const val MAX_CELLS = 6_000_000L

        /** Bigger gaps: only cells this close to the straight line are considered. */
        const val BAND = 500

        /** A gap even the band cannot cover in this much memory (about 60 MB) stays unpaired. */
        const val MAX_BAND_CELLS = 60_000_000L

        /** A transcript word with no spoken partner. */
        const val GAP_T = 1.0
    }
}
