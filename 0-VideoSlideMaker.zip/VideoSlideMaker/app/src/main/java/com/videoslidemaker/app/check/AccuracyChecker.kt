package com.videoslidemaker.app.check

/**
 * The audio is the source of truth. For every transcript segment this decides:
 *
 *  - does the spoken audio match the transcript?        -> MATCH / TEXT MISMATCH
 *  - are words missing from the transcript?             -> MISSING WORD (spoken, but not in the transcript)
 *  - are extra words in the transcript?                 -> EXTRA WORD   (in the transcript, but not spoken)
 *  - is the timestamp right?                            -> TIMESTAMP ERROR (+ actual start, difference, corrected time)
 *  - is the segment uncertain?                          -> UNCERTAIN    (the recognizer is not sure enough to accuse)
 *
 * and for every problem, WHERE in the audio it happens, so the screen can jump to it.
 *
 * A segment gets ONE status; when several things are wrong the most serious wins (text before timestamp), but the
 * timestamp check and every issue stay on the result, so nothing is hidden. Port of check() in
 * tools/accuracy-reference/checker.py.
 */
object AccuracyChecker {

    /** Fewer words than this share paired up -> the segment is not really in the audio. */
    private const val LOCATED_FRACTION = 0.34

    /** Spoken words next to the transcript's first / last word that still count (an intro or outro remark). */
    private const val EDGE_WORDS = 3
    private const val EDGE_GAP_MS = 1500L

    /** The start of a segment is read from one of its first words. */
    private const val SEGMENT_START_WORDS = 3

    /** A pause this long inside one unscripted passage lets it be shared between two segments. */
    private const val SPLIT_GAP_MS = 700L

    private val ISSUE_ORDER = listOf(CheckStatus.TEXT_MISMATCH, CheckStatus.MISSING_WORD, CheckStatus.EXTRA_WORD)

    const val NUMBER_NOTE = "Next to a number, which can be spoken several ways, so this is not counted as an error."
    private const val STUTTER_NOTE = "The speaker repeated a word here (a stutter), so this is not counted as an error."
    private const val UNSURE_WORD_NOTE = "The recognizer was not sure about this word."
    private const val UNSURE_WHAT_NOTE = "The recognizer was not sure what was said here."
    private const val ROOM_NOTE = "There is room for the word in the audio, so the recognizer may just have missed it."
    private const val EDGE_NOTE = "This is at the very edge of the recording."

    /** Roughly how long the word takes to say. */
    private fun wordMs(w: Tok): Long = 80L + 45L * w.len

    /** ... and the least room that must exist for it. */
    private fun neededMs(w: Tok): Double = 0.5 * wordMs(w)

    /** Is a number inside X[lo, hi) or right next to it? (Units like "dollars", "percent", "point five" hang off numbers.) */
    private fun touchesNumber(x: List<Tok>, lo: Int, hi: Int): Boolean {
        for (k in lo - 1..hi) if (k >= 0 && k < x.size && x[k].numeric) return true
        return false
    }

    fun check(
        segments: List<CheckSegment>,
        spoken: List<SpokenWord>,
        settings: CheckSettings = CheckSettings()
    ): CheckResult = check(segments, spoken, settings, CheckAligner.MAX_CELLS, CheckAligner.BAND, CheckAligner.MAX_BAND_CELLS)

    /** Same, with the aligner's size limits given (the tests shrink them to exercise the banded and the give-up paths). */
    internal fun check(
        segments: List<CheckSegment>,
        spoken: List<SpokenWord>,
        settings: CheckSettings,
        maxCells: Long,
        band: Int,
        maxBandCells: Long
    ): CheckResult {
        val tau = settings.minWordConfidence
        val (tokens, ranges) = CheckTokenizer.tokenizeTranscript(segments, settings)
        val heard = CheckTokenizer.tokenizeSpoken(spoken, settings)
        val intern = HashMap<String, Int>()
        for (x in tokens) x.nid = intern.getOrPut(x.norm) { intern.size }
        for (x in heard) x.nid = intern.getOrPut(x.norm) { intern.size }
        val aligner = CheckAligner(tokens, heard, maxCells, band, maxBandCells)
        val pairT = aligner.pairT
        val pairS = aligner.pairS
        val T = tokens
        val S = heard

        val whole = segments.size >= 3 && segments.count { it.timestampMs % 1000L == 0L } >= 0.9 * segments.size
        val tolerance = if (whole) maxOf(settings.timestampToleranceMs, 1000L) else settings.timestampToleranceMs

        // --- spoken words nobody claimed ("missing from the transcript"), each handed to one segment
        val insBySeg = HashMap<Int, MutableList<Int>>()
        fun give(seg: Int, x: Int) {
            insBySeg.getOrPut(seg) { ArrayList() }.add(x)
        }
        val m = S.size
        var j = 0
        while (j < m) {
            if (pairS[j] >= 0) {
                j++
                continue
            }
            val r0 = j
            while (j < m && pairS[j] < 0) j++
            val r1 = j
            val left = if (r0 > 0) r0 - 1 else -1
            val right = if (r1 < m) r1 else -1
            if (left < 0 && right < 0) continue                 // nothing aligned at all
            if (left < 0) {
                // speech before the transcript starts: only the words right next to it count
                val kept = ArrayList<Int>()
                var nxt = S[right].start
                var x = r1 - 1
                while (x >= r0) {
                    if (kept.size >= EDGE_WORDS || nxt - S[x].end > EDGE_GAP_MS) break
                    kept.add(x)
                    nxt = S[x].start
                    x--
                }
                for (w in kept) give(T[pairS[right]].seg, w)
            } else if (right < 0) {
                // speech after it ends
                val kept = ArrayList<Int>()
                var prv = S[left].end
                for (x in r0 until r1) {
                    if (kept.size >= EDGE_WORDS || S[x].start - prv > EDGE_GAP_MS) break
                    kept.add(x)
                    prv = S[x].end
                }
                for (w in kept) give(T[pairS[left]].seg, w)
            } else {
                val a = T[pairS[left]].seg
                val b = T[pairS[right]].seg
                var cut = r1
                var firstSeg = a
                var secondSeg = a
                if (a != b) {
                    // One unscripted passage stays in one piece (the nearer segment gets it). Only a real pause inside it
                    // (it is two separate remarks) lets the part before the pause go to the earlier segment.
                    var splitAt = -1
                    var widest = SPLIT_GAP_MS - 1
                    for (x in r0 + 1 until r1) {
                        val g = S[x].start - S[x - 1].end
                        if (g > widest) {
                            widest = g
                            splitAt = x
                        }
                    }
                    if (splitAt >= 0) {
                        cut = splitAt
                        firstSeg = a
                        secondSeg = b
                    } else {
                        val nearer = if (S[right].start - S[r1 - 1].end < S[r0].start - S[left].end) b else a
                        cut = r1
                        firstSeg = nearer
                        secondSeg = nearer
                    }
                }
                for (x in r0 until r1) give(if (x < cut) firstSeg else secondSeg, x)
            }
        }

        // neighbours (in the audio) of an unpaired transcript word
        val prevPaired = IntArray(T.size)
        var last = -1
        for (i in T.indices) {
            prevPaired[i] = last
            if (pairT[i] >= 0) last = pairT[i]
        }
        val nextPaired = IntArray(T.size)
        var nxtP = -1
        for (i in T.indices.reversed()) {
            nextPaired[i] = nxtP
            if (pairT[i] >= 0) nxtP = pairT[i]
        }

        val results = ArrayList<SegmentResult>()
        var totalWords = 0
        var matchedWords = 0
        for ((k, seg) in segments.withIndex()) {
            val t0 = ranges[k][0]
            val t1 = ranges[k][1]
            val words = (t0 until t1).map { T[it].disp }
            val nTok = t1 - t0
            if (nTok == 0) {
                results.add(
                    SegmentResult(
                        k, seg.timestampMs, seg.text, words, CheckStatus.UNCERTAIN, emptyList(), null, "", null, null, 0,
                        "This line has no words to check."
                    )
                )
                continue
            }
            var issues = ArrayList<WordIssue>()
            var paired = 0
            for (i in t0 until t1) if (pairT[i] >= 0) paired++
            val located = paired.toDouble() / nTok >= LOCATED_FRACTION
            var segMatched = 0

            var i = t0
            while (i < t1) {
                if (pairT[i] >= 0) {
                    if (S[pairT[i]].nid == T[i].nid) {
                        segMatched++
                        i++
                        continue
                    }
                    // a run of replaced words
                    val j0 = i
                    while (i < t1 && pairT[i] >= 0 && S[pairT[i]].nid != T[i].nid) i++
                    val sp = (j0 until i).map { S[pairT[it]] }
                    val numeric = (j0 until i).any { T[it].numeric || S[pairT[it]].numeric } ||
                        touchesNumber(T, j0, i) || touchesNumber(S, pairT[j0], pairT[i - 1] + 1)
                    val meanConf = sp.sumOf { it.conf } / sp.size
                    val firm = meanConf >= tau && !numeric
                    val note = if (numeric) NUMBER_NOTE else if (!firm) UNSURE_WHAT_NOTE else ""
                    issues.add(
                        WordIssue(
                            CheckStatus.TEXT_MISMATCH, firm,
                            (j0 until i).joinToString(" ") { T[it].disp }, sp.joinToString(" ") { it.disp },
                            sp.first().start, sp.last().end, T[j0].widx, T[i - 1].widx + 1, note
                        )
                    )
                } else {
                    val j0 = i
                    while (i < t1 && pairT[i] < 0) i++
                    val left = prevPaired[j0]
                    val right = nextPaired[i - 1]
                    val loMs: Long? = if (left >= 0) S[left].end else null
                    val hiMs: Long? = if (right >= 0) S[right].start else null
                    val need = (j0 until i).sumOf { neededMs(T[it]) }
                    val numeric = touchesNumber(T, j0, i)
                    val firm = !numeric && loMs != null && hiMs != null && (hiMs - loMs) < need
                    val note = when {
                        firm -> ""
                        numeric -> NUMBER_NOTE
                        loMs != null && hiMs != null -> ROOM_NOTE
                        else -> EDGE_NOTE
                    }
                    issues.add(
                        WordIssue(
                            CheckStatus.EXTRA_WORD, firm, (j0 until i).joinToString(" ") { T[it].disp }, "",
                            loMs ?: hiMs, hiMs ?: loMs, T[j0].widx, T[i - 1].widx + 1, note
                        )
                    )
                }
            }

            // spoken words that the transcript does not have
            val ins = (insBySeg[k] ?: emptyList<Int>()).sorted()
            var g = 0
            while (g < ins.size) {
                var h = g
                while (h + 1 < ins.size && ins[h + 1] == ins[h] + 1) h++
                val run = (g..h).map { S[ins[it]] }
                val meanConf = run.sumOf { it.conf } / run.size
                val numeric = touchesNumber(S, ins[g], ins[h] + 1)
                val first = ins[g]
                val stutter = run.size == 1 &&
                    ((first > 0 && S[first - 1].nid == S[first].nid) || (first + 1 < S.size && S[first + 1].nid == S[first].nid))
                val firm = meanConf >= tau && !numeric && !stutter
                // which transcript position it sits at: just after the last paired word of this segment before it
                var pos = 0
                for (x in t0 until t1) if (pairT[x] >= 0 && pairT[x] < first) pos = T[x].widx + 1
                val note = when {
                    firm -> ""
                    numeric -> NUMBER_NOTE
                    stutter -> STUTTER_NOTE
                    else -> UNSURE_WORD_NOTE
                }
                issues.add(
                    WordIssue(
                        CheckStatus.MISSING_WORD, firm, "", run.joinToString(" ") { it.disp },
                        run.first().start, run.last().end, pos, pos, note
                    )
                )
                g = h + 1
            }
            issues = ArrayList(issues.sortedWith(compareBy<WordIssue>({ it.tFrom }, { ISSUE_ORDER.indexOf(it.kind) })))

            // --- where does the segment really start?
            val claimed = ArrayList<Int>()
            for (x in t0 until t1) if (pairT[x] >= 0) claimed.add(pairT[x])
            insBySeg[k]?.let { claimed.addAll(it) }
            var actualStart: Long? = null
            var actualEnd: Long? = null
            if (claimed.isNotEmpty()) {
                actualStart = claimed.minOf { S[it].start }
                actualEnd = claimed.maxOf { S[it].end }
            }
            var anchorMs: Long? = null
            var skippedMs = 0L          // time taken by spoken words before the anchor that could not serve as one themselves
            for (x in t0 until minOf(t1, t0 + SEGMENT_START_WORDS)) {
                if (pairT[x] >= 0) {
                    val sw = S[pairT[x]]
                    val same = sw.nid == T[x].nid
                    if (sw.conf >= (if (same) 0.4 else tau) && (same || !T[x].numeric)) {
                        anchorMs = maxOf(0L, sw.start - skippedMs)
                        break
                    }
                    skippedMs += wordMs(T[x])
                }
            }
            val tsCheck: TimestampCheck? =
                if (located) TimestampCheck(seg.timestampMs, anchorMs, tolerance, anchorMs != null) else null

            val spokenText = claimed.toSortedSet().joinToString(" ") { S[it].disp }
            totalWords += nTok
            matchedWords += segMatched

            // --- the status
            var reason = ""
            val status: CheckStatus
            if (!located) {
                // Hardly any of this line was found. Only "the audio has no room for these words at all" still counts as
                // firm; everything else may just be the recognizer missing a passage, so it is only a doubt.
                issues = ArrayList(issues.map { it.copy(firm = it.firm && it.kind == CheckStatus.EXTRA_WORD) })
                if (issues.any { it.firm }) {
                    status = CheckStatus.EXTRA_WORD
                } else {
                    status = CheckStatus.UNCERTAIN
                    reason = "This line could not be found in the audio."
                }
            } else {
                val firmIssues = issues.filter { it.firm }
                if (firmIssues.isNotEmpty()) {
                    status = ISSUE_ORDER.first { kind -> firmIssues.any { it.kind == kind } }
                } else if (tsCheck != null && tsCheck.isError) {
                    status = CheckStatus.TIMESTAMP_ERROR
                } else if (issues.isNotEmpty() || (tsCheck != null && !tsCheck.verifiable)) {
                    status = CheckStatus.UNCERTAIN
                    reason = if (issues.isNotEmpty()) {
                        issues.firstOrNull { it.note.isNotEmpty() }?.note ?: "The recognizer was not sure enough about some words."
                    } else {
                        "The start of this line could not be located exactly."
                    }
                } else {
                    status = CheckStatus.MATCH
                }
            }
            results.add(
                SegmentResult(
                    k, seg.timestampMs, seg.text, words, status, issues, tsCheck, spokenText,
                    actualStart, actualEnd, segMatched, reason
                )
            )
        }
        return CheckResult(results, totalWords, matchedWords, whole)
    }
}
