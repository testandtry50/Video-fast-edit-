package com.videoslidemaker.app

import android.widget.Toast

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.windowInsetsBottomHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.layout.windowInsetsTopHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import com.videoslidemaker.app.model.AppStep
import com.videoslidemaker.app.data.queryDisplayName
import com.videoslidemaker.app.ui.components.AppTopBar
import com.videoslidemaker.app.ui.components.ImportProgressCard
import com.videoslidemaker.app.ui.components.StepTabsBar
import com.videoslidemaker.app.ui.screens.AppearanceScreen
import com.videoslidemaker.app.ui.screens.ExportScreen
import com.videoslidemaker.app.ui.screens.MatchScreen
import com.videoslidemaker.app.ui.screens.PhotosScreen
import com.videoslidemaker.app.ui.screens.PreviewScreen
import com.videoslidemaker.app.ui.screens.AlignmentReviewScreen
import com.videoslidemaker.app.ui.screens.ScriptScreen
import com.videoslidemaker.app.ui.screens.TextOverlayScreen
import com.videoslidemaker.app.ui.theme.AppearancePrefs
import com.videoslidemaker.app.ui.theme.Bg
import com.videoslidemaker.app.ui.theme.IsDark
import com.videoslidemaker.app.ui.theme.NavPosition
import com.videoslidemaker.app.ui.theme.Surface as TopBarColor
import com.videoslidemaker.app.ui.theme.ThemeMode
import com.videoslidemaker.app.ui.theme.VideoSlideMakerTheme
import com.videoslidemaker.app.viewmodel.AppViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Google Play now needs apps to target Android 16, which always draws apps edge to edge (behind the status and
        // navigation bars). Asking for it on every Android version keeps one look everywhere; AppRoot keeps the
        // content clear of the bars.
        enableEdgeToEdge()
        val appearance = (application as VideoSlideMakerApp).appearance
        setContent {
            val prefs by appearance.state.collectAsState()
            VideoSlideMakerTheme(prefs) {
                Surface(color = MaterialTheme.colorScheme.background) {
                    AppRoot(appearance = prefs, onAppearanceChange = appearance::update)
                }
            }
        }
    }
}

/** The step the on-screen "Back" button of [step] goes to - system Back follows the same path. */
private fun previousStep(step: AppStep, scriptLoaded: Boolean): AppStep = when (step) {
    AppStep.SCRIPT -> AppStep.SCRIPT
    AppStep.PHOTOS -> AppStep.SCRIPT
    AppStep.MATCH -> AppStep.PHOTOS
    AppStep.TEXT -> if (scriptLoaded) AppStep.MATCH else AppStep.PHOTOS
    AppStep.PREVIEW -> AppStep.TEXT
    AppStep.EXPORT -> AppStep.PREVIEW
}

@Composable
private fun AppRoot(
    appearance: AppearancePrefs,
    onAppearanceChange: ((AppearancePrefs) -> AppearancePrefs) -> Unit,
    viewModel: AppViewModel = viewModel()
) {
    val context = LocalContext.current
    val state by viewModel.ui.collectAsState()
    val undoUi by viewModel.undoUi.collectAsState()
    // Undo / Redo wait while something is running that is also changing the project.
    val historyBusy = state.importProgress != null || state.exportProgress.running ||
        state.alignment.running || state.alignment.reviewOpen
    var showAppearance by rememberSaveable { mutableStateOf(false) }
    val isDark = IsDark

    // System Back (button or swipe) walks back one step, exactly like the on-screen "Back"
    // buttons, instead of closing the app in the middle of your work. Declared first so that
    // screens which handle Back themselves (the settings page, the timestamp review) win.
    BackHandler(enabled = state.step != AppStep.SCRIPT) {
        viewModel.goStep(previousStep(state.step, state.scriptLoaded))
    }

    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { /* no-op: export still works without the permission, just without a visible notification */ }

    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) ==
                PackageManager.PERMISSION_GRANTED
            if (!granted) notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    val scriptPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val text = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
            if (text != null) viewModel.loadScript(text)
        }
    }

    val imagesPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) viewModel.addImages(uris)
    }

    // NEW: whole-folder import - see ImageStore.importFolder. The real fix for large photo
    // counts (100+), since it uses one persisted grant for the whole folder instead of one per
    // file - Android's per-file grant ceiling is well below what a movie's worth of frames needs.
    val imagesFolderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { treeUri ->
        if (treeUri != null) viewModel.addImagesFromTree(treeUri)
    }

    // NEW: the recording (audio or video) that timestamps are checked against.
    val recordingPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: SecurityException) {
                // Some providers don't support persistable grants; the Uri still works this session.
            }
            viewModel.setRecording(uri, queryDisplayName(context, uri))
        }
    }

    val musicPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: SecurityException) {
                // Some providers don't support persistable grants; the Uri still works this session.
            }
            val name = queryDisplayName(context, uri)
            viewModel.setMusicUri(uri, name)
        }
    }

    Box(Modifier.fillMaxSize().background(Bg)) {
        Column(
            Modifier
                .fillMaxSize()
                // Side cut-outs, the navigation bar and the keyboard push the content in (the status bar is the
                // coloured strip just below, so the top bar looks the way it always did).
                .windowInsetsPadding(WindowInsets.safeDrawing.only(WindowInsetsSides.Horizontal + WindowInsetsSides.Bottom))
                // While the settings page is open, hide everything underneath from screen readers.
                .then(if (showAppearance) Modifier.clearAndSetSemantics { } else Modifier)
        ) {
            Spacer(
                Modifier
                    .fillMaxWidth()
                    .background(TopBarColor)
                    .windowInsetsTopHeight(WindowInsets.statusBars)
            )
            AppTopBar(
                isDark = isDark,
                onToggleTheme = {
                    onAppearanceChange { it.copy(themeMode = if (isDark) ThemeMode.LIGHT else ThemeMode.DARK) }
                },
                onOpenAppearance = { showAppearance = true },
                canUndo = undoUi.canUndo && !historyBusy,
                canRedo = undoUi.canRedo && !historyBusy,
                undoLabel = undoUi.undoLabel,
                redoLabel = undoUi.redoLabel,
                onUndo = viewModel::undo,
                onRedo = viewModel::redo
            )
            // Text, Preview and Export need at least one photo. Instead of a tap that silently does nothing, those tabs
            // look dimmed and tapping one says why.
            val lockedSteps: Set<AppStep> = if (state.images.isEmpty()) {
                setOf(AppStep.TEXT, AppStep.PREVIEW, AppStep.EXPORT)
            } else {
                emptySet()
            }
            // The step bar sits on top (classic) or at the bottom, within thumb reach (Appearance > Layout). At the
            // bottom it steps aside while the keyboard is open, so typing keeps the whole screen.
            val stepsAtBottom = appearance.navigation == NavPosition.BOTTOM
            val keyboardOpen = WindowInsets.ime.getBottom(LocalDensity.current) > 0
            val stepBar: @Composable () -> Unit = {
                StepTabsBar(
                    currentStep = state.step,
                    disabledSteps = lockedSteps,
                    atBottom = stepsAtBottom,
                    onStepClick = { target ->
                        if (target in lockedSteps) {
                            Toast.makeText(context, "Add your photos first, then this step opens.", Toast.LENGTH_SHORT).show()
                        } else {
                            viewModel.goStep(target)
                        }
                    }
                )
            }
            if (!stepsAtBottom) stepBar()
            // Visible on every screen while a big photo import runs, so the app never looks frozen.
            state.importProgress?.let { progress ->
                ImportProgressCard(done = progress.done, total = progress.total, scanned = progress.scanned, onStop = viewModel::cancelImport)
            }
            Box(Modifier.weight(1f)) {
                when (state.step) {
                    AppStep.SCRIPT ->
                        if (state.alignment.reviewOpen) AlignmentReviewScreen(state, viewModel)
                        else ScriptScreen(
                            state, viewModel,
                            onPickScriptFile = { scriptPicker.launch(arrayOf("text/plain")) },
                            onPickRecording = { recordingPicker.launch(arrayOf("audio/*", "video/*")) }
                        )
                    AppStep.PHOTOS -> PhotosScreen(state, viewModel, onPickImages = { imagesPicker.launch(arrayOf("image/*")) }, onPickFolder = { imagesFolderPicker.launch(null) })
                    AppStep.MATCH -> MatchScreen(
                        state, viewModel,
                        onPickImages = { imagesPicker.launch(arrayOf("image/*")) },
                        onPickRecording = { recordingPicker.launch(arrayOf("audio/*", "video/*")) }
                    )
                    AppStep.TEXT -> TextOverlayScreen(state, viewModel)
                    AppStep.PREVIEW -> PreviewScreen(state, viewModel, onPickRecording = { recordingPicker.launch(arrayOf("audio/*", "video/*")) })
                    AppStep.EXPORT -> ExportScreen(state, viewModel, onPickMusic = { musicPicker.launch(arrayOf("audio/*")) })
                }
            }
            if (stepsAtBottom && !keyboardOpen) stepBar()
        }

        // With the step bar at the bottom, paint the strip behind the system navigation bar the same colour as the bar.
        if (appearance.navigation == NavPosition.BOTTOM && WindowInsets.ime.getBottom(LocalDensity.current) == 0) {
            Spacer(
                Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .windowInsetsBottomHeight(WindowInsets.navigationBars)
                    .background(TopBarColor)
            )
        }

        if (showAppearance) {
            AppearanceScreen(
                prefs = appearance,
                onChange = onAppearanceChange,
                onClose = { showAppearance = false }
            )
        }
    }
}
