package com.videoslidemaker.app.align

import com.videoslidemaker.app.data.TimestampParser

/** How sure the aligner is about one line, boiled down to what the user needs to decide. */
enum class AlignmentStatus {
    /** The timestamp already agrees with the audio (within [TimestampAligner.MATCH_TOLERANCE_MS]). */
    MATCHES,

    /** A correction was found and is trustworthy enough to apply automatically. */
    HIGH_CONFIDENCE,

    /** A time was found from the audio, but not sure enough. Nothing is changed unless the user explicitly applies it. */
    NEEDS_REVIEW,

    /**
     * No evidence for this line of its own: the time is inferred from the confident lines around it. A best guess, never
     * applied automatically.
     */
    ESTIMATED,

    /** Nothing found for this line (silence, speech that does not match, or no way to place it). Its timestamp is left alone. */
    CANNOT_ALIGN
}

/** What the detected time of a line is based on. */
enum class AlignmentEvidence {
    NONE,

    /** The audio's speech / pause structure only. */
    AUDIO,

    /** The audio AND the words the recognizer heard (the strongest). */
    AUDIO_AND_WORDS,

    /** The recognized words only (continuous speech, or no clear audio boundary). */
    WORDS,

    /** Inferred from neighbouring lines. */
    ESTIMATE
}

/** What the user (or auto-apply) did with a line. */
enum class AlignmentDecision {
    PENDING, KEPT_ORIGINAL, APPLIED,

    /** The user moved this line's timestamp by hand (Match screen), so it is neither the original nor the detected time. */
    ADJUSTED
}

/**
 * The result for ONE script line. All times are whole milliseconds on the recording's own clock,
 * which is the source of truth.
 *
 * @property originalMs  the timestamp from the user's script (before any correction).
 * @property currentMs   what the slide's timestamp is right now (== originalMs until a correction is applied).
 * @property detectedMs  when the audio says this line really starts, or null if no matching speech was found.
 * @property detectedEndMs when the spoken line ends, when it could be determined.
 * @property confidence  0..1: the estimated probability that [detectedMs] is within 250 ms of where the line really
 *                    starts. Fitted on simulated recordings with known ground truth and never above 0.99: nothing here can
 *                    be verified to 100%. [TimestampAligner.HIGH_CONFIDENCE] and above is "high".
 * @property precisionMs roughly how far off [detectedMs] can be (about 9 times in 10 it is closer than this).
 * @property evidence    what [detectedMs] is based on.
 * @property reason      for lines that are not trusted: the plain-language reason.
 */
data class AlignmentItem(
    val index: Int,
    val text: String,
    val originalMs: Long,
    val currentMs: Long,
    val detectedMs: Long?,
    val detectedEndMs: Long?,
    val confidence: Float,
    val status: AlignmentStatus,
    val reason: String?,
    val decision: AlignmentDecision = AlignmentDecision.PENDING,
    val precisionMs: Long? = null,
    val evidence: AlignmentEvidence = AlignmentEvidence.NONE
) {
    /** detected − original. Positive = the script timestamp was too early. */
    val diffMs: Long? get() = detectedMs?.let { it - originalMs }

    /** True when applying would actually move the timestamp. */
    val canApply: Boolean get() = detectedMs != null && detectedMs != currentMs
}

/**
 * A stretch of consecutive lines that could NOT be aligned with confidence, so the user knows where to look.
 * [startMs]/[endMs] are on the script's clock (original timestamps).
 */
data class AlignmentSection(
    val firstIndex: Int,
    val lastIndex: Int,
    val startMs: Long,
    val endMs: Long,
    /** The most serious status inside it: CANNOT_ALIGN, else NEEDS_REVIEW, else ESTIMATED. */
    val status: AlignmentStatus,
    val reason: String
) {
    val lineCount: Int get() = lastIndex - firstIndex + 1
}

/** One point of the drift curve: how far the script was off at [transcriptMs]. */
data class DriftPoint(val transcriptMs: Long, val shiftMs: Long)

data class AlignmentResult(
    val items: List<AlignmentItem>,
    /** Speech-vs-background level difference of the recording, in dB. Low = hard to analyse. */
    val clarityDb: Float,
    /** The drift detected across the recording (window by window), earliest first. */
    val drift: List<DriftPoint>,
    /** Stretches that could not be aligned confidently, in order. */
    val sections: List<AlignmentSection> = emptyList(),
    /** True when the recognized words were used as well as the audio. */
    val usedWords: Boolean = false
) {
    val estimatedCount: Int get() = items.count { it.status == AlignmentStatus.ESTIMATED }
    val cannotAlignCount: Int get() = items.count { it.status == AlignmentStatus.CANNOT_ALIGN }
    val highConfidenceCount: Int get() = items.count { it.status == AlignmentStatus.HIGH_CONFIDENCE }
    val needsReviewCount: Int get() = items.count { it.status == AlignmentStatus.NEEDS_REVIEW }
    val matchesCount: Int get() = items.count { it.status == AlignmentStatus.MATCHES }
}

/** Text formatting for the original / detected / difference / corrected display. */
object AlignmentFormat {
    /** `00:01:24.000` — always full precision, so original and corrected can be compared at a glance. */
    fun clock(ms: Long): String = TimestampParser.formatCanonical(ms)

    /** The confidence as shown to the user: whole percent, and NEVER 100 (nothing here can be verified to 100%). */
    fun percent(confidence: Float): Int = minOf(99, maxOf(0, Math.round(confidence * 100f)))

    /** `±0.05 s`. */
    fun plusMinus(ms: Long): String {
        val tenths = (ms + 5) / 10
        return "±${tenths / 100}.${(tenths % 100).toString().padStart(2, '0')} s"
    }

    /** `+1.430 s`, `-0.250 s`, `0.000 s`. */
    fun signedSeconds(diffMs: Long): String {
        val sign = if (diffMs > 0) "+" else if (diffMs < 0) "-" else ""
        val abs = if (diffMs < 0) -diffMs else diffMs
        val whole = abs / 1000
        val frac = (abs % 1000).toString().padStart(3, '0')
        return "$sign$whole.$frac s"
    }
}
