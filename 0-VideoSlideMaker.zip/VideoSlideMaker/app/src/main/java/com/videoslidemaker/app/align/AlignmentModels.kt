package com.videoslidemaker.app.align

import com.videoslidemaker.app.data.TimestampParser

/** How sure the aligner is about one line, boiled down to what the user needs to decide. */
enum class AlignmentStatus {
    /** The timestamp already agrees with the audio (within [TimestampAligner.MATCH_TOLERANCE_MS]). */
    MATCHES,

    /** A correction was found and is trustworthy enough to apply automatically. */
    HIGH_CONFIDENCE,

    /** Not sure enough. Nothing is changed unless the user explicitly applies it. */
    NEEDS_REVIEW
}

/** What the user (or auto-apply) did with a line. */
enum class AlignmentDecision { PENDING, KEPT_ORIGINAL, APPLIED }

/**
 * The result for ONE script line. All times are whole milliseconds on the recording's own clock,
 * which is the source of truth.
 *
 * @property originalMs  the timestamp from the user's script (before any correction).
 * @property currentMs   what the slide's timestamp is right now (== originalMs until a correction is applied).
 * @property detectedMs  when the audio says this line really starts, or null if no matching speech was found.
 * @property detectedEndMs when the spoken line ends, when it could be determined.
 * @property confidence  0..1. [TimestampAligner.HIGH_CONFIDENCE] and above is "high".
 * @property reason      for NEEDS_REVIEW lines: the plain-language reason it isn't trusted.
 */
data class AlignmentItem(
    val index: Int,
    val text: String,
    val originalMs: Long,
    val currentMs: Long,
    val detectedMs: Long?,
    val detectedEndMs: Long?,
    val confidence: Float,
    val status: AlignmentStatus,
    val reason: String?,
    val decision: AlignmentDecision = AlignmentDecision.PENDING
) {
    /** detected − original. Positive = the script timestamp was too early. */
    val diffMs: Long? get() = detectedMs?.let { it - originalMs }

    /** True when applying would actually move the timestamp. */
    val canApply: Boolean get() = detectedMs != null && detectedMs != currentMs
}

/** One point of the drift curve: how far the script was off at [transcriptMs]. */
data class DriftPoint(val transcriptMs: Long, val shiftMs: Long)

data class AlignmentResult(
    val items: List<AlignmentItem>,
    /** Speech-vs-background level difference of the recording, in dB. Low = hard to analyse. */
    val clarityDb: Float,
    /** The drift detected across the recording (window by window), earliest first. */
    val drift: List<DriftPoint>
) {
    val highConfidenceCount: Int get() = items.count { it.status == AlignmentStatus.HIGH_CONFIDENCE }
    val needsReviewCount: Int get() = items.count { it.status == AlignmentStatus.NEEDS_REVIEW }
    val matchesCount: Int get() = items.count { it.status == AlignmentStatus.MATCHES }
}

/** Text formatting for the original / detected / difference / corrected display. */
object AlignmentFormat {
    /** `00:01:24.000` — always full precision, so original and corrected can be compared at a glance. */
    fun clock(ms: Long): String = TimestampParser.formatCanonical(ms)

    /** `+1.430 s`, `-0.250 s`, `0.000 s`. */
    fun signedSeconds(diffMs: Long): String {
        val sign = if (diffMs > 0) "+" else if (diffMs < 0) "-" else ""
        val abs = if (diffMs < 0) -diffMs else diffMs
        val whole = abs / 1000
        val frac = (abs % 1000).toString().padStart(3, '0')
        return "$sign$whole.$frac s"
    }
}
