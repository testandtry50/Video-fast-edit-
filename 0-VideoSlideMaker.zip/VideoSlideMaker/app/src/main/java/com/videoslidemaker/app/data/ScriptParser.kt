package com.videoslidemaker.app.data

/**
 * Parses a .txt script file where each line is either:
 *   0:06 - some sentence text        (timestamp + sentence)
 *   12 - some sentence text          (plain-second timestamp + sentence)
 *   0:06                             (timestamp only — legacy format, blank sentence)
 *
 * The timestamp can be written in any of the formats [TimestampParser] understands — for
 * example 0:06, 00:06, 1:23:45, 00:00:000, 00:00.000, 01:23:45.500 — and every one is
 * converted to whole milliseconds before anything else happens. This object keeps the
 * seconds-based helpers the rest of the app already uses (parseTime / formatTime), now backed
 * by that exact millisecond value.
 */
object ScriptParser {

    /** [timestampMs] is the canonical value; [timestampSec] is derived from it for the rest of the app. */
    data class ParsedLine(val timestampMs: Long, val text: String) {
        val timestampSec: Double get() = timestampMs / 1000.0
    }

    /** A script line that was NOT turned into a slide, and why. */
    data class ScriptIssue(val lineNumber: Int, val message: String) {
        fun describe(): String = "Line $lineNumber: $message"
    }

    data class ScriptParseResult(val lines: List<ParsedLine>, val issues: List<ScriptIssue>)

    // ------------------------------------------------------------------------------------
    // Single timestamps (used by the time-entry fields)
    // ------------------------------------------------------------------------------------

    /** Seconds, or null if [raw] isn't a valid timestamp. Exact: it is milliseconds / 1000. */
    fun parseTime(raw: String): Double? =
        TimestampParser.parseMillisOrNull(raw)?.let { it / 1000.0 }

    /** Same as [parseTime] but says WHY an invalid timestamp is invalid. */
    fun parseTimeResult(raw: String): TimestampParser.Result = TimestampParser.parse(raw)

    /** Seconds → whole milliseconds (rounded to the nearest). Non-finite or negative → 0. */
    fun secondsToMillis(seconds: Double): Long =
        if (!seconds.isFinite() || seconds <= 0.0) 0L else Math.round(seconds * 1000.0)

    /**
     * For showing a time on screen. Adapts to the value: `0:05`, `12:30`, `1:05:00`, and when
     * the time has a millisecond part it is kept rather than silently dropped: `0:02.500`.
     * Parses back to exactly the same value, so it is also safe to seed an edit box with.
     */
    fun formatTime(seconds: Double): String =
        TimestampParser.format(secondsToMillis(seconds), includeMillis = true)

    /**
     * Like [formatTime] but always whole seconds — for a clock that ticks continuously
     * (the preview position), where flickering milliseconds would just be noise.
     */
    fun formatClock(seconds: Double): String =
        TimestampParser.format(secondsToMillis(seconds), includeMillis = false)

    // ------------------------------------------------------------------------------------
    // Whole scripts
    // ------------------------------------------------------------------------------------

    /** The slides from [content]. Lines that can't be used are dropped; see [parseScriptDetailed]. */
    fun parseScript(content: String): List<ParsedLine> = parseScriptDetailed(content).lines

    /**
     * Like [parseScript] but also reports every line that was skipped and why, with its
     * 1-based line number in the original file (blank lines count), so nothing disappears silently.
     */
    fun parseScriptDetailed(content: String): ScriptParseResult {
        val lines = ArrayList<ParsedLine>()
        val issues = ArrayList<ScriptIssue>()

        content.lines().forEachIndexed { index, rawLine ->
            val lineNumber = index + 1
            // Also strips an invisible byte-order mark at the start of the file.
            val line = TimestampParser.trimPadding(rawLine)
            if (line.isEmpty()) return@forEachIndexed

            if (line[0] !in '0'..'9') {
                issues.add(ScriptIssue(lineNumber, "\"${line.take(30)}\" doesn't start with a timestamp, so it was skipped."))
                return@forEachIndexed
            }

            // The timestamp is the longest run of digits, ':' and '.' at the start of the line.
            // Taking the WHOLE run (instead of guessing where it might end) is what lets
            // 01:23:45.500 stay in one piece — and lets a malformed run like 1:2:3:4 be reported
            // instead of being half-read as 1:2 with ":3:4" leaking into the sentence.
            var end = 0
            while (end < line.length && (line[end] in '0'..'9' || line[end] == ':' || line[end] == '.')) end++
            // A ':' or '.' hanging off the end is sentence punctuation ("0:05: Hello", "12. Hello").
            while (end > 0 && (line[end - 1] == ':' || line[end - 1] == '.')) end--

            when (val result = TimestampParser.parse(line.substring(0, end))) {
                is TimestampParser.Result.Ok ->
                    lines.add(ParsedLine(result.millis, textAfterTimestamp(line.substring(end))))
                is TimestampParser.Result.Error ->
                    issues.add(ScriptIssue(lineNumber, "${result.message} The line was skipped."))
            }
        }
        return ScriptParseResult(lines, issues)
    }

    // The separator between timestamp and text is deliberately just -/–/— (and optional, so a
    // bare space works too) — NOT ':'. Whitespace is dropped on both sides of one such dash.
    private fun textAfterTimestamp(rest: String): String {
        var text = rest.trimStart()
        if (text.isNotEmpty() && (text[0] == '-' || text[0] == '–' || text[0] == '—')) {
            text = text.substring(1).trimStart()
        }
        return text.trim()
    }
}
