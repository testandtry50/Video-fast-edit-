package com.videoslidemaker.app.adjust

import com.videoslidemaker.app.align.AlignmentApplier
import com.videoslidemaker.app.align.AlignmentItem
import com.videoslidemaker.app.align.AlignmentStatus

/**
 * Plans, previews and applies timestamp adjustments, never touching the preserved originals.
 *
 *  1. A *proposal source* turns what the user asked for into [Proposal]s (BEFORE -> AFTER):
 *     [entire], [selectedShift], [exact], [detected], [undoLast], [restoreOriginals].
 *  2. [preview] says what applying the ticked lines would really do: which would change, which are refused because they would
 *     break the timeline, which are unavailable. The user sees this BEFORE anything changes.
 *  3. [apply] makes exactly that change and keeps the original of every line it touches.
 *
 * Lines are given in script order and `lines[i].index == i`.
 */
object TimestampAdjuster {

    // ------------------------------------------------------------------------------------------------------------
    // Proposal sources
    // ------------------------------------------------------------------------------------------------------------

    /**
     * Move every timestamp by [offsetMs] and, optionally, stretch the spacing by [stretchPercent] (+0.1 makes the transcript
     * 0.1 % longer: for a recording sped up or slowed down). The first line is the anchor of the stretch, so it only moves by
     * the offset. Intended as ALL-OR-NOTHING: see [minimumOffset].
     */
    fun entire(lines: List<AdjustLine>, offsetMs: Long, stretchPercent: Double = 0.0): List<Proposal> {
        if (lines.isEmpty()) return emptyList()
        val t0 = lines[0].currentMs
        val k = 1.0 + stretchPercent / 100.0
        return lines.map { l ->
            Proposal(l.index, l.text, l.currentMs, t0 + Math.round((l.currentMs - t0) * k) + offsetMs)
        }
    }

    /** The earliest an all-lines shift can go: any more negative and the first line would start before 0:00:00. */
    fun minimumOffset(lines: List<AdjustLine>): Long = if (lines.isEmpty()) 0L else -lines.minOf { it.currentMs }

    /** Every line shifted by [offsetMs]; which lines are really moved is decided by which are ticked. */
    fun selectedShift(lines: List<AdjustLine>, offsetMs: Long): List<Proposal> =
        lines.map { Proposal(it.index, it.text, it.currentMs, it.currentMs + offsetMs) }

    /** Only line [index] gets a new time ([targetMs]); the rest are listed without one. */
    fun exact(lines: List<AdjustLine>, index: Int, targetMs: Long): List<Proposal> =
        lines.map { Proposal(it.index, it.text, it.currentMs, if (it.index == index) targetMs else null) }

    /**
     * The corrections an analysis found, for every line. A line is UNAVAILABLE when the analysis found nothing for it, when it
     * was not analysed, or when the script changed since (its text or current time is no longer what was analysed).
     */
    fun detected(lines: List<AdjustLine>, items: List<AlignmentItem>): List<Proposal> {
        val byIndex = items.associateBy { it.index }
        return lines.map { l ->
            val item = byIndex[l.index]
            when {
                item == null -> Proposal(l.index, l.text, l.currentMs, null, unavailable = "This line was not analysed.")
                item.text != l.text || item.currentMs != l.currentMs ->
                    Proposal(l.index, l.text, l.currentMs, null, unavailable = "The script changed since the analysis: analyse again.")
                item.detectedMs == null ->
                    Proposal(
                        l.index, l.text, l.currentMs, null, item.confidence, item.status,
                        unavailable = item.reason ?: "No matching speech was found for this line."
                    )
                else -> Proposal(l.index, l.text, l.currentMs, item.detectedMs, item.confidence, item.status, note = item.reason)
            }
        }
    }

    /** Taking back [batch]: each line goes back to the time it had before, unless it has been touched since. */
    fun undoLast(lines: List<AdjustLine>, batch: AdjustBatch?): List<Proposal> {
        if (batch == null) return emptyList()
        val out = ArrayList<Proposal>()
        for (c in batch.changes) {
            val l = lines.getOrNull(c.index) ?: continue
            out.add(
                when {
                    l.text.hashCode() != c.textHash ->
                        Proposal(l.index, l.text, l.currentMs, null, unavailable = "This line's text was edited after the adjustment, so it was left alone.")
                    l.currentMs != c.afterMs ->
                        Proposal(l.index, l.text, l.currentMs, null, unavailable = "This line's time was changed again after that adjustment, so it was left alone.")
                    else -> Proposal(l.index, l.text, l.currentMs, c.beforeMs)
                }
            )
        }
        return out
    }

    /** Every adjusted line back to the time the script originally gave it. Lines never adjusted are not listed. */
    fun restoreOriginals(lines: List<AdjustLine>): List<Proposal> =
        lines.filter { it.isAdjusted }.map { Proposal(it.index, it.text, it.currentMs, it.scriptMs) }

    /** The lines the analysis was sure about, that really need a change. ("Apply all high-confidence corrections".) */
    fun highConfidence(proposals: List<Proposal>): Set<Int> =
        proposals.filter {
            it.status == AlignmentStatus.HIGH_CONFIDENCE && it.unavailable == null && it.afterMs != null && it.afterMs != it.beforeMs
        }.map { it.index }.toSet()

    // ------------------------------------------------------------------------------------------------------------
    // Preview
    // ------------------------------------------------------------------------------------------------------------

    /**
     * What applying the ticked lines ([checked]) would do. Unticked lines are never changed. A ticked line is REFUSED when its
     * new time would start before 0:00:00 or sit within [AlignmentApplier.MIN_GAP_MS] of (or past) its neighbour; refusing
     * one line can free or block its neighbour, so this is decided for the whole ticked set at once, exactly as [apply] does.
     */
    fun preview(lines: List<AdjustLine>, proposals: List<Proposal>, checked: Set<Int>): Preview {
        val cur = LongArray(lines.size) { lines[it].currentMs }
        val wanted = LinkedHashMap<Int, Long>()
        val negative = HashSet<Int>()
        for (p in proposals) {
            if (p.index !in checked || p.unavailable != null || p.index !in lines.indices) continue
            val after = p.afterMs ?: continue
            if (after < 0L) negative.add(p.index) else if (after != cur[p.index]) wanted[p.index] = after
        }
        val plan = AlignmentApplier.plan(cur, wanted)
        val refused = plan.rejected.toHashSet()
        val out = ArrayList<PreviewLine>(proposals.size)
        for (p in proposals) {
            val ticked = p.index in checked
            val after = p.afterMs
            val line: PreviewLine = when {
                p.unavailable != null -> PreviewLine(p, ticked, Outcome.UNAVAILABLE, p.unavailable)
                after == null ->
                    if (ticked) PreviewLine(p, true, Outcome.UNAVAILABLE, "No new time is proposed for this line.")
                    else PreviewLine(p, false, Outcome.NOT_SELECTED, null)
                after == cur.getOrNull(p.index) -> PreviewLine(p, ticked, Outcome.NO_CHANGE, null)
                !ticked -> PreviewLine(p, false, Outcome.NOT_SELECTED, null)
                p.index in negative -> PreviewLine(p, true, Outcome.REFUSED, "It would start before 00:00:00.")
                p.index in refused -> PreviewLine(p, true, Outcome.REFUSED, "It would overlap the line before or after it.")
                else -> PreviewLine(p, true, Outcome.WILL_APPLY, null)
            }
            out.add(line)
        }
        return Preview(out, plan.accepted)
    }

    // ------------------------------------------------------------------------------------------------------------
    // Apply
    // ------------------------------------------------------------------------------------------------------------

    /**
     * Makes the changes in [wanted] (line index -> new time) that are safe, and returns the new lines.
     *
     * The ORIGINAL of every changed line is preserved: the first time a line is changed its current time becomes
     * [AdjustLine.scriptMs], and that is never overwritten afterwards. Changing a line back to its original time clears the
     * marker, because it then has the script's own time again.
     */
    fun apply(lines: List<AdjustLine>, wanted: Map<Int, Long>): ApplyResult {
        val cur = LongArray(lines.size) { lines[it].currentMs }
        val negative = wanted.filter { it.value < 0L }.keys
        val plan = AlignmentApplier.plan(cur, wanted.filter { it.value >= 0L })
        val result = lines.toMutableList()
        val applied = ArrayList<AppliedLine>()
        for (idx in plan.accepted.keys.sorted()) {                // in line order, whatever order the caller's map had
            val ms = plan.accepted.getValue(idx)
            val l = lines[idx]
            val base = l.scriptMs ?: l.currentMs            // the original: first write wins
            result[idx] = l.copy(currentMs = ms, scriptMs = if (ms == base) null else base)
            applied.add(AppliedLine(idx, l.text.hashCode(), l.currentMs, ms))
        }
        return ApplyResult(result, applied, plan.rejected + negative)
    }
}
