package com.videoslidemaker.app.align

import android.content.Context
import android.media.AudioFormat
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import java.nio.ByteOrder
import java.util.concurrent.CancellationException

/** The recording, reduced to what alignment needs. */
class RecordingEnergy(
    /** One loudness value (dBFS) per 10 ms, starting at [startOffsetMs]. */
    val frames: FloatArray,
    /** Recording time of frame 0: where the audio track begins (not always 0 for a video). */
    val startOffsetMs: Long,
    val durationMs: Long,
    val sampleRate: Int
)

/** A problem reading the recording that the user can understand. */
class RecordingReadException(message: String) : Exception(message)

/**
 * Decodes the audio of an audio OR video file (any format this phone can decode) straight into
 * 10 ms loudness frames, in one streaming pass: the raw audio is never held in memory, so a
 * multi-hour recording is fine.
 *
 * Timing is tracked exactly. Frame 0 is placed at the audio track's own start time, and if the
 * decoder ever reports a gap (a dropped chunk) the missing time is filled with silence so
 * everything after it stays on the true clock.
 */
object RecordingReader {

    private const val GAP_TOLERANCE_MS = 100L
    private const val TIMEOUT_US = 10_000L

    fun read(
        context: Context,
        uri: Uri,
        onProgress: (Int) -> Unit,
        isCancelled: () -> Boolean
    ): RecordingEnergy {
        val extractor = MediaExtractor()
        var decoder: MediaCodec? = null
        try {
            val pfd = context.contentResolver.openFileDescriptor(uri, "r")
                ?: throw RecordingReadException("Couldn't open the recording.")
            pfd.use { extractor.setDataSource(it.fileDescriptor) }

            var trackIndex = -1
            var format: MediaFormat? = null
            for (i in 0 until extractor.trackCount) {
                val f = extractor.getTrackFormat(i)
                val mime = f.getString(MediaFormat.KEY_MIME) ?: continue
                if (mime.startsWith("audio/")) {
                    trackIndex = i
                    format = f
                    break
                }
            }
            if (trackIndex < 0 || format == null) {
                throw RecordingReadException("That file has no audio track.")
            }
            extractor.selectTrack(trackIndex)
            val mime = format.getString(MediaFormat.KEY_MIME)!!
            val durationUs = if (format.containsKey(MediaFormat.KEY_DURATION)) format.getLong(MediaFormat.KEY_DURATION) else 0L

            val codec = try {
                MediaCodec.createDecoderByType(mime)
            } catch (e: Exception) {
                throw RecordingReadException("This phone can't decode that audio format ($mime).")
            }
            decoder = codec
            codec.configure(format, null, null, 0)
            codec.start()

            val info = MediaCodec.BufferInfo()
            var inputDone = false
            var outputDone = false
            var extractorState: EnergyFrameExtractor? = null
            var channels = if (format.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) format.getInteger(MediaFormat.KEY_CHANNEL_COUNT) else 1
            var sampleRate = if (format.containsKey(MediaFormat.KEY_SAMPLE_RATE)) format.getInteger(MediaFormat.KEY_SAMPLE_RATE) else 0
            var floatPcm = false
            var firstPtsUs = -1L
            var mono = FloatArray(0)
            var lastPercent = -1

            while (!outputDone) {
                if (isCancelled()) throw CancellationException()

                if (!inputDone) {
                    val inIndex = codec.dequeueInputBuffer(TIMEOUT_US)
                    if (inIndex >= 0) {
                        val buffer = codec.getInputBuffer(inIndex)!!
                        val size = extractor.readSampleData(buffer, 0)
                        if (size < 0) {
                            codec.queueInputBuffer(inIndex, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            codec.queueInputBuffer(inIndex, 0, size, extractor.sampleTime, 0)
                            extractor.advance()
                        }
                    }
                }

                val outIndex = codec.dequeueOutputBuffer(info, TIMEOUT_US)
                when {
                    outIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        val out = codec.outputFormat
                        if (out.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) channels = out.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                        if (out.containsKey(MediaFormat.KEY_SAMPLE_RATE)) sampleRate = out.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                        floatPcm = out.containsKey(MediaFormat.KEY_PCM_ENCODING) &&
                            out.getInteger(MediaFormat.KEY_PCM_ENCODING) == AudioFormat.ENCODING_PCM_FLOAT
                        if (extractorState != null && extractorState.sampleRate != sampleRate) {
                            throw RecordingReadException("The recording changes sample rate part-way through, which isn't supported.")
                        }
                    }
                    outIndex >= 0 -> {
                        if (info.size > 0) {
                            if (sampleRate <= 0) throw RecordingReadException("Couldn't determine the recording's sample rate.")
                            var ex = extractorState
                            if (ex == null) {
                                ex = EnergyFrameExtractor(sampleRate)
                                extractorState = ex
                                firstPtsUs = info.presentationTimeUs
                            }
                            // Fill a gap if the decoder skipped ahead on the true clock.
                            val expectedSamples = (info.presentationTimeUs - firstPtsUs) * sampleRate / 1_000_000L
                            val gap = expectedSamples - ex.samplesConsumed
                            if (gap * 1000L > GAP_TOLERANCE_MS * sampleRate) ex.pushSilence(gap)

                            val outBuffer = codec.getOutputBuffer(outIndex)!!
                            outBuffer.position(info.offset)
                            outBuffer.limit(info.offset + info.size)
                            outBuffer.order(ByteOrder.nativeOrder())
                            val frameCount: Int
                            if (floatPcm) {
                                val fb = outBuffer.asFloatBuffer()
                                frameCount = fb.remaining() / channels
                                if (mono.size < frameCount) mono = FloatArray(frameCount)
                                for (f in 0 until frameCount) {
                                    var sum = 0f
                                    for (c in 0 until channels) sum += fb.get()
                                    mono[f] = sum / channels
                                }
                            } else {
                                val sb = outBuffer.asShortBuffer()
                                frameCount = sb.remaining() / channels
                                if (mono.size < frameCount) mono = FloatArray(frameCount)
                                for (f in 0 until frameCount) {
                                    var sum = 0
                                    for (c in 0 until channels) sum += sb.get().toInt()
                                    mono[f] = sum / (32768f * channels)
                                }
                            }
                            ex.push(mono, frameCount)
                        }
                        codec.releaseOutputBuffer(outIndex, false)
                        if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outputDone = true

                        if (durationUs > 0L) {
                            val pct = ((info.presentationTimeUs * 100L) / durationUs).toInt().coerceIn(0, 100)
                            if (pct != lastPercent) {
                                lastPercent = pct
                                onProgress(pct)
                            }
                        }
                    }
                }
            }

            val ex = extractorState ?: throw RecordingReadException("The recording contains no audio.")
            val frames = ex.finish()
            val startMs = if (firstPtsUs > 0L) firstPtsUs / 1000L else 0L
            return RecordingEnergy(
                frames = frames,
                startOffsetMs = startMs,
                durationMs = frames.size.toLong() * EnergyFrameExtractor.HOP_MS,
                sampleRate = ex.sampleRate
            )
        } finally {
            try {
                decoder?.stop()
            } catch (_: Exception) {
            }
            try {
                decoder?.release()
            } catch (_: Exception) {
            }
            extractor.release()
        }
    }
}
