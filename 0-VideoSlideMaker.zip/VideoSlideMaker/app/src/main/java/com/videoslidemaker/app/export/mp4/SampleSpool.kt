package com.videoslidemaker.app.export.mp4

import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.EOFException
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream

/** One encoded sample parked on disk. */
internal class SpooledSample(val ptsUs: Long, val flags: Int, val data: ByteArray)

/** A queue of samples in time order, read one at a time. */
internal interface AudioSampleSource {
    fun peekPtsUs(): Long?
    fun next(): SpooledSample?
}

/**
 * Encoded audio waiting for the video to start, kept in a FILE instead of memory.
 *
 * The export encodes all the narration before the first picture exists, but the container can only be started once both the
 * audio and the video formats are known. Holding hours of encoded audio in a list (as this used to) puts hundreds of megabytes
 * and millions of small objects on the heap; here it is a sequential file, written once and read once, with one sample in memory.
 *
 * Record: `[pts: 8][flags: 4][size: 4][bytes]`. A damaged tail (a crash while writing) just ends the queue early.
 */
internal class SampleSpool(val file: File) {
    private var out: DataOutputStream? = null

    var count = 0L
        private set

    /** Bytes in the file. */
    var bytes = 0L
        private set

    fun append(ptsUs: Long, flags: Int, data: ByteArray, off: Int = 0, len: Int = data.size) {
        val o = out ?: DataOutputStream(BufferedOutputStream(FileOutputStream(file), BUFFER)).also { out = it }
        o.writeLong(ptsUs)
        o.writeInt(flags)
        o.writeInt(len)
        o.write(data, off, len)
        count++
        bytes += HEADER + len
    }

    /** Ends writing (the file exists even when nothing was written). */
    fun finishWriting() {
        val o = out
        if (o != null) {
            o.flush()
            o.close()
            out = null
        } else if (!file.exists()) {
            file.createNewFile()
        }
    }

    fun reader(): SpoolReader {
        finishWriting()
        return SpoolReader(file)
    }

    fun delete() {
        try {
            out?.close()
        } catch (_: Exception) {
        }
        out = null
        file.delete()
    }

    companion object {
        const val HEADER = 16L
        const val BUFFER = 1 shl 18
    }
}

internal class SpoolReader(file: File) : AudioSampleSource, AutoCloseable {
    private val input = DataInputStream(BufferedInputStream(FileInputStream(file), SampleSpool.BUFFER))
    private var head: SpooledSample? = null
    private var eof = false

    private fun fill() {
        if (head != null || eof) return
        try {
            val pts = input.readLong()
            val flags = input.readInt()
            val len = input.readInt()
            if (len < 0 || len > MAX_SAMPLE) {            // not a sample: the tail is damaged
                eof = true
                return
            }
            val b = ByteArray(len)
            input.readFully(b)
            head = SpooledSample(pts, flags, b)
        } catch (_: EOFException) {
            eof = true
        }
    }

    override fun peekPtsUs(): Long? {
        fill()
        return head?.ptsUs
    }

    override fun next(): SpooledSample? {
        fill()
        val h = head
        head = null
        return h
    }

    override fun close() {
        try {
            input.close()
        } catch (_: Exception) {
        }
    }

    private companion object {
        const val MAX_SAMPLE = 64 * 1024 * 1024
    }
}
