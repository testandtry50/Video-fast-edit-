package com.videoslidemaker.app.export.mp4

/** H.264 as MediaCodec produces it ("Annex B": NAL units separated by start codes) and as MP4 stores it (each NAL after its length). */
internal object AnnexB {

    /** [start, endExclusive) of each NAL unit's bytes, without the start codes in front. */
    fun nals(d: ByteArray, off: Int, len: Int): List<IntArray> {
        val end = off + len
        val out = ArrayList<IntArray>()
        var i = off
        var nalStart = -1
        while (i + 2 < end) {
            if (d[i].toInt() == 0 && d[i + 1].toInt() == 0 && d[i + 2].toInt() == 1) {
                if (nalStart >= 0) out.add(intArrayOf(nalStart, trimZeros(d, nalStart, i)))
                nalStart = i + 3
                i += 3
            } else {
                i++
            }
        }
        if (nalStart >= 0 && nalStart < end) out.add(intArrayOf(nalStart, trimZeros(d, nalStart, end)))
        return out
    }

    /** A NAL cannot end in a zero byte: any zeros before the next start code belong to that start code. */
    private fun trimZeros(d: ByteArray, start: Int, end: Int): Int {
        var e = end
        while (e > start && d[e - 1].toInt() == 0) e--
        return e
    }

    fun type(d: ByteArray, nalStart: Int): Int = d[nalStart].toInt() and 0x1F

    /**
     * One video sample in MP4 form: every NAL behind a 4-byte length. Parameter sets (7, 8) and access-unit delimiters (9) are
     * left out, because the sample entry already carries the parameter sets.
     */
    fun toLengthPrefixed(d: ByteArray, off: Int, len: Int): ByteArray {
        val nals = nals(d, off, len)
        require(nals.isNotEmpty()) { "no H.264 start code in the encoder's output" }
        var total = 0
        for (n in nals) {
            val t = type(d, n[0])
            if (t != 7 && t != 8 && t != 9) total += 4 + (n[1] - n[0])
        }
        val out = ByteArray(total)
        var p = 0
        for (n in nals) {
            val t = type(d, n[0])
            if (t == 7 || t == 8 || t == 9) continue
            val l = n[1] - n[0]
            out[p++] = (l ushr 24).toByte()
            out[p++] = (l ushr 16).toByte()
            out[p++] = (l ushr 8).toByte()
            out[p++] = l.toByte()
            System.arraycopy(d, n[0], out, p, l)
            p += l
        }
        return out
    }
}

/** The H.264 parameter sets, and the `avcC` record that carries them in an MP4 sample entry. */
internal class AvcConfig(val sps: List<ByteArray>, val pps: List<ByteArray>) {

    init {
        require(sps.isNotEmpty() && pps.isNotEmpty()) { "the encoder did not give both an SPS and a PPS" }
        require(sps[0].size >= 4) { "the SPS is too short" }
    }

    val profile: Int get() = sps[0][1].toInt() and 0xFF
    val level: Int get() = sps[0][3].toInt() and 0xFF

    /** The contents of the `avcC` box (not the box header). */
    fun avcC(): ByteArray {
        val b = Mp4Buf(64 + sps.sumOf { it.size } + pps.sumOf { it.size })
        b.u8(1)                                  // configurationVersion
        b.u8(sps[0][1].toInt() and 0xFF)         // AVCProfileIndication
        b.u8(sps[0][2].toInt() and 0xFF)         // profile_compatibility
        b.u8(sps[0][3].toInt() and 0xFF)         // AVCLevelIndication
        b.u8(0xFC or 3)                          // 4-byte NAL lengths
        b.u8(0xE0 or sps.size)
        for (s in sps) { b.u16(s.size); b.bytes(s) }
        b.u8(pps.size)
        for (p in pps) { b.u16(p.size); b.bytes(p) }
        if (profile == 100 || profile == 110 || profile == 122 || profile == 144) {
            b.u8(0xFC or 1)                      // chroma_format_idc 4:2:0
            b.u8(0xF8)                           // bit_depth_luma_minus8 = 0
            b.u8(0xF8)                           // bit_depth_chroma_minus8 = 0
            b.u8(0)                              // no SPS extensions
        }
        return b.toByteArray()
    }

    companion object {
        /** MediaCodec's `csd-0` / `csd-1` buffers: parameter sets behind start codes (both in one buffer, or one each). */
        fun fromCsd(vararg csd: ByteArray?): AvcConfig {
            val sps = ArrayList<ByteArray>()
            val pps = ArrayList<ByteArray>()
            for (c in csd) {
                if (c == null) continue
                for (n in AnnexB.nals(c, 0, c.size)) {
                    val nal = c.copyOfRange(n[0], n[1])
                    when (AnnexB.type(c, n[0])) {
                        7 -> sps.add(nal)
                        8 -> pps.add(nal)
                    }
                }
            }
            return AvcConfig(sps, pps)
        }
    }
}

/** The `esds` record for AAC. */
internal object Esds {

    /** An MPEG-4 descriptor length: the 4-byte form every parser accepts. */
    private fun descLen(b: Mp4Buf, len: Int) {
        b.u8(0x80 or ((len ushr 21) and 0x7F))
        b.u8(0x80 or ((len ushr 14) and 0x7F))
        b.u8(0x80 or ((len ushr 7) and 0x7F))
        b.u8(len and 0x7F)
    }

    /** The contents of the `esds` box after its version/flags: [audioSpecificConfig] is MediaCodec's AAC `csd-0`. */
    fun payload(audioSpecificConfig: ByteArray, avgBitrate: Int): ByteArray {
        val dsi = Mp4Buf(16 + audioSpecificConfig.size)                 // DecoderSpecificInfo
        dsi.u8(0x05); descLen(dsi, audioSpecificConfig.size); dsi.bytes(audioSpecificConfig)
        val dcd = Mp4Buf(32 + dsi.size)                                 // DecoderConfigDescriptor
        dcd.u8(0x04); descLen(dcd, 13 + dsi.size)
        dcd.u8(0x40)                                                    // MPEG-4 audio
        dcd.u8(0x15)                                                    // audio stream
        dcd.u8(0); dcd.u8(0); dcd.u8(0)                                 // buffer size
        dcd.u32(avgBitrate.toLong().coerceAtLeast(0L))                  // max bitrate
        dcd.u32(avgBitrate.toLong().coerceAtLeast(0L))                  // average bitrate
        dcd.bytes(dsi.toByteArray())
        val sl = byteArrayOf(0x06, 0x80.toByte(), 0x80.toByte(), 0x80.toByte(), 0x01, 0x02)   // SLConfigDescriptor
        val es = Mp4Buf(64 + dcd.size)                                  // ES_Descriptor
        es.u8(0x03); descLen(es, 3 + dcd.size + sl.size)
        es.u16(0)                                                       // ES_ID
        es.u8(0)                                                        // flags
        es.bytes(dcd.toByteArray())
        es.bytes(sl)
        return es.toByteArray()
    }
}
