package com.videoslidemaker.app.check

import android.content.Context
import android.net.Uri
import org.vosk.Model
import org.vosk.Recognizer

/**
 * Offline speech recognition with Vosk (Apache-2.0). Needs the speech model that [VoskModelStore] keeps.
 *
 * The recording is decoded by [SpeechPcmReader] and streamed through Vosk; every word comes back with its start / end
 * time and a confidence, and the times are put on the recording's own clock (where its audio track starts is added).
 */
class VoskWordRecognizer(private val context: Context, private val store: VoskModelStore) : WordRecognizer {

    override fun isReady(): Boolean = store.modelDir() != null

    override fun recognize(uri: Uri, onProgress: (Int) -> Unit, isCancelled: () -> Boolean): RecognizedSpeech {
        val dir = store.modelDir() ?: throw RecognizerException("No speech model is installed yet. Choose one first.")
        val model = try {
            Model(dir.absolutePath)
        } catch (e: Exception) {
            throw RecognizerException("The speech model couldn't be loaded. Try installing it again.")
        } catch (e: UnsatisfiedLinkError) {
            throw RecognizerException("Speech recognition isn't available on this phone.")
        }
        try {
            val recognizer = Recognizer(model, SpeechPcmReader.TARGET_RATE.toFloat())
            try {
                recognizer.setWords(true)
                val words = ArrayList<SpokenWord>()
                var offset = 0L
                val info = SpeechPcmReader.read(
                    context = context,
                    uri = uri,
                    onStart = { offset = it },
                    onPcm = { pcm, length ->
                        // true = Vosk reached the end of a phrase and has a finished result
                        if (recognizer.acceptWaveForm(pcm, length)) words.addAll(VoskJson.parseWords(recognizer.result, offset))
                    },
                    onProgress = onProgress,
                    isCancelled = isCancelled
                )
                words.addAll(VoskJson.parseWords(recognizer.finalResult, offset))
                return RecognizedSpeech(words, info.durationMs)
            } finally {
                recognizer.close()
            }
        } finally {
            model.close()
        }
    }
}
