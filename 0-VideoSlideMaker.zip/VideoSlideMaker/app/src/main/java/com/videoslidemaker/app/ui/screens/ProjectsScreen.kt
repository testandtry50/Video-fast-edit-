package com.videoslidemaker.app.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.videoslidemaker.app.data.ProjectInfo
import com.videoslidemaker.app.data.ProjectNames
import com.videoslidemaker.app.data.ProjectsUi
import com.videoslidemaker.app.ui.components.AlertBox
import com.videoslidemaker.app.ui.components.AlertStyle
import com.videoslidemaker.app.ui.components.BadgeChip
import com.videoslidemaker.app.ui.components.CompactButton
import com.videoslidemaker.app.ui.components.PrimaryButton
import com.videoslidemaker.app.ui.components.SectionCard
import com.videoslidemaker.app.ui.theme.Accent
import com.videoslidemaker.app.ui.theme.Bg
import com.videoslidemaker.app.ui.theme.Muted
import com.videoslidemaker.app.ui.theme.Red
import com.videoslidemaker.app.ui.theme.Surface
import com.videoslidemaker.app.ui.theme.TextMain

/**
 * NEW (2.14): all your projects in one place. Open one, start a new one, rename, copy or delete.
 *
 * Only the open project is held in memory; the others are small files on disk that cost nothing until opened, so a long
 * project (hours of video) does not slow the others down. The screen closes by itself once another project is open.
 */
@Composable
fun ProjectsScreen(
    ui: ProjectsUi,
    onClose: () -> Unit,
    onOpen: (String) -> Unit,
    onCreate: (String) -> Unit,
    onRename: (String, String) -> Unit,
    onDuplicate: (String, String) -> Unit,
    onDelete: (String) -> Unit,
    onDismissMessage: () -> Unit,
    modifier: Modifier = Modifier
) {
    // Back never leaves while a project is being opened or copied (and never falls through to the step underneath).
    BackHandler { if (ui.busyText == null) onClose() }

    // Another project became the open one: this screen has done its job.
    val startId = remember { ui.activeId }
    LaunchedEffect(ui.activeId) {
        if (startId != null && ui.activeId != null && ui.activeId != startId) onClose()
    }

    var showNew by remember { mutableStateOf(false) }
    var renaming by remember { mutableStateOf<ProjectInfo?>(null) }
    var copying by remember { mutableStateOf<ProjectInfo?>(null) }
    var deleting by remember { mutableStateOf<ProjectInfo?>(null) }
    var query by remember { mutableStateOf("") }

    val shown = remember(ui.projects, ui.activeId, query) {
        ui.ordered().filter { ProjectNames.matches(it.name, query) }
    }

    Box(
        modifier
            .fillMaxSize()
            .background(Bg)
            .safeDrawingPadding()
            // This page sits on top of the app; swallow taps so nothing underneath reacts.
            .pointerInput(Unit) { detectTapGestures { } }
    ) {
        Column(Modifier.fillMaxSize()) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .background(Surface)
                    .padding(start = 4.dp, end = 16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { if (ui.busyText == null) onClose() }) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Close the projects list", tint = TextMain)
                }
                Text(
                    "Projects",
                    style = MaterialTheme.typography.titleMedium,
                    color = TextMain,
                    modifier = Modifier.semantics { heading() }
                )
            }

            LazyColumn(
                Modifier.weight(1f),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Column {
                        Text(
                            "Work on as many videos as you like. Each project keeps its own script, photos, matches, " +
                                "recording and settings, and opens exactly where you left it.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = Muted
                        )
                        PrimaryButton(
                            "New project",
                            modifier = Modifier.padding(top = 12.dp),
                            icon = Icons.Filled.Add,
                            enabled = ui.ready && ui.busyText == null
                        ) { showNew = true }
                    }
                }

                val message = ui.message
                if (message != null) {
                    item {
                        Column {
                            AlertBox(message, if (ui.messageIsProblem) AlertStyle.WARNING else AlertStyle.SUCCESS)
                            TextButton(onClick = onDismissMessage) { Text("OK") }
                        }
                    }
                }

                // With a lot of projects, finding one by a word from its name is quicker than scrolling.
                if (ui.projects.size > 5) {
                    item {
                        OutlinedTextField(
                            value = query,
                            onValueChange = { query = it },
                            placeholder = { Text("Search your ${ui.projects.size} projects", color = Muted) },
                            leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null, tint = Muted) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }

                if (!ui.ready) {
                    item { Text("Loading your projects…", color = Muted, style = MaterialTheme.typography.bodyMedium) }
                } else if (shown.isEmpty()) {
                    item { Text("No project matches \u201C$query\u201D.", color = Muted, style = MaterialTheme.typography.bodyMedium) }
                }

                items(shown, key = { it.id }) { project ->
                    ProjectCard(
                        project = project,
                        isOpen = project.id == ui.activeId,
                        enabled = ui.busyText == null,
                        onOpen = { onOpen(project.id) },
                        onRename = { renaming = project },
                        onCopy = { copying = project },
                        onDelete = { deleting = project }
                    )
                }

                item {
                    Text(
                        "Your original photos, recordings and exported videos are never moved, changed or deleted by this list.",
                        style = MaterialTheme.typography.bodySmall,
                        color = Muted,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
            }
        }

        val busy = ui.busyText
        if (busy != null) {
            Box(
                Modifier
                    .fillMaxSize()
                    .background(Bg.copy(alpha = 0.85f))
                    .pointerInput(Unit) { detectTapGestures { } },
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator(color = Accent)
                    Text(busy, color = TextMain, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.padding(top = 12.dp))
                }
            }
        }
    }

    if (showNew) {
        NameDialog(
            title = "New project",
            explanation = "Leave the name empty to call it \u201C${ProjectNames.nextDefault(ui.projects.map { it.name })}\u201D. " +
                "The project you are in now is saved first and stays exactly as it is.",
            initial = "",
            placeholder = "Name, e.g. Episode 12",
            confirmLabel = "Create",
            allowBlank = true,
            onConfirm = { name -> showNew = false; onCreate(name) },
            onDismiss = { showNew = false }
        )
    }

    val toRename = renaming
    if (toRename != null) {
        NameDialog(
            title = "Rename project",
            explanation = null,
            initial = toRename.name,
            placeholder = "Project name",
            confirmLabel = "Save",
            allowBlank = false,
            onConfirm = { name -> renaming = null; onRename(toRename.id, name) },
            onDismiss = { renaming = null }
        )
    }

    val toCopy = copying
    if (toCopy != null) {
        NameDialog(
            title = "Copy project",
            explanation = "Makes an independent copy: script, photo list, matches, name texts and settings. " +
                "Photos cleaned by the logo cleaner are copied too, so a copy uses some extra storage. The copy is not opened.",
            initial = ProjectNames.copyOf(toCopy.name, ui.projects.map { it.name }),
            placeholder = "Name of the copy",
            confirmLabel = "Copy",
            allowBlank = false,
            onConfirm = { name -> copying = null; onDuplicate(toCopy.id, name) },
            onDismiss = { copying = null }
        )
    }

    val toDelete = deleting
    if (toDelete != null) {
        val onlyOne = ui.projects.size <= 1
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text("Delete \u201C${toDelete.name}\u201D?") },
            text = {
                Text(
                    "This removes the project from the app: its script, photo list, matches and settings. " +
                        "Your original photos, your recording and any videos you exported are not touched. " +
                        (if (onlyOne) "It is your only project, so a new empty one will be opened. " else "") +
                        "This can't be undone."
                )
            },
            confirmButton = {
                TextButton(onClick = { deleting = null; onDelete(toDelete.id) }) { Text("Delete", color = Red) }
            },
            dismissButton = {
                TextButton(onClick = { deleting = null }) { Text("Keep it") }
            }
        )
    }
}

@Composable
private fun ProjectCard(
    project: ProjectInfo,
    isOpen: Boolean,
    enabled: Boolean,
    onOpen: () -> Unit,
    onRename: () -> Unit,
    onCopy: () -> Unit,
    onDelete: () -> Unit
) {
    val count = remember { java.text.NumberFormat.getIntegerInstance() }
    val edited = remember(project.updatedAtMs) {
        if (project.updatedAtMs <= 0L) "" else
            android.text.format.DateUtils.getRelativeTimeSpanString(
                project.updatedAtMs, System.currentTimeMillis(), android.text.format.DateUtils.MINUTE_IN_MILLIS
            ).toString()
    }
    SectionCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                project.name,
                style = MaterialTheme.typography.titleSmall,
                color = TextMain,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier
                    .weight(1f)
                    .semantics { heading() }
            )
            if (isOpen) {
                BadgeChip("Open now", AlertStyle.SUCCESS, modifier = Modifier.padding(start = 8.dp))
            }
        }
        val facts = buildString {
            append(count.format(project.slideCount)).append(if (project.slideCount == 1) " slide" else " slides")
            append("  \u00B7  ").append(count.format(project.photoCount)).append(if (project.photoCount == 1) " photo" else " photos")
            append("  \u00B7  ").append(ProjectNames.formatDuration(project.durationSec)).append(" long")
        }
        Text(facts, style = MaterialTheme.typography.bodySmall, color = Muted, modifier = Modifier.padding(top = 4.dp))
        if (edited.isNotEmpty()) {
            Text("Edited $edited", style = MaterialTheme.typography.bodySmall, color = Muted)
        }

        if (!isOpen) {
            PrimaryButton("Open this project", modifier = Modifier.padding(top = 8.dp), enabled = enabled, onClick = onOpen)
        }
        Row(
            Modifier
                .fillMaxWidth()
                .padding(top = if (isOpen) 8.dp else 4.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            CompactButton("Rename", onRename, enabled)
            CompactButton("Copy", onCopy, enabled)
            CompactButton("Delete", onDelete, enabled)
        }
    }
}

@Composable
private fun NameDialog(
    title: String,
    explanation: String?,
    initial: String,
    placeholder: String,
    confirmLabel: String,
    allowBlank: Boolean,
    onConfirm: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column {
                OutlinedTextField(
                    value = text,
                    onValueChange = { if (it.length <= ProjectNames.MAX_LENGTH) text = it },
                    placeholder = { Text(placeholder, color = Muted) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                if (explanation != null) {
                    Text(
                        explanation,
                        style = MaterialTheme.typography.bodySmall,
                        color = Muted,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = allowBlank || ProjectNames.clean(text).isNotEmpty(),
                onClick = { onConfirm(text) }
            ) { Text(confirmLabel) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
