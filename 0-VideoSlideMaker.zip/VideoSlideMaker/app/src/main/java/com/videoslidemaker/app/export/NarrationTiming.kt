package com.videoslidemaker.app.export

/**
 * Keeps one spoken sentence from running into the next one.
 *
 * Each sentence is spoken by the phone's voice and laid onto the sound timeline at its own timestamp. A sentence that
 * takes longer to say than the time before the next timestamp used to carry on underneath the next sentence, so two
 * voices were heard at once - which sounds like an echo and makes the words hard to follow. (The Preview never did
 * this: it stops the old sentence the moment the next one starts.) Here the sentence is cut where the next one begins,
 * with a very short fade so the cut does not click.
 *
 * Plain Kotlin (no Android classes) so it can be tested on an ordinary JVM.
 */
object NarrationTiming {
    /** A sentence may run this long past the next timestamp: spoken sentences usually end in a little silence anyway. */
    const val GRACE_SEC = 0.10

    /** Never squeeze a sentence into less than this, so a script with two nearly equal timestamps is not turned into a click. */
    const val MIN_SLOT_SEC = 0.6

    /** The length of the fade at the cut. */
    const val FADE_SEC = 0.03

    /**
     * How many frames the sentence starting at [startSec] may use before the sentence at [nextStartSec] begins;
     * null when there is no next sentence (nothing to run into).
     */
    fun slotFrames(startSec: Double, nextStartSec: Double?, sampleRate: Int): Long? {
        if (nextStartSec == null) return null
        val slotSec = maxOf(nextStartSec - startSec, MIN_SLOT_SEC) + GRACE_SEC
        return (slotSec * sampleRate).toLong()
    }

    /**
     * [pcm] is 16-bit little-endian PCM with [channels] channels. When it is longer than [slotFrames] it is cut there,
     * ending with a short fade to silence; otherwise it is returned untouched (the same array).
     */
    fun fitToSlot(pcm: ByteArray, channels: Int, sampleRate: Int, slotFrames: Long?): ByteArray {
        if (slotFrames == null || channels <= 0) return pcm
        val frameBytes = 2 * channels
        val frames = pcm.size / frameBytes
        if (frames <= slotFrames) return pcm

        val keep = slotFrames.toInt().coerceAtLeast(1)
        val out = pcm.copyOf(keep * frameBytes)
        val fadeFrames = minOf((FADE_SEC * sampleRate).toInt().coerceAtLeast(1), keep)
        for (i in 0 until fadeFrames) {
            val gain = (fadeFrames - 1 - i).toFloat() / fadeFrames // 1 -> 0 over the last fadeFrames frames
            val frame = keep - fadeFrames + i
            for (c in 0 until channels) {
                val k = frame * frameBytes + c * 2
                val s = ((out[k + 1].toInt() shl 8) or (out[k].toInt() and 0xFF)).toShort().toInt()
                val v = Math.round(s * gain)
                out[k] = (v and 0xFF).toByte()
                out[k + 1] = ((v shr 8) and 0xFF).toByte()
            }
        }
        return out
    }
}
