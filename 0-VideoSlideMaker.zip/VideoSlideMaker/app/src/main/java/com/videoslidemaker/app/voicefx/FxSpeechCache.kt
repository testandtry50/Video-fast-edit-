package com.videoslidemaker.app.voicefx

import com.videoslidemaker.app.export.AUDIO_CHANNELS
import com.videoslidemaker.app.export.AUDIO_SAMPLE_RATE
import com.videoslidemaker.app.export.PcmResampler
import com.videoslidemaker.app.export.WavUtils
import com.videoslidemaker.app.tts.NarrationTts
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File

/**
 * The phone's text-to-speech voice, run through the voice changer, kept ready to play.
 *
 * The phone's engine can only speak a sentence out loud as it is, so to change it the sentence is first
 * recorded to a file, then changed, then played. Doing that takes a moment, so the Preview asks for the
 * next few sentences ahead of time and they are kept here (up to about 48 MB, oldest dropped first).
 * One sentence is made at a time - the engine can't do two at once.
 */
class FxSpeechCache(private val tts: NarrationTts, private val cacheDir: File) {
    private val mutex = Mutex()
    private val cache = LinkedHashMap<String, ByteArray>(16, 0.75f, true)
    private var totalBytes = 0L

    private fun lookup(key: String): ByteArray? = synchronized(cache) { cache[key] }

    private fun store(key: String, data: ByteArray) {
        synchronized(cache) {
            val old = cache.put(key, data)
            if (old != null) totalBytes -= old.size
            totalBytes += data.size
            val iter = cache.entries.iterator()
            while (totalBytes > MAX_BYTES && cache.size > 1 && iter.hasNext()) {
                val e = iter.next()
                totalBytes -= e.value.size
                iter.remove()
            }
        }
    }

    /** The sentence as 44.1 kHz stereo 16-bit PCM with [fx] applied, or null if the phone's voice failed. */
    suspend fun get(text: String, localeTag: String, rate: Float, fx: VoiceFxSettings): ByteArray? {
        val key = "$localeTag|$rate|$fx|$text"
        lookup(key)?.let { return it }
        return mutex.withLock {
            val again = lookup(key)
            if (again != null) return@withLock again
            val wav = File(cacheDir, "fx_speech_${System.nanoTime()}.wav")
            try {
                if (!tts.synthesizeToFile(text, localeTag, rate, wav)) return@withLock null
                val pcm = WavUtils.readPcm16Wav(wav) ?: return@withLock null
                val processed = withContext(Dispatchers.Default) {
                    val converted = PcmResampler.convert(
                        pcm.data, pcm.sampleRate, pcm.channelCount, AUDIO_SAMPLE_RATE, AUDIO_CHANNELS
                    )
                    VoiceFxPcm.processClip(converted, AUDIO_SAMPLE_RATE, AUDIO_CHANNELS, fx, 0)
                }
                store(key, processed)
                processed
            } finally {
                wav.delete()
            }
        }
    }

    private companion object {
        const val MAX_BYTES = 48L * 1024L * 1024L
    }
}
