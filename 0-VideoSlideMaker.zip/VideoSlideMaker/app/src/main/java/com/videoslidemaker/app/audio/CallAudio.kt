package com.videoslidemaker.app.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioManager

/**
 * NEW (2.23): lets the app's sound (🔊 Listen, the voice-changed sentence, the original recording, the background audio
 * previews) be heard WHILE a phone / WhatsApp / other call is going on.
 *
 * Why it was silent: every player here asks the phone for plain "media" sound. While a call is active, Android keeps
 * media sound quiet (or fades it away) so it does not disturb the call - but sound that is marked as "voice
 * communication" is let through and follows the call's own volume and route (earpiece / speaker / headset).
 *
 * So: when NO call is going on, [attributes] returns exactly what each player always used - nothing changes. When a
 * call IS going on, it returns the voice-communication kind instead. The check is made each time a sound starts, so it
 * adapts if a call begins or ends while you are working.
 *
 * Plain Android (no permission needed: reading the audio mode is allowed for every app).
 */
object CallAudio {
    @Volatile private var manager: AudioManager? = null

    /** Call once at start-up ([com.videoslidemaker.app.VideoSlideMakerApp]). */
    fun init(context: Context) {
        manager = context.applicationContext.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
    }

    /** True while a phone call or a VoIP call (WhatsApp, Meet, Zoom ...) is active on the phone. */
    fun inCall(): Boolean = try {
        when (manager?.mode) {
            AudioManager.MODE_IN_CALL, AudioManager.MODE_IN_COMMUNICATION -> true
            else -> false
        }
    } catch (_: Throwable) {
        false
    }

    /** The attributes a player should use: its own normal ones, or the call-friendly ones while a call is active. */
    fun attributes(normalUsage: Int, normalContentType: Int): AudioAttributes =
        if (inCall()) {
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build()
        } else {
            AudioAttributes.Builder()
                .setUsage(normalUsage)
                .setContentType(normalContentType)
                .build()
        }
}
