package com.videoslidemaker.app.ui.components

import androidx.compose.ui.draw.alpha

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.selection.selectableGroup
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.videoslidemaker.app.model.AppStep
import com.videoslidemaker.app.ui.theme.Accent
import com.videoslidemaker.app.ui.theme.BorderColor
import com.videoslidemaker.app.ui.theme.Green
import com.videoslidemaker.app.ui.theme.Muted
import com.videoslidemaker.app.ui.theme.OnAccent
import com.videoslidemaker.app.ui.theme.OnStatus
import com.videoslidemaker.app.ui.theme.Outline
import com.videoslidemaker.app.ui.theme.Surface

/**
 * The six steps. Where you are is never shown by colour alone:
 *  - the current step has a filled circle, bold label AND an underline bar,
 *  - finished steps show a tick,
 *  - steps still to do show an empty ring with their number.
 * Screen readers hear each one as a tab with its state ("Completed", "Current step", ...).
 */
@Composable
fun StepTabsBar(
    currentStep: AppStep,
    onStepClick: (AppStep) -> Unit,
    /** Steps that cannot be opened yet (shown dimmed). Tapping one still reports a click so the caller can explain why. */
    disabledSteps: Set<AppStep> = emptySet()
) {
    Column(
        Modifier
            .fillMaxWidth()
            .background(Surface)
    ) {
        Row(Modifier.fillMaxWidth().selectableGroup()) {
            AppStep.entries.forEach { step ->
                val isActive = step == currentStep
                val isDone = step.index < currentStep.index
                val isLocked = step in disabledSteps
                val stateText = when {
                    isLocked -> "Not available yet. Add photos first"
                    isActive -> "Current step"
                    isDone -> "Completed"
                    else -> "Not started"
                }
                Column(
                    Modifier
                        .weight(1f)
                        .heightIn(min = 60.dp)
                        .alpha(if (isLocked) 0.5f else 1f)
                        .selectable(selected = isActive, role = Role.Tab, onClick = { onStepClick(step) })
                        .semantics { stateDescription = stateText },
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Spacer(Modifier.height(8.dp))
                    when {
                        isDone -> Box(
                            Modifier.size(24.dp).clip(CircleShape).background(Green),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Filled.Check, contentDescription = null, tint = OnStatus, modifier = Modifier.size(15.dp))
                        }
                        isActive -> Box(
                            Modifier.size(24.dp).clip(CircleShape).background(Accent),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                "${step.index + 1}",
                                style = MaterialTheme.typography.labelSmall,
                                color = OnAccent,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        else -> Box(
                            Modifier.size(24.dp).clip(CircleShape).border(1.5.dp, Outline, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                "${step.index + 1}",
                                style = MaterialTheme.typography.labelSmall,
                                color = Muted,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                    Text(
                        step.label,
                        style = MaterialTheme.typography.labelSmall,
                        color = when {
                            isActive -> Accent
                            isDone -> Green
                            else -> Muted
                        },
                        fontWeight = if (isActive) FontWeight.Bold else FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(top = 3.dp, start = 2.dp, end = 2.dp)
                    )
                    Spacer(Modifier.height(7.dp))
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .height(3.dp)
                            .background(if (isActive) Accent else Color.Transparent)
                    )
                }
            }
        }
        Box(Modifier.fillMaxWidth().height(1.dp).background(BorderColor))
    }
}
