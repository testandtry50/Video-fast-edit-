package com.videoslidemaker.app.data

import android.content.Context
import android.net.Uri
import com.videoslidemaker.app.align.AlignmentState
import com.videoslidemaker.app.logoclean.CleanLog
import com.videoslidemaker.app.logoclean.CleanTarget
import com.videoslidemaker.app.logoclean.LogoCleanMode
import com.videoslidemaker.app.model.AppStep
import com.videoslidemaker.app.model.AspectRatioOption
import com.videoslidemaker.app.model.EffectStyle
import com.videoslidemaker.app.model.ExportSettings
import com.videoslidemaker.app.model.NarrationSettings
import com.videoslidemaker.app.model.OverlayStyle
import com.videoslidemaker.app.model.PoolImage
import com.videoslidemaker.app.model.QualityOption
import com.videoslidemaker.app.model.SentenceSlide
import com.videoslidemaker.app.model.TextOverlay
import com.videoslidemaker.app.model.TransitionStyle
import com.videoslidemaker.app.model.UiState
import com.videoslidemaker.app.voicefx.VoiceEffect
import com.videoslidemaker.app.voicefx.VoiceFxSettings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

/**
 * Saves and loads projects.
 *
 * NEW (2.14): many projects, not one. Every project is its own small file in `projects/<id>.json`, and `projects/index.json`
 * lists them with a one-line summary each. Only the project that is open is ever held in memory, and only that one
 * is ever re-written while you work - so ten projects of five hours each cost no more to work in than one.
 *
 * Earlier versions kept a single `project_draft.json`. The first time this version starts it is moved in as the first
 * project (nothing is lost, the file format inside is unchanged), and the old file is kept next to it as
 * `project_draft.json.migrated`.
 *
 * Photos and music stay wherever the user picked them from (their content Uri, plus the persisted read permission, is
 * what's saved). A project is saved to a temporary file first and then swapped in, so being closed or killed in the
 * middle of a (large, thousands-of-photos) write can never leave a half-written project behind. One lock keeps every
 * write (and the list) from ever happening at the same time.
 */
class ProjectRepository(context: Context) {
    private val dir = File(context.filesDir, "projects")
    private val indexFile = File(dir, "index.json")
    private val indexTemp = File(dir, "index.json.tmp")

    // The single-project files of version 2.13 and earlier.
    private val legacyFile = File(context.filesDir, "project_draft.json")
    private val legacyTemp = File(context.filesDir, "project_draft.json.tmp")
    private val legacyKept = File(context.filesDir, "project_draft.json.migrated")
    private val legacyScroll = File(context.filesDir, "scroll_positions.json")
    private val logoDir = File(context.filesDir, "logoclean")
    private val filesDirPath = context.filesDir

    private val saveLock = Mutex()

    /** The list as last read or written. Only touched while [saveLock] is held. */
    private var index = ProjectIndex()

    /** What [openLibrary] found: the list, and (only the first time after the update) which project the old single draft became. */
    data class Library(val index: ProjectIndex, val migratedId: String?)

    private fun fileOf(id: String) = File(dir, "$id.json")
    private fun tempOf(id: String) = File(dir, "$id.json.tmp")

    /** True when a saved file exists for this project (it may still be unreadable). */
    fun hasFile(id: String): Boolean = ProjectIndexCodec.isSafeId(id) && fileOf(id).exists()

    // ------------------------------------------------------------------------------------------ the list

    /** Reads the project list. The first time, moves an old single draft in as the first project. */
    suspend fun openLibrary(): Library = saveLock.withLock {
        withContext(Dispatchers.IO) {
            dir.mkdirs()
            var migrated: String? = null
            var loaded: ProjectIndex? = null
            try {
                if (indexFile.exists()) loaded = ProjectIndexCodec.decode(indexFile.readText())
            } catch (_: Exception) {
            }
            var result = loaded ?: ProjectIndex()
            if (loaded == null) {
                // No (readable) list yet: either the very first start of this version, or the list was damaged.
                // Projects whose files are still on disk are put back into the list rather than lost.
                result = rebuildFromFiles(result)
                if (result.projects.isEmpty() && legacyFile.exists()) {
                    val id = newId()
                    val now = System.currentTimeMillis()
                    if (copyFile(legacyFile, fileOf(id))) {
                        val stamp = legacyFile.lastModified().takeIf { it > 0L } ?: now
                        result = result
                            .plus(ProjectInfo(id, "Project 1", stamp, stamp))
                            .withActive(id)
                        migrated = id
                        // The old scroll positions belong to that project now.
                        if (legacyScroll.exists()) legacyScroll.renameTo(File(filesDirPath, scrollFileName(id)))
                    }
                }
            }
            index = result
            if (loaded == null && result.projects.isNotEmpty()) {
                writeIndexLocked()
                if (migrated != null && indexFile.exists()) {
                    legacyKept.delete()
                    if (!legacyFile.renameTo(legacyKept)) legacyFile.delete()
                    legacyTemp.delete()
                }
            }
            Library(index, migrated)
        }
    }

    /** Puts back into the list any project file that is on disk but missing from the list (a damaged list file). */
    private fun rebuildFromFiles(start: ProjectIndex): ProjectIndex {
        var result = start
        val files = dir.listFiles { f -> f.isFile && f.name.endsWith(".json") && f.name != "index.json" } ?: return result
        for (f in files.sortedBy { it.lastModified() }) {
            val id = f.name.removeSuffix(".json")
            if (!ProjectIndexCodec.isSafeId(id) || result.contains(id)) continue
            val stamp = f.lastModified().takeIf { it > 0L } ?: System.currentTimeMillis()
            result = result.plus(ProjectInfo(id, ProjectNames.unique("Recovered project", result.names), stamp, stamp))
        }
        return result
    }

    /** The list as it is now. */
    suspend fun snapshot(): ProjectIndex = saveLock.withLock { index }

    suspend fun setActive(id: String): ProjectIndex = saveLock.withLock {
        withContext(Dispatchers.IO) {
            index = index.withActive(id)
            writeIndexLocked()
            index
        }
    }

    /** Makes a new, empty project and adds it to the list. [name] blank = "Project 2" and so on. */
    suspend fun create(name: String?): Pair<ProjectInfo, ProjectIndex> = saveLock.withLock {
        withContext(Dispatchers.IO) {
            dir.mkdirs()
            val now = System.currentTimeMillis()
            val cleaned = ProjectNames.clean(name ?: "")
            val finalName = if (cleaned.isEmpty()) ProjectNames.nextDefault(index.names) else ProjectNames.unique(cleaned, index.names)
            val info = ProjectInfo(newId(), finalName, now, now)
            try {
                val temp = tempOf(info.id)
                temp.writeText(encode(UiState()).toString())
                swapIn(temp, fileOf(info.id))
            } catch (_: Exception) {
                // No file yet is fine: a project without a file opens as an empty one.
            }
            index = index.plus(info)
            writeIndexLocked()
            info to index
        }
    }

    /**
     * Copies a project as it is saved on disk (save the open project first if it is the one being copied). The cleaned
     * copies the logo cleaner made are copied too, so deleting a photo in one project can never break the other.
     */
    suspend fun duplicate(sourceId: String, name: String?): Pair<ProjectInfo, ProjectIndex>? = saveLock.withLock {
        withContext(Dispatchers.IO) {
            val source = index.find(sourceId) ?: return@withContext null
            val sourceFile = fileOf(sourceId)
            if (!sourceFile.exists()) return@withContext null
            try {
                val root = JSONObject(sourceFile.readText())
                copyCleanedPhotos(root)
                val now = System.currentTimeMillis()
                val cleaned = ProjectNames.clean(name ?: "")
                val finalName = if (cleaned.isEmpty()) ProjectNames.copyOf(source.name, index.names) else ProjectNames.unique(cleaned, index.names)
                val info = source.copy(id = newId(), name = finalName, createdAtMs = now, updatedAtMs = now)
                val temp = tempOf(info.id)
                temp.writeText(root.toString())
                swapIn(temp, fileOf(info.id))
                index = index.plus(info)
                writeIndexLocked()
                info to index
            } catch (_: Exception) {
                null
            }
        }
    }

    suspend fun rename(id: String, name: String): ProjectIndex = saveLock.withLock {
        withContext(Dispatchers.IO) {
            index = index.renamed(id, name, System.currentTimeMillis())
            writeIndexLocked()
            index
        }
    }

    /** Removes a project's file and its place in the list. (Cleaned copies are removed by the caller, see AppViewModel.) */
    suspend fun delete(id: String): ProjectIndex = saveLock.withLock {
        withContext(Dispatchers.IO) {
            if (ProjectIndexCodec.isSafeId(id)) {
                fileOf(id).delete()
                tempOf(id).delete()
                File(filesDirPath, scrollFileName(id)).delete()
            }
            index = index.minus(id)
            writeIndexLocked()
            index
        }
    }

    /** Updates a project's card (counts and length) without saving the project. Used right after opening one. */
    suspend fun refreshSummary(projectId: String, state: UiState): ProjectIndex = saveLock.withLock {
        withContext(Dispatchers.IO) {
            val before = index
            index = index.withSummary(projectId, slideCountOf(state), state.images.size, state.totalDurationSec, null)
            if (index !== before) writeIndexLocked()
            index
        }
    }

    private fun slideCountOf(state: UiState): Int = if (state.slides.isNotEmpty()) state.slides.size else state.images.size

    private fun newId(): String = UUID.randomUUID().toString().replace("-", "").take(16)

    private fun writeIndexLocked() {
        try {
            indexTemp.writeText(ProjectIndexCodec.encode(index))
            swapIn(indexTemp, indexFile)
        } catch (_: Exception) {
            // The list is small and is written again on the next save; failing once is not worth a crash.
        }
    }

    private fun copyFile(from: File, to: File): Boolean = try {
        from.copyTo(to, overwrite = true)
        true
    } catch (_: Exception) {
        false
    }

    /** Gives a copied project its OWN copies of the logo cleaner's pictures. A copy that can't be made falls back to the original photo. */
    private fun copyCleanedPhotos(root: JSONObject) {
        val images = root.optJSONArray("images") ?: return
        val logoPath = try { logoDir.canonicalPath } catch (_: Exception) { return }
        for (i in 0 until images.length()) {
            val obj = images.optJSONObject(i) ?: continue
            val original = obj.optString("origUri", "")
            if (original.isEmpty()) continue
            val uri = Uri.parse(obj.optString("uri", ""))
            if (uri.scheme != "file") continue
            val src = uri.path?.let { File(it) }
            var copied: File? = null
            if (src != null && src.exists() && src.parentFile?.canonicalPath == logoPath) {
                val ext = src.extension.ifEmpty { "jpg" }
                val target = File(src.parentFile, src.nameWithoutExtension + "_" + newId().take(6) + "." + ext)
                if (copyFile(src, target)) copied = target
            }
            if (copied != null) {
                obj.put("uri", Uri.fromFile(copied).toString())
            } else {
                // Cannot copy: point the copy at the untouched original photo, exactly what opening a project does.
                obj.put("uri", original)
                obj.remove("origUri")
                obj.remove("cleanMode")
                obj.remove("cleanLog")
            }
        }
    }

    private fun swapIn(temp: File, target: File) {
        if (!temp.renameTo(target)) {
            target.delete()
            temp.renameTo(target)
        }
    }

    // ------------------------------------------------------------------------------------------ one project

    /**
     * Writes one project. [projectId] is passed in by the caller together with the state, so a project can never be
     * written into another project's file. A project that was deleted in the meantime is not brought back.
     * Returns the updated list (new counts and "edited" time), or null if nothing was written.
     */
    suspend fun save(state: UiState, projectId: String): ProjectIndex? = saveLock.withLock {
        withContext(Dispatchers.IO) {
            try {
                if (!index.contains(projectId) || !ProjectIndexCodec.isSafeId(projectId)) return@withContext null
                val temp = tempOf(projectId)
                temp.writeText(encode(state).toString())
                swapIn(temp, fileOf(projectId))
                index = index.withSummary(projectId, slideCountOf(state), state.images.size, state.totalDurationSec, System.currentTimeMillis())
                writeIndexLocked()
                index
            } catch (_: Exception) {
                // Auto-save is best-effort; a failed write should never crash the app.
                null
            }
        }
    }

    private fun encode(state: UiState): JSONObject {
        val root = JSONObject()
        root.put("step", state.step.name)
        root.put("defaultDurationSec", state.settings.defaultDurationSec)
        root.put("voiceLocaleTag", state.settings.narration.voiceLocaleTag)
        root.put("narrationEnabled", state.settings.narration.enabled)
        root.put("audioSource", state.settings.narration.source.name)
        // voice changer
        val fx = state.settings.narration.voiceFx
        root.put("fxPitch", fx.pitchSemitones.toDouble())
        root.put("fxHumanize", fx.humanize.toDouble())
        root.put("fxBreaths", fx.breaths)
        root.put("fxEffect", fx.effect.name)
        root.put("fxAmount", fx.effectAmount.toDouble())
        root.put("fxSpeed", fx.effectSpeed.toDouble())
        root.put("effectStyle", state.settings.effectStyle.name)
        root.put("transitionStyle", state.settings.transitionStyle.name)
        root.put("aspectRatio", state.settings.aspectRatio.name)
        root.put("quality", state.settings.quality.name)
        // NEW (2.17): all sound edits (main clips, background tracks, smart mix). Replaces the old single musicUri/musicVolume.
        root.put("audio", com.videoslidemaker.app.audio.AudioCodec.encode(state.settings.audio))
        // timestamp alignment: which recording was chosen, and the auto-apply preference
        root.put("alignRecordingUri", state.alignment.recordingUri?.toString())
        root.put("alignRecordingName", state.alignment.recordingName)
        root.put("alignAutoApply", state.alignment.autoApply)
        // every applied timestamp adjustment, so "undo the last adjustment" still works after the app was closed
        root.put("adjustLog", com.videoslidemaker.app.adjust.AdjustLogCodec.encode(state.adjustLog))

        val slidesArray = JSONArray()
        state.slides.forEach { slide ->
            val obj = JSONObject()
            obj.put("t", slide.timestampSec)
            obj.put("text", slide.text)
            obj.put("assignedImageId", slide.assignedImageId)
            // the script's own timestamp, kept while an automatic correction is applied
            obj.put("origT", slide.originalTimestampSec)
            slidesArray.put(obj)
        }
        root.put("slides", slidesArray)

        val imagesArray = JSONArray()
        state.images.forEach { img ->
            val obj = JSONObject()
            obj.put("id", img.id)
            obj.put("uri", img.uri.toString())
            obj.put("name", img.displayName)
            obj.put("w", img.widthPx)
            obj.put("h", img.heightPx)
            obj.put("durationOverrideSec", img.durationOverrideSec)
            // logo cleaner: the photo currently points at a cleaned copy; remember the original too
            if (img.originalUri != null) {
                obj.put("origUri", img.originalUri.toString())
                obj.put("cleanMode", img.cleanMode?.name ?: LogoCleanMode.REMOVE.name)
                obj.put("cleanLog", CleanLog.encode(img.cleanLog))
            }
            imagesArray.put(obj)
        }
        root.put("images", imagesArray)

        val overlaysArray = JSONArray()
        state.textOverlays.forEach { ov ->
            val obj = JSONObject()
            obj.put("id", ov.id)
            obj.put("text", ov.text)
            obj.put("start", ov.startSec)
            obj.put("duration", ov.durationSec)
            obj.put("xFraction", ov.xFraction.toDouble())
            obj.put("yFraction", ov.yFraction.toDouble())
            obj.put("style", ov.style.name)
            overlaysArray.put(obj)
        }
        root.put("textOverlays", overlaysArray)

        return root
    }

    /** A saved number, or [default] when it is missing or not a number. */
    private fun fxNumber(root: JSONObject, key: String, default: Float): Float {
        val v = root.optDouble(key, default.toDouble())
        return if (v.isNaN()) default else v.toFloat()
    }

    /** Reads one project. Null if it has no file or the file can't be read (an unreadable file is kept as `<id>.json.corrupt`). */
    suspend fun load(projectId: String): UiState? = saveLock.withLock {
        withContext(Dispatchers.IO) {
            if (!ProjectIndexCodec.isSafeId(projectId)) return@withContext null
            val file = fileOf(projectId)
            try {
                if (!file.exists()) return@withContext null
                decode(JSONObject(file.readText()))
            } catch (_: Exception) {
                try { file.copyTo(File(dir, "$projectId.json.corrupt"), overwrite = true) } catch (_: Exception) {}
                null
            }
        }
    }

    private fun decode(root: JSONObject): UiState {

        val slides = mutableListOf<SentenceSlide>()
        val slidesArray = root.optJSONArray("slides") ?: JSONArray()
        for (i in 0 until slidesArray.length()) {
            val obj = slidesArray.getJSONObject(i)
            slides.add(
                SentenceSlide(
                    timestampSec = obj.getDouble("t"),
                    text = obj.optString("text", ""),
                    assignedImageId = if (obj.isNull("assignedImageId")) null else obj.optString("assignedImageId"),
                    originalTimestampSec = if (obj.isNull("origT")) null else obj.optDouble("origT").takeIf { !it.isNaN() }
                )
            )
        }

        val images = mutableListOf<PoolImage>()
        val imagesArray = root.optJSONArray("images") ?: JSONArray()
        for (i in 0 until imagesArray.length()) {
            val obj = imagesArray.getJSONObject(i)
            var uri = Uri.parse(obj.getString("uri"))
            var originalUri: Uri? = obj.optString("origUri", "").takeIf { it.isNotEmpty() }?.let { Uri.parse(it) }
            var cleanMode: LogoCleanMode? = LogoCleanMode.entries.firstOrNull { it.name == obj.optString("cleanMode") }
            // 2.9: what was cleaned per target. A draft saved before 2.9 only knows the logo cleaner existed.
            var cleanLog: Map<CleanTarget, LogoCleanMode> = CleanLog.decode(obj.optString("cleanLog", ""))
            if (cleanLog.isEmpty() && originalUri != null && cleanMode != null) {
                cleanLog = mapOf(CleanTarget.LOGO to cleanMode)
            }
            // logo cleaner: if the cleaned copy has gone missing, fall back to the original photo
            if (originalUri != null) {
                val cleanedFile = if (uri.scheme == "file") uri.path?.let { File(it) } else null
                if (cleanedFile != null && !cleanedFile.exists()) {
                    uri = originalUri
                    originalUri = null
                    cleanMode = null
                    cleanLog = emptyMap()
                }
            } else {
                cleanMode = null
                cleanLog = emptyMap()
            }
            images.add(
                PoolImage(
                    id = obj.getString("id"),
                    uri = uri,
                    displayName = obj.optString("name", "photo"),
                    widthPx = obj.optInt("w", 0),
                    heightPx = obj.optInt("h", 0),
                    durationOverrideSec = if (obj.isNull("durationOverrideSec")) null else obj.optDouble("durationOverrideSec").takeIf { !it.isNaN() },
                    originalUri = originalUri,
                    cleanMode = cleanMode,
                    cleanLog = cleanLog
                )
            )
        }

        val musicUriStr = root.optString("musicUri", "")
        val settings = ExportSettings(
            aspectRatio = AspectRatioOption.entries.firstOrNull { it.name == root.optString("aspectRatio") }
                ?: AspectRatioOption.R16_9,
            quality = QualityOption.entries.firstOrNull { it.name == root.optString("quality") }
                ?: QualityOption.P720,
            effectStyle = EffectStyle.entries.firstOrNull { it.name == root.optString("effectStyle") }
                ?: EffectStyle.ZOOM_IN,
            transitionStyle = TransitionStyle.entries.firstOrNull { it.name == root.optString("transitionStyle") }
                ?: TransitionStyle.FADE_BLACK,
            defaultDurationSec = root.optInt("defaultDurationSec", 3),
            narration = NarrationSettings(
                enabled = root.optBoolean("narrationEnabled", true),
                voiceLocaleTag = root.optString("voiceLocaleTag", "hi-IN"),
                source = com.videoslidemaker.app.model.AudioSource.entries
                    .firstOrNull { it.name == root.optString("audioSource") }
                    ?: com.videoslidemaker.app.model.AudioSource.VOICE,
                voiceFx = VoiceFxSettings(
                    pitchSemitones = fxNumber(root, "fxPitch", 0f).coerceIn(-VoiceFxSettings.MAX_PITCH_ST, VoiceFxSettings.MAX_PITCH_ST),
                    humanize = fxNumber(root, "fxHumanize", 0f).coerceIn(0f, 1f),
                    breaths = root.optBoolean("fxBreaths", false),
                    effect = VoiceEffect.entries.firstOrNull { it.name == root.optString("fxEffect") } ?: VoiceEffect.NONE,
                    effectAmount = fxNumber(root, "fxAmount", 0.6f).coerceIn(0f, 1f),
                    effectSpeed = fxNumber(root, "fxSpeed", 0.5f).coerceIn(0f, 1f)
                )
            ),
            // NEW (2.17): a project saved before the Audio step has its one music file moved into the background list,
            // set up to sound exactly as it did (looping, its own volume, nothing automatic).
            audio = if (root.has("audio")) {
                com.videoslidemaker.app.audio.AudioCodec.decode(root.optString("audio", ""))
            } else if (musicUriStr.isNotBlank()) {
                com.videoslidemaker.app.audio.AudioCodec.fromLegacyMusic(
                    musicUriStr,
                    Uri.parse(musicUriStr).lastPathSegment,
                    root.optDouble("musicVolume", 0.35).toFloat()
                )
            } else {
                com.videoslidemaker.app.audio.AudioMixSettings()
            }
        )

        val overlays = mutableListOf<TextOverlay>()
        val overlaysArray = root.optJSONArray("textOverlays") ?: JSONArray()
        for (i in 0 until overlaysArray.length()) {
            val obj = overlaysArray.getJSONObject(i)
            overlays.add(
                TextOverlay(
                    id = obj.getString("id"),
                    text = obj.optString("text", ""),
                    startSec = obj.optDouble("start", 0.0),
                    durationSec = obj.optDouble("duration", 3.0),
                    xFraction = obj.optDouble("xFraction", 0.5).toFloat(),
                    yFraction = obj.optDouble("yFraction", 0.85).toFloat(),
                    style = OverlayStyle.entries.firstOrNull { it.name == obj.optString("style") }
                        ?: OverlayStyle.TAG
                )
            )
        }

        // If the app was closed by Android while the folder picker was open, come back to the
        // screen you were on (Photos) instead of being bounced to the Script screen.
        val savedStep = AppStep.entries.firstOrNull { it.name == root.optString("step") }
        val restoredStep: AppStep = when {
            savedStep == AppStep.SCRIPT -> AppStep.SCRIPT
            savedStep == AppStep.PHOTOS -> AppStep.PHOTOS
            slides.isNotEmpty() -> AppStep.PHOTOS
            else -> AppStep.SCRIPT
        }

        return UiState(
            step = restoredStep,
            scriptLoaded = slides.isNotEmpty(),
            slides = slides,
            images = images,
            settings = settings,
            textOverlays = overlays,
            alignment = AlignmentState(
                recordingUri = root.optString("alignRecordingUri", "").takeIf { it.isNotBlank() }?.let { Uri.parse(it) },
                recordingName = root.optString("alignRecordingName", "").takeIf { it.isNotBlank() },
                autoApply = root.optBoolean("alignAutoApply", false)
            ),
            adjustLog = com.videoslidemaker.app.adjust.AdjustLogCodec.decode(root.optString("adjustLog", ""))
        )
    }

    companion object {
        /** Where the scroll positions of one project are kept (see ScrollMemory). */
        fun scrollFileName(projectId: String): String = "scroll_$projectId.json"
    }
}
