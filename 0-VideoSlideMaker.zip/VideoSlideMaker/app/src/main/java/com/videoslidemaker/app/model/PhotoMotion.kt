package com.videoslidemaker.app.model

import kotlin.math.max
import kotlin.math.min

/**
 * What ONE photo does while it is on screen. The Photo Effect setting (see [EffectStyle]) is turned into
 * one of these per photo by [PhotoMotion.plan] - a "mix" effect simply gives different photos different moves.
 */
enum class PhotoMove { STILL, ZOOM_IN, ZOOM_OUT, PAN_LEFT, PAN_RIGHT }

/**
 * Where the photo sits at one moment. [scale] is 1 for the whole cover-fitted photo and bigger when zoomed in.
 * [panX] says which part of the zoomed photo is in view: 0 = its left edge, 0.5 = centred, 1 = its right edge.
 */
data class MotionFrame(val scale: Float, val panX: Float)

/**
 * The motion of a photo, in one place, with no Android code in it.
 *
 * Before this file existed the Preview and the exporter each had their own copy of the zoom / pan numbers,
 * and the copies had drifted apart (the preview's "Pan Left" moved the opposite way to the exported video's,
 * for example). Now both ask this object, so what you preview is what you export.
 */
object PhotoMotion {

    /** How much a zoom covers: 0.15 = the photo grows by 15% over its time on screen (it used to be 6%, which was
     *  hard to even notice on a phone screen). Change this one number to make every zoom gentler or stronger. */
    const val ZOOM_AMOUNT = 0.15f

    /** How far in the photo is held while it pans, so there is a margin to slide across. */
    const val PAN_SCALE = 1.12f

    /** The "Mix" order, repeated: this photo zooms in, the next zooms out, then in, in, out ... */
    private val MIX_PATTERN = listOf(
        PhotoMove.ZOOM_IN, PhotoMove.ZOOM_OUT, PhotoMove.ZOOM_IN, PhotoMove.ZOOM_IN, PhotoMove.ZOOM_OUT
    )

    private val RANDOM_CHOICES = listOf(
        PhotoMove.ZOOM_IN, PhotoMove.ZOOM_OUT, PhotoMove.PAN_LEFT, PhotoMove.PAN_RIGHT
    )

    /**
     * The move of every photo, in order, for [style]. Computed once for the whole video, so the preview and the export
     * always agree, and the answer for photo N never changes when photos are added after it.
     */
    fun plan(style: EffectStyle, count: Int): List<PhotoMove> {
        if (count <= 0) return emptyList()
        return when (style) {
            EffectStyle.NONE -> List(count) { PhotoMove.STILL }
            EffectStyle.ZOOM_IN -> List(count) { PhotoMove.ZOOM_IN }
            EffectStyle.ZOOM_OUT -> List(count) { PhotoMove.ZOOM_OUT }
            EffectStyle.PAN_LEFT -> List(count) { PhotoMove.PAN_LEFT }
            EffectStyle.PAN_RIGHT -> List(count) { PhotoMove.PAN_RIGHT }
            EffectStyle.ZOOM_ALTERNATE -> List(count) { i -> if (i % 2 == 0) PhotoMove.ZOOM_IN else PhotoMove.ZOOM_OUT }
            EffectStyle.ZOOM_MIX -> List(count) { i -> MIX_PATTERN[i % MIX_PATTERN.size] }
            EffectStyle.RANDOM_MIX -> randomPlan(count)
        }
    }

    /** A fixed pseudo-random shuffle (always the same for the same photo count - it is NOT different each time),
     *  that never gives two neighbouring photos the same move. */
    private fun randomPlan(count: Int): List<PhotoMove> {
        val result = ArrayList<PhotoMove>(count)
        var seed = 0x2F6E2B1L
        var previous: PhotoMove? = null
        for (i in 0 until count) {
            seed = (seed * 1103515245L + 12345L) and 0x7FFFFFFFL
            var pick = RANDOM_CHOICES[((seed shr 8) % RANDOM_CHOICES.size).toInt()]
            if (pick == previous) {
                pick = RANDOM_CHOICES[(RANDOM_CHOICES.indexOf(pick) + 1) % RANDOM_CHOICES.size]
            }
            result.add(pick)
            previous = pick
        }
        return result
    }

    /** Where the photo is when it is [progress] (0 = its first moment on screen, 1 = its last) through its time slot. */
    fun frameAt(move: PhotoMove, progress: Float): MotionFrame {
        val p = if (progress.isNaN()) 0f else progress.coerceIn(0f, 1f)
        return when (move) {
            PhotoMove.STILL -> MotionFrame(1f, 0.5f)
            PhotoMove.ZOOM_IN -> MotionFrame(1f + ZOOM_AMOUNT * p, 0.5f)
            PhotoMove.ZOOM_OUT -> MotionFrame(1f + ZOOM_AMOUNT * (1f - p), 0.5f)
            // The camera pans LEFT: the view starts at the right of the photo and ends at the left of it.
            PhotoMove.PAN_LEFT -> MotionFrame(PAN_SCALE, 1f - p)
            PhotoMove.PAN_RIGHT -> MotionFrame(PAN_SCALE, p)
        }
    }
}

/** What one photo layer looks like at one moment of the preview: how see-through it is, how far it is slid
 *  sideways (as a fraction of the frame width; 1 = one whole frame to the right), and how far through its own slot it is. */
data class LayerLook(val alpha: Float, val shift: Float, val progress: Float)

/**
 * How photos change into each other - the same numbers the exporter uses, so the preview shows the real thing.
 *
 * Crossfade and Slide take place in the LAST [BLEND_SEC] of the outgoing photo's slot, so the next photo is fully
 * in place at the exact moment its sentence starts. Fade to Black fades each photo in and out at its own ends.
 */
object TransitionMath {

    /** Length of a crossfade, a slide, or one side of a fade to black. */
    const val BLEND_SEC = 0.4

    /** The crossfade / slide never takes more than a third of a photo's time. */
    fun blendSeconds(slotSec: Double): Double = min(slotSec / 3.0, BLEND_SEC)

    /** 0 until the blend starts, then rises to 1 at the end of the slot. [posInSlot] is seconds since the slot began. */
    fun blendT(posInSlot: Double, slotSec: Double): Float {
        val len = blendSeconds(slotSec)
        if (len <= 0.0) return 0f
        return ((posInSlot - (slotSec - len)) / len).coerceIn(0.0, 1.0).toFloat()
    }

    /** Fraction of a slot spent fading in from black (and the same again fading out to black). */
    fun fadeFraction(slotSec: Double): Float = min(0.5, BLEND_SEC / max(slotSec, 0.1)).toFloat()

    /** How visible a photo is under "Fade to Black", [progress] (0..1) through its slot. */
    fun fadeBlackAlpha(progress: Float, slotSec: Double): Float {
        val ff = fadeFraction(slotSec)
        if (ff <= 0f) return 1f
        var a = 1f
        if (progress < ff) a = min(a, progress / ff)
        if (progress > 1f - ff) a = min(a, (1f - progress) / ff)
        return a.coerceIn(0f, 1f)
    }

    private val HIDDEN = LayerLook(0f, 0f, 0f)

    /**
     * The look of the layer for the photo whose slot starts at [slideStart] (seconds) and lasts [slideDur], when the
     * preview is at [posSec]. [prevDur] is the length of the slot before it (0 for the first photo) and [hasNext]
     * says whether a photo follows. The preview draws this photo, and the next one on top of it, and that is all.
     */
    fun layerLook(
        style: TransitionStyle,
        posSec: Double,
        slideStart: Double,
        slideDur: Double,
        prevDur: Double,
        hasNext: Boolean
    ): LayerLook {
        val dur = max(0.1, slideDur)
        var local = posSec - slideStart
        // The FIRST photo has nothing before it, so it is simply shown from the very start (even when the script's
        // first timestamp is later than 0:00), exactly as the exported video begins with it.
        if (local < 0.0 && prevDur <= 0.0) local = 0.0
        if (local < 0.0) {
            // This photo has not started yet: it only shows while it blends in over the end of the previous slot.
            if (prevDur <= 0.0) return HIDDEN
            val t = blendT(local + prevDur, prevDur)
            return when (style) {
                TransitionStyle.CROSSFADE -> if (t > 0f) LayerLook(t, 0f, 0f) else HIDDEN
                TransitionStyle.SLIDE -> if (t > 0f) LayerLook(1f, 1f - t, 0f) else HIDDEN
                else -> HIDDEN
            }
        }
        val progress = (local / dur).toFloat().coerceIn(0f, 1f)
        return when (style) {
            TransitionStyle.FADE_BLACK -> LayerLook(fadeBlackAlpha(progress, dur), 0f, progress)
            TransitionStyle.SLIDE -> LayerLook(1f, if (hasNext) -blendT(local, dur) else 0f, progress)
            else -> LayerLook(1f, 0f, progress)
        }
    }
}
