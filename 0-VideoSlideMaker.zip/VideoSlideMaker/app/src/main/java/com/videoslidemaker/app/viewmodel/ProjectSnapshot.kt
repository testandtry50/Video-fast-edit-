package com.videoslidemaker.app.viewmodel

import com.videoslidemaker.app.model.ExportSettings
import com.videoslidemaker.app.model.PoolImage
import com.videoslidemaker.app.model.SentenceSlide
import com.videoslidemaker.app.model.TextOverlay
import com.videoslidemaker.app.model.UiState

/**
 * NEW: everything Undo / Redo can bring back - the project itself, not which screen you are on,
 * what is playing or how far an export has got. All of it is immutable, so keeping many of these
 * costs only a few references each, even with thousands of photos.
 */
data class ProjectSnapshot(
    val slides: List<SentenceSlide>,
    val images: List<PoolImage>,
    val textOverlays: List<TextOverlay>,
    val settings: ExportSettings,
    val scriptLoaded: Boolean,
    /** The sentence you were on, so undoing a photo pick also takes you back to that sentence. */
    val matchIndex: Int
) {
    /** True when the project DATA is the same (the sentence you are looking at is not data). */
    fun sameDataAs(other: ProjectSnapshot): Boolean =
        scriptLoaded == other.scriptLoaded &&
            (settings === other.settings || settings == other.settings) &&
            (slides === other.slides || slides == other.slides) &&
            (images === other.images || images == other.images) &&
            (textOverlays === other.textOverlays || textOverlays == other.textOverlays)

    companion object {
        fun of(state: UiState) = ProjectSnapshot(
            slides = state.slides,
            images = state.images,
            textOverlays = state.textOverlays,
            settings = state.settings,
            scriptLoaded = state.scriptLoaded,
            matchIndex = state.curMatchIndex
        )
    }
}

/** A few plain words for what changed between [before] and [after], shown as "Undo: ..." */
fun describeChange(before: ProjectSnapshot, after: ProjectSnapshot): String {
    if (before.scriptLoaded != after.scriptLoaded ||
        (before.slides.isEmpty() != after.slides.isEmpty())
    ) return "script"

    if (before.images.size != after.images.size) {
        return if (after.images.size > before.images.size) "photos added" else "photos removed"
    }
    if (before.images != after.images) {
        val beforeIds = before.images.map { it.id }
        val afterIds = after.images.map { it.id }
        if (beforeIds != afterIds) return "photo order"
        val anyUriChanged = before.images.indices.any { before.images[it].uri != after.images[it].uri }
        return if (anyUriChanged) "logo cleaning" else "photo time"
    }

    if (before.slides.size != after.slides.size) return "sentence split or merge"
    if (before.slides != after.slides) {
        val assignmentChanged = before.slides.indices.any {
            before.slides[it].assignedImageId != after.slides[it].assignedImageId
        }
        if (assignmentChanged) return "photo match"
        val textChanged = before.slides.indices.any { before.slides[it].text != after.slides[it].text }
        if (textChanged) return "sentence text"
        return "timestamps"
    }

    if (before.textOverlays != after.textOverlays) return "name text"
    if (before.settings != after.settings) return "settings"
    return "change"
}
