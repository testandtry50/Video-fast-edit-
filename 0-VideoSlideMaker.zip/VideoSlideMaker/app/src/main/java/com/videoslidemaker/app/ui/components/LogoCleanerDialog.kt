package com.videoslidemaker.app.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import coil.request.ImageRequest
import coil.size.Scale
import com.videoslidemaker.app.logoclean.BulkMath
import com.videoslidemaker.app.logoclean.CleanAllMode
import com.videoslidemaker.app.logoclean.CleanLog
import com.videoslidemaker.app.logoclean.CleanTarget
import com.videoslidemaker.app.logoclean.CleanUnit
import com.videoslidemaker.app.logoclean.LogoBox
import com.videoslidemaker.app.logoclean.LogoCleanController
import com.videoslidemaker.app.logoclean.LogoCleanMode
import com.videoslidemaker.app.logoclean.LogoCleanUi
import com.videoslidemaker.app.model.PoolImage
import com.videoslidemaker.app.ui.theme.Accent
import com.videoslidemaker.app.ui.theme.Bg
import com.videoslidemaker.app.ui.theme.BorderColor
import com.videoslidemaker.app.ui.theme.CardBg
import com.videoslidemaker.app.ui.theme.Green
import com.videoslidemaker.app.ui.theme.Muted
import com.videoslidemaker.app.ui.theme.Outline
import com.videoslidemaker.app.ui.theme.Red
import com.videoslidemaker.app.ui.theme.Surface
import com.videoslidemaker.app.ui.theme.TextMain
import kotlin.math.max
import kotlin.math.min

/**
 * Logo, icon, subtitle & text cleaner. Shows one photo with a box over the thing to clean (drag the box, drag a
 * corner to resize, or drag on an empty spot to draw a new one), and lets the user remove or blur just that - in
 * this photo (or segment) only, in a RANGE of them, or in ALL of them at once (built for 100,000+ photos, with a
 * live percent / speed / time-left card).
 *
 * Three things can be cleaned ([CleanTarget]): a logo / icon / watermark (found by what repeats across the photos:
 * "Find the logo automatically", "One tap"), a subtitle, or any other text (both found photo by photo inside the
 * box, and only the letters are repainted). The three modes are Remove, Blur, and Remove + Blur. The original
 * photos are never changed and can be restored; cleaning a second thing (the subtitle, after the logo) keeps the
 * first.
 *
 * [units] are the steps to page through. Null = one step per photo. The Match screen passes one per SEGMENT of the
 * video (a line of the script, with the photo it shows) and [unitWord] = "segment", so "this segment", "segments
 * 12 to 40" and "all segments" mean what the person sees there. [startUnit] is the step to open on.
 */
@Composable
fun LogoCleanerDialog(
    images: List<PoolImage>,
    ui: LogoCleanUi,
    controller: LogoCleanController,
    onDismiss: () -> Unit,
    units: List<CleanUnit>? = null,
    unitWord: String = "photo",
    startUnit: Int = 0
) {
    val unitCount = units?.size ?: images.size
    var index by remember { mutableIntStateOf(startUnit) }
    var box by remember { mutableStateOf(LogoBox.DEFAULT) }
    var target by remember { mutableStateOf(CleanTarget.LOGO) }
    var mode by remember { mutableStateOf(LogoCleanMode.REMOVE) }
    var strength by remember { mutableFloatStateOf(0.4f) }
    var how by remember { mutableStateOf(CleanAllMode.WHERE_FOUND) }
    var reach by remember { mutableStateOf(Reach.ONE) }
    var fromText by remember { mutableStateOf("1") }
    var toText by remember { mutableStateOf("1") }
    var skipCleaned by remember { mutableStateOf(true) }
    // null = no question showing; false = "clean all" waiting for a yes; true = "one tap" waiting for a yes
    var confirmAuto by remember { mutableStateOf<Boolean?>(null) }

    // when an automatic scan finishes, put the box on the logo it found
    LaunchedEffect(ui.scanSerial) {
        if (target == CleanTarget.LOGO) ui.candidates.getOrNull(ui.selected)?.let { box = it.box }
    }

    val busy = ui.scanning || ui.working
    val safeIndex = index.coerceIn(0, max(0, unitCount - 1))
    val image: PoolImage? = if (units == null) images.getOrNull(safeIndex)
    else units.getOrNull(safeIndex)?.let { step -> images.firstOrNull { it.id == step.imageId } }
    val cleanedCount = remember(images) { images.count { it.originalUri != null } }

    val word = unitWord
    val words = unitWord + "s"
    val rangeFrom = (fromText.toIntOrNull() ?: 1).coerceIn(1, max(1, unitCount))
    val rangeTo = (toText.toIntOrNull() ?: unitCount).coerceIn(1, max(1, unitCount))
    val lo = min(rangeFrom, rangeTo)
    val hi = max(rangeFrom, rangeTo)

    fun imageIdAt(i: Int): String = units?.get(i)?.imageId ?: images[i].id

    /** Which photos a "clean many" run touches. Null = every photo. */
    fun scopeIds(): Set<String>? = when (reach) {
        Reach.ONE -> null
        Reach.ALL -> if (units == null) null else units.map { it.imageId }.toSet()
        Reach.RANGE -> {
            val ids = HashSet<String>()
            for (i in lo - 1 until hi) ids.add(imageIdAt(i))
            ids
        }
    }

    // How many different photos the chosen reach covers (a photo can be shown by several segments).
    val scopeCount = remember(reach, lo, hi, units, images.size) {
        when (reach) {
            Reach.ONE -> 1
            Reach.ALL -> if (units == null) images.size else units.map { it.imageId }.toSet().size
            Reach.RANGE -> if (unitCount == 0) 0 else if (units == null) hi - lo + 1 else units.subList(lo - 1, hi).map { it.imageId }.toSet().size
        }
    }

    fun runAll(auto: Boolean) {
        val ids = scopeIds()
        if (auto) controller.autoCleanAll(mode, strength, how == CleanAllMode.WHERE_FOUND_MOVING, skipCleaned, ids)
        else controller.cleanAll(box, mode, strength, how, skipCleaned, target, ids)
    }
    // A big run asks "are you sure?" first; a handful of photos just starts.
    fun requestAll(auto: Boolean) {
        if (scopeCount >= BIG_RUN) confirmAuto = auto else runAll(auto)
    }

    fun pickTarget(t: CleanTarget) {
        if (t == target) return
        target = t
        // "Even if the logo moves" means nothing for text
        if (t.isText && how == CleanAllMode.WHERE_FOUND_MOVING) how = CleanAllMode.WHERE_FOUND
        // a fresh box lands where that kind of thing usually is
        if (t == CleanTarget.SUBTITLE && box.near(LogoBox.DEFAULT, 0.02f)) box = CleanTarget.SUBTITLE_BOX
        if (t == CleanTarget.LOGO && box.near(CleanTarget.SUBTITLE_BOX, 0.02f)) box = LogoBox.DEFAULT
    }

    val asking = confirmAuto
    if (asking != null) {
        val ids = scopeIds()
        val scoped = if (ids == null) images else images.filter { it.id in ids }
        val toDo = if (skipCleaned) scoped.count { it.cleanLog[target] != mode } else scoped.size
        val needBytes = controller.estimateStorageBytes(scoped.filter { it.originalUri == null })
        AlertDialog(
            onDismissRequest = { confirmAuto = null },
            containerColor = CardBg,
            titleContentColor = TextMain,
            textContentColor = TextMain,
            title = {
                Text(
                    if (asking) "Find the logo and clean ALL photos?"
                    else "Clean ${BulkMath.formatCount(toDo)} photos?"
                )
            },
            text = {
                Text(
                    (if (asking) "I'll look for the logo that repeats first, then clean every photo that has it.\n\n" else "") +
                        "\u2022 ${mode.label} on up to ${BulkMath.formatCount(toDo)} photos.\n" +
                        "\u2022 About ${BulkMath.formatBytes(needBytes)} of storage will be used " +
                        "(${BulkMath.formatBytes(controller.freeStorageBytes())} is free).\n" +
                        "\u2022 A big run can take a long time. You can leave the app or lock the screen - it keeps going " +
                        "and shows its progress in a notification.\n" +
                        "\u2022 Stop any time. What is finished stays finished, and pressing the button again carries on.\n" +
                        "\u2022 Your original photos are never changed.",
                    style = MaterialTheme.typography.bodyMedium
                )
            },
            confirmButton = {
                TextButton(onClick = { confirmAuto = null; runAll(asking) }) { Text("Start", fontWeight = FontWeight.Bold) }
            },
            dismissButton = {
                TextButton(onClick = { confirmAuto = null }) { Text("Cancel") }
            }
        )
    }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(
            Modifier
                .fillMaxSize()
                .background(Bg)
                .systemBarsPadding()
        ) {
            Row(Modifier.fillMaxWidth().padding(start = 4.dp, end = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Filled.Close, contentDescription = "Close the cleaner", tint = TextMain)
                }
                Text("Logo, icon, subtitle & text cleaner", color = TextMain, style = MaterialTheme.typography.titleMedium)
            }

            // Pinned above the scrolling part, so the percent stays in view however far down the person scrolls.
            if (ui.working && ui.bulk) {
                BulkProgressCard(
                    ui = ui,
                    onStop = { controller.cancel() },
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
                )
            }

            Column(
                Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                if (image == null) {
                    Text("Add some photos first.", color = Muted, style = MaterialTheme.typography.bodyMedium)
                    return@Column
                }

                LogoBoxEditor(image = image, box = box, onBoxChange = { box = it })

                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    TextButton(onClick = { index = safeIndex - 1 }, enabled = safeIndex > 0) { Text("‹ Previous") }
                    Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            "${word.replaceFirstChar { it.uppercase() }} ${safeIndex + 1} of $unitCount",
                            color = TextMain, style = MaterialTheme.typography.labelLarge
                        )
                        units?.getOrNull(safeIndex)?.label?.takeIf { it.isNotBlank() }?.let { label ->
                            Text(
                                label, color = Muted, style = MaterialTheme.typography.labelSmall,
                                maxLines = 1, textAlign = TextAlign.Center
                            )
                        }
                        val doneText = CleanLog.label(image.cleanLog).ifEmpty { image.cleanMode?.doneLabel ?: "" }
                        if (doneText.isNotEmpty()) {
                            Text(doneText, color = Green, style = MaterialTheme.typography.labelMedium)
                        }
                    }
                    TextButton(onClick = { index = safeIndex + 1 }, enabled = safeIndex < unitCount - 1) { Text("Next ›") }
                }

                // ---- what to clean
                Text("What do you want to clean?", color = TextMain, style = MaterialTheme.typography.titleSmall)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    for (t in CleanTarget.entries) {
                        ChoiceChip(t.label, target == t, { pickTarget(t) }, Modifier.weight(1f))
                    }
                }
                Text(
                    when (target) {
                        CleanTarget.LOGO ->
                            "Drag the box onto the logo, icon or watermark. Drag a corner to resize it, or drag on an " +
                                "empty spot to draw a new box. Keep it tight around just the logo."
                        CleanTarget.SUBTITLE ->
                            "Drag the box over the subtitle lines (it starts as a strip near the bottom). Every photo is " +
                                "checked on its own, and only the letters are repainted - not the whole box."
                        CleanTarget.TEXT ->
                            "Drag the box around the text: a title, a name, a number. Every photo is checked on its own, " +
                                "and only the letters are repainted - not the whole box."
                    },
                    color = Muted, style = MaterialTheme.typography.bodySmall
                )

                // ---- automatic search (a logo repeats across photos; text does not)
                if (target == CleanTarget.LOGO) {
                    if (ui.scanning) {
                        Text(
                            if (ui.total > 0) "Scanning photos… ${ui.done} of ${ui.total}" else "Scanning photos…",
                            color = TextMain, style = MaterialTheme.typography.bodyMedium
                        )
                        AppProgressBar(if (ui.total > 0) ui.done.toFloat() / ui.total else 0f)
                        TextButton(onClick = { controller.cancel() }) { Text("Stop") }
                    } else {
                        SecondaryButton("🔍 Find the logo automatically", enabled = !busy) { controller.scan() }
                    }
                    if (ui.candidates.isNotEmpty()) {
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            ui.candidates.forEachIndexed { i, c ->
                                ChoiceChip(
                                    text = "Logo ${i + 1} · in ${Math.round(c.support * 100)}% of photos",
                                    selected = ui.selected == i && box.near(c.box),
                                    onClick = {
                                        controller.selectCandidate(i)
                                        box = c.box
                                    }
                                )
                            }
                        }
                    }
                }

                // ---- what to do
                Text("What to do with the ${target.noun}", color = TextMain, style = MaterialTheme.typography.titleSmall)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ChoiceChip("Remove", mode == LogoCleanMode.REMOVE, { mode = LogoCleanMode.REMOVE }, Modifier.weight(1f))
                    ChoiceChip("Blur", mode == LogoCleanMode.BLUR, { mode = LogoCleanMode.BLUR }, Modifier.weight(1f))
                    ChoiceChip("Remove + Blur", mode == LogoCleanMode.BOTH, { mode = LogoCleanMode.BOTH }, Modifier.weight(1f))
                }
                Text(
                    if (target.isText) {
                        when (mode) {
                            LogoCleanMode.REMOVE ->
                                "Paints the letters out from the picture right around them, so the ${target.noun} looks " +
                                    "like it was never there. Works best on calm backgrounds."
                            LogoCleanMode.BLUR ->
                                "Smudges the words so they can't be read. A soft blur stays where the ${target.noun} was."
                            LogoCleanMode.BOTH ->
                                "Paints the letters out first, then softly blurs the repaired spot so no trace shows. " +
                                    "Use it when Remove alone leaves a faint ghost."
                        }
                    } else {
                        when (mode) {
                            LogoCleanMode.REMOVE ->
                                "Paints the logo out from the picture around it, so it looks like it was never there. " +
                                    "Works best on smooth or blurry backgrounds."
                            LogoCleanMode.BLUR ->
                                "Blurs only the logo so it can't be read. A soft smudge stays where it was."
                            LogoCleanMode.BOTH ->
                                "Does both: paints the logo out first, then softly blurs the repaired spot so no edge " +
                                    "or leftover trace shows. Use it when Remove alone leaves a faint patch."
                        }
                    },
                    color = Muted, style = MaterialTheme.typography.bodySmall
                )
                if (mode != LogoCleanMode.REMOVE) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Light", color = Muted, style = MaterialTheme.typography.labelMedium)
                        Slider(
                            value = strength,
                            onValueChange = { strength = it },
                            valueRange = 0f..1f,
                            colors = appSliderColors(),
                            modifier = Modifier.weight(1f).padding(horizontal = 8.dp)
                        )
                        Text("Strong", color = Muted, style = MaterialTheme.typography.labelMedium)
                    }
                }

                // ---- where: this one, a range, or all
                Text("Where to clean", color = TextMain, style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(top = 8.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ChoiceChip("This $word", reach == Reach.ONE, { reach = Reach.ONE }, Modifier.weight(1f))
                    ChoiceChip(
                        "A range", reach == Reach.RANGE,
                        {
                            reach = Reach.RANGE
                            if (fromText == "1" && toText == "1") {
                                fromText = (safeIndex + 1).toString()
                                toText = (safeIndex + 1).toString()
                            }
                        },
                        Modifier.weight(1f)
                    )
                    ChoiceChip("All ${BulkMath.formatCount(unitCount)}", reach == Reach.ALL, { reach = Reach.ALL }, Modifier.weight(1f))
                }
                if (reach == Reach.RANGE) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        NumberBox("From $word", fromText, { fromText = it }, Modifier.weight(1f))
                        NumberBox("To $word", toText, { toText = it }, Modifier.weight(1f))
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        CompactButton("Start here", { fromText = (safeIndex + 1).toString() })
                        CompactButton("End here", { toText = (safeIndex + 1).toString() })
                        CompactButton("To the last", { toText = unitCount.toString() })
                    }
                    Text(
                        "Cleans $words $lo to $hi (${BulkMath.formatCount(scopeCount)} ${if (scopeCount == 1) "photo" else "photos"}). " +
                            "Go to the first one with Previous / Next and press \"Start here\", then to the last one and " +
                            "press \"End here\" - or type the numbers.",
                        color = Muted, style = MaterialTheme.typography.bodySmall
                    )
                } else if (reach == Reach.ALL) {
                    Text(
                        "Cleans every $word (${BulkMath.formatCount(scopeCount)} ${if (scopeCount == 1) "photo" else "photos"}). " +
                            "Built for very large projects (tens of thousands of photos, 100,000+): several photos are " +
                            "cleaned at the same time, and you see the percent done, the speed and the time left.",
                        color = Muted, style = MaterialTheme.typography.bodySmall
                    )
                }

                // ---- how to find it in each photo (only for many photos)
                if (reach != Reach.ONE) {
                    if (target.isText) {
                        ChoiceChip(
                            "Only where text is found", how != CleanAllMode.SAME_SPOT,
                            { how = CleanAllMode.WHERE_FOUND }, Modifier.fillMaxWidth()
                        )
                        ChoiceChip(
                            "Everywhere in the box (no checking)", how == CleanAllMode.SAME_SPOT,
                            { how = CleanAllMode.SAME_SPOT }, Modifier.fillMaxWidth()
                        )
                        Text(
                            if (how == CleanAllMode.SAME_SPOT) {
                                "Also cleans short or faint text, and any thin lettering-like detail in the box. A photo " +
                                    "without a ${target.noun} may get a small smudge - check a few photos afterwards."
                            } else {
                                "Looks at every photo's box on its own and only cleans those where it finds text. Photos " +
                                    "without a ${target.noun} at that moment are left untouched. A one- or two-word " +
                                    "caption may be missed: use \"Everywhere in the box\" for those."
                            },
                            color = Muted, style = MaterialTheme.typography.bodySmall
                        )
                    } else {
                        ChoiceChip(
                            "Where the logo is found", how == CleanAllMode.WHERE_FOUND,
                            { how = CleanAllMode.WHERE_FOUND }, Modifier.fillMaxWidth()
                        )
                        ChoiceChip(
                            "Even if the logo moves", how == CleanAllMode.WHERE_FOUND_MOVING,
                            { how = CleanAllMode.WHERE_FOUND_MOVING }, Modifier.fillMaxWidth()
                        )
                        ChoiceChip(
                            "Exact spot, no checking (fastest)", how == CleanAllMode.SAME_SPOT,
                            { how = CleanAllMode.SAME_SPOT }, Modifier.fillMaxWidth()
                        )
                        Text(
                            when (how) {
                                CleanAllMode.WHERE_FOUND ->
                                    "Checks every photo for the logo at the same place and only cleans those. " +
                                        "Photos without it are left untouched."
                                CleanAllMode.WHERE_FOUND_MOVING ->
                                    "Also looks for the logo elsewhere in each photo, so it works when the logo moves. A little slower."
                                CleanAllMode.SAME_SPOT ->
                                    "Cleans the box on EVERY photo without checking whether a logo is there. " +
                                        "Use it if the checking misses some photos."
                            },
                            color = Muted, style = MaterialTheme.typography.bodySmall
                        )
                    }
                    SettingToggleRow(
                        label = "Skip photos that are already cleaned",
                        hint = "Lets you stop and carry on later without redoing work. Turn off to redo every photo " +
                            "with a new box or setting.",
                        checked = skipCleaned,
                        onCheckedChange = { skipCleaned = it }
                    )
                }

                // ---- go
                when (reach) {
                    Reach.ONE -> {
                        PrimaryButton("Clean this $word only", enabled = !busy) {
                            controller.cleanThis(image.id, box, mode, strength, target, how == CleanAllMode.SAME_SPOT)
                        }
                        if (ui.working && !ui.bulk) {
                            Text("Cleaning\u2026", color = TextMain, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                    Reach.RANGE -> PrimaryButton(
                        "Clean $words $lo to $hi", enabled = !busy && unitCount > 0
                    ) { requestAll(false) }
                    Reach.ALL -> PrimaryButton(
                        "Clean ALL ${BulkMath.formatCount(unitCount)} $words", enabled = !busy && unitCount > 0
                    ) { requestAll(false) }
                }
                if (target == CleanTarget.LOGO && reach != Reach.ONE) {
                    SecondaryButton("\u26A1 One tap: find the logo + clean", enabled = !busy && scopeCount > 1) {
                        requestAll(true)
                    }
                    Text(
                        "One tap looks for the logo that repeats across your photos by itself, then cleans every " +
                            "photo that has it - nothing to draw.",
                        color = Muted, style = MaterialTheme.typography.bodySmall
                    )
                }

                ui.message?.let { text ->
                    AlertBox(text, if (ui.messageIsProblem) AlertStyle.WARNING else AlertStyle.SUCCESS)
                }

                // ---- undo
                SecondaryButton("↩ Restore this $word", enabled = !busy && image.originalUri != null) {
                    controller.restore(image.id)
                }
                if (reach == Reach.RANGE) {
                    val ids = scopeIds()
                    val inRange = if (ids == null) 0 else images.count { it.id in ids && it.originalUri != null }
                    SecondaryButton("↩ Restore $words $lo to $hi (${BulkMath.formatCount(inRange)} cleaned)", enabled = !busy && inRange > 0) {
                        controller.restoreAll(scopeIds())
                    }
                }
                SecondaryButton(
                    "↩ Restore ALL photos (${BulkMath.formatCount(cleanedCount)} cleaned)",
                    enabled = !busy && cleanedCount > 0
                ) {
                    controller.restoreAll()
                }
                Text(
                    "Your original photos are never changed - cleaning saves a copy, and Restore switches back. " +
                        "You can clean the logo and then the subtitle: the second keeps the first. To start a photo " +
                        "over, restore it.",
                    color = Muted, style = MaterialTheme.typography.bodySmall, textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp)
                )
            }
        }
    }
}

/** How much one run covers: the photo (or segment) on screen, a range of them, or all of them. */
private enum class Reach { ONE, RANGE, ALL }

/** A small box for typing a whole number. */
@Composable
private fun NumberBox(label: String, value: String, onChange: (String) -> Unit, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(10.dp)
    Column(modifier) {
        Text(label, color = Muted, style = MaterialTheme.typography.labelMedium)
        BasicTextField(
            value = value,
            onValueChange = { raw -> onChange(raw.filter { it.isDigit() }.take(7)) },
            singleLine = true,
            textStyle = TextStyle(color = TextMain, fontSize = MaterialTheme.typography.bodyLarge.fontSize),
            cursorBrush = SolidColor(Accent),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 4.dp)
                .background(Surface, shape)
                .border(1.dp, Outline, shape)
                .padding(12.dp)
        )
    }
}

/** From this many photos on, "clean ALL" asks for a yes first (it can take a long time and a lot of storage). */
private const val BIG_RUN = 500

/** The big progress card for a run over many photos: percent, count, speed, time left, and what happened so far. */
@Composable
private fun BulkProgressCard(ui: LogoCleanUi, onStop: () -> Unit, modifier: Modifier = Modifier) {
    val percent = BulkMath.percent(ui.done, ui.total)
    val shape = RoundedCornerShape(16.dp)
    Column(
        modifier
            .fillMaxWidth()
            .clip(shape)
            .background(CardBg)
            .border(1.dp, Accent, shape)
            .padding(start = 16.dp, end = 8.dp, top = 8.dp, bottom = 12.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("$percent%", color = Accent, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    if (ui.stage.isNotEmpty()) ui.stage else "Working\u2026",
                    color = TextMain, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium
                )
                Text(
                    "${BulkMath.formatCount(ui.done)} of ${BulkMath.formatCount(ui.total)} photos",
                    color = Muted, style = MaterialTheme.typography.bodySmall
                )
            }
            TextButton(onClick = onStop) { Text("Stop", color = Red, fontWeight = FontWeight.Bold) }
        }
        AppProgressBar(if (ui.total > 0) ui.done.toFloat() / ui.total else 0f, Modifier.padding(end = 8.dp))
        val speed = if (ui.perSec > 0f) BulkMath.formatRate(ui.perSec) else ""
        val left = if (ui.etaSec >= 0) "about ${BulkMath.formatDuration(ui.etaSec)} left" else "working out the time left\u2026"
        Text(
            listOf(speed, left).filter { it.isNotEmpty() }.joinToString("  \u00B7  "),
            color = Muted, style = MaterialTheme.typography.bodySmall
        )
        if (ui.cleaned + ui.skipped + ui.failed > 0) {
            Text(
                "\u2714 ${BulkMath.formatCount(ui.cleaned)} cleaned   \u2022   ${BulkMath.formatCount(ui.skipped)} nothing found" +
                    "   \u2022   ${BulkMath.formatCount(ui.failed)} failed",
                color = TextMain, style = MaterialTheme.typography.labelMedium
            )
        }
    }
}

private enum class DragOp { NONE, MOVE, TL, TR, BL, BR, DRAW }

/** The photo with an editable box on top. The box is stored as fractions of the photo. */
@Composable
private fun LogoBoxEditor(image: PoolImage, box: LogoBox, onBoxChange: (LogoBox) -> Unit) {
    val aspect = if (image.widthPx > 0 && image.heightPx > 0) image.widthPx.toFloat() / image.heightPx else 16f / 9f
    val density = LocalDensity.current
    val handlePx = with(density) { 32.dp.toPx() }
    val strokePx = with(density) { 2.dp.toPx() }
    val dotPx = with(density) { 7.dp.toPx() }
    val accent = Accent
    val currentBox by rememberUpdatedState(box)
    val onChange by rememberUpdatedState(onBoxChange)
    val context = LocalContext.current
    val request = remember(image.uri) {
        ImageRequest.Builder(context).data(image.uri).size(1600, 1600).scale(Scale.FIT).build()
    }

    Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
        Box(
            Modifier
                .heightIn(max = 380.dp)
                .aspectRatio(aspect)
                .clip(RoundedCornerShape(10.dp))
                .background(Color.Black)
                .pointerInput(image.id) {
                    var op = DragOp.NONE
                    var anchor = Offset.Zero
                    detectDragGestures(
                        onDragStart = { p ->
                            val w = size.width.toFloat()
                            val h = size.height.toFloat()
                            val b = currentBox
                            val l = b.left * w
                            val t = b.top * h
                            val r = b.right * w
                            val bt = b.bottom * h
                            fun close(x: Float, y: Float) = (p.x - x) * (p.x - x) + (p.y - y) * (p.y - y) <= handlePx * handlePx
                            op = when {
                                close(l, t) -> DragOp.TL
                                close(r, t) -> DragOp.TR
                                close(l, bt) -> DragOp.BL
                                close(r, bt) -> DragOp.BR
                                p.x in l..r && p.y in t..bt -> DragOp.MOVE
                                else -> {
                                    anchor = p
                                    DragOp.DRAW
                                }
                            }
                        },
                        onDrag = { change, drag ->
                            change.consume()
                            val w = size.width.toFloat()
                            val h = size.height.toFloat()
                            val dx = drag.x / w
                            val dy = drag.y / h
                            val b = currentBox
                            val next = when (op) {
                                DragOp.MOVE -> {
                                    val nl = (b.left + dx).coerceIn(0f, 1f - b.width)
                                    val nt = (b.top + dy).coerceIn(0f, 1f - b.height)
                                    LogoBox(nl, nt, nl + b.width, nt + b.height)
                                }
                                DragOp.TL -> LogoBox(b.left + dx, b.top + dy, b.right, b.bottom)
                                DragOp.TR -> LogoBox(b.left, b.top + dy, b.right + dx, b.bottom)
                                DragOp.BL -> LogoBox(b.left + dx, b.top, b.right, b.bottom + dy)
                                DragOp.BR -> LogoBox(b.left, b.top, b.right + dx, b.bottom + dy)
                                DragOp.DRAW -> LogoBox(anchor.x / w, anchor.y / h, change.position.x / w, change.position.y / h)
                                DragOp.NONE -> b
                            }
                            onChange(next.coerced())
                        },
                        onDragEnd = { op = DragOp.NONE },
                        onDragCancel = { op = DragOp.NONE }
                    )
                }
        ) {
            AsyncImage(
                model = request,
                contentDescription = "Photo to clean",
                contentScale = ContentScale.FillBounds,
                modifier = Modifier.fillMaxSize()
            )
            Canvas(Modifier.fillMaxSize()) {
                val l = box.left * size.width
                val t = box.top * size.height
                val r = box.right * size.width
                val b = box.bottom * size.height
                val topLeft = Offset(l, t)
                val boxSize = Size(r - l, b - t)
                drawRect(color = accent.copy(alpha = 0.15f), topLeft = topLeft, size = boxSize)
                drawRect(color = accent, topLeft = topLeft, size = boxSize, style = Stroke(width = strokePx))
                for (corner in listOf(Offset(l, t), Offset(r, t), Offset(l, b), Offset(r, b))) {
                    drawCircle(color = Color.White, radius = dotPx, center = corner)
                    drawCircle(color = accent, radius = dotPx, center = corner, style = Stroke(width = strokePx))
                }
            }
        }
    }
}

@Composable
private fun ChoiceChip(text: String, selected: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(12.dp)
    Box(
        modifier
            .heightIn(min = 48.dp)
            .clip(shape)
            .background(if (selected) Accent.copy(alpha = 0.18f) else CardBg)
            .border(1.dp, if (selected) Accent else BorderColor, shape)
            .clickable(role = Role.RadioButton, onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text, color = if (selected) Accent else TextMain, style = MaterialTheme.typography.labelLarge,
            textAlign = TextAlign.Center
        )
    }
}
