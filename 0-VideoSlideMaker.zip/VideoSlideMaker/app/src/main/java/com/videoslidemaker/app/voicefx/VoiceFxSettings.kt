package com.videoslidemaker.app.voicefx

import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * The voice effects. [speedLabel] is null when the effect has no speed control; [tailSeconds] is how
 * long the effect keeps ringing after the voice stops (the exported clip is extended by this much so
 * an echo or reverb is not cut off).
 */
enum class VoiceEffect(
    val label: String,
    val emoji: String,
    val hint: String,
    val speedLabel: String?,
    val tailSeconds: Double
) {
    NONE("None", "➖", "No extra effect.", null, 0.0),
    AQUA("Aqua", "🌊", "Underwater: muffled and rippling, with a few soft bubbles.", "Ripple speed", 1.5),
    REVOLVE("Revolve 8D", "🌀", "The voice circles around your head. Use headphones for the full effect.", "Spin speed", 1.2),
    ROOM("Room", "🏠", "A small room: a little natural space around the voice.", null, 1.0),
    HALL("Hall", "🏛️", "A large hall: a longer, grander reverb.", null, 2.0),
    CAVE("Cave", "⛰️", "A cave: huge, dark, long reverb.", null, 3.0),
    ECHO("Echo", "🔁", "Repeats the voice a moment later, bouncing left and right.", null, 3.0),
    ROBOT("Robot", "🤖", "Metallic robot voice.", null, 0.1),
    TELEPHONE("Telephone", "📞", "Thin, narrow phone-call sound.", null, 0.0),
    MEGAPHONE("Megaphone", "📣", "Loud, harsh bullhorn sound.", null, 0.1),
    WHISPER("Whisper", "🤫", "Breathy whisper: the voice turns into airy noise.", null, 0.0)
}

/**
 * Everything the voice changer can do to the spoken sound (the phone's voice OR your own
 * recording - never the background music).
 *
 *  - [pitchSemitones]: -24..+24 in steps of 0.01 (one semitone = 100 cents). Speed does not change.
 *  - [humanize]: 0..1, how much to make a too-clean (AI) voice feel recorded by a person.
 *  - [breaths]: adds a soft breath in real pauses between sentences.
 *  - [effect] + [effectAmount] (0..1) + [effectSpeed] (0..1, only for effects that have a speed).
 */
data class VoiceFxSettings(
    val pitchSemitones: Float = 0f,
    val humanize: Float = 0f,
    val breaths: Boolean = false,
    val effect: VoiceEffect = VoiceEffect.NONE,
    val effectAmount: Float = 0.6f,
    val effectSpeed: Float = 0.5f
) {
    val pitchActive: Boolean get() = abs(pitchSemitones) >= MIN_PITCH_ST
    val humanizeActive: Boolean get() = humanize > 0.001f || breaths
    val effectActive: Boolean get() = effect != VoiceEffect.NONE

    /** False means the sound is passed through completely untouched. */
    val isActive: Boolean get() = pitchActive || humanizeActive || effectActive

    /** Extra seconds to keep after the voice ends so reverb/echo can fade out. */
    val tailSeconds: Double get() = if (effectActive) effect.tailSeconds else 0.0

    /** Short plain-language summary, for example "Pitch +2.35 · Human 50% · Aqua". */
    fun summary(): String {
        if (!isActive) return "Off"
        val parts = ArrayList<String>()
        if (pitchActive) parts.add("Pitch " + formatPitch(pitchSemitones))
        if (humanize > 0.001f) parts.add("Human " + (humanize * 100f).roundToInt() + "%")
        if (breaths) parts.add("Breaths")
        if (effectActive) parts.add(effect.label)
        return parts.joinToString(" · ")
    }

    companion object {
        const val MAX_PITCH_ST = 24f
        const val MIN_PITCH_ST = 0.005f

        /** "+2.35", "-0.10", "0.00" - always two decimals, never "-0.00". */
        fun formatPitch(st: Float): String {
            val hundredths = (st * 100f).roundToInt()
            if (hundredths == 0) return "0.00"
            val sign = if (hundredths > 0) "+" else "-"
            val a = abs(hundredths)
            return sign + (a / 100).toString() + "." + (a % 100).toString().padStart(2, '0')
        }
    }
}
