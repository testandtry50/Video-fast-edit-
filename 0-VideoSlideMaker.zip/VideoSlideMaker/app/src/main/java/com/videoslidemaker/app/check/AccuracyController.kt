package com.videoslidemaker.app.check

import android.content.Context
import android.net.Uri
import com.videoslidemaker.app.align.RecordingReadException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Everything the accuracy screens need. Kept out of the app's main UiState so a progress tick redraws only these screens. */
data class AccuracyUi(
    /** Name of the installed speech model, or null when there is none yet. */
    val modelName: String? = null,
    val installing: Boolean = false,
    val installPercent: Int = 0,
    val running: Boolean = false,
    val percent: Int = 0,
    val stage: String = "",
    val error: String? = null,
    val notice: String? = null,
    val result: CheckResult? = null,
    /** The transcript exactly as it was when [result] was made, to notice later edits. */
    val checked: List<CheckSegment> = emptyList(),
    /** How many words the recognizer heard in the recording. */
    val heardWords: Int = 0,
    val screenOpen: Boolean = false,
    val settings: CheckSettings = CheckSettings()
)

/**
 * Listens to the recording (offline), compares what it heard with the transcript, and keeps the result.
 *
 * What was heard is remembered for the current recording, so changing the tolerance, or fixing the transcript and
 * checking again, takes a moment instead of listening to the whole recording again.
 */
class AccuracyController(
    context: Context,
    private val scope: CoroutineScope,
    /** The transcript as it stands now. */
    private val segments: () -> List<CheckSegment>,
    private val recordingUri: () -> Uri?
) {
    private val store = VoskModelStore(context)
    private val recognizer: WordRecognizer = VoskWordRecognizer(context.applicationContext, store)

    private val _ui = MutableStateFlow(AccuracyUi())
    val ui: StateFlow<AccuracyUi> = _ui.asStateFlow()

    private var job: Job? = null
    @Volatile private var heard: RecognizedSpeech? = null
    @Volatile private var heardFrom: Uri? = null

    init {
        scope.launch(Dispatchers.IO) {
            val name = store.modelName()
            _ui.update { it.copy(modelName = name) }
        }
    }

    fun openScreen(open: Boolean) = _ui.update { it.copy(screenOpen = open) }

    /** True when a speech model is installed, so the recording's words can be recognized. */
    val hasModel: Boolean get() = _ui.value.modelName != null

    /**
     * The words heard in [uri]: straight from the cache when the accuracy check or an earlier alignment already listened to
     * this recording, otherwise by listening now. Null when no speech model is installed. Blocks while listening, so call it
     * off the main thread; throws [RecognizerException] with a message the user can act on.
     */
    fun speechFor(uri: Uri, onProgress: (Int) -> Unit, isCancelled: () -> Boolean): RecognizedSpeech? {
        val cached = heard
        if (cached != null && heardFrom == uri) return cached
        if (!recognizer.isReady()) return null
        val speech = recognizer.recognize(uri, onProgress, isCancelled)
        heard = speech
        heardFrom = uri
        return speech
    }

    /** True when the transcript differs from what [AccuracyUi.result] was made from. */
    fun isStale(ui: AccuracyUi = _ui.value): Boolean = ui.result != null && ui.checked != segments()

    // ---------------------------------------------------------------------------------------------- speech model

    fun installModel(zip: Uri) {
        if (job?.isActive == true || _ui.value.installing) return
        scope.launch {
            _ui.update { it.copy(installing = true, installPercent = 0, error = null, notice = null) }
            try {
                val name = withContext(Dispatchers.IO) {
                    store.install(
                        zip,
                        onProgress = { pct -> _ui.update { it.copy(installPercent = pct) } },
                        isCancelled = { !isActive }
                    )
                }
                _ui.update { it.copy(installing = false, installPercent = 100, modelName = name, notice = "Speech model installed: $name") }
            } catch (e: CancellationException) {
                _ui.update { it.copy(installing = false) }
                throw e
            } catch (e: RecognizerException) {
                _ui.update { it.copy(installing = false, error = e.message) }
            } catch (e: Exception) {
                _ui.update { it.copy(installing = false, error = "Couldn't install the speech model: " + (e.message ?: e.javaClass.simpleName)) }
            }
        }
    }

    fun removeModel() {
        if (_ui.value.running) return
        scope.launch(Dispatchers.IO) {
            store.remove()
            _ui.update { it.copy(modelName = null, notice = "Speech model removed.") }
        }
    }

    // ---------------------------------------------------------------------------------------------- the check

    /** The recording changed: what was heard and the result belonged to the old one. */
    fun onRecordingChanged() {
        job?.cancel()
        heard = null
        heardFrom = null
        _ui.update { it.copy(result = null, checked = emptyList(), heardWords = 0, error = null, notice = null, running = false, percent = 0, stage = "") }
    }

    fun setTimestampTolerance(ms: Long) {
        _ui.update { it.copy(settings = it.settings.copy(timestampToleranceMs = ms)) }
        if (heard != null && _ui.value.result != null && !_ui.value.running) run(listenAgain = false)
    }

    fun cancel() {
        job?.cancel()
    }

    /**
     * Checks the transcript against the recording. With [listenAgain] false, a recording that was already listened to is
     * not listened to again.
     */
    fun run(listenAgain: Boolean = true) {
        if (job?.isActive == true) return
        val segs = segments()
        val uri = recordingUri()
        if (segs.isEmpty()) return fail("Load a script first: there is no transcript to check.")
        if (uri == null) return fail("Choose the recording first.")
        val cached = heard.takeIf { !listenAgain && heardFrom == uri }
        if (cached == null && !recognizer.isReady()) return fail("Choose a speech model first (it is needed once, for the language of the recording).")

        val settings = _ui.value.settings
        job = scope.launch {
            _ui.update { it.copy(running = true, percent = 0, stage = if (cached == null) "Listening to the recording…" else "Comparing…", error = null, notice = null) }
            try {
                val speech = cached ?: withContext(Dispatchers.Default) {
                    recognizer.recognize(
                        uri,
                        onProgress = { pct -> _ui.update { it.copy(percent = pct * 95 / 100) } },
                        isCancelled = { !isActive }
                    )
                }
                heard = speech
                heardFrom = uri
                _ui.update { it.copy(stage = "Comparing…", percent = 97) }
                val result = withContext(Dispatchers.Default) { AccuracyChecker.check(segs, speech.words, settings) }
                _ui.update {
                    it.copy(
                        running = false, percent = 100, stage = "", result = result, checked = segs, heardWords = speech.words.size,
                        notice = if (speech.words.isEmpty()) "The recognizer heard no words. Is this the right recording and language model?" else null
                    )
                }
            } catch (e: CancellationException) {
                _ui.update { it.copy(running = false, percent = 0, stage = "") }
                throw e
            } catch (e: RecordingReadException) {
                fail(e.message ?: "Couldn't read the recording.")
            } catch (e: RecognizerException) {
                fail(e.message ?: "The speech recognizer failed.")
            } catch (e: OutOfMemoryError) {
                fail("The phone ran out of memory while listening. A smaller speech model may help.")
            } catch (e: Exception) {
                fail("Couldn't check the recording: " + (e.message ?: e.javaClass.simpleName))
            }
        }
    }

    private fun fail(message: String) {
        _ui.update { it.copy(running = false, percent = 0, stage = "", error = message) }
    }
}
