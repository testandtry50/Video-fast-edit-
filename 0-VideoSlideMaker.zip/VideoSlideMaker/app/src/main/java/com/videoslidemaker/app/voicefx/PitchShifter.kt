package com.videoslidemaker.app.voicefx

import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Changes the pitch without changing the speed: a phase vocoder (FFT 2048, 8x overlap) with
 * "peak locking" - every spectral peak (every harmonic of the voice) is moved as a unit, so the
 * voice does not turn watery or phasey. Any ratio works, so pitch can be set in steps of 0.01
 * semitone (1 cent) from -24 to +24.
 *
 * Output sample i is the input sample i - [latencyFrames]; the caller removes that delay.
 */
class PitchShifter(private val fs: Int) {
    private val n = 2048
    private val half = n / 2
    private val osamp = 8
    private val step = n / osamp
    private val fifoOffset = n - step

    /** Measured end-to-end delay in samples. */
    val latencyFrames: Int = n

    private val fft = Fft(n)
    private val window = DoubleArray(n)
    private val inFifo = DoubleArray(n)
    private val outFifo = DoubleArray(n)
    private val accum = DoubleArray(2 * n)
    private val lastPhase = DoubleArray(half + 1)
    private val synPhase = DoubleArray(half + 1)
    private val newPhase = DoubleArray(half + 1)
    private val anaMagn = DoubleArray(half + 1)
    private val anaPhase = DoubleArray(half + 1)
    private val synMagn = DoubleArray(half + 1)
    private val peaks = IntArray(half + 2)
    private val re = DoubleArray(n)
    private val im = DoubleArray(n)
    private var rover = fifoOffset
    private var ratio = 1.0

    init {
        for (k in 0 until n) window[k] = -0.5 * cos(TWO_PI * k / n) + 0.5
    }

    fun setSemitones(st: Double) {
        ratio = 2.0.pow(st / 12.0)
    }

    fun process(x: Double): Double {
        inFifo[rover] = x
        val y = outFifo[rover - fifoOffset]
        rover++
        if (rover >= n) {
            rover = fifoOffset
            frame()
        }
        return y
    }

    private fun frame() {
        val freqPerBin = fs.toDouble() / n
        val expct = TWO_PI * step / n
        for (k in 0 until n) {
            re[k] = inFifo[k] * window[k]
            im[k] = 0.0
        }
        fft.transform(re, im, false)
        for (k in 0..half) {
            anaMagn[k] = sqrt(re[k] * re[k] + im[k] * im[k])
            anaPhase[k] = atan2(im[k], re[k])
        }

        // spectral peaks: bigger than two neighbours on each side
        var npeaks = 0
        for (k in 2 until half - 1) {
            val m = anaMagn[k]
            if (m > 1e-9 && m > anaMagn[k - 1] && m > anaMagn[k + 1] && m >= anaMagn[k - 2] && m >= anaMagn[k + 2]) {
                peaks[npeaks] = k
                npeaks++
            }
        }

        for (k in 0..half) synMagn[k] = 0.0
        val r = ratio
        var lower = 0
        for (pk in 0 until npeaks) {
            val kp = peaks[pk]
            val upper = if (pk + 1 < npeaks) (kp + peaks[pk + 1]) / 2 else half
            // the peak's true frequency, from how far its phase moved since the last frame
            var tmp = anaPhase[kp] - lastPhase[kp]
            tmp -= kp * expct
            var qpd = (tmp / PI).toInt()
            if (qpd >= 0) qpd += qpd and 1 else qpd -= qpd and 1
            tmp -= PI * qpd
            tmp = osamp * tmp / TWO_PI
            val trueFreq = kp * freqPerBin + tmp * freqPerBin
            val q = floor(kp * r + 0.5).toInt()
            if (q > half) {
                lower = upper + 1
                continue
            }
            var adv = (trueFreq * r - q * freqPerBin) / freqPerBin
            adv = TWO_PI * adv / osamp + q * expct
            val peakPhase = synPhase[q] + adv
            val delta = q - kp
            for (k in lower..upper) {
                val d = k + delta
                if (d < 0 || d > half) continue
                if (anaMagn[k] >= synMagn[d]) {
                    synMagn[d] = anaMagn[k]
                    newPhase[d] = peakPhase + (anaPhase[k] - anaPhase[kp])
                }
            }
            lower = upper + 1
        }
        for (k in 0..half) lastPhase[k] = anaPhase[k]

        for (k in 0..half) {
            if (synMagn[k] > 0.0) {
                var ph = newPhase[k]
                ph -= TWO_PI * floor(ph / TWO_PI + 0.5) // keep in [-pi, pi): hours of audio stay exact
                synPhase[k] = ph
                val m = synMagn[k] * 2.0
                re[k] = m * cos(ph)
                im[k] = m * sin(ph)
            } else {
                re[k] = 0.0
                im[k] = 0.0
            }
        }
        for (k in half + 1 until n) {
            re[k] = 0.0
            im[k] = 0.0
        }
        fft.transform(re, im, true)
        val scale = GAIN / (half * osamp)
        for (k in 0 until n) accum[k] += window[k] * re[k] * scale
        for (k in 0 until step) outFifo[k] = accum[k]
        for (k in 0 until n) accum[k] = accum[k + step]
        for (k in n until 2 * n) accum[k] = 0.0
        for (k in 0 until fifoOffset) inFifo[k] = inFifo[k + step]
    }

    private companion object {
        /** Calibrated: unity level at 8x overlap with a Hann window on both sides. */
        const val GAIN = 2.0 / 1.5
    }
}
