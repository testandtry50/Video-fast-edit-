package com.videoslidemaker.app.ui.components

import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import com.videoslidemaker.app.ui.theme.Accent
import com.videoslidemaker.app.ui.theme.OnAccent
import kotlin.math.roundToInt

/** Lists shorter than this don't need a fast-scroll handle. */
const val FastScrollMinItems = 6

/** Width of the strip on the right edge that the handle lives in. Leave this much padding on the list's end. */
val FastScrollGutter = 32.dp

/** Where a finger at [fraction] (0 = top of the strip, 1 = bottom) should jump to in a list of [count] items. */
fun fastScrollIndexFor(fraction: Float, count: Int): Int {
    if (count <= 0) return 0
    return (fraction.coerceIn(0f, 1f) * (count - 1)).roundToInt().coerceIn(0, count - 1)
}

/** How far down the strip the handle sits for a list showing [firstVisibleIndex] first. */
fun fastScrollFractionFor(firstVisibleIndex: Int, count: Int, atEnd: Boolean): Float {
    if (atEnd) return 1f
    if (count <= 1) return 0f
    return (firstVisibleIndex.toFloat() / (count - 1)).coerceIn(0f, 1f)
}

/**
 * NEW: a fast-scroll handle for long lists / grids (hundreds or thousands of photos).
 *
 * Put it in a [Box] on top of the list, give the list [FastScrollGutter] of end padding, and grab
 * the handle on the right edge: drag it to fly through the whole list, and a bubble next to your
 * finger tells you where you are (for example "Photo 212 / 640"). Touching anywhere in the strip
 * jumps there straight away. The list jumps instantly (no animation), which is what makes it fast.
 *
 * It only reports positions - the caller decides how to scroll ([onJumpTo]) - so it works with
 * LazyColumn, LazyVerticalGrid and the staggered grid alike.
 */
@Composable
fun FastScroller(
    itemCount: Int,
    firstVisibleIndex: Int,
    atEnd: Boolean,
    isScrolling: Boolean,
    onJumpTo: (Int) -> Unit,
    label: (Int) -> String,
    modifier: Modifier = Modifier,
    minItems: Int = FastScrollMinItems
) {
    if (itemCount < minItems) return

    val density = LocalDensity.current
    val handleHeight = 72.dp
    val handlePx = with(density) { handleHeight.toPx() }

    var dragging by remember { mutableStateOf(false) }
    var dragFraction by remember { mutableFloatStateOf(0f) }
    var trackPx by remember { mutableIntStateOf(0) }
    val jump by rememberUpdatedState(onJumpTo)
    val count by rememberUpdatedState(itemCount)

    val fraction = if (dragging) dragFraction else fastScrollFractionFor(firstVisibleIndex, itemCount, atEnd)
    val usablePx = (trackPx - handlePx).coerceAtLeast(0f)
    val handleTopPx = (fraction * usablePx).roundToInt()
    val shownIndex = fastScrollIndexFor(fraction, itemCount)

    val active = dragging || isScrolling
    val handleAlpha by animateFloatAsState(if (active) 1f else 0.55f, label = "fastScrollAlpha")
    val handleWidth by animateDpAsState(if (dragging) 18.dp else 10.dp, label = "fastScrollWidth")

    Box(modifier.onSizeChanged { trackPx = it.height }) {
        if (dragging) {
            Text(
                label(shownIndex),
                style = MaterialTheme.typography.labelLarge,
                color = OnAccent,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .offset {
                        IntOffset(
                            x = -(FastScrollGutter + 8.dp).roundToPx(),
                            y = handleTopPx + (handlePx / 2f).roundToInt() - 19.dp.roundToPx()
                        )
                    }
                    .clip(RoundedCornerShape(14.dp))
                    .background(Accent)
                    .padding(horizontal = 14.dp, vertical = 9.dp)
            )
        }

        // The touch strip. Everything in it scrubs the list, so there is no tiny target to miss.
        Box(
            Modifier
                .align(Alignment.CenterEnd)
                .fillMaxHeight()
                .width(FastScrollGutter)
                .semantics { contentDescription = "Fast scroll. Drag up or down to jump through the list" }
                .pointerInput(Unit) {
                    awaitEachGesture {
                        val down = awaitFirstDown(requireUnconsumed = false)
                        val usable = (size.height - handlePx).coerceAtLeast(1f)
                        fun moveTo(y: Float) {
                            val f = ((y - handlePx / 2f) / usable).coerceIn(0f, 1f)
                            dragFraction = f
                            jump(fastScrollIndexFor(f, count))
                        }
                        dragging = true
                        try {
                            down.consume()
                            moveTo(down.position.y)
                            while (true) {
                                val event = awaitPointerEvent()
                                val change = event.changes.firstOrNull { it.id == down.id } ?: break
                                if (!change.pressed) break
                                moveTo(change.position.y)
                                change.consume()
                            }
                        } finally {
                            dragging = false
                        }
                    }
                }
        ) {
            Box(
                Modifier
                    .align(Alignment.TopEnd)
                    .offset { IntOffset(0, handleTopPx) }
                    .padding(end = 4.dp)
                    .size(width = handleWidth, height = handleHeight)
                    .alpha(handleAlpha)
                    .clip(RoundedCornerShape(9.dp))
                    .background(Accent)
            )
        }
    }
}
