package com.videoslidemaker.app.align

import android.media.AudioTrack
import android.media.MediaPlayer
import android.media.PlaybackParams
import com.videoslidemaker.app.model.PreviewSpeed

/**
 * NEW (2.8): speeds sound up or slows it down WITHOUT changing the pitch (so a voice at 2x is fast, not a
 * chipmunk), using the time-stretching that Android's own sound system provides (API 23+; this app needs 26+).
 *
 * Some phones only accept part of the range. They are told to REFUSE what they can't do (instead of
 * silently muting the sound), and then a simpler speed is tried - see [PreviewSpeed.fallbackLadder].
 * Both functions return the speed that really ended up in use, so the pictures can follow the sound.
 */
internal object PlaybackSpeed {

    private fun params(speed: Float): PlaybackParams =
        PlaybackParams()
            .setSpeed(speed)
            .setPitch(1f)
            .setAudioFallbackMode(PlaybackParams.AUDIO_FALLBACK_MODE_FAIL)

    /**
     * Sets [wanted] on a prepared [player]. Note: Android treats a speed above zero as "play", so a paused
     * player starts playing - call this at the moment playing should start.
     */
    fun setOn(player: MediaPlayer, wanted: Float): Float {
        for (speed in PreviewSpeed.fallbackLadder(wanted)) {
            try {
                player.setPlaybackParams(params(speed))
                return speed
            } catch (_: Exception) {
                // this phone refuses that speed - try a simpler one
            }
        }
        return PreviewSpeed.NORMAL
    }

    /** Sets [wanted] on a ready [track] (before it is played). */
    fun setOn(track: AudioTrack, wanted: Float): Float {
        for (speed in PreviewSpeed.fallbackLadder(wanted)) {
            try {
                track.setPlaybackParams(params(speed))
                return speed
            } catch (_: Exception) {
                // this phone refuses that speed - try a simpler one
            }
        }
        return PreviewSpeed.NORMAL
    }
}
