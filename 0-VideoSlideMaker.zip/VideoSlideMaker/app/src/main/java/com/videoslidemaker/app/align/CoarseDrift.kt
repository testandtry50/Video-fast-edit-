package com.videoslidemaker.app.align

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/** One analysis window of the coarse search: the best-fitting lag for that stretch of the recording. */
internal class CoarseWindow(
    val centerMs: Int,
    val lagMs: Int,
    val peak: Double,
    val second: Double,
    /** True when the correlation peak is strong and clearly better than any other lag. */
    val ok: Boolean
)

/** Interpolated lag at one transcript time, and whether a trustworthy window is near enough. */
internal class CoarseShift(val ms: Double, val reliable: Boolean)

/**
 * Finds, WITHOUT assuming how large the error is, how far each part of the transcript is from
 * the audio. It lines up "the transcript says someone is speaking here" with "the audio has
 * speech here" at 100 ms resolution, for every 90 s window of the recording, over lags of up
 * to ±40 s. A smoothing pass (Viterbi) then lets the lag change slowly from window to window,
 * which is exactly what drift looks like, while refusing to jump wildly on a weak window.
 *
 * This is deliberately coarse (±100 ms). Its job is to put the fine, boundary-level alignment in
 * the right neighbourhood, and to act as an independent second opinion that the fine result must
 * agree with before it is ever trusted.
 */
internal object CoarseDrift {
    const val BIN_MS = 100
    private const val BIN_FRAMES = BIN_MS / EnergyFrameExtractor.HOP_MS
    private const val WIN_BINS = 900          // 90 s
    private const val STEP_BINS = 450         // 45 s
    const val MAX_LAG_BINS = 400              // ±40 s
    private const val MIN_PEAK = 0.30
    private const val MIN_SHARPNESS = 0.12
    private const val PEN_PER_BIN = 0.004
    private const val MAX_JUMP_BINS = 40      // 4 s of lag change between neighbouring windows
    private const val FAR_BINS = 20           // "a different answer" = at least 2 s away
    private const val ASSUMED_RHO = 0.85
    private const val NEG = -1e9

    /** Speech present (1) / absent (0) per 100 ms, with gaps under 250 ms bridged. */
    fun speechBins(mask: BooleanArray): DoubleArray {
        val k = mask.size
        val m = mask.copyOf()
        var i = 0
        while (i < k) {
            if (!m[i]) {
                var j = i
                while (j < k && !m[j]) j++
                if (i > 0 && j < k && (j - i) < 25) {
                    for (x in i until j) m[x] = true
                }
                i = j
            } else {
                i++
            }
        }
        val nb = k / BIN_FRAMES
        val out = DoubleArray(nb)
        for (b in 0 until nb) {
            var c = 0
            for (f in 0 until BIN_FRAMES) if (m[b * BIN_FRAMES + f]) c++
            out[b] = if (c * 2 >= BIN_FRAMES) 1.0 else 0.0
        }
        return out
    }

    /** Where the transcript says speech happens, padded by [MAX_LAG_BINS] on both sides (index = bin + MAX_LAG_BINS). */
    private fun transcriptBins(t: IntArray, units: DoubleArray, nBins: Int): DoubleArray {
        val off = MAX_LAG_BINS
        val out = DoubleArray(nBins + 2 * MAX_LAG_BINS + 1)
        for (i in t.indices) {
            var durMs = units[i] / TextUnits.RATE0 * ASSUMED_RHO * 1000.0
            if (i + 1 < t.size) durMs = min(durMs, max(0, t[i + 1] - t[i]).toDouble())
            val a = max(0, Math.floorDiv(t[i], BIN_MS) + off)
            val b = min(out.size, Math.floorDiv((t[i] + durMs).toInt(), BIN_MS) + off + 1)
            for (x in a until b) out[x] = 1.0
        }
        return out
    }

    fun estimate(t: IntArray, units: DoubleArray, mask: BooleanArray): List<CoarseWindow> {
        if (t.isEmpty()) return emptyList()
        val sb = speechBins(mask)
        val nb = sb.size
        var maxT = t[0]
        for (v in t) if (v > maxT) maxT = v
        val lastTBin = Math.floorDiv(maxT, BIN_MS) + 1
        val tb = transcriptBins(t, units, max(nb, Math.floorDiv(maxT, BIN_MS) + 2))

        // prefix sums of the (binary) audio indicator, for O(1) window mean/variance
        val cs = DoubleArray(nb + 1)
        for (i in 0 until nb) cs[i + 1] = cs[i] + sb[i]

        val nLags = 2 * MAX_LAG_BINS + 1
        val windows = ArrayList<IntArray>()
        val end = max(lastTBin, 1)
        var w0 = 0
        while (w0 < end) {
            val w1 = min(w0 + WIN_BINS, max(end, w0 + 1))
            windows.add(intArrayOf(w0, w1))
            if (w1 >= end) break
            w0 += STEP_BINS
        }

        val scores = Array(windows.size) { w -> windowScores(tb, sb, cs, windows[w][0], windows[w][1]) }
        val nW = windows.size

        // Viterbi over windows: maximise total correlation, penalise lag changes between windows.
        val v = Array(nW) { DoubleArray(nLags) { NEG } }
        val ptr = Array(nW) { IntArray(nLags) }
        for (li in 0 until nLags) v[0][li] = scores[0][li]
        for (w in 1 until nW) {
            for (li in 0 until nLags) {
                val lo = max(0, li - MAX_JUMP_BINS)
                val hi = min(nLags, li + MAX_JUMP_BINS + 1)
                var bestV = Double.NEGATIVE_INFINITY
                var bestK = lo
                for (x in lo until hi) {
                    val c = v[w - 1][x] - PEN_PER_BIN * abs(x - li)
                    if (c > bestV) {
                        bestV = c
                        bestK = x
                    }
                }
                v[w][li] = bestV + scores[w][li]
                ptr[w][li] = bestK
            }
        }
        val path = IntArray(nW)
        var bestEnd = 0
        for (li in 1 until nLags) if (v[nW - 1][li] > v[nW - 1][bestEnd]) bestEnd = li
        path[nW - 1] = bestEnd
        for (w in nW - 1 downTo 1) path[w - 1] = ptr[w][path[w]]

        val out = ArrayList<CoarseWindow>(nW)
        for (w in 0 until nW) {
            val chosen = path[w]
            val pk = scores[w][chosen]
            var second = 0.0
            for (li in 0 until nLags) {
                if (abs(li - chosen) >= FAR_BINS && scores[w][li] > second) second = scores[w][li]
            }
            val lag = (chosen - MAX_LAG_BINS) * BIN_MS
            out.add(
                CoarseWindow(
                    centerMs = (windows[w][0] + windows[w][1]) / 2 * BIN_MS,
                    lagMs = lag,
                    peak = pk,
                    second = second,
                    ok = pk >= MIN_PEAK && pk - second >= MIN_SHARPNESS
                )
            )
        }
        return out
    }

    /** Pearson correlation of transcript window [w0, w1) against the audio indicator at every lag. */
    private fun windowScores(tb: DoubleArray, sb: DoubleArray, cs: DoubleArray, w0: Int, w1: Int): DoubleArray {
        val nLags = 2 * MAX_LAG_BINS + 1
        val scores = DoubleArray(nLags)
        val n = w1 - w0
        if (n <= 0) return scores
        val off = MAX_LAG_BINS
        var mean = 0.0
        for (i in 0 until n) mean += tb[w0 + off + i]
        mean /= n
        val em = DoubleArray(n)
        var ss = 0.0
        for (i in 0 until n) {
            em[i] = tb[w0 + off + i] - mean
            ss += em[i] * em[i]
        }
        val ne = sqrt(ss)
        if (ne < 1e-6) return scores        // the transcript has no speech/silence contrast here
        val nbins = sb.size
        for (li in 0 until nLags) {
            val lag = li - MAX_LAG_BINS
            val a = w0 + lag
            val b = w1 + lag
            if (a < 0 || b > nbins) continue   // only windows fully covered by the recording
            val sum = cs[b] - cs[a]
            val variance = sum - sum * sum / n   // binary signal: sum of squares == sum
            val ns = sqrt(max(0.0, variance))
            if (ns < 1e-6) continue
            var dot = 0.0
            for (i in 0 until n) dot += em[i] * sb[a + i]
            scores[li] = dot / (ne * ns)
        }
        return scores
    }

    /**
     * The lag at transcript time [tMs], interpolated between windows that have a clear peak
     * (null if no window does). `reliable` means such a window is within 100 s of [tMs].
     */
    fun shiftAt(windows: List<CoarseWindow>, tMs: Int): CoarseShift? {
        var firstGood = -1
        var count = 0
        for (i in windows.indices) if (windows[i].ok) {
            if (firstGood < 0) firstGood = i
            count++
        }
        if (count == 0) return null
        var prevX = 0.0
        var prevY = 0.0
        var havePrev = false
        var value = Double.NaN
        var nearest = Double.MAX_VALUE
        for (w in windows) {
            if (!w.ok) continue
            val x = w.centerMs.toDouble()
            val y = w.lagMs.toDouble()
            nearest = min(nearest, abs(x - tMs))
            if (value.isNaN()) {
                if (tMs <= x) {
                    value = if (!havePrev) y else prevY + (y - prevY) * (tMs - prevX) / (x - prevX)
                }
            }
            prevX = x
            prevY = y
            havePrev = true
        }
        if (value.isNaN()) value = prevY            // beyond the last good window: hold its value
        return CoarseShift(value, nearest <= 100000.0)
    }
}
