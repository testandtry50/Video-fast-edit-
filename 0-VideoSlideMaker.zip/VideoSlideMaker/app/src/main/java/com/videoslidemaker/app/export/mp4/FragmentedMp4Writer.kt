package com.videoslidemaker.app.export.mp4

internal class VideoTrack(val width: Int, val height: Int, val avc: AvcConfig)

internal class AudioTrack(
    val sampleRate: Int,
    val channelCount: Int,
    /** MediaCodec's AAC `csd-0`. */
    val audioSpecificConfig: ByteArray,
    val bitrate: Int,
    /** Samples in one AAC frame (1024 for AAC-LC). */
    val samplesPerFrame: Int = 1024
)

/**
 * Writes an MP4 as a stream of small self-contained fragments instead of one big index at the end.
 *
 * Why this and not Android's MP4 muxer, for a very large export:
 *  - **No size limit of its own.** The platform muxer keeps 32-bit file offsets and stops at about 4 GB. Here every offset is
 *    64-bit, so the only limit is the storage.
 *  - **Constant memory.** Only one fragment (about two seconds of video, at most [MAX_FRAGMENT_BYTES]) is ever held; everything
 *    else has already been written. Nothing needs the whole video, or an index of it, in RAM.
 *  - **Nothing is written twice and nothing is seeked back to.** The index is not rewritten at the end (the old design needed
 *    the whole file finished first), so the file can be written straight to its destination as a stream.
 *  - **Valid at every moment.** After each fragment the file is a complete, playable video. If the export stops (storage full,
 *    a crash, the system ending the service), everything up to the last fragment still plays.
 *
 * Layout: `ftyp`, `moov` (the tracks, with the planned duration, so players show the length straight away), then repeated
 * `moof`+`mdat` fragments that interleave audio and video, and a closing `mfra` (an index for seeking).
 *
 * Frames must arrive in presentation order (no B-frames), which the encoder is configured to give.
 */
internal class FragmentedMp4Writer(
    private val sink: ByteSink,
    private val video: VideoTrack,
    private val audio: AudioTrack?,
    private val audioSource: AudioSampleSource?,
    private val plannedDurationUs: Long,
    /** How long the very last frame lasts (one frame at the export's frame rate). */
    private val frameDurationUs: Long
) {
    companion object {
        const val VIDEO_TIMESCALE = 90_000L
        const val MAX_FRAGMENT_BYTES = 16L * 1024 * 1024

        /** Audio samples in an audio-only fragment (the narration running past the last picture), about 2 seconds. */
        const val AUDIO_CHUNK_SAMPLES = 94

        const val VIDEO_TRACK = 1
        const val AUDIO_TRACK = 2
        private const val SYNC = 0x02000000
        private const val NON_SYNC = 0x01010000
        private const val TRUN_FLAGS = 0x000701          // data offset, duration, size, flags
        private const val TFHD_DEFAULT_BASE_IS_MOOF = 0x020000
        private const val TRAF_FIXED = 64                // traf + tfhd + tfdt + trun, without the samples
        private const val TRAF_PER_SAMPLE = 12
        private const val MOOF_FIXED = 24                // moof + mfhd
    }

    private class VSample(val ptsUs: Long, val key: Boolean, val data: ByteArray)

    private val pending = ArrayList<VSample>()
    private var pendingBytes = 0L
    private var sequence = 1L
    private var started = false
    private var finished = false
    private var lastEndPtsUs = 0L

    private val videoIndex = ArrayList<LongArray>()       // [first dts, moof offset]
    private val audioIndex = ArrayList<LongArray>()       // [first dts, moof offset, traf number]

    var fragments = 0
        private set

    var videoSamples = 0L
        private set

    var audioSamples = 0L
        private set

    /** Bytes written so far: the size of the file, right now. */
    val bytesWritten: Long get() = sink.position

    /** How much of the video is already in the file and playable, in microseconds. */
    val playableUs: Long get() = lastEndPtsUs

    private fun videoDts(ptsUs: Long): Long = (ptsUs * VIDEO_TIMESCALE + 500_000L) / 1_000_000L
    private fun audioDts(ptsUs: Long): Long = (ptsUs * audio!!.sampleRate.toLong() + 500_000L) / 1_000_000L

    // ---------------------------------------------------------------------------------------------------------
    // The start of the file
    // ---------------------------------------------------------------------------------------------------------

    fun start() {
        check(!started) { "already started" }
        val b = Mp4Buf(8192)
        val ftyp = b.begin("ftyp")
        b.fourcc("isom"); b.u32(512L)
        for (brand in arrayOf("isom", "iso5", "iso6", "avc1", "mp41")) b.fourcc(brand)
        b.end(ftyp)
        writeMoov(b)
        b.writeTo(sink)
        started = true
    }

    private fun matrix(b: Mp4Buf) {
        for (v in longArrayOf(0x00010000L, 0, 0, 0, 0x00010000L, 0, 0, 0, 0x40000000L)) b.u32(v)
    }

    private fun writeMoov(b: Mp4Buf) {
        val plannedMs = plannedDurationUs / 1000L
        val moov = b.begin("moov")

        val mvhd = b.beginFull("mvhd", 1, 0)
        b.u64(0); b.u64(0); b.u32(1000L); b.u64(plannedMs)
        b.u32(0x00010000L)                              // rate 1.0
        b.u16(0x0100); b.u16(0)                         // volume 1.0, reserved
        b.u32(0); b.u32(0)
        matrix(b)
        for (i in 0 until 6) b.u32(0)
        b.u32(if (audio != null) 3L else 2L)            // next track id
        b.end(mvhd)

        val mvex = b.begin("mvex")
        val mehd = b.beginFull("mehd", 1, 0)
        b.u64(plannedMs)
        b.end(mehd)
        writeTrex(b, VIDEO_TRACK)
        if (audio != null) writeTrex(b, AUDIO_TRACK)
        b.end(mvex)

        writeVideoTrak(b, plannedMs)
        if (audio != null) writeAudioTrak(b, plannedMs)
        b.end(moov)
    }

    private fun writeTrex(b: Mp4Buf, trackId: Int) {
        val p = b.beginFull("trex", 0, 0)
        b.u32(trackId.toLong()); b.u32(1); b.u32(0); b.u32(0); b.u32(0)
        b.end(p)
    }

    private fun tkhd(b: Mp4Buf, trackId: Int, plannedMs: Long, volume: Int, width: Int, height: Int) {
        val p = b.beginFull("tkhd", 1, 0x000007)
        b.u64(0); b.u64(0); b.u32(trackId.toLong()); b.u32(0); b.u64(plannedMs)
        b.u32(0); b.u32(0)
        b.u16(0); b.u16(0); b.u16(volume); b.u16(0)
        matrix(b)
        b.u32(width.toLong() shl 16); b.u32(height.toLong() shl 16)
        b.end(p)
    }

    private fun mdhd(b: Mp4Buf, timescale: Long, durationUnits: Long) {
        val p = b.beginFull("mdhd", 1, 0)
        b.u64(0); b.u64(0); b.u32(timescale); b.u64(durationUnits)
        b.u16(0x55C4); b.u16(0)                         // language "und"
        b.end(p)
    }

    private fun hdlr(b: Mp4Buf, type: String, name: String) {
        val p = b.beginFull("hdlr", 0, 0)
        b.u32(0); b.fourcc(type); b.u32(0); b.u32(0); b.u32(0)
        b.bytes(name.toByteArray(Charsets.US_ASCII)); b.u8(0)
        b.end(p)
    }

    private fun dinf(b: Mp4Buf) {
        val d = b.begin("dinf")
        val dref = b.beginFull("dref", 0, 0)
        b.u32(1)
        val url = b.beginFull("url ", 0, 1)
        b.end(url)
        b.end(dref)
        b.end(d)
    }

    /** The tables a fragmented file leaves empty (the samples are described in each fragment). */
    private fun emptyTables(b: Mp4Buf) {
        var p = b.beginFull("stts", 0, 0); b.u32(0); b.end(p)
        p = b.beginFull("stsc", 0, 0); b.u32(0); b.end(p)
        p = b.beginFull("stsz", 0, 0); b.u32(0); b.u32(0); b.end(p)
        p = b.beginFull("stco", 0, 0); b.u32(0); b.end(p)
    }

    private fun writeVideoTrak(b: Mp4Buf, plannedMs: Long) {
        val trak = b.begin("trak")
        tkhd(b, VIDEO_TRACK, plannedMs, 0, video.width, video.height)
        val mdia = b.begin("mdia")
        mdhd(b, VIDEO_TIMESCALE, plannedDurationUs * VIDEO_TIMESCALE / 1_000_000L)
        hdlr(b, "vide", "VideoHandler")
        val minf = b.begin("minf")
        val vmhd = b.beginFull("vmhd", 0, 1)
        b.u16(0); b.u16(0); b.u16(0); b.u16(0)
        b.end(vmhd)
        dinf(b)
        val stbl = b.begin("stbl")
        val stsd = b.beginFull("stsd", 0, 0)
        b.u32(1)
        val avc1 = b.begin("avc1")
        b.zeros(6); b.u16(1)                            // reserved, data reference index
        b.u16(0); b.u16(0); b.u32(0); b.u32(0); b.u32(0)
        b.u16(video.width); b.u16(video.height)
        b.u32(0x00480000L); b.u32(0x00480000L)          // 72 dpi
        b.u32(0)
        b.u16(1)                                        // frame count
        b.zeros(32)                                     // compressor name
        b.u16(0x0018); b.u16(0xFFFF)                    // depth, pre-defined
        val avcC = b.begin("avcC")
        b.bytes(video.avc.avcC())
        b.end(avcC)
        b.end(avc1)
        b.end(stsd)
        emptyTables(b)
        b.end(stbl)
        b.end(minf)
        b.end(mdia)
        b.end(trak)
    }

    private fun writeAudioTrak(b: Mp4Buf, plannedMs: Long) {
        val a = audio!!
        val trak = b.begin("trak")
        tkhd(b, AUDIO_TRACK, plannedMs, 0x0100, 0, 0)
        val mdia = b.begin("mdia")
        mdhd(b, a.sampleRate.toLong(), plannedDurationUs * a.sampleRate.toLong() / 1_000_000L)
        hdlr(b, "soun", "SoundHandler")
        val minf = b.begin("minf")
        val smhd = b.beginFull("smhd", 0, 0)
        b.u16(0); b.u16(0)
        b.end(smhd)
        dinf(b)
        val stbl = b.begin("stbl")
        val stsd = b.beginFull("stsd", 0, 0)
        b.u32(1)
        val mp4a = b.begin("mp4a")
        b.zeros(6); b.u16(1)
        b.u16(0); b.u16(0); b.u32(0)                    // version, revision, vendor
        b.u16(a.channelCount); b.u16(16); b.u16(0); b.u16(0)
        b.u32(a.sampleRate.toLong() shl 16)
        val esds = b.beginFull("esds", 0, 0)
        b.bytes(Esds.payload(a.audioSpecificConfig, a.bitrate))
        b.end(esds)
        b.end(mp4a)
        b.end(stsd)
        emptyTables(b)
        b.end(stbl)
        b.end(minf)
        b.end(mdia)
        b.end(trak)
    }

    // ---------------------------------------------------------------------------------------------------------
    // Video in, fragments out
    // ---------------------------------------------------------------------------------------------------------

    /**
     * One encoded frame, as MediaCodec produced it (Annex B). A new fragment begins at every key frame (or when the current one
     * has grown to [MAX_FRAGMENT_BYTES]), so each fragment can be decoded on its own and the file can be sought.
     */
    fun writeVideoSample(annexB: ByteArray, off: Int, len: Int, ptsUs: Long, key: Boolean) {
        check(started && !finished) { "the writer is not open" }
        val data = AnnexB.toLengthPrefixed(annexB, off, len)
        if (pending.isNotEmpty()) {
            require(ptsUs > pending[pending.size - 1].ptsUs) { "video frames must arrive in presentation order" }
            if (key || pendingBytes >= MAX_FRAGMENT_BYTES) flushVideo(ptsUs)
        }
        pending.add(VSample(ptsUs, key, data))
        pendingBytes += data.size.toLong()
    }

    /** Writes everything held as one fragment. [endPtsUs] is where the next frame starts, which ends the last held frame. */
    private fun flushVideo(endPtsUs: Long) {
        val n = pending.size
        val dts = LongArray(n + 1) { if (it < n) videoDts(pending[it].ptsUs) else videoDts(endPtsUs) }
        val durations = LongArray(n) { dts[it + 1] - dts[it] }
        val sizes = IntArray(n) { pending[it].data.size }
        val flags = IntArray(n) { if (pending[it].key) SYNC else NON_SYNC }

        // the audio that plays during this stretch
        val aud = ArrayList<SpooledSample>()
        val src = audioSource
        if (audio != null && src != null) {
            while (true) {
                val p = src.peekPtsUs() ?: break
                if (p >= endPtsUs) break
                aud.add(src.next()!!)
            }
        }
        val written = Track(VIDEO_TRACK, dts[0], durations, sizes, flags, pending.map { it.data })
        val audioTrack = if (aud.isEmpty()) null else audioRun(aud, src!!)
        writeFragment(written, audioTrack)
        videoSamples += n
        lastEndPtsUs = endPtsUs
        pending.clear()
        pendingBytes = 0L
    }

    /** The audio samples [aud] as a track run; the last one lasts until the next audio sample begins. */
    private fun audioRun(aud: List<SpooledSample>, src: AudioSampleSource): Track {
        val a = audio!!
        val n = aud.size
        val dts = LongArray(n) { audioDts(aud[it].ptsUs) }
        val next = src.peekPtsUs()
        val durations = LongArray(n) {
            if (it + 1 < n) dts[it + 1] - dts[it]
            else if (next != null) audioDts(next) - dts[it]
            else a.samplesPerFrame.toLong()
        }
        return Track(AUDIO_TRACK, dts[0], durations, IntArray(n) { aud[it].data.size }, IntArray(n) { SYNC }, aud.map { it.data })
    }

    private class Track(
        val id: Int,
        val baseDts: Long,
        val durations: LongArray,
        val sizes: IntArray,
        val flags: IntArray,
        val payloads: List<ByteArray>
    ) {
        val count: Int get() = sizes.size
        val bytes: Long get() = sizes.fold(0L) { acc, s -> acc + s }
    }

    private fun writeFragment(video: Track?, audio: Track?) {
        val tracks = listOfNotNull(video, audio)
        var moofSize = MOOF_FIXED
        for (t in tracks) moofSize += TRAF_FIXED + TRAF_PER_SAMPLE * t.count
        val payload = tracks.fold(0L) { acc, t -> acc + t.bytes }
        val bigMdat = payload + 8L > 0xFFFFFFFFL
        val mdatHeader = if (bigMdat) 16 else 8
        val moofOffset = sink.position

        val b = Mp4Buf(moofSize + 32)
        val moof = b.begin("moof")
        val mfhd = b.beginFull("mfhd", 0, 0)
        b.u32(sequence)
        b.end(mfhd)
        var dataOffset = (moofSize + mdatHeader).toLong()
        for (t in tracks) {
            val traf = b.begin("traf")
            val tfhd = b.beginFull("tfhd", 0, TFHD_DEFAULT_BASE_IS_MOOF)
            b.u32(t.id.toLong())
            b.end(tfhd)
            val tfdt = b.beginFull("tfdt", 1, 0)
            b.u64(t.baseDts)
            b.end(tfdt)
            val trun = b.beginFull("trun", 0, TRUN_FLAGS)
            b.u32(t.count.toLong())
            b.u32(dataOffset)
            for (i in 0 until t.count) {
                b.u32(t.durations[i]); b.u32(t.sizes[i].toLong()); b.u32(t.flags[i].toLong() and 0xFFFFFFFFL)
            }
            b.end(trun)
            b.end(traf)
            dataOffset += t.bytes
        }
        b.end(moof)
        check(b.size == moofSize) { "fragment header is ${b.size} bytes, expected $moofSize" }

        // the mdat's header goes after the moof in the same buffer
        if (bigMdat) {
            b.u32(1L); b.fourcc("mdat"); b.u64(payload + 16L)
        } else {
            b.u32(payload + 8L); b.fourcc("mdat")
        }
        b.writeTo(sink)
        for (t in tracks) for (p in t.payloads) sink.write(p, 0, p.size)
        sink.flush()

        if (video != null) videoIndex.add(longArrayOf(video.baseDts, moofOffset))
        if (audio != null) audioIndex.add(longArrayOf(audio.baseDts, moofOffset, if (video != null) 2L else 1L))
        if (audio != null) audioSamples += audio.count
        sequence++
        fragments++
    }

    // ---------------------------------------------------------------------------------------------------------
    // The end of the file
    // ---------------------------------------------------------------------------------------------------------

    /**
     * Writes the last frames, any narration that runs past the last picture, and the closing index. Safe to call after an error
     * too: what was written is already playable, and this just tidies the end.
     */
    fun finish() {
        if (finished) return
        check(started) { "the writer was never started" }
        if (pending.isNotEmpty()) flushVideo(pending[pending.size - 1].ptsUs + frameDurationUs)
        val src = audioSource
        if (audio != null && src != null) {
            while (src.peekPtsUs() != null) {
                val chunk = ArrayList<SpooledSample>()
                while (chunk.size < AUDIO_CHUNK_SAMPLES) chunk.add(src.next() ?: break)
                if (chunk.isEmpty()) break
                writeFragment(null, audioRun(chunk, src))
            }
        }
        writeMfra()
        sink.flush()
        finished = true
    }

    private fun writeMfra() {
        val b = Mp4Buf(64 + 25 * (videoIndex.size + audioIndex.size))
        val mfra = b.begin("mfra")
        tfra(b, VIDEO_TRACK, videoIndex, false)
        if (audio != null) tfra(b, AUDIO_TRACK, audioIndex, true)
        val mfro = b.beginFull("mfro", 0, 0)
        b.u32((b.size - mfra + 4).toLong())             // the whole mfra: everything so far (its 12-byte mfro header included) plus this 4-byte field
        b.end(mfro)
        b.end(mfra)
        b.writeTo(sink)
    }

    private fun tfra(b: Mp4Buf, trackId: Int, index: List<LongArray>, hasTrafNumber: Boolean) {
        val p = b.beginFull("tfra", 1, 0)
        b.u32(trackId.toLong())
        b.u32(0)                                        // one-byte traf / trun / sample numbers
        b.u32(index.size.toLong())
        for (e in index) {
            b.u64(e[0]); b.u64(e[1])
            b.u8(if (hasTrafNumber) e[2].toInt() else 1); b.u8(1); b.u8(1)
        }
        b.end(p)
    }
}
