package com.videoslidemaker.app.export

/**
 * Holds items (encoded sound samples) in the order they arrive, each with its time in microseconds, and hands them
 * back out only up to a given time. The export uses it to write the sound track into the MP4 in step with the
 * pictures instead of all of it before the first picture: a file whose sound is stored as one block ahead of the
 * whole video is "not interleaved", and some players (and sharing apps) then play only the first seconds of sound.
 *
 * Plain Kotlin (no Android classes) so it can be tested on an ordinary JVM.
 */
class TimedQueue<T> {
    private val items = ArrayDeque<Pair<Long, T>>()

    val size: Int get() = items.size

    fun add(timeUs: Long, item: T) {
        items.addLast(timeUs to item)
    }

    /** Gives every held item whose time is at or before [uptoUs] to [sink], oldest first, and forgets it. */
    fun drainUpTo(uptoUs: Long, sink: (T) -> Unit) {
        while (items.isNotEmpty() && items.first().first <= uptoUs) {
            sink(items.removeFirst().second)
        }
    }

    /** Gives everything that is left to [sink], oldest first, and forgets it. */
    fun drainAll(sink: (T) -> Unit) {
        while (items.isNotEmpty()) {
            sink(items.removeFirst().second)
        }
    }
}
