package com.videoslidemaker.app.export

import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import java.io.File
import java.io.RandomAccessFile

/** Encodes 16-bit PCM into AAC and writes it into the shared muxer's audio track. */
class AudioEncoder(
    private val sampleRate: Int,
    private val channelCount: Int,
    bitrateBps: Int,
    private val muxer: MuxerHolder
) {
    private val mimeType = MediaFormat.MIMETYPE_AUDIO_AAC
    private val codec: MediaCodec = MediaCodec.createEncoderByType(mimeType)
    private val bufferInfo = MediaCodec.BufferInfo()
    private var trackIndex = -1
    private var totalFramesWritten = 0L
    private var released = false

    init {
        val format = MediaFormat.createAudioFormat(mimeType, sampleRate, channelCount).apply {
            setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
            setInteger(MediaFormat.KEY_BIT_RATE, bitrateBps)
        }
        codec.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        codec.start()
    }

    /** Streams 16-bit PCM from [file] (its first [totalBytes] bytes) into the encoder in small
     *  fixed-size chunks — memory use here is bounded by the chunk size, not by how long the
     *  video is, since the source data now lives on disk instead of in one big array.
     *
     *  [checkCancelled] is called every loop so Cancel Export takes effect straight away, and
     *  [onProgress] is called (0..1) about once per percent so the screen never looks frozen
     *  while a long recording is being encoded. */
    fun feedPcmFile(
        file: File,
        totalBytes: Long,
        checkCancelled: () -> Unit = {},
        onProgress: (Float) -> Unit = {}
    ) {
        val frameBytes = 2 * channelCount
        RandomAccessFile(file, "r").use { raf ->
            val readBuf = ByteArray(64 * 1024)
            var offset = 0L
            var lastReportedPercent = -1
            while (offset < totalBytes) {
                checkCancelled()
                // This wait (up to 10 ms) is the natural back-pressure: it only blocks while the
                // encoder genuinely has no free input buffer.
                val inputIndex = codec.dequeueInputBuffer(TIMEOUT_US)
                if (inputIndex >= 0) {
                    val buffer = codec.getInputBuffer(inputIndex)
                    if (buffer != null) {
                        buffer.clear()
                        var chunk = minOf(buffer.capacity().toLong(), totalBytes - offset, readBuf.size.toLong()).toInt()
                        chunk -= chunk % frameBytes // never split a stereo frame across two buffers
                        val ptsUs = totalFramesWritten * 1_000_000L / sampleRate
                        if (chunk <= 0) {
                            // Nothing usable left (or a degenerate buffer): hand the slot back and stop.
                            codec.queueInputBuffer(inputIndex, 0, 0, ptsUs, 0)
                            offset = totalBytes
                        } else {
                            raf.readFully(readBuf, 0, chunk)
                            buffer.put(readBuf, 0, chunk)
                            codec.queueInputBuffer(inputIndex, 0, chunk, ptsUs, 0)
                            totalFramesWritten += chunk / frameBytes
                            offset += chunk
                        }
                    } else {
                        // Should not happen for a validly dequeued index; queue an empty
                        // buffer so this slot isn't left dangling, and retry next loop.
                        codec.queueInputBuffer(inputIndex, 0, 0, 0, 0)
                    }
                }
                // Pull out whatever is ready WITHOUT waiting. This used to wait 10 ms on every
                // single pass, which for a ~20 minute recording added up to minutes of dead time
                // with no progress shown at all.
                drain(endOfStream = false, checkCancelled = checkCancelled)

                val percent = if (totalBytes > 0) (offset * 100 / totalBytes).toInt() else 100
                if (percent != lastReportedPercent) {
                    lastReportedPercent = percent
                    onProgress(percent / 100f)
                }
            }
        }
    }

    fun finish(checkCancelled: () -> Unit = {}) {
        // The end-of-stream marker MUST get into the encoder. Before, a single attempt was made and
        // if the encoder's input queue happened to be full at that instant the marker was silently
        // skipped, and the drain below then waited forever for an end that was never coming.
        var waitedMs = 0L
        var queued = false
        while (!queued) {
            checkCancelled()
            val inputIndex = codec.dequeueInputBuffer(TIMEOUT_US)
            if (inputIndex >= 0) {
                val ptsUs = totalFramesWritten * 1_000_000L / sampleRate
                codec.queueInputBuffer(inputIndex, 0, 0, ptsUs, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                queued = true
            } else {
                drain(endOfStream = false, checkCancelled = checkCancelled) // frees up queue space
                waitedMs += TIMEOUT_US / 1000
                if (waitedMs > STALL_LIMIT_MS) {
                    throw IllegalStateException("The phone's audio encoder stopped responding while finishing the sound track.")
                }
            }
        }
        drain(endOfStream = true, checkCancelled = checkCancelled)
        release()
    }

    /** Safe to call any number of times, and after a failure — frees the hardware codec so an
     *  aborted export can't leave it allocated and break the next one. */
    fun release() {
        if (released) return
        released = true
        try { codec.stop() } catch (_: Throwable) {}
        try { codec.release() } catch (_: Throwable) {}
    }

    private fun drain(endOfStream: Boolean, checkCancelled: () -> Unit = {}) {
        var idleMs = 0L
        while (true) {
            checkCancelled()
            // Only block while waiting for the final end-of-stream; while feeding, never wait.
            val timeoutUs = if (endOfStream) TIMEOUT_US else 0L
            val outputIndex = codec.dequeueOutputBuffer(bufferInfo, timeoutUs)
            when {
                outputIndex == MediaCodec.INFO_TRY_AGAIN_LATER -> {
                    if (!endOfStream) return
                    idleMs += TIMEOUT_US / 1000
                    if (idleMs > STALL_LIMIT_MS) {
                        throw IllegalStateException("The phone's audio encoder stopped responding while finishing the sound track.")
                    }
                }
                outputIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                    trackIndex = muxer.addAudioTrack(codec.outputFormat)
                    idleMs = 0L
                }
                outputIndex >= 0 -> {
                    idleMs = 0L
                    val encodedData = codec.getOutputBuffer(outputIndex)
                    if (encodedData != null && bufferInfo.size > 0 &&
                        (bufferInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0
                    ) {
                        encodedData.position(bufferInfo.offset)
                        encodedData.limit(bufferInfo.offset + bufferInfo.size)
                        muxer.writeAudioSample(trackIndex, encodedData, bufferInfo)
                    }
                    codec.releaseOutputBuffer(outputIndex, false)
                    if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) return
                }
            }
        }
    }

    companion object {
        private const val TIMEOUT_US = 10_000L
        private const val STALL_LIMIT_MS = 30_000L
    }
}
