package com.videoslidemaker.app.adjust

/**
 * The adjustment log as one string, so it can live in the saved draft and "undo last adjustment" still works after the app
 * was closed. One batch per line: `id|atEpochMs|label|index:textHash:before:after,index:textHash:before:after,...`.
 * Damaged or unknown pieces are skipped, never fatal (like the logo cleaner's log).
 */
object AdjustLogCodec {

    fun encode(log: List<AdjustBatch>): String =
        log.joinToString("\n") { b ->
            val label = b.label.replace('|', ' ').replace('\n', ' ').replace('\r', ' ')
            "${b.id}|${b.atEpochMs}|$label|" + b.changes.joinToString(",") { "${it.index}:${it.textHash}:${it.beforeMs}:${it.afterMs}" }
        }

    fun decode(text: String?): List<AdjustBatch> {
        if (text.isNullOrBlank()) return emptyList()
        val out = ArrayList<AdjustBatch>()
        for (line in text.split('\n')) {
            val p = line.split('|', limit = 4)
            if (p.size != 4) continue
            val id = p[0].toLongOrNull() ?: continue
            val at = p[1].toLongOrNull() ?: continue
            val changes = ArrayList<AppliedLine>()
            var bad = false
            if (p[3].isNotEmpty()) {
                for (piece in p[3].split(',')) {
                    val q = piece.split(':')
                    if (q.size != 4) { bad = true; break }
                    val index = q[0].toIntOrNull()
                    val hash = q[1].toIntOrNull()
                    val before = q[2].toLongOrNull()
                    val after = q[3].toLongOrNull()
                    if (index == null || hash == null || before == null || after == null) { bad = true; break }
                    changes.add(AppliedLine(index, hash, before, after))
                }
            }
            if (!bad) out.add(AdjustBatch(id, p[2], at, changes))
        }
        return out.takeLast(AdjustLog.MAX_BATCHES)
    }
}
