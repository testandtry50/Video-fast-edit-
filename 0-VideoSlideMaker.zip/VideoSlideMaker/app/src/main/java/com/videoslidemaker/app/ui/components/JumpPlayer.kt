package com.videoslidemaker.app.ui.components

import android.media.MediaPlayer
import android.net.Uri
import android.widget.VideoView
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.videoslidemaker.app.check.CheckFormat
import com.videoslidemaker.app.ui.theme.Accent
import com.videoslidemaker.app.ui.theme.Muted
import com.videoslidemaker.app.ui.theme.TextMain
import kotlinx.coroutines.delay

/**
 * Holds the state of the [JumpPlayer] and does the jumping.
 *
 * [jumpTo] seeks to the CLOSEST frame (not the previous keyframe, which is what a plain VideoView does and can be
 * seconds away) and starts playing. It starts a quarter of a second early so the beginning of the word is heard, and
 * says so on screen. A jump asked for before the file has opened is done as soon as it has.
 */
@Stable
class MediaJumper {
    private var view: VideoView? = null
    private var player: MediaPlayer? = null
    private var pending: Long? = null

    var ready by mutableStateOf(false)
        private set
    var hasVideo by mutableStateOf(false)
        private set
    var playing by mutableStateOf(false)
        private set
    var failed: String? by mutableStateOf(null)
        internal set
    var positionMs by mutableLongStateOf(0L)
        private set
    var durationMs by mutableLongStateOf(0L)
        private set

    /** Where the last jump was aimed (the exact place of the problem) and what it was. */
    var jumpedTo: Long? by mutableStateOf(null)
        private set
    var jumpLabel: String by mutableStateOf("")
        private set

    internal fun attach(v: VideoView) {
        view = v
    }

    internal fun onPrepared(mp: MediaPlayer) {
        player = mp
        ready = true
        durationMs = mp.duration.toLong().coerceAtLeast(0L)
        hasVideo = mp.videoWidth > 0
        pending?.let {
            pending = null
            seekAndPlay(mp, it)
        }
    }

    internal fun onCompleted() {
        playing = false
    }

    /** Jumps to [ms] on the recording's clock and plays. */
    fun jumpTo(ms: Long, label: String) {
        jumpedTo = ms
        jumpLabel = label
        val mp = player
        if (mp == null || !ready) {
            pending = ms
            return
        }
        seekAndPlay(mp, ms)
    }

    private fun seekAndPlay(mp: MediaPlayer, ms: Long) {
        try {
            mp.seekTo(maxOf(0L, ms - LEAD_IN_MS), MediaPlayer.SEEK_CLOSEST)
            positionMs = maxOf(0L, ms - LEAD_IN_MS)
            if (!mp.isPlaying) mp.start()
            playing = true
        } catch (e: IllegalStateException) {
            failed = "The player stopped. Leave this screen and open it again."
        }
    }

    /** Moves to [ms] exactly where it is, without changing whether it plays. */
    fun seekTo(ms: Long) {
        val mp = player ?: return
        try {
            mp.seekTo(ms.coerceIn(0L, maxOf(0L, durationMs)), MediaPlayer.SEEK_CLOSEST)
            positionMs = ms
        } catch (_: IllegalStateException) {
        }
    }

    fun toggle() {
        val mp = player ?: return
        try {
            if (mp.isPlaying) {
                mp.pause()
                playing = false
            } else {
                mp.start()
                playing = true
            }
        } catch (_: IllegalStateException) {
        }
    }

    fun pause() {
        val mp = player ?: return
        try {
            if (mp.isPlaying) mp.pause()
            playing = false
        } catch (_: IllegalStateException) {
        }
    }

    fun poll() {
        val mp = player ?: return
        try {
            positionMs = mp.currentPosition.toLong()
            playing = mp.isPlaying
        } catch (_: IllegalStateException) {
        }
    }

    fun release() {
        try {
            view?.stopPlayback()
        } catch (_: Exception) {
        }
        view = null
        player = null
        pending = null
        ready = false
        playing = false
    }

    companion object {
        /** A jump starts this long before the word, so its first sound is not clipped by the recognizer's timing error. */
        const val LEAD_IN_MS = 250L
    }
}

@Composable
fun rememberMediaJumper(): MediaJumper = remember { MediaJumper() }

/** The video (or a dark panel for an audio file) with play / pause, a seek bar and the time. Call inside `key(uri)`. */
@Composable
fun JumpPlayer(uri: Uri, jumper: MediaJumper, modifier: Modifier = Modifier) {
    // never keep playing in the background
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner, jumper) {
        val observer = LifecycleEventObserver { _, event -> if (event == Lifecycle.Event.ON_PAUSE) jumper.pause() }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }
    DisposableEffect(uri) { onDispose { jumper.release() } }
    LaunchedEffect(jumper.ready) {
        while (jumper.ready) {
            jumper.poll()
            delay(100)
        }
    }

    Column(modifier.fillMaxWidth()) {
        Box(Modifier.fillMaxWidth().height(200.dp).background(Color.Black), contentAlignment = Alignment.Center) {
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { ctx ->
                    VideoView(ctx).also { v ->
                        jumper.attach(v)
                        v.setOnPreparedListener { mp -> jumper.onPrepared(mp) }
                        v.setOnCompletionListener { jumper.onCompleted() }
                        v.setOnErrorListener { _, _, _ ->
                            jumper.failed = "This phone can't play that file here."
                            true
                        }
                        v.setVideoURI(uri)
                    }
                }
            )
            val problem = jumper.failed
            when {
                problem != null -> Text(problem, color = Color.White, modifier = Modifier.padding(16.dp))
                !jumper.ready -> Text("Opening…", color = Color.White.copy(alpha = 0.7f))
                !jumper.hasVideo -> Text("Audio only", color = Color.White.copy(alpha = 0.7f))
                else -> Unit
            }
        }

        val max = maxOf(1L, jumper.durationMs)
        var dragging by remember { mutableStateOf<Float?>(null) }
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            IconButton(onClick = jumper::toggle, enabled = jumper.ready) {
                Icon(
                    if (jumper.playing) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                    contentDescription = if (jumper.playing) "Pause" else "Play",
                    tint = Accent
                )
            }
            Slider(
                value = (dragging ?: jumper.positionMs.toFloat()).coerceIn(0f, max.toFloat()),
                onValueChange = { dragging = it },
                onValueChangeFinished = {
                    dragging?.let { jumper.seekTo(it.toLong()) }
                    dragging = null
                },
                valueRange = 0f..max.toFloat(),
                enabled = jumper.ready,
                colors = appSliderColors(),
                modifier = Modifier.weight(1f)
            )
        }
        Text(
            CheckFormat.clock((dragging?.toLong()) ?: jumper.positionMs) + "  /  " + CheckFormat.clock(jumper.durationMs),
            color = TextMain,
            style = MaterialTheme.typography.bodySmall,
            fontFamily = FontFamily.Monospace,
            modifier = Modifier.padding(horizontal = 16.dp)
        )
        val at = jumper.jumpedTo
        Text(
            if (at == null) "Tap a problem below to jump to that place in the audio."
            else "Jumped to ${CheckFormat.clock(at)} · ${jumper.jumpLabel} (it starts a moment early so you hear the beginning)",
            color = Muted,
            style = MaterialTheme.typography.bodySmall,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
        )
    }
}
