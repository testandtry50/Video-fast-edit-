package com.videoslidemaker.app.ui.components

import android.content.Context
import androidx.compose.foundation.ScrollState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.staggeredgrid.LazyStaggeredGridState
import androidx.compose.foundation.lazy.staggeredgrid.rememberLazyStaggeredGridState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.videoslidemaker.app.ui.theme.Outline
import com.videoslidemaker.app.ui.theme.Surface
import com.videoslidemaker.app.ui.theme.TextMain
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** A remembered spot: which item was first on screen, and how far that item is scrolled. */
data class ScrollPos(val index: Int = 0, val offset: Int = 0)

/**
 * NEW: remembers where each photo list / page was scrolled to.
 *
 * Before, every screen made a brand-new scroll state each time it appeared, so going to Preview
 * and coming back put the photo pool at the first photo again. This keeps the positions in the
 * ViewModel (so they survive switching screens) AND in a tiny file (so they survive closing the
 * app). It is a separate small file on purpose - saving a scroll position must never re-write the
 * big project draft with thousands of photos in it.
 */
class ScrollMemory(
    context: Context,
    private val scope: CoroutineScope,
    /** NEW (2.14): every project keeps its own positions file (see ProjectRepository.scrollFileName). */
    fileName: String = "scroll_positions.json"
) {
    private val file = File(context.filesDir, fileName)
    private val tempFile = File(context.filesDir, "$fileName.tmp")
    private val positions = HashMap<String, ScrollPos>()
    private var saveJob: Job? = null
    @Volatile private var discarded = false
    // true while there is a change that has not reached the file yet
    @Volatile private var dirty = false
    // only one write at a time may touch the temp file (the delayed save and flushNow() could otherwise overlap)
    private val writeLock = Any()

    init {
        try {
            if (file.exists()) {
                val root = JSONObject(file.readText())
                val keys = root.keys()
                while (keys.hasNext()) {
                    val key = keys.next()
                    val pair = root.optJSONArray(key) ?: continue
                    positions[key] = ScrollPos(pair.optInt(0, 0).coerceAtLeast(0), pair.optInt(1, 0).coerceAtLeast(0))
                }
            }
        } catch (_: Exception) {
            // A damaged positions file just means "start from the top" - never a crash.
        }
    }

    @Synchronized
    fun get(key: String): ScrollPos = positions[key] ?: ScrollPos()

    /** The project this belongs to was deleted: stop saving and remove the file. */
    @Synchronized
    fun discard() {
        discarded = true
        saveJob?.cancel()
        try {
            file.delete()
            tempFile.delete()
        } catch (_: Exception) {
        }
    }

    @Synchronized
    fun set(key: String, pos: ScrollPos) {
        if (discarded || positions[key] == pos) return
        positions[key] = pos
        dirty = true
        // Saved a moment after the LAST change, not on every scrolled pixel.
        saveJob?.cancel()
        saveJob = scope.launch {
            delay(400)
            withContext(Dispatchers.IO) { write() }
        }
    }

    /**
     * NEW: write any change that is still waiting for its delayed save RIGHT NOW. Called when the app goes to the
     * background - otherwise swiping the app away within a moment of your last tap would lose that last position.
     */
    @Synchronized
    fun flushNow() {
        if (discarded || !dirty) return
        saveJob?.cancel()
        saveJob = null
        write()
    }

    private fun write() {
        if (discarded) return
        try {
            val json = synchronized(this) {
                dirty = false
                val root = JSONObject()
                positions.forEach { (key, pos) -> root.put(key, JSONArray().put(pos.index).put(pos.offset)) }
                root.toString()
            }
            synchronized(writeLock) {
                tempFile.writeText(json)
                if (!tempFile.renameTo(file)) {
                    file.delete()
                    tempFile.renameTo(file)
                }
            }
        } catch (_: Exception) {
            // Best-effort, like the project draft.
            dirty = true
        }
    }
}

/** A photo grid whose scroll position is remembered under [key] (plain grid state if [memory] is null). */
@Composable
fun rememberSavedStaggeredGridState(memory: ScrollMemory?, key: String, itemCount: Int): LazyStaggeredGridState {
    val start = remember(memory, key) { memory?.get(key) ?: ScrollPos() }
    val state = rememberLazyStaggeredGridState(start.index, start.offset)
    val count by rememberUpdatedState(itemCount)
    if (memory != null) {
        LaunchedEffect(state, memory, key) {
            snapshotFlow { ScrollPos(state.firstVisibleItemIndex, state.firstVisibleItemScrollOffset) }
                .collect { pos -> if (count > 0) memory.set(key, pos) }
        }
    }
    return state
}

/** A scrolling list (like the Photos screen) whose scroll position is remembered under [key]. */
@Composable
fun rememberSavedLazyListState(memory: ScrollMemory?, key: String, itemCount: Int): LazyListState {
    val start = remember(memory, key) { memory?.get(key) ?: ScrollPos() }
    val state = rememberLazyListState(start.index, start.offset)
    val count by rememberUpdatedState(itemCount)
    if (memory != null) {
        LaunchedEffect(state, memory, key) {
            snapshotFlow { ScrollPos(state.firstVisibleItemIndex, state.firstVisibleItemScrollOffset) }
                .collect { pos -> if (count > 0) memory.set(key, pos) }
        }
    }
    return state
}

/** A whole page that scrolls with a plain scrollbar (like the Match screen), position remembered under [key]. */
@Composable
fun rememberSavedScrollState(memory: ScrollMemory?, key: String): ScrollState {
    val start = remember(memory, key) { memory?.get(key)?.offset ?: 0 }
    val state = rememberScrollState(start)
    if (memory != null) {
        LaunchedEffect(state, memory, key) {
            snapshotFlow { state.value }.collect { value -> memory.set(key, ScrollPos(0, value)) }
        }
    }
    return state
}

/**
 * NEW: three big buttons - Top, Middle, Bottom - floating over a long photo list, so reaching the
 * start, the halfway point or the end is one thumb tap instead of a long drag.
 */
@Composable
fun JumpBar(
    onTop: () -> Unit,
    onMiddle: () -> Unit,
    onBottom: () -> Unit,
    modifier: Modifier = Modifier
) {
    val shape = RoundedCornerShape(24.dp)
    Row(
        modifier
            .clip(shape)
            .background(Surface.copy(alpha = 0.94f))
            .border(1.dp, Outline, shape)
            .padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        JumpChip("⬆ Top", onTop)
        JumpChip("● Middle", onMiddle)
        JumpChip("⬇ Bottom", onBottom)
    }
}

@Composable
private fun JumpChip(label: String, onClick: () -> Unit) {
    Box(
        Modifier
            .heightIn(min = 44.dp)
            .clip(RoundedCornerShape(20.dp))
            .clickable(role = Role.Button, onClick = onClick)
            .padding(horizontal = 14.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(label, style = MaterialTheme.typography.labelLarge, color = TextMain, fontWeight = FontWeight.Bold, maxLines = 1)
    }
}
