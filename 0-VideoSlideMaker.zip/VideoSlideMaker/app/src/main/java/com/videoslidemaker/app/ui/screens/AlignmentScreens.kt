package com.videoslidemaker.app.ui.screens

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Warning

import com.videoslidemaker.app.ui.components.AppProgressBar
import androidx.compose.ui.semantics.Role
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.layout.heightIn
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.videoslidemaker.app.align.AlignmentDecision
import com.videoslidemaker.app.align.AlignmentFormat
import com.videoslidemaker.app.align.AlignmentItem
import com.videoslidemaker.app.align.AlignmentEvidence
import com.videoslidemaker.app.align.AlignmentSection
import com.videoslidemaker.app.align.AlignmentStatus
import com.videoslidemaker.app.align.DriftPoint
import com.videoslidemaker.app.model.SentenceSlide
import com.videoslidemaker.app.model.UiState
import com.videoslidemaker.app.ui.components.AlertBox
import com.videoslidemaker.app.ui.components.AlertStyle
import com.videoslidemaker.app.ui.components.BadgeChip
import com.videoslidemaker.app.ui.components.CompactButton
import com.videoslidemaker.app.ui.components.PrimaryButton
import com.videoslidemaker.app.ui.components.SecondaryButton
import com.videoslidemaker.app.ui.components.SectionCard
import com.videoslidemaker.app.ui.components.SettingRow
import com.videoslidemaker.app.ui.components.SettingToggleRow
import com.videoslidemaker.app.ui.theme.Accent
import com.videoslidemaker.app.ui.theme.Bg
import com.videoslidemaker.app.ui.theme.OnAccent
import com.videoslidemaker.app.ui.theme.Outline
import com.videoslidemaker.app.ui.theme.BorderColor
import com.videoslidemaker.app.ui.theme.CardBg
import com.videoslidemaker.app.ui.theme.Green
import com.videoslidemaker.app.ui.theme.Muted
import com.videoslidemaker.app.ui.theme.Red
import com.videoslidemaker.app.ui.theme.TextMain
import com.videoslidemaker.app.ui.theme.Yellow
import com.videoslidemaker.app.viewmodel.AppViewModel
import kotlin.math.abs

/** Results belong to a particular script; if its lines were edited since, they must not be applied. */
private fun alignmentIsStale(items: List<AlignmentItem>, slides: List<SentenceSlide>): Boolean =
    items.isNotEmpty() && items.any { val s = slides.getOrNull(it.index); s == null || s.text != it.text }

private fun driftSummary(drift: List<DriftPoint>): String? {
    if (drift.size < 2) return null
    val first = drift.first()
    val last = drift.last()
    var lo = drift[0].shiftMs
    var hi = drift[0].shiftMs
    for (d in drift) {
        if (d.shiftMs < lo) lo = d.shiftMs
        if (d.shiftMs > hi) hi = d.shiftMs
    }
    val line = "Timing error: ${AlignmentFormat.signedSeconds(first.shiftMs)} near ${AlignmentFormat.clock(first.transcriptMs)}" +
        " → ${AlignmentFormat.signedSeconds(last.shiftMs)} near ${AlignmentFormat.clock(last.transcriptMs)}"
    return if (hi - lo >= 300) "$line (it changes through the recording, range ${AlignmentFormat.signedSeconds(lo)} to ${AlignmentFormat.signedSeconds(hi)})"
    else "$line (roughly constant)"
}

// =====================================================================================
// Card on the Script screen
// =====================================================================================

@Composable
fun AlignmentCard(state: UiState, viewModel: AppViewModel, onPickRecording: () -> Unit) {
    val a = state.alignment
    val slides = state.slides
    val stale = remember(a.items, slides) { alignmentIsStale(a.items, slides) }
    val hasResults = a.items.isNotEmpty() && !stale
    val high = a.items.count { it.status == AlignmentStatus.HIGH_CONFIDENCE }
    val pendingHigh = a.items.count {
        it.status == AlignmentStatus.HIGH_CONFIDENCE && it.decision == AlignmentDecision.PENDING && it.canApply
    }
    val review = a.items.count { it.status == AlignmentStatus.NEEDS_REVIEW }
    val matching = a.items.count { it.status == AlignmentStatus.MATCHES }
    val unaligned = a.items.count { it.status == AlignmentStatus.ESTIMATED || it.status == AlignmentStatus.CANNOT_ALIGN }
    val accuracyUi by viewModel.accuracy.ui.collectAsState()
    val hasModel = accuracyUi.modelName != null
    val anyCorrected = slides.any { it.originalTimestampSec != null }

    SectionCard(title = "Automatic timestamp alignment", modifier = Modifier.padding(bottom = 12.dp)) {
        Text(
            "Choose the audio or video recording. The app listens to it and checks every line's timestamp against when that line is really spoken. The recording is treated as the truth; your original timestamps are always kept.",
            style = MaterialTheme.typography.bodySmall,
            color = Muted,
            modifier = Modifier.padding(bottom = 10.dp)
        )

        UploadZone(
            done = a.recordingUri != null,
            icon = Icons.Filled.Mic,
            title = a.recordingName ?: "Tap to choose the recording",
            hint = "Audio or video file (mp3, m4a, wav, mp4…)",
            onClick = onPickRecording
        )

        if (hasModel) {
            SettingToggleRow(
                "Also use the words (speech recognition)",
                "More accurate: it finds lines at any offset and notices when the spoken words don't match the line. Slower: the app listens to the whole recording once.",
                a.useWords,
                viewModel::setAlignmentUseWords
            )
        } else {
            Text(
                "Tip: set up a speech model in the \"Check the words against the audio\" box below, and this also uses the words that are spoken, which is much more accurate.",
                style = MaterialTheme.typography.bodySmall,
                color = Muted,
                modifier = Modifier.padding(bottom = 6.dp)
            )
        }

        SettingToggleRow(
            "Apply high-confidence corrections automatically",
            "Off by default. Otherwise you choose per line, or apply them all in one tap.",
            a.autoApply,
            viewModel::setAutoApplyAlignment
        )

        if (!state.scriptLoaded) {
            AlertBox("Load a script first — there are no timestamps to check yet.", AlertStyle.INFO, Modifier.padding(vertical = 6.dp))
        }

        if (a.running) {
            Text(
                "${a.stage.ifBlank { "Working…" }}  ${a.percent}%",
                style = MaterialTheme.typography.bodyMedium,
                color = TextMain,
                modifier = Modifier.padding(top = 8.dp)
            )
            AppProgressBar(a.percent / 100f, Modifier.padding(vertical = 8.dp))
            SecondaryButton("Cancel", onClick = viewModel::cancelAlignment)
        } else {
            PrimaryButton(
                if (hasResults) "Analyze again" else "Analyze timestamps",
                enabled = a.recordingUri != null && state.scriptLoaded,
                onClick = viewModel::runAlignment
            )
        }

        a.error?.let { AlertBox(it, AlertStyle.WARNING, Modifier.padding(top = 6.dp)) }
        a.notice?.let { AlertBox(it, AlertStyle.INFO, Modifier.padding(top = 6.dp)) }

        if (stale) {
            AlertBox(
                "The script was edited after the last analysis, so those results are hidden. Analyze again to get fresh ones.",
                AlertStyle.WARNING,
                Modifier.padding(top = 6.dp)
            )
        }

        if (hasResults && !a.running) {
            Text(
                "${a.items.size} lines checked",
                style = MaterialTheme.typography.titleSmall,
                color = TextMain,
                modifier = Modifier.padding(top = 12.dp, bottom = 6.dp)
            )
            BadgeChip("$matching already match the audio", AlertStyle.SUCCESS, Modifier.padding(bottom = 6.dp), Icons.Filled.CheckCircle)
            BadgeChip("$high high-confidence correction(s)", AlertStyle.INFO, Modifier.padding(bottom = 6.dp), Icons.Filled.Info)
            BadgeChip("$review need review", AlertStyle.WARNING, Modifier.padding(bottom = 6.dp), Icons.Filled.Warning)
            if (unaligned > 0) {
                BadgeChip("$unaligned can't be aligned confidently", AlertStyle.WARNING, Modifier.padding(bottom = 6.dp), Icons.Filled.Warning)
            }
            if (a.sections.isNotEmpty()) {
                Text(
                    "${a.sections.size} stretch(es) need your attention. They are listed at the top of the review.",
                    style = MaterialTheme.typography.bodySmall,
                    color = Muted,
                    modifier = Modifier.padding(bottom = 6.dp)
                )
            }
            driftSummary(a.drift)?.let {
                Text(it, style = MaterialTheme.typography.bodySmall, color = Muted, modifier = Modifier.padding(bottom = 8.dp))
            }
            if (a.clarityDb < 15f) {
                AlertBox(
                    "This recording is noisy or has little contrast between speech and background, so most lines are marked Needs review rather than corrected.",
                    AlertStyle.WARNING,
                    Modifier.padding(bottom = 8.dp)
                )
            }
            PrimaryButton("Review & choose per line →", onClick = { viewModel.openAlignmentReview(true) })
            SecondaryButton(
                "Apply all high-confidence ($pendingHigh)",
                enabled = pendingHigh > 0,
                onClick = viewModel::applyAllHighConfidence
            )
        }
        if (anyCorrected && !a.running) {
            SecondaryButton("Restore all original timestamps", onClick = viewModel::revertAllAlignment)
        }

        Text(
            if (a.usedWords) {
                "How it checks: it matches the words the recognizer hears to your text (which tells it WHICH sentence each line is, at any offset), then places each line on the exact moment the speech starts in the audio. The confidence is an estimate of the chance the time is within 0.25 s of the truth. It was measured on simulated recordings, is never shown above 99%, and real recordings can be harder. Lines it can't place are left alone and listed."
            } else {
                "How it checks: it compares the pauses and how long each stretch of speech lasts with your text. Without a speech model it does not know which words are spoken, so it can't tell if the wrong words are spoken at the right rhythm. The confidence is an estimate (never 100%), and lines it can't place are left alone and listed."
            },
            style = MaterialTheme.typography.bodySmall,
            color = Muted,
            modifier = Modifier.padding(top = 10.dp)
        )
    }
}

// =====================================================================================
// Full-screen review
// =====================================================================================

private enum class ReviewFilter(val label: String) {
    ALL("All"),
    CORRECTIONS("Corrections"),
    REVIEW("Needs review"),
    UNALIGNED("Can't align"),
    MATCHING("Matching");

    fun accepts(item: AlignmentItem): Boolean = when (this) {
        ALL -> true
        CORRECTIONS -> item.status == AlignmentStatus.HIGH_CONFIDENCE
        REVIEW -> item.status == AlignmentStatus.NEEDS_REVIEW
        UNALIGNED -> item.status == AlignmentStatus.ESTIMATED || item.status == AlignmentStatus.CANNOT_ALIGN
        MATCHING -> item.status == AlignmentStatus.MATCHES
    }
}

@Composable
fun AlignmentReviewScreen(state: UiState, viewModel: AppViewModel) {
    BackHandler { viewModel.openAlignmentReview(false) }
    var filter by remember { mutableStateOf(ReviewFilter.ALL) }
    val items = state.alignment.items
    val shown = remember(items, filter) { items.filter { filter.accepts(it) } }
    val pendingHigh = items.count {
        it.status == AlignmentStatus.HIGH_CONFIDENCE && it.decision == AlignmentDecision.PENDING && it.canApply
    }

    Column(Modifier.fillMaxSize().background(Bg)) {
        Row(
            Modifier.fillMaxWidth().padding(start = 4.dp, end = 12.dp, top = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(onClick = { viewModel.openAlignmentReview(false) }) { Text("← Back", color = Accent) }
            Text(
                "Timestamp review",
                style = MaterialTheme.typography.titleMedium,
                color = TextMain,
                fontWeight = FontWeight.Bold
            )
        }
        Column(Modifier.padding(horizontal = 16.dp)) {
            PrimaryButton(
                "Apply all high-confidence ($pendingHigh)",
                enabled = pendingHigh > 0,
                onClick = viewModel::applyAllHighConfidence
            )
            state.alignment.notice?.let {
                AlertBox(it, AlertStyle.INFO, Modifier.padding(vertical = 4.dp))
            }
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                for (f in ReviewFilter.entries) {
                    val count = items.count { f.accepts(it) }
                    val selected = f == filter
                    Box(
                        Modifier
                            .heightIn(min = 44.dp)
                            .clip(RoundedCornerShape(22.dp))
                            .background(if (selected) Accent else CardBg)
                            .border(1.dp, if (selected) Accent else Outline, RoundedCornerShape(22.dp))
                            .selectable(selected = selected, role = Role.RadioButton, onClick = { filter = f })
                            .padding(horizontal = 16.dp, vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            (if (selected) "✓ " else "") + "${f.label} ($count)",
                            color = if (selected) OnAccent else TextMain,
                            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }
        }
        LazyColumn(
            Modifier.weight(1f),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (state.alignment.sections.isNotEmpty()) {
                item(key = "sections") { SectionsBlock(state.alignment.sections) }
            }
            item(key = "bulk-actions") {
                BulkActions(
                    filter = filter,
                    shown = shown,
                    onKeepAll = { viewModel.keepOriginalForAll(shown.map { it.index }) },
                    onApplyAll = { viewModel.applyCorrectionToAll(shown.map { it.index }) }
                )
            }
            items(shown, key = { it.index }) { item -> AlignmentItemCard(item, viewModel) }
        }
    }
}

/** The stretches of the script that could not be aligned with confidence, so the user knows exactly where to look. */
@Composable
private fun SectionsBlock(sections: List<AlignmentSection>) {
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(CardBg)
            .border(1.dp, Yellow.copy(alpha = 0.6f), RoundedCornerShape(12.dp))
            .padding(12.dp)
    ) {
        Text(
            "Not confidently aligned (${sections.size})",
            color = Yellow,
            fontWeight = FontWeight.Bold,
            style = MaterialTheme.typography.bodyMedium
        )
        Text(
            "Check these stretches by ear. Nothing in them is changed unless you apply it.",
            color = Muted,
            style = MaterialTheme.typography.bodySmall,
            modifier = Modifier.padding(top = 2.dp, bottom = 6.dp)
        )
        for (sec in sections.take(12)) {
            Text(
                (if (sec.lineCount == 1) "Line ${sec.firstIndex + 1}" else "Lines ${sec.firstIndex + 1}–${sec.lastIndex + 1}") +
                    "  ·  ${AlignmentFormat.clock(sec.startMs)}" +
                    (if (sec.lineCount > 1) " – ${AlignmentFormat.clock(sec.endMs)}" else "") +
                    "  ·  " + (if (sec.status == AlignmentStatus.CANNOT_ALIGN) "can't be aligned" else if (sec.status == AlignmentStatus.NEEDS_REVIEW) "needs review" else "estimated"),
                color = TextMain,
                style = MaterialTheme.typography.bodySmall,
                fontWeight = FontWeight.Medium,
                modifier = Modifier.padding(top = 4.dp)
            )
            Text(sec.reason, color = Muted, style = MaterialTheme.typography.bodySmall)
        }
        if (sections.size > 12) {
            Text("…and ${sections.size - 12} more.", color = Muted, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 4.dp))
        }
    }
}

/**
 * "Keep original" / "Apply correction" for many lines at once. They act on the lines currently
 * listed, so with the All tab they cover every line, and with another tab only that group.
 */
@Composable
private fun BulkActions(
    filter: ReviewFilter,
    shown: List<AlignmentItem>,
    onKeepAll: () -> Unit,
    onApplyAll: () -> Unit
) {
    val total = shown.size
    val applicable = shown.count { it.canApply }
    val anyToKeep = shown.any { it.decision != AlignmentDecision.KEPT_ORIGINAL }
    val scope = if (filter == ReviewFilter.ALL) "all $total" else "${filter.label} ($total)"
    Column(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            BulkButton(
                title = "Keep original",
                subtitle = scope,
                enabled = anyToKeep,
                highlighted = false,
                onClick = onKeepAll
            )
            BulkButton(
                title = "Apply correction",
                subtitle = if (applicable == total) scope else "$applicable of $total",
                enabled = applicable > 0,
                highlighted = true,
                onClick = onApplyAll
            )
        }
        Text(
            if (filter == ReviewFilter.ALL) "These two buttons cover every line. Pick a tab above to limit them to that group."
            else "These two buttons cover only the $total line(s) in \u201c${filter.label}\u201d. Switch to All to include every line.",
            color = Muted,
            style = MaterialTheme.typography.bodySmall,
            modifier = Modifier.padding(top = 6.dp, bottom = 2.dp)
        )
    }
}

@Composable
private fun RowScope.BulkButton(
    title: String,
    subtitle: String,
    enabled: Boolean,
    highlighted: Boolean,
    onClick: () -> Unit
) {
    OutlinedButton(
        onClick = onClick,
        enabled = enabled,
        modifier = Modifier.weight(1f).heightIn(min = 56.dp),
        shape = RoundedCornerShape(12.dp),
        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 10.dp),
        border = BorderStroke(1.dp, if (highlighted && enabled) Accent else if (enabled) Outline else BorderColor),
        colors = ButtonDefaults.outlinedButtonColors(contentColor = if (highlighted) Accent else TextMain)
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(title, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, maxLines = 1)
            Text(
                subtitle,
                style = MaterialTheme.typography.labelSmall,
                color = LocalContentColor.current.copy(alpha = 0.7f),
                textAlign = TextAlign.Center,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun AlignmentItemCard(item: AlignmentItem, viewModel: AppViewModel) {
    val (statusColor, statusLabel) = when (item.status) {
        AlignmentStatus.MATCHES -> Green to "Matches audio"
        AlignmentStatus.HIGH_CONFIDENCE -> Accent to "High confidence"
        AlignmentStatus.NEEDS_REVIEW -> Yellow to "Needs review"
        AlignmentStatus.ESTIMATED -> Yellow to "Estimated from neighbouring lines"
        AlignmentStatus.CANNOT_ALIGN -> Red to "Cannot be aligned"
    }
    val applied = item.decision == AlignmentDecision.APPLIED
    val adjusted = item.decision == AlignmentDecision.ADJUSTED
    val diff = item.diffMs
    val diffColor = when {
        diff == null -> Muted
        abs(diff) <= 100 -> Green
        abs(diff) <= 1000 -> Yellow
        else -> Red
    }

    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(CardBg)
            .border(1.dp, BorderColor, RoundedCornerShape(12.dp))
            .padding(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("#${item.index + 1}", color = TextMain, fontWeight = FontWeight.Bold, modifier = Modifier.padding(end = 8.dp))
            Text(statusLabel, color = statusColor, style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
            if (item.status != AlignmentStatus.CANNOT_ALIGN) {
                Text(
                    (if (item.status == AlignmentStatus.ESTIMATED) "about " else "") + "${AlignmentFormat.percent(item.confidence)}% sure",
                    color = Muted,
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
        Text(
            item.text.ifBlank { "(no sentence)" },
            color = Muted,
            style = MaterialTheme.typography.bodySmall,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(top = 4.dp, bottom = 6.dp)
        )

        ValueRow("Original", AlignmentFormat.clock(item.originalMs), TextMain)
        ValueRow("Detected in audio", item.detectedMs?.let { AlignmentFormat.clock(it) } ?: "—", TextMain)
        ValueRow("Difference", diff?.let { AlignmentFormat.signedSeconds(it) } ?: "—", diffColor)
        ValueRow(
            "Corrected",
            when {
                applied || adjusted -> AlignmentFormat.clock(item.currentMs)
                item.detectedMs != null -> AlignmentFormat.clock(item.detectedMs) + "  (if applied)"
                else -> "—"
            },
            if (applied || adjusted) Green else Muted
        )
        item.detectedEndMs?.let { ValueRow("Speech ends about", AlignmentFormat.clock(it), Muted) }
        item.precisionMs?.let { ValueRow("Precision", AlignmentFormat.plusMinus(it), Muted) }
        if (item.evidence != AlignmentEvidence.NONE) {
            ValueRow(
                "Based on",
                when (item.evidence) {
                    AlignmentEvidence.AUDIO -> "the audio (pauses and speech length)"
                    AlignmentEvidence.AUDIO_AND_WORDS -> "the audio and the spoken words"
                    AlignmentEvidence.WORDS -> "the spoken words"
                    AlignmentEvidence.ESTIMATE -> "the lines around it (no evidence of its own)"
                    AlignmentEvidence.NONE -> ""
                },
                Muted
            )
        }

        item.reason?.let {
            Text(it, color = Yellow, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 6.dp))
        }
        when (item.decision) {
            AlignmentDecision.APPLIED -> Text("✔ Correction applied", color = Green, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 6.dp))
            AlignmentDecision.KEPT_ORIGINAL -> Text("Original kept", color = Muted, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 6.dp))
            AlignmentDecision.ADJUSTED -> Text("✎ Adjusted by hand", color = Green, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 6.dp))
            AlignmentDecision.PENDING -> {}
        }

        Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            CompactButton(
                "Keep original",
                onClick = { viewModel.keepOriginalTimestamp(item.index) },
                enabled = item.decision != AlignmentDecision.KEPT_ORIGINAL
            )
            CompactButton(
                if (applied) "Applied ✓" else "Apply correction",
                onClick = { viewModel.applyAlignmentCorrection(item.index) },
                enabled = item.canApply && !applied
            )
        }
    }
}

@Composable
private fun ValueRow(label: String, value: String, valueColor: Color) {
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
        Text(label, color = Muted, style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
        Text(value, color = valueColor, style = MaterialTheme.typography.bodySmall, fontFamily = FontFamily.Monospace)
    }
}
