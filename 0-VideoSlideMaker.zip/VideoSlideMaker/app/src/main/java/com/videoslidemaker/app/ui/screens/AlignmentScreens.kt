package com.videoslidemaker.app.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.videoslidemaker.app.align.AlignmentDecision
import com.videoslidemaker.app.align.AlignmentFormat
import com.videoslidemaker.app.align.AlignmentItem
import com.videoslidemaker.app.align.AlignmentStatus
import com.videoslidemaker.app.align.DriftPoint
import com.videoslidemaker.app.model.SentenceSlide
import com.videoslidemaker.app.model.UiState
import com.videoslidemaker.app.ui.components.AlertBox
import com.videoslidemaker.app.ui.components.AlertStyle
import com.videoslidemaker.app.ui.components.BadgeChip
import com.videoslidemaker.app.ui.components.CompactButton
import com.videoslidemaker.app.ui.components.PrimaryButton
import com.videoslidemaker.app.ui.components.SecondaryButton
import com.videoslidemaker.app.ui.components.SectionCard
import com.videoslidemaker.app.ui.components.SettingRow
import com.videoslidemaker.app.ui.components.ToggleSwitch
import com.videoslidemaker.app.ui.theme.Accent
import com.videoslidemaker.app.ui.theme.BgDark
import com.videoslidemaker.app.ui.theme.BorderColor
import com.videoslidemaker.app.ui.theme.CardBg
import com.videoslidemaker.app.ui.theme.Green
import com.videoslidemaker.app.ui.theme.Muted
import com.videoslidemaker.app.ui.theme.Red
import com.videoslidemaker.app.ui.theme.TextMain
import com.videoslidemaker.app.ui.theme.Yellow
import com.videoslidemaker.app.viewmodel.AppViewModel
import kotlin.math.abs
import kotlin.math.roundToInt

/** Results belong to a particular script; if its lines were edited since, they must not be applied. */
private fun alignmentIsStale(items: List<AlignmentItem>, slides: List<SentenceSlide>): Boolean =
    items.isNotEmpty() && items.any { val s = slides.getOrNull(it.index); s == null || s.text != it.text }

private fun driftSummary(drift: List<DriftPoint>): String? {
    if (drift.size < 2) return null
    val first = drift.first()
    val last = drift.last()
    var lo = drift[0].shiftMs
    var hi = drift[0].shiftMs
    for (d in drift) {
        if (d.shiftMs < lo) lo = d.shiftMs
        if (d.shiftMs > hi) hi = d.shiftMs
    }
    val line = "Timing error: ${AlignmentFormat.signedSeconds(first.shiftMs)} near ${AlignmentFormat.clock(first.transcriptMs)}" +
        " → ${AlignmentFormat.signedSeconds(last.shiftMs)} near ${AlignmentFormat.clock(last.transcriptMs)}"
    return if (hi - lo >= 300) "$line (it changes through the recording, range ${AlignmentFormat.signedSeconds(lo)} to ${AlignmentFormat.signedSeconds(hi)})"
    else "$line (roughly constant)"
}

// =====================================================================================
// Card on the Script screen
// =====================================================================================

@Composable
fun AlignmentCard(state: UiState, viewModel: AppViewModel, onPickRecording: () -> Unit) {
    val a = state.alignment
    val slides = state.slides
    val stale = remember(a.items, slides) { alignmentIsStale(a.items, slides) }
    val hasResults = a.items.isNotEmpty() && !stale
    val high = a.items.count { it.status == AlignmentStatus.HIGH_CONFIDENCE }
    val pendingHigh = a.items.count {
        it.status == AlignmentStatus.HIGH_CONFIDENCE && it.decision == AlignmentDecision.PENDING && it.canApply
    }
    val review = a.items.count { it.status == AlignmentStatus.NEEDS_REVIEW }
    val matching = a.items.count { it.status == AlignmentStatus.MATCHES }
    val anyCorrected = slides.any { it.originalTimestampSec != null }

    SectionCard(title = "⏱ Automatic timestamp alignment", modifier = Modifier.padding(bottom = 12.dp)) {
        Text(
            "Choose the audio or video recording. The app listens to it and checks every line's timestamp against when that line is really spoken. The recording is treated as the truth; your original timestamps are always kept.",
            style = MaterialTheme.typography.bodySmall,
            color = Muted,
            modifier = Modifier.padding(bottom = 10.dp)
        )

        UploadZone(
            done = a.recordingUri != null,
            icon = "🎙️",
            title = a.recordingName ?: "Tap to choose the recording",
            hint = "Audio or video file (mp3, m4a, wav, mp4…)",
            onClick = onPickRecording
        )

        SettingRow("Apply high-confidence corrections automatically", "Off by default. Otherwise you choose per line, or apply them all in one tap.") {
            ToggleSwitch(a.autoApply, viewModel::setAutoApplyAlignment)
        }

        if (!state.scriptLoaded) {
            AlertBox("Load a script first — there are no timestamps to check yet.", AlertStyle.INFO, Modifier.padding(vertical = 6.dp))
        }

        if (a.running) {
            Text(
                "${a.stage.ifBlank { "Working…" }}  ${a.percent}%",
                style = MaterialTheme.typography.bodyMedium,
                color = TextMain,
                modifier = Modifier.padding(top = 8.dp)
            )
            Box(
                Modifier
                    .padding(vertical = 8.dp)
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp))
                    .background(BorderColor)
            ) {
                Box(
                    Modifier
                        .fillMaxWidth((a.percent / 100f).coerceIn(0f, 1f))
                        .height(6.dp)
                        .background(Accent)
                )
            }
            SecondaryButton("Cancel", onClick = viewModel::cancelAlignment)
        } else {
            PrimaryButton(
                if (hasResults) "Analyze again" else "Analyze timestamps",
                enabled = a.recordingUri != null && state.scriptLoaded,
                onClick = viewModel::runAlignment
            )
        }

        a.error?.let { AlertBox("⚠️ $it", AlertStyle.WARNING, Modifier.padding(top = 6.dp)) }
        a.notice?.let { AlertBox(it, AlertStyle.INFO, Modifier.padding(top = 6.dp)) }

        if (stale) {
            AlertBox(
                "The script was edited after the last analysis, so those results are hidden. Analyze again to get fresh ones.",
                AlertStyle.WARNING,
                Modifier.padding(top = 6.dp)
            )
        }

        if (hasResults && !a.running) {
            Text(
                "${a.items.size} lines checked",
                style = MaterialTheme.typography.titleSmall,
                color = TextMain,
                modifier = Modifier.padding(top = 12.dp, bottom = 6.dp)
            )
            BadgeChip("✅ $matching already match the audio", AlertStyle.SUCCESS, Modifier.padding(bottom = 6.dp))
            BadgeChip("🛠 $high high-confidence correction(s)", AlertStyle.INFO, Modifier.padding(bottom = 6.dp))
            BadgeChip("⚠️ $review need review", AlertStyle.WARNING, Modifier.padding(bottom = 6.dp))
            driftSummary(a.drift)?.let {
                Text(it, style = MaterialTheme.typography.bodySmall, color = Muted, modifier = Modifier.padding(bottom = 8.dp))
            }
            if (a.clarityDb < 15f) {
                AlertBox(
                    "This recording is noisy or has little contrast between speech and background, so most lines are marked Needs review rather than corrected.",
                    AlertStyle.WARNING,
                    Modifier.padding(bottom = 8.dp)
                )
            }
            PrimaryButton("Review & choose per line →", onClick = { viewModel.openAlignmentReview(true) })
            SecondaryButton(
                "Apply all high-confidence ($pendingHigh)",
                enabled = pendingHigh > 0,
                onClick = viewModel::applyAllHighConfidence
            )
        }
        if (anyCorrected && !a.running) {
            SecondaryButton("Restore all original timestamps", onClick = viewModel::revertAllAlignment)
        }

        Text(
            "How it checks: it compares the pauses and how long each stretch of speech lasts with your text. It does not transcribe the words, so it can't tell if the wrong words are spoken at the right rhythm.",
            style = MaterialTheme.typography.bodySmall,
            color = Muted,
            modifier = Modifier.padding(top = 10.dp)
        )
    }
}

// =====================================================================================
// Full-screen review
// =====================================================================================

private enum class ReviewFilter(val label: String) {
    ALL("All"),
    CORRECTIONS("Corrections"),
    REVIEW("Needs review"),
    MATCHING("Matching");

    fun accepts(item: AlignmentItem): Boolean = when (this) {
        ALL -> true
        CORRECTIONS -> item.status == AlignmentStatus.HIGH_CONFIDENCE
        REVIEW -> item.status == AlignmentStatus.NEEDS_REVIEW
        MATCHING -> item.status == AlignmentStatus.MATCHES
    }
}

@Composable
fun AlignmentReviewScreen(state: UiState, viewModel: AppViewModel) {
    BackHandler { viewModel.openAlignmentReview(false) }
    var filter by remember { mutableStateOf(ReviewFilter.ALL) }
    val items = state.alignment.items
    val shown = remember(items, filter) { items.filter { filter.accepts(it) } }
    val pendingHigh = items.count {
        it.status == AlignmentStatus.HIGH_CONFIDENCE && it.decision == AlignmentDecision.PENDING && it.canApply
    }

    Column(Modifier.fillMaxSize().background(BgDark)) {
        Row(
            Modifier.fillMaxWidth().padding(start = 4.dp, end = 12.dp, top = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(onClick = { viewModel.openAlignmentReview(false) }) { Text("← Back", color = Accent) }
            Text(
                "Timestamp review",
                style = MaterialTheme.typography.titleMedium,
                color = TextMain,
                fontWeight = FontWeight.Bold
            )
        }
        Column(Modifier.padding(horizontal = 16.dp)) {
            PrimaryButton(
                "Apply all high-confidence ($pendingHigh)",
                enabled = pendingHigh > 0,
                onClick = viewModel::applyAllHighConfidence
            )
            state.alignment.notice?.let {
                AlertBox(it, AlertStyle.INFO, Modifier.padding(vertical = 4.dp))
            }
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                for (f in ReviewFilter.entries) {
                    val count = items.count { f.accepts(it) }
                    val selected = f == filter
                    Box(
                        Modifier
                            .clip(RoundedCornerShape(20.dp))
                            .background(if (selected) Accent else CardBg)
                            .border(1.dp, if (selected) Accent else BorderColor, RoundedCornerShape(20.dp))
                            .clickable { filter = f }
                            .padding(horizontal = 14.dp, vertical = 8.dp)
                    ) {
                        Text("${f.label} ($count)", color = if (selected) Color.White else TextMain, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
        LazyColumn(
            Modifier.weight(1f),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item(key = "bulk-actions") {
                BulkActions(
                    filter = filter,
                    shown = shown,
                    onKeepAll = { viewModel.keepOriginalForAll(shown.map { it.index }) },
                    onApplyAll = { viewModel.applyCorrectionToAll(shown.map { it.index }) }
                )
            }
            items(shown, key = { it.index }) { item -> AlignmentItemCard(item, viewModel) }
        }
    }
}

/**
 * "Keep original" / "Apply correction" for many lines at once. They act on the lines currently
 * listed, so with the All tab they cover every line, and with another tab only that group.
 */
@Composable
private fun BulkActions(
    filter: ReviewFilter,
    shown: List<AlignmentItem>,
    onKeepAll: () -> Unit,
    onApplyAll: () -> Unit
) {
    val total = shown.size
    val applicable = shown.count { it.canApply }
    val anyToKeep = shown.any { it.decision != AlignmentDecision.KEPT_ORIGINAL }
    val scope = if (filter == ReviewFilter.ALL) "all $total" else "${filter.label} ($total)"
    Column(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            BulkButton(
                title = "Keep original",
                subtitle = scope,
                enabled = anyToKeep,
                highlighted = false,
                onClick = onKeepAll
            )
            BulkButton(
                title = "Apply correction",
                subtitle = if (applicable == total) scope else "$applicable of $total",
                enabled = applicable > 0,
                highlighted = true,
                onClick = onApplyAll
            )
        }
        Text(
            if (filter == ReviewFilter.ALL) "These two buttons cover every line. Pick a tab above to limit them to that group."
            else "These two buttons cover only the $total line(s) in \u201c${filter.label}\u201d. Switch to All to include every line.",
            color = Muted,
            style = MaterialTheme.typography.bodySmall,
            modifier = Modifier.padding(top = 6.dp, bottom = 2.dp)
        )
    }
}

@Composable
private fun RowScope.BulkButton(
    title: String,
    subtitle: String,
    enabled: Boolean,
    highlighted: Boolean,
    onClick: () -> Unit
) {
    OutlinedButton(
        onClick = onClick,
        enabled = enabled,
        modifier = Modifier.weight(1f),
        shape = RoundedCornerShape(12.dp),
        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 10.dp),
        border = BorderStroke(1.dp, if (highlighted && enabled) Accent else BorderColor),
        colors = ButtonDefaults.outlinedButtonColors(contentColor = if (highlighted) Accent else TextMain)
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(title, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, maxLines = 1)
            Text(
                subtitle,
                style = MaterialTheme.typography.labelSmall,
                color = LocalContentColor.current.copy(alpha = 0.7f),
                textAlign = TextAlign.Center,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun AlignmentItemCard(item: AlignmentItem, viewModel: AppViewModel) {
    val (statusColor, statusLabel) = when (item.status) {
        AlignmentStatus.MATCHES -> Green to "Matches audio"
        AlignmentStatus.HIGH_CONFIDENCE -> Accent to "High confidence"
        AlignmentStatus.NEEDS_REVIEW -> Yellow to "Needs review"
    }
    val applied = item.decision == AlignmentDecision.APPLIED
    val diff = item.diffMs
    val diffColor = when {
        diff == null -> Muted
        abs(diff) <= 100 -> Green
        abs(diff) <= 1000 -> Yellow
        else -> Red
    }

    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(CardBg)
            .border(1.dp, BorderColor, RoundedCornerShape(12.dp))
            .padding(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("#${item.index + 1}", color = TextMain, fontWeight = FontWeight.Bold, modifier = Modifier.padding(end = 8.dp))
            Text(statusLabel, color = statusColor, style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
            Text(
                "${(item.confidence * 100).roundToInt()}% sure",
                color = Muted,
                style = MaterialTheme.typography.bodySmall
            )
        }
        Text(
            item.text.ifBlank { "(no sentence)" },
            color = Muted,
            style = MaterialTheme.typography.bodySmall,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(top = 4.dp, bottom = 6.dp)
        )

        ValueRow("Original", AlignmentFormat.clock(item.originalMs), TextMain)
        ValueRow("Detected in audio", item.detectedMs?.let { AlignmentFormat.clock(it) } ?: "—", TextMain)
        ValueRow("Difference", diff?.let { AlignmentFormat.signedSeconds(it) } ?: "—", diffColor)
        ValueRow(
            "Corrected",
            when {
                applied -> AlignmentFormat.clock(item.currentMs)
                item.detectedMs != null -> AlignmentFormat.clock(item.detectedMs) + "  (if applied)"
                else -> "—"
            },
            if (applied) Green else Muted
        )
        item.detectedEndMs?.let { ValueRow("Speech ends about", AlignmentFormat.clock(it), Muted) }

        item.reason?.let {
            Text(it, color = Yellow, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 6.dp))
        }
        when (item.decision) {
            AlignmentDecision.APPLIED -> Text("✔ Correction applied", color = Green, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 6.dp))
            AlignmentDecision.KEPT_ORIGINAL -> Text("Original kept", color = Muted, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 6.dp))
            AlignmentDecision.PENDING -> {}
        }

        Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            CompactButton(
                "Keep original",
                onClick = { viewModel.keepOriginalTimestamp(item.index) },
                enabled = item.decision != AlignmentDecision.KEPT_ORIGINAL
            )
            CompactButton(
                if (applied) "Applied ✓" else "Apply correction",
                onClick = { viewModel.applyAlignmentCorrection(item.index) },
                enabled = item.canApply && !applied
            )
        }
    }
}

@Composable
private fun ValueRow(label: String, value: String, valueColor: Color) {
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
        Text(label, color = Muted, style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
        Text(value, color = valueColor, style = MaterialTheme.typography.bodySmall, fontFamily = FontFamily.Monospace)
    }
}
