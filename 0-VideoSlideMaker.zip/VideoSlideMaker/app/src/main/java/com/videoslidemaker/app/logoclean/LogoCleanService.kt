package com.videoslidemaker.app.logoclean

import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.videoslidemaker.app.MainActivity
import com.videoslidemaker.app.R
import com.videoslidemaker.app.VideoSlideMakerApp

/**
 * Keeps the app alive while thousands of photos are being cleaned.
 *
 * The cleaning itself runs in [LogoCleanController]; this service only does two jobs so Android does not
 * stop or slow the app when it is not on screen: it makes the app a "foreground" app with a progress
 * notification, and it holds a wake lock so the CPU keeps working with the screen off. It is started when a
 * big run begins and stopped when it ends (or is stopped by the person).
 */
class LogoCleanService : Service() {

    private var wakeLock: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        running = true
        startForeground(NOTIFICATION_ID, buildNotification(this, 0, "Starting\u2026"))
        val power = getSystemService(Context.POWER_SERVICE) as? PowerManager
        wakeLock = power?.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "VideoSlideMaker:logoclean")?.apply {
            setReferenceCounted(false)
            acquire(WAKE_LOCK_TIMEOUT_MS) // safety cap, released as soon as the run ends
        }
    }

    // If Android ever kills the app, there is no run left to look after - so do not restart this.
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_NOT_STICKY

    /**
     * Android 15 and newer end a "data sync" foreground service after about 6 hours in a day. The system then calls
     * this, and the service has to stop within a few seconds - otherwise Android crashes the app. A run over many
     * thousands of photos can last that long, so: tell the run to stop (everything finished so far is kept, and
     * pressing the button again carries on), then stop.
     */
    override fun onTimeout(startId: Int, fgsType: Int) {
        try {
            timeoutListener?.invoke()
        } catch (e: Exception) {
        }
        stopSelf()
    }

    override fun onDestroy() {
        running = false
        wakeLock?.let { if (it.isHeld) it.release() }
        wakeLock = null
        super.onDestroy()
    }

    companion object {
        private const val NOTIFICATION_ID = 43
        private const val DONE_NOTIFICATION_ID = 44
        private const val WAKE_LOCK_TIMEOUT_MS = 12 * 60 * 60 * 1000L

        @Volatile
        private var running = false

        /** Called when Android ends the service for running too long (see [onTimeout]). Set by the cleaning run. */
        @Volatile
        var timeoutListener: (() -> Unit)? = null

        fun start(context: Context) {
            try {
                ContextCompat.startForegroundService(context, Intent(context, LogoCleanService::class.java))
            } catch (e: Exception) {
                // Not allowed to start right now: the cleaning still works, it just may pause in the background.
            }
        }

        fun stop(context: Context) {
            try {
                context.stopService(Intent(context, LogoCleanService::class.java))
            } catch (e: Exception) {
            }
        }

        /** Moves the progress bar in the notification. Does nothing unless a run is going. */
        fun update(context: Context, percent: Int, text: String) {
            if (!running) return
            try {
                context.getSystemService(NotificationManager::class.java)
                    ?.notify(NOTIFICATION_ID, buildNotification(context, percent, text))
            } catch (e: Exception) {
            }
        }

        /** A normal, dismissible "finished" notification, for when the person has left the app during a long run. */
        fun notifyDone(context: Context, text: String) {
            try {
                val notification = NotificationCompat.Builder(context, VideoSlideMakerApp.LOGO_CLEAN_CHANNEL_ID)
                    .setContentTitle("Photo cleaning finished")
                    .setContentText(text)
                    .setStyle(NotificationCompat.BigTextStyle().bigText(text))
                    .setSmallIcon(R.drawable.ic_notification)
                    .setAutoCancel(true)
                    .setContentIntent(openAppIntent(context))
                    .build()
                context.getSystemService(NotificationManager::class.java)?.notify(DONE_NOTIFICATION_ID, notification)
            } catch (e: Exception) {
            }
        }

        // Opens the app's existing screen instead of starting a second copy of it (a second copy would
        // have none of the run that is in progress).
        private fun openAppIntent(context: Context): PendingIntent {
            val launch = context.packageManager.getLaunchIntentForPackage(context.packageName)
                ?: Intent(context, MainActivity::class.java)
            return PendingIntent.getActivity(context, 0, launch, PendingIntent.FLAG_IMMUTABLE)
        }

        private fun buildNotification(context: Context, percent: Int, text: String): Notification =
            NotificationCompat.Builder(context, VideoSlideMakerApp.LOGO_CLEAN_CHANNEL_ID)
                .setContentTitle("Cleaning photos \u2013 $percent%")
                .setContentText(text)
                .setSmallIcon(R.drawable.ic_notification)
                .setProgress(100, percent.coerceIn(0, 100), false)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setContentIntent(openAppIntent(context))
                .build()
    }
}
