package com.videoslidemaker.app.audio

import com.videoslidemaker.app.audio.AudioLimits.MIN_CLIP_SEC

/**
 * NEW (2.17): every way of editing a clip, as plain functions that take clips and give back new clips. Nothing here
 * touches a file or the phone, so all of it is tested on a plain JVM (and mirrored in tools/audiomix-reference).
 * "Local" seconds are counted from the start of the clip's used part, which is what the sliders show.
 */
object ClipEdit {

    /** Cuts the beginning off: the clip keeps its place on the timeline but now starts later in the file. */
    fun trimStart(c: AudioClip, newSrcStartSec: Double): AudioClip {
        val hi = (c.srcEndSec - MIN_CLIP_SEC).coerceAtLeast(0.0)
        return c.copy(srcStartSec = newSrcStartSec.coerceIn(0.0, hi))
    }

    /** Cuts the end off (or, going the other way, brings it back, never past the end of the file). */
    fun trimEnd(c: AudioClip, newSrcEndSec: Double): AudioClip {
        val hi = if (c.sourceDurationSec > 0.0) c.sourceDurationSec else Double.MAX_VALUE
        val lo = c.srcStartSec + MIN_CLIP_SEC
        val end = newSrcEndSec.coerceIn(lo, maxOf(lo, hi))
        // NEW (2.19): when a part is marked, its end IS this end
        return c.copy(srcEndSec = end, markEndSec = if (c.markEndSec > 0.0) end else 0.0)
    }

    /** Splits one clip into two that sound exactly like the original, side by side. Too close to an edge = no change. */
    fun split(c: AudioClip, atLocalSec: Double, newId: String): List<AudioClip> {
        if (atLocalSec < MIN_CLIP_SEC || atLocalSec > c.lengthSec - MIN_CLIP_SEC) return listOf(c)
        val cut = c.srcStartSec + atLocalSec
        // (a slot's name and time range belong to the whole slot, so neither half keeps them - see BgSlots)
        // (NEW 2.19: a marked part ends where the first half ends)
        val first = c.copy(srcEndSec = cut, markEndSec = if (c.markEndSec > 0.0) cut else 0.0, fadeOutSec = 0.0, loop = false, slot = "", rangeEndSec = 0.0)
        val second = c.copy(id = newId, srcStartSec = cut, startSec = c.startSec + atLocalSec, fadeInSec = 0.0, loop = false, slot = "", rangeEndSec = 0.0)
        return listOf(first, second)
    }

    /**
     * Removes the stretch [fromLocalSec]..[toLocalSec] from clip [id]. With [closeGap] everything after it moves
     * earlier by the removed length (so the rest of that lane stays joined up); without, the gap stays as silence.
     * The first part that survives keeps the clip's id. Returns the whole lane.
     */
    fun cutInTrack(clips: List<AudioClip>, id: String, fromLocalSec: Double, toLocalSec: Double, closeGap: Boolean, newId: String): List<AudioClip> {
        val target = clips.firstOrNull { it.id == id } ?: return clips
        val len = target.lengthSec
        var from = fromLocalSec.coerceIn(0.0, len)
        var to = toLocalSec.coerceIn(0.0, len)
        if (to < from) { val t = from; from = to; to = t }
        if (to - from < MIN_CLIP_SEC) return clips

        val removed = to - from
        val oldEnd = target.endSec
        val leftOk = from >= MIN_CLIP_SEC
        val rightOk = len - to >= MIN_CLIP_SEC

        val parts = ArrayList<AudioClip>(2)
        if (leftOk) {
            val leftEnd = target.srcStartSec + from
            parts.add(target.copy(srcEndSec = leftEnd, markEndSec = if (target.markEndSec > 0.0) leftEnd else 0.0, fadeOutSec = 0.0, loop = false, slot = "", rangeEndSec = 0.0))
        }
        if (rightOk) {
            val rightStart = when {
                !leftOk && closeGap -> target.startSec
                !leftOk -> target.startSec + to
                closeGap -> target.startSec + from
                else -> target.startSec + to
            }
            parts.add(
                target.copy(
                    id = if (leftOk) newId else target.id,
                    srcStartSec = target.srcStartSec + to,
                    startSec = rightStart,
                    fadeInSec = if (leftOk) 0.0 else target.fadeInSec,
                    loop = false,
                    slot = "",
                    rangeEndSec = 0.0
                )
            )
        }

        val out = ArrayList<AudioClip>(clips.size + 1)
        for (c in clips) {
            when {
                c.id == id -> out.addAll(parts)
                closeGap && c.startSec >= oldEnd - 1e-6 -> out.add(c.copy(startSec = (c.startSec - removed).coerceAtLeast(0.0)))
                else -> out.add(c)
            }
        }
        return out
    }

    /** Joins clips into one continuous stretch: in time order, back to back (with [gapSec] between), from the earliest start. */
    fun combine(clips: List<AudioClip>, gapSec: Double = 0.0): List<AudioClip> {
        if (clips.isEmpty()) return clips
        val sorted = clips.sortedBy { it.startSec }
        var t = sorted.first().startSec
        val out = ArrayList<AudioClip>(sorted.size)
        for (c in sorted) {
            out.add(c.copy(startSec = t))
            t += c.lengthSec + gapSec
        }
        return out
    }

    /** Swaps a clip with its neighbour in time (earlier or later), keeping the pair where it was. */
    fun swapWithNeighbour(clips: List<AudioClip>, id: String, later: Boolean): List<AudioClip> {
        val sorted = clips.sortedBy { it.startSec }
        val i = sorted.indexOfFirst { it.id == id }
        val j = if (later) i + 1 else i - 1
        if (i < 0 || j < 0 || j >= sorted.size) return clips
        val firstOld = if (i < j) sorted[i] else sorted[j]
        val secondOld = if (i < j) sorted[j] else sorted[i]
        val gap = (secondOld.startSec - firstOld.endSec).coerceAtLeast(0.0)
        val newFirst = secondOld.copy(startSec = firstOld.startSec)
        val newSecond = firstOld.copy(startSec = newFirst.endSec + gap)
        return clips.map {
            when (it.id) {
                firstOld.id -> newSecond
                secondOld.id -> newFirst
                else -> it
            }
        }
    }

    /** Puts a different file in a clip's place: same spot, volume and fades, the whole new file. */
    fun replaceSource(c: AudioClip, uri: String, name: String, durationSec: Double): AudioClip =
        c.copy(uri = uri, name = name, sourceDurationSec = durationSec, srcStartSec = 0.0, srcEndSec = durationSec, markEndSec = 0.0)

    /** Background music that exactly covers a video of [totalSec]: too long = trimmed and faded out, too short = repeated. */
    fun fitToVideo(c: AudioClip, totalSec: Double): AudioClip {
        if (totalSec <= 0.0 || c.lengthSec <= 0.0) return c.copy(startSec = 0.0)
        return if (c.lengthSec >= totalSec) {
            c.copy(
                startSec = 0.0,
                srcEndSec = c.srcStartSec + totalSec,
                loop = false,
                fadeOutSec = maxOf(c.fadeOutSec, minOf(AudioLimits.END_FADE_SEC, totalSec / 2))
            )
        } else {
            c.copy(startSec = 0.0, loop = true)
        }
    }

    /**
     * The clip as it plays in a video of [totalSec] when [AudioClip.fitVideo] is on. Worked out fresh every time from the
     * whole file (never stored), so it follows the video when it gets longer OR shorter later.
     */
    fun followVideo(c: AudioClip, totalSec: Double): AudioClip {
        if (!c.fitVideo || totalSec <= 0.0) return c
        // NEW (2.19): the material is the MARKED part when there is one (a beat), else the rest of the file
        val avail = (c.materialEndSec - c.srcStartSec).coerceAtLeast(0.0)
        if (avail <= 0.0) return c
        return when {
            avail >= totalSec -> c.copy(startSec = 0.0, srcEndSec = c.srcStartSec + totalSec, loop = false)
            // NEW (2.19): a one-shot sound plays once instead of filling the video
            c.playOnce -> c.copy(startSec = 0.0, srcEndSec = c.srcStartSec + avail, loop = false)
            else -> c.copy(startSec = 0.0, srcEndSec = c.srcStartSec + avail, loop = true)
        }
    }

    /**
     * NEW (2.18): the clip as it plays when it is tied to a time range (a background-audio slot with a start AND an end).
     * It covers exactly [AudioClip.startSec]..[AudioClip.rangeEndSec]: a file that is longer is cut at the range's end, a
     * file that is shorter is repeated (with the same smooth join as any repeating track) until the range is filled.
     * Worked out fresh every time from the whole file (never stored), so changing the range later - or choosing another
     * file - always fits again. Clips without a range, empty slots and "always fit the video" clips come back unchanged.
     */
    fun followRange(c: AudioClip): AudioClip {
        if (c.fitVideo || c.isPlaceholder || !c.hasRange) return c
        val range = c.rangeEndSec - c.startSec
        // NEW (2.19): only the MARKED part (a beat, one voice, one sound) is cut or repeated to the range, not the whole file
        val avail = (c.materialEndSec - c.srcStartSec).coerceAtLeast(0.0)
        if (avail <= 0.0) return c
        return when {
            avail >= range - 1e-6 -> c.copy(srcEndSec = c.srcStartSec + range, loop = false)
            // NEW (2.19): a one-shot sound plays once at the start of the range
            c.playOnce -> c.copy(srcEndSec = c.srcStartSec + avail, loop = false)
            else -> c.copy(srcEndSec = c.srcStartSec + avail, loop = true)
        }
    }

    /** The background clip as it really plays in a video of [totalSec]: "always fit the video" first, then the slot's range. */
    fun asPlayed(c: AudioClip, totalSec: Double): AudioClip = followRange(followVideo(c, totalSec))

    // ------------------------------------------------------------------------------------
    // NEW (2.19): marking a part of the ORIGINAL file, and giving the result to a background-audio slot
    // ------------------------------------------------------------------------------------

    /**
     * "Keep only this part": the stretch [fromSrcSec]..[toSrcSec] of the ORIGINAL file (seconds counted from the very start
     * of the file, whatever was trimmed or fitted before) becomes the only part of the sound that is used. Everything else
     * is set aside - not deleted: [useWholeFile] brings it back. From then on, repeating or fitting the sound to the video
     * or to a scene repeats ONLY this part. The ends may be given in any order. Marking the whole file means "no mark".
     * A part shorter than the shortest clip, or a sound whose length is not known yet, changes nothing.
     * A part of [AudioLimits.EXACT_LOOP_AUTO_MAX_SEC] or less is a beat, so it is set to repeat exactly.
     */
    fun keepOnly(c: AudioClip, fromSrcSec: Double, toSrcSec: Double): AudioClip {
        if (c.sourceDurationSec <= 0.0 || fromSrcSec.isNaN() || toSrcSec.isNaN()) return c
        val fileEnd = c.sourceDurationSec
        val a = minOf(fromSrcSec, toSrcSec).coerceIn(0.0, fileEnd)
        val b = maxOf(fromSrcSec, toSrcSec).coerceIn(0.0, fileEnd)
        if (b - a < MIN_CLIP_SEC) return c
        val whole = a <= 1e-6 && b >= fileEnd - 1e-6
        return c.copy(
            srcStartSec = a,
            srcEndSec = b,
            markEndSec = if (whole) 0.0 else b,
            exactLoop = if (whole) c.exactLoop else (b - a <= AudioLimits.EXACT_LOOP_AUTO_MAX_SEC) || c.exactLoop
        )
    }

    /** Brings back the whole original file: no start cut, no marked end. (Kind, volume, fades and place are kept.) */
    fun useWholeFile(c: AudioClip): AudioClip {
        if (c.sourceDurationSec <= 0.0) return c
        return c.copy(srcStartSec = 0.0, srcEndSec = c.sourceDurationSec, markEndSec = 0.0)
    }

    /**
     * Puts the edited sound [source] into the background-audio [slot]: the slot keeps its name (B1...), its id and its time
     * range, and takes everything about the sound - the file, the marked part, volume, kind, mood and mixing choices. The
     * sound is then fitted to the slot's range by [followRange] (a longer marked part is cut, a shorter one repeats, or plays
     * once for a one-shot sound). Fades are never shorter than the slot's own, so the range's edges never click.
     */
    fun assignToSlot(source: AudioClip, slot: AudioClip): AudioClip = source.copy(
        id = slot.id,
        slot = slot.slot,
        startSec = slot.startSec,
        rangeEndSec = slot.rangeEndSec,
        muted = slot.muted,
        fitVideo = false,
        loop = false,
        // (a one-shot sound keeps its own tiny fades: a longer fade-in would soften the very moment it is there for)
        fadeInSec = if (source.playOnce) source.fadeInSec else maxOf(source.fadeInSec, slot.fadeInSec),
        fadeOutSec = if (source.playOnce) source.fadeOutSec else maxOf(source.fadeOutSec, slot.fadeOutSec)
    )

    /** Where the last sound in a lane ends. */
    fun laneEnd(clips: List<AudioClip>): Double = clips.maxOfOrNull { it.endSec } ?: 0.0
}
