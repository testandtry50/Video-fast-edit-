package com.videoslidemaker.app.audio

import com.videoslidemaker.app.audio.AudioLimits.MIN_CLIP_SEC

/**
 * NEW (2.17): every way of editing a clip, as plain functions that take clips and give back new clips. Nothing here
 * touches a file or the phone, so all of it is tested on a plain JVM (and mirrored in tools/audiomix-reference).
 * "Local" seconds are counted from the start of the clip's used part, which is what the sliders show.
 */
object ClipEdit {

    /** Cuts the beginning off: the clip keeps its place on the timeline but now starts later in the file. */
    fun trimStart(c: AudioClip, newSrcStartSec: Double): AudioClip {
        val hi = (c.srcEndSec - MIN_CLIP_SEC).coerceAtLeast(0.0)
        return c.copy(srcStartSec = newSrcStartSec.coerceIn(0.0, hi))
    }

    /** Cuts the end off (or, going the other way, brings it back, never past the end of the file). */
    fun trimEnd(c: AudioClip, newSrcEndSec: Double): AudioClip {
        val hi = if (c.sourceDurationSec > 0.0) c.sourceDurationSec else Double.MAX_VALUE
        val lo = c.srcStartSec + MIN_CLIP_SEC
        return c.copy(srcEndSec = newSrcEndSec.coerceIn(lo, maxOf(lo, hi)))
    }

    /** Splits one clip into two that sound exactly like the original, side by side. Too close to an edge = no change. */
    fun split(c: AudioClip, atLocalSec: Double, newId: String): List<AudioClip> {
        if (atLocalSec < MIN_CLIP_SEC || atLocalSec > c.lengthSec - MIN_CLIP_SEC) return listOf(c)
        val cut = c.srcStartSec + atLocalSec
        val first = c.copy(srcEndSec = cut, fadeOutSec = 0.0, loop = false)
        val second = c.copy(id = newId, srcStartSec = cut, startSec = c.startSec + atLocalSec, fadeInSec = 0.0, loop = false)
        return listOf(first, second)
    }

    /**
     * Removes the stretch [fromLocalSec]..[toLocalSec] from clip [id]. With [closeGap] everything after it moves
     * earlier by the removed length (so the rest of that lane stays joined up); without, the gap stays as silence.
     * The first part that survives keeps the clip's id. Returns the whole lane.
     */
    fun cutInTrack(clips: List<AudioClip>, id: String, fromLocalSec: Double, toLocalSec: Double, closeGap: Boolean, newId: String): List<AudioClip> {
        val target = clips.firstOrNull { it.id == id } ?: return clips
        val len = target.lengthSec
        var from = fromLocalSec.coerceIn(0.0, len)
        var to = toLocalSec.coerceIn(0.0, len)
        if (to < from) { val t = from; from = to; to = t }
        if (to - from < MIN_CLIP_SEC) return clips

        val removed = to - from
        val oldEnd = target.endSec
        val leftOk = from >= MIN_CLIP_SEC
        val rightOk = len - to >= MIN_CLIP_SEC

        val parts = ArrayList<AudioClip>(2)
        if (leftOk) parts.add(target.copy(srcEndSec = target.srcStartSec + from, fadeOutSec = 0.0, loop = false))
        if (rightOk) {
            val rightStart = when {
                !leftOk && closeGap -> target.startSec
                !leftOk -> target.startSec + to
                closeGap -> target.startSec + from
                else -> target.startSec + to
            }
            parts.add(
                target.copy(
                    id = if (leftOk) newId else target.id,
                    srcStartSec = target.srcStartSec + to,
                    startSec = rightStart,
                    fadeInSec = if (leftOk) 0.0 else target.fadeInSec,
                    loop = false
                )
            )
        }

        val out = ArrayList<AudioClip>(clips.size + 1)
        for (c in clips) {
            when {
                c.id == id -> out.addAll(parts)
                closeGap && c.startSec >= oldEnd - 1e-6 -> out.add(c.copy(startSec = (c.startSec - removed).coerceAtLeast(0.0)))
                else -> out.add(c)
            }
        }
        return out
    }

    /** Joins clips into one continuous stretch: in time order, back to back (with [gapSec] between), from the earliest start. */
    fun combine(clips: List<AudioClip>, gapSec: Double = 0.0): List<AudioClip> {
        if (clips.isEmpty()) return clips
        val sorted = clips.sortedBy { it.startSec }
        var t = sorted.first().startSec
        val out = ArrayList<AudioClip>(sorted.size)
        for (c in sorted) {
            out.add(c.copy(startSec = t))
            t += c.lengthSec + gapSec
        }
        return out
    }

    /** Swaps a clip with its neighbour in time (earlier or later), keeping the pair where it was. */
    fun swapWithNeighbour(clips: List<AudioClip>, id: String, later: Boolean): List<AudioClip> {
        val sorted = clips.sortedBy { it.startSec }
        val i = sorted.indexOfFirst { it.id == id }
        val j = if (later) i + 1 else i - 1
        if (i < 0 || j < 0 || j >= sorted.size) return clips
        val firstOld = if (i < j) sorted[i] else sorted[j]
        val secondOld = if (i < j) sorted[j] else sorted[i]
        val gap = (secondOld.startSec - firstOld.endSec).coerceAtLeast(0.0)
        val newFirst = secondOld.copy(startSec = firstOld.startSec)
        val newSecond = firstOld.copy(startSec = newFirst.endSec + gap)
        return clips.map {
            when (it.id) {
                firstOld.id -> newSecond
                secondOld.id -> newFirst
                else -> it
            }
        }
    }

    /** Puts a different file in a clip's place: same spot, volume and fades, the whole new file. */
    fun replaceSource(c: AudioClip, uri: String, name: String, durationSec: Double): AudioClip =
        c.copy(uri = uri, name = name, sourceDurationSec = durationSec, srcStartSec = 0.0, srcEndSec = durationSec)

    /** Background music that exactly covers a video of [totalSec]: too long = trimmed and faded out, too short = repeated. */
    fun fitToVideo(c: AudioClip, totalSec: Double): AudioClip {
        if (totalSec <= 0.0 || c.lengthSec <= 0.0) return c.copy(startSec = 0.0)
        return if (c.lengthSec >= totalSec) {
            c.copy(
                startSec = 0.0,
                srcEndSec = c.srcStartSec + totalSec,
                loop = false,
                fadeOutSec = maxOf(c.fadeOutSec, minOf(AudioLimits.END_FADE_SEC, totalSec / 2))
            )
        } else {
            c.copy(startSec = 0.0, loop = true)
        }
    }

    /**
     * The clip as it plays in a video of [totalSec] when [AudioClip.fitVideo] is on. Worked out fresh every time from the
     * whole file (never stored), so it follows the video when it gets longer OR shorter later.
     */
    fun followVideo(c: AudioClip, totalSec: Double): AudioClip {
        if (!c.fitVideo || totalSec <= 0.0) return c
        val fileEnd = if (c.sourceDurationSec > 0.0) c.sourceDurationSec else c.srcEndSec
        val avail = (fileEnd - c.srcStartSec).coerceAtLeast(0.0)
        if (avail <= 0.0) return c
        return if (avail >= totalSec) c.copy(startSec = 0.0, srcEndSec = c.srcStartSec + totalSec, loop = false)
        else c.copy(startSec = 0.0, srcEndSec = c.srcStartSec + avail, loop = true)
    }

    /** Where the last sound in a lane ends. */
    fun laneEnd(clips: List<AudioClip>): Double = clips.maxOfOrNull { it.endSec } ?: 0.0
}
