package com.videoslidemaker.app.logoclean

import java.util.Random
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/*
 * Pure image maths for the logo cleaner. Nothing in this file touches Android classes, so it runs
 * (and is unit-tested) on a plain JVM. It is a port of tools/logoclean-reference/logoclean.py - same
 * steps, same constants.
 *
 * Colour images are passed around as ONE FloatArray, interleaved r,g,b,r,g,b... with values 0..255.
 */

/** Square (2r+1) x (2r+1) "any pixel set" filter on a boolean grid. Works in two cheap passes. */
internal fun maxFilter(src: BooleanArray, w: Int, h: Int, r: Int): BooleanArray {
    if (r <= 0) return src.copyOf()
    val tmp = BooleanArray(w * h)
    for (y in 0 until h) {
        val row = y * w
        var count = 0
        for (x in 0..min(r, w - 1)) if (src[row + x]) count++
        for (x in 0 until w) {
            tmp[row + x] = count > 0
            val add = x + r + 1
            val rem = x - r
            if (add < w && src[row + add]) count++
            if (rem >= 0 && src[row + rem]) count--
        }
    }
    val out = BooleanArray(w * h)
    for (x in 0 until w) {
        var count = 0
        for (y in 0..min(r, h - 1)) if (tmp[y * w + x]) count++
        for (y in 0 until h) {
            out[y * w + x] = count > 0
            val add = y + r + 1
            val rem = y - r
            if (add < h && tmp[add * w + x]) count++
            if (rem >= 0 && tmp[rem * w + x]) count--
        }
    }
    return out
}

internal class Labels(val data: IntArray, val count: Int)

/** 4-connected components of a boolean grid. Label 0 = background, components are 1..count. */
internal fun label4(b: BooleanArray, w: Int, h: Int): Labels {
    val lab = IntArray(w * h)
    val stack = IntArray(w * h)
    var n = 0
    for (start in 0 until w * h) {
        if (!b[start] || lab[start] != 0) continue
        n++
        var sp = 0
        stack[sp++] = start
        lab[start] = n
        while (sp > 0) {
            val i = stack[--sp]
            val x = i % w
            val y = i / w
            if (x > 0 && b[i - 1] && lab[i - 1] == 0) { lab[i - 1] = n; stack[sp++] = i - 1 }
            if (x < w - 1 && b[i + 1] && lab[i + 1] == 0) { lab[i + 1] = n; stack[sp++] = i + 1 }
            if (y > 0 && b[i - w] && lab[i - w] == 0) { lab[i - w] = n; stack[sp++] = i - w }
            if (y < h - 1 && b[i + w] && lab[i + w] == 0) { lab[i + w] = n; stack[sp++] = i + w }
        }
    }
    return Labels(lab, n)
}

/** Mean filter of radius r (edges repeat the border pixel). */
internal fun boxBlur(src: FloatArray, w: Int, h: Int, r: Int): FloatArray {
    if (r <= 0) return src.copyOf()
    val tmp = FloatArray(w * h)
    val out = FloatArray(w * h)
    val inv = 1f / (2 * r + 1)
    for (y in 0 until h) {
        val row = y * w
        var sum = 0f
        for (k in -r..r) sum += src[row + k.coerceIn(0, w - 1)]
        for (x in 0 until w) {
            tmp[row + x] = sum * inv
            sum += src[row + min(x + r + 1, w - 1)] - src[row + max(x - r, 0)]
        }
    }
    for (x in 0 until w) {
        var sum = 0f
        for (k in -r..r) sum += tmp[k.coerceIn(0, h - 1) * w + x]
        for (y in 0 until h) {
            out[y * w + x] = sum * inv
            sum += tmp[min(y + r + 1, h - 1) * w + x] - tmp[max(y - r, 0) * w + x]
        }
    }
    return out
}

/** Gaussian blur, approximated by three box passes (fast, no matter how large sigma is). */
internal fun gaussBlur(src: FloatArray, w: Int, h: Int, sigma: Float): FloatArray {
    if (sigma < 0.5f) return src.copyOf()
    val r = max(1, Math.round(sqrt(12.0 * sigma * sigma / 3.0 + 1.0) / 2.0 - 0.5).toInt())
    var out = src
    for (pass in 0 until 3) out = boxBlur(out, w, h, r)
    return out
}

// ----------------------------------------------------------------------------------------------
// Diffusion ("harmonic") inpainting on a pyramid
// ----------------------------------------------------------------------------------------------

private class Level(val w: Int, val h: Int, val img: FloatArray, val known: BooleanArray)

private fun downLevel(l: Level): Level {
    val w2 = (l.w + 1) / 2
    val h2 = (l.h + 1) / 2
    val img = FloatArray(w2 * h2 * 3)
    val kn = BooleanArray(w2 * h2)
    for (y in 0 until h2) {
        for (x in 0 until w2) {
            var c = 0
            var r = 0f
            var g = 0f
            var b = 0f
            for (dy in 0..1) {
                for (dx in 0..1) {
                    val sx = 2 * x + dx
                    val sy = 2 * y + dy
                    if (sx < l.w && sy < l.h && l.known[sy * l.w + sx]) {
                        val i = (sy * l.w + sx) * 3
                        r += l.img[i]; g += l.img[i + 1]; b += l.img[i + 2]
                        c++
                    }
                }
            }
            if (c > 0) {
                val o = (y * w2 + x) * 3
                img[o] = r / c; img[o + 1] = g / c; img[o + 2] = b / c
                kn[y * w2 + x] = true
            }
        }
    }
    return Level(w2, h2, img, kn)
}

/** Jacobi relaxation: every unknown pixel becomes the average of its four neighbours. */
private fun relax(l: Level, cur: FloatArray, iterations: Int) {
    val w = l.w
    val h = l.h
    var a = cur
    var b = FloatArray(cur.size)
    for (iter in 0 until iterations) {
        for (y in 0 until h) {
            val ym = if (y > 0) y - 1 else 0
            val yp = if (y < h - 1) y + 1 else h - 1
            for (x in 0 until w) {
                val i = y * w + x
                val o = i * 3
                if (l.known[i]) {
                    b[o] = a[o]; b[o + 1] = a[o + 1]; b[o + 2] = a[o + 2]
                } else {
                    val xm = if (x > 0) x - 1 else 0
                    val xp = if (x < w - 1) x + 1 else w - 1
                    val up = (ym * w + x) * 3
                    val dn = (yp * w + x) * 3
                    val lf = (y * w + xm) * 3
                    val rt = (y * w + xp) * 3
                    b[o] = 0.25f * (a[up] + a[dn] + a[lf] + a[rt])
                    b[o + 1] = 0.25f * (a[up + 1] + a[dn + 1] + a[lf + 1] + a[rt + 1])
                    b[o + 2] = 0.25f * (a[up + 2] + a[dn + 2] + a[lf + 2] + a[rt + 2])
                }
            }
        }
        val t = a; a = b; b = t
    }
    if (a !== cur) System.arraycopy(a, 0, cur, 0, cur.size)
}

private fun countUnknown(known: BooleanArray): Int {
    var n = 0
    for (k in known) if (!k) n++
    return n
}

/**
 * Fills the masked pixels with a smooth membrane that matches the surroundings. It is solved on a
 * pyramid (small picture first, then refined at each bigger size), which converges far faster than
 * relaxing at full size only.
 */
internal fun harmonicFill(img: FloatArray, w: Int, h: Int, mask: BooleanArray, iterations: Int = 60): FloatArray {
    val known0 = BooleanArray(w * h) { !mask[it] }
    if (countUnknown(known0) == w * h) return img.copyOf() // nothing known to copy from
    val base = FloatArray(img.size)
    for (i in 0 until w * h) {
        if (known0[i]) {
            base[i * 3] = img[i * 3]; base[i * 3 + 1] = img[i * 3 + 1]; base[i * 3 + 2] = img[i * 3 + 2]
        }
    }
    val levels = ArrayList<Level>()
    levels.add(Level(w, h, base, known0))
    while (true) {
        val l = levels[levels.size - 1]
        if (min(l.w, l.h) < 8 || countUnknown(l.known) == 0 || max(l.w, l.h) <= 12) break
        val d = downLevel(l)
        levels.add(d)
        if (countUnknown(d.known) == 0) break
    }
    // coarsest level: start from the mean colour of what is known there
    val top = levels[levels.size - 1]
    var mr = 0.0
    var mg = 0.0
    var mb = 0.0
    var kn = 0
    for (i in 0 until top.w * top.h) {
        if (top.known[i]) {
            mr += top.img[i * 3]; mg += top.img[i * 3 + 1]; mb += top.img[i * 3 + 2]
            kn++
        }
    }
    val meanR = (mr / max(1, kn)).toFloat()
    val meanG = (mg / max(1, kn)).toFloat()
    val meanB = (mb / max(1, kn)).toFloat()
    var cur = FloatArray(top.img.size)
    for (i in 0 until top.w * top.h) {
        if (top.known[i]) {
            cur[i * 3] = top.img[i * 3]; cur[i * 3 + 1] = top.img[i * 3 + 1]; cur[i * 3 + 2] = top.img[i * 3 + 2]
        } else {
            cur[i * 3] = meanR; cur[i * 3 + 1] = meanG; cur[i * 3 + 2] = meanB
        }
    }
    relax(top, cur, iterations * 3)
    for (li in levels.size - 2 downTo 0) {
        val lv = levels[li]
        val coarseW = levels[li + 1].w
        val up = FloatArray(lv.w * lv.h * 3)
        for (y in 0 until lv.h) {
            for (x in 0 until lv.w) {
                val i = y * lv.w + x
                val o = i * 3
                if (lv.known[i]) {
                    up[o] = lv.img[o]; up[o + 1] = lv.img[o + 1]; up[o + 2] = lv.img[o + 2]
                } else {
                    val s = ((y / 2) * coarseW + (x / 2)) * 3
                    up[o] = cur[s]; up[o + 1] = cur[s + 1]; up[o + 2] = cur[s + 2]
                }
            }
        }
        relax(lv, up, iterations)
        cur = up
    }
    return cur
}

/** The photo's own fine noise, measured in a ring just outside the mask. */
private fun estimateGrain(img: FloatArray, w: Int, h: Int, mask: BooleanArray, ring: Int = 6): Float {
    val grown = maxFilter(mask, w, h, ring)
    var count = 0
    for (i in 0 until w * h) {
        grown[i] = grown[i] && !mask[i]
        if (grown[i]) count++
    }
    if (count < 20) return 0f
    val lum = FloatArray(w * h) { (img[it * 3] + img[it * 3 + 1] + img[it * 3 + 2]) / 3f }
    val low = gaussBlur(lum, w, h, 1.5f)
    var s = 0.0
    var s2 = 0.0
    for (i in 0 until w * h) {
        if (grown[i]) {
            val v = (lum[i] - low[i]).toDouble()
            s += v
            s2 += v * v
        }
    }
    val mean = s / count
    return sqrt(max(0.0, s2 / count - mean * mean)).toFloat()
}

/** 1 inside the mask, fading to 0 just outside it, so the repaired patch melts into the photo. */
private fun softMask(mask: BooleanArray, w: Int, h: Int, feather: Float): FloatArray {
    val f = FloatArray(w * h) { if (mask[it]) 1f else 0f }
    val soft = gaussBlur(f, w, h, feather)
    for (i in 0 until w * h) if (mask[i]) soft[i] = 1f
    return soft
}

/**
 * REMOVE: fills the masked pixels from their surroundings (smooth fill + matching grain) and feathers
 * the patch in. Pixels away from the mask are returned unchanged.
 */
internal fun inpaint(
    img: FloatArray, w: Int, h: Int, mask: BooleanArray,
    grain: Float = 0.8f, feather: Float = 1.5f, seed: Long = 1234L
): FloatArray {
    val fill = harmonicFill(img, w, h, mask)
    val sigma = estimateGrain(img, w, h, mask) * grain
    if (sigma > 0f) {
        val rng = Random(seed)
        val noise = FloatArray(w * h) { (rng.nextGaussian() * sigma).toFloat() }
        val low = gaussBlur(noise, w, h, 1.0f)
        for (i in 0 until w * h) {
            val n = noise[i] - low[i] * 0.5f
            fill[i * 3] += n; fill[i * 3 + 1] += n; fill[i * 3 + 2] += n
        }
    }
    val soft = softMask(mask, w, h, feather)
    val out = FloatArray(img.size)
    for (i in 0 until w * h) {
        val s = soft[i]
        for (c in 0..2) out[i * 3 + c] = fill[i * 3 + c] * s + img[i * 3 + c] * (1f - s)
    }
    return out
}

/** BLUR: blurs the photo with [sigma] and shows that blur only inside the (feathered) mask. */
internal fun blurMasked(img: FloatArray, w: Int, h: Int, mask: BooleanArray, sigma: Float, feather: Float): FloatArray {
    val blurred = FloatArray(img.size)
    for (c in 0..2) {
        val ch = FloatArray(w * h) { img[it * 3 + c] }
        val b = gaussBlur(ch, w, h, sigma)
        for (i in 0 until w * h) blurred[i * 3 + c] = b[i]
    }
    val soft = softMask(mask, w, h, feather)
    val out = FloatArray(img.size)
    for (i in 0 until w * h) {
        val s = soft[i]
        for (c in 0..2) out[i * 3 + c] = blurred[i * 3 + c] * s + img[i * 3 + c] * (1f - s)
    }
    return out
}

/** Scales a small boolean mask up to [outW] x [outH] with bilinear sampling (smooth edges). */
internal fun upscaleMask(mask: BooleanArray, mw: Int, mh: Int, outW: Int, outH: Int): BooleanArray {
    val out = BooleanArray(outW * outH)
    if (mw <= 0 || mh <= 0 || outW <= 0 || outH <= 0) return out
    val sx = mw.toFloat() / outW
    val sy = mh.toFloat() / outH
    for (y in 0 until outH) {
        val fy = (y + 0.5f) * sy - 0.5f
        val y0 = Math.floor(fy.toDouble()).toInt().coerceIn(0, mh - 1)
        val y1 = (y0 + 1).coerceIn(0, mh - 1)
        val ty = (fy - y0).coerceIn(0f, 1f)
        for (x in 0 until outW) {
            val fx = (x + 0.5f) * sx - 0.5f
            val x0 = Math.floor(fx.toDouble()).toInt().coerceIn(0, mw - 1)
            val x1 = (x0 + 1).coerceIn(0, mw - 1)
            val tx = (fx - x0).coerceIn(0f, 1f)
            val a = (if (mask[y0 * mw + x0]) 1f else 0f) * (1 - tx) + (if (mask[y0 * mw + x1]) 1f else 0f) * tx
            val b = (if (mask[y1 * mw + x0]) 1f else 0f) * (1 - tx) + (if (mask[y1 * mw + x1]) 1f else 0f) * tx
            out[y * outW + x] = (a * (1 - ty) + b * ty) > 0.5f
        }
    }
    return out
}

/** A rounded rectangle (x0,y0 inclusive .. x1,y1 exclusive) inside a w x h grid. */
internal fun roundedRectMask(w: Int, h: Int, x0: Int, y0: Int, x1: Int, y1: Int, radius: Int): BooleanArray {
    val m = BooleanArray(w * h)
    val rad = max(0, min(radius, min((x1 - x0) / 2, (y1 - y0) / 2)))
    for (y in max(0, y0) until min(h, y1)) {
        val cy = when {
            y < y0 + rad -> y0 + rad
            y >= y1 - rad -> y1 - rad - 1
            else -> y
        }
        for (x in max(0, x0) until min(w, x1)) {
            val cx = when {
                x < x0 + rad -> x0 + rad
                x >= x1 - rad -> x1 - rad - 1
                else -> x
            }
            val dx = x - cx
            val dy = y - cy
            if (dx * dx + dy * dy <= rad * rad) m[y * w + x] = true
        }
    }
    return m
}
