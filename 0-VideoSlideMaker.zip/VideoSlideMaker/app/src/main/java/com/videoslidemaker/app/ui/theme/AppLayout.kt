package com.videoslidemaker.app.ui.theme

import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * The sizes behind the "Layout" choices: how round the corners are and how much room cards, headers and buttons get.
 * The shared components (cards, buttons, chips, alert boxes) read these, so changing the choice re-lays-out the
 * whole app at once. Buttons are never shorter than 48 dp - that is the smallest comfortable thumb target.
 */
@Immutable
data class LayoutSpec(
    val cardRadius: Dp,
    val controlRadius: Dp,
    val smallRadius: Dp,
    val tinyRadius: Dp,
    val cardPadding: Dp,
    val headerMinHeight: Dp,
    val buttonMinHeight: Dp,
    val titleGap: Dp
)

fun layoutSpecOf(spacing: SpacingChoice, corners: CornerChoice): LayoutSpec {
    // (card, control, small, tiny)
    val radii = when (corners) {
        CornerChoice.ROUNDED -> listOf(18.dp, 14.dp, 12.dp, 10.dp)
        CornerChoice.SOFT -> listOf(12.dp, 10.dp, 8.dp, 7.dp)
        CornerChoice.SQUARE -> listOf(4.dp, 4.dp, 3.dp, 3.dp)
    }
    return when (spacing) {
        SpacingChoice.COMPACT -> LayoutSpec(radii[0], radii[1], radii[2], radii[3], 12.dp, 52.dp, 48.dp, 12.dp)
        SpacingChoice.COMFORTABLE -> LayoutSpec(radii[0], radii[1], radii[2], radii[3], 16.dp, 60.dp, 52.dp, 20.dp)
        SpacingChoice.ROOMY -> LayoutSpec(radii[0], radii[1], radii[2], radii[3], 20.dp, 68.dp, 58.dp, 24.dp)
    }
}

val LocalLayoutSpec = staticCompositionLocalOf { layoutSpecOf(SpacingChoice.COMFORTABLE, CornerChoice.ROUNDED) }

val AppLayout: LayoutSpec
    @Composable @ReadOnlyComposable get() = LocalLayoutSpec.current
