package com.videoslidemaker.app.viewmodel

import android.app.Application
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.net.Uri
import android.os.IBinder
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.videoslidemaker.app.align.AlignmentApplier
import com.videoslidemaker.app.align.AlignmentDecision
import com.videoslidemaker.app.align.AlignmentStatus
import com.videoslidemaker.app.align.ClipState
import com.videoslidemaker.app.align.RecordingClipPlayer
import com.videoslidemaker.app.align.RecordingReadException
import com.videoslidemaker.app.align.RecordingReader
import com.videoslidemaker.app.align.TimestampAligner
import com.videoslidemaker.app.data.ImageStore
import com.videoslidemaker.app.data.ProjectRepository
import com.videoslidemaker.app.data.ScriptParser
import com.videoslidemaker.app.export.ExportForegroundService
import com.videoslidemaker.app.model.AppStep
import com.videoslidemaker.app.model.AspectRatioOption
import com.videoslidemaker.app.model.EffectStyle
import com.videoslidemaker.app.model.ImportProgress
import com.videoslidemaker.app.model.OverlayStyle
import com.videoslidemaker.app.model.PoolImage
import com.videoslidemaker.app.model.QualityOption
import com.videoslidemaker.app.model.SentenceSlide
import com.videoslidemaker.app.model.TextOverlay
import com.videoslidemaker.app.model.TransitionStyle
import com.videoslidemaker.app.model.UiState
import com.videoslidemaker.app.tts.NarrationTts
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.UUID

class AppViewModel(application: Application) : AndroidViewModel(application) {
    private val PREVIEW_TICK_MS = 50L
    private val DRAFT_SAVE_DELAY_MS = 400L

    private val imageStore = ImageStore(application)
    private val tts = NarrationTts(application)
    private val clipPlayer = RecordingClipPlayer(application, viewModelScope)

    /** Live state of the "play original" control on the Match screen (kept out of [ui] so it doesn't redraw the whole screen). */
    val clip: StateFlow<ClipState> = clipPlayer.state
    private val projectRepository = ProjectRepository(application)

    private val _ui = MutableStateFlow(UiState())
    val ui: StateFlow<UiState> =
        combine(_ui, ExportForegroundService.progress) { state, progress -> state.copy(exportProgress = progress) }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), UiState())

    // Kept as a Job so a photo import can wait until the saved draft has finished loading -
    // otherwise a late-arriving draft could overwrite photos that were just added.
    private val draftLoadJob: Job = viewModelScope.launch {
        projectRepository.load()?.let { restored -> _ui.update { restored } }
    }

    private var persistJob: Job? = null

    /**
     * Auto-saves the draft a moment after the LAST change, instead of once per change. Importing
     * thousands of photos changes the state many times in a row, and re-writing a multi-megabyte
     * file every single time was wasted work.
     */
    private fun persistDraft() {
        persistJob?.cancel()
        persistJob = viewModelScope.launch {
            delay(DRAFT_SAVE_DELAY_MS)
            projectRepository.save(_ui.value)
        }
    }

    // ---------- Navigation ----------

    fun goStep(step: AppStep) {
        val state = _ui.value
        if ((step == AppStep.TEXT || step == AppStep.PREVIEW || step == AppStep.EXPORT) && state.images.isEmpty()) return
        _ui.update { it.copy(step = step) }
        when (step) {
            AppStep.MATCH -> _ui.update { it.copy(curMatchIndex = it.curMatchIndex.coerceIn(0, (it.slides.size - 1).coerceAtLeast(0))) }
            AppStep.PREVIEW -> {
                stopPreview()
                previewLastSpokenIndex = -1
                _ui.update { it.copy(previewPositionSec = 0.0) }
            }
            else -> {}
        }
    }

    /** Where "Next" from the Photos screen should go: Match only makes sense with a script loaded. */
    fun goNextFromPhotos() {
        goStep(if (_ui.value.scriptLoaded) AppStep.MATCH else AppStep.TEXT)
    }

    // ---------- Step 1: Script + global settings ----------

    fun loadScript(content: String) {
        val parsed = ScriptParser.parseScriptDetailed(content)
        val slides = parsed.lines.map { SentenceSlide(it.timestampSec, it.text) }
        val issues = parsed.issues.map { it.describe() }
        _ui.update { it.copy(slides = slides, scriptLoaded = slides.isNotEmpty(), curMatchIndex = 0, scriptIssues = issues) }
        persistDraft()
    }

    fun setDefaultDuration(seconds: Int) {
        _ui.update { it.copy(settings = it.settings.copy(defaultDurationSec = seconds.coerceIn(1, 30))) }
        persistDraft()
    }
    fun setVoiceLocale(tag: String) {
        _ui.update { it.copy(settings = it.settings.copy(narration = it.settings.narration.copy(voiceLocaleTag = tag))) }
        persistDraft()
    }
    fun setEffectStyle(style: EffectStyle) {
        _ui.update { it.copy(settings = it.settings.copy(effectStyle = style)) }
        persistDraft()
    }
    fun setTransitionStyle(style: TransitionStyle) {
        _ui.update { it.copy(settings = it.settings.copy(transitionStyle = style)) }
        persistDraft()
    }
    fun setAspectRatio(ratio: AspectRatioOption) {
        _ui.update { it.copy(settings = it.settings.copy(aspectRatio = ratio)) }
        persistDraft()
    }
    fun setQuality(quality: QualityOption) {
        _ui.update { it.copy(settings = it.settings.copy(quality = quality)) }
        persistDraft()
    }
    fun setNarrationEnabled(enabled: Boolean) {
        _ui.update { it.copy(settings = it.settings.copy(narration = it.settings.narration.copy(enabled = enabled))) }
        persistDraft()
    }
    fun setMusicUri(uri: Uri?, displayName: String?) {
        _ui.update { it.copy(settings = it.settings.copy(music = it.settings.music.copy(uri = uri, displayName = displayName))) }
        persistDraft()
    }
    fun setMusicVolume(volume: Float) {
        _ui.update { it.copy(settings = it.settings.copy(music = it.settings.music.copy(volume = volume.coerceIn(0f, 1f)))) }
        persistDraft()
    }

    // ---------- Automatic timestamp alignment (script screen) ----------

    private var alignJob: Job? = null

    private fun toMs(seconds: Double): Long = ScriptParser.secondsToMillis(seconds)

    private fun updateAlignment(change: (com.videoslidemaker.app.align.AlignmentState) -> com.videoslidemaker.app.align.AlignmentState) {
        _ui.update { it.copy(alignment = change(it.alignment)) }
    }

    /** Chooses the recording (audio or video) that timestamps will be checked against. */
    fun setRecording(uri: Uri?, name: String?) {
        clipPlayer.release()
        updateAlignment {
            it.copy(
                recordingUri = uri, recordingName = name, error = null, notice = null,
                // results belong to the old recording
                items = emptyList(), drift = emptyList(), reviewOpen = false
            )
        }
        persistDraft()
    }

    fun setAutoApplyAlignment(on: Boolean) {
        updateAlignment { it.copy(autoApply = on) }
        persistDraft()
    }

    fun openAlignmentReview(open: Boolean) = updateAlignment { it.copy(reviewOpen = open) }

    fun cancelAlignment() {
        alignJob?.cancel()
    }

    private fun alignmentFailed(message: String) {
        updateAlignment { it.copy(running = false, percent = 0, stage = "", error = message) }
    }

    /**
     * Listens to the recording and works out, for every script line independently, when it is
     * really spoken. Nothing is changed in the script here — this only produces suggestions.
     * The baseline for comparison is always the script's ORIGINAL timestamp, so re-running after
     * applying corrections gives the same answers rather than drifting further.
     */
    fun runAlignment() {
        if (alignJob?.isActive == true) return
        val state = _ui.value
        val uri = state.alignment.recordingUri
        if (uri == null) { alignmentFailed("Choose the recording first."); return }
        if (state.slides.isEmpty()) { alignmentFailed("Load a script first — there are no timestamps to check."); return }

        val slides = state.slides
        val originals = slides.map { toMs(it.originalTimestampSec ?: it.timestampSec) }
        val currents = slides.map { toMs(it.timestampSec) }
        val texts = slides.map { it.text }
        val hadOriginal = slides.map { it.originalTimestampSec != null }

        alignJob = viewModelScope.launch {
            updateAlignment {
                it.copy(running = true, percent = 0, stage = "Reading the recording…", error = null, notice = null, items = emptyList(), drift = emptyList())
            }
            try {
                val recording = withContext(Dispatchers.Default) {
                    RecordingReader.read(
                        context = getApplication<Application>(),
                        uri = uri,
                        onProgress = { pct -> updateAlignment { a -> a.copy(percent = pct * 85 / 100) } },
                        isCancelled = { !isActive }
                    )
                }
                val result = withContext(Dispatchers.Default) {
                    TimestampAligner.align(
                        frames = recording.frames,
                        timeOffsetMs = recording.startOffsetMs,
                        originalMs = originals,
                        texts = texts,
                        onStage = { stage -> updateAlignment { a -> a.copy(stage = stage, percent = 90) } },
                        isCancelled = { !isActive }
                    )
                }
                val items = result.items.map { item ->
                    val cur = currents[item.index]
                    val alreadyApplied = hadOriginal[item.index] && item.detectedMs != null && cur == item.detectedMs
                    item.copy(
                        currentMs = cur,
                        decision = if (alreadyApplied) AlignmentDecision.APPLIED else AlignmentDecision.PENDING
                    )
                }
                updateAlignment {
                    it.copy(running = false, percent = 100, stage = "", items = items, clarityDb = result.clarityDb, drift = result.drift)
                }
                if (_ui.value.alignment.autoApply) applyAllHighConfidence()
            } catch (e: CancellationException) {
                updateAlignment { it.copy(running = false, percent = 0, stage = "") }
                throw e
            } catch (e: RecordingReadException) {
                alignmentFailed(e.message ?: "Couldn't read the recording.")
            } catch (e: OutOfMemoryError) {
                alignmentFailed("The phone ran out of memory while analysing the recording.")
            } catch (e: Exception) {
                alignmentFailed("Couldn't analyse the recording: " + (e.message ?: e.javaClass.simpleName))
            }
        }
    }

    /** "Apply correction" for one line. */
    fun applyAlignmentCorrection(index: Int) = applyItems(listOf(index))

    /** "Apply all high-confidence corrections": every line the analysis was sure about and the user hasn't decided on. */
    fun applyAllHighConfidence() {
        val ids = _ui.value.alignment.items
            .filter { it.status == AlignmentStatus.HIGH_CONFIDENCE && it.decision == AlignmentDecision.PENDING && it.canApply }
            .map { it.index }
        applyItems(ids)
    }

    /**
     * "Apply correction to all": applies the detected time to every given line that can still be
     * corrected, including lines the user earlier chose to keep as original. Lines where no
     * matching speech was found have nothing to apply and are reported in the notice.
     * Lines that would overlap a neighbour are refused by [AlignmentApplier], as with a single apply.
     */
    fun applyCorrectionToAll(indices: List<Int>) {
        val items = _ui.value.alignment.items
        val scope = indices.toHashSet()
        val inScope = items.filter { it.index in scope }
        val ids = inScope.filter { it.canApply }.map { it.index }
        val noDetection = inScope.count { it.detectedMs == null }
        val note = if (noDetection > 0) "$noDetection skipped: no matching speech was found in the audio." else null
        if (ids.isEmpty()) {
            updateAlignment {
                it.copy(notice = "Nothing to apply${if (noDetection > 0) " — no matching speech was found for these lines" else " — they already use the detected time"}.")
            }
            return
        }
        applyItems(ids, note)
    }

    /**
     * "Keep original for all": every given line goes back to (or stays at) the timestamp the script
     * originally had, and is marked "Original kept". Lines that can't be moved back without
     * overlapping a neighbour keep their current time and are reported in the notice.
     */
    fun keepOriginalForAll(indices: List<Int>) {
        if (indices.isEmpty()) return
        _ui.update { state ->
            val slides = state.slides
            val items = state.alignment.items
            val scope = indices.toHashSet()
            val cur = LongArray(slides.size) { toMs(slides[it].timestampSec) }
            val wanted = LinkedHashMap<Int, Long>()
            for (idx in scope) {
                val sl = slides.getOrNull(idx) ?: continue
                sl.originalTimestampSec?.let { wanted[idx] = toMs(it) }
            }
            val plan = AlignmentApplier.plan(cur, wanted)
            val rejected = plan.rejected.toHashSet()
            val list = slides.toMutableList()
            for (idx in plan.accepted.keys) {
                val sl = list[idx]
                list[idx] = sl.copy(timestampSec = sl.originalTimestampSec ?: sl.timestampSec, originalTimestampSec = null)
            }
            // a line already sitting at its original time only needs the "corrected" marker cleared
            for ((idx, ms) in wanted) {
                if (!plan.accepted.containsKey(idx) && idx !in rejected && ms == cur[idx]) {
                    list[idx] = list[idx].copy(originalTimestampSec = null)
                }
            }
            var kept = 0
            val newItems = items.map { item ->
                if (item.index !in scope || item.index in rejected) item
                else {
                    kept++
                    val restored = plan.accepted[item.index]
                    item.copy(currentMs = restored ?: item.currentMs, decision = AlignmentDecision.KEPT_ORIGINAL)
                }
            }
            val restoredCount = plan.accepted.size
            state.copy(
                slides = list,
                alignment = state.alignment.copy(
                    items = newItems,
                    notice = "Original kept for $kept line(s)" +
                        (if (restoredCount > 0) ", $restoredCount restored to the original time." else ".") +
                        (if (rejected.isNotEmpty()) " ${rejected.size} couldn't be restored (they would overlap a neighbouring line)." else "")
                )
            )
        }
        persistDraft()
    }

    private fun applyItems(indices: List<Int>, extraNote: String? = null) {
        if (indices.isEmpty() && extraNote == null) return
        _ui.update { state ->
            val slides = state.slides
            val items = state.alignment.items
            val byIndex = items.associateBy { it.index }
            val wanted = LinkedHashMap<Int, Long>()
            var stale = 0
            for (idx in indices) {
                val item = byIndex[idx] ?: continue
                val target = item.detectedMs ?: continue
                val slide = slides.getOrNull(idx)
                // The script may have been edited since the analysis; never write to the wrong line.
                if (slide == null || slide.text != item.text || toMs(slide.timestampSec) != item.currentMs) {
                    stale++
                    continue
                }
                if (target != item.currentMs) wanted[idx] = target
            }
            val plan = AlignmentApplier.plan(LongArray(slides.size) { toMs(slides[it].timestampSec) }, wanted)
            val newSlides = slides.toMutableList()
            for ((idx, ms) in plan.accepted) {
                val old = newSlides[idx]
                newSlides[idx] = old.copy(timestampSec = ms / 1000.0, originalTimestampSec = old.originalTimestampSec ?: old.timestampSec)
            }
            val newItems = items.map { item ->
                val ms = plan.accepted[item.index]
                if (ms != null) item.copy(currentMs = ms, decision = AlignmentDecision.APPLIED) else item
            }
            val notes = ArrayList<String>()
            if (plan.rejected.isNotEmpty()) notes.add("${plan.rejected.size} not applied: they would overlap a neighbouring line.")
            if (stale > 0) notes.add("$stale not applied: the script changed since the analysis — analyse again.")
            if (extraNote != null) notes.add(extraNote)
            state.copy(
                slides = newSlides,
                alignment = state.alignment.copy(
                    items = newItems,
                    notice = if (plan.accepted.isNotEmpty() || notes.isNotEmpty())
                        (listOf("${plan.accepted.size} timestamp(s) corrected.") + notes).joinToString(" ") else null
                )
            )
        }
        persistDraft()
    }

    /** "Keep original": makes sure this line uses the script's own timestamp (restoring it if a correction had been applied). */
    fun keepOriginalTimestamp(index: Int) {
        _ui.update { state ->
            val slide = state.slides.getOrNull(index)
            val items = state.alignment.items
            val item = items.firstOrNull { it.index == index }
            if (slide == null || item == null) return@update state
            var slides = state.slides
            var currentMs = item.currentMs
            var notice: String? = state.alignment.notice
            val original = slide.originalTimestampSec
            if (original != null) {
                val target = toMs(original)
                val cur = LongArray(slides.size) { toMs(slides[it].timestampSec) }
                if (target == cur[index]) {
                    // already at the original time; just drop the "corrected" marker
                    val list = slides.toMutableList()
                    list[index] = slide.copy(originalTimestampSec = null)
                    slides = list
                    notice = null
                } else {
                    val plan = AlignmentApplier.plan(cur, mapOf(index to target))
                    if (plan.accepted.containsKey(index)) {
                        val list = slides.toMutableList()
                        list[index] = slide.copy(timestampSec = original, originalTimestampSec = null)
                        slides = list
                        currentMs = target
                        notice = null
                    } else {
                        return@update state.copy(
                            alignment = state.alignment.copy(
                                notice = "Couldn't restore line ${index + 1}: it would overlap a neighbouring line. Restore that one first."
                            )
                        )
                    }
                }
            }
            state.copy(
                slides = slides,
                alignment = state.alignment.copy(
                    notice = notice,
                    items = items.map { if (it.index == index) it.copy(currentMs = currentMs, decision = AlignmentDecision.KEPT_ORIGINAL) else it }
                )
            )
        }
        persistDraft()
    }

    /** Restores every corrected line to the timestamp the script originally had. */
    fun revertAllAlignment() {
        _ui.update { state ->
            val slides = state.slides
            val cur = LongArray(slides.size) { toMs(slides[it].timestampSec) }
            val wanted = LinkedHashMap<Int, Long>()
            for ((i, sl) in slides.withIndex()) sl.originalTimestampSec?.let { wanted[i] = toMs(it) }
            val plan = AlignmentApplier.plan(cur, wanted)
            val list = slides.toMutableList()
            for ((idx, _) in plan.accepted) {
                val sl = list[idx]
                list[idx] = sl.copy(timestampSec = sl.originalTimestampSec ?: sl.timestampSec, originalTimestampSec = null)
            }
            // a line whose timestamp already equals its original just needs the marker cleared
            for ((idx, ms) in wanted) {
                if (!plan.accepted.containsKey(idx) && ms == cur[idx]) list[idx] = list[idx].copy(originalTimestampSec = null)
            }
            val newItems = state.alignment.items.map { item ->
                if (plan.accepted.containsKey(item.index)) item.copy(currentMs = item.originalMs, decision = AlignmentDecision.PENDING) else item
            }
            state.copy(
                slides = list,
                alignment = state.alignment.copy(
                    items = newItems,
                    notice = "${plan.accepted.size} timestamp(s) restored to the original." +
                        if (plan.rejected.isNotEmpty()) " ${plan.rejected.size} couldn't be restored (they would overlap a neighbouring line)." else ""
                )
            )
        }
        persistDraft()
    }

    // ---------- Step 2: Photos ----------

    private var importJob: Job? = null

    fun addImages(uris: List<Uri>) {
        if (uris.isEmpty()) return
        runImport { onBatch -> imageStore.importFiles(uris, onBatch) }
    }

    /** NEW: bulk-import every image in a picked folder at once — see ImageStore.importFolder
     *  for why this is the real fix for large photo counts (hundreds+), not just a convenience. */
    fun addImagesFromTree(treeUri: Uri) {
        runImport { onBatch ->
            imageStore.importFolder(treeUri, onBatch) { found ->
                // While the folders are still being listed: show how many photos turned up so far.
                _ui.update { it.copy(importProgress = ImportProgress(0, 0, found)) }
            }
        }
    }

    /** Stops a running photo import. Photos that were already added stay in the list. */
    fun cancelImport() {
        importJob?.cancel()
    }

    /**
     * Runs one photo import in the background. Every finished chunk of photos is added to the
     * list straight away and the progress is published, so the screen keeps showing live
     * progress instead of looking frozen until thousands of photos are done. Only one import
     * runs at a time, and nothing that goes wrong inside it can crash the app.
     *
     * [work] does the actual reading (see ImageStore) and returns how many photos were skipped.
     */
    private fun runImport(work: suspend ((List<PoolImage>, Int, Int) -> Unit) -> Int) {
        if (importJob?.isActive == true) return
        importJob = viewModelScope.launch {
            draftLoadJob.join()
            _ui.update { it.copy(importProgress = ImportProgress(), importNote = null) }

            var added = 0
            var skipped = 0
            var failed = false
            var failureDetail: String? = null
            var cancelled = false

            val onBatch: (List<PoolImage>, Int, Int) -> Unit = { batch, processed, total ->
                added += batch.size
                _ui.update {
                    it.copy(
                        images = if (batch.isEmpty()) it.images else it.images + batch,
                        importProgress = ImportProgress(processed, total)
                    )
                }
            }

            try {
                skipped = work(onBatch)
            } catch (e: CancellationException) {
                cancelled = true
                throw e
            } catch (e: Exception) {
                failed = true
                failureDetail = e.message
            } catch (e: OutOfMemoryError) {
                failed = true
                failureDetail = "The phone ran out of memory."
            } finally {
                val note: String? = when {
                    cancelled -> null
                    failed -> (failureDetail ?: "Something went wrong while adding photos.") + " $added photos were added."
                    skipped > 0 -> "$skipped photos couldn't be read and were skipped."
                    added == 0 -> "No photos found in that folder or its sub-folders. Android doesn't allow picking " +
                        "Downloads or the very top of your storage - pick a folder inside them instead."
                    else -> null
                }
                _ui.update { it.copy(importProgress = null, importNote = note) }
                persistDraft()
            }
        }
    }

    fun deleteImage(id: String) {
        _ui.update { state ->
            state.copy(
                images = state.images.filterNot { it.id == id },
                slides = state.slides.map { s -> if (s.assignedImageId == id) s.copy(assignedImageId = null) else s }
            )
        }
        persistDraft()
    }

    fun clearAllImages() {
        importJob?.cancel()
        _ui.update {
            it.copy(
                images = emptyList(),
                slides = it.slides.map { s -> s.copy(assignedImageId = null) },
                importNote = null
            )
        }
        persistDraft()
    }

    fun moveImage(from: Int, to: Int) {
        _ui.update { state ->
            val list = state.images.toMutableList()
            if (from !in list.indices || to !in list.indices) return@update state
            val moved = list.removeAt(from)
            list.add(to, moved)
            state.copy(images = list)
        }
        persistDraft()
    }

    fun moveImageUp(index: Int) { if (index > 0) moveImage(index, index - 1) }
    fun moveImageDown(index: Int) { if (index < _ui.value.images.size - 1) moveImage(index, index + 1) }

    /** NEW: sets one photo's own display time (the editable "2:30" box) — drives simple mode. */
    fun setPhotoDuration(imageId: String, seconds: Double) {
        val clamped = seconds.coerceIn(0.5, 3600.0)
        _ui.update { state ->
            state.copy(images = state.images.map { img -> if (img.id == imageId) img.copy(durationOverrideSec = clamped) else img })
        }
        persistDraft()
    }

    // ---------- Step 3: Match ----------

    fun matchPrev() = _ui.update { it.copy(curMatchIndex = (it.curMatchIndex - 1).coerceAtLeast(0)) }
    fun matchSkip() = _ui.update { it.copy(curMatchIndex = (it.curMatchIndex + 1).coerceAtMost((it.slides.size - 1).coerceAtLeast(0))) }
    fun setAutoAdvance(on: Boolean) = _ui.update { it.copy(autoAdvance = on) }

    fun pickImage(imageId: String) {
        _ui.update { state ->
            val idx = state.curMatchIndex
            val newSlides = state.slides.toMutableList()
            if (idx in newSlides.indices) newSlides[idx] = newSlides[idx].copy(assignedImageId = imageId)
            state.copy(slides = newSlides)
        }
        persistDraft()
        if (_ui.value.autoAdvance) {
            viewModelScope.launch {
                delay(300)
                _ui.update { it.copy(curMatchIndex = (it.curMatchIndex + 1).coerceAtMost((it.slides.size - 1).coerceAtLeast(0))) }
            }
        }
    }

    fun editSentenceText(index: Int, text: String) {
        _ui.update { state ->
            val list = state.slides.toMutableList()
            if (index in list.indices) list[index] = list[index].copy(text = text)
            state.copy(slides = list)
        }
    }

    fun commitSentenceEdit() = persistDraft()

    fun speakCurrentSentence() {
        val state = _ui.value
        val text = state.slides.getOrNull(state.curMatchIndex)?.text ?: return
        clipPlayer.stop()
        tts.speak(text, state.settings.narration.voiceLocaleTag, state.settings.narration.speechRate)
    }

    // ---------- Match screen: hear the ORIGINAL recording for the current sentence ----------

    /**
     * Plays the part of the original recording that belongs to the current sentence: from its
     * timestamp up to the next sentence's timestamp. The recording's clock is the script's clock,
     * so the timestamp is used as-is.
     */
    fun playCurrentOriginal() {
        val state = _ui.value
        val uri = state.alignment.recordingUri ?: return
        val idx = state.curMatchIndex
        val slide = state.slides.getOrNull(idx) ?: return
        val startMs = toMs(slide.timestampSec)
        val endMs = state.slides.getOrNull(idx + 1)?.let { toMs(it.timestampSec) }
            ?: (startMs + state.settings.defaultDurationSec * 1000L)
        tts.stop()
        clipPlayer.play(uri, startMs, endMs)
    }

    fun stopOriginalClip() = clipPlayer.stop()

    /**
     * Moves one sentence's start time earlier (negative) or later (positive) by [deltaMs] and replays
     * the current sentence so the change can be heard at once. Moving the START of sentence N+1 is
     * how the END of sentence N is changed, so the Match screen calls this with the next index for that.
     * The script's original timestamp is kept. Returns a message when the move isn't possible, else null.
     */
    fun nudgeTimestamp(index: Int, deltaMs: Long): String? {
        val current = _ui.value.slides.getOrNull(index) ?: return null
        val message = setSlideTimestamp(index, toMs(current.timestampSec) + deltaMs)
        if (message == null) playCurrentOriginal()
        return message
    }

    /** Puts one sentence's start time back to what the script originally said, then replays it. */
    fun restoreOriginalTime(index: Int): String? {
        val original = _ui.value.slides.getOrNull(index)?.originalTimestampSec ?: return null
        val message = setSlideTimestamp(index, toMs(original))
        if (message == null) playCurrentOriginal()
        return message
    }

    /**
     * The one place a single sentence's timestamp is changed by hand. Sentences must stay in time
     * order and at least [AlignmentApplier.MIN_GAP_MS] apart, so the same rule as automatic
     * corrections decides whether the move is allowed. Keeps [SentenceSlide.originalTimestampSec]
     * (and clears it again if the time is moved back to the original), and keeps the alignment
     * results in step so later "apply" actions don't think the script changed underneath them.
     */
    private fun setSlideTimestamp(index: Int, targetMs: Long): String? {
        var message: String? = null
        var changed = false
        _ui.update { state ->
            message = null
            changed = false
            val slides = state.slides
            val slide = slides.getOrNull(index) ?: return@update state
            val cur = LongArray(slides.size) { toMs(slides[it].timestampSec) }
            if (targetMs == cur[index]) return@update state
            val plan = AlignmentApplier.plan(cur, mapOf(index to targetMs))
            if (!plan.accepted.containsKey(index)) {
                message = if (targetMs < 0L) "A sentence can't start before 0:00."
                else "Too close to the neighbouring sentence — they must stay at least 0.1 s apart."
                return@update state
            }
            val originalSec = slide.originalTimestampSec ?: slide.timestampSec
            val backToOriginal = toMs(originalSec) == targetMs
            val list = slides.toMutableList()
            list[index] = slide.copy(
                timestampSec = targetMs / 1000.0,
                originalTimestampSec = if (backToOriginal) null else originalSec
            )
            val oldMs = cur[index]
            val newItems = state.alignment.items.map { item ->
                if (item.index != index || item.currentMs != oldMs) item
                else item.copy(
                    currentMs = targetMs,
                    decision = when {
                        backToOriginal -> AlignmentDecision.KEPT_ORIGINAL
                        item.detectedMs == targetMs -> AlignmentDecision.APPLIED
                        else -> AlignmentDecision.ADJUSTED
                    }
                )
            }
            changed = true
            state.copy(slides = list, alignment = state.alignment.copy(items = newItems))
        }
        if (changed) persistDraft()
        return message
    }

    fun mergeCurrentWithNext() {
        clipPlayer.stop()
        _ui.update { state ->
            val idx = state.curMatchIndex
            if (idx >= state.slides.size - 1) return@update state
            val list = state.slides.toMutableList()
            val combined = listOf(list[idx].text, list[idx + 1].text).filter { it.isNotBlank() }.joinToString(" ")
            list[idx] = list[idx].copy(text = combined)
            list.removeAt(idx + 1)
            state.copy(slides = list)
        }
        persistDraft()
    }

    /** @param cursorOffset character offset within the current sentence where it should be cut. */
    fun splitCurrentSentence(cursorOffset: Int, splitTimeSec: Double): Boolean {
        clipPlayer.stop()
        var applied = false
        _ui.update { state ->
            val idx = state.curMatchIndex
            val slide = state.slides.getOrNull(idx) ?: return@update state
            val next = state.slides.getOrNull(idx + 1)
            val slotStart = slide.timestampSec
            val slotEnd = next?.timestampSec ?: (slotStart + state.settings.defaultDurationSec)
            if (splitTimeSec <= slotStart || splitTimeSec >= slotEnd) return@update state

            val text = slide.text
            val cut = cursorOffset.coerceIn(0, text.length)
            val part1 = text.substring(0, cut).trim()
            val part2 = text.substring(cut).trim()
            if (part1.isBlank() || part2.isBlank()) return@update state

            val list = state.slides.toMutableList()
            list[idx] = slide.copy(text = part1)
            list.add(idx + 1, SentenceSlide(splitTimeSec, part2))
            applied = true
            state.copy(slides = list)
        }
        if (applied) persistDraft()
        return applied
    }

    /** NEW: jump straight to any segment (used by the Match screen's full timeline strip). */
    fun goToMatchIndex(index: Int) {
        _ui.update { it.copy(curMatchIndex = index.coerceIn(0, (it.slides.size - 1).coerceAtLeast(0))) }
    }

    /**
     * NEW: removes the photo at [index] without leaving a dead gap in the timeline. The freed
     * time range is folded into a neighbor, which keeps ITS OWN photo and simply expands to
     * cover the extra time — matching the "remove this photo, let the next one cover this place"
     * workflow. Text from both slides is combined onto the surviving slide (same rule the
     * existing Merge uses), so no narration is silently dropped.
     *
     * Prefers folding forward into the next segment (next's photo expands backward to [index]'s
     * start time). If [index] is the last segment, folds backward into the previous one instead
     * (previous's photo expands forward). If it's the only segment, there's nothing to fold into,
     * so this just clears the assignment.
     */
    fun removePhotoAndCloseGap(index: Int) {
        _ui.update { state ->
            val list = state.slides.toMutableList()
            if (index !in list.indices) return@update state
            when {
                list.size == 1 -> {
                    list[index] = list[index].copy(assignedImageId = null)
                }
                index < list.size - 1 -> {
                    val current = list[index]
                    val next = list[index + 1]
                    val combinedText = listOf(current.text, next.text).filter { it.isNotBlank() }.joinToString(" ")
                    list[index + 1] = next.copy(timestampSec = current.timestampSec, text = combinedText)
                    list.removeAt(index)
                }
                else -> {
                    val current = list[index]
                    val prev = list[index - 1]
                    val combinedText = listOf(prev.text, current.text).filter { it.isNotBlank() }.joinToString(" ")
                    list[index - 1] = prev.copy(text = combinedText)
                    list.removeAt(index)
                }
            }
            state.copy(slides = list, curMatchIndex = state.curMatchIndex.coerceIn(0, (list.size - 1).coerceAtLeast(0)))
        }
        persistDraft()
    }

    // ---------- Step: Text overlays (character names etc.) ----------

    /** Adds a new overlay defaulting to a sensible, always-visible-on-first-add placement: right
     *  at the start of the timeline, for 3 seconds, so it's immediately visible to edit further. */
    fun addTextOverlay(text: String) {
        if (text.isBlank()) return
        val overlay = TextOverlay(
            id = UUID.randomUUID().toString(),
            text = text.trim(),
            startSec = 0.0,
            durationSec = 3.0
        )
        _ui.update { it.copy(textOverlays = it.textOverlays + overlay) }
        persistDraft()
    }

    fun updateTextOverlay(
        id: String,
        text: String? = null,
        startSec: Double? = null,
        durationSec: Double? = null,
        xFraction: Float? = null,
        yFraction: Float? = null,
        style: OverlayStyle? = null
    ) {
        _ui.update { state ->
            state.copy(textOverlays = state.textOverlays.map { ov ->
                if (ov.id != id) return@map ov
                ov.copy(
                    text = text ?: ov.text,
                    startSec = (startSec ?: ov.startSec).coerceAtLeast(0.0),
                    durationSec = (durationSec ?: ov.durationSec).coerceAtLeast(0.2),
                    xFraction = (xFraction ?: ov.xFraction).coerceIn(0.02f, 0.98f),
                    yFraction = (yFraction ?: ov.yFraction).coerceIn(0.05f, 0.95f),
                    style = style ?: ov.style
                )
            })
        }
        persistDraft()
    }

    fun removeTextOverlay(id: String) {
        _ui.update { it.copy(textOverlays = it.textOverlays.filterNot { ov -> ov.id == id }) }
        persistDraft()
    }

    // ---------- Step 4: Preview ----------

    private var previewJob: Job? = null
    private var previewLastSpokenIndex: Int = -1

    /**
     * NEW: real-time playback instead of the old "step through at 600ms per second of real
     * duration" simulation. Advances previewPositionSec at actual wall-clock speed (measured
     * between ticks, not assumed) so the zoom animation and duration shown genuinely match what
     * the export will produce, and speaks each sentence's narration once, right as its slide
     * becomes current, so you can listen and confirm photo/text/audio line up before exporting.
     */
    fun previewTogglePlay() {
        if (_ui.value.previewPlaying) {
            stopPreview()
            return
        }
        val total = _ui.value.totalDurationSec
        if (total <= 0.0) return
        // Pressing play at (or past) the end starts over, like a normal video player would,
        // instead of doing nothing.
        if (_ui.value.previewPositionSec >= total - 0.05) {
            previewLastSpokenIndex = -1
            _ui.update { it.copy(previewPositionSec = 0.0) }
        }
        _ui.update { it.copy(previewPlaying = true) }
        // Built once per playback, not once per 50 ms tick - with thousands of photos, rebuilding
        // it on every tick kept the phone busy enough to freeze the screen.
        val timeline = _ui.value.effectiveSlides
        previewJob = viewModelScope.launch {
            var lastTickMs = System.currentTimeMillis()
            while (true) {
                delay(PREVIEW_TICK_MS)
                val now = System.currentTimeMillis()
                val elapsedSec = (now - lastTickMs) / 1000.0
                lastTickMs = now

                val state = _ui.value
                val newPos = state.previewPositionSec + elapsedSec
                if (newPos >= total) {
                    tts.stop()
                    _ui.update { it.copy(previewPlaying = false, previewPositionSec = total) }
                    return@launch
                }
                _ui.update { it.copy(previewPositionSec = newPos) }

                if (state.settings.narration.enabled) {
                    val idx = state.slideIndexAt(newPos, timeline)
                    if (idx >= 0 && idx != previewLastSpokenIndex) {
                        previewLastSpokenIndex = idx
                        val text = timeline.getOrNull(idx)?.text
                        if (!text.isNullOrBlank()) {
                            tts.speak(text, state.settings.narration.voiceLocaleTag, state.settings.narration.speechRate)
                        }
                    }
                }
            }
        }
    }

    fun stopPreview() {
        previewJob?.cancel()
        tts.stop() // otherwise a sentence mid-speech keeps talking over a paused/static screen
        _ui.update { it.copy(previewPlaying = false) }
    }

    private fun previewSeekToSlide(index: Int) {
        stopPreview()
        val target = _ui.value.effectiveSlides.getOrNull(index)?.timestampSec ?: 0.0
        // One behind the target so resuming playback from here still speaks this slide once.
        previewLastSpokenIndex = index - 1
        _ui.update { it.copy(previewPositionSec = target) }
    }

    fun previewPrev() {
        val state = _ui.value
        previewSeekToSlide((state.slideIndexAt(state.previewPositionSec) - 1).coerceAtLeast(0))
    }

    fun previewNext() {
        val state = _ui.value
        val maxIndex = (state.effectiveSlides.size - 1).coerceAtLeast(0)
        previewSeekToSlide((state.slideIndexAt(state.previewPositionSec) + 1).coerceAtMost(maxIndex))
    }

    // ---------- Step 5: Export ----------

    fun startExport() {
        val app = getApplication<Application>()
        val state = _ui.value
        val intent = Intent(app, ExportForegroundService::class.java)
        app.startForegroundService(intent)
        app.bindService(intent, object : ServiceConnection {
            override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
                (binder as? ExportForegroundService.LocalBinder)?.service()?.startExport(state.effectiveSlides, state.images, state.settings, state.textOverlays)
                app.unbindService(this)
            }
            override fun onServiceDisconnected(name: ComponentName?) {}
        }, Context.BIND_AUTO_CREATE)
    }

    fun cancelExport() {
        val app = getApplication<Application>()
        app.bindService(Intent(app, ExportForegroundService::class.java), object : ServiceConnection {
            override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
                (binder as? ExportForegroundService.LocalBinder)?.service()?.cancel()
                app.unbindService(this)
            }
            override fun onServiceDisconnected(name: ComponentName?) {}
        }, Context.BIND_AUTO_CREATE)
    }

    override fun onCleared() {
        clipPlayer.release()
        tts.shutdown()
        super.onCleared()
    }
}
