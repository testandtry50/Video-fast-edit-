package com.videoslidemaker.app.viewmodel

import android.app.Application
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.net.Uri
import android.os.IBinder
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.videoslidemaker.app.align.AlignmentApplier
import com.videoslidemaker.app.align.AlignmentDecision
import com.videoslidemaker.app.align.AlignmentStatus
import com.videoslidemaker.app.align.ClipState
import com.videoslidemaker.app.align.PreviewRecordingPlayer
import com.videoslidemaker.app.align.RecordingClipPlayer
import com.videoslidemaker.app.align.RecordingReadException
import com.videoslidemaker.app.align.RecordingReader
import com.videoslidemaker.app.align.TimestampAligner
import com.videoslidemaker.app.data.ImageStore
import com.videoslidemaker.app.data.ProjectRepository
import com.videoslidemaker.app.ui.components.ScrollMemory
import com.videoslidemaker.app.data.ScriptParser
import com.videoslidemaker.app.export.ExportForegroundService
import com.videoslidemaker.app.logoclean.LogoCleanController
import com.videoslidemaker.app.model.AppStep
import com.videoslidemaker.app.model.AudioSource
import com.videoslidemaker.app.model.NarrationSettings
import com.videoslidemaker.app.model.AspectRatioOption
import com.videoslidemaker.app.model.EffectStyle
import com.videoslidemaker.app.model.ImportProgress
import com.videoslidemaker.app.model.OverlayStyle
import com.videoslidemaker.app.model.PoolImage
import com.videoslidemaker.app.model.PreviewSpeed
import com.videoslidemaker.app.model.QualityOption
import com.videoslidemaker.app.model.SentenceSlide
import com.videoslidemaker.app.model.TextOverlay
import com.videoslidemaker.app.model.TransitionStyle
import com.videoslidemaker.app.model.UiState
import com.videoslidemaker.app.tts.NarrationTts
import com.videoslidemaker.app.voicefx.FxRecordingPlayer
import com.videoslidemaker.app.voicefx.FxSpeechCache
import com.videoslidemaker.app.voicefx.PcmClipPlayer
import com.videoslidemaker.app.voicefx.VoiceEffect
import com.videoslidemaker.app.voicefx.VoiceFxSettings
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.UUID
import kotlin.math.abs
import kotlin.math.roundToInt

class AppViewModel(application: Application) : AndroidViewModel(application) {
    private val DRAFT_SAVE_DELAY_MS = 400L
    private val AUDITION_MS = 8_000L

    private val imageStore = ImageStore(application)
    private val tts = NarrationTts(application)
    private val clipPlayer = RecordingClipPlayer(application, viewModelScope)
    private val previewAudio = PreviewRecordingPlayer(application)

    // NEW: the voice changer. [fxAudio] plays the original recording through the effects, [clipFx] plays a
    // spoken sentence that was made and changed ahead of time by [speechFx].
    private val fxAudio = FxRecordingPlayer(application)
    private val clipFx = PcmClipPlayer()
    private val speechFx = FxSpeechCache(tts, application.cacheDir)
    private var fxSpeakJob: Job? = null
    private var fxRestartJob: Job? = null

    /** Live state of the "play original" control on the Match screen (kept out of [ui] so it doesn't redraw the whole screen). */
    val clip: StateFlow<ClipState> = clipPlayer.state
    private val projectRepository = ProjectRepository(application)

    /** NEW: remembers where the photo pools / pages were scrolled to (kept across screens AND app restarts). */
    val scrollMemory = ScrollMemory(application, viewModelScope)

    private val _ui = MutableStateFlow(UiState())

    // ---------- Undo / redo ----------
    // NEW: Undo and Redo for everything that changes the project (photos, matching, sentence text,
    // timestamps, name texts, all settings). Instead of adding "remember this" code to each of the
    // ~85 places that change the project, the project is WATCHED: when it changes, how it looked
    // before is kept. Changes that come in a rush (typing, dragging a slider, a big import) count
    // as ONE step, so one Undo takes back the whole rush.
    private val UNDO_GROUP_MS = 700L
    private val history = UndoHistory<ProjectSnapshot>()
    /** The project as of the last settled moment. */
    private var baseline = ProjectSnapshot.of(UiState())
    /** Set while a rush of changes is still going: how the project looked just before it began. */
    private var burstBase: ProjectSnapshot? = null
    private var commitJob: Job? = null

    private val _undoUi = MutableStateFlow(UndoUi())
    /** What the Undo / Redo buttons need: whether each can be used and what it would take back. */
    val undoUi: StateFlow<UndoUi> = _undoUi.asStateFlow()

    init {
        viewModelScope.launch { _ui.collect { onProjectMaybeChanged(it) } }
    }
    val ui: StateFlow<UiState> =
        combine(_ui, ExportForegroundService.progress) { state, progress -> state.copy(exportProgress = progress) }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), UiState())

    // Kept as a Job so a photo import can wait until the saved draft has finished loading -
    // otherwise a late-arriving draft could overwrite photos that were just added.
    private val draftLoadJob: Job = viewModelScope.launch {
        projectRepository.load()?.let { restored ->
            // Come back to the same sentence you were matching, not the first one.
            val savedSentence = scrollMemory.get("match_index").index
            _ui.update { restored.copy(curMatchIndex = savedSentence.coerceIn(0, (restored.slides.size - 1).coerceAtLeast(0))) }
            // Loading the saved project is not something to undo.
            resetHistory()
        }
    }

    private var persistJob: Job? = null

    /**
     * Auto-saves the draft a moment after the LAST change, instead of once per change. Importing
     * thousands of photos changes the state many times in a row, and re-writing a multi-megabyte
     * file every single time was wasted work.
     */
    private fun persistDraft() {
        persistJob?.cancel()
        persistJob = viewModelScope.launch {
            delay(DRAFT_SAVE_DELAY_MS)
            projectRepository.save(_ui.value)
        }
    }

    // ---------- Undo / redo: the machinery ----------

    private fun onProjectMaybeChanged(state: UiState) {
        if (burstBase == null) {
            val now = ProjectSnapshot.of(state)
            if (now.sameDataAs(baseline)) {
                // Only moving around changed (for example which sentence you are on) - not an edit.
                baseline = now
                return
            }
            burstBase = baseline // an edit began: remember how things were just before it
        }
        scheduleCommit()
    }

    private fun scheduleCommit() {
        commitJob?.cancel()
        commitJob = viewModelScope.launch {
            delay(UNDO_GROUP_MS)
            // A long import / logo-cleaning run is ONE step: wait until it is finished.
            while (_ui.value.importProgress != null || logoClean.ui.value.working || logoClean.ui.value.scanning) {
                delay(UNDO_GROUP_MS)
            }
            commitBurst()
        }
    }

    /** Closes the current rush of changes into one undo step. */
    private fun commitBurst() {
        val before = burstBase ?: return
        val now = ProjectSnapshot.of(_ui.value)
        burstBase = null
        if (!now.sameDataAs(before)) {
            history.push(before, describeChange(before, now))
            publishUndoUi()
        }
        baseline = now
    }

    private fun resetHistory() {
        commitJob?.cancel()
        burstBase = null
        history.clear()
        baseline = ProjectSnapshot.of(_ui.value)
        publishUndoUi()
    }

    private fun publishUndoUi() {
        _undoUi.value = UndoUi(
            canUndo = history.canUndo,
            canRedo = history.canRedo,
            undoLabel = history.undoLabel,
            redoLabel = history.redoLabel
        )
    }

    /** Not while something is running that is also changing the project - the two would fight. */
    private fun historyBlocked(): Boolean {
        val s = _ui.value
        return s.importProgress != null ||
            s.alignment.running ||
            s.alignment.reviewOpen ||
            ExportForegroundService.progress.value.running ||
            logoClean.ui.value.working
    }

    fun undo() = stepHistory(undo = true)

    fun redo() = stepHistory(undo = false)

    private fun stepHistory(undo: Boolean) {
        if (historyBlocked()) return
        // An edit that is still "in progress" (you just typed) becomes its own step first.
        commitJob?.cancel()
        commitBurst()
        val current = ProjectSnapshot.of(_ui.value)
        val entry = (if (undo) history.undo(current) else history.redo(current)) ?: return
        applySnapshot(entry.snapshot)
        publishUndoUi()
        android.widget.Toast.makeText(
            getApplication<Application>(),
            (if (undo) "Undid: " else "Redid: ") + entry.label,
            android.widget.Toast.LENGTH_SHORT
        ).show()
    }

    private fun applySnapshot(snap: ProjectSnapshot) {
        // A photo's cleaned copy is deleted when the photo is removed. If Undo brings that photo
        // back, point it at its original file again (exactly what loading a saved draft does).
        val images = if (snap.images.any { it.originalUri != null }) {
            snap.images.map { img ->
                val original = img.originalUri
                val cleanedFile = if (img.uri.scheme == "file") img.uri.path?.let { java.io.File(it) } else null
                if (original != null && cleanedFile != null && !cleanedFile.exists()) {
                    img.copy(uri = original, originalUri = null, cleanMode = null, cleanLog = emptyMap())
                } else img
            }
        } else snap.images
        val applied = snap.copy(images = images)

        // Set the baseline FIRST, so the project watcher sees "nothing new" and Undo is not
        // recorded as an edit of its own.
        commitJob?.cancel()
        burstBase = null
        baseline = applied
        val before = _ui.value
        _ui.update { st ->
            val sentence = if (st.step == AppStep.MATCH) snap.matchIndex else st.curMatchIndex
            st.copy(
                slides = applied.slides,
                images = applied.images,
                textOverlays = applied.textOverlays,
                settings = applied.settings,
                scriptLoaded = applied.scriptLoaded,
                curMatchIndex = sentence.coerceIn(0, (applied.slides.size - 1).coerceAtLeast(0)),
                // Timestamp-check results belong to the sentences as they were; they no longer match.
                alignment = if (before.slides !== applied.slides) {
                    st.alignment.copy(items = emptyList(), drift = emptyList(), reviewOpen = false, notice = null)
                } else st.alignment
            )
        }
        persistDraft()
    }

    // ---------- Logo & watermark cleaner ----------

    /**
     * Finds a small logo / watermark in the photos and blurs or removes just that spot. It never edits
     * the original photos: a cleaned copy is saved and the photo's uri is pointed at it, so the
     * thumbnails, preview and export all pick it up with no other change.
     */
    val logoClean = LogoCleanController(
        context = application,
        store = imageStore,
        scope = viewModelScope,
        currentImages = { _ui.value.images },
        replaceImages = { updates ->
            _ui.update { state -> state.copy(images = state.images.map { updates[it.id] ?: it }) }
            persistDraft()
        }
    )

    // ---------- Navigation ----------

    fun goStep(step: AppStep) {
        val state = _ui.value
        if ((step == AppStep.TEXT || step == AppStep.PREVIEW || step == AppStep.EXPORT) && state.images.isEmpty()) return
        // Moving to another screen must never leave the preview's sound running in the background.
        if (step != state.step) stopPreview()
        _ui.update { it.copy(step = step) }
        when (step) {
            AppStep.MATCH -> _ui.update { it.copy(curMatchIndex = it.curMatchIndex.coerceIn(0, (it.slides.size - 1).coerceAtLeast(0))) }
            AppStep.PREVIEW -> {
                stopPreview()
                previewLastSpokenIndex = -1
                _previewPos.value = 0.0
            }
            else -> {}
        }
    }

    /** Where "Next" from the Photos screen should go: Match only makes sense with a script loaded. */
    fun goNextFromPhotos() {
        goStep(if (_ui.value.scriptLoaded) AppStep.MATCH else AppStep.TEXT)
    }

    // ---------- Step 1: Script + global settings ----------

    fun loadScript(content: String) {
        val parsed = ScriptParser.parseScriptDetailed(content)
        val slides = parsed.lines.map { SentenceSlide(it.timestampSec, it.text) }
        val issues = parsed.issues.map { it.describe() }
        _ui.update { it.copy(slides = slides, scriptLoaded = slides.isNotEmpty(), curMatchIndex = 0, scriptIssues = issues) }
        persistDraft()
    }

    fun setDefaultDuration(seconds: Int) {
        _ui.update { it.copy(settings = it.settings.copy(defaultDurationSec = seconds.coerceIn(1, 30))) }
        persistDraft()
    }
    fun setVoiceLocale(tag: String) {
        _ui.update { it.copy(settings = it.settings.copy(narration = it.settings.narration.copy(voiceLocaleTag = tag))) }
        persistDraft()
    }
    fun setEffectStyle(style: EffectStyle) {
        _ui.update { it.copy(settings = it.settings.copy(effectStyle = style)) }
        persistDraft()
    }
    fun setTransitionStyle(style: TransitionStyle) {
        _ui.update { it.copy(settings = it.settings.copy(transitionStyle = style)) }
        persistDraft()
    }
    fun setAspectRatio(ratio: AspectRatioOption) {
        _ui.update { it.copy(settings = it.settings.copy(aspectRatio = ratio)) }
        persistDraft()
    }
    fun setQuality(quality: QualityOption) {
        _ui.update { it.copy(settings = it.settings.copy(quality = quality)) }
        persistDraft()
    }
    fun setNarrationEnabled(enabled: Boolean) {
        val wasPlaying = _ui.value.previewPlaying
        if (wasPlaying) stopPreview()
        _ui.update { it.copy(settings = it.settings.copy(narration = it.settings.narration.copy(enabled = enabled)), previewAudioNote = null) }
        persistDraft()
        if (wasPlaying) startPreview()
    }

    /** Picks what is heard with the photos: the text-to-speech voice, or the user's own recording. */
    fun setAudioSource(source: AudioSource) {
        val wasPlaying = _ui.value.previewPlaying
        if (wasPlaying) stopPreview()
        _ui.update {
            it.copy(
                settings = it.settings.copy(narration = it.settings.narration.copy(source = source, enabled = true)),
                previewAudioNote = null
            )
        }
        persistDraft()
        if (wasPlaying) startPreview()
    }
    fun setMusicUri(uri: Uri?, displayName: String?) {
        _ui.update { it.copy(settings = it.settings.copy(music = it.settings.music.copy(uri = uri, displayName = displayName))) }
        persistDraft()
    }
    fun setMusicVolume(volume: Float) {
        _ui.update { it.copy(settings = it.settings.copy(music = it.settings.music.copy(volume = volume.coerceIn(0f, 1f)))) }
        persistDraft()
    }

    // ---------- Voice changer ----------

    private fun updateVoiceFx(change: (VoiceFxSettings) -> VoiceFxSettings) {
        _ui.update { st ->
            val narration = st.settings.narration
            st.copy(settings = st.settings.copy(narration = narration.copy(voiceFx = change(narration.voiceFx))))
        }
        persistDraft()
        restartPreviewSoundSoon()
    }

    private fun roundTo(value: Float, steps: Float): Float = (value * steps).roundToInt() / steps

    /** Pitch in semitones, -24..+24, in steps of 0.01 (1 cent). The speed of the voice does not change. */
    fun setPitch(semitones: Float) {
        val limit = VoiceFxSettings.MAX_PITCH_ST
        val v = roundTo(semitones.coerceIn(-limit, limit), 100f)
        updateVoiceFx { it.copy(pitchSemitones = v) }
    }

    /** Moves the pitch by [deltaSemitones] (for the small -1 / -0.1 / -0.01 / +0.01 / +0.1 / +1 buttons). */
    fun nudgePitch(deltaSemitones: Float) {
        setPitch(_ui.value.settings.narration.voiceFx.pitchSemitones + deltaSemitones)
    }

    /** How much to make a too-clean (AI) voice feel recorded by a person, 0..1. */
    fun setHumanize(amount: Float) {
        val v = roundTo(amount.coerceIn(0f, 1f), 100f)
        updateVoiceFx { it.copy(humanize = v) }
    }

    fun setBreaths(on: Boolean) = updateVoiceFx { it.copy(breaths = on) }

    fun setVoiceEffect(effect: VoiceEffect) = updateVoiceFx { it.copy(effect = effect) }

    fun setEffectAmount(amount: Float) {
        val v = roundTo(amount.coerceIn(0f, 1f), 100f)
        updateVoiceFx { it.copy(effectAmount = v) }
    }

    fun setEffectSpeed(speed: Float) {
        val v = roundTo(speed.coerceIn(0f, 1f), 100f)
        updateVoiceFx { it.copy(effectSpeed = v) }
    }

    fun resetVoiceFx() = updateVoiceFx { VoiceFxSettings() }

    /** While the preview plays, a changed setting is applied by restarting the sound at the same spot (once the sliders settle). */
    private fun restartPreviewSoundSoon() {
        if (!_ui.value.previewPlaying) return
        fxRestartJob?.cancel()
        fxRestartJob = viewModelScope.launch {
            delay(350)
            if (_ui.value.previewPlaying) previewSeekTo(_previewPos.value)
        }
    }

    /**
     * "Hear a sample": plays about 8 seconds of your recording (from where the preview is, or from the
     * first sentence), or one sentence of the phone's voice, with the current voice-changer settings.
     */
    fun auditionVoiceFx() {
        val state = _ui.value
        if (state.previewPlaying) return
        stopPreview()
        clipPlayer.stop()
        val narration = state.settings.narration
        val fx = narration.voiceFx
        if (narration.source == AudioSource.ORIGINAL) {
            val recording = state.alignment.recordingUri
            if (recording == null) {
                _ui.update { it.copy(previewAudioNote = "Choose your recording first, then you can hear the voice changer on it.") }
                return
            }
            val startSec = if (_previewPos.value > 0.0) _previewPos.value else (state.slides.firstOrNull()?.timestampSec ?: 0.0)
            val startMs = toMs(startSec)
            fxSpeakJob = viewModelScope.launch {
                _ui.update { it.copy(previewLoadingAudio = true, previewAudioNote = null) }
                val problem = fxAudio.playFrom(recording, startMs, fx, startMs + AUDITION_MS)
                _ui.update { it.copy(previewLoadingAudio = false, previewAudioNote = problem) }
            }
        } else {
            val text = (state.slides.firstOrNull { it.text.isNotBlank() }?.text ?: sampleSentence(narration.voiceLocaleTag)).take(160)
            fxSpeakJob = viewModelScope.launch {
                _ui.update { it.copy(previewLoadingAudio = true, previewAudioNote = null) }
                val pcm = speechFx.get(text, narration.voiceLocaleTag, narration.speechRate, fx)
                _ui.update {
                    it.copy(
                        previewLoadingAudio = false,
                        previewAudioNote = if (pcm == null) "The phone's voice could not make this sample." else null
                    )
                }
                if (pcm != null && isActive) clipFx.play(pcm)
            }
        }
    }

    private fun sampleSentence(localeTag: String): String =
        if (localeTag.startsWith("hi")) "नमस्ते, यह मेरी आवाज़ है। सुनिए, यह कैसी लग रही है।"
        else "Hello, this is how my voice sounds with these settings."

    // ---------- Automatic timestamp alignment (script screen) ----------

    private var alignJob: Job? = null

    private fun toMs(seconds: Double): Long = ScriptParser.secondsToMillis(seconds)

    private fun updateAlignment(change: (com.videoslidemaker.app.align.AlignmentState) -> com.videoslidemaker.app.align.AlignmentState) {
        _ui.update { it.copy(alignment = change(it.alignment)) }
    }

    /** Chooses the recording (audio or video) that timestamps will be checked against. */
    fun setRecording(uri: Uri?, name: String?) {
        clipPlayer.release()
        previewAudio.release()
        fxAudio.release()
        updateAlignment {
            it.copy(
                recordingUri = uri, recordingName = name, error = null, notice = null,
                // results belong to the old recording
                items = emptyList(), drift = emptyList(), reviewOpen = false
            )
        }
        persistDraft()
    }

    fun setAutoApplyAlignment(on: Boolean) {
        updateAlignment { it.copy(autoApply = on) }
        persistDraft()
    }

    fun openAlignmentReview(open: Boolean) = updateAlignment { it.copy(reviewOpen = open) }

    fun cancelAlignment() {
        alignJob?.cancel()
    }

    private fun alignmentFailed(message: String) {
        updateAlignment { it.copy(running = false, percent = 0, stage = "", error = message) }
    }

    /**
     * Listens to the recording and works out, for every script line independently, when it is
     * really spoken. Nothing is changed in the script here — this only produces suggestions.
     * The baseline for comparison is always the script's ORIGINAL timestamp, so re-running after
     * applying corrections gives the same answers rather than drifting further.
     */
    fun runAlignment() {
        if (alignJob?.isActive == true) return
        val state = _ui.value
        val uri = state.alignment.recordingUri
        if (uri == null) { alignmentFailed("Choose the recording first."); return }
        if (state.slides.isEmpty()) { alignmentFailed("Load a script first — there are no timestamps to check."); return }

        val slides = state.slides
        val originals = slides.map { toMs(it.originalTimestampSec ?: it.timestampSec) }
        val currents = slides.map { toMs(it.timestampSec) }
        val texts = slides.map { it.text }
        val hadOriginal = slides.map { it.originalTimestampSec != null }

        alignJob = viewModelScope.launch {
            updateAlignment {
                it.copy(running = true, percent = 0, stage = "Reading the recording…", error = null, notice = null, items = emptyList(), drift = emptyList())
            }
            try {
                val recording = withContext(Dispatchers.Default) {
                    RecordingReader.read(
                        context = getApplication<Application>(),
                        uri = uri,
                        onProgress = { pct -> updateAlignment { a -> a.copy(percent = pct * 85 / 100) } },
                        isCancelled = { !isActive }
                    )
                }
                val result = withContext(Dispatchers.Default) {
                    TimestampAligner.align(
                        frames = recording.frames,
                        timeOffsetMs = recording.startOffsetMs,
                        originalMs = originals,
                        texts = texts,
                        onStage = { stage -> updateAlignment { a -> a.copy(stage = stage, percent = 90) } },
                        isCancelled = { !isActive }
                    )
                }
                val items = result.items.map { item ->
                    val cur = currents[item.index]
                    val alreadyApplied = hadOriginal[item.index] && item.detectedMs != null && cur == item.detectedMs
                    item.copy(
                        currentMs = cur,
                        decision = if (alreadyApplied) AlignmentDecision.APPLIED else AlignmentDecision.PENDING
                    )
                }
                updateAlignment {
                    it.copy(running = false, percent = 100, stage = "", items = items, clarityDb = result.clarityDb, drift = result.drift)
                }
                if (_ui.value.alignment.autoApply) applyAllHighConfidence()
            } catch (e: CancellationException) {
                updateAlignment { it.copy(running = false, percent = 0, stage = "") }
                throw e
            } catch (e: RecordingReadException) {
                alignmentFailed(e.message ?: "Couldn't read the recording.")
            } catch (e: OutOfMemoryError) {
                alignmentFailed("The phone ran out of memory while analysing the recording.")
            } catch (e: Exception) {
                alignmentFailed("Couldn't analyse the recording: " + (e.message ?: e.javaClass.simpleName))
            }
        }
    }

    /** "Apply correction" for one line. */
    fun applyAlignmentCorrection(index: Int) = applyItems(listOf(index))

    /** "Apply all high-confidence corrections": every line the analysis was sure about and the user hasn't decided on. */
    fun applyAllHighConfidence() {
        val ids = _ui.value.alignment.items
            .filter { it.status == AlignmentStatus.HIGH_CONFIDENCE && it.decision == AlignmentDecision.PENDING && it.canApply }
            .map { it.index }
        applyItems(ids)
    }

    /**
     * "Apply correction to all": applies the detected time to every given line that can still be
     * corrected, including lines the user earlier chose to keep as original. Lines where no
     * matching speech was found have nothing to apply and are reported in the notice.
     * Lines that would overlap a neighbour are refused by [AlignmentApplier], as with a single apply.
     */
    fun applyCorrectionToAll(indices: List<Int>) {
        val items = _ui.value.alignment.items
        val scope = indices.toHashSet()
        val inScope = items.filter { it.index in scope }
        val ids = inScope.filter { it.canApply }.map { it.index }
        val noDetection = inScope.count { it.detectedMs == null }
        val note = if (noDetection > 0) "$noDetection skipped: no matching speech was found in the audio." else null
        if (ids.isEmpty()) {
            updateAlignment {
                it.copy(notice = "Nothing to apply${if (noDetection > 0) " — no matching speech was found for these lines" else " — they already use the detected time"}.")
            }
            return
        }
        applyItems(ids, note)
    }

    /**
     * "Keep original for all": every given line goes back to (or stays at) the timestamp the script
     * originally had, and is marked "Original kept". Lines that can't be moved back without
     * overlapping a neighbour keep their current time and are reported in the notice.
     */
    fun keepOriginalForAll(indices: List<Int>) {
        if (indices.isEmpty()) return
        _ui.update { state ->
            val slides = state.slides
            val items = state.alignment.items
            val scope = indices.toHashSet()
            val cur = LongArray(slides.size) { toMs(slides[it].timestampSec) }
            val wanted = LinkedHashMap<Int, Long>()
            for (idx in scope) {
                val sl = slides.getOrNull(idx) ?: continue
                sl.originalTimestampSec?.let { wanted[idx] = toMs(it) }
            }
            val plan = AlignmentApplier.plan(cur, wanted)
            val rejected = plan.rejected.toHashSet()
            val list = slides.toMutableList()
            for (idx in plan.accepted.keys) {
                val sl = list[idx]
                list[idx] = sl.copy(timestampSec = sl.originalTimestampSec ?: sl.timestampSec, originalTimestampSec = null)
            }
            // a line already sitting at its original time only needs the "corrected" marker cleared
            for ((idx, ms) in wanted) {
                if (!plan.accepted.containsKey(idx) && idx !in rejected && ms == cur[idx]) {
                    list[idx] = list[idx].copy(originalTimestampSec = null)
                }
            }
            var kept = 0
            val newItems = items.map { item ->
                if (item.index !in scope || item.index in rejected) item
                else {
                    kept++
                    val restored = plan.accepted[item.index]
                    item.copy(currentMs = restored ?: item.currentMs, decision = AlignmentDecision.KEPT_ORIGINAL)
                }
            }
            val restoredCount = plan.accepted.size
            state.copy(
                slides = list,
                alignment = state.alignment.copy(
                    items = newItems,
                    notice = "Original kept for $kept line(s)" +
                        (if (restoredCount > 0) ", $restoredCount restored to the original time." else ".") +
                        (if (rejected.isNotEmpty()) " ${rejected.size} couldn't be restored (they would overlap a neighbouring line)." else "")
                )
            )
        }
        persistDraft()
    }

    private fun applyItems(indices: List<Int>, extraNote: String? = null) {
        if (indices.isEmpty() && extraNote == null) return
        _ui.update { state ->
            val slides = state.slides
            val items = state.alignment.items
            val byIndex = items.associateBy { it.index }
            val wanted = LinkedHashMap<Int, Long>()
            var stale = 0
            for (idx in indices) {
                val item = byIndex[idx] ?: continue
                val target = item.detectedMs ?: continue
                val slide = slides.getOrNull(idx)
                // The script may have been edited since the analysis; never write to the wrong line.
                if (slide == null || slide.text != item.text || toMs(slide.timestampSec) != item.currentMs) {
                    stale++
                    continue
                }
                if (target != item.currentMs) wanted[idx] = target
            }
            val plan = AlignmentApplier.plan(LongArray(slides.size) { toMs(slides[it].timestampSec) }, wanted)
            val newSlides = slides.toMutableList()
            for ((idx, ms) in plan.accepted) {
                val old = newSlides[idx]
                newSlides[idx] = old.copy(timestampSec = ms / 1000.0, originalTimestampSec = old.originalTimestampSec ?: old.timestampSec)
            }
            val newItems = items.map { item ->
                val ms = plan.accepted[item.index]
                if (ms != null) item.copy(currentMs = ms, decision = AlignmentDecision.APPLIED) else item
            }
            val notes = ArrayList<String>()
            if (plan.rejected.isNotEmpty()) notes.add("${plan.rejected.size} not applied: they would overlap a neighbouring line.")
            if (stale > 0) notes.add("$stale not applied: the script changed since the analysis — analyse again.")
            if (extraNote != null) notes.add(extraNote)
            state.copy(
                slides = newSlides,
                alignment = state.alignment.copy(
                    items = newItems,
                    notice = if (plan.accepted.isNotEmpty() || notes.isNotEmpty())
                        (listOf("${plan.accepted.size} timestamp(s) corrected.") + notes).joinToString(" ") else null
                )
            )
        }
        persistDraft()
    }

    /** "Keep original": makes sure this line uses the script's own timestamp (restoring it if a correction had been applied). */
    fun keepOriginalTimestamp(index: Int) {
        _ui.update { state ->
            val slide = state.slides.getOrNull(index)
            val items = state.alignment.items
            val item = items.firstOrNull { it.index == index }
            if (slide == null || item == null) return@update state
            var slides = state.slides
            var currentMs = item.currentMs
            var notice: String? = state.alignment.notice
            val original = slide.originalTimestampSec
            if (original != null) {
                val target = toMs(original)
                val cur = LongArray(slides.size) { toMs(slides[it].timestampSec) }
                if (target == cur[index]) {
                    // already at the original time; just drop the "corrected" marker
                    val list = slides.toMutableList()
                    list[index] = slide.copy(originalTimestampSec = null)
                    slides = list
                    notice = null
                } else {
                    val plan = AlignmentApplier.plan(cur, mapOf(index to target))
                    if (plan.accepted.containsKey(index)) {
                        val list = slides.toMutableList()
                        list[index] = slide.copy(timestampSec = original, originalTimestampSec = null)
                        slides = list
                        currentMs = target
                        notice = null
                    } else {
                        return@update state.copy(
                            alignment = state.alignment.copy(
                                notice = "Couldn't restore line ${index + 1}: it would overlap a neighbouring line. Restore that one first."
                            )
                        )
                    }
                }
            }
            state.copy(
                slides = slides,
                alignment = state.alignment.copy(
                    notice = notice,
                    items = items.map { if (it.index == index) it.copy(currentMs = currentMs, decision = AlignmentDecision.KEPT_ORIGINAL) else it }
                )
            )
        }
        persistDraft()
    }

    /** Restores every corrected line to the timestamp the script originally had. */
    fun revertAllAlignment() {
        _ui.update { state ->
            val slides = state.slides
            val cur = LongArray(slides.size) { toMs(slides[it].timestampSec) }
            val wanted = LinkedHashMap<Int, Long>()
            for ((i, sl) in slides.withIndex()) sl.originalTimestampSec?.let { wanted[i] = toMs(it) }
            val plan = AlignmentApplier.plan(cur, wanted)
            val list = slides.toMutableList()
            for ((idx, _) in plan.accepted) {
                val sl = list[idx]
                list[idx] = sl.copy(timestampSec = sl.originalTimestampSec ?: sl.timestampSec, originalTimestampSec = null)
            }
            // a line whose timestamp already equals its original just needs the marker cleared
            for ((idx, ms) in wanted) {
                if (!plan.accepted.containsKey(idx) && ms == cur[idx]) list[idx] = list[idx].copy(originalTimestampSec = null)
            }
            val newItems = state.alignment.items.map { item ->
                if (plan.accepted.containsKey(item.index)) item.copy(currentMs = item.originalMs, decision = AlignmentDecision.PENDING) else item
            }
            state.copy(
                slides = list,
                alignment = state.alignment.copy(
                    items = newItems,
                    notice = "${plan.accepted.size} timestamp(s) restored to the original." +
                        if (plan.rejected.isNotEmpty()) " ${plan.rejected.size} couldn't be restored (they would overlap a neighbouring line)." else ""
                )
            )
        }
        persistDraft()
    }

    // ---------- Step 2: Photos ----------

    private var importJob: Job? = null

    fun addImages(uris: List<Uri>) {
        if (uris.isEmpty()) return
        runImport { onBatch -> imageStore.importFiles(uris, onBatch) }
    }

    /** NEW: bulk-import every image in a picked folder at once — see ImageStore.importFolder
     *  for why this is the real fix for large photo counts (hundreds+), not just a convenience. */
    fun addImagesFromTree(treeUri: Uri) {
        runImport { onBatch ->
            imageStore.importFolder(treeUri, onBatch) { found ->
                // While the folders are still being listed: show how many photos turned up so far.
                _ui.update { it.copy(importProgress = ImportProgress(0, 0, found)) }
            }
        }
    }

    /** Stops a running photo import. Photos that were already added stay in the list. */
    fun cancelImport() {
        importJob?.cancel()
    }

    /**
     * Runs one photo import in the background. Every finished chunk of photos is added to the
     * list straight away and the progress is published, so the screen keeps showing live
     * progress instead of looking frozen until thousands of photos are done. Only one import
     * runs at a time, and nothing that goes wrong inside it can crash the app.
     *
     * [work] does the actual reading (see ImageStore) and returns how many photos were skipped.
     */
    private fun runImport(work: suspend ((List<PoolImage>, Int, Int) -> Unit) -> Int) {
        if (importJob?.isActive == true) return
        importJob = viewModelScope.launch {
            draftLoadJob.join()
            _ui.update { it.copy(importProgress = ImportProgress(), importNote = null) }

            var added = 0
            var skipped = 0
            var failed = false
            var failureDetail: String? = null
            var cancelled = false

            val onBatch: (List<PoolImage>, Int, Int) -> Unit = { batch, processed, total ->
                added += batch.size
                _ui.update {
                    it.copy(
                        images = if (batch.isEmpty()) it.images else it.images + batch,
                        importProgress = ImportProgress(processed, total)
                    )
                }
            }

            try {
                skipped = work(onBatch)
            } catch (e: CancellationException) {
                cancelled = true
                throw e
            } catch (e: Exception) {
                failed = true
                failureDetail = e.message
            } catch (e: OutOfMemoryError) {
                failed = true
                failureDetail = "The phone ran out of memory."
            } finally {
                val note: String? = when {
                    cancelled -> null
                    failed -> (failureDetail ?: "Something went wrong while adding photos.") + " $added photos were added."
                    skipped > 0 -> "$skipped photos couldn't be read and were skipped."
                    added == 0 -> "No photos found in that folder or its sub-folders. Android doesn't allow picking " +
                        "Downloads or the very top of your storage - pick a folder inside them instead."
                    else -> null
                }
                _ui.update { it.copy(importProgress = null, importNote = note) }
                persistDraft()
            }
        }
    }

    fun deleteImage(id: String) {
        logoClean.discard(_ui.value.images.filter { it.id == id })
        _ui.update { state ->
            state.copy(
                images = state.images.filterNot { it.id == id },
                slides = state.slides.map { s -> if (s.assignedImageId == id) s.copy(assignedImageId = null) else s }
            )
        }
        persistDraft()
    }

    fun clearAllImages() {
        importJob?.cancel()
        logoClean.cancel()
        logoClean.discard(_ui.value.images)
        _ui.update {
            it.copy(
                images = emptyList(),
                slides = it.slides.map { s -> s.copy(assignedImageId = null) },
                importNote = null
            )
        }
        persistDraft()
    }

    fun moveImage(from: Int, to: Int) {
        _ui.update { state ->
            val list = state.images.toMutableList()
            if (from !in list.indices || to !in list.indices) return@update state
            val moved = list.removeAt(from)
            list.add(to, moved)
            state.copy(images = list)
        }
        persistDraft()
    }

    fun moveImageUp(index: Int) { if (index > 0) moveImage(index, index - 1) }
    fun moveImageDown(index: Int) { if (index < _ui.value.images.size - 1) moveImage(index, index + 1) }

    /** NEW: sets one photo's own display time (the editable "2:30" box) — drives simple mode. */
    fun setPhotoDuration(imageId: String, seconds: Double) {
        val clamped = seconds.coerceIn(0.5, 3600.0)
        _ui.update { state ->
            state.copy(images = state.images.map { img -> if (img.id == imageId) img.copy(durationOverrideSec = clamped) else img })
        }
        persistDraft()
    }

    // ---------- Step 3: Match ----------

    fun matchPrev() = _ui.update { it.copy(curMatchIndex = (it.curMatchIndex - 1).coerceAtLeast(0)) }
    fun matchSkip() = _ui.update { it.copy(curMatchIndex = (it.curMatchIndex + 1).coerceAtMost((it.slides.size - 1).coerceAtLeast(0))) }
    fun setAutoAdvance(on: Boolean) = _ui.update { it.copy(autoAdvance = on) }

    fun pickImage(imageId: String) {
        _ui.update { state ->
            val idx = state.curMatchIndex
            val newSlides = state.slides.toMutableList()
            if (idx in newSlides.indices) newSlides[idx] = newSlides[idx].copy(assignedImageId = imageId)
            state.copy(slides = newSlides)
        }
        persistDraft()
        if (_ui.value.autoAdvance) {
            viewModelScope.launch {
                delay(300)
                _ui.update { it.copy(curMatchIndex = (it.curMatchIndex + 1).coerceAtMost((it.slides.size - 1).coerceAtLeast(0))) }
            }
        }
    }

    fun editSentenceText(index: Int, text: String) {
        _ui.update { state ->
            val list = state.slides.toMutableList()
            if (index in list.indices) list[index] = list[index].copy(text = text)
            state.copy(slides = list)
        }
    }

    fun commitSentenceEdit() = persistDraft()

    fun speakCurrentSentence() {
        val state = _ui.value
        val text = state.slides.getOrNull(state.curMatchIndex)?.text ?: return
        clipPlayer.stop()
        val narration = state.settings.narration
        fxSpeakJob?.cancel()
        clipFx.stop()
        if (narration.voiceFx.isActive) {
            // the voice changer can't touch live speech, so the sentence is made first, changed, then played
            tts.stop()
            fxSpeakJob = viewModelScope.launch {
                val pcm = speechFx.get(text, narration.voiceLocaleTag, narration.speechRate, narration.voiceFx)
                if (pcm != null && isActive) clipFx.play(pcm)
            }
        } else {
            tts.speak(text, narration.voiceLocaleTag, narration.speechRate)
        }
    }

    // ---------- Match screen: hear the ORIGINAL recording for the current sentence ----------

    /**
     * Plays the part of the original recording that belongs to the current sentence: from its
     * timestamp up to the next sentence's timestamp. The recording's clock is the script's clock,
     * so the timestamp is used as-is.
     */
    fun playCurrentOriginal() {
        val state = _ui.value
        val uri = state.alignment.recordingUri ?: return
        val idx = state.curMatchIndex
        val slide = state.slides.getOrNull(idx) ?: return
        val startMs = toMs(slide.timestampSec)
        val endMs = state.slides.getOrNull(idx + 1)?.let { toMs(it.timestampSec) }
            ?: (startMs + state.settings.defaultDurationSec * 1000L)
        tts.stop()
        fxSpeakJob?.cancel()
        clipFx.stop()
        clipPlayer.play(uri, startMs, endMs)
    }

    fun stopOriginalClip() = clipPlayer.stop()

    /**
     * Moves one sentence's start time earlier (negative) or later (positive) by [deltaMs] and replays
     * the current sentence so the change can be heard at once. Moving the START of sentence N+1 is
     * how the END of sentence N is changed, so the Match screen calls this with the next index for that.
     * The script's original timestamp is kept. Returns a message when the move isn't possible, else null.
     */
    fun nudgeTimestamp(index: Int, deltaMs: Long): String? {
        val current = _ui.value.slides.getOrNull(index) ?: return null
        val message = setSlideTimestamp(index, toMs(current.timestampSec) + deltaMs)
        if (message == null) playCurrentOriginal()
        return message
    }

    /** Puts one sentence's start time back to what the script originally said, then replays it. */
    fun restoreOriginalTime(index: Int): String? {
        val original = _ui.value.slides.getOrNull(index)?.originalTimestampSec ?: return null
        val message = setSlideTimestamp(index, toMs(original))
        if (message == null) playCurrentOriginal()
        return message
    }

    /**
     * The one place a single sentence's timestamp is changed by hand. Sentences must stay in time
     * order and at least [AlignmentApplier.MIN_GAP_MS] apart, so the same rule as automatic
     * corrections decides whether the move is allowed. Keeps [SentenceSlide.originalTimestampSec]
     * (and clears it again if the time is moved back to the original), and keeps the alignment
     * results in step so later "apply" actions don't think the script changed underneath them.
     */
    private fun setSlideTimestamp(index: Int, targetMs: Long): String? {
        var message: String? = null
        var changed = false
        _ui.update { state ->
            message = null
            changed = false
            val slides = state.slides
            val slide = slides.getOrNull(index) ?: return@update state
            val cur = LongArray(slides.size) { toMs(slides[it].timestampSec) }
            if (targetMs == cur[index]) return@update state
            val plan = AlignmentApplier.plan(cur, mapOf(index to targetMs))
            if (!plan.accepted.containsKey(index)) {
                message = if (targetMs < 0L) "A sentence can't start before 0:00."
                else "Too close to the neighbouring sentence — they must stay at least 0.1 s apart."
                return@update state
            }
            val originalSec = slide.originalTimestampSec ?: slide.timestampSec
            val backToOriginal = toMs(originalSec) == targetMs
            val list = slides.toMutableList()
            list[index] = slide.copy(
                timestampSec = targetMs / 1000.0,
                originalTimestampSec = if (backToOriginal) null else originalSec
            )
            val oldMs = cur[index]
            val newItems = state.alignment.items.map { item ->
                if (item.index != index || item.currentMs != oldMs) item
                else item.copy(
                    currentMs = targetMs,
                    decision = when {
                        backToOriginal -> AlignmentDecision.KEPT_ORIGINAL
                        item.detectedMs == targetMs -> AlignmentDecision.APPLIED
                        else -> AlignmentDecision.ADJUSTED
                    }
                )
            }
            changed = true
            state.copy(slides = list, alignment = state.alignment.copy(items = newItems))
        }
        if (changed) persistDraft()
        return message
    }

    fun mergeCurrentWithNext() {
        clipPlayer.stop()
        _ui.update { state ->
            val idx = state.curMatchIndex
            if (idx >= state.slides.size - 1) return@update state
            val list = state.slides.toMutableList()
            val combined = listOf(list[idx].text, list[idx + 1].text).filter { it.isNotBlank() }.joinToString(" ")
            list[idx] = list[idx].copy(text = combined)
            list.removeAt(idx + 1)
            state.copy(slides = list)
        }
        persistDraft()
    }

    /** @param cursorOffset character offset within the current sentence where it should be cut. */
    fun splitCurrentSentence(cursorOffset: Int, splitTimeSec: Double): Boolean {
        clipPlayer.stop()
        var applied = false
        _ui.update { state ->
            val idx = state.curMatchIndex
            val slide = state.slides.getOrNull(idx) ?: return@update state
            val next = state.slides.getOrNull(idx + 1)
            val slotStart = slide.timestampSec
            val slotEnd = next?.timestampSec ?: (slotStart + state.settings.defaultDurationSec)
            if (splitTimeSec <= slotStart || splitTimeSec >= slotEnd) return@update state

            val text = slide.text
            val cut = cursorOffset.coerceIn(0, text.length)
            val part1 = text.substring(0, cut).trim()
            val part2 = text.substring(cut).trim()
            if (part1.isBlank() || part2.isBlank()) return@update state

            val list = state.slides.toMutableList()
            list[idx] = slide.copy(text = part1)
            list.add(idx + 1, SentenceSlide(splitTimeSec, part2))
            applied = true
            state.copy(slides = list)
        }
        if (applied) persistDraft()
        return applied
    }

    /** NEW: jump straight to any segment (used by the Match screen's full timeline strip). */
    fun goToMatchIndex(index: Int) {
        _ui.update { it.copy(curMatchIndex = index.coerceIn(0, (it.slides.size - 1).coerceAtLeast(0))) }
    }

    /**
     * NEW: removes the photo at [index] without leaving a dead gap in the timeline. The freed
     * time range is folded into a neighbor, which keeps ITS OWN photo and simply expands to
     * cover the extra time — matching the "remove this photo, let the next one cover this place"
     * workflow. Text from both slides is combined onto the surviving slide (same rule the
     * existing Merge uses), so no narration is silently dropped.
     *
     * Prefers folding forward into the next segment (next's photo expands backward to [index]'s
     * start time). If [index] is the last segment, folds backward into the previous one instead
     * (previous's photo expands forward). If it's the only segment, there's nothing to fold into,
     * so this just clears the assignment.
     */
    fun removePhotoAndCloseGap(index: Int) {
        _ui.update { state ->
            val list = state.slides.toMutableList()
            if (index !in list.indices) return@update state
            when {
                list.size == 1 -> {
                    list[index] = list[index].copy(assignedImageId = null)
                }
                index < list.size - 1 -> {
                    val current = list[index]
                    val next = list[index + 1]
                    val combinedText = listOf(current.text, next.text).filter { it.isNotBlank() }.joinToString(" ")
                    list[index + 1] = next.copy(timestampSec = current.timestampSec, text = combinedText)
                    list.removeAt(index)
                }
                else -> {
                    val current = list[index]
                    val prev = list[index - 1]
                    val combinedText = listOf(prev.text, current.text).filter { it.isNotBlank() }.joinToString(" ")
                    list[index - 1] = prev.copy(text = combinedText)
                    list.removeAt(index)
                }
            }
            state.copy(slides = list, curMatchIndex = state.curMatchIndex.coerceIn(0, (list.size - 1).coerceAtLeast(0)))
        }
        persistDraft()
    }

    // ---------- Step: Text overlays (character names etc.) ----------

    /** Adds a new overlay defaulting to a sensible, always-visible-on-first-add placement: right
     *  at the start of the timeline, for 3 seconds, so it's immediately visible to edit further. */
    fun addTextOverlay(text: String) {
        if (text.isBlank()) return
        val overlay = TextOverlay(
            id = UUID.randomUUID().toString(),
            text = text.trim(),
            startSec = 0.0,
            durationSec = 3.0
        )
        _ui.update { it.copy(textOverlays = it.textOverlays + overlay) }
        persistDraft()
    }

    fun updateTextOverlay(
        id: String,
        text: String? = null,
        startSec: Double? = null,
        durationSec: Double? = null,
        xFraction: Float? = null,
        yFraction: Float? = null,
        style: OverlayStyle? = null
    ) {
        _ui.update { state ->
            state.copy(textOverlays = state.textOverlays.map { ov ->
                if (ov.id != id) return@map ov
                ov.copy(
                    text = text ?: ov.text,
                    startSec = (startSec ?: ov.startSec).coerceAtLeast(0.0),
                    durationSec = (durationSec ?: ov.durationSec).coerceAtLeast(0.2),
                    xFraction = (xFraction ?: ov.xFraction).coerceIn(0.02f, 0.98f),
                    yFraction = (yFraction ?: ov.yFraction).coerceIn(0.05f, 0.95f),
                    style = style ?: ov.style
                )
            })
        }
        persistDraft()
    }

    fun removeTextOverlay(id: String) {
        _ui.update { it.copy(textOverlays = it.textOverlays.filterNot { ov -> ov.id == id }) }
        persistDraft()
    }

    // ---------- Step 4: Preview ----------

    /**
     * Seconds into the timeline. Deliberately NOT part of [ui]: it changes on every screen frame,
     * and when it lived in the shared state every change redrew the whole app (and the zoom could
     * only step 20 times a second). The Preview screen reads this directly and only the pieces
     * that really move are redrawn.
     */
    private val _previewPos = MutableStateFlow(0.0)
    val previewPosition: StateFlow<Double> = _previewPos.asStateFlow()

    private var previewStartJob: Job? = null
    private var previewLastSpokenIndex: Int = -1

    // The preview clock is "a start point + the real time since then". When the original recording
    // is the sound, its own position is checked against that clock and the clock is corrected if
    // they ever drift apart - the sound is the master, the photos follow it.
    private var previewRunning = false
    private var previewAnchorNanos = 0L
    private var previewAnchorSec = 0.0
    private var previewUsingOriginal = false
    private var previewUsingFx = false // the original recording is playing through the voice changer
    private var previewLastAudioPollNanos = 0L
    private var previewTimeline: List<SentenceSlide> = emptyList()
    private var previewTotalSec = 0.0

    // NEW (2.8): playback speed. [previewRunSpeed] is the speed the clock AND the sound are really running
    // at in this playback (fixed when it starts; a change of speed restarts it from the same spot). It can
    // differ from UiState.previewSpeed for a moment, or when a phone refuses a speed and plays a simpler one.
    private var previewRunSpeed = 1f
    // Whether the sound's own position may pull the photos back into line. Always yes for the plain recording
    // player; for the voice-changed recording only at normal speed (see startPreview).
    private var previewTrustAudioClock = false

    fun previewTogglePlay() {
        if (_ui.value.previewPlaying) stopPreview() else startPreview()
    }

    private fun startPreview() {
        val state = _ui.value
        val total = state.totalDurationSec
        if (total <= 0.0) return
        // Pressing play at (or past) the end starts over, like a normal video player would.
        if (_previewPos.value >= total - 0.05) _previewPos.value = 0.0

        val timeline = state.effectiveSlides // built once per playback, not once per frame
        previewTimeline = timeline
        previewTotalSec = total
        // Read once: the sound and the clock below must both use THIS value, even if the speed is changed
        // while the recording is still opening (that change restarts the playback a moment later).
        val speed = state.previewSpeed
        val startSec = _previewPos.value
        // One behind the current slide, so playing (or resuming) speaks the current sentence again.
        previewLastSpokenIndex = state.slideIndexAt(startSec, timeline) - 1

        val narration = state.settings.narration
        val recording = state.alignment.recordingUri
        val wantOriginal = narration.enabled && narration.source == AudioSource.ORIGINAL
        val fx = narration.voiceFx
        val wantFxVoice = narration.enabled && narration.source == AudioSource.VOICE && fx.isActive

        previewStartJob?.cancel()
        fxSpeakJob?.cancel()
        previewRunning = false
        clipPlayer.stop()
        clipFx.stop()
        fxAudio.pause()
        tts.stop()
        _ui.update {
            it.copy(
                previewPlaying = true,
                previewLoadingAudio = (wantOriginal && recording != null) || wantFxVoice,
                previewAudioNote = null
            )
        }

        previewStartJob = viewModelScope.launch {
            var usingOriginal = false
            var usingFx = false
            var note: String? = null
            var runSpeed = speed
            if (wantOriginal) {
                if (recording == null) {
                    note = "No recording chosen yet. Choose it below to hear your original sound."
                } else {
                    // with the voice changer on, the recording is played by our own player (MediaPlayer can't change it)
                    val problem = if (fx.isActive) {
                        fxAudio.playFrom(recording, toMs(startSec), fx, speed = speed)
                    } else {
                        previewAudio.playFrom(recording, toMs(startSec), speed)
                    }
                    if (problem == null) {
                        usingOriginal = true
                        usingFx = fx.isActive
                        // A phone can refuse a speed. The sound then says what it really plays at, and the
                        // photos follow THAT, so picture and sound never separate.
                        runSpeed = if (fx.isActive) fxAudio.appliedSpeed else previewAudio.appliedSpeed
                    } else {
                        note = problem
                    }
                }
            } else if (wantFxVoice) {
                // get the first sentence made and changed before the clock starts, so it is not heard late
                val text = timeline.getOrNull(state.slideIndexAt(startSec, timeline))?.text
                if (!text.isNullOrBlank()) speechFx.get(text, narration.voiceLocaleTag, narration.speechRate, fx)
            }
            if (!_ui.value.previewPlaying) {
                // paused again while the recording was still opening
                previewAudio.pause()
                fxAudio.pause()
                return@launch
            }
            previewUsingOriginal = usingOriginal
            previewUsingFx = usingFx
            previewRunSpeed = runSpeed
            // The plain recording player reports its position in the recording's own time at any speed, so it
            // stays the master clock. The voice-changed player is only trusted at normal speed (as before);
            // when sped up its position is not relied on, and the clock simply runs at the chosen speed.
            previewTrustAudioClock = usingOriginal && (!usingFx || runSpeed == 1f)
            previewAnchorSec = startSec
            previewAnchorNanos = System.nanoTime()
            previewLastAudioPollNanos = previewAnchorNanos
            previewRunning = true
            if (runSpeed != speed) {
                note = "Your phone can't play your recording at ${PreviewSpeed.label(speed)}, " +
                    "so the preview is at ${PreviewSpeed.label(runSpeed)} instead."
            }
            _ui.update {
                it.copy(
                    previewLoadingAudio = false,
                    previewAudioNote = note,
                    previewSpeed = if (runSpeed != speed) runSpeed else it.previewSpeed
                )
            }
        }
    }

    /**
     * Called by the Preview screen once per screen frame while it is playing. Works out where the
     * timeline is right now, speaks the voice when a new slide begins (voice mode only), and
     * stops at the end.
     */
    fun previewFrame() {
        if (!previewRunning) return
        val now = System.nanoTime()
        // the timeline moves [previewRunSpeed] seconds for every real second (1 = normal)
        var pos = previewAnchorSec + (now - previewAnchorNanos) / 1_000_000_000.0 * previewRunSpeed

        if (previewTrustAudioClock && now - previewLastAudioPollNanos >= 100_000_000L) {
            previewLastAudioPollNanos = now
            val audioMs = if (previewUsingFx) fxAudio.positionMs() else previewAudio.positionMs()
            // Trust the sound only once it has really started moving, and only fix a real drift.
            if (audioMs >= 0 && now - previewAnchorNanos >= 500_000_000L) {
                val audioSec = audioMs / 1000.0
                if (abs(audioSec - pos) > PreviewSpeed.driftToleranceSec(previewRunSpeed)) {
                    previewAnchorSec = audioSec
                    previewAnchorNanos = now
                    pos = audioSec
                }
            }
        }

        if (pos >= previewTotalSec) {
            previewRunning = false
            previewAudio.pause()
            fxAudio.pause()
            clipFx.stop()
            tts.stop()
            _previewPos.value = previewTotalSec
            _ui.update { it.copy(previewPlaying = false) }
            return
        }
        _previewPos.value = pos

        val state = _ui.value
        val narration = state.settings.narration
        if (!previewUsingOriginal && narration.enabled) {
            val idx = state.slideIndexAt(pos, previewTimeline)
            if (idx >= 0 && idx != previewLastSpokenIndex) {
                previewLastSpokenIndex = idx
                val text = previewTimeline.getOrNull(idx)?.text
                if (!text.isNullOrBlank()) speakPreviewSentence(text, narration, idx)
            }
        }
    }

    /**
     * Speaks one sentence of the preview. Without the voice changer the phone speaks it live. With it, the
     * sentence is taken from the ready-made (already changed) clips - the next few are made in the
     * background while this one plays - and played from there.
     */
    private fun speakPreviewSentence(text: String, narration: NarrationSettings, index: Int) {
        val fx = narration.voiceFx
        val speed = previewRunSpeed
        if (!fx.isActive) {
            // the phone's voice itself speaks faster / slower (it keeps its natural pitch)
            tts.speak(text, narration.voiceLocaleTag, PreviewSpeed.ttsRate(narration.speechRate, speed))
            return
        }
        val upcoming = previewTimeline.drop(index + 1).take(3).map { it.text }.filter { it.isNotBlank() }
        fxSpeakJob?.cancel()
        clipFx.stop()
        fxSpeakJob = viewModelScope.launch {
            // the ready-made clip is made once at normal speed (and reused); it is played faster / slower
            val pcm = speechFx.get(text, narration.voiceLocaleTag, narration.speechRate, fx)
            if (pcm != null && isActive) {
                val played = clipFx.play(pcm, speed = speed)
                if (played != speed) {
                    _ui.update {
                        it.copy(
                            previewAudioNote = "Your phone can't change the speed of the changed voice, " +
                                "so it is heard at ${PreviewSpeed.label(played)} here."
                        )
                    }
                }
            }
            for (next in upcoming) {
                if (!isActive) break
                speechFx.get(next, narration.voiceLocaleTag, narration.speechRate, fx)
            }
        }
    }

    /**
     * Sets how fast the preview plays (1 = normal; see [PreviewSpeed]). While it is playing, the sound is
     * restarted at the same spot at the new speed once the choice settles (so dragging the slider does not
     * restart it at every step) - the same way the voice-changer sliders work. With no sound there is
     * nothing to restart, so the pictures change speed at once, from where they are.
     */
    fun previewSetSpeed(speed: Float) {
        val s = PreviewSpeed.snap(speed)
        if (s == _ui.value.previewSpeed) return
        _ui.update { it.copy(previewSpeed = s, previewAudioNote = null) }
        if (!_ui.value.previewPlaying) return
        if (previewRunning && !_ui.value.settings.narration.enabled) {
            val now = System.nanoTime()
            previewAnchorSec += (now - previewAnchorNanos) / 1_000_000_000.0 * previewRunSpeed
            previewAnchorNanos = now
            previewRunSpeed = s
        } else {
            restartPreviewSoundSoon()
        }
    }

    fun stopPreview() {
        previewStartJob?.cancel()
        fxSpeakJob?.cancel()
        previewRunning = false
        previewAudio.pause()
        fxAudio.pause()
        clipFx.stop()
        tts.stop() // otherwise a sentence mid-speech keeps talking over a paused/static screen
        _ui.update { it.copy(previewPlaying = false, previewLoadingAudio = false) }
    }

    /** Moves the preview to [sec]. If it was playing it keeps playing from there. */
    private fun previewSeekTo(sec: Double) {
        val wasPlaying = _ui.value.previewPlaying
        stopPreview()
        _previewPos.value = sec.coerceIn(0.0, _ui.value.totalDurationSec)
        if (wasPlaying) startPreview()
    }

    /** For the scrub bar: [fraction] is 0..1 of the whole timeline. */
    fun previewSeekToFraction(fraction: Float) {
        previewSeekTo(fraction.coerceIn(0f, 1f) * _ui.value.totalDurationSec)
    }

    private fun previewSeekToSlide(index: Int) {
        val target = _ui.value.effectiveSlides.getOrNull(index)?.timestampSec ?: 0.0
        previewSeekTo(target)
    }

    fun previewPrev() {
        val state = _ui.value
        previewSeekToSlide((state.slideIndexAt(_previewPos.value) - 1).coerceAtLeast(0))
    }

    fun previewNext() {
        val state = _ui.value
        val maxIndex = (state.effectiveSlides.size - 1).coerceAtLeast(0)
        previewSeekToSlide((state.slideIndexAt(_previewPos.value) + 1).coerceAtMost(maxIndex))
    }

    // ---------- Step 5: Export ----------

    fun startExport() {
        stopPreview()
        val app = getApplication<Application>()
        val state = _ui.value
        // The export runs in its own service, so the recording is passed along with the settings.
        val exportSettings = state.settings.copy(
            narration = state.settings.narration.copy(originalUri = state.alignment.recordingUri)
        )
        val intent = Intent(app, ExportForegroundService::class.java)
        app.startForegroundService(intent)
        app.bindService(intent, object : ServiceConnection {
            override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
                (binder as? ExportForegroundService.LocalBinder)?.service()?.startExport(state.effectiveSlides, state.images, exportSettings, state.textOverlays)
                app.unbindService(this)
            }
            override fun onServiceDisconnected(name: ComponentName?) {}
        }, Context.BIND_AUTO_CREATE)
    }

    fun cancelExport() {
        val app = getApplication<Application>()
        app.bindService(Intent(app, ExportForegroundService::class.java), object : ServiceConnection {
            override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
                (binder as? ExportForegroundService.LocalBinder)?.service()?.cancel()
                app.unbindService(this)
            }
            override fun onServiceDisconnected(name: ComponentName?) {}
        }, Context.BIND_AUTO_CREATE)
    }

    override fun onCleared() {
        clipPlayer.release()
        previewAudio.release()
        fxAudio.release()
        clipFx.stop()
        tts.shutdown()
        super.onCleared()
    }
}
