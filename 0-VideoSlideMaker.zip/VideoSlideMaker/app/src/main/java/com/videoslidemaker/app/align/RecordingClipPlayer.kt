package com.videoslidemaker.app.align

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/** What the "play original" control needs to draw itself. Times are on the recording's own clock. */
data class ClipState(
    val loading: Boolean = false,
    val playing: Boolean = false,
    val positionMs: Long = 0L,
    val startMs: Long = 0L,
    val endMs: Long = 0L,
    val error: String? = null
)

/**
 * Plays ONE stretch of the user's original recording (for example the part that belongs to one
 * sentence) and stops by itself at the end of it. Nothing is cut or copied: the recording is
 * opened once and the player just jumps to the start time, so any timestamp can be heard instantly.
 *
 * Everything here runs on the main thread (pass viewModelScope). Position changes go out through
 * [state], which only the small play control collects, so the rest of the screen isn't redrawn
 * while a clip plays.
 */
class RecordingClipPlayer(
    private val context: Context,
    private val scope: CoroutineScope
) {
    private var player: MediaPlayer? = null
    private var loadedUri: Uri? = null
    private var job: Job? = null

    /** Bumped on every play/stop so a cancelled clip can't undo what a newer one has just done. */
    private var generation = 0

    private val _state = MutableStateFlow(ClipState())
    val state: StateFlow<ClipState> = _state.asStateFlow()

    fun play(uri: Uri, startMs: Long, endMs: Long) {
        job?.cancel()
        pauseQuietly()
        val myGen = ++generation
        _state.value = ClipState(loading = true, startMs = startMs, endMs = endMs, positionMs = startMs)
        job = scope.launch {
            var problem: String? = null
            try {
                val mp = prepared(uri)
                val duration = runCatching { mp.duration.toLong() }.getOrDefault(-1L)
                if (duration > 0 && startMs >= duration) {
                    problem = "This sentence starts after the end of the recording."
                    return@launch
                }
                val end = if (duration > 0) minOf(endMs, duration) else endMs
                if (myGen != generation) return@launch
                seekTo(mp, startMs)
                if (myGen != generation) return@launch
                mp.start()
                _state.value = ClipState(playing = true, startMs = startMs, endMs = end, positionMs = startMs)
                while (isActive && myGen == generation) {
                    val pos = mp.currentPosition.toLong()
                    if (pos >= end || !mp.isPlaying) break
                    _state.value = _state.value.copy(positionMs = pos)
                    delay(40)
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                // the opened player may be in a bad state; drop it so the next try starts fresh
                if (myGen == generation) {
                    runCatching { player?.release() }
                    player = null
                    loadedUri = null
                    problem = "Couldn't play the recording. Choose it again on the Script screen."
                }
            } finally {
                if (myGen == generation) {
                    pauseQuietly()
                    _state.value = ClipState(startMs = startMs, endMs = endMs, error = problem)
                }
            }
        }
    }

    fun stop() {
        generation++
        job?.cancel()
        pauseQuietly()
        _state.value = ClipState()
    }

    /** Frees the media player. Call when the screen's owner goes away, or the recording changes. */
    fun release() {
        generation++
        job?.cancel()
        runCatching { player?.release() }
        player = null
        loadedUri = null
        _state.value = ClipState()
    }

    private fun pauseQuietly() {
        runCatching { player?.takeIf { it.isPlaying }?.pause() }
    }

    /** Opens [uri] once and keeps it ready, so replaying (for example after a nudge) is instant. */
    private suspend fun prepared(uri: Uri): MediaPlayer {
        val existing = player
        if (existing != null && loadedUri == uri) return existing
        runCatching { player?.release() }
        player = null
        loadedUri = null

        val mp = MediaPlayer()
        try {
            mp.setAudioAttributes(
                AudioAttributes.Builder()
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .build()
            )
            mp.setDataSource(context, uri)
            suspendCancellableCoroutine<Unit> { cont ->
                mp.setOnPreparedListener { if (cont.isActive) cont.resume(Unit) }
                mp.setOnErrorListener { _, what, extra ->
                    if (cont.isActive) cont.resumeWithException(IllegalStateException("Media error $what/$extra"))
                    true
                }
                mp.prepareAsync()
            }
            // after preparing, an error just ends the clip; the polling loop notices
            mp.setOnErrorListener { _, _, _ -> true }
        } catch (t: Throwable) {
            runCatching { mp.release() }
            throw t
        }
        player = mp
        loadedUri = uri
        return mp
    }

    /** Jumps to [ms] as exactly as the file allows, and waits until the jump has happened. */
    private suspend fun seekTo(mp: MediaPlayer, ms: Long) {
        withTimeoutOrNull(3000L) {
            suspendCancellableCoroutine<Unit> { cont ->
                mp.setOnSeekCompleteListener { if (cont.isActive) cont.resume(Unit) }
                mp.seekTo(ms, MediaPlayer.SEEK_CLOSEST)
            }
        }
        mp.setOnSeekCompleteListener(null)
    }
}
