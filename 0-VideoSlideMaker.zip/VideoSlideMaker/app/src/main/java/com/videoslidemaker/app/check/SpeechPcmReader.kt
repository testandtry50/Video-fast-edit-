package com.videoslidemaker.app.check

import android.content.Context
import android.media.AudioFormat
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import com.videoslidemaker.app.align.RecordingReadException
import com.videoslidemaker.app.export.StreamingPcmConverter
import java.nio.ByteOrder
import java.util.concurrent.CancellationException

/**
 * Decodes the audio of an audio OR video file (any format this phone can decode) and hands it on as 16 kHz, mono,
 * 16-bit little-endian PCM - what speech recognizers want - in small pieces, so a multi-hour recording never sits in
 * memory.
 *
 * Time is kept exact, the same way [com.videoslidemaker.app.align.RecordingReader] does it: the first sample sits at the
 * audio track's own start time ([PcmInfo.startOffsetMs], reported through `onStart` BEFORE the first piece, so word times
 * can be put on the recording's clock as they arrive), and if the decoder ever skips ahead the gap is filled with silence
 * so everything after it stays on the true clock.
 */
object SpeechPcmReader {

    const val TARGET_RATE = 16_000
    private const val GAP_TOLERANCE_MS = 100L
    private const val TIMEOUT_US = 10_000L

    class PcmInfo(
        /** Recording time of the first sample. */
        val startOffsetMs: Long,
        /** How much audio was handed on. */
        val durationMs: Long
    )

    fun read(
        context: Context,
        uri: Uri,
        onStart: (startOffsetMs: Long) -> Unit,
        onPcm: (pcm: ByteArray, length: Int) -> Unit,
        onProgress: (Int) -> Unit,
        isCancelled: () -> Boolean
    ): PcmInfo {
        val extractor = MediaExtractor()
        var decoder: MediaCodec? = null
        try {
            val pfd = context.contentResolver.openFileDescriptor(uri, "r")
                ?: throw RecordingReadException("Couldn't open the recording.")
            pfd.use { extractor.setDataSource(it.fileDescriptor) }

            var trackIndex = -1
            var format: MediaFormat? = null
            for (i in 0 until extractor.trackCount) {
                val f = extractor.getTrackFormat(i)
                val mime = f.getString(MediaFormat.KEY_MIME) ?: continue
                if (mime.startsWith("audio/")) {
                    trackIndex = i
                    format = f
                    break
                }
            }
            if (trackIndex < 0 || format == null) throw RecordingReadException("That file has no audio track.")
            extractor.selectTrack(trackIndex)
            val mime = format.getString(MediaFormat.KEY_MIME)!!
            val durationUs = if (format.containsKey(MediaFormat.KEY_DURATION)) format.getLong(MediaFormat.KEY_DURATION) else 0L

            val codec = try {
                MediaCodec.createDecoderByType(mime)
            } catch (e: Exception) {
                throw RecordingReadException("This phone can't decode that audio format ($mime).")
            }
            decoder = codec
            codec.configure(format, null, null, 0)
            codec.start()

            val info = MediaCodec.BufferInfo()
            var inputDone = false
            var outputDone = false
            var channels = if (format.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) format.getInteger(MediaFormat.KEY_CHANNEL_COUNT) else 1
            var sampleRate = if (format.containsKey(MediaFormat.KEY_SAMPLE_RATE)) format.getInteger(MediaFormat.KEY_SAMPLE_RATE) else 0
            var floatPcm = false
            var converter: StreamingPcmConverter? = null
            var convertedRate = 0
            var convertedChannels = 0
            var firstPtsUs = -1L
            var startOffsetMs = 0L
            var samplesIn = 0L            // source frames handed to the converter so far (including silence that filled gaps)
            var bytesOut = 0L
            var lastPercent = -1

            fun emit(bytes: ByteArray, length: Int) {
                val conv = converter ?: return
                val out = conv.convert(bytes, length)
                if (out.isNotEmpty()) {
                    bytesOut += out.size
                    onPcm(out, out.size)
                }
            }

            while (!outputDone) {
                if (isCancelled()) throw CancellationException()

                if (!inputDone) {
                    val inIndex = codec.dequeueInputBuffer(TIMEOUT_US)
                    if (inIndex >= 0) {
                        val buffer = codec.getInputBuffer(inIndex)!!
                        val size = extractor.readSampleData(buffer, 0)
                        if (size < 0) {
                            codec.queueInputBuffer(inIndex, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            codec.queueInputBuffer(inIndex, 0, size, extractor.sampleTime, 0)
                            extractor.advance()
                        }
                    }
                }

                val outIndex = codec.dequeueOutputBuffer(info, TIMEOUT_US)
                when {
                    outIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        // The decoder says what it REALLY outputs (some AAC decodes at twice the header's rate): trust it.
                        val out = codec.outputFormat
                        if (out.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) channels = out.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                        if (out.containsKey(MediaFormat.KEY_SAMPLE_RATE)) sampleRate = out.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                        floatPcm = out.containsKey(MediaFormat.KEY_PCM_ENCODING) &&
                            out.getInteger(MediaFormat.KEY_PCM_ENCODING) == AudioFormat.ENCODING_PCM_FLOAT
                        if (converter != null && (convertedRate != sampleRate || convertedChannels != channels)) {
                            throw RecordingReadException("The recording changes sample rate part-way through, which isn't supported.")
                        }
                    }
                    outIndex >= 0 -> {
                        if (info.size > 0) {
                            if (sampleRate <= 0 || channels <= 0) throw RecordingReadException("Couldn't determine the recording's sample rate.")
                            if (converter == null) {
                                converter = StreamingPcmConverter(sampleRate, channels, TARGET_RATE, 1)
                                convertedRate = sampleRate
                                convertedChannels = channels
                                firstPtsUs = info.presentationTimeUs
                                startOffsetMs = if (firstPtsUs > 0L) firstPtsUs / 1000L else 0L
                                onStart(startOffsetMs)
                            }
                            // Fill a gap if the decoder skipped ahead on the true clock.
                            val expectedFrames = (info.presentationTimeUs - firstPtsUs) * sampleRate / 1_000_000L
                            var gap = expectedFrames - samplesIn
                            if (gap * 1000L > GAP_TOLERANCE_MS * sampleRate) {
                                val silence = ByteArray(4096 * 2 * channels)
                                while (gap > 0L) {
                                    val n = minOf(gap, 4096L).toInt()
                                    emit(silence, n * 2 * channels)
                                    samplesIn += n
                                    gap -= n
                                }
                            }

                            val outBuffer = codec.getOutputBuffer(outIndex)!!
                            outBuffer.position(info.offset)
                            outBuffer.limit(info.offset + info.size)
                            outBuffer.order(ByteOrder.nativeOrder())
                            val bytes: ByteArray
                            val frames: Int
                            if (floatPcm) {
                                val fb = outBuffer.asFloatBuffer()
                                val count = fb.remaining()
                                frames = count / channels
                                bytes = ByteArray(frames * channels * 2)
                                var o = 0
                                for (n in 0 until frames * channels) {
                                    val v = Math.round(fb.get() * 32768f).coerceIn(-32768, 32767)
                                    bytes[o++] = (v and 0xFF).toByte()
                                    bytes[o++] = ((v shr 8) and 0xFF).toByte()
                                }
                            } else {
                                bytes = ByteArray(info.size)
                                outBuffer.get(bytes)
                                frames = info.size / (2 * channels)
                            }
                            emit(bytes, frames * 2 * channels)
                            samplesIn += frames
                        }
                        codec.releaseOutputBuffer(outIndex, false)
                        if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outputDone = true

                        if (durationUs > 0L) {
                            val pct = ((info.presentationTimeUs * 100L) / durationUs).toInt().coerceIn(0, 100)
                            if (pct != lastPercent) {
                                lastPercent = pct
                                onProgress(pct)
                            }
                        }
                    }
                }
            }

            if (converter == null) throw RecordingReadException("The recording contains no audio.")
            return PcmInfo(startOffsetMs, bytesOut / 2L * 1000L / TARGET_RATE)
        } finally {
            try {
                decoder?.stop()
            } catch (_: Exception) {
            }
            try {
                decoder?.release()
            } catch (_: Exception) {
            }
            extractor.release()
        }
    }
}
