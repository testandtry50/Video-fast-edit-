package com.videoslidemaker.app.audio

/** Which of the two lanes a clip lives in. */
enum class ClipTrack { MAIN, BACKGROUND }

object AudioLimits {
    /** Nothing shorter than this is kept when cutting (it would only be a click). */
    const val MIN_CLIP_SEC = 0.1
    const val MAX_VOLUME = 2f
    const val MAX_FADE_SEC = 15.0
    /** The automatic fade-out at the very end of the video when "Fade out at the end" is on. */
    const val END_FADE_SEC = 3.0
}

/**
 * NEW (2.17): one piece of sound on the video's timeline - a stretch of an audio (or video) file, placed at a time.
 *
 * Everything is described, nothing is copied: the file itself is never changed. "Cut", "trim" and "split" only change
 * which stretch of the file ([srcStartSec]..[srcEndSec]) is used and where it sits ([startSec]), so every edit can be
 * undone with the normal Undo button, and the project stays small.
 *
 * [uri] is kept as text (not android.net.Uri) so the editing logic can be tested on a plain JVM.
 */
data class AudioClip(
    val id: String,
    val uri: String,
    val name: String,
    /** Length of the whole file. 0 = not measured yet (a project saved by an older version). */
    val sourceDurationSec: Double,
    /** First second of the file that is used. */
    val srcStartSec: Double = 0.0,
    /** End of the used part of the file. 0 together with [sourceDurationSec] = 0 means "the whole file, not measured yet". */
    val srcEndSec: Double = sourceDurationSec,
    /** Where on the video's timeline this clip begins. */
    val startSec: Double = 0.0,
    /** 1 = the file's own loudness; up to [AudioLimits.MAX_VOLUME]. */
    val volume: Float = 1f,
    val fadeInSec: Double = 0.0,
    val fadeOutSec: Double = 0.0,
    val muted: Boolean = false,
    /** Background only: repeat (with a smooth join) until the video ends. */
    val loop: Boolean = false,
    /** Background only: take part in "lower under the voice". */
    val autoDuck: Boolean = true,
    /** Background only: always cover exactly the video's length, however the video changes later (photos added or
     *  removed, timing changed). Too long = cut at the end, too short = repeated. Overrides position, end and repeat. */
    val fitVideo: Boolean = false
) {
    val isUnmeasured: Boolean get() = sourceDurationSec <= 0.0 && srcEndSec <= 0.0

    /** How long the used part is. */
    val lengthSec: Double get() = (srcEndSec - srcStartSec).coerceAtLeast(0.0)

    /** Where the used part ends on the timeline (ignoring looping). */
    val endSec: Double get() = startSec + lengthSec

    /** When this clip stops sounding in a video that is [totalSec] long. */
    fun playsUntil(totalSec: Double): Double = if (loop) totalSec else minOf(endSec, totalSec)

    /** The same clip once the file's real length is known. */
    fun measured(durationSec: Double): AudioClip =
        if (durationSec <= 0.0) this else copy(sourceDurationSec = durationSec, srcStartSec = 0.0, srcEndSec = durationSec)
}

/** The "smart mix" switches: everything here is plain on-device signal processing - free, offline, no account. */
data class SmartMixSettings(
    /** Music gets quieter while someone is speaking and swells back in the gaps. */
    val autoDuck: Boolean = true,
    /** How much quieter the music gets under speech, in dB (negative). */
    val duckDb: Float = -14f,
    /** Sets the music's loudness from the voice's, so it never drowns the speech or disappears. */
    val autoLevel: Boolean = true,
    /** The last seconds of the video fade out. */
    val fadeAtEnd: Boolean = true,
    /** Gently rounds off peaks where voice and music add up, instead of letting them crackle. */
    val limiter: Boolean = true
) {
    companion object {
        const val MIN_DUCK_DB = -30f
        const val MAX_DUCK_DB = -3f

        /** What a project saved before 2.17 (one music file, one volume slider) sounded like: nothing automatic. */
        val ALL_OFF = SmartMixSettings(autoDuck = false, autoLevel = false, fadeAtEnd = false, limiter = false)
    }
}

/** All the sound edits of one project. Part of ExportSettings, so Undo / Redo and saving work with no extra code. */
data class AudioMixSettings(
    /** True = the video's main sound is [main] (your edited audio). False = the voice / recording chosen on the Script step. */
    val useCustomMain: Boolean = false,
    val main: List<AudioClip> = emptyList(),
    val background: List<AudioClip> = emptyList(),
    val smart: SmartMixSettings = SmartMixSettings()
) {
    val activeMain: List<AudioClip> get() = if (useCustomMain) main.filter { !it.muted } else emptyList()
    val activeBackground: List<AudioClip> get() = background.filter { !it.muted }
    val hasAnySound: Boolean get() = activeMain.isNotEmpty() || activeBackground.isNotEmpty()

    fun clip(id: String?): AudioClip? = if (id == null) null else (main.firstOrNull { it.id == id } ?: background.firstOrNull { it.id == id })
    fun trackOf(id: String): ClipTrack? = when {
        main.any { it.id == id } -> ClipTrack.MAIN
        background.any { it.id == id } -> ClipTrack.BACKGROUND
        else -> null
    }

    /** Applies [change] to the clip with [id], wherever it is. */
    fun editClip(id: String, change: (AudioClip) -> AudioClip): AudioMixSettings = copy(
        main = main.map { if (it.id == id) change(it) else it },
        background = background.map { if (it.id == id) change(it) else it }
    )

    fun removeClip(id: String): AudioMixSettings = copy(main = main.filter { it.id != id }, background = background.filter { it.id != id })

    /** A few plain words for the Export screen. */
    fun summary(): String {
        val parts = ArrayList<String>()
        if (useCustomMain) parts.add("${activeMain.size} main clip" + if (activeMain.size == 1) "" else "s")
        if (activeBackground.isNotEmpty()) parts.add("${activeBackground.size} background track" + if (activeBackground.size == 1) "" else "s")
        if (activeBackground.isNotEmpty() && smart.autoDuck) parts.add("auto-lowering under voice")
        return parts.joinToString(", ")
    }
}
