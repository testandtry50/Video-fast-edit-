package com.videoslidemaker.app.audio

/** Which of the two lanes a clip lives in. */
enum class ClipTrack { MAIN, BACKGROUND }

object AudioLimits {
    /** Nothing shorter than this is kept when cutting (it would only be a click). */
    const val MIN_CLIP_SEC = 0.1
    const val MAX_VOLUME = 2f
    const val MAX_FADE_SEC = 15.0
    /** The automatic fade-out at the very end of the video when "Fade out at the end" is on. */
    const val END_FADE_SEC = 3.0
    /** NEW (2.19): a marked part this short or shorter is treated as a beat: it repeats exactly, with no blended join. */
    const val EXACT_LOOP_AUTO_MAX_SEC = 8.0
    /** NEW (2.19): the tiny fade at each join of an exactly repeating sound, so a cut mid-wave never clicks. */
    const val DECLICK_SEC = 0.003
}

/**
 * NEW (2.17): one piece of sound on the video's timeline - a stretch of an audio (or video) file, placed at a time.
 *
 * Everything is described, nothing is copied: the file itself is never changed. "Cut", "trim" and "split" only change
 * which stretch of the file ([srcStartSec]..[srcEndSec]) is used and where it sits ([startSec]), so every edit can be
 * undone with the normal Undo button, and the project stays small.
 *
 * [uri] is kept as text (not android.net.Uri) so the editing logic can be tested on a plain JVM.
 */
data class AudioClip(
    val id: String,
    val uri: String,
    val name: String,
    /** Length of the whole file. 0 = not measured yet (a project saved by an older version). */
    val sourceDurationSec: Double,
    /** First second of the file that is used. */
    val srcStartSec: Double = 0.0,
    /** End of the used part of the file. 0 together with [sourceDurationSec] = 0 means "the whole file, not measured yet". */
    val srcEndSec: Double = sourceDurationSec,
    /** Where on the video's timeline this clip begins. */
    val startSec: Double = 0.0,
    /** 1 = the file's own loudness; up to [AudioLimits.MAX_VOLUME]. */
    val volume: Float = 1f,
    val fadeInSec: Double = 0.0,
    val fadeOutSec: Double = 0.0,
    val muted: Boolean = false,
    /** Background only: repeat (with a smooth join) until the video ends. */
    val loop: Boolean = false,
    /** Background only: take part in "lower under the voice". */
    val autoDuck: Boolean = true,
    /** Background only: always cover exactly the video's length, however the video changes later (photos added or
     *  removed, timing changed). Too long = cut at the end, too short = repeated. Overrides position, end and repeat. */
    val fitVideo: Boolean = false,
    /** NEW (2.18): the short unique name of a background-audio SLOT made by pressing and holding a scene on the Match step
     *  ("B1", "B2", ...). Empty for every ordinary clip. A slot exists from the moment it is made - even before any audio
     *  file is chosen for it ([uri] is empty then) - and keeps its name when a file is chosen later. */
    val slot: String = "",
    /** NEW (2.18): where the slot ends on the video's timeline. When this is later than [startSec] the clip is tied to the
     *  time range [startSec]..[rangeEndSec] and is fitted to it exactly: a longer file is cut, a shorter one is repeated.
     *  0 = no end chosen yet. */
    val rangeEndSec: Double = 0.0,
    /** NEW (2.19): what kind of sound this is (music, ambience, a sound effect...). [SoundKind.UNSET] until the user says. */
    val kind: SoundKind = SoundKind.UNSET,
    /** NEW (2.19): the feeling of music (action, dramatic, emotional...). Only music-like kinds use it. */
    val mood: SoundMood = SoundMood.NONE,
    /** NEW (2.19): the end of the MARKED part of the original file (the beat, the voice, the one sound that was wanted).
     *  The marked part is [srcStartSec]..[markEndSec]. When a clip is fitted to the video or to a scene, ONLY this part is
     *  cut or repeated - not the rest of the file. 0 = nothing marked: the whole file (from [srcStartSec]) is the material. */
    val markEndSec: Double = 0.0,
    /** NEW (2.19): added to the smart mix's "lower under the voice" depth for this sound, in dB. Negative = lowers more,
     *  positive = lowers less (rain under a voice should hardly pump; a sung track should step well aside). 0 = as set. */
    val duckAdjustDb: Double = 0.0,
    /** NEW (2.19): how far below the voice this sound's loudness is matched, in dB (e.g. -12). null = the standard distance
     *  of the smart mix. Set by [SoundProfiles] from the kind and mood. Only used while "match loudness" is on. */
    val levelDb: Double? = null,
    /** NEW (2.19): in a time range or "fit the video": a sound shorter than the space plays ONCE (a door, a whoosh) instead of
     *  being repeated until the space is full. */
    val playOnce: Boolean = false,
    /** NEW (2.19): a repeating sound repeats EXACTLY - same length every round, no blending of the join - which keeps a
     *  beat's rhythm. A few thousandths of a second at each join are smoothed so it never clicks. */
    val exactLoop: Boolean = false
) {
    val isUnmeasured: Boolean get() = sourceDurationSec <= 0.0 && srcEndSec <= 0.0

    /** NEW (2.19): true when a part of the original has been marked (see [markEndSec]). */
    val hasMark: Boolean get() = markEndSec > srcStartSec + AudioLimits.MIN_CLIP_SEC

    /** NEW (2.19): the end of the file's usable material: the marked end when a part is marked, else the end of the file. */
    val materialEndSec: Double
        get() {
            val fileEnd = if (sourceDurationSec > 0.0) sourceDurationSec else srcEndSec
            return if (hasMark) minOf(markEndSec, fileEnd).coerceAtLeast(srcStartSec) else fileEnd
        }

    /** NEW (2.19): true when only a part of the original file is used (a start was cut off or the end is marked). */
    val usesPartOfFile: Boolean
        get() {
            val fileEnd = if (sourceDurationSec > 0.0) sourceDurationSec else srcEndSec
            return srcStartSec > 0.05 || fileEnd - materialEndSec > 0.05
        }

    /** NEW (2.18): a slot that has no audio file yet. It is shown and saved but makes no sound. */
    val isPlaceholder: Boolean get() = uri.isBlank()

    /** NEW (2.18): true when an end time has been chosen, so the clip is tied to [startSec]..[rangeEndSec]. */
    val hasRange: Boolean get() = rangeEndSec > startSec + AudioLimits.MIN_CLIP_SEC

    /** How long the used part is. */
    val lengthSec: Double get() = (srcEndSec - srcStartSec).coerceAtLeast(0.0)

    /** Where the used part ends on the timeline (ignoring looping). */
    val endSec: Double get() = startSec + lengthSec

    /** Where a repeating clip must stop in a video of [totalSec]: its chosen end, or (with none) the end of the video. */
    fun stopsAt(totalSec: Double): Double = if (!fitVideo && hasRange) minOf(rangeEndSec, totalSec) else totalSec

    /** When this clip stops sounding in a video that is [totalSec] long. */
    fun playsUntil(totalSec: Double): Double = if (loop) stopsAt(totalSec) else minOf(endSec, totalSec)

    /** The same clip once the file's real length is known. */
    fun measured(durationSec: Double): AudioClip =
        if (durationSec <= 0.0) this else copy(sourceDurationSec = durationSec, srcStartSec = 0.0, srcEndSec = durationSec)
}

/** The "smart mix" switches: everything here is plain on-device signal processing - free, offline, no account. */
data class SmartMixSettings(
    /** Music gets quieter while someone is speaking and swells back in the gaps. */
    val autoDuck: Boolean = true,
    /** How much quieter the music gets under speech, in dB (negative). */
    val duckDb: Float = -14f,
    /** Sets the music's loudness from the voice's, so it never drowns the speech or disappears. */
    val autoLevel: Boolean = true,
    /** The last seconds of the video fade out. */
    val fadeAtEnd: Boolean = true,
    /** Gently rounds off peaks where voice and music add up, instead of letting them crackle. */
    val limiter: Boolean = true
) {
    companion object {
        const val MIN_DUCK_DB = -30f
        const val MAX_DUCK_DB = -3f

        /** What a project saved before 2.17 (one music file, one volume slider) sounded like: nothing automatic. */
        val ALL_OFF = SmartMixSettings(autoDuck = false, autoLevel = false, fadeAtEnd = false, limiter = false)
    }
}

/** All the sound edits of one project. Part of ExportSettings, so Undo / Redo and saving work with no extra code. */
data class AudioMixSettings(
    /** True = the video's main sound is [main] (your edited audio). False = the voice / recording chosen on the Script step. */
    val useCustomMain: Boolean = false,
    val main: List<AudioClip> = emptyList(),
    val background: List<AudioClip> = emptyList(),
    val smart: SmartMixSettings = SmartMixSettings()
) {
    val activeMain: List<AudioClip> get() = if (useCustomMain) main.filter { !it.muted } else emptyList()
    /** The background tracks that make sound: not muted, and (NEW 2.18) not an empty slot still waiting for its audio file. */
    val activeBackground: List<AudioClip> get() = background.filter { !it.muted && !it.isPlaceholder }
    val hasAnySound: Boolean get() = activeMain.isNotEmpty() || activeBackground.isNotEmpty()

    fun clip(id: String?): AudioClip? = if (id == null) null else (main.firstOrNull { it.id == id } ?: background.firstOrNull { it.id == id })
    fun trackOf(id: String): ClipTrack? = when {
        main.any { it.id == id } -> ClipTrack.MAIN
        background.any { it.id == id } -> ClipTrack.BACKGROUND
        else -> null
    }

    /** Applies [change] to the clip with [id], wherever it is. */
    fun editClip(id: String, change: (AudioClip) -> AudioClip): AudioMixSettings = copy(
        main = main.map { if (it.id == id) change(it) else it },
        background = background.map { if (it.id == id) change(it) else it }
    )

    fun removeClip(id: String): AudioMixSettings = copy(main = main.filter { it.id != id }, background = background.filter { it.id != id })

    /** A few plain words for the Export screen. */
    fun summary(): String {
        val parts = ArrayList<String>()
        if (useCustomMain) parts.add("${activeMain.size} main clip" + if (activeMain.size == 1) "" else "s")
        if (activeBackground.isNotEmpty()) parts.add("${activeBackground.size} background track" + if (activeBackground.size == 1) "" else "s")
        if (activeBackground.isNotEmpty() && smart.autoDuck) parts.add("auto-lowering under voice")
        val empty = background.count { it.isPlaceholder && !it.muted }
        if (empty > 0) parts.add("$empty empty background slot" + (if (empty == 1) "" else "s") + " (silent until you choose a file)")
        return parts.joinToString(", ")
    }
}
