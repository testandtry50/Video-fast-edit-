package com.videoslidemaker.app.align

/**
 * Decides which timestamp changes can be made without breaking the timeline.
 *
 * The rest of the app (preview, export, the Match screen) relies on slides being in strictly
 * increasing time order, so a correction that would make a line start at or before its
 * neighbour — or leave it less than [MIN_GAP_MS] away — is refused rather than silently
 * reordering or squashing lines. Refused lines keep whatever timestamp they have.
 */
object AlignmentApplier {

    const val MIN_GAP_MS = 100L

    class Plan(
        /** slide index → new timestamp (ms), only the changes that are safe to make */
        val accepted: Map<Int, Long>,
        /** slide indices whose change was refused because it would collide with a neighbour */
        val rejected: List<Int>
    )

    /**
     * @param currentMs the slides' timestamps right now, in slide order.
     * @param wanted    the changes asked for: slide index → new timestamp.
     */
    fun plan(currentMs: LongArray, wanted: Map<Int, Long>): Plan {
        val accepted = LinkedHashMap<Int, Long>()
        for ((idx, ms) in wanted) {
            if (idx in currentMs.indices && ms >= 0L && ms != currentMs[idx]) accepted[idx] = ms
        }
        val rejected = ArrayList<Int>()
        var changed = true
        while (changed) {
            changed = false
            for (idx in accepted.keys.sorted()) {
                val v = accepted[idx] ?: continue
                val prev: Long? = if (idx > 0) (accepted[idx - 1] ?: currentMs[idx - 1]) else null
                val next: Long? = if (idx < currentMs.size - 1) (accepted[idx + 1] ?: currentMs[idx + 1]) else null
                val collides = (prev != null && v - prev < MIN_GAP_MS) || (next != null && next - v < MIN_GAP_MS)
                if (collides) {
                    accepted.remove(idx)
                    rejected.add(idx)
                    changed = true
                }
            }
        }
        return Plan(accepted, rejected)
    }
}
