package com.videoslidemaker.app.ui.theme

import android.content.Context
import androidx.compose.runtime.Immutable
import androidx.compose.ui.graphics.Color
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Which look the app uses. SYSTEM follows the phone's own light/dark setting. */
enum class ThemeMode(val label: String) {
    SYSTEM("System"),
    LIGHT("Light"),
    DARK("Dark")
}

/**
 * The seven base colours of one background style. Everything else (accent, status colours, text on buttons) is worked
 * out from these in buildAppColors, and nudged where needed so it stays readable on them.
 *
 *  bg       the page   surface  bars / inset areas   card  raised cards   border  quiet dividers
 *  outline  the edge of anything tappable   textMain / muted  normal and softer text
 */
@Immutable
class StylePalette(
    val bg: Color,
    val surface: Color,
    val card: Color,
    val border: Color,
    val outline: Color,
    val textMain: Color,
    val muted: Color
)

/** The look used while dark mode is on. CHARCOAL is the original; BLACK is the old "pure black" switch. */
enum class DarkStyle(val label: String, val palette: StylePalette) {
    CHARCOAL("Charcoal", StylePalette(Color(0xFF131313), Color(0xFF1B1B1B), Color(0xFF222222), Color(0xFF303030), Color(0xFF7E7E7E), Color(0xFFE6E6E6), Color(0xFFA9A9A9))),
    BLACK("Pure black", StylePalette(Color(0xFF000000), Color(0xFF0C0C0C), Color(0xFF171717), Color(0xFF2A2A2A), Color(0xFF7E7E7E), Color(0xFFE6E6E6), Color(0xFFA9A9A9))),
    SLATE("Slate", StylePalette(Color(0xFF1C2128), Color(0xFF222830), Color(0xFF2B323B), Color(0xFF414A56), Color(0xFF8793A1), Color(0xFFD8DEE6), Color(0xFFA3AEBB))),
    MIDNIGHT("Midnight", StylePalette(Color(0xFF0B1220), Color(0xFF111A2C), Color(0xFF17233A), Color(0xFF26354F), Color(0xFF7C8CA8), Color(0xFFE4EAF5), Color(0xFFA3AEC4))),
    FOREST("Forest", StylePalette(Color(0xFF0E1511), Color(0xFF141E18), Color(0xFF1A2620), Color(0xFF2B3B32), Color(0xFF7F9686), Color(0xFFE3EBE5), Color(0xFFA2B3A8))),
    MOCHA("Mocha", StylePalette(Color(0xFF17120E), Color(0xFF1F1914), Color(0xFF282019), Color(0xFF3A3027), Color(0xFF9A8878), Color(0xFFEFE6DC), Color(0xFFB5A596))),
    PLUM("Plum", StylePalette(Color(0xFF150F1A), Color(0xFF1D1624), Color(0xFF261C2E), Color(0xFF372A42), Color(0xFF9684A6), Color(0xFFEEE6F3), Color(0xFFB3A5C0)))
}

/** The look used while light mode is on. PAPER is the original. */
enum class LightStyle(val label: String, val palette: StylePalette) {
    PAPER("Paper", StylePalette(Color(0xFFF4F2EE), Color(0xFFEBE8E2), Color(0xFFFBFAF8), Color(0xFFDDD9D1), Color(0xFF7D7A74), Color(0xFF2B2D31), Color(0xFF5B5E64))),
    SNOW("Snow", StylePalette(Color(0xFFF2F5F9), Color(0xFFE7ECF2), Color(0xFFFAFBFD), Color(0xFFD5DCE6), Color(0xFF70798A), Color(0xFF1F2733), Color(0xFF566072))),
    SEPIA("Sepia", StylePalette(Color(0xFFF3EAD7), Color(0xFFE9DEC6), Color(0xFFFBF5E7), Color(0xFFD8CBAE), Color(0xFF7D705A), Color(0xFF3A3123), Color(0xFF61563F))),
    MINT("Mint", StylePalette(Color(0xFFEEF4EF), Color(0xFFE1ECE4), Color(0xFFF8FBF8), Color(0xFFCFE0D4), Color(0xFF6B8274), Color(0xFF1E2B23), Color(0xFF4F6257))),
    BLUSH("Blush", StylePalette(Color(0xFFF7EFF1), Color(0xFFEFE3E7), Color(0xFFFDF9FA), Color(0xFFE3D2D8), Color(0xFF87707A), Color(0xFF2E2327), Color(0xFF66535B))),
    LAVENDER("Lavender", StylePalette(Color(0xFFF2F0F8), Color(0xFFE8E4F2), Color(0xFFFBFAFE), Color(0xFFD8D2E8), Color(0xFF7A7290), Color(0xFF25212F), Color(0xFF5A546B)))
}

/**
 * Accent colour presets (buttons, selected items, highlights). Each has two tones: a lighter one that reads well on
 * dark backgrounds and a deeper one for light backgrounds. buildAppColors nudges a tone if a particular background
 * style would make it hard to read, so every accent works on every style (ThemeContrastTest checks all of them).
 * CUSTOM takes its colour from a hue slider instead - see [accentTone].
 */
enum class AccentChoice(val label: String, val darkTone: Color, val lightTone: Color) {
    RED("Red", Color(0xFFF28B82), Color(0xFFB3261E)),
    CORAL("Coral", Color(0xFFFF9E80), Color(0xFFB23A12)),
    ORANGE("Orange", Color(0xFFF5A964), Color(0xFF8F4A0A)),
    AMBER("Amber", Color(0xFFFFCA5C), Color(0xFF8A5B00)),
    YELLOW("Yellow", Color(0xFFF2E266), Color(0xFF746200)),
    LIME("Lime", Color(0xFFBDE05A), Color(0xFF4F6B00)),
    LEAF("Leaf", Color(0xFF8FDB6B), Color(0xFF2F7A1C)),
    SAGE("Green", Color(0xFF86D39B), Color(0xFF2C6B3F)),
    EMERALD("Emerald", Color(0xFF4FD6A0), Color(0xFF0B6B45)),
    TEAL("Teal", Color(0xFF55CFC0), Color(0xFF0B6B63)),
    CYAN("Cyan", Color(0xFF5FD3E8), Color(0xFF0A6678)),
    SKY("Sky", Color(0xFF7CC4FA), Color(0xFF1566A0)),
    BLUE("Blue", Color(0xFF86B4F2), Color(0xFF2459A6)),
    INDIGO("Indigo", Color(0xFF9FA8F5), Color(0xFF3F46A8)),
    VIOLET("Violet", Color(0xFFB8A0F7), Color(0xFF5B3FB8)),
    PURPLE("Purple", Color(0xFFD6A0F2), Color(0xFF8A2FAE)),
    MAGENTA("Magenta", Color(0xFFF395E6), Color(0xFFA6208F)),
    ROSE("Rose", Color(0xFFF29AB8), Color(0xFFA8325E)),
    BROWN("Brown", Color(0xFFD2A98A), Color(0xFF7A4A2B)),
    SLATE("Slate", Color(0xFFA7B4C4), Color(0xFF4A5A6E)),
    /** The tones here are only placeholders; the real colour comes from [AppearancePrefs.customHue]. */
    CUSTOM("Custom", Color(0xFF86B4F2), Color(0xFF2459A6))
}

/** Extra text scaling that is applied ON TOP of the phone's own font-size setting. */
enum class TextSizeChoice(val label: String, val scale: Float) {
    SMALL("Small", 0.87f),
    DEFAULT("Default", 1.0f),
    LARGE("Large", 1.15f),
    LARGER("Larger", 1.3f),
    LARGEST("Largest", 1.5f)
}

/** Where the Photos / Match / Voice... step bar sits. BOTTOM is easier to reach with one hand. */
enum class NavPosition(val label: String) {
    TOP("Top"),
    BOTTOM("Bottom")
}

/** How much room cards, buttons and headers get. Buttons stay at least 48 dp tall in every choice. */
enum class SpacingChoice(val label: String) {
    COMPACT("Compact"),
    COMFORTABLE("Comfortable"),
    ROOMY("Roomy")
}

/** How round the corners of cards, buttons and chips are. */
enum class CornerChoice(val label: String) {
    ROUNDED("Round"),
    SOFT("Soft"),
    SQUARE("Square")
}

/** Ready-made layout combinations; picking one sets the three layout choices at once. */
enum class LayoutPreset(
    val label: String,
    val hint: String,
    val navigation: NavPosition,
    val spacing: SpacingChoice,
    val corners: CornerChoice
) {
    CLASSIC("Classic", "Steps on top, round cards", NavPosition.TOP, SpacingChoice.COMFORTABLE, CornerChoice.ROUNDED),
    COMPACT("Compact", "Fits more on the screen", NavPosition.TOP, SpacingChoice.COMPACT, CornerChoice.SOFT),
    ONE_HAND("One-hand", "Steps at the bottom, roomy", NavPosition.BOTTOM, SpacingChoice.ROOMY, CornerChoice.ROUNDED),
    SHARP("Sharp", "Square corners, clean lines", NavPosition.TOP, SpacingChoice.COMFORTABLE, CornerChoice.SQUARE)
}

@Immutable
data class AppearancePrefs(
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    /** The look used while dark mode is showing. */
    val darkStyle: DarkStyle = DarkStyle.CHARCOAL,
    /** The look used while light mode is showing. */
    val lightStyle: LightStyle = LightStyle.PAPER,
    val accent: AccentChoice = AccentChoice.BLUE,
    /** 0..359; only used while [accent] is CUSTOM. */
    val customHue: Int = 210,
    val textSize: TextSizeChoice = TextSizeChoice.DEFAULT,
    val highContrast: Boolean = false,
    val navigation: NavPosition = NavPosition.TOP,
    val spacing: SpacingChoice = SpacingChoice.COMFORTABLE,
    val corners: CornerChoice = CornerChoice.ROUNDED
)

/** Whether the dark palette should be used for [prefs], given the phone's own setting. */
fun AppearancePrefs.resolveDark(systemDark: Boolean): Boolean = when (themeMode) {
    ThemeMode.SYSTEM -> systemDark
    ThemeMode.LIGHT -> false
    ThemeMode.DARK -> true
}

/** The layout preset these prefs match exactly, or null when the three layout choices were set one by one. */
fun AppearancePrefs.matchingPreset(): LayoutPreset? =
    LayoutPreset.entries.firstOrNull { it.navigation == navigation && it.spacing == spacing && it.corners == corners }

fun AppearancePrefs.withPreset(preset: LayoutPreset): AppearancePrefs =
    copy(navigation = preset.navigation, spacing = preset.spacing, corners = preset.corners)

/** The accent colour to start from for this look (before buildAppColors makes sure it is readable). */
fun AppearancePrefs.accentTone(dark: Boolean): Color =
    if (accent == AccentChoice.CUSTOM) customAccentTone(customHue, dark)
    else if (dark) accent.darkTone else accent.lightTone

/** Any hue on the colour wheel as a light tone (for dark backgrounds) or a deep tone (for light backgrounds). */
fun customAccentTone(hue: Int, dark: Boolean): Color =
    if (dark) hslColor(hue.toDouble(), 0.78, 0.68) else hslColor(hue.toDouble(), 0.70, 0.34)

/**
 * Older versions had one "pure black" switch instead of dark styles. If no dark style has been saved yet, that switch
 * decides: on means the BLACK style, off means CHARCOAL. A saved style always wins.
 */
fun parseDarkStyle(savedName: String?, legacyPureBlack: Boolean): DarkStyle =
    DarkStyle.entries.firstOrNull { it.name == savedName }
        ?: if (legacyPureBlack) DarkStyle.BLACK else DarkStyle.CHARCOAL

/**
 * Remembers the person's appearance choices between launches. Kept separate from the project
 * draft on purpose: a theme or text-size choice belongs to the person, not to one video project.
 */
class AppearanceStore(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences(FILE_NAME, Context.MODE_PRIVATE)

    private val _state = MutableStateFlow(read())
    val state: StateFlow<AppearancePrefs> = _state.asStateFlow()

    fun update(transform: (AppearancePrefs) -> AppearancePrefs) {
        val next = transform(_state.value)
        _state.value = next
        prefs.edit()
            .putString(KEY_THEME, next.themeMode.name)
            .putString(KEY_DARK_STYLE, next.darkStyle.name)
            .putString(KEY_LIGHT_STYLE, next.lightStyle.name)
            .putString(KEY_ACCENT, next.accent.name)
            .putInt(KEY_CUSTOM_HUE, next.customHue)
            .putString(KEY_TEXT_SIZE, next.textSize.name)
            .putBoolean(KEY_HIGH_CONTRAST, next.highContrast)
            .putString(KEY_NAVIGATION, next.navigation.name)
            .putString(KEY_SPACING, next.spacing.name)
            .putString(KEY_CORNERS, next.corners.name)
            .apply()
    }

    private fun read(): AppearancePrefs = AppearancePrefs(
        themeMode = enumOrDefault(prefs.getString(KEY_THEME, null), ThemeMode.SYSTEM),
        darkStyle = parseDarkStyle(prefs.getString(KEY_DARK_STYLE, null), prefs.getBoolean(KEY_PURE_BLACK, false)),
        lightStyle = enumOrDefault(prefs.getString(KEY_LIGHT_STYLE, null), LightStyle.PAPER),
        accent = enumOrDefault(prefs.getString(KEY_ACCENT, null), AccentChoice.BLUE),
        customHue = prefs.getInt(KEY_CUSTOM_HUE, 210).coerceIn(0, 359),
        textSize = enumOrDefault(prefs.getString(KEY_TEXT_SIZE, null), TextSizeChoice.DEFAULT),
        highContrast = prefs.getBoolean(KEY_HIGH_CONTRAST, false),
        navigation = enumOrDefault(prefs.getString(KEY_NAVIGATION, null), NavPosition.TOP),
        spacing = enumOrDefault(prefs.getString(KEY_SPACING, null), SpacingChoice.COMFORTABLE),
        corners = enumOrDefault(prefs.getString(KEY_CORNERS, null), CornerChoice.ROUNDED)
    )

    private companion object {
        const val FILE_NAME = "appearance_prefs"
        const val KEY_THEME = "theme_mode"
        const val KEY_PURE_BLACK = "pure_black"      // read once to carry an old choice over; no longer written
        const val KEY_DARK_STYLE = "dark_style"
        const val KEY_LIGHT_STYLE = "light_style"
        const val KEY_ACCENT = "accent"
        const val KEY_CUSTOM_HUE = "custom_hue"
        const val KEY_TEXT_SIZE = "text_size"
        const val KEY_HIGH_CONTRAST = "high_contrast"
        const val KEY_NAVIGATION = "navigation"
        const val KEY_SPACING = "spacing"
        const val KEY_CORNERS = "corners"
    }
}

private inline fun <reified T : Enum<T>> enumOrDefault(name: String?, default: T): T =
    enumValues<T>().firstOrNull { it.name == name } ?: default
