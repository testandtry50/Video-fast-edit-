package com.videoslidemaker.app.ui.theme

import android.content.Context
import androidx.compose.ui.graphics.Color
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Which look the app uses. SYSTEM follows the phone's own light/dark setting. */
enum class ThemeMode(val label: String) {
    SYSTEM("System"),
    LIGHT("Light"),
    DARK("Dark")
}

/**
 * Accent colour presets. Each one has two tones: a lighter tone that reads well on dark
 * backgrounds and a deeper tone that reads well on light backgrounds. Every combination is
 * checked against WCAG contrast ratios in ThemeContrastTest.
 */
enum class AccentChoice(val label: String, val darkTone: Color, val lightTone: Color) {
    BLUE("Blue", Color(0xFF86B4F2), Color(0xFF2459A6)),
    TEAL("Teal", Color(0xFF55CFC0), Color(0xFF0B6B63)),
    SAGE("Green", Color(0xFF86D39B), Color(0xFF2C6B3F)),
    ORANGE("Orange", Color(0xFFF5A964), Color(0xFF8F4A0A)),
    ROSE("Rose", Color(0xFFF29AB8), Color(0xFFA8325E))
}

/** Extra text scaling that is applied ON TOP of the phone's own font-size setting. */
enum class TextSizeChoice(val label: String, val scale: Float) {
    DEFAULT("Default", 1.0f),
    LARGE("Large", 1.15f),
    LARGER("Larger", 1.3f),
    LARGEST("Largest", 1.5f)
}

data class AppearancePrefs(
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    /** Only has an effect while the dark theme is showing. */
    val pureBlack: Boolean = false,
    val accent: AccentChoice = AccentChoice.BLUE,
    val textSize: TextSizeChoice = TextSizeChoice.DEFAULT,
    val highContrast: Boolean = false
)

/** Whether the dark palette should be used for [prefs], given the phone's own setting. */
fun AppearancePrefs.resolveDark(systemDark: Boolean): Boolean = when (themeMode) {
    ThemeMode.SYSTEM -> systemDark
    ThemeMode.LIGHT -> false
    ThemeMode.DARK -> true
}

/**
 * Remembers the person's appearance choices between launches. Kept separate from the project
 * draft on purpose: a theme or text-size choice belongs to the person, not to one video project.
 */
class AppearanceStore(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences(FILE_NAME, Context.MODE_PRIVATE)

    private val _state = MutableStateFlow(read())
    val state: StateFlow<AppearancePrefs> = _state.asStateFlow()

    fun update(transform: (AppearancePrefs) -> AppearancePrefs) {
        val next = transform(_state.value)
        _state.value = next
        prefs.edit()
            .putString(KEY_THEME, next.themeMode.name)
            .putBoolean(KEY_PURE_BLACK, next.pureBlack)
            .putString(KEY_ACCENT, next.accent.name)
            .putString(KEY_TEXT_SIZE, next.textSize.name)
            .putBoolean(KEY_HIGH_CONTRAST, next.highContrast)
            .apply()
    }

    private fun read(): AppearancePrefs = AppearancePrefs(
        themeMode = enumOrDefault(prefs.getString(KEY_THEME, null), ThemeMode.SYSTEM),
        pureBlack = prefs.getBoolean(KEY_PURE_BLACK, false),
        accent = enumOrDefault(prefs.getString(KEY_ACCENT, null), AccentChoice.BLUE),
        textSize = enumOrDefault(prefs.getString(KEY_TEXT_SIZE, null), TextSizeChoice.DEFAULT),
        highContrast = prefs.getBoolean(KEY_HIGH_CONTRAST, false)
    )

    private companion object {
        const val FILE_NAME = "appearance_prefs"
        const val KEY_THEME = "theme_mode"
        const val KEY_PURE_BLACK = "pure_black"
        const val KEY_ACCENT = "accent"
        const val KEY_TEXT_SIZE = "text_size"
        const val KEY_HIGH_CONTRAST = "high_contrast"
    }
}

private inline fun <reified T : Enum<T>> enumOrDefault(name: String?, default: T): T =
    enumValues<T>().firstOrNull { it.name == name } ?: default
