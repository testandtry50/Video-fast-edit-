package com.videoslidemaker.app

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import com.videoslidemaker.app.ui.theme.AppearanceStore

class VideoSlideMakerApp : Application() {
    /** The person's theme / text-size / contrast choices. One instance for the whole app. */
    lateinit var appearance: AppearanceStore
        private set

    override fun onCreate() {
        super.onCreate()
        appearance = AppearanceStore(this)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                EXPORT_CHANNEL_ID,
                "Video export",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Shows progress while your video is being created"
            }
            getSystemService(NotificationManager::class.java)?.createNotificationChannel(channel)

            val cleanChannel = NotificationChannel(
                LOGO_CLEAN_CHANNEL_ID,
                "Logo cleaning",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Shows progress while logos are removed or blurred in many photos"
            }
            getSystemService(NotificationManager::class.java)?.createNotificationChannel(cleanChannel)
        }
    }

    companion object {
        const val EXPORT_CHANNEL_ID = "export_channel"
        const val LOGO_CLEAN_CHANNEL_ID = "logo_clean_channel"
    }
}
