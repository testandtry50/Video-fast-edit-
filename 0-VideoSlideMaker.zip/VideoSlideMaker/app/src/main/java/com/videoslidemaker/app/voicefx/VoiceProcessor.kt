package com.videoslidemaker.app.voicefx

import kotlin.math.min

/**
 * The whole voice changer for one stream of sound: pitch -> humanize -> effect -> soft limiter.
 * Mono in, stereo out, one sample at a time. A new instance starts from silence, so use one
 * per recording (or per spoken sentence).
 *
 * The pitch shifter and the humanizer each delay the sound a little; [latencyFrames] is the total,
 * and [VoiceFxPcmStream] removes it so the processed sound lines up exactly with the original.
 */
class VoiceProcessor(private val fs: Int, settings: VoiceFxSettings, seed: Int = 0) {
    private val pitch: PitchShifter? =
        if (settings.pitchActive) PitchShifter(fs).also { it.setSemitones(settings.pitchSemitones.toDouble()) } else null
    private val hum: Humanizer? =
        if (settings.humanizeActive) Humanizer(fs, settings.humanize.toDouble(), settings.breaths, mixSeed(0x1234ABCD, seed)) else null
    private val fx: StereoEffect? =
        makeEffect(fs, settings.effect, settings.effectAmount.toDouble(), settings.effectSpeed.toDouble(), seed)

    val latencyFrames: Int = (pitch?.latencyFrames ?: 0) + (hum?.latencyFrames ?: 0)

    private val tmp = DoubleArray(2)

    /** Processes one mono sample (-1..1) and writes the stereo result into [out] (size 2). */
    fun process(x: Double, out: DoubleArray) {
        var v = x
        val p = pitch
        if (p != null) v = p.process(v)
        var l = v
        var r = v
        val h = hum
        if (h != null) {
            h.process(v, tmp)
            l = tmp[0]
            r = tmp[1]
        }
        val e = fx
        if (e != null) {
            e.process(l, r, tmp)
            l = tmp[0]
            r = tmp[1]
        }
        out[0] = softLimit(l)
        out[1] = softLimit(r)
    }
}

/**
 * Applies the voice changer to 16-bit little-endian PCM, one chunk at a time, so a recording of any
 * length can be processed without holding it in memory. [channels] is 1 or 2 (stereo input is mixed
 * to mono for processing - this is a voice tool - and the result has the same channel count).
 *
 * Feed chunks to [process] in order, then call [finish] once at the end. The output is delayed-free:
 * N frames in give N frames out in total, lined up with the input (the filters' own delay is removed),
 * plus the [finish] tail.
 */
class VoiceFxPcmStream(settings: VoiceFxSettings, sampleRate: Int, private val channels: Int, seed: Int = 0) {
    private val proc = VoiceProcessor(sampleRate, settings, seed)
    private var skip = proc.latencyFrames
    private val out = DoubleArray(2)

    fun process(chunk: ByteArray, length: Int = chunk.size): ByteArray {
        val frameBytes = channels * 2
        val frames = length / frameBytes
        if (frames <= 0) return ByteArray(0)
        val res = ByteArray(frames * frameBytes)
        var o = 0
        var idx = 0
        for (f in 0 until frames) {
            val inL = sample16(chunk, idx)
            val inR = if (channels >= 2) sample16(chunk, idx + 2) else inL
            idx += frameBytes
            proc.process((inL + inR) * 0.5 / 32768.0, out)
            if (skip > 0) {
                skip--
                continue
            }
            if (channels >= 2) {
                put16(res, o, out[0])
                put16(res, o + 2, out[1])
            } else {
                put16(res, o, (out[0] + out[1]) * 0.5)
            }
            o += frameBytes
        }
        return if (o == res.size) res else res.copyOf(o)
    }

    /**
     * Ends the stream: returns the last [VoiceProcessor.latencyFrames] frames that were still inside
     * the filters, plus [tailFrames] more frames of silence-in so reverb and echo can fade out.
     */
    fun finish(tailFrames: Int): ByteArray {
        val total = proc.latencyFrames + tailFrames.coerceAtLeast(0)
        if (total <= 0) return ByteArray(0)
        return process(ByteArray(total * channels * 2))
    }

    private fun sample16(buf: ByteArray, i: Int): Double =
        (((buf[i + 1].toInt() shl 8) or (buf[i].toInt() and 0xFF)).toShort().toInt()).toDouble()

    private fun put16(buf: ByteArray, pos: Int, v: Double) {
        val s = Math.round(v * 32767.0).toInt().coerceIn(-32768, 32767)
        buf[pos] = (s and 0xFF).toByte()
        buf[pos + 1] = ((s shr 8) and 0xFF).toByte()
    }
}

/** Whole-clip helper, used for one spoken sentence (the clip is short, so it is done in one go). */
object VoiceFxPcm {
    /**
     * Returns [pcm] with the voice changer applied, longer by the effect's tail (an echo or reverb
     * rings on after the last word). When [fx] is not active the same array is returned untouched.
     */
    fun processClip(pcm: ByteArray, sampleRate: Int, channels: Int, fx: VoiceFxSettings, seed: Int = 0): ByteArray {
        if (!fx.isActive || pcm.isEmpty()) return pcm
        val stream = VoiceFxPcmStream(fx, sampleRate, channels, seed)
        val head = stream.process(pcm)
        val tailFrames = (fx.tailSeconds * sampleRate).toInt()
        val tail = stream.finish(tailFrames)
        // the tail is cut off at some point, so fade its last moments instead of leaving a click
        if (tailFrames > 0) fadeOut(tail, channels, (0.15 * sampleRate).toInt())
        return head + tail
    }

    private fun fadeOut(buf: ByteArray, channels: Int, fadeFrames: Int) {
        val frameBytes = channels * 2
        val frames = buf.size / frameBytes
        val n = min(fadeFrames, frames)
        if (n <= 0) return
        for (j in 0 until n) {
            val gain = 1.0 - (j + 1.0) / n
            val base = (frames - n + j) * frameBytes
            for (c in 0 until channels) {
                val pos = base + c * 2
                val s = ((buf[pos + 1].toInt() shl 8) or (buf[pos].toInt() and 0xFF)).toShort().toInt()
                val v = Math.round(s * gain).toInt().coerceIn(-32768, 32767)
                buf[pos] = (v and 0xFF).toByte()
                buf[pos + 1] = ((v shr 8) and 0xFF).toByte()
            }
        }
    }
}
