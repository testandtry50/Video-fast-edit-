package com.videoslidemaker.app.align

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/**
 * Plays the user's ORIGINAL recording straight through while the Preview runs, so the photos can
 * be checked against the real sound. (RecordingClipPlayer, used on the Match screen, only plays one
 * short stretch and then stops; this one keeps going until it is paused.)
 *
 * The recording's clock is the script's clock, so a script timestamp of 12.5 s means 12 500 ms
 * into the recording. While it plays, [positionMs] is the sound's own position, which the Preview
 * uses as the master clock so the photos can never drift away from what is being heard.
 *
 * All calls must come from the main thread.
 */
class PreviewRecordingPlayer(private val context: Context) {
    private var player: MediaPlayer? = null
    private var loadedUri: Uri? = null

    /** The speed currently set on [player]. A freshly opened player is always at normal speed. */
    private var playerSpeed = 1f

    /**
     * NEW (2.8): the speed the last [playFrom] really started at - the one asked for, or the nearest one
     * this phone accepts. The Preview runs its clock at this speed so the photos stay with the sound.
     */
    var appliedSpeed: Float = 1f
        private set

    /**
     * Opens the recording (only once - later plays reuse it), jumps to [startMs] and starts playing at
     * [speed] (1 = normal; the voice keeps its pitch). Returns null when it is playing, or a short
     * plain-language problem when it could not be.
     */
    suspend fun playFrom(uri: Uri, startMs: Long, speed: Float = 1f): String? {
        try {
            val mp = prepared(uri)
            val duration = runCatching { mp.duration.toLong() }.getOrDefault(-1L)
            if (duration > 0 && startMs >= duration) {
                return "Your recording ends before this point, so there is no original sound here."
            }
            seekTo(mp, startMs)
            appliedSpeed = applySpeed(mp, speed)
            mp.start()
            return null
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            // the opened player may be in a bad state; drop it so the next try starts fresh
            runCatching { player?.release() }
            player = null
            loadedUri = null
            playerSpeed = 1f
            appliedSpeed = 1f
            return "Couldn't play your recording. Choose it again on the Script screen."
        }
    }

    fun pause() {
        runCatching { player?.takeIf { it.isPlaying }?.pause() }
    }

    /** Position in the recording in ms, or -1 when nothing is playing (paused, finished, or not opened). */
    fun positionMs(): Long {
        val mp = player ?: return -1L
        return try {
            if (mp.isPlaying) mp.currentPosition.toLong() else -1L
        } catch (_: Exception) {
            -1L
        }
    }

    /** Frees the media player. Call when the screen's owner goes away, or the recording changes. */
    fun release() {
        runCatching { player?.release() }
        player = null
        loadedUri = null
        playerSpeed = 1f
    }

    private suspend fun prepared(uri: Uri): MediaPlayer {
        val existing = player
        if (existing != null && loadedUri == uri) return existing
        runCatching { player?.release() }
        player = null
        loadedUri = null
        playerSpeed = 1f

        val mp = MediaPlayer()
        try {
            mp.setAudioAttributes(
                AudioAttributes.Builder()
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .build()
            )
            mp.setDataSource(context, uri)
            suspendCancellableCoroutine<Unit> { cont ->
                mp.setOnPreparedListener { if (cont.isActive) cont.resume(Unit) }
                mp.setOnErrorListener { _, what, extra ->
                    if (cont.isActive) cont.resumeWithException(IllegalStateException("Media error $what/$extra"))
                    true
                }
                mp.prepareAsync()
            }
            // after preparing, an error just ends playback; the preview keeps going on its own clock
            mp.setOnErrorListener { _, _, _ -> true }
        } catch (t: Throwable) {
            runCatching { mp.release() }
            throw t
        }
        player = mp
        loadedUri = uri
        return mp
    }

    /**
     * Puts [wanted] on the player and returns the speed it really has. At normal speed on a player that was
     * never changed nothing is touched, so playback is exactly what it was before the speed control existed.
     * (Android treats "set a speed" as "play" - fine here, because playing is about to start anyway.)
     */
    private fun applySpeed(mp: MediaPlayer, wanted: Float): Float {
        if (wanted == playerSpeed) return playerSpeed
        val got = PlaybackSpeed.setOn(mp, wanted)
        playerSpeed = got
        return got
    }

    /** Jumps to [ms] as exactly as the file allows, and waits until the jump has happened. */
    private suspend fun seekTo(mp: MediaPlayer, ms: Long) {
        withTimeoutOrNull(3000L) {
            suspendCancellableCoroutine<Unit> { cont ->
                mp.setOnSeekCompleteListener { if (cont.isActive) cont.resume(Unit) }
                mp.seekTo(ms, MediaPlayer.SEEK_CLOSEST)
            }
        }
        mp.setOnSeekCompleteListener(null)
    }
}
