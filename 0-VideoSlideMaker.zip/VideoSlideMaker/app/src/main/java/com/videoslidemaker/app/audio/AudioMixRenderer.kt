package com.videoslidemaker.app.audio

import android.content.Context
import android.net.Uri
import com.videoslidemaker.app.export.AUDIO_CHANNELS
import com.videoslidemaker.app.export.AUDIO_SAMPLE_RATE
import com.videoslidemaker.app.export.AudioDecoder
import java.io.File
import java.io.FileOutputStream
import java.io.RandomAccessFile
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.roundToLong

/** A stretch of the video's timeline to build instead of all of it (used to listen to a short part of the mix). */
data class AudioWindow(val startSec: Double, val lengthSec: Double)

/** What the voice is doing: used to lower the music under it and to set the music's loudness. */
class VoiceProfile(
    val mask: BooleanArray,
    val framesPerWindow: Int,
    val voiceDb: Double?
)

/**
 * NEW (2.17): lays the edited main clips and the background tracks onto the export's audio timeline (the same disk file
 * the narration is built in), one small piece at a time, so a long video never needs the sound in memory.
 * Frames are counted at [AUDIO_SAMPLE_RATE]; everything on the timeline is stereo 16-bit.
 */
object AudioMixRenderer {
    private const val RATE = AUDIO_SAMPLE_RATE
    private const val CH = AUDIO_CHANNELS
    private const val FRAME_BYTES = CH * 2
    private const val CHUNK_FRAMES = 8192
    private const val LOOP_CROSSFADE_SEC = 1.5

    /** The clip with its length known: a clip saved by an older version is measured now, and as a last resort assumed long. */
    private fun resolved(context: Context, clip: AudioClip): AudioClip {
        if (!clip.isUnmeasured) return clip
        val measured = AudioProbe.durationSec(context, clip.uri)
        return if (measured > 0.0) clip.measured(measured) else clip.copy(srcEndSec = 6 * 3600.0)
    }

    /**
     * Lays the main clips on the timeline (adding to whatever is already there). Returns how many made sound.
     * [windowStartSec] is the timeline second that frame 0 of the file stands for.
     */
    fun mixMainClips(
        context: Context,
        raf: RandomAccessFile,
        totalFrames: Long,
        clips: List<AudioClip>,
        windowStartSec: Double,
        limiter: Boolean,
        checkCancelled: () -> Unit
    ): Int {
        val timeline = Timeline(raf, totalFrames, limiter)
        var played = 0
        for (original in clips) {
            checkCancelled()
            val clip = resolved(context, original)
            val lengthSec = clip.lengthSec
            if (lengthSec <= 0.0) continue
            val offset = ((clip.startSec - windowStartSec) * RATE).roundToLong()
            val lengthFrames = (lengthSec * RATE).toLong()
            if (offset + lengthFrames <= 0L || offset >= totalFrames) continue
            val skip = max(0L, -offset)
            val first = max(0L, offset)
            val framesToPlay = min(lengthFrames - skip, totalFrames - first)
            if (framesToPlay <= 0L) continue
            val srcFrom = clip.srcStartSec + skip.toDouble() / RATE
            val srcTo = srcFrom + framesToPlay.toDouble() / RATE

            var writeFrame = first
            var clipFrame = skip
            var buf = FloatArray(0)
            val plainGain = clip.fadeInSec <= 0.0 && clip.fadeOutSec <= 0.0
            val ok = AudioDecoder.streamSegment(context, Uri.parse(clip.uri), srcFrom, srcTo, RATE, CH) { chunk ->
                checkCancelled()
                val frames = chunk.size / FRAME_BYTES
                if (buf.size < frames * CH) buf = FloatArray(frames * CH)
                var b = 0
                for (f in 0 until frames) {
                    val g = if (plainGain) clip.volume
                    else clip.volume * SmartMix.fade((clipFrame + f).toDouble() / RATE, lengthSec, clip.fadeInSec, clip.fadeOutSec)
                    for (c in 0 until CH) {
                        val s = ((chunk[b + 1].toInt() shl 8) or (chunk[b].toInt() and 0xFF)).toShort() / 32768f
                        buf[f * CH + c] = s * g
                        b += 2
                    }
                }
                timeline.mix(writeFrame, buf, frames)
                writeFrame += frames
                clipFrame += frames
                true
            }
            if (ok) played++
        }
        return played
    }

    /** Listens to the main sound that is already on the timeline and works out when someone is speaking and how loudly. */
    fun analyzeVoice(raf: RandomAccessFile, totalFrames: Long, checkCancelled: () -> Unit): VoiceProfile {
        val meter = SmartMix.EnergyMeter(RATE, CH)
        val buf = ByteArray(RATE * FRAME_BYTES) // one second
        var left = totalFrames * FRAME_BYTES
        raf.seek(0)
        while (left > 0L) {
            checkCancelled()
            val n = min(buf.size.toLong(), left).toInt()
            raf.readFully(buf, 0, n)
            meter.push(buf, n)
            left -= n
        }
        val rms = meter.result()
        val mask = SmartMix.speechMask(rms)
        return VoiceProfile(mask, meter.framesPerWindow, SmartMix.activeLevelDb(rms, mask))
    }

    /**
     * Mixes the background tracks under what is already on the timeline, with fades, looping, automatic lowering under
     * the voice and automatic loudness according to [smart]. [videoTotalSec] is the whole video's length (a short
     * [windowStartSec] window of it may be what is being built), so "until the end of the video" and the closing fade
     * stay right even then. Returns how many tracks made sound.
     */
    fun mixBackground(
        context: Context,
        raf: RandomAccessFile,
        totalFrames: Long,
        clips: List<AudioClip>,
        windowStartSec: Double,
        videoTotalSec: Double,
        smart: SmartMixSettings,
        cacheDir: File,
        checkCancelled: () -> Unit,
        onProgress: (fraction: Float, message: String) -> Unit = { _, _ -> }
    ): Int {
        if (clips.isEmpty() || totalFrames <= 0L) return 0
        val timeline = Timeline(raf, totalFrames, smart.limiter)
        val voice: VoiceProfile? =
            if (smart.autoDuck || smart.autoLevel) analyzeVoice(raf, totalFrames, checkCancelled) else null
        val duckCurve: FloatArray? =
            if (smart.autoDuck && voice != null && voice.mask.isNotEmpty()) {
                SmartMix.duckGains(voice.mask, 10.0.pow(smart.duckDb / 20.0).toFloat())
            } else null

        var played = 0
        for ((index, original) in clips.withIndex()) {
            checkCancelled()
            onProgress(index.toFloat() / clips.size, "Mixing background audio ${index + 1} of ${clips.size}")
            // "Always fit the video" tracks are fitted to the video as it is NOW, so they stay right after any later change.
            val clip = ClipEdit.followVideo(resolved(context, original), videoTotalSec)
            if (clip.lengthSec <= 0.0) continue

            // 1. the used part of the file, decoded once to a temporary file (so it can be repeated), and its loudness measured
            val tmp = File(cacheDir, "bg_${System.nanoTime()}.pcm")
            try {
                val meter = SmartMix.EnergyMeter(RATE, CH)
                var frames = 0L
                FileOutputStream(tmp).use { out ->
                    AudioDecoder.streamSegment(context, Uri.parse(clip.uri), clip.srcStartSec, clip.srcEndSec, RATE, CH) { chunk ->
                        checkCancelled()
                        out.write(chunk)
                        meter.push(chunk)
                        frames += chunk.size / FRAME_BYTES
                        true
                    }
                }
                if (frames < 1L) continue
                val musicDb = SmartMix.musicLevelDb(meter.result())

                // 2. where it plays
                val sourceSec = frames.toDouble() / RATE
                val spanSec = if (clip.loop) videoTotalSec - clip.startSec else min(sourceSec, videoTotalSec - clip.startSec)
                if (spanSec <= 0.0) continue
                val spanStart = ((clip.startSec - windowStartSec) * RATE).roundToLong()
                val spanFrames = (spanSec * RATE).toLong()
                val from = max(spanStart, 0L)
                val to = min(spanStart + spanFrames, totalFrames)
                if (to <= from) continue

                // 3. fades, repeating, loudness
                val reachesEnd = clip.startSec + spanSec >= videoTotalSec - 0.05
                val fadeOut = if (smart.fadeAtEnd && reachesEnd) max(clip.fadeOutSec, AudioLimits.END_FADE_SEC) else clip.fadeOutSec
                val repeats = clip.loop && frames < spanFrames
                val cross = if (repeats && frames >= 2L * RATE) min((LOOP_CROSSFADE_SEC * RATE).toLong(), frames / 4) else 0L
                val period = frames - cross
                val level = if (smart.autoLevel) SmartMix.autoLevelGain(voice?.voiceDb, musicDb, SmartMix.bedOffsetDb(smart.autoDuck)) else 1f
                val ducking = duckCurve != null && clip.autoDuck

                RandomAccessFile(tmp, "r").use { srcFile ->
                    val src = PcmReader(srcFile, frames)
                    val buf = FloatArray(CHUNK_FRAMES * CH)
                    val spare = FloatArray(CHUNK_FRAMES * CH)
                    var f = from
                    while (f < to) {
                        checkCancelled()
                        val n = min(CHUNK_FRAMES.toLong(), to - f).toInt()
                        val posInSpan = f - spanStart
                        if (repeats) fillLooped(src, period, cross, posInSpan, n, buf, spare)
                        else src.read(posInSpan, n, buf, 0)
                        for (i in 0 until n) {
                            val t = (posInSpan + i).toDouble() / RATE
                            var g = clip.volume * level * SmartMix.fade(t, spanSec, clip.fadeInSec, fadeOut)
                            if (ducking) g *= SmartMix.gainAt(duckCurve!!, f + i, voice!!.framesPerWindow)
                            buf[i * CH] *= g
                            buf[i * CH + 1] *= g
                        }
                        timeline.mix(f, buf, n)
                        f += n
                    }
                }
                played++
            } finally {
                tmp.delete()
            }
        }
        onProgress(1f, "Background audio mixed")
        return played
    }

    /**
     * Reads [n] frames of a track that repeats: every round plays [period] frames, and the first [cross] frames of a
     * round are blended with the part of the file that came right after the round, so the join has no click or jump.
     */
    private fun fillLooped(src: PcmReader, period: Long, cross: Long, posInSpan: Long, n: Int, dst: FloatArray, spare: FloatArray) {
        var produced = 0
        var cyc = posInSpan % period
        while (produced < n) {
            val inHead = cross > 0L && cyc < cross
            val room = if (inHead) cross - cyc else period - cyc
            val take = min(room, (n - produced).toLong()).toInt()
            src.read(cyc, take, dst, produced)
            if (inHead) {
                src.read(period + cyc, take, spare, 0)
                for (i in 0 until take) {
                    val x = (cyc + i + 0.5) / cross
                    val wi = SmartMix.crossIn(x)
                    val wo = SmartMix.crossOut(x)
                    val d = (produced + i) * CH
                    dst[d] = dst[d] * wi + spare[i * CH] * wo
                    dst[d + 1] = dst[d + 1] * wi + spare[i * CH + 1] * wo
                }
            }
            produced += take
            cyc += take
            if (cyc >= period) cyc = 0L
        }
    }

    /** Reads 16-bit stereo frames of a temporary PCM file as floats; anything past the end reads as silence. */
    private class PcmReader(private val raf: RandomAccessFile, private val frames: Long) {
        private var scratch = ByteArray(0)

        fun read(startFrame: Long, count: Int, dst: FloatArray, dstFrame: Int) {
            val avail = (frames - startFrame).coerceIn(0L, count.toLong()).toInt()
            if (avail > 0) {
                val bytes = avail * FRAME_BYTES
                if (scratch.size < bytes) scratch = ByteArray(bytes)
                raf.seek(startFrame * FRAME_BYTES)
                raf.readFully(scratch, 0, bytes)
                var b = 0
                var d = dstFrame * CH
                for (i in 0 until avail * CH) {
                    dst[d++] = ((scratch[b + 1].toInt() shl 8) or (scratch[b].toInt() and 0xFF)).toShort() / 32768f
                    b += 2
                }
            }
            for (i in (dstFrame + avail) * CH until (dstFrame + count) * CH) dst[i] = 0f
        }
    }

    /** The export's audio timeline: adds float samples onto the 16-bit sound already in the file. */
    private class Timeline(private val raf: RandomAccessFile, private val totalFrames: Long, private val limiter: Boolean) {
        private var scratch = ByteArray(0)

        fun mix(startFrame: Long, samples: FloatArray, frames: Int) {
            if (startFrame < 0L || startFrame >= totalFrames) return
            val n = min(frames.toLong(), totalFrames - startFrame).toInt()
            if (n <= 0) return
            val bytes = n * FRAME_BYTES
            if (scratch.size < bytes) scratch = ByteArray(bytes)
            raf.seek(startFrame * FRAME_BYTES)
            raf.readFully(scratch, 0, bytes)
            var b = 0
            for (i in 0 until n * CH) {
                val add = samples[i]
                if (add != 0f) {
                    val existing = ((scratch[b + 1].toInt() shl 8) or (scratch[b].toInt() and 0xFF)).toShort() / 32768f
                    val sum = existing + add
                    val v = if (limiter) SmartMix.softClip(sum) else sum.coerceIn(-1f, 1f)
                    val q = (v * 32767f).roundToInt().coerceIn(-32768, 32767)
                    scratch[b] = (q and 0xFF).toByte()
                    scratch[b + 1] = ((q shr 8) and 0xFF).toByte()
                }
                b += 2
            }
            raf.seek(startFrame * FRAME_BYTES)
            raf.write(scratch, 0, bytes)
        }
    }
}
