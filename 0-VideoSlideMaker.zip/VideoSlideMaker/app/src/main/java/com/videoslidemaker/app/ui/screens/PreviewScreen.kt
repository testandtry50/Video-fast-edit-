package com.videoslidemaker.app.ui.screens

import com.videoslidemaker.app.ui.theme.Outline
import com.videoslidemaker.app.ui.components.appSliderColors
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.Role
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.heightIn
import android.content.Context
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.key
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.BiasAlignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import coil.imageLoader
import coil.request.ImageRequest
import coil.size.Scale
import com.videoslidemaker.app.data.ScriptParser
import com.videoslidemaker.app.model.AppStep
import com.videoslidemaker.app.model.AudioSource
import com.videoslidemaker.app.model.EffectStyle
import com.videoslidemaker.app.model.OverlayStyle
import com.videoslidemaker.app.model.PhotoMotion
import com.videoslidemaker.app.model.PhotoMove
import com.videoslidemaker.app.model.PreviewSpeed
import com.videoslidemaker.app.model.SentenceSlide
import com.videoslidemaker.app.model.TransitionMath
import com.videoslidemaker.app.model.TransitionStyle
import com.videoslidemaker.app.model.UiState
import com.videoslidemaker.app.ui.components.AlertBox
import com.videoslidemaker.app.ui.components.AlertStyle
import com.videoslidemaker.app.ui.components.BadgeChip
import com.videoslidemaker.app.ui.components.PrimaryButton
import com.videoslidemaker.app.ui.components.ScreenTitle
import com.videoslidemaker.app.ui.components.SecondaryButton
import com.videoslidemaker.app.ui.theme.Accent
import com.videoslidemaker.app.ui.theme.BorderColor
import com.videoslidemaker.app.ui.theme.CardBg
import com.videoslidemaker.app.ui.theme.Muted
import com.videoslidemaker.app.ui.theme.Surface
import com.videoslidemaker.app.ui.theme.TextMain
import com.videoslidemaker.app.ui.theme.Yellow
import com.videoslidemaker.app.viewmodel.AppViewModel

// Photos are always requested at this exact size, both when they are shown and when they are
// loaded ahead of time. An explicit size means the image does not have to wait for layout, and
// a photo that was loaded ahead of time is found in memory the instant its slide begins - no
// blank flash or hitch at the cut.
private const val PHOTO_W_PX = 1080
private const val PHOTO_H_PX = 810

private fun photoRequest(context: Context, uri: Uri): ImageRequest =
    ImageRequest.Builder(context)
        .data(uri)
        .size(PHOTO_W_PX, PHOTO_H_PX)
        .scale(Scale.FILL)
        .build()

/**
 * One photo in the preview. Everything that moves - the zoom / pan, the fade, the slide - is worked out from the
 * PLAYING POSITION inside the two graphicsLayer blocks below, using the very same numbers as the exported video
 * (PhotoMotion and TransitionMath), so what you see here is what the export gives you. Because it depends only on
 * the position, scrubbing, previous / next and speed changes all show the right picture at once.
 *
 * Two nested layers on purpose: the OUTER box is the window (it slides / fades and clips), the INNER image is what
 * zooms and pans inside the window. A zoomed photo therefore can never spill outside its own frame.
 */
@Composable
private fun PhotoLayer(
    request: ImageRequest,
    move: PhotoMove,
    transition: TransitionStyle,
    slideStart: Double,
    slideDur: Double,
    prevDur: Double,
    hasNext: Boolean,
    posState: State<Double>
) {
    Box(
        Modifier
            .fillMaxSize()
            .graphicsLayer {
                val look = TransitionMath.layerLook(transition, posState.value, slideStart, slideDur, prevDur, hasNext)
                alpha = look.alpha
                translationX = look.shift * size.width
            }
            .clipToBounds()
    ) {
        AsyncImage(
            model = request,
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer {
                    val look = TransitionMath.layerLook(transition, posState.value, slideStart, slideDur, prevDur, hasNext)
                    val frame = PhotoMotion.frameAt(move, look.progress)
                    // The layer scales around its centre; moving it by this much shows the part of the zoomed
                    // photo the export shows (panX 0.5 = centred, so a plain zoom needs no sideways move at all).
                    scaleX = frame.scale
                    scaleY = frame.scale
                    translationX = size.width * (frame.scale - 1f) * (0.5f - frame.panX)
                }
        )
    }
}

@Composable
fun PreviewScreen(state: UiState, viewModel: AppViewModel, onPickRecording: () -> Unit) {
    // These only change when the photos/slides/settings change - NOT while playing.
    val timeline = remember(state.slides, state.images, state.settings.defaultDurationSec) { state.effectiveSlides }
    val sequence = remember(state.slides, state.images, state.settings.defaultDurationSec) { state.finalSequence() }
    val totalDuration = remember(state.slides, state.images, state.settings.defaultDurationSec) { state.totalDurationSec }

    // The moving position. It is only ever READ inside small pieces (graphicsLayer, the clock text,
    // the scrub bar), so this screen as a whole is not redrawn on every frame - only when the
    // slide number really changes.
    val posState = viewModel.previewPosition.collectAsState()
    val index by remember(timeline) {
        derivedStateOf {
            state.slideIndexAt(posState.value, timeline).coerceIn(0, (timeline.size - 1).coerceAtLeast(0))
        }
    }
    val currentSlide = timeline.getOrNull(index)

    // One tick per screen frame while playing, so the zoom/pan is as smooth as the screen itself.
    LaunchedEffect(state.previewPlaying) {
        if (state.previewPlaying) {
            while (true) {
                withFrameNanos { viewModel.previewFrame() }
            }
        }
    }
    // Leaving this screen (any way) must stop the sound.
    DisposableEffect(Unit) { onDispose { viewModel.stopPreview() } }

    // Load the next photos while the current one is on screen.
    val context = LocalContext.current
    val imageLoader = context.imageLoader
    // Sped up, slides go by faster, so more of them are loaded ahead (2 at normal speed, up to 8 at 4x).
    val lookAhead = PreviewSpeed.lookAhead(state.previewSpeed)
    LaunchedEffect(index, sequence, lookAhead) {
        for (ahead in 1..lookAhead) {
            val next = sequence.getOrNull(index + ahead) ?: break
            imageLoader.enqueue(photoRequest(context, next.uri))
        }
    }

    val effectStyle = state.settings.effectStyle
    val transitionStyle = state.settings.transitionStyle
    // One move per photo, the same list the exporter uses (this is what makes the "Mix" effects mix).
    val motionPlan = remember(effectStyle, sequence.size) { PhotoMotion.plan(effectStyle, sequence.size) }

    // Scrolls: with the photo, the controls and two buttons this screen is taller than most phones,
    // so the bottom buttons used to be pushed off-screen with no way to reach them.
    Column(
        Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        ScreenTitle("Preview", "Plays in real time with the same motion, timing, and sound your export will have.")

        Box(
            Modifier
                .fillMaxWidth()
                .height(280.dp)
                .clip(RoundedCornerShape(14.dp))
                // black behind the photos, exactly like the exported video (a fade to black used to dip to grey here)
                .background(if (sequence.isNotEmpty()) Color.Black else CardBg),
            contentAlignment = Alignment.Center
        ) {
            if (sequence.isNotEmpty()) {
                // The photo on screen, and - for Crossfade and Slide only - the NEXT one on top of it, which is invisible
                // until the last moments of the current slot. Their identity is the slide number (key), so when the
                // next photo takes over it simply carries on instead of being loaded again.
                val needNext = transitionStyle == TransitionStyle.CROSSFADE || transitionStyle == TransitionStyle.SLIDE
                val lastShown = if (needNext) minOf(index + 1, sequence.lastIndex) else index
                for (idx in index..lastShown) {
                    key(idx) {
                        val image = sequence.getOrNull(idx)
                        if (image != null) {
                            val request = remember(image.uri) { photoRequest(context, image.uri) }
                            PhotoLayer(
                                request = request,
                                move = motionPlan.getOrElse(idx) { PhotoMove.STILL },
                                transition = transitionStyle,
                                slideStart = timeline.getOrNull(idx)?.timestampSec ?: 0.0,
                                slideDur = state.durationForIndex(idx),
                                prevDur = if (idx > 0) state.durationForIndex(idx - 1) else 0.0,
                                hasNext = idx < sequence.lastIndex,
                                posState = posState
                            )
                        }
                    }
                }
            } else {
                Text("No photos yet", color = Muted)
            }
            if (currentSlide != null && currentSlide.text.isNotBlank()) {
                Box(
                    Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .background(Color.Black.copy(alpha = 0.55f))
                        .padding(10.dp)
                ) {
                    Text(currentSlide.text, color = Color.White, style = MaterialTheme.typography.bodyMedium)
                }
            }
            if (state.textOverlays.isNotEmpty()) {
                OverlaysLayer(state, posState)
            }
            if (!PreviewSpeed.same(state.previewSpeed, PreviewSpeed.NORMAL)) {
                // like the "2x" badge on YouTube: a reminder that this is not normal speed
                Text(
                    PreviewSpeed.label(state.previewSpeed),
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.labelLarge,
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(8.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color.Black.copy(alpha = 0.6f))
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                )
            }
        }

        TimeRow(posState, totalDuration, index, timeline.size)
        ScrubBar(posState, totalDuration, viewModel)

        Row(
            Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            BadgeChip(state.settings.effectStyle.label, if (state.settings.effectStyle != EffectStyle.NONE) AlertStyle.SUCCESS else AlertStyle.INFO)
            BadgeChip(state.settings.transitionStyle.label, if (state.settings.transitionStyle != TransitionStyle.NONE) AlertStyle.SUCCESS else AlertStyle.INFO)
        }

        Row(
            Modifier.fillMaxWidth().padding(vertical = 12.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // same width as the speed button on the other side, so the play button stays in the middle
            Spacer(Modifier.width(64.dp))
            IconButton(onClick = viewModel::previewPrev, modifier = Modifier.size(52.dp)) {
                Icon(Icons.Filled.SkipPrevious, contentDescription = "Previous photo", tint = TextMain, modifier = Modifier.size(30.dp))
            }
            IconButton(onClick = viewModel::previewTogglePlay, modifier = Modifier.size(64.dp).padding(horizontal = 12.dp)) {
                Icon(
                    if (state.previewPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                    contentDescription = if (state.previewPlaying) "Pause preview" else "Play preview",
                    tint = Accent,
                    modifier = Modifier.size(40.dp)
                )
            }
            IconButton(onClick = viewModel::previewNext, modifier = Modifier.size(52.dp)) {
                Icon(Icons.Filled.SkipNext, contentDescription = "Next photo", tint = TextMain, modifier = Modifier.size(30.dp))
            }
            // NEW (2.8): shows the speed; each tap goes to the next common one (0.5x, 1x, 1.5x, 2x, 3x)
            PreviewSpeedButton(
                speed = state.previewSpeed,
                onClick = { viewModel.previewSetSpeed(PreviewSpeed.cycle(state.previewSpeed)) },
                modifier = Modifier.widthIn(min = 64.dp)
            )
        }

        // NEW (2.8): playback speed - see and hear the preview at 0.25x ... 4x, like a YouTube viewer would
        PreviewSpeedPanel(state, viewModel, timeline.size, totalDuration, Modifier.padding(bottom = 12.dp))

        SoundChoice(state, viewModel, onPickRecording)

        // NEW: pitch, "make it sound human" and voice effects (for both the phone's voice and your own recording)
        if (state.settings.narration.enabled) {
            VoiceChangerPanel(state, viewModel, Modifier.padding(bottom = 12.dp))
        }

        // NEW (2.17): this preview plays the Script step's voice / recording only; the Audio step's edits are heard there.
        val audioEdits = state.settings.audio
        if (audioEdits.useCustomMain || audioEdits.activeBackground.isNotEmpty()) {
            AlertBox(
                if (audioEdits.useCustomMain) {
                    "This preview shows the photos and their timing. Your edited audio plays in the Audio step (\"Hear the mix\") and is in the exported video."
                } else {
                    "Background music is not played in this preview. Hear it in the Audio step; it is in the exported video."
                },
                style = AlertStyle.INFO,
                modifier = Modifier.padding(bottom = 12.dp)
            )
        }

        PrimaryButton("Next — Export →", onClick = { viewModel.stopPreview(); viewModel.goStep(AppStep.EXPORT) })
        SecondaryButton("← Back to Audio", onClick = { viewModel.stopPreview(); viewModel.goStep(AppStep.AUDIO) })
    }
}

/** Elapsed / total and the slide number. Only this small row is redrawn as the clock moves. */
@Composable
private fun TimeRow(posState: State<Double>, totalDuration: Double, index: Int, slideCount: Int) {
    // changes once a second, not every frame
    val wholeSeconds by remember { derivedStateOf { posState.value.toInt() } }
    Row(
        Modifier.fillMaxWidth().padding(top = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            "${ScriptParser.formatClock(wholeSeconds.toDouble())} / ${ScriptParser.formatClock(totalDuration)}",
            style = MaterialTheme.typography.bodySmall,
            color = Muted
        )
        if (slideCount > 0) {
            Text("${index + 1} / $slideCount", style = MaterialTheme.typography.bodySmall, color = Muted)
        }
    }
}

/** Progress line you can drag - jump to any point to check that a photo changes exactly where its words are spoken. */
@Composable
private fun ScrubBar(posState: State<Double>, totalDuration: Double, viewModel: AppViewModel) {
    var dragging by remember { mutableStateOf(false) }
    var dragValue by remember { mutableFloatStateOf(0f) }
    val shown = if (dragging) {
        dragValue
    } else if (totalDuration <= 0.0) {
        0f
    } else {
        (posState.value / totalDuration).toFloat().coerceIn(0f, 1f)
    }
    Slider(
        value = shown,
        onValueChange = { dragging = true; dragValue = it },
        onValueChangeFinished = {
            viewModel.previewSeekToFraction(dragValue)
            dragging = false
        },
        colors = appSliderColors(),
        modifier = Modifier
            .fillMaxWidth()
            .semantics { contentDescription = "Playback position" }
    )
}

/** The character-name labels. Redrawn per frame, but it is only a handful of small items. */
@Composable
private fun BoxScope.OverlaysLayer(state: UiState, posState: State<Double>) {
    state.overlaysActiveAt(posState.value).forEach { (overlay, alpha) ->
        // Direct fraction -> bias mapping (0..1 fraction becomes Alignment's -1..1 bias). This uses
        // the exact same xFraction/yFraction as the drag editor and the real export.
        val overlayAlignment = BiasAlignment(
            horizontalBias = overlay.xFraction * 2f - 1f,
            verticalBias = overlay.yFraction * 2f - 1f
        )
        Box(
            Modifier
                .align(overlayAlignment)
                .alpha(alpha)
        ) {
            when (overlay.style) {
                OverlayStyle.TAG -> {
                    Row(
                        Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color.Black.copy(alpha = 0.75f)),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(Modifier.width(4.dp).height(26.dp).background(Accent))
                        Text(
                            overlay.text,
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                        )
                    }
                }
                OverlayStyle.UNDERLINE -> {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(overlay.text, color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                        Box(Modifier.padding(top = 4.dp).width(60.dp).height(3.dp).background(Accent))
                    }
                }
                OverlayStyle.MINIMAL -> {
                    Text(overlay.text, color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                }
            }
        }
    }
}

/** Voice / Original recording / Off - the same choice the export will use - plus what to expect from each. */
@Composable
private fun SoundChoice(state: UiState, viewModel: AppViewModel, onPickRecording: () -> Unit) {
    val narration = state.settings.narration
    val selected = when {
        !narration.enabled -> 2
        narration.source == AudioSource.ORIGINAL -> 1
        else -> 0
    }
    val hasRecording = state.alignment.recordingUri != null

    Text(
        "Sound",
        color = TextMain,
        fontWeight = FontWeight.Bold,
        style = MaterialTheme.typography.bodyMedium,
        modifier = Modifier.padding(bottom = 6.dp)
    )
    Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        ChoiceChip("🔊 Voice", selected == 0) { viewModel.setAudioSource(AudioSource.VOICE) }
        ChoiceChip("🎧 Original", selected == 1) { viewModel.setAudioSource(AudioSource.ORIGINAL) }
        ChoiceChip("🔇 Off", selected == 2) { viewModel.setNarrationEnabled(false) }
    }

    when (selected) {
        0 -> Text(
            "The phone's voice reads each sentence as its photo comes up.",
            style = MaterialTheme.typography.bodySmall,
            color = Muted,
            modifier = Modifier.padding(bottom = 8.dp)
        )
        1 -> {
            if (!hasRecording) {
                AlertBox(
                    "Choose the recording you made this script from, and it will play here with the photos.",
                    AlertStyle.WARNING,
                    Modifier.padding(bottom = 4.dp)
                )
                SecondaryButton("🎙️ Choose the recording", onClick = onPickRecording)
            } else {
                Text(
                    state.alignment.recordingName?.let { "Playing: $it. " }.orEmpty() +
                        "Your own sound is the clock - the photos follow it. Drag the bar to any point to check that a photo changes exactly where its words are spoken.",
                    style = MaterialTheme.typography.bodySmall,
                    color = Muted,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
            }
        }
        else -> Text(
            "No sound in the preview or the exported video.",
            style = MaterialTheme.typography.bodySmall,
            color = Muted,
            modifier = Modifier.padding(bottom = 8.dp)
        )
    }

    if (state.previewLoadingAudio) {
        Text("Getting the sound ready…", style = MaterialTheme.typography.bodySmall, color = Muted, modifier = Modifier.padding(bottom = 8.dp))
    }
    state.previewAudioNote?.let {
        Text(it, style = MaterialTheme.typography.bodySmall, color = Yellow, modifier = Modifier.padding(bottom = 8.dp))
    }
}

@Composable
private fun RowScope.ChoiceChip(text: String, selected: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(10.dp)
    Box(
        Modifier
            .weight(1f)
            .heightIn(min = 48.dp)
            .clip(shape)
            .background(if (selected) Accent.copy(alpha = 0.22f) else Surface)
            .border(if (selected) 2.dp else 1.dp, if (selected) Accent else Outline, shape)
            .selectable(selected = selected, role = Role.RadioButton, onClick = onClick)
            .padding(horizontal = 4.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text,
            color = TextMain,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
            style = MaterialTheme.typography.labelLarge,
            maxLines = 1
        )
    }
}
