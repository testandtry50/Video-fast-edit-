package com.videoslidemaker.app.ui.screens

import android.content.Context
import android.net.Uri
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.BiasAlignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import coil.imageLoader
import coil.request.ImageRequest
import coil.size.Scale
import com.videoslidemaker.app.data.ScriptParser
import com.videoslidemaker.app.model.AppStep
import com.videoslidemaker.app.model.AudioSource
import com.videoslidemaker.app.model.EffectStyle
import com.videoslidemaker.app.model.OverlayStyle
import com.videoslidemaker.app.model.SentenceSlide
import com.videoslidemaker.app.model.TransitionStyle
import com.videoslidemaker.app.model.UiState
import com.videoslidemaker.app.ui.components.AlertBox
import com.videoslidemaker.app.ui.components.AlertStyle
import com.videoslidemaker.app.ui.components.BadgeChip
import com.videoslidemaker.app.ui.components.PrimaryButton
import com.videoslidemaker.app.ui.components.ScreenTitle
import com.videoslidemaker.app.ui.components.SecondaryButton
import com.videoslidemaker.app.ui.theme.Accent
import com.videoslidemaker.app.ui.theme.BorderColor
import com.videoslidemaker.app.ui.theme.CardBg
import com.videoslidemaker.app.ui.theme.Muted
import com.videoslidemaker.app.ui.theme.Surface
import com.videoslidemaker.app.ui.theme.TextMain
import com.videoslidemaker.app.ui.theme.Yellow
import com.videoslidemaker.app.viewmodel.AppViewModel

// Photos are always requested at this exact size, both when they are shown and when they are
// loaded ahead of time. An explicit size means the image does not have to wait for layout, and
// a photo that was loaded ahead of time is found in memory the instant its slide begins - no
// blank flash or hitch at the cut.
private const val PHOTO_W_PX = 1080
private const val PHOTO_H_PX = 810

private fun photoRequest(context: Context, uri: Uri): ImageRequest =
    ImageRequest.Builder(context)
        .data(uri)
        .size(PHOTO_W_PX, PHOTO_H_PX)
        .scale(Scale.FILL)
        .build()

/** How far (0..1) the preview is through slide [idx]'s own time window. Same math as the export. */
private fun slideProgress(state: UiState, timeline: List<SentenceSlide>, idx: Int, posSec: Double): Float {
    val start = timeline.getOrNull(idx)?.timestampSec ?: return 0f
    val duration = state.durationForIndex(idx).coerceAtLeast(0.1)
    return ((posSec - start) / duration).toFloat().coerceIn(0f, 1f)
}

@Composable
fun PreviewScreen(state: UiState, viewModel: AppViewModel, onPickRecording: () -> Unit) {
    // These only change when the photos/slides/settings change - NOT while playing.
    val timeline = remember(state.slides, state.images, state.settings.defaultDurationSec) { state.effectiveSlides }
    val sequence = remember(state.slides, state.images, state.settings.defaultDurationSec) { state.finalSequence() }
    val totalDuration = remember(state.slides, state.images, state.settings.defaultDurationSec) { state.totalDurationSec }

    // The moving position. It is only ever READ inside small pieces (graphicsLayer, the clock text,
    // the scrub bar), so this screen as a whole is not redrawn on every frame - only when the
    // slide number really changes.
    val posState = viewModel.previewPosition.collectAsState()
    val index by remember(timeline) {
        derivedStateOf {
            state.slideIndexAt(posState.value, timeline).coerceIn(0, (timeline.size - 1).coerceAtLeast(0))
        }
    }
    val currentSlide = timeline.getOrNull(index)

    // One tick per screen frame while playing, so the zoom/pan is as smooth as the screen itself.
    LaunchedEffect(state.previewPlaying) {
        if (state.previewPlaying) {
            while (true) {
                withFrameNanos { viewModel.previewFrame() }
            }
        }
    }
    // Leaving this screen (any way) must stop the sound.
    DisposableEffect(Unit) { onDispose { viewModel.stopPreview() } }

    // Load the next photos while the current one is on screen.
    val context = LocalContext.current
    val imageLoader = context.imageLoader
    LaunchedEffect(index, sequence) {
        for (ahead in 1..2) {
            val next = sequence.getOrNull(index + ahead) ?: break
            imageLoader.enqueue(photoRequest(context, next.uri))
        }
    }

    val effectStyle = state.settings.effectStyle

    Column(Modifier.fillMaxWidth().padding(16.dp)) {
        ScreenTitle("Preview", "Plays in real time with the same motion, timing, and sound your export will have.")

        Box(
            Modifier
                .fillMaxWidth()
                .height(280.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(CardBg),
            contentAlignment = Alignment.Center
        ) {
            if (sequence.isNotEmpty()) {
                // The slide NUMBER is what changes (not the photo), so each photo keeps moving on its
                // own time window while it fades out - it no longer jumps at the cut.
                AnimatedContent(
                    targetState = index,
                    transitionSpec = {
                        when (state.settings.transitionStyle) {
                            TransitionStyle.NONE -> fadeIn(tween(0)) togetherWith fadeOut(tween(0))
                            TransitionStyle.FADE_BLACK -> fadeIn(tween(300, delayMillis = 150)) togetherWith fadeOut(tween(150))
                            TransitionStyle.CROSSFADE -> fadeIn(tween(350)) togetherWith fadeOut(tween(350))
                            TransitionStyle.SLIDE -> slideInHorizontally(tween(350)) { it } togetherWith slideOutHorizontally(tween(350)) { -it }
                        }
                    },
                    label = "preview-photo"
                ) { idx ->
                    val image = sequence.getOrNull(idx)
                    if (image != null) {
                        val request = remember(image.uri) { photoRequest(context, image.uri) }
                        AsyncImage(
                            model = request,
                            contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(280.dp)
                                .graphicsLayer {
                                    // Read inside the layer block: only this layer is redrawn per frame.
                                    val p = slideProgress(state, timeline, idx, posState.value)
                                    val s = when (effectStyle) {
                                        EffectStyle.NONE -> 1f
                                        EffectStyle.ZOOM_IN -> 1f + p * 0.06f
                                        EffectStyle.ZOOM_OUT -> 1.06f - p * 0.06f
                                        EffectStyle.PAN_LEFT, EffectStyle.PAN_RIGHT -> 1.12f
                                    }
                                    // A simplified approximation of the export's pixel-accurate pan.
                                    val panDp = when (effectStyle) {
                                        EffectStyle.PAN_LEFT -> (0.5f - p) * 40f
                                        EffectStyle.PAN_RIGHT -> (p - 0.5f) * 40f
                                        else -> 0f
                                    }
                                    scaleX = s
                                    scaleY = s
                                    translationX = panDp * density
                                }
                        )
                    }
                }
            } else {
                Text("No photos yet", color = Muted)
            }
            if (currentSlide != null && currentSlide.text.isNotBlank()) {
                Box(
                    Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .background(Color.Black.copy(alpha = 0.55f))
                        .padding(10.dp)
                ) {
                    Text(currentSlide.text, color = Color.White, style = MaterialTheme.typography.bodyMedium)
                }
            }
            if (state.textOverlays.isNotEmpty()) {
                OverlaysLayer(state, posState)
            }
        }

        TimeRow(posState, totalDuration, index, timeline.size)
        ScrubBar(posState, totalDuration, viewModel)

        Row(
            Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            BadgeChip(state.settings.effectStyle.label, if (state.settings.effectStyle != EffectStyle.NONE) AlertStyle.SUCCESS else AlertStyle.INFO)
            BadgeChip(state.settings.transitionStyle.label, if (state.settings.transitionStyle != TransitionStyle.NONE) AlertStyle.SUCCESS else AlertStyle.INFO)
        }

        Row(
            Modifier.fillMaxWidth().padding(vertical = 12.dp),
            horizontalArrangement = Arrangement.Center
        ) {
            IconButton(onClick = viewModel::previewPrev, modifier = Modifier.size(52.dp)) {
                Icon(Icons.Filled.SkipPrevious, contentDescription = "Previous", tint = Muted, modifier = Modifier.size(30.dp))
            }
            IconButton(onClick = viewModel::previewTogglePlay, modifier = Modifier.size(64.dp).padding(horizontal = 12.dp)) {
                Icon(
                    if (state.previewPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                    contentDescription = "Play/Pause",
                    tint = Accent,
                    modifier = Modifier.size(40.dp)
                )
            }
            IconButton(onClick = viewModel::previewNext, modifier = Modifier.size(52.dp)) {
                Icon(Icons.Filled.SkipNext, contentDescription = "Next", tint = Muted, modifier = Modifier.size(30.dp))
            }
        }

        SoundChoice(state, viewModel, onPickRecording)

        PrimaryButton("Next — Export →", onClick = { viewModel.stopPreview(); viewModel.goStep(AppStep.EXPORT) })
        SecondaryButton("← Back to Text", onClick = { viewModel.stopPreview(); viewModel.goStep(AppStep.TEXT) })
    }
}

/** Elapsed / total and the slide number. Only this small row is redrawn as the clock moves. */
@Composable
private fun TimeRow(posState: State<Double>, totalDuration: Double, index: Int, slideCount: Int) {
    // changes once a second, not every frame
    val wholeSeconds by remember { derivedStateOf { posState.value.toInt() } }
    Row(
        Modifier.fillMaxWidth().padding(top = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            "${ScriptParser.formatClock(wholeSeconds.toDouble())} / ${ScriptParser.formatClock(totalDuration)}",
            style = MaterialTheme.typography.bodySmall,
            color = Muted
        )
        if (slideCount > 0) {
            Text("${index + 1} / $slideCount", style = MaterialTheme.typography.bodySmall, color = Muted)
        }
    }
}

/** Progress line you can drag - jump to any point to check that a photo changes exactly where its words are spoken. */
@Composable
private fun ScrubBar(posState: State<Double>, totalDuration: Double, viewModel: AppViewModel) {
    var dragging by remember { mutableStateOf(false) }
    var dragValue by remember { mutableFloatStateOf(0f) }
    val shown = if (dragging) {
        dragValue
    } else if (totalDuration <= 0.0) {
        0f
    } else {
        (posState.value / totalDuration).toFloat().coerceIn(0f, 1f)
    }
    Slider(
        value = shown,
        onValueChange = { dragging = true; dragValue = it },
        onValueChangeFinished = {
            viewModel.previewSeekToFraction(dragValue)
            dragging = false
        },
        colors = SliderDefaults.colors(
            thumbColor = Accent,
            activeTrackColor = Accent,
            inactiveTrackColor = BorderColor
        ),
        modifier = Modifier.fillMaxWidth()
    )
}

/** The character-name labels. Redrawn per frame, but it is only a handful of small items. */
@Composable
private fun BoxScope.OverlaysLayer(state: UiState, posState: State<Double>) {
    state.overlaysActiveAt(posState.value).forEach { (overlay, alpha) ->
        // Direct fraction -> bias mapping (0..1 fraction becomes Alignment's -1..1 bias). This uses
        // the exact same xFraction/yFraction as the drag editor and the real export.
        val overlayAlignment = BiasAlignment(
            horizontalBias = overlay.xFraction * 2f - 1f,
            verticalBias = overlay.yFraction * 2f - 1f
        )
        Box(
            Modifier
                .align(overlayAlignment)
                .alpha(alpha)
        ) {
            when (overlay.style) {
                OverlayStyle.TAG -> {
                    Row(
                        Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color.Black.copy(alpha = 0.75f)),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(Modifier.width(4.dp).height(26.dp).background(Accent))
                        Text(
                            overlay.text,
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                        )
                    }
                }
                OverlayStyle.UNDERLINE -> {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(overlay.text, color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                        Box(Modifier.padding(top = 4.dp).width(60.dp).height(3.dp).background(Accent))
                    }
                }
                OverlayStyle.MINIMAL -> {
                    Text(overlay.text, color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                }
            }
        }
    }
}

/** Voice / Original recording / Off - the same choice the export will use - plus what to expect from each. */
@Composable
private fun SoundChoice(state: UiState, viewModel: AppViewModel, onPickRecording: () -> Unit) {
    val narration = state.settings.narration
    val selected = when {
        !narration.enabled -> 2
        narration.source == AudioSource.ORIGINAL -> 1
        else -> 0
    }
    val hasRecording = state.alignment.recordingUri != null

    Text(
        "Sound",
        color = TextMain,
        fontWeight = FontWeight.Bold,
        style = MaterialTheme.typography.bodyMedium,
        modifier = Modifier.padding(bottom = 6.dp)
    )
    Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        ChoiceChip("🔊 Voice", selected == 0) { viewModel.setAudioSource(AudioSource.VOICE) }
        ChoiceChip("🎧 Original", selected == 1) { viewModel.setAudioSource(AudioSource.ORIGINAL) }
        ChoiceChip("🔇 Off", selected == 2) { viewModel.setNarrationEnabled(false) }
    }

    when (selected) {
        0 -> Text(
            "The phone's voice reads each sentence as its photo comes up.",
            style = MaterialTheme.typography.bodySmall,
            color = Muted,
            modifier = Modifier.padding(bottom = 8.dp)
        )
        1 -> {
            if (!hasRecording) {
                AlertBox(
                    "Choose the recording you made this script from, and it will play here with the photos.",
                    AlertStyle.WARNING,
                    Modifier.padding(bottom = 4.dp)
                )
                SecondaryButton("🎙️ Choose the recording", onClick = onPickRecording)
            } else {
                Text(
                    state.alignment.recordingName?.let { "Playing: $it. " }.orEmpty() +
                        "Your own sound is the clock - the photos follow it. Drag the bar to any point to check that a photo changes exactly where its words are spoken.",
                    style = MaterialTheme.typography.bodySmall,
                    color = Muted,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
            }
        }
        else -> Text(
            "No sound in the preview or the exported video.",
            style = MaterialTheme.typography.bodySmall,
            color = Muted,
            modifier = Modifier.padding(bottom = 8.dp)
        )
    }

    if (state.previewLoadingAudio) {
        Text("Opening your recording…", style = MaterialTheme.typography.bodySmall, color = Muted, modifier = Modifier.padding(bottom = 8.dp))
    }
    state.previewAudioNote?.let {
        Text(it, style = MaterialTheme.typography.bodySmall, color = Yellow, modifier = Modifier.padding(bottom = 8.dp))
    }
}

@Composable
private fun RowScope.ChoiceChip(text: String, selected: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(10.dp)
    Box(
        Modifier
            .weight(1f)
            .height(44.dp)
            .clip(shape)
            .background(if (selected) Accent.copy(alpha = 0.22f) else Surface)
            .border(1.dp, if (selected) Accent else BorderColor, shape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text,
            color = if (selected) TextMain else Muted,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
            style = MaterialTheme.typography.labelLarge,
            maxLines = 1
        )
    }
}
