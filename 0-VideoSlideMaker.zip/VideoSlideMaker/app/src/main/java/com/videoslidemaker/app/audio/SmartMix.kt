package com.videoslidemaker.app.audio

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * NEW (2.17): the "smart mix" - what makes background music sit properly under a voice with no manual work.
 * It is ordinary signal processing (a speech detector, a smoothed volume curve and a loudness match), so it is free,
 * works offline, needs no account and no AI service. All of it is mirrored in tools/audiomix-reference/smartmix.py,
 * where it is tested against synthetic speech.
 */
object SmartMix {
    const val WINDOW_MS = 20
    private const val SILENCE_DB = -55.0

    fun dbOf(linear: Double): Double = 20.0 * log10(max(linear, 1e-6))

    /**
     * Measures loudness as it streams past: one RMS value per 20 ms of sound, however long the sound is
     * (an hour is only 180,000 numbers). Feed it 16-bit little-endian PCM in whole frames.
     */
    class EnergyMeter(sampleRate: Int, private val channels: Int) {
        val framesPerWindow: Int = max(1, sampleRate * WINDOW_MS / 1000)
        private var out = FloatArray(1024)
        private var count = 0
        private var sumSq = 0.0
        private var framesInWindow = 0

        fun push(pcm: ByteArray, length: Int = pcm.size) {
            val frameBytes = channels * 2
            val frames = length / frameBytes
            var idx = 0
            for (f in 0 until frames) {
                var frameSq = 0.0
                for (c in 0 until channels) {
                    val lo = pcm[idx].toInt() and 0xFF
                    val hi = pcm[idx + 1].toInt()
                    val s = ((hi shl 8) or lo).toShort() / 32768.0
                    frameSq += s * s
                    idx += 2
                }
                sumSq += frameSq / channels
                framesInWindow++
                if (framesInWindow == framesPerWindow) {
                    add(sqrt(sumSq / framesPerWindow).toFloat())
                    sumSq = 0.0
                    framesInWindow = 0
                }
            }
        }

        private fun add(v: Float) {
            if (count == out.size) out = out.copyOf(out.size * 2)
            out[count++] = v
        }

        /** The RMS of every full 20 ms window heard so far (a trailing partial window is dropped). */
        fun result(): FloatArray = out.copyOf(count)
    }

    /** True for every 20 ms window where someone is speaking (or anything else as loud as speech is). */
    fun speechMask(rms: FloatArray): BooleanArray {
        val n = rms.size
        if (n == 0) return BooleanArray(0)
        val db = DoubleArray(n) { dbOf(rms[it].toDouble()) }
        val sorted = db.sortedArray()
        val floor = sorted[(n * 0.10).toInt().coerceAtMost(n - 1)]
        val peak = sorted[(n * 0.95).toInt().coerceAtMost(n - 1)]
        if (peak < SILENCE_DB) return BooleanArray(n)
        // No difference between the quiet and the loud parts: it is one continuous sound, so treat it all as voice.
        if (peak - floor < 8.0) return BooleanArray(n) { db[it] > -45.0 }
        val threshold = max(-50.0, floor + 0.3 * (peak - floor))
        return BooleanArray(n) { db[it] >= threshold }
    }

    /**
     * The music's volume (1 = untouched, [duckGain] = fully lowered) for every 20 ms window. The music starts lowering
     * [lookaheadMs] BEFORE the voice, stays lowered through short pauses ([holdMs]) so it does not pump up and down
     * between words, and swells back in [releaseMs].
     */
    fun duckGains(
        mask: BooleanArray,
        duckGain: Float,
        attackMs: Int = 60,
        releaseMs: Int = 400,
        holdMs: Int = 300,
        lookaheadMs: Int = 100
    ): FloatArray {
        val n = mask.size
        val hold = holdMs / WINDOW_MS
        val look = lookaheadMs / WINDOW_MS
        val far = Int.MAX_VALUE / 4
        val lastActive = IntArray(n)
        var prev = -far
        for (i in 0 until n) { if (mask[i]) prev = i; lastActive[i] = prev }
        val nextActive = IntArray(n)
        var next = far
        for (i in n - 1 downTo 0) { if (mask[i]) next = i; nextActive[i] = next }

        val out = FloatArray(n)
        var g = 1.0
        for (i in 0 until n) {
            val ducked = (i - lastActive[i] <= hold) || (nextActive[i] - i <= look)
            val target = if (ducked) duckGain.toDouble() else 1.0
            val tau = if (target < g) attackMs else releaseMs
            val a = 1.0 - exp(-WINDOW_MS.toDouble() / tau)
            g += (target - g) * a
            out[i] = g.toFloat()
        }
        return out
    }

    /** The curve's value at output frame [frame], smoothly between its 20 ms points so the volume never "steps". */
    fun gainAt(gains: FloatArray, frame: Long, framesPerWindow: Int): Float {
        if (gains.isEmpty()) return 1f
        if (frame < 0) return gains[0]
        val pos = frame.toDouble() / framesPerWindow
        val i = pos.toInt()
        if (i >= gains.size - 1) return gains[gains.size - 1]
        val frac = (pos - i).toFloat()
        return gains[i] + (gains[i + 1] - gains[i]) * frac
    }

    /** Average loudness (dB) of the windows where speech is happening; null when there is none. */
    fun activeLevelDb(rms: FloatArray, mask: BooleanArray): Double? {
        var total = 0.0
        var c = 0
        for (i in rms.indices) {
            if (i < mask.size && mask[i]) { total += rms[i].toDouble() * rms[i]; c++ }
        }
        return if (c == 0) null else dbOf(sqrt(total / c))
    }

    /** Average loudness (dB) of the music, ignoring near-silence; null for silence. */
    fun musicLevelDb(rms: FloatArray, gateDb: Double = -60.0): Double? {
        var total = 0.0
        var c = 0
        for (v in rms) {
            if (dbOf(v.toDouble()) > gateDb) { total += v.toDouble() * v; c++ }
        }
        return if (c == 0) null else dbOf(sqrt(total / c))
    }

    /** How far the music sits below the voice before any ducking: higher up when it will be ducked anyway. */
    fun bedOffsetDb(autoDuck: Boolean): Double = if (autoDuck) -10.0 else -18.0

    /** The gain that puts the music [offsetDb] from the voice. 1 when either is unknown (no voice = nothing to match). */
    fun autoLevelGain(voiceDb: Double?, musicDb: Double?, offsetDb: Double): Float {
        if (voiceDb == null || musicDb == null) return 1f
        val g = 10.0.pow((voiceDb + offsetDb - musicDb) / 20.0)
        return g.coerceIn(0.03, 6.0).toFloat()
    }

    /** A smooth fade curve: 0 at the clip's edges, 1 inside. [posSec] counts from the clip's start. */
    fun fade(posSec: Double, lengthSec: Double, fadeInSec: Double, fadeOutSec: Double): Float {
        if (lengthSec <= 0.0) return 0f
        var g = 1.0
        if (fadeInSec > 0.0 && posSec < fadeInSec) {
            val x = max(0.0, posSec / fadeInSec)
            g *= x * x * (3 - 2 * x)
        }
        val left = lengthSec - posSec
        if (fadeOutSec > 0.0 && left < fadeOutSec) {
            val x = max(0.0, left / fadeOutSec)
            g *= x * x * (3 - 2 * x)
        }
        return g.toFloat()
    }

    /**
     * NEW (2.19): the weight of the very short fade at the join of an exactly repeating sound. [edgeFrames] counts frames
     * from the nearest end of the round (0 = the first or last frame), [declickFrames] is the fade's length: the weight
     * rises smoothly from just above 0 at the edge to 1 [declickFrames] in. Outside the fade it is 1.
     */
    fun declickWeight(edgeFrames: Long, declickFrames: Long): Float {
        if (declickFrames <= 0L || edgeFrames >= declickFrames) return 1f
        val x = (edgeFrames.coerceAtLeast(0L) + 0.5) / declickFrames
        return (x * x * (3 - 2 * x)).toFloat()
    }

    /** Equal-power crossfade weights for the join of a looped track: at [x] 0..1 the new part is [sin], the old one [cos]. */
    fun crossIn(x: Double): Float = sin(x.coerceIn(0.0, 1.0) * PI / 2).toFloat()
    fun crossOut(x: Double): Float = cos(x.coerceIn(0.0, 1.0) * PI / 2).toFloat()

    /** Rounds off peaks above 0.8 (full scale = 1) instead of cutting them flat. Only touches the loud ones. */
    fun softClip(x: Float): Float {
        val a = if (x < 0) -x else x
        if (a <= 0.8f) return x
        val shaped = 0.8f + 0.2f * kotlin.math.tanh(((a - 0.8f) / 0.2f).toDouble()).toFloat()
        return if (x < 0) -shaped else shaped
    }

}
