package com.videoslidemaker.app.logoclean

import java.text.NumberFormat
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

/**
 * Small pure helpers for "clean ALL photos" runs over very large numbers of photos (100,000+).
 * Nothing here touches Android classes, so it is unit-tested on a plain JVM (see BulkMathTest).
 */
internal object BulkMath {
    /** Most photos worked on at the same time. More does not help: decoding and saving fight for the same phone. */
    const val MAX_WORKERS = 4

    /** Rough memory one photo being repainted can need, in MB (a 4096 px photo plus its working copies). */
    const val MB_PER_WORKER = 160L

    /** A cleaned JPEG is about this many bytes per pixel at the bulk quality (video frames are smooth, so small). */
    const val JPEG_BYTES_PER_PIXEL = 0.30

    /** A cleaned PNG is about this many bytes per pixel. */
    const val PNG_BYTES_PER_PIXEL = 1.5

    /** Photos with an unknown size are counted as a 1920 x 1080 frame. */
    private const val UNKNOWN_PIXELS = 1920L * 1080L

    /**
     * How many photos to repaint at once: leave one CPU core free for the screen, never more than
     * [MAX_WORKERS], and never more than the app's memory allows ([MB_PER_WORKER] each). At least 1.
     */
    fun workerCount(cores: Int, maxHeapBytes: Long): Int {
        val byCpu = (cores - 1).coerceIn(1, MAX_WORKERS)
        val byHeap = (maxHeapBytes / (MB_PER_WORKER * 1024L * 1024L)).coerceIn(1L, MAX_WORKERS.toLong()).toInt()
        return min(byCpu, byHeap)
    }

    /** Whole percent done, rounded DOWN so it only reads 100% when really finished. */
    fun percent(done: Int, total: Int): Int {
        if (total <= 0) return 0
        return ((done.toLong() * 100L) / total).toInt().coerceIn(0, 100)
    }

    /** Seconds left at the speed so far, or -1 while there is not enough to go on yet. */
    fun etaSeconds(done: Int, total: Int, elapsedMs: Long): Long {
        if (done < 3 || elapsedMs < 2_000L || total <= done) return -1L
        val perSecond = done * 1000.0 / elapsedMs
        if (perSecond <= 0.0) return -1L
        return ((total - done) / perSecond + 0.5).toLong()
    }

    /** "under a minute", "12 min", "1 h 5 min", "3 h". Empty for an unknown (negative) time. */
    fun formatDuration(seconds: Long): String {
        if (seconds < 0) return ""
        if (seconds < 45) return "under a minute"
        val totalMin = (seconds + 30) / 60
        if (totalMin < 60) return "$totalMin min"
        val h = totalMin / 60
        val m = totalMin % 60
        return if (m == 0L) "$h h" else "$h h $m min"
    }

    /** "850 KB", "420 MB", "48.3 GB". */
    fun formatBytes(bytes: Long, locale: Locale = Locale.getDefault()): String {
        val b = max(0L, bytes)
        return when {
            b < 1024L * 1024L -> "${b / 1024L} KB"
            b < 1024L * 1024L * 1024L -> String.format(locale, "%.0f MB", b / (1024.0 * 1024.0))
            else -> String.format(locale, "%.1f GB", b / (1024.0 * 1024.0 * 1024.0))
        }
    }

    /** 100000 -> "100,000" (or the phone's own style). */
    fun formatCount(n: Int, locale: Locale = Locale.getDefault()): String =
        NumberFormat.getIntegerInstance(locale).format(n.toLong())

    /** Photos per second as "38 photos/s" or "0.4 photos/s". */
    fun formatRate(perSecond: Float, locale: Locale = Locale.getDefault()): String =
        if (perSecond >= 10f) String.format(locale, "%.0f photos/s", perSecond)
        else String.format(locale, "%.1f photos/s", perSecond)

    /**
     * Rough size of the cleaned copy of one photo. Photos longer than [LogoCleaner.MAX_EDGE] are saved
     * scaled down to it, so the estimate is scaled down the same way.
     */
    fun estimateOutputBytes(widthPx: Int, heightPx: Int, lossless: Boolean): Long {
        var pixels = if (widthPx > 0 && heightPx > 0) widthPx.toLong() * heightPx.toLong() else UNKNOWN_PIXELS
        if (widthPx > 0 && heightPx > 0) {
            val longEdge = max(widthPx, heightPx)
            if (longEdge > LogoCleaner.MAX_EDGE) {
                val scale = LogoCleaner.MAX_EDGE.toDouble() / longEdge
                pixels = (pixels * scale * scale).toLong()
            }
        }
        val perPixel = if (lossless) PNG_BYTES_PER_PIXEL else JPEG_BYTES_PER_PIXEL
        return (pixels * perPixel).toLong()
    }
}
