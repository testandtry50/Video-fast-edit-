package com.videoslidemaker.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.videoslidemaker.app.data.ScriptParser
import com.videoslidemaker.app.model.AudioSource
import com.videoslidemaker.app.model.PreviewSpeed
import com.videoslidemaker.app.model.UiState
import com.videoslidemaker.app.ui.components.AlertBox
import com.videoslidemaker.app.ui.components.AlertStyle
import com.videoslidemaker.app.ui.components.SectionCard
import com.videoslidemaker.app.ui.components.appSliderColors
import com.videoslidemaker.app.ui.theme.Accent
import com.videoslidemaker.app.ui.theme.Muted
import com.videoslidemaker.app.ui.theme.Outline
import com.videoslidemaker.app.ui.theme.Surface
import com.videoslidemaker.app.ui.theme.TextMain
import com.videoslidemaker.app.viewmodel.AppViewModel
import kotlin.math.abs

/** A photo that stays on screen for less than this many real seconds is "quick" - it can be missed. */
private const val QUICK_SEC = 1.0

/** The small step buttons: how much one tap changes the speed. */
private val SPEED_NUDGES = listOf(
    -0.25f to "−0.25",
    -0.05f to "−0.05",
    0.05f to "+0.05",
    0.25f to "+0.25"
)

/**
 * NEW (2.8): playback speed for the Preview, like the speed menu on YouTube. People watch videos faster
 * and slower than they were made; this shows (and plays) your video that way, so you can see how the
 * photos, the text and the sound come across.
 *
 *  - One-tap speeds from 0.25x to 3x.
 *  - A slider from 0.25x to 4x on a log scale (normal speed is in the middle), and small step buttons,
 *    for every speed in between.
 *  - What the speed means for THIS video: how long it takes to watch, how long the shortest photo is
 *    on screen, and a warning when speeding up would make photos flash by too quickly.
 *
 * It only changes the preview. The exported video is always at normal speed.
 */
@Composable
fun PreviewSpeedPanel(
    state: UiState,
    viewModel: AppViewModel,
    slideCount: Int,
    totalDurationSec: Double,
    modifier: Modifier = Modifier
) {
    val speed = state.previewSpeed
    val isNormal = PreviewSpeed.same(speed, PreviewSpeed.NORMAL)

    // Looking at every photo's length is one pass over the list. It is done again only when the photos or
    // times change (and, for the "at this speed" count, when the speed changes) - not on every redraw.
    val shortestSec = remember(state.slides, state.images, state.settings.defaultDurationSec) {
        PreviewSpeed.shortest(slideCount) { state.durationForIndex(it) }
    }
    val quickAtNormal = remember(state.slides, state.images, state.settings.defaultDurationSec) {
        PreviewSpeed.countBelow(slideCount, QUICK_SEC, PreviewSpeed.NORMAL) { state.durationForIndex(it) }
    }
    val quickAtSpeed = remember(state.slides, state.images, state.settings.defaultDurationSec, speed) {
        PreviewSpeed.countBelow(slideCount, QUICK_SEC, speed) { state.durationForIndex(it) }
    }

    SectionCard(modifier = modifier) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(
                "⏩ Playback speed",
                color = TextMain,
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.titleSmall,
                modifier = Modifier.weight(1f)
            )
            Text(
                PreviewSpeed.label(speed),
                color = Accent,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                style = MaterialTheme.typography.titleLarge,
                modifier = Modifier.padding(start = 12.dp)
            )
        }
        // full width (not squeezed next to the big number), so it reads well on a narrow phone
        Text(
            "See and hear your video the way viewers who speed it up or slow it down do. " +
                "Only this preview changes - the exported video is always normal speed.",
            color = Muted,
            style = MaterialTheme.typography.bodySmall,
            modifier = Modifier.padding(top = 2.dp)
        )

        for (rowItems in PreviewSpeed.PRESETS.chunked(4)) {
            Row(
                Modifier.fillMaxWidth().padding(top = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                for (preset in rowItems) {
                    SpeedChip(PreviewSpeed.label(preset), PreviewSpeed.same(speed, preset), PreviewSpeed.spoken(preset)) {
                        viewModel.previewSetSpeed(preset)
                    }
                }
            }
        }

        Slider(
            value = PreviewSpeed.toSlider(speed),
            onValueChange = { viewModel.previewSetSpeed(PreviewSpeed.fromSlider(it)) },
            valueRange = 0f..1f,
            colors = appSliderColors(),
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 8.dp)
                .semantics {
                    contentDescription = "Playback speed"
                    stateDescription = PreviewSpeed.spoken(speed)
                }
        )
        Row(Modifier.fillMaxWidth()) {
            Text(
                "◀ ${PreviewSpeed.label(PreviewSpeed.MIN)} slower",
                color = Muted,
                style = MaterialTheme.typography.labelSmall,
                modifier = Modifier.weight(1f)
            )
            // normal speed is exactly in the middle of the slider
            Text(PreviewSpeed.label(PreviewSpeed.NORMAL), color = Muted, style = MaterialTheme.typography.labelSmall)
            Text(
                "faster ${PreviewSpeed.label(PreviewSpeed.MAX)} ▶",
                color = Muted,
                style = MaterialTheme.typography.labelSmall,
                textAlign = TextAlign.End,
                modifier = Modifier.weight(1f)
            )
        }

        Row(
            Modifier.fillMaxWidth().padding(top = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            for ((delta, text) in SPEED_NUDGES) {
                SpeedNudge(text, (if (delta < 0f) "Slower by " else "Faster by ") + abs(delta)) {
                    viewModel.previewSetSpeed(PreviewSpeed.nudge(speed, delta))
                }
            }
        }

        // What this speed means for THIS video
        val normalTime = ScriptParser.formatClock(totalDurationSec)
        Text(
            if (isNormal) {
                "Watch time: $normalTime"
            } else {
                "Watch time at ${PreviewSpeed.label(speed)}: " +
                    ScriptParser.formatClock(PreviewSpeed.watchSeconds(totalDurationSec, speed)) +
                    " (normal: $normalTime)"
            },
            color = TextMain,
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.padding(top = 12.dp)
        )
        if (slideCount > 0) {
            Text(
                "Shortest photo on screen: " + onScreenTime(PreviewSpeed.watchSeconds(shortestSec, speed)),
                color = Muted,
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.padding(top = 2.dp)
            )
        }

        if (speed > PreviewSpeed.NORMAL && quickAtSpeed > quickAtNormal) {
            val atNormal = if (quickAtNormal > 0) " ($quickAtNormal at normal speed)" else ""
            AlertBox(
                "At ${PreviewSpeed.label(speed)}, $quickAtSpeed of $slideCount photos stay on screen for less than " +
                    "1 second$atNormal. Fast viewers may barely see them.",
                AlertStyle.WARNING,
                Modifier.padding(top = 10.dp)
            )
        }

        val narration = state.settings.narration
        val plainPhoneVoice = narration.enabled && narration.source == AudioSource.VOICE && !narration.voiceFx.isActive
        if (plainPhoneVoice && speed > 2f) {
            Text(
                "The phone's voice may not keep up above 2×: sentences can run late or get cut off. " +
                    "This is only the preview - your exported video is not affected.",
                color = Muted,
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.padding(top = 8.dp)
            )
        }
    }
}

/**
 * NEW (2.8): the speed button that sits next to the play button, so the speed can be changed without
 * scrolling away from the picture. It shows the current speed; each tap goes to the next common speed
 * (0.5x, 1x, 1.5x, 2x, 3x, then round again). The card below has every other speed.
 */
@Composable
fun PreviewSpeedButton(speed: Float, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(10.dp)
    val normal = PreviewSpeed.same(speed, PreviewSpeed.NORMAL)
    Box(
        modifier
            .heightIn(min = 48.dp)
            .clip(shape)
            .background(if (normal) Surface else Accent.copy(alpha = 0.22f))
            .border(if (normal) 1.dp else 2.dp, if (normal) Outline else Accent, shape)
            .semantics { contentDescription = "Playback speed: " + PreviewSpeed.spoken(speed) + ". Tap to change." }
            .clickable(role = Role.Button, onClick = onClick)
            .padding(horizontal = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            PreviewSpeed.label(speed),
            color = TextMain,
            fontWeight = FontWeight.Bold,
            style = MaterialTheme.typography.labelLarge,
            maxLines = 1
        )
    }
}

/** "0.4 s", "12 s", or m:ss once it is a minute or more. */
private fun onScreenTime(seconds: Double): String =
    if (seconds < 60.0) PreviewSpeed.formatShort(seconds) else ScriptParser.formatClock(seconds)

// ---------------------------------------------------------------------------------------------
// Small building blocks (built from Box, not Button, so rows of them always fit side by side on a phone)
// ---------------------------------------------------------------------------------------------

@Composable
private fun RowScope.SpeedChip(text: String, selected: Boolean, description: String, onClick: () -> Unit) {
    val shape = RoundedCornerShape(10.dp)
    Box(
        Modifier
            .weight(1f)
            .heightIn(min = 48.dp)
            .clip(shape)
            .background(if (selected) Accent.copy(alpha = 0.22f) else Surface)
            .border(if (selected) 2.dp else 1.dp, if (selected) Accent else Outline, shape)
            .semantics { contentDescription = description }
            .selectable(selected = selected, role = Role.RadioButton, onClick = onClick)
            .padding(horizontal = 4.dp, vertical = 6.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text,
            color = TextMain,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
            style = MaterialTheme.typography.labelMedium,
            textAlign = TextAlign.Center,
            maxLines = 1
        )
    }
}

@Composable
private fun RowScope.SpeedNudge(text: String, description: String, onClick: () -> Unit) {
    val shape = RoundedCornerShape(10.dp)
    Box(
        Modifier
            .weight(1f)
            .heightIn(min = 48.dp)
            .clip(shape)
            .background(Surface)
            .border(1.dp, Outline, shape)
            .semantics { contentDescription = description }
            .clickable(role = Role.Button, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = TextMain, style = MaterialTheme.typography.labelMedium, maxLines = 1)
    }
}
