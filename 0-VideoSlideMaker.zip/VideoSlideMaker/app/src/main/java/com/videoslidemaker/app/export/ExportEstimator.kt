package com.videoslidemaker.app.export

import kotlin.math.max
import kotlin.math.min

/** What the export screen and the notification show about a running export. */
data class ExportStats(
    /** Overall progress, 0..1. Never goes backwards. */
    val fraction: Double,
    /** Bytes written to the output so far. */
    val processedBytes: Long,
    /** The best current guess of the final size: the plan at first, the measured rate once there is enough to measure. */
    val estimatedTotalBytes: Long,
    val elapsedMs: Long,
    /** Time left, or null while it is too early to say anything honest. */
    val remainingMs: Long?
) {
    val percent: Int get() = (fraction * 100.0).toInt().coerceIn(0, 100)
}

/**
 * Turns "how far along are we, and how many bytes are written" into the numbers shown to the user.
 *
 *  - **Remaining time** comes from the speed over the last [windowMs] (not the whole run, because the audio stage and the
 *    picture stage run at very different speeds), smoothed so the figure counts down instead of jumping, and withheld
 *    until there is something to measure.
 *  - **Final size** starts as the plan's estimate and moves to the measured `bytes / fraction` as the export proceeds, so a
 *    wrong plan corrects itself. It is never smaller than what is already written.
 *
 * The clock is passed in, so this is plain testable code.
 */
class RateEstimator(
    private val plannedTotalBytes: Long,
    private val startMs: Long,
    private val windowMs: Long = 60_000L
) {
    private class Sample(val timeMs: Long, val fraction: Double)

    private val samples = ArrayDeque<Sample>()
    private var lastFraction = 0.0
    private var lastRemaining: Double? = null
    private var lastRemainingAt = 0L

    fun update(nowMs: Long, fraction: Double, bytesWritten: Long): ExportStats {
        val f = max(lastFraction, fraction.coerceIn(0.0, 1.0))
        lastFraction = f
        val elapsed = max(0L, nowMs - startMs)
        val bytes = max(0L, bytesWritten)

        samples.addLast(Sample(nowMs, f))
        while (samples.size > 2 && nowMs - samples.first().timeMs > windowMs) samples.removeFirst()

        return ExportStats(f, bytes, projectedBytes(f, bytes), elapsed, remaining(nowMs, f, elapsed))
    }

    private fun projectedBytes(f: Double, bytes: Long): Long {
        if (f >= 1.0) return bytes
        val observed = if (f >= MIN_FRACTION_FOR_SIZE && bytes > 0L) bytes / f else null
        val estimate = when {
            observed == null -> plannedTotalBytes.toDouble()
            plannedTotalBytes <= 0L -> observed
            else -> {
                val w = ((f - MIN_FRACTION_FOR_SIZE) / (FULL_TRUST_FRACTION - MIN_FRACTION_FOR_SIZE)).coerceIn(0.0, 1.0)
                (1.0 - w) * plannedTotalBytes + w * observed
            }
        }
        return max(bytes, Math.round(estimate))
    }

    private fun remaining(nowMs: Long, f: Double, elapsed: Long): Long? {
        if (f >= 1.0) {
            lastRemaining = 0.0
            lastRemainingAt = nowMs
            return 0L
        }
        if (elapsed < MIN_ELAPSED_MS || f < MIN_FRACTION_FOR_TIME) return null
        val oldest = samples.first()
        val dt = nowMs - oldest.timeMs
        val df = f - oldest.fraction
        // speed over the window; before the window has anything in it, over the whole run
        val rate = if (dt >= MIN_WINDOW_MS && df > 0.0) df / dt else f / elapsed
        if (rate <= 0.0) return lastRemaining?.let { max(0.0, it - (nowMs - lastRemainingAt)).toLong() }
        val raw = (1.0 - f) / rate
        val previous = lastRemaining
        val smoothed = if (previous == null) raw else {
            val carried = max(0.0, previous - (nowMs - lastRemainingAt))     // what the old figure says is left by now
            (1.0 - SMOOTHING) * carried + SMOOTHING * raw
        }
        lastRemaining = smoothed
        lastRemainingAt = nowMs
        return min(smoothed, MAX_REMAINING_MS).toLong()
    }

    private companion object {
        const val MIN_ELAPSED_MS = 10_000L
        const val MIN_WINDOW_MS = 5_000L
        const val MIN_FRACTION_FOR_TIME = 0.005
        const val MIN_FRACTION_FOR_SIZE = 0.02
        const val FULL_TRUST_FRACTION = 0.20
        const val SMOOTHING = 0.25
        const val MAX_REMAINING_MS = 1000.0 * 3600.0 * 24.0 * 400.0     // a figure beyond a year is not an estimate
    }
}
