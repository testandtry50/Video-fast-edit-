package com.videoslidemaker.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.videoslidemaker.app.model.AudioSource
import com.videoslidemaker.app.model.UiState
import com.videoslidemaker.app.ui.components.SecondaryButton
import com.videoslidemaker.app.ui.components.SectionCard
import com.videoslidemaker.app.ui.components.SettingToggleRow
import com.videoslidemaker.app.ui.components.appSliderColors
import com.videoslidemaker.app.ui.theme.Accent
import com.videoslidemaker.app.ui.theme.Muted
import com.videoslidemaker.app.ui.theme.Outline
import com.videoslidemaker.app.ui.theme.Surface
import com.videoslidemaker.app.ui.theme.TextMain
import com.videoslidemaker.app.viewmodel.AppViewModel
import com.videoslidemaker.app.voicefx.VoiceEffect
import com.videoslidemaker.app.voicefx.VoiceFxSettings
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.roundToInt

/** How far the pitch slider reaches. Smaller = each finger-width of the slider is a finer change. */
private val PITCH_RANGES = listOf(1f, 3f, 12f, 24f)
private val PITCH_RANGE_LABELS = listOf("Fine ±1", "±3", "±12", "±24")

/**
 * NEW: the voice changer. One panel for both ways of getting sound (the phone's voice and your own
 * recording) - on the Script screen and under the player on the Preview screen.
 *
 *  - Pitch: one slider that can be zoomed from "fine" (±1 semitone across the whole width) to "wide"
 *    (±24), small step buttons from 0.01 to 1, and an exact value you can type.
 *  - Make it sound human: for AI voices that sound too clean.
 *  - Voice effects: Aqua (underwater), Revolve 8D, Room/Hall/Cave, Echo, Robot, Telephone, Megaphone, Whisper.
 *  - "Hear a sample" so every change can be heard right away.
 */
@Composable
fun VoiceChangerPanel(state: UiState, viewModel: AppViewModel, modifier: Modifier = Modifier) {
    val fx = state.settings.narration.voiceFx
    var expanded by rememberSaveable { mutableStateOf(false) }

    SectionCard(modifier = modifier) {
        Row(
            Modifier
                .fillMaxWidth()
                .heightIn(min = 56.dp)
                .clickable(onClickLabel = if (expanded) "Hide the voice changer" else "Show the voice changer", role = Role.Button) {
                    expanded = !expanded
                },
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text("🎚️ Voice changer", color = TextMain, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                Text(
                    fx.summary(),
                    color = if (fx.isActive) Accent else Muted,
                    style = MaterialTheme.typography.bodySmall
                )
            }
            Text(if (expanded) "▲" else "▼", color = Muted, style = MaterialTheme.typography.titleMedium)
        }

        if (expanded) {
            PitchSection(fx, viewModel)
            SectionDivider()
            HumanSection(fx, viewModel)
            SectionDivider()
            EffectSection(fx, viewModel)
            SectionDivider()
            SampleSection(state, fx, viewModel)
        }
    }
}

@Composable
private fun SectionDivider() {
    Spacer(Modifier.height(10.dp))
    Box(Modifier.fillMaxWidth().height(1.dp).background(Outline.copy(alpha = 0.5f)))
    Spacer(Modifier.height(10.dp))
}

@Composable
private fun Heading(text: String) {
    Text(text, color = TextMain, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyLarge)
}

@Composable
private fun Hint(text: String, modifier: Modifier = Modifier) {
    Text(text, color = Muted, style = MaterialTheme.typography.bodySmall, modifier = modifier)
}

@Composable
private fun FxValueRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = TextMain, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
        Text(value, color = Accent, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, style = MaterialTheme.typography.bodyMedium)
    }
}

// ---------------------------------------------------------------------------------------------
// Pitch
// ---------------------------------------------------------------------------------------------

private fun describePitch(st: Float): String {
    val hundredths = (st * 100f).roundToInt()
    if (hundredths == 0) return "Original pitch"
    val a = abs(hundredths)
    val amount = (a / 100).toString() + "." + (a % 100).toString().padStart(2, '0')
    return (if (hundredths > 0) "Higher" else "Lower") + " by $amount semitones ($a cents)"
}

@Composable
private fun PitchSection(fx: VoiceFxSettings, viewModel: AppViewModel) {
    var rangeIndex by rememberSaveable { mutableStateOf(2) }
    val pitch = fx.pitchSemitones
    // if the pitch is already beyond the chosen range (typed in, or saved earlier), widen the slider to fit it
    val rangeMax = max(PITCH_RANGES[rangeIndex], ceil(abs(pitch)))
    val rangeLabel = rangeMax.roundToInt()

    Heading("🎵 Pitch")
    FxValueRow(describePitch(pitch), VoiceFxSettings.formatPitch(pitch) + " st")
    Hint(
        "Higher or lower, without changing the speed. Choose how far the slider reaches, then drag. " +
            "\"Fine\" makes the whole slider cover just ±1 semitone, so tiny changes are easy.",
        Modifier.padding(top = 2.dp, bottom = 8.dp)
    )

    Row(Modifier.fillMaxWidth().padding(bottom = 4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        for (i in PITCH_RANGES.indices) {
            OptionChip(PITCH_RANGE_LABELS[i], selected = rangeIndex == i, description = "Slider range ${PITCH_RANGE_LABELS[i]}") {
                rangeIndex = i
            }
        }
    }

    Slider(
        value = pitch.coerceIn(-rangeMax, rangeMax),
        onValueChange = { viewModel.setPitch(it) },
        valueRange = -rangeMax..rangeMax,
        colors = appSliderColors(),
        modifier = Modifier
            .fillMaxWidth()
            .semantics {
                contentDescription = "Pitch"
                stateDescription = describePitch(pitch)
            }
    )
    Row(Modifier.fillMaxWidth()) {
        Text("−$rangeLabel", color = Muted, style = MaterialTheme.typography.labelSmall, modifier = Modifier.weight(1f))
        Text("0", color = Muted, style = MaterialTheme.typography.labelSmall)
        Text("+$rangeLabel", color = Muted, style = MaterialTheme.typography.labelSmall, textAlign = TextAlign.End, modifier = Modifier.weight(1f))
    }

    Row(Modifier.fillMaxWidth().padding(top = 8.dp)) {
        Text("◀ lower", color = Muted, style = MaterialTheme.typography.labelSmall, modifier = Modifier.weight(1f))
        Text("higher ▶", color = Muted, style = MaterialTheme.typography.labelSmall, textAlign = TextAlign.End, modifier = Modifier.weight(1f))
    }
    Row(Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        for ((delta, text) in PITCH_NUDGES) {
            NudgeButton(text, description = "${if (delta < 0f) "Lower" else "Raise"} the pitch by ${abs(delta)} semitone") {
                viewModel.nudgePitch(delta)
            }
        }
    }

    ExactPitchField(pitch, viewModel)

    if (abs(pitch) > 4f) {
        Hint(
            "Big changes also change the character of the voice (very high sounds like a chipmunk, very low like a giant). " +
                "Changes of about ±3 keep it natural.",
            Modifier.padding(top = 6.dp)
        )
    }
}

private val PITCH_NUDGES = listOf(
    -1f to "−1",
    -0.1f to "−0.1",
    -0.01f to "−0.01",
    0.01f to "+0.01",
    0.1f to "+0.1",
    1f to "+1"
)

@Composable
private fun ExactPitchField(pitch: Float, viewModel: AppViewModel) {
    val shown = VoiceFxSettings.formatPitch(pitch)
    var text by remember(pitch) { mutableStateOf(shown) }
    val focus = LocalFocusManager.current

    fun commit() {
        val value = text.trim().replace(',', '.').toFloatOrNull()
        if (value == null || value.isNaN()) {
            text = shown // not a number: put back what is really set
        } else {
            viewModel.setPitch(value)
        }
        focus.clearFocus()
    }

    Row(Modifier.fillMaxWidth().padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        OutlinedTextField(
            value = text,
            onValueChange = { typed -> text = typed.filter { c -> c.isDigit() || c == '.' || c == ',' || c == '-' || c == '+' }.take(7) },
            label = { Text("Exact pitch (−24 to +24 semitones)") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text, imeAction = ImeAction.Done),
            keyboardActions = KeyboardActions(onDone = { commit() }),
            modifier = Modifier.weight(1f)
        )
        Spacer(Modifier.width(8.dp))
        SmallButton("Set", "Apply the typed pitch", Modifier.width(64.dp)) { commit() }
        Spacer(Modifier.width(6.dp))
        SmallButton("0", "Reset pitch to the original", Modifier.width(48.dp)) { viewModel.setPitch(0f) }
    }
}

// ---------------------------------------------------------------------------------------------
// Make it sound human
// ---------------------------------------------------------------------------------------------

@Composable
private fun HumanSection(fx: VoiceFxSettings, viewModel: AppViewModel) {
    Heading("🧑 Make it sound human")
    Hint(
        "For AI voices (ElevenLabs and others) that sound too clean or perfect. Adds what a real recording has: " +
            "a tiny natural pitch drift, warmth, gentle dynamics, a faint room tone and small room reflections.",
        Modifier.padding(top = 2.dp)
    )
    FxValueRow("Strength", if (fx.humanize <= 0.001f) "Off" else "${(fx.humanize * 100f).roundToInt()}%")
    Slider(
        value = fx.humanize,
        onValueChange = { viewModel.setHumanize(it) },
        valueRange = 0f..1f,
        colors = appSliderColors(),
        modifier = Modifier
            .fillMaxWidth()
            .semantics {
                contentDescription = "Human sound strength"
                stateDescription = "${(fx.humanize * 100f).roundToInt()} percent"
            }
    )
    Hint("Most AI voices sound best at 40–60%. Go higher only if you want an obviously \"recorded\" sound.")
    SettingToggleRow(
        "Natural breaths",
        "A soft breath in real pauses between sentences (only after speech, never on top of words)",
        fx.breaths,
        viewModel::setBreaths
    )
}

// ---------------------------------------------------------------------------------------------
// Effects
// ---------------------------------------------------------------------------------------------

@Composable
private fun EffectSection(fx: VoiceFxSettings, viewModel: AppViewModel) {
    Heading("🎭 Voice effect")
    Hint("Pick one. It is added after the pitch and the human sound.", Modifier.padding(top = 2.dp, bottom = 8.dp))

    for (rowItems in VoiceEffect.entries.chunked(3)) {
        Row(Modifier.fillMaxWidth().padding(bottom = 6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            for (effect in rowItems) {
                OptionChip(
                    "${effect.emoji} ${effect.label}",
                    selected = fx.effect == effect,
                    description = "Effect: ${effect.label}"
                ) { viewModel.setVoiceEffect(effect) }
            }
            for (i in 0 until 3 - rowItems.size) Spacer(Modifier.weight(1f))
        }
    }

    if (fx.effect != VoiceEffect.NONE) {
        Hint(fx.effect.hint, Modifier.padding(top = 2.dp))
        val strengthLabel = if (fx.effect == VoiceEffect.REVOLVE) "Circle width" else "Strength"
        FxValueRow(strengthLabel, "${(fx.effectAmount * 100f).roundToInt()}%")
        Slider(
            value = fx.effectAmount,
            onValueChange = { viewModel.setEffectAmount(it) },
            valueRange = 0f..1f,
            colors = appSliderColors(),
            modifier = Modifier
                .fillMaxWidth()
                .semantics {
                    contentDescription = "Effect $strengthLabel"
                    stateDescription = "${(fx.effectAmount * 100f).roundToInt()} percent"
                }
        )
        val speedLabel = fx.effect.speedLabel
        if (speedLabel != null) {
            FxValueRow(speedLabel, "${(fx.effectSpeed * 100f).roundToInt()}%")
            Slider(
                value = fx.effectSpeed,
                onValueChange = { viewModel.setEffectSpeed(it) },
                valueRange = 0f..1f,
                colors = appSliderColors(),
                modifier = Modifier
                    .fillMaxWidth()
                    .semantics {
                        contentDescription = speedLabel
                        stateDescription = "${(fx.effectSpeed * 100f).roundToInt()} percent"
                    }
            )
        }
    }
}

// ---------------------------------------------------------------------------------------------
// Hear it / reset
// ---------------------------------------------------------------------------------------------

@Composable
private fun SampleSection(state: UiState, fx: VoiceFxSettings, viewModel: AppViewModel) {
    val fromRecording = state.settings.narration.source == AudioSource.ORIGINAL
    SecondaryButton(
        if (state.previewLoadingAudio) "Getting the sample ready…" else "▶ Hear a sample",
        enabled = !state.previewPlaying && !state.previewLoadingAudio,
        onClick = viewModel::auditionVoiceFx
    )
    Hint(
        if (fromRecording) {
            "Plays about 8 seconds of your recording with these settings. You can also press play on the preview and move the sliders while it plays."
        } else {
            "Speaks one sentence of your script with these settings. You can also press play on the preview and move the sliders while it plays."
        }
    )
    state.previewAudioNote?.let {
        Text(it, color = com.videoslidemaker.app.ui.theme.Yellow, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 6.dp))
    }
    if (fx.isActive) {
        SecondaryButton("Reset the voice changer", modifier = Modifier.padding(top = 4.dp), onClick = viewModel::resetVoiceFx)
    }
}

// ---------------------------------------------------------------------------------------------
// Small building blocks (built from Box, not Button, so rows of them always fit side by side on a phone)
// ---------------------------------------------------------------------------------------------

@Composable
private fun RowScope.OptionChip(text: String, selected: Boolean, description: String, onClick: () -> Unit) {
    val shape = RoundedCornerShape(10.dp)
    Box(
        Modifier
            .weight(1f)
            .heightIn(min = 48.dp)
            .clip(shape)
            .background(if (selected) Accent.copy(alpha = 0.22f) else Surface)
            .border(if (selected) 2.dp else 1.dp, if (selected) Accent else Outline, shape)
            .semantics { contentDescription = description }
            .selectable(selected = selected, role = Role.RadioButton, onClick = onClick)
            .padding(horizontal = 4.dp, vertical = 6.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text,
            color = TextMain,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
            style = MaterialTheme.typography.labelMedium,
            textAlign = TextAlign.Center,
            maxLines = 2
        )
    }
}

@Composable
private fun RowScope.NudgeButton(text: String, description: String, onClick: () -> Unit) {
    val shape = RoundedCornerShape(10.dp)
    Box(
        Modifier
            .weight(1f)
            .heightIn(min = 48.dp)
            .clip(shape)
            .background(Surface)
            .border(1.dp, Outline, shape)
            .semantics { contentDescription = description }
            .clickable(role = Role.Button, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = TextMain, style = MaterialTheme.typography.labelMedium, maxLines = 1)
    }
}

@Composable
private fun SmallButton(text: String, description: String, modifier: Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(10.dp)
    Box(
        modifier
            .heightIn(min = 48.dp)
            .clip(shape)
            .background(Surface)
            .border(1.dp, Outline, shape)
            .semantics { contentDescription = description }
            .clickable(role = Role.Button, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = TextMain, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelLarge, maxLines = 1)
    }
}
