package com.videoslidemaker.app.align

import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/** Per-frame speech/non-speech decision plus the noise floor it was based on. */
class SpeechMap(
    val mask: BooleanArray,
    val noiseDb: FloatArray,
    /** Median gap between the speech level and the background level, in dB. */
    val clarityDb: Float
)

/** A dip in loudness inside a speech run — a likely word or phrase boundary. */
class Dip(val frame: Int, val depthDb: Float)

/**
 * Finds where speech is in a stream of 10 ms energy frames (see [EnergyFrameExtractor]).
 *
 * The noise floor and the speech level are re-estimated every 5 s and smoothed, so a recording
 * whose background level wanders (traffic, a fan switching on) is still judged against its own
 * local background rather than one global threshold. A recording with no clear gap between
 * speech and background (under 9 dB) produces no speech decisions at all: guessing there would
 * only lead to wrong timestamps.
 */
object SpeechAnalysis {
    private const val BLOCK = 500            // 5 s of frames
    private const val MIN_CLARITY_DB = 9.0

    fun detect(e: FloatArray): SpeechMap {
        val k = e.size
        if (k == 0) return SpeechMap(BooleanArray(0), FloatArray(0), 0f)

        val blocks = (k + BLOCK - 1) / BLOCK
        val noiseB = DoubleArray(blocks)
        val speechB = DoubleArray(blocks)
        for (b in 0 until blocks) {
            val from = b * BLOCK
            val to = min(k, from + BLOCK)
            val seg = e.copyOfRange(from, to)
            seg.sort()
            noiseB[b] = percentile(seg, 15.0)
            speechB[b] = percentile(seg, 95.0)
        }
        val noiseLevel = DoubleArray(blocks) { b -> median(noiseB, max(0, b - 3), min(blocks, b + 4)) }
        val speechLevel = DoubleArray(blocks) { b -> median(speechB, max(0, b - 6), min(blocks, b + 7)) }

        val noise = FloatArray(k)
        val range = DoubleArray(k)
        val mask = BooleanArray(k)
        var on = false
        for (i in 0 until k) {
            val b = i / BLOCK
            val n = noiseLevel[b]
            val rng = speechLevel[b] - n
            noise[i] = n.toFloat()
            range[i] = rng
            val margin = max(6.0, 0.30 * rng)
            val thrOn = n + margin
            val thrOff = thrOn - 4.0
            val v = e[i].toDouble()
            on = when {
                rng < MIN_CLARITY_DB -> false
                on -> v >= thrOff
                else -> v >= thrOn
            }
            mask[i] = on
        }
        val cleaned = removeStationary(e, mask)

        val sortedRange = range.copyOf()
        sortedRange.sort()
        val clarity = median(sortedRange, 0, sortedRange.size)
        return SpeechMap(cleaned, noise, clarity.toFloat())
    }

    /**
     * Clears the mask over stretches whose loudness barely varies — hum, a steady tone, a flat
     * music bed. Speech always rises and falls at syllable rate by several dB, so a stretch of
     * at least 400 ms with under 1.5 dB of variation is not speech.
     */
    private fun removeStationary(e: FloatArray, mask: BooleanArray): BooleanArray {
        val k = e.size
        val half = 10
        val maxStd = 1.5
        val minLen = 40
        val c1 = DoubleArray(k + 1)
        val c2 = DoubleArray(k + 1)
        for (i in 0 until k) {
            val v = e[i].toDouble()
            c1[i + 1] = c1[i] + v
            c2[i + 1] = c2[i] + v * v
        }
        val flat = BooleanArray(k)
        for (i in 0 until k) {
            val lo = max(0, i - half)
            val hi = min(k, i + half + 1)
            val n = (hi - lo).toDouble()
            val mean = (c1[hi] - c1[lo]) / n
            val variance = max(0.0, (c2[hi] - c2[lo]) / n - mean * mean)
            flat[i] = sqrt(variance) < maxStd
        }
        val out = mask.copyOf()
        var i = 0
        while (i < k) {
            if (flat[i]) {
                var j = i
                while (j < k && flat[j]) j++
                if (j - i >= minLen) {
                    for (x in i until j) out[x] = false
                }
                i = j
            } else {
                i++
            }
        }
        return out
    }

    /** `[start, end)` frame runs of speech; gaps under 100 ms are bridged and runs under 60 ms dropped. */
    fun runs(mask: BooleanArray, minSpeech: Int = 6, bridge: Int = 10): List<IntArray> {
        val raw = ArrayList<IntArray>()
        var i = 0
        val k = mask.size
        while (i < k) {
            if (mask[i]) {
                var j = i
                while (j < k && mask[j]) j++
                raw.add(intArrayOf(i, j))
                i = j
            } else {
                i++
            }
        }
        val merged = ArrayList<IntArray>()
        for (r in raw) {
            if (merged.isNotEmpty() && r[0] - merged[merged.size - 1][1] < bridge) {
                merged[merged.size - 1][1] = r[1]
            } else {
                merged.add(intArrayOf(r[0], r[1]))
            }
        }
        return merged.filter { it[1] - it[0] >= minSpeech }
    }

    /**
     * Moves each run's start back to where the sound actually begins to rise out of the
     * background (the "foot" of the onset), and each end forward to the foot of the fall. The
     * threshold that detects speech sits above that foot, so without this every onset would be
     * reported a few tens of milliseconds late.
     */
    fun refineEdges(
        runs: List<IntArray>,
        e: FloatArray,
        noise: FloatArray,
        footDb: Double = 6.0,
        maxBack: Int = 15
    ): List<IntArray> {
        val k = e.size
        val widened = ArrayList<IntArray>(runs.size)
        for (r in runs) {
            val s = r[0]
            val t = r[1]
            var s2 = s
            while (s2 > 0 && (s - s2) < maxBack && e[s2 - 1] >= noise[s2 - 1] + footDb) s2--
            var t2 = t
            while (t2 < k && (t2 - t) < maxBack && e[t2] >= noise[t2] + footDb) t2++
            widened.add(intArrayOf(s2, t2))
        }
        val fixed = ArrayList<IntArray>(widened.size)
        for (r in widened) {
            var s = r[0]
            val t = r[1]
            if (fixed.isNotEmpty() && s < fixed[fixed.size - 1][1]) s = fixed[fixed.size - 1][1]
            if (t > s) fixed.add(intArrayOf(s, t))
        }
        return fixed
    }

    /** Loudness dips inside speech runs — candidate word/phrase boundaries for continuous speech. */
    fun dips(
        e: FloatArray,
        runs: List<IntArray>,
        minDepth: Double = 4.0,
        span: Int = 12,
        minSep: Int = 15
    ): List<Dip> {
        val k = e.size
        if (k < 3) return emptyList()
        val es = e.copyOf()
        for (i in 1 until k - 1) es[i] = (e[i - 1] + 2f * e[i] + e[i + 1]) / 4f

        val found = ArrayList<Dip>()
        for (r in runs) {
            val lo = r[0] + 3
            val hi = r[1] - 3
            for (i in lo until hi) {
                if (i < 1 || i + 1 >= k) continue
                if (es[i] > es[i - 1] || es[i] >= es[i + 1]) continue
                val l0 = max(0, i - span)
                val r1 = min(k, i + span + 1)
                var lm = Float.NEGATIVE_INFINITY
                for (x in l0 until i) if (es[x] > lm) lm = es[x]
                var rm = Float.NEGATIVE_INFINITY
                for (x in i + 1 until r1) if (es[x] > rm) rm = es[x]
                val depth = min(lm, rm) - es[i]
                if (depth >= minDepth) found.add(Dip(i, depth))
            }
        }
        // Keep the deepest dip of any cluster: nothing within minSep frames of a kept dip.
        val byDepth = found.sortedByDescending { it.depthDb }
        val taken = BooleanArray(k)
        val kept = ArrayList<Dip>()
        for (d in byDepth) {
            if (taken[d.frame]) continue
            kept.add(d)
            val from = max(0, d.frame - (minSep - 1))
            val to = min(k - 1, d.frame + (minSep - 1))
            for (x in from..to) taken[x] = true
        }
        kept.sortBy { it.frame }

        // Report the end of each dip's floor: that is where the next word starts rising.
        val out = ArrayList<Dip>(kept.size)
        for (d in kept) {
            var j = d.frame
            val level = es[d.frame] + 0.15f * d.depthDb
            while (j + 1 < k && es[j + 1] <= level && j - d.frame < 8) j++
            out.add(Dip(j, d.depthDb))
        }
        return out
    }

    // ---- small statistics helpers (match numpy's defaults so results agree with the validated reference) ----

    /** [p]-th percentile of an ascending-sorted array, linear interpolation. */
    private fun percentile(sorted: FloatArray, p: Double): Double {
        val n = sorted.size
        if (n == 0) return 0.0
        val pos = p / 100.0 * (n - 1)
        val lo = floor(pos).toInt()
        val hi = ceil(pos).toInt()
        if (lo == hi) return sorted[lo].toDouble()
        val frac = pos - lo
        return sorted[lo] * (1.0 - frac) + sorted[hi] * frac
    }

    private fun median(values: DoubleArray, from: Int, to: Int): Double {
        val n = to - from
        if (n <= 0) return 0.0
        val copy = values.copyOfRange(from, to)
        copy.sort()
        return if (n % 2 == 1) copy[n / 2] else (copy[n / 2 - 1] + copy[n / 2]) / 2.0
    }
}

/**
 * A rough "how long does this take to say" model for a line of text, in syllable-like units.
 * It needs no dictionary and works across scripts: Latin words count vowel groups; digits count
 * one unit each; other scripts (Devanagari, …) count about one unit per two characters.
 */
object TextUnits {
    /** Typical speaking rate used to turn units into seconds; the aligner re-estimates the real rate. */
    const val RATE0 = 4.5

    fun of(text: String): Double {
        var total = 0.0
        var i = 0
        val n = text.length
        while (i < n) {
            if (!isWordChar(text[i])) {
                i++
                continue
            }
            var j = i
            while (j < n && isWordChar(text[j])) j++
            total += tokenUnits(text.substring(i, j))
            i = j
        }
        return max(total, 1.0)
    }

    fun hasContent(text: String): Boolean = text.any { it.isLetterOrDigit() }

    private fun isWordChar(c: Char): Boolean {
        if (c == '_') return false
        if (c.isLetterOrDigit()) return true
        // Combining marks (Devanagari vowel signs etc.) belong to the word they decorate.
        val type = Character.getType(c)
        return type == Character.NON_SPACING_MARK.toInt() ||
            type == Character.COMBINING_SPACING_MARK.toInt() ||
            type == Character.ENCLOSING_MARK.toInt()
    }

    private fun isAsciiLetter(c: Char) = (c in 'a'..'z') || (c in 'A'..'Z')
    private fun isVowel(c: Char) = c in "aeiouyAEIOUY"

    private fun tokenUnits(tok: String): Double {
        if (tok.all { it.isDigit() }) return tok.length.toDouble()
        if (isAsciiLetter(tok[0])) {
            var groups = 0
            var inGroup = false
            for (c in tok) {
                if (isVowel(c)) {
                    if (!inGroup) groups++
                    inGroup = true
                } else {
                    inGroup = false
                }
            }
            if (groups > 0) return max(1, groups).toDouble()
        }
        return max(1.0, tok.length / 2.0)
    }
}
