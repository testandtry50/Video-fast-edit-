package com.videoslidemaker.app.export

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/*
 * Band-limited sample-rate conversion (Kaiser-windowed sinc).
 *
 * WHY THIS EXISTS: the old converter drew straight lines between neighbouring samples ("linear interpolation").
 * That is fast, but it does not filter: when a 22.05 kHz phone voice was brought up to 44.1 kHz it left a mirror
 * image of the voice above 11 kHz, about 36 dB below the voice itself. You do not hear that at normal pitch, but the
 * voice changer moves the whole sound - lower the pitch and those mirror images slide down into the range you CAN
 * hear, as a fuzzy hiss behind the voice. A proper filter removes them (about 88 dB below the voice instead of 36).
 * tools/voicefx-reference/resample_check.py measures this.
 *
 * The filter is designed once per pair of rates ([ResamplePlan]) as a table of "phases", one per fractional position
 * an output sample can fall on, so converting is just a small dot product per output sample.
 */

private const val HALF_WIDTH = 32.0      // zero crossings on each side of the centre (before widening for down-sampling)
private const val KAISER_BETA = 10.0     // window shape: about 100 dB of rejection
private const val CUTOFF_MARGIN = 0.93   // pass-band edge as a fraction of the lower of the two Nyquist frequencies
private const val MAX_PHASES = 2048

private fun gcd(a: Int, b: Int): Int {
    var x = a
    var y = b
    while (y != 0) {
        val t = x % y
        x = y
        y = t
    }
    return x
}

/** Modified Bessel function of the first kind, order 0 (for the Kaiser window). */
private fun besselI0(x: Double): Double {
    var sum = 1.0
    var term = 1.0
    val q = x * x / 4.0
    var k = 1
    while (k < 80) {
        term *= q / (k.toDouble() * k.toDouble())
        sum += term
        if (term < 1e-14 * sum) break
        k++
    }
    return sum
}

/** The filter table for converting [srcRate] to [dstRate]. Immutable and shared between streams. */
internal class ResamplePlan private constructor(srcRate: Int, dstRate: Int) {
    /** Source frames / output frames per repeating cycle (the rates divided by their greatest common divisor). */
    val s: Int
    val d: Int
    val phases: Int
    val halfTaps: Int
    val taps: Int
    val table: FloatArray

    init {
        val g = gcd(srcRate, dstRate)
        s = srcRate / g
        d = dstRate / g
        phases = min(d, MAX_PHASES)
        val cutoff = min(1.0, dstRate.toDouble() / srcRate.toDouble()) * CUTOFF_MARGIN
        halfTaps = ceil(HALF_WIDTH / cutoff).toInt()
        taps = 2 * halfTaps
        table = FloatArray(phases * taps)
        val norm = besselI0(KAISER_BETA)
        val row = DoubleArray(taps)
        for (p in 0 until phases) {
            val frac = p.toDouble() / phases
            var sum = 0.0
            for (t in 0 until taps) {
                // tap t reads source frame (n0 - halfTaps + 1 + t); the output sits frac after frame n0
                val x = frac - (t - halfTaps + 1).toDouble()
                val sinc = if (abs(x) < 1e-12) cutoff else sin(PI * cutoff * x) / (PI * x)
                val r = x / halfTaps
                val w = if (abs(r) < 1.0) besselI0(KAISER_BETA * sqrt(1.0 - r * r)) / norm else 0.0
                row[t] = sinc * w
                sum += row[t]
            }
            // unity gain at 0 Hz, whatever the phase
            for (t in 0 until taps) table[p * taps + t] = (row[t] / sum).toFloat()
        }
    }

    companion object {
        private val cache = HashMap<Long, ResamplePlan>()

        @Synchronized
        fun of(srcRate: Int, dstRate: Int): ResamplePlan {
            val key = (srcRate.toLong() shl 32) or dstRate.toLong()
            return cache.getOrPut(key) { ResamplePlan(srcRate, dstRate) }
        }
    }
}

/**
 * Converts ONE channel as a stream: [push] the source frames in order, in pieces of any size, and it returns the
 * output frames that are complete so far. It keeps only the few frames it still needs between pieces, so a
 * recording of any length can go through. Before the first frame the sound is treated as silence; call [finish]
 * once at the very end to get the last few output frames (the filter needs to look a little ahead).
 */
internal class ChannelResampler(private val plan: ResamplePlan) {
    private var tail = FloatArray(plan.halfTaps)          // silence before the start
    private var tailStart = -plan.halfTaps.toLong()       // source frame number of tail[0]
    private var outIndex = 0L                             // number of the next output frame

    fun push(input: FloatArray, offset: Int, count: Int): FloatArray {
        if (count <= 0) return FloatArray(0)
        val work = FloatArray(tail.size + count)
        System.arraycopy(tail, 0, work, 0, tail.size)
        System.arraycopy(input, offset, work, tail.size, count)
        val workStart = tailStart
        val avail = workStart + work.size                  // one past the last source frame held in [work]
        val h = plan.halfTaps
        val taps = plan.taps
        val table = plan.table
        val out = FloatArray((count.toLong() * plan.d / plan.s).toInt() + 8)
        var n = 0
        while (n < out.size) {
            val num = outIndex * plan.s
            var base = num / plan.d
            var phase = ((num % plan.d).toDouble() / plan.d * plan.phases + 0.5).toInt()
            if (phase >= plan.phases) {
                phase = 0
                base += 1
            }
            if (base + h >= avail) break                   // needs source frames that have not arrived yet
            val k = phase * taps
            val first = (base - h + 1 - workStart).toInt()
            var acc = 0.0
            for (t in 0 until taps) acc += work[first + t] * table[k + t]
            out[n] = acc.toFloat()
            n++
            outIndex++
        }
        val nextBase = (outIndex * plan.s) / plan.d
        val keepFrom = maxOf(workStart, nextBase - h + 1)
        val from = (keepFrom - workStart).toInt().coerceIn(0, work.size)
        tail = work.copyOfRange(from, work.size)
        tailStart = workStart + from
        return if (n == out.size) out else out.copyOf(n)
    }

    /** The output frames that were still waiting for source frames after the last one (the end is silence). */
    fun finish(): FloatArray = push(FloatArray(plan.halfTaps), 0, plan.halfTaps)
}
