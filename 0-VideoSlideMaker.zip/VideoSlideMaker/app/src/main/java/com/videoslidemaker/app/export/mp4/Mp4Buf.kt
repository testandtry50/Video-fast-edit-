package com.videoslidemaker.app.export.mp4

/** Where finished bytes go. [position] is how many have been written, which is the file offset of the next byte. */
interface ByteSink {
    fun write(bytes: ByteArray, off: Int, len: Int)
    val position: Long
    fun flush()
}

/** A [ByteSink] over any output stream, counting what passes through. */
class StreamSink(private val out: java.io.OutputStream, startPosition: Long = 0L) : ByteSink {
    override var position: Long = startPosition
        private set

    override fun write(bytes: ByteArray, off: Int, len: Int) {
        out.write(bytes, off, len)
        position += len.toLong()
    }

    override fun flush() = out.flush()
}

/**
 * A growing byte buffer with the writing helpers MP4 needs (big-endian numbers, four-character codes, and boxes whose size is
 * filled in when they are closed). Only ever holds one box tree at a time (a header, or one fragment's header), never the video.
 */
internal class Mp4Buf(initialCapacity: Int = 4096) {
    private var buf = ByteArray(initialCapacity)
    var size = 0
        private set

    private fun ensure(extra: Int) {
        if (size + extra > buf.size) buf = buf.copyOf(maxOf(buf.size * 2, size + extra))
    }

    fun u8(v: Int) {
        ensure(1)
        buf[size++] = v.toByte()
    }

    fun u16(v: Int) {
        ensure(2)
        buf[size++] = (v ushr 8).toByte()
        buf[size++] = v.toByte()
    }

    /** An unsigned 32-bit number held in a Long. */
    fun u32(v: Long) {
        ensure(4)
        buf[size++] = (v ushr 24).toByte()
        buf[size++] = (v ushr 16).toByte()
        buf[size++] = (v ushr 8).toByte()
        buf[size++] = v.toByte()
    }

    fun u64(v: Long) {
        ensure(8)
        for (shift in 56 downTo 0 step 8) buf[size++] = (v ushr shift).toByte()
    }

    fun bytes(b: ByteArray, off: Int = 0, len: Int = b.size) {
        ensure(len)
        System.arraycopy(b, off, buf, size, len)
        size += len
    }

    fun zeros(n: Int) {
        ensure(n)
        java.util.Arrays.fill(buf, size, size + n, 0.toByte())
        size += n
    }

    fun fourcc(s: String) {
        require(s.length == 4) { "a box type is four characters: $s" }
        for (c in s) u8(c.code)
    }

    /** Starts a box; returns where it started, to hand to [end]. */
    fun begin(type: String): Int {
        val p = size
        u32(0L)
        fourcc(type)
        return p
    }

    fun beginFull(type: String, version: Int, flags: Int): Int {
        val p = begin(type)
        u8(version)
        u8((flags ushr 16) and 0xFF)
        u8((flags ushr 8) and 0xFF)
        u8(flags and 0xFF)
        return p
    }

    /** Closes the box that started at [p]: its size becomes the number of bytes written since. */
    fun end(p: Int) {
        val len = size - p
        buf[p] = (len ushr 24).toByte()
        buf[p + 1] = (len ushr 16).toByte()
        buf[p + 2] = (len ushr 8).toByte()
        buf[p + 3] = len.toByte()
    }

    fun toByteArray(): ByteArray = buf.copyOf(size)

    fun writeTo(sink: ByteSink) = sink.write(buf, 0, size)
}
