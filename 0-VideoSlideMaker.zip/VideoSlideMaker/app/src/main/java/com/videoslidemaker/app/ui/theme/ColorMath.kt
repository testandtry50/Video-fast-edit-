package com.videoslidemaker.app.ui.theme

import androidx.compose.ui.graphics.Color
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow

/*
 * Colour maths used to keep every look readable. tools/theme-reference/palette_check.py is the Python original: it
 * checks every style x accent combination (and every custom hue) against the same contrast rules as ThemeContrastTest.
 */

/** WCAG relative luminance: 0 = black, 1 = white. */
fun relativeLuminance(c: Color): Double {
    fun channel(v: Float): Double {
        val d = v.toDouble()
        return if (d <= 0.03928) d / 12.92 else ((d + 0.055) / 1.055).pow(2.4)
    }
    return 0.2126 * channel(c.red) + 0.7152 * channel(c.green) + 0.0722 * channel(c.blue)
}

/** WCAG contrast ratio between two colours, 1 (identical) to 21 (black on white). */
fun contrastRatio(a: Color, b: Color): Double {
    val la = relativeLuminance(a)
    val lb = relativeLuminance(b)
    return (max(la, lb) + 0.05) / (min(la, lb) + 0.05)
}

/** [fg] drawn at [alpha] on top of [bg] - how the tinted boxes, badges and chips actually look. */
fun blendOver(fg: Color, alpha: Float, bg: Color): Color = Color(
    red = fg.red * alpha + bg.red * (1f - alpha),
    green = fg.green * alpha + bg.green * (1f - alpha),
    blue = fg.blue * alpha + bg.blue * (1f - alpha)
)

/** Hue 0..360, saturation 0..1, lightness 0..1. */
class Hsl(val h: Double, val s: Double, val l: Double)

fun Color.toHsl(): Hsl {
    val r = red.toDouble()
    val g = green.toDouble()
    val b = blue.toDouble()
    val mx = max(r, max(g, b))
    val mn = min(r, min(g, b))
    val l = (mx + mn) / 2.0
    val d = mx - mn
    if (d < 1e-9) return Hsl(0.0, 0.0, l)
    val s = d / (1.0 - abs(2.0 * l - 1.0))
    var sector = when {
        mx == r -> (g - b) / d
        mx == g -> (b - r) / d + 2.0
        else -> (r - g) / d + 4.0
    }
    if (sector < 0.0) sector += 6.0
    return Hsl((sector * 60.0) % 360.0, s, l)
}

fun hslColor(h: Double, s: Double, l: Double): Color {
    val c = (1.0 - abs(2.0 * l - 1.0)) * s
    var hue = h % 360.0
    if (hue < 0.0) hue += 360.0
    val hp = hue / 60.0
    val x = c * (1.0 - abs(hp % 2.0 - 1.0))
    val r1: Double
    val g1: Double
    val b1: Double
    when (hp.toInt() % 6) {
        0 -> { r1 = c; g1 = x; b1 = 0.0 }
        1 -> { r1 = x; g1 = c; b1 = 0.0 }
        2 -> { r1 = 0.0; g1 = c; b1 = x }
        3 -> { r1 = 0.0; g1 = x; b1 = c }
        4 -> { r1 = x; g1 = 0.0; b1 = c }
        else -> { r1 = c; g1 = 0.0; b1 = x }
    }
    val m = l - c / 2.0
    return Color(
        red = (r1 + m).toFloat().coerceIn(0f, 1f),
        green = (g1 + m).toFloat().coerceIn(0f, 1f),
        blue = (b1 + m).toFloat().coerceIn(0f, 1f)
    )
}

/**
 * Nudges the lightness of [base] (0.01 at a time, towards light or towards dark) until it reads at [target]:1 or
 * better on every colour [backgrounds] returns for it (the function gets the candidate, so a colour's own tinted
 * fill can be one of the backgrounds). Returns [base] itself when it already does. Always ends: pure white / pure
 * black pass on any background of the right kind.
 */
fun fitColor(base: Color, towardLight: Boolean, target: Double, backgrounds: (Color) -> List<Color>): Color {
    fun reads(c: Color): Boolean {
        for (bg in backgrounds(c)) {
            if (contrastRatio(c, bg) < target) return false
        }
        return true
    }
    if (reads(base)) return base
    val hsl = base.toHsl()
    var l = hsl.l
    for (step in 0 until 100) {
        l = if (towardLight) min(1.0, l + 0.01) else max(0.0, l - 0.01)
        val candidate = hslColor(hsl.h, hsl.s, l)
        if (reads(candidate)) return candidate
    }
    return hslColor(hsl.h, hsl.s, if (towardLight) 1.0 else 0.0)
}

private val PureWhite = Color(0xFFFFFFFF)
private val PureBlack = Color(0xFF000000)

/** The colour for text / icons on a solid [fill]: [preferred] when it reads well enough, else white or black. */
fun readableOn(fill: Color, preferred: Color): Color {
    if (contrastRatio(preferred, fill) >= 4.6) return preferred
    return if (contrastRatio(PureWhite, fill) >= contrastRatio(PureBlack, fill)) PureWhite else PureBlack
}
