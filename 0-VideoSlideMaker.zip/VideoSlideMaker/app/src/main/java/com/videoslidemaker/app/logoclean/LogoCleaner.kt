package com.videoslidemaker.app.logoclean

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import com.videoslidemaker.app.data.ImageStore
import com.videoslidemaker.app.model.PoolImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import kotlin.math.floor
import kotlin.math.max

/** Result of scanning the photos for a logo that repeats. */
internal class ScanResult(
    val consistency: Consistency?,
    val candidates: List<LogoCandidate>,
    /** Photos actually analysed. */
    val checked: Int,
    /** Photos in the largest group of same-sized photos. */
    val sameSize: Int
)

/** How cleaning the text of one photo ended. */
internal enum class TextStatus {
    /** The text was repainted and a cleaned copy was saved. */
    CLEANED,

    /** The box did not look like it holds text in this photo (the caption is not on screen): photo left alone. */
    NO_TEXT,

    /** The photo could not be read, or the area could not be repainted or saved. */
    FAILED
}

internal class TextOutcome(val status: TextStatus, val image: PoolImage? = null)

/** Whether (and where) a logo template was found in one photo. Shifts are fractions of the photo. */
internal class Located(val found: Boolean, val shiftX: Float, val shiftY: Float, val score: Float)

/**
 * Does the actual work on photos: reads them, finds the logo, repaints it and saves a cleaned copy.
 *
 * The original photo is never modified or deleted. The cleaned picture is written to the app's own
 * folder and the photo's [PoolImage.uri] is pointed at it; [PoolImage.originalUri] remembers the
 * original, which is ALWAYS what gets read for scanning and cleaning (so cleaning twice never stacks
 * and "restore" is exact). Thumbnails, preview and export all just follow [PoolImage.uri].
 */
internal class LogoCleaner(context: Context, private val store: ImageStore) {
    private val appContext = context.applicationContext

    private val dir: File
        get() = File(appContext.filesDir, "logoclean").also { it.mkdirs() }

    /** The photo to LOOK at when scanning: always the original, so a scan never sees an earlier cleaning. */
    private fun sourceOf(image: PoolImage): Uri = image.originalUri ?: image.uri

    /**
     * The picture to PAINT on. Cleaning the same thing again starts from the original (so a redo never stacks, as
     * before). But when something ELSE was cleaned in this photo (say the logo, and now the subtitle) the new
     * cleaning goes on top of the cleaned copy - starting from the original would bring the logo back.
     */
    private fun paintSourceOf(image: PoolImage, target: CleanTarget): Uri {
        val original = image.originalUri ?: return image.uri
        val somethingElseCleaned = image.cleanLog.keys.any { it != target }
        return if (somethingElseCleaned) image.uri else original
    }

    /** Edge map of one photo (from its original file) at analysis size. Null if it can't be read. */
    suspend fun analyze(image: PoolImage): EdgeData? = withContext(Dispatchers.Default) {
        val bmp = store.decodeThumbnail(sourceOf(image), LogoDetector.L_ANALYSIS) ?: return@withContext null
        try {
            val s = LogoDetector.analysisScale(bmp.width, bmp.height)
            val aw = max(8, Math.round(bmp.width * s))
            val ah = max(8, Math.round(bmp.height * s))
            val scaled = if (aw == bmp.width && ah == bmp.height) bmp else Bitmap.createScaledBitmap(bmp, aw, ah, true)
            val px = IntArray(aw * ah)
            scaled.getPixels(px, 0, aw, 0, 0, aw, ah)
            if (scaled !== bmp) scaled.recycle()
            LogoDetector.computeEdges(LogoDetector.luma(px), aw, ah)
        } finally {
            bmp.recycle()
        }
    }

    /**
     * Looks for a logo that repeats across the photos. Uses the biggest group of same-sized photos
     * (a logo overlay is at the same place in photos cut from the same video) and at most [MAX_SCAN]
     * of them, spread evenly - plenty for a clear answer, and quick.
     */
    suspend fun scan(images: List<PoolImage>, onProgress: (Int, Int) -> Unit): ScanResult {
        val groups = images.filter { it.widthPx > 0 && it.heightPx > 0 }.groupBy { it.widthPx to it.heightPx }
        val group = groups.values.maxByOrNull { it.size } ?: return ScanResult(null, emptyList(), 0, 0)
        if (group.size < LogoDetector.MIN_COUNT) return ScanResult(null, emptyList(), 0, group.size)
        val picked = if (group.size <= MAX_SCAN) group else List(MAX_SCAN) { group[(it.toLong() * (group.size - 1) / (MAX_SCAN - 1)).toInt()] }
        val maps = ArrayList<EdgeData>()
        for ((i, image) in picked.withIndex()) {
            currentCoroutineContext().ensureActive()
            val edges = try { analyze(image) } catch (e: OutOfMemoryError) { null }
            if (edges != null) maps.add(edges)
            onProgress(i + 1, picked.size)
        }
        return withContext(Dispatchers.Default) {
            val c = LogoDetector.consistency(maps) ?: return@withContext ScanResult(null, emptyList(), 0, group.size)
            val candidates = LogoDetector.findBlobs(c).map { LogoCandidate(LogoDetector.toTemplate(it, c), it.support, c.n) }
            ScanResult(c, candidates, c.n, group.size)
        }
    }

    /** The logo inside a box the user drew, if something in it repeats across the scanned photos. */
    suspend fun templateForBox(c: Consistency, box: LogoBox): LogoTemplate? = withContext(Dispatchers.Default) {
        val l = floor(box.left * c.w).toInt()
        val t = floor(box.top * c.h).toInt()
        val r = Math.round(box.right * c.w)
        val b = Math.round(box.bottom * c.h)
        val blob = LogoDetector.blobInBox(c, l, t, r, b) ?: return@withContext null
        LogoDetector.toTemplate(blob, c)
    }

    /**
     * Is the logo in this photo, and where? First at the same place (+-6 analysis px); if that fails and
     * [follow] is on, anywhere in the photo with a stricter bar. Null when the photo can't be read.
     */
    suspend fun locate(image: PoolImage, template: LogoTemplate, follow: Boolean): Located? {
        val edges = analyze(image) ?: return null
        return withContext(Dispatchers.Default) {
            var m = LogoDetector.match(edges, template, LogoDetector.FIXED_SEARCH_R)
            var ok = m.score >= LogoDetector.MATCH_FIXED
            if (!ok && follow) {
                m = LogoDetector.match(edges, template, -1)
                ok = m.score >= LogoDetector.MATCH_FOLLOW
            }
            Located(ok, m.dx.toFloat() / edges.w, m.dy.toFloat() / edges.h, m.score)
        }
    }

    /**
     * Cleans ONE photo and returns its updated entry (uri now points at the cleaned copy), or null if the
     * photo couldn't be read / the area couldn't be painted. [template] gives the logo's exact shape
     * (null = use the rectangle [box]); [shiftX]/[shiftY] move the template when the logo was found
     * somewhere else in this photo. [target] is only what gets written into the photo's cleaning record.
     */
    suspend fun clean(
        image: PoolImage, box: LogoBox, template: LogoTemplate?,
        shiftX: Float, shiftY: Float, mode: LogoCleanMode, strength: Float,
        jpegQuality: Int = SINGLE_JPEG_QUALITY,
        target: CleanTarget = CleanTarget.LOGO
    ): PoolImage? {
        val work = decodeForPainting(image, target) ?: return null
        try {
            val plan = withContext(Dispatchers.Default) {
                LogoPaint.planMask(work.width, work.height, box, template, shiftX, shiftY)
            } ?: return null
            val window = IntArray(plan.w * plan.h)
            work.getPixels(window, 0, plan.w, plan.x0, plan.y0, plan.w, plan.h)
            val painted = withContext(Dispatchers.Default) {
                LogoPaint.paint(window, plan.w, plan.h, plan.mask, mode, strength)
            }
            work.setPixels(painted, 0, plan.w, plan.x0, plan.y0, plan.w, plan.h)
            return writeCleaned(image, work, mode, target, jpegQuality)
        } finally {
            work.recycle()
        }
    }

    /**
     * Cleans the TEXT (a subtitle, a title, a name) inside [box] in ONE photo. Unlike a logo, text is different in
     * every photo, so it is looked for in this photo alone: only the letters are repainted (Remove) or smudged
     * (Blur), not the whole box. When the box does not look like it holds text in this photo, the photo is left
     * alone ([TextStatus.NO_TEXT]). [relaxed] = "everywhere in the box": short and faint text counts too.
     */
    suspend fun cleanText(
        image: PoolImage, box: LogoBox, target: CleanTarget, mode: LogoCleanMode, strength: Float,
        relaxed: Boolean, jpegQuality: Int = SINGLE_JPEG_QUALITY
    ): TextOutcome {
        val work = decodeForPainting(image, target) ?: return TextOutcome(TextStatus.FAILED)
        try {
            val plan = withContext(Dispatchers.Default) {
                LogoPaint.planTextRegion(work.width, work.height, box)
            } ?: return TextOutcome(TextStatus.FAILED)
            val window = IntArray(plan.w * plan.h)
            work.getPixels(window, 0, plan.w, plan.x0, plan.y0, plan.w, plan.h)
            val found = withContext(Dispatchers.Default) {
                TextMask.detect(window, plan.w, plan.h, plan.mask, relaxed)
            } ?: return TextOutcome(TextStatus.NO_TEXT)
            val painted = withContext(Dispatchers.Default) {
                LogoPaint.paint(window, plan.w, plan.h, found.mask, mode, strength, found.blurMask)
            }
            work.setPixels(painted, 0, plan.w, plan.x0, plan.y0, plan.w, plan.h)
            val saved = writeCleaned(image, work, mode, target, jpegQuality)
                ?: return TextOutcome(TextStatus.FAILED)
            return TextOutcome(TextStatus.CLEANED, saved)
        } finally {
            work.recycle()
        }
    }

    /** Decodes the picture to paint on as a bitmap that may be changed; null if it can't be read. */
    private suspend fun decodeForPainting(image: PoolImage, target: CleanTarget): Bitmap? {
        val decoded = store.decodeAtMost(paintSourceOf(image, target), MAX_EDGE) ?: return null
        if (decoded.isMutable && decoded.config == Bitmap.Config.ARGB_8888) return decoded
        val copy = decoded.copy(Bitmap.Config.ARGB_8888, true)
        decoded.recycle()
        return copy
    }

    /**
     * Saves [work] as the photo's new cleaned copy and returns the updated entry (null if it couldn't be written).
     * The previous cleaned copy of this photo, if any, is deleted - the new one already contains it.
     */
    private suspend fun writeCleaned(
        image: PoolImage, work: Bitmap, mode: LogoCleanMode, target: CleanTarget, jpegQuality: Int
    ): PoolImage? {
        val lossless = isLossless(image)
        val safeId = image.id.filter { it.isLetterOrDigit() || it == '-' }
        val file = File(dir, "${safeId}_${System.currentTimeMillis()}.${if (lossless) "png" else "jpg"}")
        // If the run is stopped (or the write fails) half way, the unfinished file must not stay behind:
        // with 100,000 photos a leftover per stop would quietly eat storage.
        var keep = false
        try {
            val written = withContext(Dispatchers.IO) {
                try {
                    FileOutputStream(file).use { out ->
                        work.compress(
                            if (lossless) Bitmap.CompressFormat.PNG else Bitmap.CompressFormat.JPEG,
                            jpegQuality.coerceIn(50, 100), out
                        )
                    }
                } catch (e: Exception) {
                    false
                }
            }
            if (!written) return null
            keep = true
        } finally {
            if (!keep) file.delete()
        }
        deleteCleanedFile(image) // the previous cleaned copy of this photo, if any
        return image.copy(
            uri = Uri.fromFile(file),
            originalUri = image.originalUri ?: image.uri,
            cleanMode = mode,
            cleanLog = image.cleanLog + (target to mode)
        )
    }

    private fun isLossless(image: PoolImage): Boolean =
        image.displayName.lowercase().let { it.endsWith(".png") || it.endsWith(".bmp") || it.endsWith(".gif") }

    /** Rough storage the cleaned copies of [images] will take (see [BulkMath.estimateOutputBytes]). */
    fun estimateBytes(images: List<PoolImage>): Long {
        var sum = 0L
        for (image in images) sum += BulkMath.estimateOutputBytes(image.widthPx, image.heightPx, isLossless(image))
        return sum
    }

    /** Free space where the cleaned copies are written. */
    fun freeBytes(): Long = try {
        appContext.filesDir.usableSpace
    } catch (e: Exception) {
        Long.MAX_VALUE
    }

    /** How many photos a bulk run repaints at the same time on this phone. */
    fun workerCount(): Int {
        val rt = Runtime.getRuntime()
        return BulkMath.workerCount(rt.availableProcessors(), rt.maxMemory())
    }

    /** Puts a photo back to its original file and deletes the cleaned copy. */
    fun restored(image: PoolImage): PoolImage {
        val original = image.originalUri ?: return image
        deleteCleanedFile(image)
        return image.copy(uri = original, originalUri = null, cleanMode = null, cleanLog = emptyMap())
    }

    /** Deletes the cleaned copy a photo currently points at (only ever files inside our own folder). */
    fun deleteCleanedFile(image: PoolImage) {
        if (image.originalUri == null || image.uri.scheme != "file") return
        try {
            val f = File(image.uri.path ?: return)
            if (f.parentFile?.canonicalPath == dir.canonicalPath) f.delete()
        } catch (_: Exception) {
        }
    }

    companion object {
        /** Photos used for the automatic scan. */
        const val MAX_SCAN = 40

        /** Photos bigger than this (long edge) are cleaned at this size, so repainting can't run out of memory. */
        const val MAX_EDGE = 4096

        /** JPEG quality of a cleaned copy when one photo is cleaned. */
        const val SINGLE_JPEG_QUALITY = 95

        /** JPEG quality when thousands are cleaned at once: visually the same, about a quarter smaller on disk. */
        const val BULK_JPEG_QUALITY = 90
    }
}
