package com.videoslidemaker.app.export

/**
 * File sizes for people: `450 MB`, `2.35 GB`, `48.7 GB`, `100 GB`.
 *
 * Units are decimal (1 KB = 1000 B), as Android and most file managers show them, in B, KB, MB, GB and TB. A number always has
 * three significant digits (`450`, `48.7`, `2.35`) and no trailing zeros (`100 GB`, never `100.0 GB`). The rounding is done in
 * whole numbers, not floating point, so `2.345 GB` is `2.35 GB` and `999.5 KB` becomes `1 MB` instead of `1000 KB`.
 */
object ByteSize {
    private val UNITS = arrayOf("B", "KB", "MB", "GB", "TB")

    // Beyond ~90 PB the arithmetic below would overflow; no real file is that large.
    private const val MAX_BYTES = 90_000_000_000_000_000L

    fun format(bytes: Long): String {
        val b = bytes.coerceIn(0L, MAX_BYTES)
        if (b < 1000L) return "$b B"
        var unit = 1
        var div = 1000L
        while (true) {
            // hundredths of the unit, half-up
            val hundredths = (b * 100L + div / 2L) / div
            val last = unit == UNITS.size - 1
            val text: String
            val carry: Boolean
            if (hundredths >= 10_000L) {                              // 100 or more: no decimals
                val whole = (hundredths + 50L) / 100L
                carry = whole >= 1000L && !last
                text = whole.toString()
            } else if (hundredths >= 1_000L) {                        // 10 to 99.9: one decimal
                val tenths = (hundredths + 5L) / 10L
                carry = false
                text = trim(tenths / 10L, (tenths % 10L) * 10L)
            } else {                                                   // under 10: two decimals
                carry = false
                text = trim(hundredths / 100L, hundredths % 100L)
            }
            if (!carry) return "$text ${UNITS[unit]}"
            unit++
            div *= 1000L
        }
    }

    /** `12.4 GB of 48.7 GB`. */
    fun ofTotal(done: Long, total: Long): String = "${format(done)} of ${format(total)}"

    /** whole.frac with the fraction given in hundredths, trailing zeros removed. */
    private fun trim(whole: Long, hundredths: Long): String {
        if (hundredths == 0L) return whole.toString()
        val two = hundredths.toString().padStart(2, '0')
        return "$whole." + two.trimEnd('0')
    }
}

/** Elapsed / remaining times: `0:42`, `3:25:07`, `115:00:09` (hours are not capped: a long export can take days). */
object ClockText {
    fun format(ms: Long): String {
        val total = if (ms < 0L) 0L else ms / 1000L
        val h = total / 3600L
        val m = (total / 60L) % 60L
        val s = total % 60L
        return if (h > 0L) "$h:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}"
        else "$m:${s.toString().padStart(2, '0')}"
    }
}
