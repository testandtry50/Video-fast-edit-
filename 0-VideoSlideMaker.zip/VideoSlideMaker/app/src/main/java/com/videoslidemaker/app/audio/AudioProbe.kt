package com.videoslidemaker.app.audio

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import com.videoslidemaker.app.export.AudioDecoder

/** NEW (2.17): reads what the editor needs to know about a file - how long it is and what it looks like. */
object AudioProbe {

    /** The length of the sound in [uriText] in seconds, or 0 when it can't be read. */
    fun durationSec(context: Context, uriText: String): Double {
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(context, Uri.parse(uriText))
            val ms = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            ms / 1000.0
        } catch (_: Exception) {
            0.0
        } finally {
            runCatching { retriever.release() }
        }
    }

    /**
     * A picture of the sound for the editor: [bins] loudness values from 0 to 1 spread over the whole file. Decoded at a
     * very low quality (8 kHz mono) because only the shape matters, so even a long file is quick. Null when unreadable.
     */
    fun peaks(context: Context, uriText: String, durationSec: Double, bins: Int = 640, checkCancelled: () -> Unit = {}): FloatArray? {
        if (durationSec <= 0.0 || bins <= 0) return null
        val rate = 8000
        val totalFrames = (durationSec * rate).toLong().coerceAtLeast(1L)
        val out = FloatArray(bins)
        var frame = 0L
        val ok = AudioDecoder.streamSegment(context, Uri.parse(uriText), 0.0, durationSec + 1.0, rate, 1) { chunk ->
            checkCancelled()
            var i = 0
            while (i + 1 < chunk.size) {
                val s = ((chunk[i + 1].toInt() shl 8) or (chunk[i].toInt() and 0xFF)).toShort().toInt()
                val a = if (s < 0) -s else s
                val bin = ((frame * bins) / totalFrames).toInt().coerceIn(0, bins - 1)
                val v = a / 32768f
                if (v > out[bin]) out[bin] = v
                frame++
                i += 2
            }
            true
        }
        if (!ok) return null
        var top = 0f
        for (v in out) if (v > top) top = v
        if (top <= 0f) return out
        for (i in out.indices) out[i] = out[i] / top
        return out
    }
}
