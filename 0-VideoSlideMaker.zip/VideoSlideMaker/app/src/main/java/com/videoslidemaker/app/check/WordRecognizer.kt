package com.videoslidemaker.app.check

import android.net.Uri

/** What a recognizer heard in a recording: words with times on the RECORDING's clock (the same clock as the player). */
class RecognizedSpeech(val words: List<SpokenWord>, val durationMs: Long)

/** A problem the user can understand (no model installed, model broken, ...). */
class RecognizerException(message: String) : Exception(message)

/**
 * Anything that can turn a recording into timed words. The checker does not care which: a different engine (a Whisper
 * port, say) only has to implement this. [recognize] blocks, so call it off the main thread, and it must throw
 * [java.util.concurrent.CancellationException] when [isCancelled] says so.
 */
interface WordRecognizer {
    /** True when everything the recognizer needs (its speech model) is in place. */
    fun isReady(): Boolean

    fun recognize(uri: Uri, onProgress: (Int) -> Unit, isCancelled: () -> Boolean): RecognizedSpeech
}
