package com.videoslidemaker.app.check

import java.text.Normalizer
import java.util.Locale

/**
 * Both sides (the transcript and what the recognizer heard) are cut into words the SAME way, so that case, punctuation,
 * "um", "twenty five" vs "25" and "$5" vs "five dollars" never count as differences. Port of the tokenizer in
 * tools/accuracy-reference/checker.py.
 *
 * Lengths and character tests work on Unicode code points (not UTF-16 units) so every script behaves like the reference.
 */
internal class Tok(
    /** The word as written / heard (punctuation trimmed off the ends). */
    val disp: String,
    /** The word for comparing: letters and digits only, lower case, apostrophes gone (don't == dont). */
    val norm: String,
    var start: Long = 0L,
    var end: Long = 0L,
    var conf: Double = 1.0,
    var seg: Int = -1,
    /** Index among the words of its transcript segment. */
    var widx: Int = -1,
    var numeric: Boolean = false,
    var nid: Int = 0
) {
    /** Length in code points. */
    val len: Int = norm.codePointCount(0, norm.length)
    val cps: IntArray = CheckTokenizer.codePoints(norm)
}

internal object CheckTokenizer {

    val FILLERS: Set<String> = setOf("um", "umm", "uh", "uhh", "uhm", "er", "erm", "ah", "hmm", "hm", "mm", "mmm", "mhm", "eh")

    private val UNITS: Map<String, Int> = (
        "zero one two three four five six seven eight nine ten eleven twelve thirteen fourteen fifteen " +
            "sixteen seventeen eighteen nineteen"
        ).split(" ").withIndex().associate { (i, w) -> w to i }

    private val TENS: Map<String, Int> = mapOf(
        "twenty" to 20, "thirty" to 30, "forty" to 40, "fourty" to 40, "fifty" to 50,
        "sixty" to 60, "seventy" to 70, "eighty" to 80, "ninety" to 90
    )

    private val SCALES: Map<String, Long> = mapOf(
        "hundred" to 100L, "thousand" to 1_000L, "million" to 1_000_000L, "billion" to 1_000_000_000L
    )

    private val YEAR_PREFIX: Map<String, Int> = mapOf(
        "eleven" to 11, "twelve" to 12, "thirteen" to 13, "fourteen" to 14, "fifteen" to 15, "sixteen" to 16,
        "seventeen" to 17, "eighteen" to 18, "nineteen" to 19, "twenty" to 20
    )

    private val BRACKETS = Regex("\\[[^\\]]*\\]")
    private val SPLIT = Regex("[\\s\\-\\u2010-\\u2015/]+")
    private const val DOLLAR = "\$"
    private val CURRENCY = Regex("([" + DOLLAR + "\\u20ac\\u00a3\\u20b9])\\s*(\\d[\\d,]*(?:\\.\\d+)?)")

    private fun currencyName(symbol: String): String = when (symbol) {
        DOLLAR -> "dollars"
        "\u20ac" -> "euros"
        "\u00a3" -> "pounds"
        else -> "rupees"
    }

    fun codePoints(s: String): IntArray {
        val out = IntArray(s.codePointCount(0, s.length))
        var i = 0
        var k = 0
        while (i < s.length) {
            val cp = s.codePointAt(i)
            out[k++] = cp
            i += Character.charCount(cp)
        }
        return out
    }

    /** Letter, number or combining mark (Unicode categories L*, N*, M*). Devanagari vowel signs are marks, so they count. */
    private fun isWordChar(cp: Int): Boolean = when (Character.getType(cp).toByte()) {
        Character.UPPERCASE_LETTER, Character.LOWERCASE_LETTER, Character.TITLECASE_LETTER, Character.MODIFIER_LETTER,
        Character.OTHER_LETTER,
        Character.NON_SPACING_MARK, Character.ENCLOSING_MARK, Character.COMBINING_SPACING_MARK,
        Character.DECIMAL_DIGIT_NUMBER, Character.LETTER_NUMBER, Character.OTHER_NUMBER -> true
        else -> false
    }

    private fun isAllDigits(s: String): Boolean {
        if (s.isEmpty()) return false
        var i = 0
        while (i < s.length) {
            val cp = s.codePointAt(i)
            if (!Character.isDigit(cp)) return false
            i += Character.charCount(cp)
        }
        return true
    }

    /** A transcript writes "$5", "10%" and "Q&A"; a speaker says "five dollars", "ten percent", "Q and A". */
    private fun spellSymbols(text: String): String {
        val t = CURRENCY.replace(text) { m -> m.groupValues[2] + " " + currencyName(m.groupValues[1]) }
        return t.replace("%", " percent ").replace("&", " and ")
    }

    /** [(display, norm)]. Lower-case, punctuation gone, apostrophes dropped from norm. */
    fun splitWords(input: String): List<Pair<String, String>> {
        var text = BRACKETS.replace(input, " ")
        text = Normalizer.normalize(text, Normalizer.Form.NFKC).replace('\u2019', '\'').replace('\u2018', '\'')
        text = spellSymbols(text)
        val out = ArrayList<Pair<String, String>>()
        for (raw in SPLIT.split(text)) {
            var a = 0
            var b = raw.length
            while (a < b) {
                val cp = raw.codePointAt(a)
                if (isWordChar(cp)) break
                a += Character.charCount(cp)
            }
            while (b > a) {
                val cp = raw.codePointBefore(b)
                if (isWordChar(cp)) break
                b -= Character.charCount(cp)
            }
            val disp = raw.substring(a, b)
            val sb = StringBuilder()
            var i = 0
            while (i < disp.length) {
                val cp = disp.codePointAt(i)
                if (isWordChar(cp)) sb.appendCodePoint(cp)
                i += Character.charCount(cp)
            }
            val norm = sb.toString().lowercase(Locale.ROOT)
            if (norm.isNotEmpty()) out.add(disp to norm)
        }
        return out
    }

    // ---------------------------------------------------------------------------------------------------------
    // Numbers: "twenty five" -> one token "25", so it equals the digits "25" in a transcript.
    // ---------------------------------------------------------------------------------------------------------

    private const val UNIT = 1
    private const val TEEN = 2
    private const val TENS_CLASS = 3
    private const val HUNDRED = 4
    private const val SCALE = 5

    private fun numClass(w: String): Int {
        val u = UNITS[w]
        if (u != null) return if (u < 10) UNIT else TEEN
        if (w in TENS) return TENS_CLASS
        if (w == "hundred") return HUNDRED
        if (w in SCALES) return SCALE
        return 0
    }

    private fun canFollow(prev: String, cur: String): Boolean {
        val p = numClass(prev)
        val c = numClass(cur)
        if (p == 0 || c == 0) return false
        if (prev == "zero") return false
        return when (p) {
            UNIT, TEEN -> (c == HUNDRED || c == SCALE) && !(p == TEEN && c == HUNDRED)
            TENS_CLASS -> c == UNIT && cur != "zero"
            HUNDRED -> (c == UNIT || c == TEEN || c == TENS_CLASS || c == SCALE) && cur != "zero"
            else -> (c == UNIT || c == TEEN || c == TENS_CLASS || c == HUNDRED) && cur != "zero"   // after thousand / million ...
        }
    }

    private fun numberValue(words: List<String>): Long {
        var total = 0L
        var cur = 0L
        for (w in words) {
            if (w == "and") continue
            val u = UNITS[w]
            val t = TENS[w]
            when {
                u != null -> cur += u
                t != null -> cur += t
                w == "hundred" -> cur = (if (cur != 0L) cur else 1L) * 100L
                else -> {
                    total += (if (cur != 0L) cur else 1L) * SCALES.getValue(w)
                    cur = 0L
                }
            }
        }
        return total + cur
    }

    /** A year said in two halves ("nineteen eighty four", "twenty twenty", "nineteen oh five"): (value, tokens used). */
    private fun yearAt(toks: List<Tok>, i: Int): Pair<Int, Int>? {
        val p = YEAR_PREFIX[toks[i].norm] ?: return null
        if (i + 1 >= toks.size) return null
        val a = toks[i + 1].norm
        val b = if (i + 2 < toks.size) toks[i + 2].norm else ""
        val ta = TENS[a]
        val ua = UNITS[a]
        val ub = UNITS[b]
        if (ta != null) {
            return if (ub != null && ub in 1..9) Pair(p * 100 + ta + ub, 3) else Pair(p * 100 + ta, 2)
        }
        if (ua != null && ua in 10..19) return Pair(p * 100 + ua, 2)
        if ((a == "oh" || a == "o") && ub != null && ub in 1..9) return Pair(p * 100 + ub, 3)
        return null
    }

    private fun joinRun(run: List<Tok>, norm: String, seg: Int): Tok {
        var minConf = run[0].conf
        for (r in run) if (r.conf < minConf) minConf = r.conf
        return Tok(
            disp = run.joinToString(" ") { it.disp }, norm = norm,
            start = run.first().start, end = run.last().end, conf = minConf, seg = seg, numeric = true
        )
    }

    fun mergeNumbers(toks: List<Tok>): List<Tok> {
        val out = ArrayList<Tok>()
        var i = 0
        while (i < toks.size) {
            val t = toks[i]
            val year = yearAt(toks, i)
            if (year != null) {
                val used = year.second
                out.add(joinRun(toks.subList(i, i + used), year.first.toString(), t.seg))
                i += used
                continue
            }
            if (numClass(t.norm) == 0) {
                if (isAllDigits(t.norm)) t.numeric = true
                out.add(t)
                i += 1
                continue
            }
            val run = ArrayList<Tok>()
            run.add(t)
            var prev = t.norm
            var k = i + 1
            while (k < toks.size) {
                val cur = toks[k].norm
                if (cur == "and" && (numClass(prev) == HUNDRED || numClass(prev) == SCALE) && k + 1 < toks.size &&
                    canFollow(prev, toks[k + 1].norm)
                ) {
                    run.add(toks[k])
                    run.add(toks[k + 1])
                    prev = toks[k + 1].norm
                    k += 2
                } else if (canFollow(prev, cur)) {
                    run.add(toks[k])
                    prev = cur
                    k += 1
                } else {
                    break
                }
            }
            val value = numberValue(run.map { it.norm })
            out.add(joinRun(run, value.toString(), t.seg))
            i = k
        }
        return out
    }

    private fun finish(toks: List<Tok>, settings: CheckSettings): List<Tok> {
        val kept = if (settings.ignoreFillers) toks.filter { it.norm !in FILLERS } else toks
        return mergeNumbers(kept)
    }

    /** All transcript words, plus for each segment the range [from, to) of its words in that list. */
    fun tokenizeTranscript(segments: List<CheckSegment>, settings: CheckSettings): Pair<List<Tok>, List<IntArray>> {
        val all = ArrayList<Tok>()
        val ranges = ArrayList<IntArray>()
        for ((k, seg) in segments.withIndex()) {
            val toks = finish(splitWords(seg.text).map { (d, n) -> Tok(d, n, seg = k) }, settings)
            for ((w, t) in toks.withIndex()) {
                t.seg = k
                t.widx = w
            }
            ranges.add(intArrayOf(all.size, all.size + toks.size))
            all.addAll(toks)
        }
        return all to ranges
    }

    /** What was heard, in time order. A multi-word recognizer item has its time shared out evenly between its words. */
    fun tokenizeSpoken(spoken: List<SpokenWord>, settings: CheckSettings): List<Tok> {
        val toks = ArrayList<Tok>()
        for (sp in spoken.sortedWith(compareBy<SpokenWord>({ it.startMs }, { it.endMs }))) {
            val parts = splitWords(sp.text)
            if (parts.isEmpty()) continue
            val span = maxOf(0L, sp.endMs - sp.startMs)
            for ((i, p) in parts.withIndex()) {
                toks.add(
                    Tok(
                        p.first, p.second,
                        start = sp.startMs + span * i / parts.size,
                        end = sp.startMs + span * (i + 1) / parts.size,
                        conf = sp.conf
                    )
                )
            }
        }
        return finish(toks, settings)
    }
}
