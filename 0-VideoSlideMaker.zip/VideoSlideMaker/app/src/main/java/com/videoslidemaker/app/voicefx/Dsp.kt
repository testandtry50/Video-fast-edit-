package com.videoslidemaker.app.voicefx

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tanh

/*
 * Building blocks for the voice changer. Everything works one sample at a time (so it can run on
 * a live stream or on a whole file) and uses Double throughout, which keeps long recordings exact.
 *
 * tools/voicefx-reference/dsp.py is the Python original of this code, checked by run_tests.py.
 */

const val TWO_PI: Double = 2.0 * PI

/** xorshift32: tiny, fast and identical on every device, so noise is repeatable. */
class Rng(seed: Int) {
    private var s: Int = if (seed == 0) 1 else seed

    fun nextU32(): Int {
        var x = s
        x = x xor (x shl 13)
        x = x xor (x ushr 17)
        x = x xor (x shl 5)
        s = x
        return x
    }

    /** A value in [-1, 1). */
    fun next(): Double = (nextU32() ushr 8) / 8388608.0 - 1.0

    /** A value in [0, 1). */
    fun unit(): Double = (nextU32() ushr 8) / 16777216.0
}

/** Mixes a per-clip number into a base seed (0 gives the base seed back). */
fun mixSeed(base: Int, seed: Int): Int = base xor (seed * -1640531535)

/** In-place radix-2 complex FFT (forward is unnormalised; inverse is the unnormalised conjugate). */
class Fft(val n: Int) {
    private val cosT = DoubleArray(n / 2)
    private val sinT = DoubleArray(n / 2)
    private val rev = IntArray(n)

    init {
        for (i in 0 until n / 2) {
            cosT[i] = cos(TWO_PI * i / n)
            sinT[i] = sin(TWO_PI * i / n)
        }
        var bits = 0
        while ((1 shl bits) < n) bits++
        for (i in 0 until n) {
            var r = 0
            var v = i
            for (b in 0 until bits) {
                r = (r shl 1) or (v and 1)
                v = v shr 1
            }
            rev[i] = r
        }
    }

    fun transform(re: DoubleArray, im: DoubleArray, inverse: Boolean) {
        for (i in 0 until n) {
            val j = rev[i]
            if (j > i) {
                val tr = re[i]; re[i] = re[j]; re[j] = tr
                val ti = im[i]; im[i] = im[j]; im[j] = ti
            }
        }
        var size = 2
        while (size <= n) {
            val half = size / 2
            val step = n / size
            var start = 0
            while (start < n) {
                var k = 0
                for (j in start until start + half) {
                    val wr = cosT[k]
                    val wi = if (inverse) sinT[k] else -sinT[k]
                    val xr = re[j + half] * wr - im[j + half] * wi
                    val xi = re[j + half] * wi + im[j + half] * wr
                    re[j + half] = re[j] - xr
                    im[j + half] = im[j] - xi
                    re[j] += xr
                    im[j] += xi
                    k += step
                }
                start += size
            }
            size *= 2
        }
    }
}

/** A two-pole filter (the "RBJ cookbook" shapes). Every setter returns this so calls can chain. */
class Biquad {
    private var b0 = 1.0
    private var b1 = 0.0
    private var b2 = 0.0
    private var a1 = 0.0
    private var a2 = 0.0
    private var z1 = 0.0
    private var z2 = 0.0

    private fun setCoeffs(nb0: Double, nb1: Double, nb2: Double, a0: Double, na1: Double, na2: Double) {
        b0 = nb0 / a0
        b1 = nb1 / a0
        b2 = nb2 / a0
        a1 = na1 / a0
        a2 = na2 / a0
    }

    fun process(x: Double): Double {
        val y = b0 * x + z1
        z1 = b1 * x - a1 * y + z2
        z2 = b2 * x - a2 * y
        return y
    }

    private fun omega(fs: Int, f0: Double): Double = TWO_PI * min(max(f0, 10.0), fs * 0.45) / fs

    fun lowpass(fs: Int, f0: Double, q: Double): Biquad {
        val w = omega(fs, f0); val c = cos(w); val al = sin(w) / (2 * q)
        setCoeffs((1 - c) / 2, 1 - c, (1 - c) / 2, 1 + al, -2 * c, 1 - al)
        return this
    }

    fun highpass(fs: Int, f0: Double, q: Double): Biquad {
        val w = omega(fs, f0); val c = cos(w); val al = sin(w) / (2 * q)
        setCoeffs((1 + c) / 2, -(1 + c), (1 + c) / 2, 1 + al, -2 * c, 1 - al)
        return this
    }

    /** Band-pass with constant 0 dB peak gain. */
    fun bandpass(fs: Int, f0: Double, q: Double): Biquad {
        val w = omega(fs, f0); val c = cos(w); val al = sin(w) / (2 * q)
        setCoeffs(al, 0.0, -al, 1 + al, -2 * c, 1 - al)
        return this
    }

    fun lowShelf(fs: Int, f0: Double, gainDb: Double): Biquad {
        val a = 10.0.pow(gainDb / 40); val w = omega(fs, f0); val c = cos(w); val s = sin(w)
        val beta = 2 * sqrt(a) * (s / 2) * sqrt(2.0)
        setCoeffs(
            a * ((a + 1) - (a - 1) * c + beta), 2 * a * ((a - 1) - (a + 1) * c),
            a * ((a + 1) - (a - 1) * c - beta), (a + 1) + (a - 1) * c + beta,
            -2 * ((a - 1) + (a + 1) * c), (a + 1) + (a - 1) * c - beta
        )
        return this
    }

    fun highShelf(fs: Int, f0: Double, gainDb: Double): Biquad {
        val a = 10.0.pow(gainDb / 40); val w = omega(fs, f0); val c = cos(w); val s = sin(w)
        val beta = 2 * sqrt(a) * (s / 2) * sqrt(2.0)
        setCoeffs(
            a * ((a + 1) + (a - 1) * c + beta), -2 * a * ((a - 1) + (a + 1) * c),
            a * ((a + 1) + (a - 1) * c - beta), (a + 1) - (a - 1) * c + beta,
            2 * ((a - 1) - (a + 1) * c), (a + 1) - (a - 1) * c - beta
        )
        return this
    }
}

/** y += k * (x - y), with k set from a cut-off frequency. */
class OnePole(fs: Int, fc: Double) {
    private var y = 0.0
    private val k: Double = 1.0 - exp(-TWO_PI * min(fc, fs * 0.45) / fs)

    fun process(x: Double): Double {
        y += k * (x - y)
        return y
    }
}

/** Circular delay. Call write() once per sample, then read at a delay of 1 or more samples (2+ for [read]). */
class DelayLine(maxSamples: Int) {
    private val buf: DoubleArray
    private val mask: Int
    private var w = 0

    init {
        var size = 1
        while (size < maxSamples + 8) size *= 2
        buf = DoubleArray(size)
        mask = size - 1
    }

    fun write(x: Double) {
        w = (w + 1) and mask
        buf[w] = x
    }

    fun readInt(d: Int): Double = buf[(w - d) and mask]

    /** Fractional delay (cubic interpolation). [d] must be at least 2 samples. */
    fun read(d: Double): Double {
        val pos = w - d
        val i = floor(pos).toInt()
        val f = pos - i
        val y0 = buf[(i - 1) and mask]
        val y1 = buf[i and mask]
        val y2 = buf[(i + 1) and mask]
        val y3 = buf[(i + 2) and mask]
        val c1 = 0.5 * (y2 - y0)
        val c2 = y0 - 2.5 * y1 + 2.0 * y2 - 0.5 * y3
        val c3 = 0.5 * (y3 - y0) + 1.5 * (y1 - y2)
        return ((c3 * f + c2) * f + c1) * f + y1
    }
}

/** Freeverb: 8 comb filters + 4 all-pass filters per ear. [process] returns ONLY the reverberated part. */
class Reverb(fs: Int, room: Double, damp: Double, private val wet: Double, predelayMs: Double) {
    private val combsL: Array<DoubleArray>
    private val combsR: Array<DoubleArray>
    private val ciL = IntArray(8)
    private val ciR = IntArray(8)
    private val csL = DoubleArray(8)
    private val csR = DoubleArray(8)
    private val apL: Array<DoubleArray>
    private val apR: Array<DoubleArray>
    private val aiL = IntArray(4)
    private val aiR = IntArray(4)
    private val feedback: Double = room * 0.28 + 0.7
    private val damp1: Double = damp * 0.4
    private val damp2: Double = 1.0 - damp * 0.4
    private val pre: DelayLine
    private val preN: Int

    init {
        val sc = fs / 44100.0
        combsL = Array(8) { DoubleArray(max(1, Math.round(COMB[it] * sc).toInt())) }
        combsR = Array(8) { DoubleArray(max(1, Math.round((COMB[it] + SPREAD) * sc).toInt())) }
        apL = Array(4) { DoubleArray(max(1, Math.round(ALLPASS[it] * sc).toInt())) }
        apR = Array(4) { DoubleArray(max(1, Math.round((ALLPASS[it] + SPREAD) * sc).toInt())) }
        val pd = (predelayMs * 0.001 * fs).toInt()
        pre = DelayLine(max(pd, 1) + 2)
        preN = pd
    }

    fun process(l: Double, r: Double, out: DoubleArray) {
        var x = (l + r) * 0.015
        if (preN > 0) {
            pre.write(x)
            x = pre.readInt(preN)
        }
        var outL = 0.0
        var outR = 0.0
        for (i in 0 until 8) {
            var b = combsL[i]
            var k = ciL[i]
            var o = b[k]
            csL[i] = o * damp2 + csL[i] * damp1
            b[k] = x + csL[i] * feedback
            ciL[i] = if (k + 1 < b.size) k + 1 else 0
            outL += o

            b = combsR[i]
            k = ciR[i]
            o = b[k]
            csR[i] = o * damp2 + csR[i] * damp1
            b[k] = x + csR[i] * feedback
            ciR[i] = if (k + 1 < b.size) k + 1 else 0
            outR += o
        }
        for (i in 0 until 4) {
            var b = apL[i]
            var k = aiL[i]
            var bo = b[k]
            b[k] = outL + bo * 0.5
            outL = -outL + bo
            aiL[i] = if (k + 1 < b.size) k + 1 else 0

            b = apR[i]
            k = aiR[i]
            bo = b[k]
            b[k] = outR + bo * 0.5
            outR = -outR + bo
            aiR[i] = if (k + 1 < b.size) k + 1 else 0
        }
        out[0] = outL * wet
        out[1] = outR * wet
    }

    private companion object {
        val COMB = intArrayOf(1116, 1188, 1277, 1356, 1422, 1491, 1557, 1617)
        val ALLPASS = intArrayOf(556, 441, 341, 225)
        const val SPREAD = 23
    }
}

/** Keeps the output below full scale without a hard click: linear up to 0.9, then a soft knee. */
fun softLimit(y: Double): Double {
    val a = abs(y)
    if (a <= 0.9) return y
    val s = 0.9 + 0.1 * tanh((a - 0.9) / 0.1)
    return if (y > 0) s else -s
}
