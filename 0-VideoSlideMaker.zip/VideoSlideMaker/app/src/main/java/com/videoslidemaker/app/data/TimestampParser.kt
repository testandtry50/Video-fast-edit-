package com.videoslidemaker.app.data

/**
 * The one place in the app that turns text into a time, and a time back into text.
 *
 * Every accepted timestamp is normalised to a whole number of MILLISECONDS (a [Long]). All
 * arithmetic is integer arithmetic — no floating point is involved until a caller deliberately
 * divides by 1000 to get seconds — so there is no rounding drift, and milliseconds can never be
 * mistaken for seconds. The object holds no mutable state, so it is safe to call from any thread.
 *
 * ## Accepted formats (leading zeros optional everywhere, whitespace around the value ignored)
 *
 * | Shape                  | Meaning                    | Examples                         |
 * |------------------------|----------------------------|----------------------------------|
 * | `S` / `S.fff`          | seconds                    | `12`, `12.5`                     |
 * | `M:SS` / `M:SS.fff`    | minutes:seconds            | `0:05`, `1:23`, `00:00.000`      |
 * | `H:MM:SS`              | hours:minutes:seconds      | `00:00:00`, `01:23:45`           |
 * | `H:MM:SS.fff`          | hours:minutes:seconds.ms   | `00:00:00.000`, `01:23:45.500`   |
 * | `M:SS:mmm`             | minutes:seconds:ms         | `00:00:000`, `1:23:456`          |
 *
 * ## How the two three-part shapes are told apart
 * `H:MM:SS` and `M:SS:mmm` look alike, so the rule is deliberately simple and never guesses:
 * a three-part value with NO decimal point whose last part is EXACTLY three digits is
 * minutes:seconds:milliseconds. Anything else three-part is hours:minutes:seconds. This is
 * unambiguous because a three-digit "seconds" part (100–999) is never valid in hours:minutes:
 * seconds, so no real HH:MM:SS value can be misread as milliseconds.
 *
 * ## Ranges
 * - Seconds are 0–59 whenever a colon is used, and minutes are 0–59 when hours are present.
 * - In `M:SS` the minutes may exceed 59 (`90:00` = 90 minutes). The app has always accepted
 *   this (e.g. "15:00" for a long photo), so existing scripts keep working.
 * - A bare number is seconds and may exceed 59 (`75` = 75 s), as before.
 * - More than three decimal digits are rounded half-up to the nearest millisecond.
 * - Anything above [MAX_MILLIS] (99:59:59.999) is rejected as a probable typo.
 */
object TimestampParser {

    /** Largest accepted timestamp: 99:59:59.999. */
    const val MAX_MILLIS: Long = 100L * 3_600_000L - 1L

    private const val MS_PER_SECOND = 1_000L
    private const val MS_PER_MINUTE = 60_000L
    private const val MS_PER_HOUR = 3_600_000L

    sealed class Result {
        /** [millis] is always in 0..[MAX_MILLIS]. */
        data class Ok(val millis: Long) : Result()

        /** [message] is written for the end user and already quotes the offending text. */
        data class Error(val message: String) : Result()
    }

    /** Internal control-flow signal; always caught inside [parse] and never escapes it. */
    private class Rejected(message: String) : Exception(message, null, false, false)

    // ------------------------------------------------------------------------------------
    // Parsing
    // ------------------------------------------------------------------------------------

    /** Parses [raw] and either returns the time in milliseconds or a clear error message. */
    fun parse(raw: String): Result =
        try {
            Result.Ok(parseOrThrow(raw))
        } catch (e: Rejected) {
            Result.Error(e.message ?: "Invalid timestamp.")
        }

    /** Convenience for callers that only care whether it parsed: milliseconds, or null. */
    fun parseMillisOrNull(raw: String): Long? = (parse(raw) as? Result.Ok)?.millis

    private fun parseOrThrow(raw: String): Long {
        val s = trimPadding(raw)
        if (s.isEmpty()) throw Rejected("Timestamp is empty.")
        val shown = quote(s)

        // 1. Alphabet check. ASCII digits only: this deliberately rejects things like Arabic-Indic
        //    digits, 'd'/'f' suffixes, exponents ("1e3"), "NaN" and "Infinity", all of which a
        //    general-purpose string-to-double conversion would quietly accept.
        for (i in s.indices) {
            val c = s[i]
            if (c in '0'..'9' || c == ':' || c == '.') continue
            throw Rejected(
                when {
                    i == 0 && (c == '-' || c == '\u2212') ->
                        "$shown is negative — timestamps can't be negative."
                    c.isWhitespace() ->
                        "$shown has a space inside it — write it without spaces, like 1:23."
                    else ->
                        "$shown contains '$c', which isn't allowed — use only digits, ':' and '.'."
                }
            )
        }

        // 2. Split off the optional decimal part. It may only appear once, at the very end.
        val dot = s.indexOf('.')
        if (dot != s.lastIndexOf('.')) throw Rejected("$shown has more than one decimal point.")
        val clock = if (dot < 0) s else s.substring(0, dot)
        val frac: String? = if (dot < 0) null else s.substring(dot + 1)
        if (frac != null) {
            if (frac.isEmpty()) throw Rejected("$shown ends with '.' — add the milliseconds after it, like 1:23.500.")
            if (frac.contains(':')) throw Rejected("$shown has ':' after the decimal point — the decimal part must come last, like 1:23.500.")
        }
        if (clock.isEmpty()) throw Rejected("$shown is missing the number before the '.'.")

        // 3. Split the clock part on ':'.
        val fields = clock.split(':')
        if (fields.size > 3) {
            throw Rejected("$shown has too many parts — use at most hours:minutes:seconds, like 1:23:45.")
        }
        if (fields.any { it.isEmpty() }) {
            throw Rejected("$shown has an empty part around a ':' — write it like 1:23 or 1:23:45.")
        }
        val fracMs = if (frac == null) 0L else fractionToMillis(frac)

        // 4. Interpret by shape. Each branch yields the total in milliseconds.
        val total: Long = when (fields.size) {
            1 -> {
                bigField(fields[0], shown) * MS_PER_SECOND + fracMs
            }

            2 -> {
                bigField(fields[0], shown) * MS_PER_MINUTE +
                    smallField(fields[1], "seconds", shown) * MS_PER_SECOND + fracMs
            }

            else -> {
                val a = fields[0]
                val b = fields[1]
                val c = fields[2]
                when {
                    c.length > 3 -> throw Rejected("$shown — the last part has too many digits.")

                    c.length == 3 && frac != null ->
                        throw Rejected("$shown — a 3-digit last part after ':' means milliseconds (like 00:00:000), so it can't also have a decimal point.")

                    // M:SS:mmm — no decimal point, last part exactly three digits (000..999).
                    c.length == 3 ->
                        bigField(a, shown) * MS_PER_MINUTE +
                            smallField(b, "seconds", shown) * MS_PER_SECOND +
                            digitsToLong(c)

                    // H:MM:SS[.fff]
                    else ->
                        bigField(a, shown) * MS_PER_HOUR +
                            smallField(b, "minutes", shown) * MS_PER_MINUTE +
                            smallField(c, "seconds", shown) * MS_PER_SECOND + fracMs
                }
            }
        }

        if (total > MAX_MILLIS) throw tooLarge(shown)
        return total
    }

    /** A leading field with no 0–59 limit (hours, bare seconds, or minutes in M:SS). */
    private fun bigField(field: String, shown: String): Long {
        var start = 0
        while (start < field.length - 1 && field[start] == '0') start++
        // More than 9 significant digits can't be a sane time and would risk overflow below.
        if (field.length - start > 9) throw tooLarge(shown)
        return digitsToLong(field)
    }

    /** A seconds/minutes field that must be 1–2 digits and 0–59. */
    private fun smallField(field: String, what: String, shown: String): Long {
        if (field.length > 2) throw Rejected("$shown — the $what part must be 1–2 digits (0–59).")
        val v = digitsToLong(field)
        if (v > 59) throw Rejected("$shown — $what must be between 0 and 59 (got $v).")
        return v
    }

    /** Pure ASCII-digit string → Long. Callers guarantee digits only and a safe length. */
    private fun digitsToLong(digits: String): Long {
        var v = 0L
        for (ch in digits) v = v * 10 + (ch - '0')
        return v
    }

    /**
     * Digits after the decimal point → milliseconds. The first three digits are the
     * milliseconds; if there are more, the fourth digit decides rounding (half-up). The result
     * can be 1000 after rounding, which the caller simply adds in, so the carry into the next
     * second happens automatically.
     */
    private fun fractionToMillis(frac: String): Long {
        var ms = 0L
        for (i in 0 until 3) {
            ms = ms * 10 + (if (i < frac.length) (frac[i] - '0') else 0)
        }
        if (frac.length > 3 && frac[3] >= '5') ms += 1
        return ms
    }

    private fun tooLarge(shown: String) =
        Rejected("$shown is longer than the maximum supported time (99:59:59.999).")

    private fun quote(s: String): String = if (s.length <= 24) "\"$s\"" else "\"${s.take(24)}…\""

    /**
     * Trims whitespace AND invisible "format" characters (byte-order mark, zero-width space,
     * left-to-right mark, …) from both ends. Plain trim() leaves those in place, and they are
     * easy to pick up by copy-pasting from chat apps or from a text file saved with a BOM —
     * the first timestamp of such a file would otherwise fail to parse.
     */
    fun trimPadding(s: String): String {
        var start = 0
        var end = s.length
        while (start < end && isPadding(s[start])) start++
        while (end > start && isPadding(s[end - 1])) end--
        return s.substring(start, end)
    }

    private fun isPadding(c: Char) = c.isWhitespace() || c.category == CharCategory.FORMAT

    // ------------------------------------------------------------------------------------
    // Formatting
    // ------------------------------------------------------------------------------------

    /**
     * Display form that adapts to the value:
     *  - under an hour:   `m:ss`     (e.g. `0:05`, `12:30`)
     *  - an hour or more: `h:mm:ss`  (e.g. `1:05:00`)
     *  - `.mmm` is appended only when [includeMillis] is true AND the value actually has a
     *    non-zero millisecond part, always as exactly three digits (`0:02.500`, never `0:02.5`).
     * Every string this produces parses back to exactly the same milliseconds.
     * Negative input is shown as zero.
     */
    fun format(millis: Long, includeMillis: Boolean = true): String {
        val total = if (millis < 0) 0L else millis
        val wholeSeconds = total / MS_PER_SECOND
        val ms = (total % MS_PER_SECOND).toInt()
        val h = wholeSeconds / 3600
        val m = ((wholeSeconds % 3600) / 60).toInt()
        val s = (wholeSeconds % 60).toInt()

        val base = if (h > 0) "$h:${pad2(m)}:${pad2(s)}" else "$m:${pad2(s)}"
        return if (includeMillis && ms != 0) "$base.${ms.toString().padStart(3, '0')}" else base
    }

    /** Fixed, fully-padded form `HH:MM:SS.mmm` (e.g. `01:23:45.500`) — handy for logs/tests. */
    fun formatCanonical(millis: Long): String {
        val total = if (millis < 0) 0L else millis
        val h = total / MS_PER_HOUR
        val m = (total % MS_PER_HOUR) / MS_PER_MINUTE
        val s = (total % MS_PER_MINUTE) / MS_PER_SECOND
        val ms = total % MS_PER_SECOND
        return "${h.toString().padStart(2, '0')}:${pad2(m.toInt())}:${pad2(s.toInt())}.${ms.toString().padStart(3, '0')}"
    }

    private fun pad2(n: Int) = n.toString().padStart(2, '0')
}
