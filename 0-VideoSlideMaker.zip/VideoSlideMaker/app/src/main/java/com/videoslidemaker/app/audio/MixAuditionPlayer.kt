package com.videoslidemaker.app.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import java.io.File
import java.io.RandomAccessFile
import kotlin.math.max
import kotlin.math.min

/**
 * NEW (2.17): plays a short built piece of the mix (16-bit PCM in a file) so the sound can be checked before exporting.
 * Streams it in small pieces - nothing large is held in memory - and stops the moment the calling coroutine is cancelled.
 */
class MixAuditionPlayer {

    /** Plays [totalBytes] of [file]; returns when it has finished or was cancelled. [onPositionSec] reports how far it is. */
    suspend fun play(file: File, sampleRate: Int, channels: Int, totalBytes: Long, onPositionSec: (Double) -> Unit) {
        withContext(Dispatchers.IO) {
            val mask = if (channels == 1) AudioFormat.CHANNEL_OUT_MONO else AudioFormat.CHANNEL_OUT_STEREO
            val bytesPerFrame = channels * 2
            val minBuffer = AudioTrack.getMinBufferSize(sampleRate, mask, AudioFormat.ENCODING_PCM_16BIT)
            val bufferSize = max(minBuffer, sampleRate * bytesPerFrame / 4)
            val track = AudioTrack.Builder()
                .setAudioAttributes(
                    CallAudio.attributes(AudioAttributes.USAGE_MEDIA, AudioAttributes.CONTENT_TYPE_MUSIC)
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sampleRate)
                        .setChannelMask(mask)
                        .build()
                )
                .setBufferSizeInBytes(bufferSize)
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()
            try {
                track.play()
                val totalFrames = totalBytes / bytesPerFrame
                RandomAccessFile(file, "r").use { raf ->
                    val buf = ByteArray(bytesPerFrame * 4096)
                    var done = 0L
                    while (done < totalBytes) {
                        ensureActive()
                        val n = raf.read(buf, 0, min(buf.size.toLong(), totalBytes - done).toInt())
                        if (n <= 0) break
                        track.write(buf, 0, n)
                        done += n
                    }
                }
                // everything is handed over; wait for what is still queued to be heard
                while (isActive && track.playbackHeadPosition < totalFrames) {
                    onPositionSec(track.playbackHeadPosition.toDouble() / sampleRate)
                    delay(40)
                }
                onPositionSec(totalFrames.toDouble() / sampleRate)
            } finally {
                runCatching { track.stop() }
                runCatching { track.release() }
            }
        }
    }
}
