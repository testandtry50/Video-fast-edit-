package com.videoslidemaker.app.check

import org.json.JSONObject

/** Reads the JSON text Vosk returns for a stretch of speech. */
object VoskJson {

    /**
     * `{"result":[{"conf":0.98,"start":0.9,"end":1.2,"word":"hello"}, ...],"text":"hello ..."}` -> words, with times in
     * milliseconds and [offsetMs] added (where the recording's audio starts). Anything unreadable gives no words rather
     * than an error: a silent stretch is a normal result.
     */
    fun parseWords(json: String?, offsetMs: Long): List<SpokenWord> {
        if (json.isNullOrBlank()) return emptyList()
        val root = try {
            JSONObject(json)
        } catch (e: Exception) {
            return emptyList()
        }
        val arr = root.optJSONArray("result") ?: return emptyList()
        val out = ArrayList<SpokenWord>(arr.length())
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val word = o.optString("word", "")
            if (word.isEmpty()) continue
            val start = Math.round(o.optDouble("start", 0.0) * 1000.0)
            val end = Math.round(o.optDouble("end", o.optDouble("start", 0.0)) * 1000.0)
            out.add(SpokenWord(word, offsetMs + start, offsetMs + maxOf(start, end), o.optDouble("conf", 1.0)))
        }
        return out
    }
}
