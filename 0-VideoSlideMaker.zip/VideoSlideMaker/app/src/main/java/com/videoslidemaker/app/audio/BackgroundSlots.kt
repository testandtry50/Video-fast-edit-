package com.videoslidemaker.app.audio

import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * NEW (2.18): one scene of the Match step as a stretch of the video's timeline (seconds). The scene is the sentence
 * [startSec] belongs to: it lasts until the next sentence begins (or, for the last one, the default photo time).
 */
data class SceneSpan(val startSec: Double, val endSec: Double)

/** Where a scene stands in relation to a background-audio slot. */
enum class BadgeKind {
    /** The slot begins in this scene (and goes on after it, or has no end yet). */
    START,
    /** The slot is already playing when this scene begins and is still playing when it ends. */
    MIDDLE,
    /** The slot stops in this scene. */
    END,
    /** The slot begins AND stops inside this one scene. */
    WHOLE
}

/** A small tag on a scene card: which slot ([label], e.g. "B1") touches this scene and how. */
data class SceneBadge(val label: String, val kind: BadgeKind, val waiting: Boolean)

/** Why a start / end time pair can not be used (see [BgSlots.checkTimes]). */
enum class TimeProblem(val message: String) {
    START_OUT_OF_VIDEO("The start has to be inside the video."),
    END_NOT_AFTER_START("The end has to be after the start."),
    END_OUT_OF_VIDEO("The end can not be after the end of the video.")
}

/** How a slot's audio file fits the time range given to it (see [BgSlots.fit]). */
sealed class SlotFit {
    /** No audio file has been chosen yet: the slot is silent. */
    object Empty : SlotFit()
    /** A file is chosen but no end yet: it plays its own length from the start. */
    data class NoEnd(val fileSec: Double) : SlotFit()
    /** The file is as long as the range (to a tenth of a second). */
    data class Exact(val rangeSec: Double) : SlotFit()
    /** The file is longer than the range: only the first [usedSec] of it plays (cut at the end). */
    data class Trimmed(val fileSec: Double, val usedSec: Double) : SlotFit()
    /** The file is shorter than the range: it repeats [times] times (a fraction means the last round is cut short). */
    data class Repeats(val fileSec: Double, val rangeSec: Double, val times: Double) : SlotFit()
    /** NEW (2.19): a one-shot sound (a door, a whoosh) that is shorter than the range: it plays once, from the start. */
    data class PlaysOnce(val fileSec: Double, val rangeSec: Double) : SlotFit()
}

/**
 * NEW (2.18): everything the Match step's "background audio" feature decides, as plain functions on plain data (no
 * Android, no files), so all of it is tested on a plain JVM.
 *
 * The idea: pressing and holding a scene can add a background-audio SLOT - an [AudioClip] in the background lane that has
 * a short unique name ("B1", "B2", ...), a start time, no audio file yet and, later, an end time. The slot is in the
 * project (saved, undone, listed in chronological order) from the moment it is made. Choosing the audio file afterwards
 * only fills it in. With a start and an end the audio is fitted to the range when the video is made: a file that is too
 * long is cut, one that is too short is repeated (see [ClipEdit.followRange]).
 */
object BgSlots {
    /** A slot has to be at least this long (the same as the shortest clip the editor keeps). */
    const val MIN_SPAN_SEC = AudioLimits.MIN_CLIP_SEC

    /** A short fade at both ends of a slot's sound, so cutting a file at the range's edges never clicks. */
    const val DEFAULT_FADE_SEC = 0.3

    /** Rounding noise: two times closer than this are the same moment. */
    private const val EPS = 1e-6

    // ------------------------------------------------------------------------------------
    // Names and lists
    // ------------------------------------------------------------------------------------

    /** The number inside a slot name ("B3" -> 3); 0 for anything that is not one. */
    fun number(label: String): Int = label.removePrefix("B").toIntOrNull()?.coerceAtLeast(0) ?: 0

    /** The next unused name: one more than the highest number ever used in this project ("B1", then "B2", ...). */
    fun nextLabel(audio: AudioMixSettings): String {
        val highest = (audio.main + audio.background).maxOfOrNull { number(it.slot) } ?: 0
        return "B${highest + 1}"
    }

    /** True for a clip that was made as a slot. */
    fun isSlot(c: AudioClip): Boolean = c.slot.isNotEmpty()

    /** All slots, in chronological order (the earlier start first; the lower number first when they start together). */
    fun slots(audio: AudioMixSettings): List<AudioClip> =
        audio.background.filter { isSlot(it) }.sortedWith(compareBy<AudioClip>({ it.startSec }, { number(it.slot) }))

    /** Slots that have a start but no end yet - the ones the "End background audio" choice is for. */
    fun openSlots(audio: AudioMixSettings): List<AudioClip> = slots(audio).filter { !it.hasRange }

    /** Slots that still have no audio file. */
    fun emptySlots(audio: AudioMixSettings): List<AudioClip> = slots(audio).filter { it.isPlaceholder }

    // ------------------------------------------------------------------------------------
    // Making and changing slots
    // ------------------------------------------------------------------------------------

    /** Which problem, if any, stops [startSec] / [endSec] from being used in a video that is [totalSec] long. */
    fun checkTimes(startSec: Double, endSec: Double?, totalSec: Double): TimeProblem? {
        if (startSec.isNaN() || startSec < 0.0 || (totalSec > 0.0 && startSec > totalSec - MIN_SPAN_SEC + EPS)) {
            return TimeProblem.START_OUT_OF_VIDEO
        }
        if (endSec == null) return null
        if (endSec.isNaN() || endSec < startSec + MIN_SPAN_SEC - EPS) return TimeProblem.END_NOT_AFTER_START
        if (totalSec > 0.0 && endSec > totalSec + EPS) return TimeProblem.END_OUT_OF_VIDEO
        return null
    }

    /** An empty slot named [label], starting at [startSec] and (when given) ending at [endSec]. No audio file yet. */
    fun placeholder(id: String, label: String, startSec: Double, endSec: Double?): AudioClip = AudioClip(
        id = id,
        uri = "",
        // Until a file is chosen the slot's name IS its label; choosing a file replaces it with the file's name.
        name = label,
        sourceDurationSec = 0.0,
        srcEndSec = 0.0,
        startSec = startSec,
        fadeInSec = DEFAULT_FADE_SEC,
        fadeOutSec = DEFAULT_FADE_SEC,
        slot = label,
        rangeEndSec = endSec ?: 0.0
    )

    /** Adds the empty slot. The caller checks the times first with [checkTimes]. */
    fun add(audio: AudioMixSettings, id: String, label: String, startSec: Double, endSec: Double?): AudioMixSettings =
        audio.copy(background = audio.background + placeholder(id, label, startSec, endSec))

    /**
     * Gives slot [id] new times. [endSec] = null takes the end away (the slot is "not ended" again). The caller checks
     * the times first with [checkTimes]; as a last safety an end that is not after the start is also taken away.
     */
    fun setTimes(audio: AudioMixSettings, id: String, startSec: Double, endSec: Double?): AudioMixSettings {
        val end = if (endSec != null && endSec >= startSec + MIN_SPAN_SEC - EPS) endSec else null
        return audio.editClip(id) { c -> if (isSlot(c)) c.copy(startSec = startSec.coerceAtLeast(0.0), rangeEndSec = end ?: 0.0) else c }
    }

    // ------------------------------------------------------------------------------------
    // How the audio fits
    // ------------------------------------------------------------------------------------

    /** What happens to this slot's audio when the video is made. */
    fun fit(c: AudioClip): SlotFit {
        if (c.isPlaceholder) return SlotFit.Empty
        // NEW (2.19): the material is the MARKED part of the file when one is marked
        val avail = (c.materialEndSec - c.srcStartSec).coerceAtLeast(0.0)
        if (!c.hasRange) return SlotFit.NoEnd(avail)
        val range = c.rangeEndSec - c.startSec
        return when {
            abs(avail - range) < 0.05 -> SlotFit.Exact(range)
            avail > range -> SlotFit.Trimmed(avail, range)
            c.playOnce -> SlotFit.PlaysOnce(avail, range)
            else -> SlotFit.Repeats(avail, range, if (avail > 0.0) range / avail else 0.0)
        }
    }

    /** One plain sentence about [fit], for the slot's card. */
    fun describeFit(c: AudioClip): String {
        // NEW (2.19): when a part of the file is marked, it is the marked part that is cut or repeated
        val what = if (c.hasMark) "The marked part is" else "File is"
        val exactWhat = if (c.hasMark) "The marked part is" else "The file is"
        return when (val f = fit(c)) {
            is SlotFit.Empty -> "No audio file yet - silent until you choose one."
            is SlotFit.NoEnd -> "Plays its own ${clockShort(f.fileSec)} from the start. Choose an end time to fit it to a range."
            is SlotFit.Exact -> "$exactWhat exactly as long as the ${clockShort(f.rangeSec)} you gave it."
            is SlotFit.Trimmed -> "$what ${clockShort(f.fileSec)}, longer than the ${clockShort(f.usedSec)} range: it is cut to fit."
            is SlotFit.PlaysOnce -> "$what ${clockShort(f.fileSec)}, shorter than the ${clockShort(f.rangeSec)} range: it plays once from the start and is not repeated."
            is SlotFit.Repeats -> {
                val times = ((f.times * 10).roundToInt() / 10.0)
                "$what ${clockShort(f.fileSec)}, shorter than the ${clockShort(f.rangeSec)} range: it repeats" +
                    " (about ${if (times == times.toInt().toDouble()) times.toInt().toString() else times.toString()} times) to fill it."
            }
        }
    }

    // ------------------------------------------------------------------------------------
    // Where slots show on the scene strip
    // ------------------------------------------------------------------------------------

    /** The tags to show on [scene]'s card for these [slots] (already in the order they should be listed). */
    fun badgesFor(slots: List<AudioClip>, scene: SceneSpan): List<SceneBadge> {
        val out = ArrayList<SceneBadge>(2)
        for (c in slots) {
            val startsHere = c.startSec >= scene.startSec - EPS && c.startSec < scene.endSec - EPS
            val end = if (c.hasRange) c.rangeEndSec else null
            val endsHere = end != null && end > scene.startSec + EPS && end <= scene.endSec + EPS
            val covers = end != null && c.startSec < scene.endSec - EPS && end > scene.startSec + EPS
            val kind = when {
                startsHere && endsHere -> BadgeKind.WHOLE
                startsHere -> BadgeKind.START
                endsHere -> BadgeKind.END
                covers -> BadgeKind.MIDDLE
                else -> null
            } ?: continue
            out.add(SceneBadge(c.slot, kind, c.isPlaceholder))
        }
        return out
    }

    // ------------------------------------------------------------------------------------
    // Time wheels
    // ------------------------------------------------------------------------------------

    /** A time split the way the three wheels show it: minutes, seconds (0-59) and tenths of a second (0-9). */
    data class Parts(val minutes: Int, val seconds: Int, val tenths: Int)

    /** [sec] rounded to the nearest tenth of a second, split for the wheels. */
    fun parts(sec: Double): Parts {
        val t = (sec.coerceAtLeast(0.0) * 10.0).roundToInt()
        return Parts(minutes = t / 600, seconds = (t / 10) % 60, tenths = t % 10)
    }

    /** The wheels' three values as seconds. */
    fun fromParts(minutes: Int, seconds: Int, tenths: Int): Double =
        (minutes.coerceAtLeast(0) * 600 + seconds.coerceIn(0, 59) * 10 + tenths.coerceIn(0, 9)) / 10.0

    /** How many minutes the minutes wheel needs for a video of [totalSec] (it always has at least "0"). */
    fun maxMinutes(totalSec: Double): Int = (totalSec.coerceAtLeast(0.0) / 60.0).toInt()

    /** "m:ss.t" - one decimal, the precision the wheels work to. */
    fun clock(sec: Double): String {
        val p = parts(sec)
        return "${p.minutes}:${p.seconds.toString().padStart(2, '0')}.${p.tenths}"
    }

    /** Like [clock] but without the decimal when it is zero: "0:08", "1:05.5". */
    fun clockShort(sec: Double): String {
        val p = parts(sec)
        val base = "${p.minutes}:${p.seconds.toString().padStart(2, '0')}"
        return if (p.tenths == 0) base else "$base.${p.tenths}"
    }

    /** [sec] kept inside the video (and, for a start, leaving room for at least the shortest slot). */
    fun clampToVideo(sec: Double, totalSec: Double, isStart: Boolean): Double {
        if (totalSec <= 0.0) return sec.coerceAtLeast(0.0)
        val hi = if (isStart) (totalSec - MIN_SPAN_SEC).coerceAtLeast(0.0) else totalSec
        return sec.coerceIn(0.0, hi)
    }

    /** The time the "start" wheels open on: the start of the scene that was pressed. */
    fun suggestStart(scene: SceneSpan, totalSec: Double): Double = clampToVideo(scene.startSec, totalSec, isStart = true)

    /**
     * The time the "end" wheels open on for a slot that starts at [startSec]: the end of the scene that was pressed (so
     * the audio covers that scene), or - if that is not after the start - a few seconds later. Always inside the video.
     */
    fun suggestEnd(startSec: Double, scene: SceneSpan, totalSec: Double): Double {
        val wanted = if (scene.endSec >= startSec + MIN_SPAN_SEC) scene.endSec else startSec + 3.0
        val inside = if (totalSec > 0.0) wanted.coerceAtMost(totalSec) else wanted
        return if (inside >= startSec + MIN_SPAN_SEC) inside else (startSec + MIN_SPAN_SEC)
    }
}
