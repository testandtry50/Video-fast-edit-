package com.videoslidemaker.app.logoclean

import android.content.Context
import android.os.SystemClock
import com.videoslidemaker.app.data.ImageStore
import com.videoslidemaker.app.model.PoolImage
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.joinAll
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger

/** Which photos "Clean all" touches. */
enum class CleanAllMode {
    /** Only photos where the logo is found at the same place. Everything else is left alone. */
    WHERE_FOUND,

    /** Photos where the logo is found at the same place OR anywhere else (follows a moving logo). */
    WHERE_FOUND_MOVING,

    /** Every photo, at exactly the box the user set, without checking whether a logo is there. */
    SAME_SPOT
}

/** What the logo cleaner screen shows. */
data class LogoCleanUi(
    val scanning: Boolean = false,
    val working: Boolean = false,
    val done: Int = 0,
    val total: Int = 0,
    val candidates: List<LogoCandidate> = emptyList(),
    val selected: Int = -1,
    /** Goes up each time a scan the user asked for finishes, so the screen can move its box once. */
    val scanSerial: Int = 0,
    val message: String? = null,
    val messageIsProblem: Boolean = false,
    /** True while a run over many photos is going: the screen then shows the big progress card. */
    val bulk: Boolean = false,
    /** What the big progress card says it is doing. */
    val stage: String = "",
    /** Counters of the run in progress (photos cleaned / had no logo / could not be processed). */
    val cleaned: Int = 0,
    val skipped: Int = 0,
    val failed: Int = 0,
    /** Photos per second so far, and seconds left at that speed (-1 = not known yet). */
    val perSec: Float = 0f,
    val etaSec: Long = -1L
)

/**
 * Runs the logo cleaner. It owns no photos: it reads the current list through [currentImages] and hands
 * every changed photo back through [replaceImages] (id -> new entry), so the rest of the app - the
 * Photos list, previews, saved draft and export - just sees photos whose uri changed.
 *
 * "Clean ALL" is built for very large projects (100,000+ photos):
 *  - several photos are repainted at the same time (see [BulkMath.workerCount]),
 *  - finished photos are handed back in BATCHES, not one by one (handing back one at a time would rebuild
 *    the whole photo list 100,000 times),
 *  - progress (percent, count, speed, time left) is published a couple of times a second,
 *  - it can be stopped at any time and started again: photos already cleaned are skipped,
 *  - storage is checked first and while running, and
 *  - a foreground service keeps the app running with the screen off or while another app is open.
 */
class LogoCleanController(
    context: Context,
    store: ImageStore,
    private val scope: CoroutineScope,
    private val currentImages: () -> List<PoolImage>,
    private val replaceImages: (Map<String, PoolImage>) -> Unit
) {
    private val appContext = context.applicationContext
    private val cleaner = LogoCleaner(context, store)
    private val _ui = MutableStateFlow(LogoCleanUi())
    val ui: StateFlow<LogoCleanUi> = _ui.asStateFlow()

    private var job: Job? = null
    private var consistency: Consistency? = null
    private var scanKey: Int = 0

    private val busy: Boolean get() = job?.isActive == true

    // ------------------------------------------------------------------------------ small helpers

    private fun keyOf(images: List<PoolImage>): Int = images.map { it.id }.hashCode()

    private fun selectedCandidate(box: LogoBox): LogoCandidate? {
        val s = _ui.value
        return s.candidates.getOrNull(s.selected)?.takeIf { it.box.near(box) }
    }

    private fun tooBig(box: LogoBox): Boolean = box.width * box.height > MAX_BOX_AREA

    private fun problemText(e: Throwable): String =
        if (e is OutOfMemoryError) "The phone ran out of memory on a photo. Try a smaller box, or Blur."
        else "Something went wrong with a photo."

    private fun count(n: Int): String = BulkMath.formatCount(n)

    private fun plural(n: Int, one: String, many: String): String = if (n == 1) one else many

    /** Set when Android ended the background service for running too long (see [LogoCleanService.onTimeout]). */
    @Volatile
    private var timedOut = false

    private fun cap(text: String): String = text.replaceFirstChar { it.uppercase() }

    /** The photos a run is limited to (null = every photo). */
    private fun inScope(only: Set<String>?): List<PoolImage> {
        val all = currentImages()
        return if (only == null) all else all.filter { it.id in only }
    }

    private fun tooBigMessage(target: CleanTarget): String =
        if (target.isText) "That box covers a big part of the photo. Draw it around just the ${target.noun} lines."
        else "That box covers a big part of the photo. Draw it tightly around just the logo."

    private fun noTextMessage(target: CleanTarget): String =
        "I can't see any ${target.noun} in that box in this photo. Draw the box right around the text, or choose " +
            "\"Everywhere in the box\" for short or faint text."

    /** A run on ONE photo. */
    private fun begin(total: Int) {
        _ui.update {
            it.copy(working = true, bulk = false, done = 0, total = total, message = null, messageIsProblem = false)
        }
    }

    /** A run over many photos: the big progress card replaces the small line. */
    private fun beginBulk(total: Int, stage: String) {
        _ui.update {
            it.copy(
                working = true, bulk = true, stage = stage, done = 0, total = total,
                cleaned = 0, skipped = 0, failed = 0, perSec = 0f, etaSec = -1L,
                message = null, messageIsProblem = false
            )
        }
    }

    private fun finish(message: String, problem: Boolean = false) {
        _ui.update {
            it.copy(working = false, scanning = false, bulk = false, message = message, messageIsProblem = problem)
        }
    }

    fun dismissMessage() {
        _ui.update { it.copy(message = null) }
    }

    fun selectCandidate(index: Int) {
        _ui.update { it.copy(selected = index) }
    }

    /** Stops a scan or a "clean all" that is running. What was already cleaned stays cleaned. */
    fun cancel() {
        job?.cancel()
    }

    /** About how much storage cleaning these photos will use (shown before a big run). */
    fun estimateStorageBytes(images: List<PoolImage>): Long = cleaner.estimateBytes(images)

    /** Free storage where cleaned copies are saved. */
    fun freeStorageBytes(): Long = cleaner.freeBytes()

    // ------------------------------------------------------------------------------ scanning

    /** Scan the photos for a logo that repeats (button "Find the logo automatically"). */
    fun scan() {
        if (busy) return
        job = scope.launch { runScan(showCandidates = true) }
    }

    private suspend fun runScan(showCandidates: Boolean): ScanResult? {
        val images = currentImages()
        _ui.update { it.copy(scanning = true, done = 0, total = 0, message = null, messageIsProblem = false) }
        val result = try {
            cleaner.scan(images) { done, total -> _ui.update { s -> s.copy(done = done, total = total) } }
        } catch (e: CancellationException) {
            _ui.update { it.copy(scanning = false, message = "Scan stopped.") }
            throw e
        } catch (e: Exception) {
            finish(problemText(e), problem = true)
            return null
        } catch (e: OutOfMemoryError) {
            finish(problemText(e), problem = true)
            return null
        }
        consistency = result.consistency
        scanKey = keyOf(images)
        if (showCandidates) {
            val found = result.candidates
            val text = when {
                result.sameSize < LogoDetector.MIN_COUNT ->
                    "To find a logo by itself I need at least 3 photos of the same size. You can still drag the box over a logo by hand."
                found.isEmpty() ->
                    "No logo repeats across your photos. You can still drag the box over a logo by hand."
                found.size == 1 -> "Found a logo in ${percent(found[0])} of ${found[0].photos} photos checked. Check the box, then clean."
                else -> "Found ${found.size} possible logos. Tap one to select it."
            }
            _ui.update {
                it.copy(
                    scanning = false,
                    candidates = found,
                    selected = if (found.isEmpty()) -1 else 0,
                    scanSerial = it.scanSerial + 1,
                    message = text,
                    messageIsProblem = found.isEmpty()
                )
            }
        } else {
            _ui.update { it.copy(scanning = false) }
        }
        return result
    }

    private fun percent(c: LogoCandidate): String = "${Math.round(c.support * 100)}%"

    private suspend fun ensureConsistency(): Consistency? {
        val key = keyOf(currentImages())
        val cached = consistency
        if (cached != null && key == scanKey) return cached
        return runScan(showCandidates = false)?.consistency
    }

    // ------------------------------------------------------------------------------ cleaning ONE photo

    /** Clean just this photo, at the box as drawn. [relaxed] only matters for text: short and faint text counts too. */
    fun cleanThis(
        imageId: String, box: LogoBox, mode: LogoCleanMode, strength: Float,
        target: CleanTarget = CleanTarget.LOGO, relaxed: Boolean = false
    ) {
        if (busy) return
        val image = currentImages().firstOrNull { it.id == imageId } ?: return
        if (tooBig(box)) {
            finish(tooBigMessage(target), problem = true)
            return
        }
        job = scope.launch {
            begin(1)
            try {
                if (target.isText) {
                    val result = cleaner.cleanText(image, box, target, mode, strength, relaxed)
                    val cleanedImage = result.image
                    when {
                        result.status == TextStatus.CLEANED && cleanedImage != null -> {
                            replaceImages(mapOf(image.id to cleanedImage))
                            finish("${cap(target.noun)} ${mode.verb} this photo.")
                        }
                        result.status == TextStatus.NO_TEXT -> finish(noTextMessage(target), problem = true)
                        else -> finish("Couldn't clean this photo. Try a smaller box, or Blur.", problem = true)
                    }
                } else {
                    val template = selectedCandidate(box)?.template
                    val out = cleaner.clean(image, box, template, 0f, 0f, mode, strength)
                    if (out != null) {
                        replaceImages(mapOf(image.id to out))
                        finish("Logo ${mode.verb} this photo.")
                    } else {
                        finish("Couldn't clean this photo. Try a smaller box, or Blur.", problem = true)
                    }
                }
            } catch (e: CancellationException) {
                _ui.update { it.copy(working = false) }
                throw e
            } catch (e: Exception) {
                finish(problemText(e), problem = true)
            } catch (e: OutOfMemoryError) {
                finish(problemText(e), problem = true)
            }
        }
    }

    // ------------------------------------------------------------------------------ cleaning ALL photos

    /**
     * Clean every photo, as chosen by [how].
     * [skipCleaned]: leave photos that are already cleaned in this same mode alone - that is what makes
     * "stop now, continue later" cost nothing. Turn it off to redo every photo (new box, new strength).
     * [only]: just these photos (the ones of one segment, or of a range of segments); null = every photo.
     * [target]: a logo is found by what repeats across photos; subtitles and other text are found photo by photo
     * inside the box. For text, [how] = SAME_SPOT means "everywhere in the box, no checking" (short or faint text
     * too); anything else means "only where text is found".
     */
    fun cleanAll(
        box: LogoBox, mode: LogoCleanMode, strength: Float, how: CleanAllMode, skipCleaned: Boolean = true,
        target: CleanTarget = CleanTarget.LOGO, only: Set<String>? = null
    ) {
        if (busy) return
        if (inScope(only).isEmpty()) return
        if (tooBig(box)) {
            finish(tooBigMessage(target), problem = true)
            return
        }
        job = scope.launch {
            var template: LogoTemplate? = if (target.isText) null else selectedCandidate(box)?.template
            if (!target.isText && how != CleanAllMode.SAME_SPOT && template == null) {
                // a box drawn by hand: look for edges inside it that repeat across the photos
                val c = ensureConsistency()
                template = c?.let { cleaner.templateForBox(it, box) }
                if (template == null) {
                    finish(
                        "I can't see a logo that repeats inside that box. Draw it around the whole logo, " +
                            "or choose \"Exact spot, no checking\".",
                        problem = true
                    )
                    return@launch
                }
            }
            runBulk(box, template, how, mode, strength, skipCleaned, target, only)
        }
    }

    /**
     * ONE TAP for everything: finds the logo that repeats across the photos, then cleans ALL photos that
     * have it. Nothing to draw. (If no logo repeats, nothing is changed and the screen says why.)
     */
    fun autoCleanAll(
        mode: LogoCleanMode, strength: Float, follow: Boolean, skipCleaned: Boolean = true,
        only: Set<String>? = null
    ) {
        if (busy) return
        if (inScope(only).isEmpty()) return
        job = scope.launch {
            _ui.update { it.copy(stage = "Looking for the logo\u2026") }
            // runScan already explains on screen when nothing is found (or too few photos of one size)
            val result = runScan(showCandidates = true) ?: return@launch
            val found = result.candidates.firstOrNull() ?: return@launch
            if (tooBig(found.box)) {
                finish("The logo I found covers too much of the photo to be a logo. Draw the box by hand instead.", problem = true)
                return@launch
            }
            runBulk(
                found.box, found.template,
                if (follow) CleanAllMode.WHERE_FOUND_MOVING else CleanAllMode.WHERE_FOUND,
                mode, strength, skipCleaned, CleanTarget.LOGO, only
            )
        }
    }

    /**
     * The batch engine. Runs on whatever thread called it (the screen's), but does the heavy work on
     * [workers] background coroutines that pull the next photo from a shared counter.
     */
    private suspend fun runBulk(
        box: LogoBox, template: LogoTemplate?, how: CleanAllMode,
        mode: LogoCleanMode, strength: Float, skipCleaned: Boolean,
        target: CleanTarget, only: Set<String>?
    ) {
        val all = inScope(only)
        // already done = this same thing was cleaned in this same mode (a logo removed does not make a subtitle "done")
        val todo = if (skipCleaned) all.filter { it.cleanLog[target] != mode } else all
        val alreadyDone = all.size - todo.size
        if (todo.isEmpty()) {
            finish(
                "All ${count(all.size)} photos are already cleaned this way, so nothing was done. " +
                    "Turn off \"Skip photos that are already cleaned\" to do them again."
            )
            return
        }
        // text is checked inside cleanText (photo by photo); only a logo is first looked for with its template
        val verify = !target.isText && how != CleanAllMode.SAME_SPOT
        val follow = how == CleanAllMode.WHERE_FOUND_MOVING
        val relaxedText = target.isText && how == CleanAllMode.SAME_SPOT
        val tpl = template

        // Each photo gets its own cleaned copy on disk. Check there is room before starting 100,000 of them.
        // (A photo that already has a cleaned copy just replaces it, so it adds nothing.)
        val needBytes = cleaner.estimateBytes(todo.filter { it.originalUri == null })
        val freeBytes = cleaner.freeBytes()
        if (needBytes > freeBytes - LOW_SPACE_BYTES) {
            finish(
                "Not enough free storage. Cleaning ${count(todo.size)} photos needs about " +
                    "${BulkMath.formatBytes(needBytes)} and only ${BulkMath.formatBytes(freeBytes)} is free. " +
                    "Free up some space and try again.",
                problem = true
            )
            return
        }

        val total = todo.size
        val workers = cleaner.workerCount()
        val next = AtomicInteger(0)
        val done = AtomicInteger(0)
        val cleaned = AtomicInteger(0)
        val skipped = AtomicInteger(0)
        val failed = AtomicInteger(0)
        val noSpace = AtomicBoolean(false)
        val pending = ConcurrentHashMap<String, PoolImage>()
        val started = SystemClock.elapsedRealtime()
        var lastFlush = started
        var lastNotifiedPercent = -1
        val flushEveryMs = (total.toLong() / 25L).coerceIn(1_500L, 10_000L)
        val useService = total >= SERVICE_MIN_PHOTOS

        beginBulk(
            total,
            when {
                target.isText -> "Looking for the ${target.noun} in each photo\u2026"
                verify -> "Checking each photo and cleaning\u2026"
                else -> "Cleaning every photo\u2026"
            }
        )
        timedOut = false
        if (useService) {
            // Android 15+ ends a long background service after ~6 hours: stop the run cleanly instead of crashing
            LogoCleanService.timeoutListener = {
                timedOut = true
                job?.cancel()
            }
            LogoCleanService.start(appContext)
        }

        // Hands the finished photos to the app in ONE update (one rebuild of the list, one draft save).
        fun flush() {
            if (pending.isEmpty()) return
            val batch = HashMap<String, PoolImage>()
            for (key in pending.keys.toList()) {
                val value = pending.remove(key)
                if (value != null) batch[key] = value
            }
            if (batch.isNotEmpty()) replaceImages(batch)
        }

        fun publish() {
            val d = done.get()
            val elapsed = (SystemClock.elapsedRealtime() - started).coerceAtLeast(1L)
            val rate = d * 1000f / elapsed
            val eta = BulkMath.etaSeconds(d, total, elapsed)
            _ui.update {
                it.copy(
                    done = d, total = total, cleaned = cleaned.get(), skipped = skipped.get(),
                    failed = failed.get(), perSec = rate, etaSec = eta
                )
            }
            val pct = BulkMath.percent(d, total)
            if (useService && pct != lastNotifiedPercent) {
                lastNotifiedPercent = pct
                val left = if (eta >= 0) " \u00B7 ${BulkMath.formatDuration(eta)} left" else ""
                LogoCleanService.update(appContext, pct, "${count(d)} of ${count(total)} photos$left")
            }
        }

        suspend fun cleanOne(image: PoolImage, b: LogoBox, t: LogoTemplate?, sx: Float, sy: Float) {
            val out = cleaner.clean(image, b, t, sx, sy, mode, strength, LogoCleaner.BULK_JPEG_QUALITY)
            if (out != null) {
                pending[image.id] = out
                cleaned.incrementAndGet()
            } else {
                failed.incrementAndGet()
                // a write that fails over and over is usually a full disk: stop instead of failing 90,000 more
                if (cleaner.freeBytes() < LOW_SPACE_BYTES) noSpace.set(true)
            }
        }

        suspend fun work() {
            while (true) {
                currentCoroutineContext().ensureActive()
                if (noSpace.get()) return
                val i = next.getAndIncrement()
                if (i >= total) return
                val image = todo[i]
                try {
                    if (target.isText) {
                        val outcome = cleaner.cleanText(image, box, target, mode, strength, relaxedText, LogoCleaner.BULK_JPEG_QUALITY)
                        val cleanedImage = outcome.image
                        if (outcome.status == TextStatus.CLEANED && cleanedImage != null) {
                            pending[image.id] = cleanedImage
                            cleaned.incrementAndGet()
                        } else if (outcome.status == TextStatus.NO_TEXT) {
                            skipped.incrementAndGet()
                        } else {
                            failed.incrementAndGet()
                            if (cleaner.freeBytes() < LOW_SPACE_BYTES) noSpace.set(true)
                        }
                    } else if (verify) {
                        val t = tpl!!
                        val where = cleaner.locate(image, t, follow)
                        if (where == null) {
                            failed.incrementAndGet()
                        } else if (!where.found) {
                            skipped.incrementAndGet()
                        } else {
                            cleanOne(image, t.box, t, where.shiftX, where.shiftY)
                        }
                    } else {
                        cleanOne(image, box, tpl, 0f, 0f)
                    }
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    failed.incrementAndGet()
                } catch (e: OutOfMemoryError) {
                    failed.incrementAndGet()
                }
                done.incrementAndGet()
            }
        }

        try {
            coroutineScope {
                val ticker = launch {
                    while (true) {
                        delay(PROGRESS_EVERY_MS)
                        if (cleaner.freeBytes() < LOW_SPACE_BYTES) noSpace.set(true)
                        val now = SystemClock.elapsedRealtime()
                        if (now - lastFlush >= flushEveryMs) {
                            flush()
                            lastFlush = now
                        }
                        publish()
                    }
                }
                val pool = List(workers) { launch(Dispatchers.Default) { work() } }
                pool.joinAll()
                ticker.cancel()
            }
        } catch (e: CancellationException) {
            // Stop pressed (or the screen was closed): keep everything finished so far.
            flush()
            publish()
            val why = if (timedOut) "Android pauses long background work after about 6 hours. " else ""
            val stoppedText = why + "Stopped at ${BulkMath.percent(done.get(), total)}%. ${count(cleaned.get())} " +
                "${plural(cleaned.get(), "photo was", "photos were")} cleaned before that. " +
                "Open the app and press the button again to continue - photos already cleaned are skipped."
            finish(stoppedText)
            if (timedOut && useService) LogoCleanService.notifyDone(appContext, stoppedText)
            throw e
        } catch (e: Exception) {
            flush()
            publish()
            finish(
                problemText(e) + " ${count(cleaned.get())} ${plural(cleaned.get(), "photo was", "photos were")} " +
                    "cleaned before that.",
                problem = true
            )
            return
        } finally {
            if (useService) {
                LogoCleanService.timeoutListener = null
                LogoCleanService.stop(appContext)
            }
        }

        flush()
        publish()

        if (noSpace.get()) {
            val text = "Stopped because the phone is almost out of storage. ${count(cleaned.get())} " +
                "${plural(cleaned.get(), "photo was", "photos were")} cleaned. Free up some space, then press the " +
                "button again - photos already cleaned are skipped."
            finish(text, problem = true)
            if (useService) LogoCleanService.notifyDone(appContext, text)
            return
        }

        val text = summary(cleaned.get(), skipped.get(), failed.get(), alreadyDone, mode, target)
        finish(text, problem = cleaned.get() == 0)
        if (useService) LogoCleanService.notifyDone(appContext, text)
    }

    private fun summary(cleaned: Int, skipped: Int, failed: Int, alreadyDone: Int, mode: LogoCleanMode, target: CleanTarget): String {
        if (cleaned == 0 && skipped > 0 && failed == 0) {
            return if (target.isText) {
                "I couldn't see any ${target.noun} in the box in these photos, so nothing was changed. Check that the box " +
                    "sits right on the text, or choose \"Everywhere in the box\"."
            } else {
                "The logo wasn't found in any photo, so nothing was changed. Try \"Even if the logo moves\", " +
                    "or \"Exact spot, no checking\"."
            }
        }
        val sb = StringBuilder()
        sb.append("${cap(target.noun)} ${mode.verb} ${count(cleaned)} ${plural(cleaned, "photo", "photos")}.")
        if (skipped > 0) sb.append(" ${count(skipped)} had no ${target.noun} and ${plural(skipped, "was", "were")} left untouched.")
        if (alreadyDone > 0) sb.append(" ${count(alreadyDone)} ${plural(alreadyDone, "was", "were")} already cleaned and skipped.")
        if (failed > 0) sb.append(" ${count(failed)} couldn't be processed.")
        return sb.toString()
    }

    // ------------------------------------------------------------------------------ restore

    fun restore(imageId: String) {
        if (busy) return
        val image = currentImages().firstOrNull { it.id == imageId && it.originalUri != null } ?: return
        replaceImages(mapOf(imageId to cleaner.restored(image)))
        finish("Original photo restored.")
    }

    /** Puts the photos back to their originals: every cleaned photo, or only those in [only] (a segment range). */
    fun restoreAll(only: Set<String>? = null) {
        if (busy) return
        val cleanedImages = inScope(only).filter { it.originalUri != null }
        if (cleanedImages.isEmpty()) {
            finish("No photos have been cleaned.")
            return
        }
        // Deleting 100,000 files takes a while: do it in the background, in batches, with the progress card.
        job = scope.launch {
            beginBulk(cleanedImages.size, "Restoring the original photos\u2026")
            var restoredCount = 0
            try {
                for (chunk in cleanedImages.chunked(RESTORE_CHUNK)) {
                    currentCoroutineContext().ensureActive()
                    val updates = withContext(Dispatchers.IO) { chunk.associate { it.id to cleaner.restored(it) } }
                    replaceImages(updates)
                    restoredCount += chunk.size
                    _ui.update { it.copy(done = restoredCount) }
                }
            } catch (e: CancellationException) {
                finish("Stopped. Restored ${count(restoredCount)} of ${count(cleanedImages.size)} photos.")
                throw e
            }
            finish("Restored ${count(restoredCount)} original ${plural(restoredCount, "photo", "photos")}.")
        }
    }

    /** Deletes the cleaned copies of photos that are being removed from the project. */
    fun discard(images: List<PoolImage>) {
        for (image in images) cleaner.deleteCleanedFile(image)
    }

    companion object {
        /** A box bigger than this share of the photo is not a logo - refuse instead of repainting half the picture. */
        const val MAX_BOX_AREA = 0.35f

        /** The progress numbers are refreshed this often while a big run is going. */
        private const val PROGRESS_EVERY_MS = 500L

        /** Stop (and refuse to start) when less than this is free: the phone itself needs room to work. */
        private const val LOW_SPACE_BYTES = 300L * 1024L * 1024L

        /** Runs over fewer photos than this are over in moments, so they skip the background service. */
        private const val SERVICE_MIN_PHOTOS = 50

        private const val RESTORE_CHUNK = 500
    }
}
