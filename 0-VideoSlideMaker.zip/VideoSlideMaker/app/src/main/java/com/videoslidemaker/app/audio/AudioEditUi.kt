package com.videoslidemaker.app.audio

/**
 * NEW (2.17): the Audio step's own live state. Kept apart from the project (UiState) on purpose: the playhead moves many
 * times a second while a mix is playing, and it is not something to save or undo.
 */
data class AudioEditUi(
    val selectedId: String? = null,
    /** True while the short piece of the mix is being built before it plays. */
    val building: Boolean = false,
    val playing: Boolean = false,
    /** Timeline position (seconds) of what is playing. */
    val playheadSec: Double = 0.0,
    /** A plain-language message (what happened, or why something could not be done). */
    val note: String? = null,
    /** The loudness picture of each file, by its uri. */
    val peaks: Map<String, FloatArray> = emptyMap(),
    /** Clips whose file could not be opened (moved, deleted, or access lost). They are skipped when exporting. */
    val unreadable: Set<String> = emptySet()
)
