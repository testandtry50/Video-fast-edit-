package com.videoslidemaker.app.export

import android.content.Context
import com.videoslidemaker.app.audio.AudioMixRenderer
import com.videoslidemaker.app.audio.AudioWindow
import com.videoslidemaker.app.model.AudioSource
import com.videoslidemaker.app.model.ExportSettings
import com.videoslidemaker.app.model.SentenceSlide
import com.videoslidemaker.app.tts.NarrationTts
import com.videoslidemaker.app.voicefx.VoiceFxPcm
import com.videoslidemaker.app.voicefx.VoiceFxPcmStream
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File
import java.io.RandomAccessFile

const val AUDIO_SAMPLE_RATE = 44100
const val AUDIO_CHANNELS = 2

/** This many sentences failing back-to-back means the voice engine is broken, not just one line. */
private const val MAX_CONSECUTIVE_TTS_FAILURES = 5

/** A spoken sentence that starts earlier than this before a built stretch cannot reach into it. */
private const val MAX_SENTENCE_SEC = 20.0

/** The finished, mixed narration+music timeline. Backed by a temp file rather than an in-memory
 *  buffer — for a long video (the whole point of supporting long exports) this timeline can run
 *  well past 100-200MB, and building it as a single ByteArray was a real OutOfMemory risk on top
 *  of everything else export already needs in memory. A phone's free storage is comfortably
 *  bigger than its available RAM, so writing it to disk and streaming it to the encoder in small
 *  chunks scales to any video length without that risk. Caller is responsible for deleting [file]
 *  once the encoder has consumed it. */
data class PcmAudioFile(val sampleRate: Int, val channelCount: Int, val file: File, val totalBytes: Long)

/**
 * NEW: in the original app, the on-device voice was only ever heard live, while matching a
 * sentence to a photo — the exported video itself had no audio at all. Here, that same voice
 * is synthesized to a WAV per sentence and placed at that sentence's exact timestamp in one
 * combined PCM timeline, so it becomes a real audio track in the finished video.
 * NEW (2.17): the Audio step's edited main clips can be that main sound instead, and any number of background tracks
 * are mixed underneath by audio/AudioMixRenderer (looping, fades, lowering under the voice).
 */
class NarrationAudioBuilder(
    private val context: Context,
    private val tts: NarrationTts
) {
    suspend fun build(
        slides: List<SentenceSlide>,
        totalDurationSec: Double,
        settings: ExportSettings,
        cacheDir: File,
        // NEW (2.17): build only this stretch of the video (the Audio step's "hear the mix"). Null = the whole video.
        window: AudioWindow? = null,
        onProgress: (fraction: Float, message: String) -> Unit
    ): PcmAudioFile = withContext(Dispatchers.IO) {
        val windowStartSec = window?.startSec ?: 0.0
        val builtSec = window?.lengthSec ?: totalDurationSec
        // NEW (2.17): with "my edited audio" as the main sound, the voice / recording from the Script step is not used.
        val customMain = settings.audio.useCustomMain
        val totalBytes = (builtSec * AUDIO_SAMPLE_RATE).toLong().coerceAtLeast(1) * AUDIO_CHANNELS * 2
        val timelineFile = File(cacheDir, "audio_timeline_${System.nanoTime()}.pcm")

        try {
            RandomAccessFile(timelineFile, "rw").use { raf ->
                // Extends the file to its full length, logically zero-filled (silence) — this is a
                // normal RandomAccessFile guarantee, not something that needs every byte touched by
                // this process, so it's fast regardless of how long the video is.
                raf.setLength(totalBytes)

                if (customMain) {
                    // NEW (2.17): the edited clips are the main sound (laid on below)
                } else if (settings.narration.enabled && settings.narration.source == AudioSource.ORIGINAL) {
                    // NEW: the user's own recording is the sound. It sits on the same clock as the script,
                    // so it is laid onto the timeline as it is - no per-sentence voice at all.
                    val recordingUri = settings.narration.originalUri
                    if (recordingUri != null) {
                        val fx = settings.narration.voiceFx
                        onProgress(0.1f, if (fx.isActive) "Adding your original recording with voice changes" else "Adding your original recording")
                        val ok = if (window == null) {
                            AudioDecoder.decodeIntoFile(context, recordingUri, raf, totalBytes, AUDIO_SAMPLE_RATE, AUDIO_CHANNELS, fx)
                        } else {
                            // only the wanted stretch of the recording, placed at the start of the built piece
                            val fxStream: VoiceFxPcmStream? =
                                if (fx.isActive) VoiceFxPcmStream(fx, AUDIO_SAMPLE_RATE, AUDIO_CHANNELS, 0) else null
                            var pos = 0L
                            AudioDecoder.streamSegment(
                                context, recordingUri, window.startSec, window.startSec + window.lengthSec,
                                AUDIO_SAMPLE_RATE, AUDIO_CHANNELS
                            ) { chunk ->
                                ensureActive()
                                val data = if (fxStream != null) fxStream.process(chunk) else chunk
                                val n = minOf(data.size.toLong(), totalBytes - pos).toInt()
                                if (n > 0) {
                                    raf.seek(pos)
                                    raf.write(data, 0, n)
                                    pos += n
                                }
                                pos < totalBytes
                            }
                        }
                        if (!ok) onProgress(0.9f, "Couldn't read the sound of your recording")
                    }
                } else if (settings.narration.enabled) {
                    var skipped = 0
                    var consecutiveFailures = 0
                    slides.forEachIndexed { index, slide ->
                        // Lets Cancel Export stop the work between sentences.
                        ensureActive()
                        // When only a stretch is built, sentences clearly outside it are not spoken at all.
                        val outsideWindow = window != null &&
                            (slide.timestampSec > window.startSec + window.lengthSec || slide.timestampSec < window.startSec - MAX_SENTENCE_SEC)
                        if (slide.text.isNotBlank() && !outsideWindow) {
                            val skippedNote = if (skipped > 0) " ($skipped skipped)" else ""
                            onProgress(
                                (index + 1f) / slides.size,
                                "Recording narration ${index + 1} of ${slides.size}$skippedNote"
                            )
                            val wavFile = File(cacheDir, "narration_$index.wav")
                            try {
                                val ok = tts.synthesizeToFile(
                                    slide.text,
                                    settings.narration.voiceLocaleTag,
                                    settings.narration.speechRate,
                                    wavFile
                                )
                                if (ok) {
                                    consecutiveFailures = 0
                                    WavUtils.readPcm16Wav(wavFile)?.let { pcm ->
                                        val plain = PcmResampler.convert(
                                            pcm.data, pcm.sampleRate, pcm.channelCount,
                                            AUDIO_SAMPLE_RATE, AUDIO_CHANNELS
                                        )
                                        // FIXED: a sentence that takes longer to say than the time before the next
                                        // timestamp used to carry on underneath the next sentence - two voices at
                                        // once, heard as an echo. It is now cut where the next sentence begins (as
                                        // the Preview already does), BEFORE the voice changer so an echo / reverb
                                        // effect the person chose still rings out naturally after the cut.
                                        var nextStartSec: Double? = null
                                        for (j in index + 1 until slides.size) {
                                            val later = slides[j]
                                            if (later.text.isNotBlank() && later.timestampSec > slide.timestampSec) {
                                                nextStartSec = later.timestampSec
                                                break
                                            }
                                        }
                                        val fitted = NarrationTiming.fitToSlot(
                                            plain, AUDIO_CHANNELS, AUDIO_SAMPLE_RATE,
                                            NarrationTiming.slotFrames(slide.timestampSec, nextStartSec, AUDIO_SAMPLE_RATE)
                                        )
                                        // NEW: the voice changer, one sentence at a time. Pitch does not change the
                                        // speed, so every sentence still starts and ends where its timestamp says.
                                        // Each sentence gets its own noise pattern (seed = its number).
                                        val converted = VoiceFxPcm.processClip(
                                            fitted, AUDIO_SAMPLE_RATE, AUDIO_CHANNELS, settings.narration.voiceFx, index
                                        )
                                        val offsetBytes = ((slide.timestampSec - windowStartSec) * AUDIO_SAMPLE_RATE).toLong() * AUDIO_CHANNELS * 2
                                        mixIntoFile(raf, totalBytes, converted, offsetBytes, gain = 1f)
                                    }
                                } else {
                                    skipped++
                                    consecutiveFailures++
                                    // One odd sentence is skipped and the export carries on. But several
                                    // in a row means the phone's voice engine itself is not working —
                                    // stop with a clear reason instead of grinding on silently (or for hours).
                                    if (consecutiveFailures >= MAX_CONSECUTIVE_TTS_FAILURES) {
                                        throw IllegalStateException(
                                            "The phone's text-to-speech voice stopped responding around sentence " +
                                                "${index + 1} of ${slides.size}. Try again, pick a different voice or " +
                                                "speech engine in Android Settings → Text-to-speech, or turn narration " +
                                                "off on the Script step."
                                        )
                                    }
                                }
                            } finally {
                                wavFile.delete()
                            }
                        }
                    }
                }

                // NEW (2.17): the edited main clips, then the background tracks under them (see audio/AudioMixRenderer).
                val totalFrames = totalBytes / (AUDIO_CHANNELS * 2)
                val smart = settings.audio.smart
                if (customMain) {
                    val clips = settings.audio.activeMain
                    if (clips.isNotEmpty()) {
                        onProgress(0.5f, "Adding your edited audio")
                        AudioMixRenderer.mixMainClips(context, raf, totalFrames, clips, windowStartSec, smart.limiter) { ensureActive() }
                    }
                }
                val background = settings.audio.activeBackground
                if (background.isNotEmpty()) {
                    ensureActive()
                    onProgress(0.9f, "Mixing background audio")
                    AudioMixRenderer.mixBackground(
                        context, raf, totalFrames, background, windowStartSec, totalDurationSec, smart, cacheDir,
                        { ensureActive() }
                    ) { fraction, message -> onProgress(0.9f + fraction * 0.1f, message) }
                }
            }
        } catch (t: Throwable) {
            // A half-built timeline can be hundreds of MB — don't leave it behind when the build
            // fails or is cancelled.
            timelineFile.delete()
            throw t
        }

        PcmAudioFile(AUDIO_SAMPLE_RATE, AUDIO_CHANNELS, timelineFile, totalBytes)
    }

    /**
     * Mixes [addition] into the open file [raf] at [offsetBytes], reading and writing only the
     * small window [addition] actually covers — never the file's full length — so peak memory
     * for this operation is bounded by one narration clip's size (typically a few seconds of
     * audio), not by the total video duration, no matter how long that duration is.
     */
    private fun mixIntoFile(raf: RandomAccessFile, fileLen: Long, addition: ByteArray, offsetBytes: Long, gain: Float) {
        if (addition.isEmpty()) return
        val effectiveStart = offsetBytes.coerceAtLeast(0L)
        val skipInAddition = (-offsetBytes).coerceAtLeast(0L).toInt().coerceAtMost(addition.size)
        val availableInAddition = addition.size - skipInAddition
        val availableInFile = (fileLen - effectiveStart).coerceAtLeast(0L)
        val len = minOf(availableInAddition.toLong(), availableInFile).toInt()
        if (len <= 0) return

        raf.seek(effectiveStart)
        val existing = ByteArray(len)
        raf.readFully(existing)
        val trimmedAddition = if (skipInAddition == 0 && addition.size == len) {
            addition
        } else {
            addition.copyOfRange(skipInAddition, skipInAddition + len)
        }
        PcmResampler.mixInto(existing, trimmedAddition, 0, gain)
        raf.seek(effectiveStart)
        raf.write(existing)
    }
}
