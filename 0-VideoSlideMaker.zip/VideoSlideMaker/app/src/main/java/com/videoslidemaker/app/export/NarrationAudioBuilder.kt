package com.videoslidemaker.app.export

import android.content.Context
import com.videoslidemaker.app.model.AudioSource
import com.videoslidemaker.app.model.ExportSettings
import com.videoslidemaker.app.model.SentenceSlide
import com.videoslidemaker.app.tts.NarrationTts
import com.videoslidemaker.app.voicefx.VoiceFxPcm
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File
import java.io.RandomAccessFile

const val AUDIO_SAMPLE_RATE = 44100
const val AUDIO_CHANNELS = 2

/** This many sentences failing back-to-back means the voice engine is broken, not just one line. */
private const val MAX_CONSECUTIVE_TTS_FAILURES = 5

/** The finished, mixed narration+music timeline. Backed by a temp file rather than an in-memory
 *  buffer — for a long video (the whole point of supporting long exports) this timeline can run
 *  well past 100-200MB, and building it as a single ByteArray was a real OutOfMemory risk on top
 *  of everything else export already needs in memory. A phone's free storage is comfortably
 *  bigger than its available RAM, so writing it to disk and streaming it to the encoder in small
 *  chunks scales to any video length without that risk. Caller is responsible for deleting [file]
 *  once the encoder has consumed it. */
data class PcmAudioFile(val sampleRate: Int, val channelCount: Int, val file: File, val totalBytes: Long)

/**
 * NEW: in the original app, the on-device voice was only ever heard live, while matching a
 * sentence to a photo — the exported video itself had no audio at all. Here, that same voice
 * is synthesized to a WAV per sentence and placed at that sentence's exact timestamp in one
 * combined PCM timeline, so it becomes a real audio track in the finished video. An optional
 * background-music file is decoded, looped or trimmed to the video's length, and mixed
 * underneath at a lower volume.
 */
class NarrationAudioBuilder(
    private val context: Context,
    private val tts: NarrationTts
) {
    suspend fun build(
        slides: List<SentenceSlide>,
        totalDurationSec: Double,
        settings: ExportSettings,
        cacheDir: File,
        onProgress: (fraction: Float, message: String) -> Unit
    ): PcmAudioFile = withContext(Dispatchers.IO) {
        val totalBytes = (totalDurationSec * AUDIO_SAMPLE_RATE).toLong().coerceAtLeast(1) * AUDIO_CHANNELS * 2
        val timelineFile = File(cacheDir, "audio_timeline_${System.nanoTime()}.pcm")

        try {
            RandomAccessFile(timelineFile, "rw").use { raf ->
                // Extends the file to its full length, logically zero-filled (silence) — this is a
                // normal RandomAccessFile guarantee, not something that needs every byte touched by
                // this process, so it's fast regardless of how long the video is.
                raf.setLength(totalBytes)

                if (settings.narration.enabled && settings.narration.source == AudioSource.ORIGINAL) {
                    // NEW: the user's own recording is the sound. It sits on the same clock as the script,
                    // so it is laid onto the timeline as it is - no per-sentence voice at all.
                    val recordingUri = settings.narration.originalUri
                    if (recordingUri != null) {
                        val fx = settings.narration.voiceFx
                        onProgress(0.1f, if (fx.isActive) "Adding your original recording with voice changes" else "Adding your original recording")
                        val ok = AudioDecoder.decodeIntoFile(context, recordingUri, raf, totalBytes, AUDIO_SAMPLE_RATE, AUDIO_CHANNELS, fx)
                        if (!ok) onProgress(0.9f, "Couldn't read the sound of your recording")
                    }
                } else if (settings.narration.enabled) {
                    var skipped = 0
                    var consecutiveFailures = 0
                    slides.forEachIndexed { index, slide ->
                        // Lets Cancel Export stop the work between sentences.
                        ensureActive()
                        if (slide.text.isNotBlank()) {
                            val skippedNote = if (skipped > 0) " ($skipped skipped)" else ""
                            onProgress(
                                (index + 1f) / slides.size,
                                "Recording narration ${index + 1} of ${slides.size}$skippedNote"
                            )
                            val wavFile = File(cacheDir, "narration_$index.wav")
                            try {
                                val ok = tts.synthesizeToFile(
                                    slide.text,
                                    settings.narration.voiceLocaleTag,
                                    settings.narration.speechRate,
                                    wavFile
                                )
                                if (ok) {
                                    consecutiveFailures = 0
                                    WavUtils.readPcm16Wav(wavFile)?.let { pcm ->
                                        val plain = PcmResampler.convert(
                                            pcm.data, pcm.sampleRate, pcm.channelCount,
                                            AUDIO_SAMPLE_RATE, AUDIO_CHANNELS
                                        )
                                        // NEW: the voice changer, one sentence at a time. Pitch does not change the
                                        // speed, so every sentence still starts and ends where its timestamp says.
                                        // Each sentence gets its own noise pattern (seed = its number).
                                        val converted = VoiceFxPcm.processClip(
                                            plain, AUDIO_SAMPLE_RATE, AUDIO_CHANNELS, settings.narration.voiceFx, index
                                        )
                                        val offsetBytes = (slide.timestampSec * AUDIO_SAMPLE_RATE).toLong() * AUDIO_CHANNELS * 2
                                        mixIntoFile(raf, totalBytes, converted, offsetBytes, gain = 1f)
                                    }
                                } else {
                                    skipped++
                                    consecutiveFailures++
                                    // One odd sentence is skipped and the export carries on. But several
                                    // in a row means the phone's voice engine itself is not working —
                                    // stop with a clear reason instead of grinding on silently (or for hours).
                                    if (consecutiveFailures >= MAX_CONSECUTIVE_TTS_FAILURES) {
                                        throw IllegalStateException(
                                            "The phone's text-to-speech voice stopped responding around sentence " +
                                                "${index + 1} of ${slides.size}. Try again, pick a different voice or " +
                                                "speech engine in Android Settings → Text-to-speech, or turn narration " +
                                                "off on the Script step."
                                        )
                                    }
                                }
                            } finally {
                                wavFile.delete()
                            }
                        }
                    }
                }

                val musicUri = settings.music.uri
                if (musicUri != null) {
                    ensureActive()
                    onProgress(0.95f, "Mixing background music")
                    val musicPcm = AudioDecoder.decodeToPcm(context, musicUri, AUDIO_SAMPLE_RATE, AUDIO_CHANNELS)
                    if (musicPcm != null && musicPcm.isNotEmpty()) {
                        mixLoopedIntoFile(raf, totalBytes, musicPcm, gain = settings.music.volume)
                    }
                }
            }
        } catch (t: Throwable) {
            // A half-built timeline can be hundreds of MB — don't leave it behind when the build
            // fails or is cancelled.
            timelineFile.delete()
            throw t
        }

        PcmAudioFile(AUDIO_SAMPLE_RATE, AUDIO_CHANNELS, timelineFile, totalBytes)
    }

    /**
     * Mixes [addition] into the open file [raf] at [offsetBytes], reading and writing only the
     * small window [addition] actually covers — never the file's full length — so peak memory
     * for this operation is bounded by one narration clip's size (typically a few seconds of
     * audio), not by the total video duration, no matter how long that duration is.
     */
    private fun mixIntoFile(raf: RandomAccessFile, fileLen: Long, addition: ByteArray, offsetBytes: Long, gain: Float) {
        if (addition.isEmpty()) return
        val effectiveStart = offsetBytes.coerceAtLeast(0L)
        val skipInAddition = (-offsetBytes).coerceAtLeast(0L).toInt().coerceAtMost(addition.size)
        val availableInAddition = addition.size - skipInAddition
        val availableInFile = (fileLen - effectiveStart).coerceAtLeast(0L)
        val len = minOf(availableInAddition.toLong(), availableInFile).toInt()
        if (len <= 0) return

        raf.seek(effectiveStart)
        val existing = ByteArray(len)
        raf.readFully(existing)
        val trimmedAddition = if (skipInAddition == 0 && addition.size == len) {
            addition
        } else {
            addition.copyOfRange(skipInAddition, skipInAddition + len)
        }
        PcmResampler.mixInto(existing, trimmedAddition, 0, gain)
        raf.seek(effectiveStart)
        raf.write(existing)
    }

    /**
     * Mixes [pcm] into the file repeatedly (looping) to cover its full length, one loop-length
     * window at a time — never materializes a full-duration looped copy the way the old
     * in-memory version did, which used to double peak memory whenever background music was on.
     */
    private fun mixLoopedIntoFile(raf: RandomAccessFile, totalBytes: Long, pcm: ByteArray, gain: Float) {
        if (pcm.isEmpty()) return
        var pos = 0L
        while (pos < totalBytes) {
            mixIntoFile(raf, totalBytes, pcm, pos, gain)
            pos += pcm.size
        }
    }
}
