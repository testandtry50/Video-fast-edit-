package com.videoslidemaker.app.ui.theme

import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

/**
 * Every colour the app draws with, for ONE look (light / dark / pure-black / high-contrast, plus
 * the chosen accent). Screens never hard-code colours - they read the named values below, which
 * resolve to whichever palette is active, so switching theme re-colours the whole app at once.
 *
 *  bg       the page behind everything
 *  surface  bars and "inset" areas (step bar, text fields, dropdowns)
 *  card     raised cards that sit on the page
 *  border   quiet divider / card edge (decorative only)
 *  outline  the edge of anything you can tap or type in - kept at 3:1 contrast or better
 */
@Immutable
data class AppColors(
    val isDark: Boolean,
    val bg: Color,
    val surface: Color,
    val card: Color,
    val border: Color,
    val outline: Color,
    val accent: Color,
    val onAccent: Color,
    val textMain: Color,
    val muted: Color,
    val green: Color,
    val yellow: Color,
    val red: Color,
    /** Text / icon colour for use ON a solid green (e.g. a tick badge). */
    val onStatus: Color
)

/**
 * The palettes.
 *
 *  Dark   a true neutral charcoal (equal red / green / blue, so there is no purple or blue cast at all). The page, the
 *         bars and the cards are three close steps of grey so things "lift" off the background without hard lines, and
 *         the text is a soft off-white rather than pure white, which glares less on a dark screen.
 *  Light  a calm, low-glare "paper" look: a warm off-white page, slightly lighter cards (never pure #FFFFFF), and soft
 *         charcoal text (never pure #000000). Large bright-white areas are what tire the eyes, so there are none.
 *
 * All text, accent and status colours are verified against WCAG contrast ratios in ThemeContrastTest - change a value
 * here and that test tells you if readability broke.
 */
fun buildAppColors(dark: Boolean, prefs: AppearancePrefs): AppColors {
    val colors = if (dark) {
        val black = prefs.pureBlack
        AppColors(
            isDark = true,
            bg = if (black) Color(0xFF000000) else Color(0xFF131313),
            surface = if (black) Color(0xFF0C0C0C) else Color(0xFF1B1B1B),
            card = if (black) Color(0xFF171717) else Color(0xFF222222),
            border = if (black) Color(0xFF2A2A2A) else Color(0xFF303030),
            outline = Color(0xFF7E7E7E),
            accent = prefs.accent.darkTone,
            onAccent = Color(0xFF0E0E0E),
            textMain = Color(0xFFE6E6E6),
            muted = Color(0xFFA9A9A9),
            green = Color(0xFF6FD394),
            yellow = Color(0xFFF2C14E),
            red = Color(0xFFFF8A80),
            onStatus = Color(0xFF0E0E0E)
        )
    } else {
        AppColors(
            isDark = false,
            bg = Color(0xFFF4F2EE),
            surface = Color(0xFFEBE8E2),
            card = Color(0xFFFBFAF8),
            border = Color(0xFFDDD9D1),
            outline = Color(0xFF7D7A74),
            accent = prefs.accent.lightTone,
            onAccent = Color(0xFFFFFFFF),
            textMain = Color(0xFF2B2D31),
            muted = Color(0xFF5B5E64),
            green = Color(0xFF1F6B43),
            yellow = Color(0xFF855500),
            red = Color(0xFFB3302B),
            onStatus = Color(0xFFFFFFFF)
        )
    }

    if (!prefs.highContrast) return colors
    return if (dark) {
        colors.copy(
            textMain = Color(0xFFFFFFFF),
            muted = Color(0xFFD6D6D6),
            border = Color(0xFF8A8A8A),
            outline = Color(0xFFC8C8C8)
        )
    } else {
        colors.copy(
            textMain = Color(0xFF000000),
            muted = Color(0xFF2E2E2E),
            border = Color(0xFF6B6B6B),
            outline = Color(0xFF3D3D3D)
        )
    }
}

val LocalAppColors = staticCompositionLocalOf { buildAppColors(dark = true, prefs = AppearancePrefs()) }

// ---------------------------------------------------------------------------------------------
// The names the screens use. They are read inside composables, so they always reflect the
// active palette.
// ---------------------------------------------------------------------------------------------

val Bg: Color
    @Composable @ReadOnlyComposable get() = LocalAppColors.current.bg

val Surface: Color
    @Composable @ReadOnlyComposable get() = LocalAppColors.current.surface

val CardBg: Color
    @Composable @ReadOnlyComposable get() = LocalAppColors.current.card

val BorderColor: Color
    @Composable @ReadOnlyComposable get() = LocalAppColors.current.border

val Outline: Color
    @Composable @ReadOnlyComposable get() = LocalAppColors.current.outline

val Accent: Color
    @Composable @ReadOnlyComposable get() = LocalAppColors.current.accent

val OnAccent: Color
    @Composable @ReadOnlyComposable get() = LocalAppColors.current.onAccent

val TextMain: Color
    @Composable @ReadOnlyComposable get() = LocalAppColors.current.textMain

val Muted: Color
    @Composable @ReadOnlyComposable get() = LocalAppColors.current.muted

val Green: Color
    @Composable @ReadOnlyComposable get() = LocalAppColors.current.green

val Yellow: Color
    @Composable @ReadOnlyComposable get() = LocalAppColors.current.yellow

val Red: Color
    @Composable @ReadOnlyComposable get() = LocalAppColors.current.red

val OnStatus: Color
    @Composable @ReadOnlyComposable get() = LocalAppColors.current.onStatus

val IsDark: Boolean
    @Composable @ReadOnlyComposable get() = LocalAppColors.current.isDark

// Controls drawn on top of PHOTOS (remove buttons etc). A photo can be any colour, so these stay
// the same in every theme: a dark scrim with a white icon is readable on all of them.
val OverlayScrim = Color.Black.copy(alpha = 0.65f)
val OverlayIcon = Color.White
