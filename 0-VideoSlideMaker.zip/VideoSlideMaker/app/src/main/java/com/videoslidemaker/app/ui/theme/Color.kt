package com.videoslidemaker.app.ui.theme

import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

/**
 * Every colour the app draws with, for ONE look (a light or dark background style, high-contrast or not, plus
 * the chosen accent). Screens never hard-code colours - they read the named values below, which
 * resolve to whichever palette is active, so switching theme re-colours the whole app at once.
 *
 *  bg       the page behind everything
 *  surface  bars and "inset" areas (step bar, text fields, dropdowns)
 *  card     raised cards that sit on the page
 *  border   quiet divider / card edge (decorative only)
 *  outline  the edge of anything you can tap or type in - kept at 3:1 contrast or better
 */
@Immutable
data class AppColors(
    val isDark: Boolean,
    val bg: Color,
    val surface: Color,
    val card: Color,
    val border: Color,
    val outline: Color,
    val accent: Color,
    val onAccent: Color,
    val textMain: Color,
    val muted: Color,
    val green: Color,
    val yellow: Color,
    val red: Color,
    /** Text / icon colour for use ON a solid green (e.g. a tick badge). */
    val onStatus: Color
)

/**
 * Works out every colour for ONE look from the chosen background styles and accent.
 *
 * The background styles (DarkStyle / LightStyle in Appearance.kt) only say what the page, bars, cards and text look
 * like. The accent, the green / yellow / red status colours, the softer text and the tappable outlines are then
 * nudged (see fitColor) wherever a particular background would make them hard to read - so ANY accent, including a
 * custom hue, is readable on ANY style. Text on buttons is chosen to read on the button's own colour.
 *
 *  Charcoal / Black   true neutral greys (equal red / green / blue - no purple or blue cast), soft off-white text.
 *  Paper              a calm warm off-white page and slightly lighter cards (never pure white), soft charcoal text.
 *
 * Everything is verified against WCAG contrast ratios in ThemeContrastTest - change a value here or in Appearance.kt
 * and that test tells you if readability broke (tools/theme-reference/palette_check.py does the same in Python).
 */
fun buildAppColors(dark: Boolean, prefs: AppearancePrefs): AppColors {
    val style = if (dark) prefs.darkStyle.palette else prefs.lightStyle.palette
    val bg = style.bg
    val surface = style.surface
    val card = style.card
    var textMain = style.textMain
    var muted = style.muted
    var border = style.border
    var outline = style.outline
    if (prefs.highContrast) {
        if (dark) {
            textMain = Color(0xFFFFFFFF)
            muted = Color(0xFFD6D6D6)
            border = Color(0xFF8A8A8A)
            outline = Color(0xFFC8C8C8)
        } else {
            textMain = Color(0xFF000000)
            muted = Color(0xFF2E2E2E)
            border = Color(0xFF6B6B6B)
            outline = Color(0xFF3D3D3D)
        }
    }
    val onPage = listOf(bg, surface, card)

    val accent = fitColor(prefs.accentTone(dark), dark, FIT_TARGET) { a ->
        listOf(bg, surface, card, blendOver(a, 0.15f, card), blendOver(a, 0.13f, bg))
    }
    // green / yellow / red are used as text and icons on the page AND on their own 10-13 % tinted boxes
    fun status(base: Color): Color = fitColor(base, dark, FIT_TARGET) { c ->
        listOf(bg, surface, card, blendOver(c, 0.10f, card), blendOver(c, 0.13f, bg))
    }
    val green = status(if (dark) Color(0xFF6FD394) else Color(0xFF1F6B43))
    val yellow = status(if (dark) Color(0xFFF2C14E) else Color(0xFF855500))
    val red = status(if (dark) Color(0xFFFF8A80) else Color(0xFFB3302B))
    muted = fitColor(muted, dark, if (prefs.highContrast) 7.2 else 4.7) { onPage }
    outline = fitColor(outline, dark, 3.2) { onPage }

    val preferredOn = if (dark) Color(0xFF0E0E0E) else Color(0xFFFFFFFF)
    return AppColors(
        isDark = dark,
        bg = bg,
        surface = surface,
        card = card,
        border = border,
        outline = outline,
        accent = accent,
        onAccent = readableOn(accent, preferredOn),
        textMain = textMain,
        muted = muted,
        green = green,
        yellow = yellow,
        red = red,
        onStatus = readableOn(green, preferredOn)
    )
}

/** Contrast the accent and status colours are fitted to (the tests require 4.5; the extra is a safety margin). */
private const val FIT_TARGET = 4.55

val LocalAppColors = staticCompositionLocalOf { buildAppColors(dark = true, prefs = AppearancePrefs()) }

// ---------------------------------------------------------------------------------------------
// The names the screens use. They are read inside composables, so they always reflect the
// active palette.
// ---------------------------------------------------------------------------------------------

val Bg: Color
    @Composable @ReadOnlyComposable get() = LocalAppColors.current.bg

val Surface: Color
    @Composable @ReadOnlyComposable get() = LocalAppColors.current.surface

val CardBg: Color
    @Composable @ReadOnlyComposable get() = LocalAppColors.current.card

val BorderColor: Color
    @Composable @ReadOnlyComposable get() = LocalAppColors.current.border

val Outline: Color
    @Composable @ReadOnlyComposable get() = LocalAppColors.current.outline

val Accent: Color
    @Composable @ReadOnlyComposable get() = LocalAppColors.current.accent

val OnAccent: Color
    @Composable @ReadOnlyComposable get() = LocalAppColors.current.onAccent

val TextMain: Color
    @Composable @ReadOnlyComposable get() = LocalAppColors.current.textMain

val Muted: Color
    @Composable @ReadOnlyComposable get() = LocalAppColors.current.muted

val Green: Color
    @Composable @ReadOnlyComposable get() = LocalAppColors.current.green

val Yellow: Color
    @Composable @ReadOnlyComposable get() = LocalAppColors.current.yellow

val Red: Color
    @Composable @ReadOnlyComposable get() = LocalAppColors.current.red

val OnStatus: Color
    @Composable @ReadOnlyComposable get() = LocalAppColors.current.onStatus

val IsDark: Boolean
    @Composable @ReadOnlyComposable get() = LocalAppColors.current.isDark

// Controls drawn on top of PHOTOS (remove buttons etc). A photo can be any colour, so these stay
// the same in every theme: a dark scrim with a white icon is readable on all of them.
val OverlayScrim = Color.Black.copy(alpha = 0.65f)
val OverlayIcon = Color.White
