package com.videoslidemaker.app.adjust

import com.videoslidemaker.app.align.AlignmentStatus

/*
 * "Adjust timestamps": changing the script's timestamps without ever destroying the originals.
 *
 * Everything in this package is plain Kotlin (no Android), so it runs in ordinary unit tests. The screen and the
 * ViewModel only feed it the current lines and write back what it decides.
 *
 * The rules that keep the original safe:
 *  - A line's FIRST original time is remembered ([AdjustLine.scriptMs]) and never overwritten, however many adjustments
 *    are stacked on top of each other. Adjusting a line back to that time clears the marker (it is the script's own again).
 *  - Nothing is applied without a preview, and nothing that would break the timeline's order is applied (the same
 *    [com.videoslidemaker.app.align.AlignmentApplier] rule the automatic corrections obey).
 *  - Every applied adjustment is logged ([AdjustBatch]) so the last one can be undone, and the preserved originals allow
 *    restoring any line, or all of them, whatever happened in between.
 */

/** The five things the user can choose to do. */
enum class AdjustMode {
    /** Move every timestamp by the same amount (and optionally stretch/shrink the spacing). All or nothing. */
    ENTIRE_TRANSCRIPT,

    /** Listen to the recording, then preview the detected times for the whole transcript. */
    AUTO_SYNC,

    /** Shift (or set exactly) only the lines the user picks. */
    SELECTED,

    /** Preview the corrections an earlier analysis already found. */
    DETECTED,

    /** Undo the last adjustment, or restore originals. */
    UNDO
}

/** How the UNDO mode takes things back. */
enum class UndoAction {
    /** Revert the most recent adjustment batch. */
    LAST_ADJUSTMENT,

    /** Put every adjusted line back to the timestamp the script originally had. */
    RESTORE_ALL,

    /** Put only the picked lines back to their original timestamp. */
    RESTORE_SELECTED
}

/** What "selected" mode does to the picked lines. */
enum class SelectedMethod { SHIFT, EXACT }

/**
 * One line of the script as the adjuster sees it.
 *
 * @property scriptMs the time the SCRIPT gave this line, kept while an adjustment is in place; null while the line still has
 *                    its own time. This is the preserved original.
 */
data class AdjustLine(val index: Int, val text: String, val currentMs: Long, val scriptMs: Long? = null) {
    /** What the script originally said (the current time while nothing was adjusted). */
    val originalMs: Long get() = scriptMs ?: currentMs

    /** True when an adjustment is in place and there is something to restore. */
    val isAdjusted: Boolean get() = scriptMs != null && scriptMs != currentMs
}

/**
 * What an action would do to one line: BEFORE ([beforeMs]) -> AFTER ([afterMs]).
 *
 * @property afterMs     the proposed new time, or null when nothing is proposed for this line.
 * @property unavailable why nothing can be done for it (no matching speech, script changed since, ...); shown to the user.
 * @property confidence  for corrections found by the analysis: the calibrated 0..1 confidence.
 * @property status      ... and its status (only [AlignmentStatus.HIGH_CONFIDENCE] counts as high-confidence).
 */
data class Proposal(
    val index: Int,
    val text: String,
    val beforeMs: Long,
    val afterMs: Long?,
    val confidence: Float? = null,
    val status: AlignmentStatus? = null,
    val unavailable: String? = null,
    val note: String? = null
) {
    val diffMs: Long? get() = afterMs?.let { it - beforeMs }
}

/** What would happen to a previewed line. */
enum class Outcome {
    /** Ticked, and safe: it will be changed. */
    WILL_APPLY,

    /** A new time is proposed but the line is not ticked. */
    NOT_SELECTED,

    /** The proposed time is the time it already has. */
    NO_CHANGE,

    /** Ticked, but it would break the timeline (overlap a neighbour, or start before 0:00). Left alone. */
    REFUSED,

    /** Nothing can be proposed for it. */
    UNAVAILABLE
}

data class PreviewLine(
    val proposal: Proposal,
    val checked: Boolean,
    val outcome: Outcome,
    /** Why it is REFUSED / UNAVAILABLE. */
    val reason: String?
)

data class Preview(
    val lines: List<PreviewLine>,
    /** line index -> new time (ms): exactly what applying the ticked lines would change. */
    val willApply: Map<Int, Long>
) {
    val willApplyCount: Int get() = willApply.size
    val refusedCount: Int get() = lines.count { it.outcome == Outcome.REFUSED }
    val unavailableChecked: Int get() = lines.count { it.checked && it.outcome == Outcome.UNAVAILABLE }

    /** True when ticking everything would be accepted without leaving anything out: what an all-or-nothing action needs. */
    val isClean: Boolean get() = refusedCount == 0 && unavailableChecked == 0
}

/** One line changed by one adjustment. [textHash] ties it to the sentence it was, so a later edit is noticed. */
data class AppliedLine(val index: Int, val textHash: Int, val beforeMs: Long, val afterMs: Long)

/** One adjustment the user applied, kept so it can be undone. */
data class AdjustBatch(val id: Long, val label: String, val atEpochMs: Long, val changes: List<AppliedLine>)

/** The result of applying: the new lines, and what really changed. */
data class ApplyResult(
    val lines: List<AdjustLine>,
    val applied: List<AppliedLine>,
    /** Lines that were asked for but refused (they would have broken the timeline). */
    val refused: List<Int>
)

/** The newest adjustments, oldest first. Capped so the saved draft stays small. */
object AdjustLog {
    const val MAX_BATCHES = 20

    fun push(log: List<AdjustBatch>, batch: AdjustBatch): List<AdjustBatch> = (log + batch).takeLast(MAX_BATCHES)

    fun dropLast(log: List<AdjustBatch>): List<AdjustBatch> = if (log.isEmpty()) log else log.subList(0, log.size - 1)
}
