package com.videoslidemaker.app.ui.screens

import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Settings
import androidx.compose.ui.graphics.vector.ImageVector
import com.videoslidemaker.app.ui.components.CollapsibleCard
import com.videoslidemaker.app.ui.theme.Green

import com.videoslidemaker.app.ui.theme.TextMain
import com.videoslidemaker.app.ui.theme.Outline
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.Role
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import com.videoslidemaker.app.model.AppStep
import com.videoslidemaker.app.model.AspectRatioOption
import com.videoslidemaker.app.model.AudioSource
import com.videoslidemaker.app.model.EffectStyle
import com.videoslidemaker.app.model.QualityOption
import com.videoslidemaker.app.model.TransitionStyle
import com.videoslidemaker.app.model.UiState
import com.videoslidemaker.app.ui.components.AlertBox
import com.videoslidemaker.app.ui.components.AlertStyle
import com.videoslidemaker.app.ui.components.BadgeChip
import com.videoslidemaker.app.ui.components.PrimaryButton
import com.videoslidemaker.app.ui.components.ScreenTitle
import com.videoslidemaker.app.ui.components.SectionCard
import com.videoslidemaker.app.ui.components.SettingRow
import com.videoslidemaker.app.ui.components.SettingToggleRow
import com.videoslidemaker.app.ui.theme.Accent
import com.videoslidemaker.app.ui.theme.BorderColor
import com.videoslidemaker.app.ui.theme.Muted
import com.videoslidemaker.app.ui.theme.Surface
import com.videoslidemaker.app.viewmodel.AppViewModel
import kotlin.math.max
import kotlin.math.min

private val VOICE_OPTIONS = listOf("hi-IN" to "Hindi", "en-US" to "English", "en-IN" to "English (India)")

@Composable
fun ScriptScreen(state: UiState, viewModel: AppViewModel, onPickScriptFile: () -> Unit, onPickRecording: () -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        ScreenTitle(
            "Start your video",
            "Add photos to make a slideshow. A script is optional: it lets you match sentences and voice to timestamps."
        )

        UploadZone(
            done = state.scriptLoaded,
            icon = Icons.Filled.Description,
            title = if (state.scriptLoaded) "Script added - tap to choose a different one" else "Add a script file (optional)",
            hint = "A .txt file with one line per timestamp, like: 0:06 - your sentence",
            onClick = onPickScriptFile
        )

        BadgeChip(
            text = if (state.scriptLoaded) {
                val withText = state.slides.count { it.text.isNotBlank() }
                "${state.slides.size} timestamps loaded ($withText with sentences)"
            } else "No script added. That's fine, you can skip this.",
            style = if (state.scriptLoaded) AlertStyle.SUCCESS else AlertStyle.INFO,
            icon = if (state.scriptLoaded) Icons.Filled.CheckCircle else Icons.Filled.Info,
            modifier = Modifier.padding(top = 10.dp, bottom = 12.dp)
        )

        if (state.scriptIssues.isNotEmpty()) {
            val shown = state.scriptIssues.take(5)
            val more = state.scriptIssues.size - shown.size
            AlertBox(
                text = "${state.scriptIssues.size} line(s) skipped:\n" +
                    shown.joinToString("\n") +
                    if (more > 0) "\n…and $more more" else "",
                style = AlertStyle.WARNING,
                modifier = Modifier.padding(bottom = 12.dp)
            )
        }

        // NEW: check the script's timestamps against the real audio
        AlignmentCard(state, viewModel, onPickRecording)

        CollapsibleCard(
            title = "How to write your script file",
            icon = Icons.Filled.Lightbulb,
            modifier = Modifier.padding(bottom = 12.dp)
        ) {
            TipLine("Each line: timestamp, then dash, then sentence")
            TipLine("Example: 0:00 - Once upon a time")
            TipLine("Example: 0:06 - admi ne khana khaya")
            TipLine("Any time style works: 0:06, 00:06, 1:23:45, 0:06.500 or 01:23:45.500")
            TipLine("Mix Hindi, English or Hinglish — all work fine")
            TipLine("Just timestamps with no text also works (old format)")
        }

        CollapsibleCard(
            title = "Video settings",
            icon = Icons.Filled.Settings,
            summary = settingsSummary(state),
            modifier = Modifier.padding(bottom = 12.dp)
        ) {
            SettingRow("Default Duration", "Seconds per image") {
                Stepper(
                    value = state.settings.defaultDurationSec,
                    range = 1..30,
                    onChange = viewModel::setDefaultDuration
                )
            }
            SettingRow("Voice Language", "For reading sentences aloud, and for narration in the exported video") {
                LabeledDropdown(
                    options = VOICE_OPTIONS.map { it.second },
                    selectedIndex = VOICE_OPTIONS.indexOfFirst { it.first == state.settings.narration.voiceLocaleTag }.coerceAtLeast(0),
                    onSelect = { idx -> viewModel.setVoiceLocale(VOICE_OPTIONS[idx].first) }
                )
            }
            SettingRow("Photo Effect", "Motion applied while each photo is on screen") {
                LabeledDropdown(
                    options = EffectStyle.entries.map { it.label },
                    selectedIndex = EffectStyle.entries.indexOf(state.settings.effectStyle),
                    onSelect = { idx -> viewModel.setEffectStyle(EffectStyle.entries[idx]) }
                )
            }
            SettingRow("Transition", "How one photo changes to the next") {
                LabeledDropdown(
                    options = TransitionStyle.entries.map { it.label },
                    selectedIndex = TransitionStyle.entries.indexOf(state.settings.transitionStyle),
                    onSelect = { idx -> viewModel.setTransitionStyle(TransitionStyle.entries[idx]) }
                )
            }
            SettingToggleRow(
                "Sound in video",
                "Turn the sound of the preview and the exported file on or off",
                state.settings.narration.enabled,
                viewModel::setNarrationEnabled
            )
            SettingRow("Sound comes from", "The phone's voice reading your text, or your own recording (choose it above)") {
                LabeledDropdown(
                    options = AudioSource.entries.map { it.label },
                    selectedIndex = AudioSource.entries.indexOf(state.settings.narration.source),
                    onSelect = { idx -> viewModel.setAudioSource(AudioSource.entries[idx]) }
                )
            }
            SettingRow("Aspect Ratio", "Shape of your video") {
                LabeledDropdown(
                    options = AspectRatioOption.entries.map { it.label },
                    selectedIndex = AspectRatioOption.entries.indexOf(state.settings.aspectRatio),
                    onSelect = { idx -> viewModel.setAspectRatio(AspectRatioOption.entries[idx]) }
                )
            }
            SettingRow("Resolution", "Output video size") {
                LabeledDropdown(
                    options = QualityOption.entries.map { it.label },
                    selectedIndex = QualityOption.entries.indexOf(state.settings.quality),
                    onSelect = { idx -> viewModel.setQuality(QualityOption.entries[idx]) }
                )
            }

            val (outW, outH) = previewOutputSize(state)
            Text(
                "Output size: $outW×$outH",
                style = MaterialTheme.typography.bodySmall,
                color = Muted,
                modifier = Modifier.padding(top = 8.dp)
            )
        }

        // NEW: the voice changer - pitch, "make it sound human", effects
        if (state.settings.narration.enabled) {
            VoiceChangerPanel(state, viewModel, Modifier.padding(bottom = 12.dp))
        }

        AspectPreviewBox(state)

        PrimaryButton(
            if (state.scriptLoaded) "Next — Add Photos →" else "Skip — Add Photos Directly →",
            modifier = Modifier.padding(top = 4.dp),
            onClick = { viewModel.goStep(AppStep.PHOTOS) }
        )
    }
}

/** One line that shows the main settings while the Settings card is folded away. */
private fun settingsSummary(state: UiState): String {
    val s = state.settings
    val sound = if (s.narration.enabled) "sound on" else "sound off"
    return "${s.defaultDurationSec} s per photo \u00B7 ${s.aspectRatio.label} \u00B7 ${s.quality.label} \u00B7 $sound"
}

@Composable
private fun TipLine(text: String) {
    Row(Modifier.padding(bottom = 5.dp)) {
        Text("→ ", color = Accent, style = MaterialTheme.typography.bodySmall)
        Text(text, color = Muted, style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
fun UploadZone(done: Boolean, icon: ImageVector, title: String, hint: String, onClick: () -> Unit) {
    val shape = RoundedCornerShape(18.dp)
    val tone = if (done) Green else Accent
    Column(
        Modifier
            .fillMaxWidth()
            .heightIn(min = 96.dp)
            .clip(shape)
            .background(Surface)
            .border(if (done) 2.dp else 1.5.dp, if (done) Green else Outline, shape)
            .clickable(role = Role.Button, onClick = onClick)
            .padding(vertical = 20.dp, horizontal = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            Modifier
                .size(52.dp)
                .clip(CircleShape)
                .background(tone.copy(alpha = 0.14f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                if (done) Icons.Filled.CheckCircle else icon,
                contentDescription = null,
                tint = tone,
                modifier = Modifier.size(28.dp)
            )
        }
        Text(
            title,
            style = MaterialTheme.typography.titleSmall,
            color = TextMain,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            modifier = Modifier.padding(top = 10.dp, bottom = 4.dp)
        )
        Text(
            hint,
            style = MaterialTheme.typography.bodySmall,
            color = Muted,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center
        )
    }
}

@Composable
fun Stepper(value: Int, range: IntRange, onChange: (Int) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = { onChange(max(range.first, value - 1)) }) {
            Icon(Icons.Filled.Remove, contentDescription = "Decrease seconds", tint = TextMain)
        }
        Text(
            "$value",
            style = MaterialTheme.typography.titleSmall,
            color = TextMain,
            modifier = Modifier
                .padding(horizontal = 4.dp)
                .semantics { contentDescription = "$value seconds" }
        )
        IconButton(onClick = { onChange(min(range.last, value + 1)) }) {
            Icon(Icons.Filled.Add, contentDescription = "Increase seconds", tint = TextMain)
        }
    }
}

@Composable
fun LabeledDropdown(options: List<String>, selectedIndex: Int, onSelect: (Int) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    val safeIndex = selectedIndex.coerceIn(0, (options.size - 1).coerceAtLeast(0))
    Box {
        Row(
            Modifier
                .heightIn(min = 48.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(Surface)
                .border(1.dp, Outline, RoundedCornerShape(10.dp))
                .clickable(role = Role.DropdownList) { expanded = true }
                .padding(start = 12.dp, end = 6.dp, top = 8.dp, bottom = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                options.getOrElse(safeIndex) { "" },
                style = MaterialTheme.typography.bodyMedium,
                color = TextMain,
                fontWeight = FontWeight.Medium
            )
            Icon(Icons.Filled.KeyboardArrowDown, contentDescription = null, tint = TextMain, modifier = Modifier.size(24.dp))
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            options.forEachIndexed { index, label ->
                DropdownMenuItem(
                    text = { Text(label) },
                    onClick = { onSelect(index); expanded = false }
                )
            }
        }
    }
}

@Composable
fun AspectPreviewBox(state: UiState) {
    val ratio = state.settings.aspectRatio
    SectionCard(modifier = Modifier.padding(top = 4.dp, bottom = 12.dp)) {
        Text(
            "Preview shape",
            style = MaterialTheme.typography.titleSmall,
            color = TextMain,
            modifier = Modifier.padding(bottom = 14.dp)
        )
        Box(Modifier.fillMaxWidth().height(160.dp), contentAlignment = Alignment.Center) {
            val boxRatio = ratio.w.toFloat() / ratio.h.toFloat()
            Box(
                Modifier
                    .fillMaxWidth(if (boxRatio >= 1f) 0.7f else 0.7f * boxRatio)
                    .aspectRatio(boxRatio)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Accent.copy(alpha = 0.85f))
                    .semantics { contentDescription = "Shape of your video: ${ratio.label}" }
            )
        }
    }
}

/** Mirrors getAspectWH(forExport=true) from the original script, for the live "Output size" label. */
private fun previewOutputSize(state: UiState): Pair<Int, Int> {
    val ratio = state.settings.aspectRatio
    fun evenize(v: Int) = if (v % 2 == 0) v else v + 1
    if (state.settings.quality == QualityOption.ORIGINAL) {
        val largest = state.images.maxByOrNull { it.widthPx.toLong() * it.heightPx.toLong() }
        val maxW = largest?.widthPx?.takeIf { it > 0 } ?: 1920
        val maxH = largest?.heightPx?.takeIf { it > 0 } ?: 1080
        val base = max(maxW, maxH)
        var w: Int
        var h: Int
        if (ratio.w >= ratio.h) {
            h = base * ratio.h / ratio.w; w = base
            if (w < maxW) { w = maxW; h = (w.toLong() * ratio.h / ratio.w).toInt() }
        } else {
            w = base * ratio.w / ratio.h; h = base
            if (h < maxH) { h = maxH; w = (h.toLong() * ratio.w / ratio.h).toInt() }
        }
        return evenize(w) to evenize(h)
    }
    val base = state.settings.quality.basePx ?: 720
    var w: Int
    var h: Int
    if (ratio.w >= ratio.h) { h = base; w = ((base.toLong() * ratio.w) / ratio.h).toInt() }
    else { w = base; h = ((base.toLong() * ratio.h) / ratio.w).toInt() }
    return evenize(w) to evenize(h)
}
