package com.videoslidemaker.app.audio

import com.videoslidemaker.app.audio.AudioLimits.MIN_CLIP_SEC
import kotlin.math.floor

/**
 * NEW (2.19): the arithmetic behind the "mark the part to keep" editor, as plain functions (no Android, no files), so it
 * is tested on a plain JVM and mirrored in tools/audiomix-reference/beatmark.py.
 *
 * A mark is a pair of times - start and end - counted in seconds from the very START OF THE ORIGINAL FILE, however the
 * clip was trimmed or fitted before. The two handles on the picture, the two typed times, the "mark here" buttons while
 * listening and the nudge buttons all end up in these same functions.
 */
object MarkMath {

    /**
     * Reads a time that was typed. Accepts seconds ("72", "72.5"), minutes and seconds ("1:12", "1:12.5") and hours
     * ("1:02:03"); a comma works as the decimal point ("1:12,5") because many keyboards have no dot on the first page;
     * spaces and a trailing "s" are ignored. Returns null for anything else (so nothing is changed by a typing mistake).
     */
    fun parseTime(text: String): Double? {
        val t = text.trim().lowercase().removeSuffix("s").trim().replace(',', '.')
        if (t.isEmpty()) return null
        val parts = t.split(':')
        if (parts.size > 3) return null
        var total = 0.0
        for ((i, raw) in parts.withIndex()) {
            val part = raw.trim()
            if (part.isEmpty()) return null
            // only plain digits and one point: Kotlin's own number reader would also take "5d", "1e3" or "0x1p3"
            if (part.any { it !in '0'..'9' && it != '.' }) return null
            val v = part.toDoubleOrNull() ?: return null
            if (v.isNaN() || v.isInfinite() || v < 0.0) return null
            val last = i == parts.size - 1
            // a part before the last one counts whole minutes or hours
            if (!last && v != floor(v)) return null
            // minutes and seconds after a colon are below 60
            if (i > 0 && v >= 60.0) return null
            total = total * 60.0 + v
        }
        return total
    }

    /** "m:ss.t" - one decimal. The same way every other time in the editor is shown. */
    fun format(sec: Double): String = BgSlots.clock(sec)

    /** The mark's length. */
    fun lengthSec(start: Double, end: Double): Double = (end - start).coerceAtLeast(0.0)

    /** Puts a pair in order and inside the file, at least the shortest clip apart. */
    fun fix(start: Double, end: Double, fileSec: Double): Pair<Double, Double> {
        if (fileSec <= MIN_CLIP_SEC) return 0.0 to fileSec.coerceAtLeast(0.0)
        var a = minOf(start, end).coerceIn(0.0, fileSec)
        var b = maxOf(start, end).coerceIn(0.0, fileSec)
        if (b - a < MIN_CLIP_SEC) {
            b = (a + MIN_CLIP_SEC).coerceAtMost(fileSec)
            a = (b - MIN_CLIP_SEC).coerceAtLeast(0.0)
        }
        return a to b
    }

    /**
     * The mark with its START moved to [t]. When that would pass the end, the end goes along and keeps the mark's length
     * (so sliding the start past the end moves the whole mark instead of squashing it).
     */
    fun withStart(start: Double, end: Double, t: Double, fileSec: Double): Pair<Double, Double> {
        if (t.isNaN()) return fix(start, end, fileSec)
        val oldLen = maxOf(MIN_CLIP_SEC, end - start)
        val a = t.coerceIn(0.0, (fileSec - MIN_CLIP_SEC).coerceAtLeast(0.0))
        val b = if (end < a + MIN_CLIP_SEC) a + oldLen else end
        return fix(a, b, fileSec)
    }

    /**
     * The mark with its END moved to [t]. When that would pass the start, the start goes along and keeps the mark's length.
     */
    fun withEnd(start: Double, end: Double, t: Double, fileSec: Double): Pair<Double, Double> {
        if (t.isNaN()) return fix(start, end, fileSec)
        val oldLen = maxOf(MIN_CLIP_SEC, end - start)
        val b = t.coerceIn(MIN_CLIP_SEC.coerceAtMost(fileSec), fileSec)
        val a = if (start > b - MIN_CLIP_SEC) b - oldLen else start
        return fix(a, b, fileSec)
    }

    /** Moves the whole mark by [deltaSec] (keeping its length), stopping at the ends of the file. */
    fun shift(start: Double, end: Double, deltaSec: Double, fileSec: Double): Pair<Double, Double> {
        val len = maxOf(MIN_CLIP_SEC, end - start)
        val a = (start + deltaSec).coerceIn(0.0, (fileSec - len).coerceAtLeast(0.0))
        return fix(a, a + len, fileSec)
    }

    /** Which handle a touch at [t] should move: the nearer one (the start on a tie). */
    fun nearestIsStart(start: Double, end: Double, t: Double): Boolean = kotlin.math.abs(t - start) <= kotlin.math.abs(t - end)
}
