package com.videoslidemaker.app.model

/**
 * NEW (2.22): the rule behind "Select multiple photos -> Apply to sentences" in the photo browser.
 *
 * You tap photos in the browser in the order you want them (1st, 2nd, 3rd ...). Applying puts the 1st selected photo on the
 * sentence you are on, the 2nd on the next sentence in time, and so on. It works for any amount: 300, 400 or exactly 500
 * photos for 500 sentences. If you selected more photos than there are sentences left, the extra photos are simply not
 * used; if fewer, the sentences after them keep what they have.
 *
 * Plain Kotlin on ids and times (no Android classes) so it can be tested alone. It never touches a sentence outside the
 * run it fills, and it does not change the existing [AutoMatch] / [PhotoShift] rules at all.
 */
object MultiPhotoApply {

    data class Result(
        /** The photo id for every sentence, in the order the sentences were given in (null = none). */
        val assignments: List<String?>,
        /** First sentence that gets a photo, 1-based (the sentence you started on). 0 when there are no sentences. */
        val firstSentence: Int,
        /** Last sentence that gets a photo, 1-based. 0 when nothing is applied. */
        val lastSentence: Int,
        /** How many selected photos find a sentence. */
        val applied: Int,
        /** How many selected photos find no sentence (more photos than sentences left). */
        val extraPhotos: Int,
        /** How many of the filled sentences already had a DIFFERENT photo, which is replaced. */
        val replaced: Int,
        /** How many sentences end up with a different photo than before. */
        val changed: Int
    ) {
        /** The live line shown before applying. */
        fun preview(selectedCount: Int): String {
            if (selectedCount == 0) {
                return "Tap photos in the order you want them (1, 2, 3 ...). They go onto the sentences one by one, starting at sentence $firstSentence."
            }
            if (applied == 0) return "No sentence is left to put these photos on."
            val text = StringBuilder(
                if (applied == 1) "1 photo will go on sentence $firstSentence."
                else "$applied photos will go on sentences $firstSentence – $lastSentence, one each, in your order."
            )
            if (replaced > 0) text.append(if (replaced == 1) " 1 sentence already has a photo that will be replaced." else " $replaced sentences already have a photo that will be replaced.")
            if (extraPhotos > 0) text.append(if (extraPhotos == 1) " 1 photo has no sentence left and is not used." else " $extraPhotos photos have no sentence left and are not used.")
            return text.toString()
        }

        /** The sentence shown after applying. */
        fun message(): String {
            if (applied == 0) return "Nothing changed - no photo was selected, or no sentence is left."
            if (changed == 0) return "Nothing changed - those sentences already have these photos."
            val text = StringBuilder(
                if (applied == 1) "Done - 1 photo applied to sentence $firstSentence."
                else "Done - $applied photos applied to sentences $firstSentence – $lastSentence."
            )
            if (extraPhotos > 0) text.append(if (extraPhotos == 1) " 1 photo was not used (no sentence left)." else " $extraPhotos photos were not used (no sentence left).")
            text.append(" Undo takes it all back.")
            return text.toString()
        }
    }

    /**
     * @param times the start time of every sentence, in the order the sentences are kept in.
     * @param current the photo each sentence has now (null = none), the same length as [times].
     * @param selectedIds the selected photos, in the order they were selected.
     * @param startIndex the sentence (0-based, list order) the first photo goes on - normally the one you are on.
     */
    fun plan(times: List<Double>, current: List<String?>, selectedIds: List<String>, startIndex: Int): Result {
        val n = minOf(times.size, current.size)
        val out = ArrayList<String?>(n)
        for (i in 0 until n) out.add(current[i])
        if (n == 0) return Result(out, 0, 0, 0, selectedIds.distinct().size, 0, 0)

        val inTimeOrder = (0 until n).sortedBy { times[it] } // stable: the same time keeps list order
        val from = inTimeOrder.indexOf(startIndex.coerceIn(0, n - 1))
        val targets = inTimeOrder.subList(from, inTimeOrder.size)
        val photos = selectedIds.distinct()
        val applied = minOf(photos.size, targets.size)

        var replaced = 0
        var changed = 0
        for (k in 0 until applied) {
            val at = targets[k]
            val before = current[at]
            if (before != null && before != photos[k]) replaced++
            if (before != photos[k]) changed++
            out[at] = photos[k]
        }
        return Result(
            assignments = out,
            firstSentence = targets[0] + 1,
            lastSentence = if (applied == 0) 0 else targets[applied - 1] + 1,
            applied = applied,
            extraPhotos = photos.size - applied,
            replaced = replaced,
            changed = changed
        )
    }
}
