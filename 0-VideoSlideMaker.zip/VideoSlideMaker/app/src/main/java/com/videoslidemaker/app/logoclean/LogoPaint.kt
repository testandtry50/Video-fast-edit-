package com.videoslidemaker.app.logoclean

import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min

/** A window of the photo to repaint: its position, size, and which pixels in it are the logo. */
internal class PaintPlan(val x0: Int, val y0: Int, val w: Int, val h: Int, val mask: BooleanArray)

internal object LogoPaint {
    /** Largest window we are willing to repaint (memory on a phone). */
    const val MAX_WINDOW_PIXELS = 3_000_000L

    /**
     * Works out which pixels of a [photoW] x [photoH] photo are the logo.
     *  - With a [template] (found automatically) the mask follows the logo's own shape, moved by
     *    [shiftX]/[shiftY] (fractions of the photo) when the logo was found somewhere else.
     *  - Without one, the mask is the rounded rectangle the user drew ([box]).
     * The window around the mask holds some surroundings, which the fill needs to copy from.
     * Returns null if nothing sensible can be painted (empty, outside the photo, or too big).
     */
    fun planMask(
        photoW: Int, photoH: Int, box: LogoBox, template: LogoTemplate?, shiftX: Float, shiftY: Float
    ): PaintPlan? {
        if (photoW < 8 || photoH < 8) return null
        val longEdge = max(photoW, photoH)
        val fx0: Int
        val fy0: Int
        val rw: Int
        val rh: Int
        val rectMask: BooleanArray
        val grow: Int
        if (template != null) {
            val r = template.maskRect.shifted(shiftX, shiftY)
            fx0 = floor(r.left * photoW).toInt()
            fy0 = floor(r.top * photoH).toInt()
            rw = ceil(r.right * photoW).toInt() - fx0
            rh = ceil(r.bottom * photoH).toInt() - fy0
            if (rw < 2 || rh < 2) return null
            rectMask = upscaleMask(template.mask, template.maskW, template.maskH, rw, rh)
            // a mask cell is ~3 photo px wide; grow by about one cell so a 1-cell mismatch is still covered
            val cellPx = r.width * photoW / max(1, template.maskW)
            grow = max(2, Math.round(0.9f * cellPx))
        } else {
            val pad = max(3, Math.round(0.0025f * longEdge))
            fx0 = floor(box.left * photoW).toInt() - pad
            fy0 = floor(box.top * photoH).toInt() - pad
            rw = ceil(box.right * photoW).toInt() + pad - fx0
            rh = ceil(box.bottom * photoH).toInt() + pad - fy0
            if (rw < 2 || rh < 2) return null
            rectMask = roundedRectMask(rw, rh, 0, 0, rw, rh, max(2, (0.18f * min(rw, rh)).toInt()))
            grow = 0
        }
        val ctx = max(24, (0.6f * max(rw, rh)).toInt())
        val wx0 = max(0, fx0 - ctx)
        val wy0 = max(0, fy0 - ctx)
        val wx1 = min(photoW, fx0 + rw + ctx)
        val wy1 = min(photoH, fy0 + rh + ctx)
        val ww = wx1 - wx0
        val wh = wy1 - wy0
        if (ww < 8 || wh < 8) return null
        if (ww.toLong() * wh > MAX_WINDOW_PIXELS) return null
        val mask = BooleanArray(ww * wh)
        var any = false
        for (y in 0 until rh) {
            val wy = fy0 + y - wy0
            if (wy < 0 || wy >= wh) continue
            for (x in 0 until rw) {
                val wx = fx0 + x - wx0
                if (wx < 0 || wx >= ww) continue
                if (rectMask[y * rw + x]) { mask[wy * ww + wx] = true; any = true }
            }
        }
        if (!any) return null
        return PaintPlan(wx0, wy0, ww, wh, if (grow > 0) maxFilter(mask, ww, wh, grow) else mask)
    }

    /**
     * The window for looking for TEXT in the box the user drew: the box itself (the mask - where text may be) plus
     * a margin of surroundings, which is both what the finder reads to learn how busy the picture is and what the
     * repaint copies its colours from. Much tighter than [planMask]'s window, so a wide subtitle strip on a 4K
     * photo still fits. Mirrors window_for() in tools/textclean-reference/synth_text.py.
     * Returns null if the box is too small or its window is too big to repaint.
     */
    fun planTextRegion(photoW: Int, photoH: Int, box: LogoBox): PaintPlan? {
        if (photoW < 8 || photoH < 8) return null
        val bx0 = max(0, floor(box.left * photoW).toInt())
        val by0 = max(0, floor(box.top * photoH).toInt())
        val bx1 = min(photoW, ceil(box.right * photoW).toInt())
        val by1 = min(photoH, ceil(box.bottom * photoH).toInt())
        val bw = bx1 - bx0
        val bh = by1 - by0
        if (bw < 4 || bh < 4) return null
        val ctx = max(24, Math.round(0.5f * min(bw, bh)))
        val wx0 = max(0, bx0 - ctx)
        val wy0 = max(0, by0 - ctx)
        val wx1 = min(photoW, bx1 + ctx)
        val wy1 = min(photoH, by1 + ctx)
        val ww = wx1 - wx0
        val wh = wy1 - wy0
        if (ww < 8 || wh < 8) return null
        if (ww.toLong() * wh > MAX_WINDOW_PIXELS) return null
        val mask = BooleanArray(ww * wh)
        for (y in by0 until by1) {
            val row = (y - wy0) * ww
            for (x in bx0 until bx1) mask[row + (x - wx0)] = true
        }
        return PaintPlan(wx0, wy0, ww, wh, mask)
    }

    /**
     * Repaints the masked pixels of an ARGB window. Pixels away from the mask come back identical.
     * [strength] (0..1) only matters for BLUR.
     */
    fun paint(
        pixels: IntArray, w: Int, h: Int, mask: BooleanArray, mode: LogoCleanMode, strength: Float,
        blurMask: BooleanArray? = null
    ): IntArray {
        var minX = w; var maxX = -1; var minY = h; var maxY = -1
        for (y in 0 until h) {
            for (x in 0 until w) {
                if (mask[y * w + x]) {
                    if (x < minX) minX = x
                    if (x > maxX) maxX = x
                    if (y < minY) minY = y
                    if (y > maxY) maxY = y
                }
            }
        }
        if (maxX < 0) return pixels
        val img = FloatArray(w * h * 3)
        for (i in 0 until w * h) {
            val p = pixels[i]
            img[i * 3] = ((p shr 16) and 0xFF).toFloat()
            img[i * 3 + 1] = ((p shr 8) and 0xFF).toFloat()
            img[i * 3 + 2] = (p and 0xFF).toFloat()
        }
        val out = when (mode) {
            LogoCleanMode.REMOVE -> inpaint(img, w, h, mask)
            LogoCleanMode.BLUR -> {
                // For text, BLUR gets its own mask (letters merged into words and lines) so it smudges the words
                // instead of leaving the shape of every letter behind. Without one it is the same as before.
                val area = blurMask ?: mask
                val minSide = if (blurMask == null) min(maxX - minX + 1, maxY - minY + 1) else minSideOf(area, w, h)
                val sigma = (0.12f + 0.48f * strength.coerceIn(0f, 1f)) * minSide
                blurMasked(img, w, h, area, sigma, max(2f, 0.45f * sigma))
            }
            LogoCleanMode.BOTH -> {
                // Remove first, then soften only the repaired spot. The blur is much gentler than plain
                // BLUR: it is there to melt the patch into its surroundings, not to hide a logo.
                val removed = inpaint(img, w, h, mask)
                val minSide = min(maxX - minX + 1, maxY - minY + 1)
                val sigma = max(1.5f, (0.03f + 0.17f * strength.coerceIn(0f, 1f)) * minSide)
                blurMasked(removed, w, h, mask, sigma, max(2f, 0.45f * sigma))
            }
        }
        val result = IntArray(w * h)
        for (i in 0 until w * h) {
            val r = (out[i * 3] + 0.5f).toInt().coerceIn(0, 255)
            val g = (out[i * 3 + 1] + 0.5f).toInt().coerceIn(0, 255)
            val b = (out[i * 3 + 2] + 0.5f).toInt().coerceIn(0, 255)
            result[i] = (pixels[i] and 0xFF000000.toInt()) or (r shl 16) or (g shl 8) or b
        }
        return result
    }

    /** Shorter side of the box around the set pixels of [mask] (1 if none). */
    private fun minSideOf(mask: BooleanArray, w: Int, h: Int): Int {
        var minX = w
        var maxX = -1
        var minY = h
        var maxY = -1
        for (y in 0 until h) {
            for (x in 0 until w) {
                if (mask[y * w + x]) {
                    if (x < minX) minX = x
                    if (x > maxX) maxX = x
                    if (y < minY) minY = y
                    if (y > maxY) maxY = y
                }
            }
        }
        if (maxX < 0) return 1
        return max(1, min(maxX - minX + 1, maxY - minY + 1))
    }
}
