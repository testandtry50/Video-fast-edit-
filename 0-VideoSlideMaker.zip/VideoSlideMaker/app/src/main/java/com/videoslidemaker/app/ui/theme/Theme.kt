package com.videoslidemaker.app.ui.theme

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.graphics.drawable.ColorDrawable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.Density
import androidx.core.view.WindowCompat

/**
 * The app theme. The light / dark style, accent colour, high contrast, text size and layout all come from [prefs];
 * with the default (System) the look simply follows the phone.
 */
@Composable
fun VideoSlideMakerTheme(
    prefs: AppearancePrefs = AppearancePrefs(),
    content: @Composable () -> Unit
) {
    val dark = prefs.resolveDark(isSystemInDarkTheme())
    val colors = remember(dark, prefs.darkStyle, prefs.lightStyle, prefs.accent, prefs.customHue, prefs.highContrast) {
        buildAppColors(dark, prefs)
    }
    val layout = remember(prefs.spacing, prefs.corners) { layoutSpecOf(prefs.spacing, prefs.corners) }
    val scheme = remember(colors) { colors.toMaterialColorScheme() }

    // Make the status bar, navigation bar and window background match the chosen look, and flip
    // the system icons between dark-on-light and light-on-dark so they stay visible.
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = view.context.findActivity()?.window
            if (window != null) {
                // (The status / navigation bar COLOURS are no longer set here: from Android 15 on they cannot be, the
                // bars are see-through and the app draws the strip behind them - see AppRoot. Only the icons are set.)
                window.setBackgroundDrawable(ColorDrawable(colors.bg.toArgb()))
                val controller = WindowCompat.getInsetsController(window, view)
                controller.isAppearanceLightStatusBars = !colors.isDark
                controller.isAppearanceLightNavigationBars = !colors.isDark
            }
        }
    }

    // "Text size" multiplies the phone's own font scale, so people who already enlarged their
    // system font keep that and can add more on top. Capped so layouts can't break completely.
    val baseDensity = LocalDensity.current
    val density = remember(baseDensity, prefs.textSize) {
        Density(
            density = baseDensity.density,
            fontScale = (baseDensity.fontScale * prefs.textSize.scale).coerceIn(MIN_FONT_SCALE, MAX_FONT_SCALE)
        )
    }

    CompositionLocalProvider(
        LocalAppColors provides colors,
        LocalLayoutSpec provides layout,
        LocalDensity provides density
    ) {
        MaterialTheme(
            colorScheme = scheme,
            typography = VideoSlideMakerTypography,
            content = content
        )
    }
}

private const val MAX_FONT_SCALE = 2.2f

/** "Small" text on a phone whose own font size is already small must stay readable. */
private const val MIN_FONT_SCALE = 0.8f

/**
 * Maps our palette onto Material's colour roles. EVERY surface role is set on purpose - the stock
 * Material dark scheme is purple-tinted, and dialogs, menus and sliders would otherwise bring that
 * purple back.
 */
private fun AppColors.toMaterialColorScheme(): ColorScheme {
    val base = if (isDark) darkColorScheme() else lightColorScheme()
    return base.copy(
        primary = accent,
        onPrimary = onAccent,
        primaryContainer = card,
        onPrimaryContainer = textMain,
        inversePrimary = accent,
        secondary = accent,
        onSecondary = onAccent,
        secondaryContainer = border,
        onSecondaryContainer = textMain,
        tertiary = accent,
        onTertiary = onAccent,
        tertiaryContainer = card,
        onTertiaryContainer = textMain,
        errorContainer = card,
        onErrorContainer = red,
        scrim = Color.Black,
        background = bg,
        onBackground = textMain,
        surface = bg,
        onSurface = textMain,
        surfaceVariant = card,
        onSurfaceVariant = muted,
        surfaceTint = Color.Transparent,
        inverseSurface = textMain,
        inverseOnSurface = bg,
        error = red,
        onError = onStatus,
        outline = outline,
        outlineVariant = border,
        surfaceBright = card,
        surfaceDim = bg,
        surfaceContainerLowest = bg,
        surfaceContainerLow = surface,
        surfaceContainer = card,
        surfaceContainerHigh = card,
        surfaceContainerHighest = card
    )
}

private tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}
