package com.videoslidemaker.app.align

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.log10
import kotlin.math.min
import kotlin.math.sin

/**
 * Turns a mono audio stream into one loudness value per 10 ms ("frame"), in dB relative to full
 * scale, after band-limiting to the speech range (150 Hz .. 4 kHz). Streaming: feed it chunks as
 * they are decoded, so a 45-minute recording never has to sit in memory as raw audio.
 *
 * Frame k covers samples [round(k·fs/100), round((k+1)·fs/100)). Boundaries are computed with
 * integer arithmetic from the absolute sample count, so a sample rate that isn't a multiple of
 * 100 (22 050 Hz, say) cannot accumulate rounding error — over 45 minutes that would otherwise
 * be several seconds of drift introduced by the analysis itself.
 */
class EnergyFrameExtractor(val sampleRate: Int) {

    companion object {
        const val HOP_MS = 10
        private const val HIGH_PASS_HZ = 150.0
        private const val LOW_PASS_HZ = 4000.0
    }

    init {
        require(sampleRate >= 3000) { "Sample rate too low for speech analysis: $sampleRate Hz" }
    }

    private val highPass = Biquad.highPass(sampleRate.toDouble(), HIGH_PASS_HZ)
    private val lowPass = Biquad.lowPass(sampleRate.toDouble(), min(LOW_PASS_HZ, 0.45 * sampleRate))

    private var frames = FloatArray(4096)
    private var count = 0
    private var samplesSeen = 0L
    private var nextBoundary = boundaryFor(1L)
    private var energySum = 0.0
    private var energyCount = 0

    /** Number of complete 10 ms frames produced so far. */
    val frameCount: Int get() = count

    /** Total samples consumed so far (including any silence pushed with [pushSilence]). */
    val samplesConsumed: Long get() = samplesSeen

    private fun boundaryFor(frameNumber: Long): Long = (frameNumber * sampleRate + 50L) / 100L

    /** Consumes the first [length] samples of [samples] (mono, range −1..1). */
    fun push(samples: FloatArray, length: Int) {
        for (n in 0 until length) {
            consume(samples[n].toDouble())
        }
    }

    /** Consumes [length] samples of digital silence (used to fill a gap in the decoded audio). */
    fun pushSilence(length: Long) {
        var left = length
        while (left > 0) {
            consume(0.0)
            left--
        }
    }

    private fun consume(x: Double) {
        val y = lowPass.process(highPass.process(x))
        energySum += y * y
        energyCount++
        samplesSeen++
        if (samplesSeen >= nextBoundary) {
            emitFrame()
            nextBoundary = boundaryFor(count.toLong() + 1L)
        }
    }

    private fun emitFrame() {
        val power = if (energyCount > 0) energySum / energyCount else 0.0
        val db = 10.0 * log10(power + 1e-10)
        if (count == frames.size) frames = frames.copyOf(frames.size * 2)
        frames[count++] = db.toFloat()
        energySum = 0.0
        energyCount = 0
    }

    /** The finished frames. A trailing partial frame is dropped. */
    fun finish(): FloatArray = frames.copyOf(count)
}

/** Second-order IIR filter (RBJ cookbook), Butterworth Q, direct form I. */
private class Biquad(
    private val b0: Double,
    private val b1: Double,
    private val b2: Double,
    private val a1: Double,
    private val a2: Double
) {
    private var x1 = 0.0
    private var x2 = 0.0
    private var y1 = 0.0
    private var y2 = 0.0

    fun process(x: Double): Double {
        val y = b0 * x + b1 * x1 + b2 * x2 - a1 * y1 - a2 * y2
        x2 = x1
        x1 = x
        y2 = y1
        y1 = y
        return y
    }

    companion object {
        private const val Q = 0.7071

        fun highPass(fs: Double, f0: Double): Biquad = design(fs, f0, true)
        fun lowPass(fs: Double, f0: Double): Biquad = design(fs, f0, false)

        private fun design(fs: Double, f0: Double, high: Boolean): Biquad {
            val w0 = 2.0 * PI * f0 / fs
            val cw = cos(w0)
            val alpha = sin(w0) / (2.0 * Q)
            val a0 = 1.0 + alpha
            val b0: Double
            val b1: Double
            val b2: Double
            if (high) {
                b0 = (1.0 + cw) / 2.0
                b1 = -(1.0 + cw)
                b2 = (1.0 + cw) / 2.0
            } else {
                b0 = (1.0 - cw) / 2.0
                b1 = 1.0 - cw
                b2 = (1.0 - cw) / 2.0
            }
            return Biquad(b0 / a0, b1 / a0, b2 / a0, -2.0 * cw / a0, (1.0 - alpha) / a0)
        }
    }
}
