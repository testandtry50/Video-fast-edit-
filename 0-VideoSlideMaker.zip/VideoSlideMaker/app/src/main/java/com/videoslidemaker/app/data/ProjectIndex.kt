package com.videoslidemaker.app.data

import org.json.JSONArray
import org.json.JSONObject

/**
 * NEW (2.14): several projects in one app.
 *
 * This file is the small, Android-free part of that: what the project LIST looks like, the naming rules, and how the
 * list is written to disk. Nothing here opens a project - a project's own data (script, photos, matches, settings)
 * stays in its own file, see [ProjectRepository]. The list only keeps a one-line summary of each project, so showing
 * 50 projects never means reading 50 big project files.
 */
data class ProjectInfo(
    val id: String,
    val name: String,
    val createdAtMs: Long,
    val updatedAtMs: Long,
    /** Script lines (or photos, for a project without a script) - the number of slides the video will have. */
    val slideCount: Int = 0,
    val photoCount: Int = 0,
    /** Length of the finished video. A 5 hour project shows as 5:00:00. */
    val durationSec: Double = 0.0
)

/** The list of projects, and which one is open. Immutable: every change returns a new list. */
data class ProjectIndex(
    val projects: List<ProjectInfo> = emptyList(),
    val activeId: String? = null
) {
    fun find(id: String): ProjectInfo? = projects.firstOrNull { it.id == id }

    fun contains(id: String): Boolean = projects.any { it.id == id }

    val names: List<String> get() = projects.map { it.name }

    /** Adds [info] at the end. A project with the same id is replaced, never doubled. */
    fun plus(info: ProjectInfo): ProjectIndex =
        copy(projects = projects.filterNot { it.id == info.id } + info)

    /** Takes a project out of the list. If it was the open one, nothing is open any more. */
    fun minus(id: String): ProjectIndex =
        copy(projects = projects.filterNot { it.id == id }, activeId = if (activeId == id) null else activeId)

    fun withActive(id: String?): ProjectIndex =
        copy(activeId = if (id != null && contains(id)) id else null)

    /** A new name, made unique among the OTHER projects. An empty name is ignored. */
    fun renamed(id: String, rawName: String, nowMs: Long): ProjectIndex {
        val current = find(id) ?: return this
        val cleaned = ProjectNames.clean(rawName)
        if (cleaned.isEmpty()) return this
        val others = projects.filter { it.id != id }.map { it.name }
        val finalName = ProjectNames.unique(cleaned, others)
        if (finalName == current.name) return this
        return replace(current.copy(name = finalName, updatedAtMs = nowMs))
    }

    /**
     * The numbers shown on the project's card. With [nowMs] null the "edited" time is left as it was (used right after
     * a project is opened, which is not an edit).
     */
    fun withSummary(id: String, slides: Int, photos: Int, durationSec: Double, nowMs: Long?): ProjectIndex {
        val current = find(id) ?: return this
        val updated = current.copy(
            slideCount = slides.coerceAtLeast(0),
            photoCount = photos.coerceAtLeast(0),
            durationSec = if (durationSec.isNaN() || durationSec < 0.0) 0.0 else durationSec,
            updatedAtMs = nowMs ?: current.updatedAtMs
        )
        return if (updated == current) this else replace(updated)
    }

    /** The project that was edited most recently, ignoring [id]. Null when there is no other project. */
    fun mostRecentOtherThan(id: String?): ProjectInfo? =
        projects.filter { it.id != id }.maxByOrNull { it.updatedAtMs }

    /** For the Projects screen: the open project first, then the rest, newest edit first. */
    fun ordered(): List<ProjectInfo> {
        val rest = projects.filter { it.id != activeId }.sortedByDescending { it.updatedAtMs }
        val open = projects.firstOrNull { it.id == activeId }
        return if (open != null) listOf(open) + rest else rest
    }

    private fun replace(info: ProjectInfo): ProjectIndex =
        copy(projects = projects.map { if (it.id == info.id) info else it })
}

/** What the Projects screen needs. Kept in the ViewModel; the screen only draws it. */
data class ProjectsUi(
    val projects: List<ProjectInfo> = emptyList(),
    val activeId: String? = null,
    /** False until the saved projects have been read (the first moments after the app starts). */
    val ready: Boolean = false,
    /** Words for the "please wait" cover while a project is being opened, copied or deleted. Null = nothing going on. */
    val busyText: String? = null,
    /** One line about what just happened or why something was refused. */
    val message: String? = null,
    val messageIsProblem: Boolean = false
) {
    val activeName: String? get() = projects.firstOrNull { it.id == activeId }?.name

    /** The open project first, then the others, newest edit first. */
    fun ordered(): List<ProjectInfo> = ProjectIndex(projects, activeId).ordered()
}

object ProjectNames {
    const val MAX_LENGTH = 60

    /** Trims, turns every run of spaces / new lines into one space and cuts the name at [MAX_LENGTH]. */
    fun clean(raw: String): String {
        val collapsed = raw.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }.joinToString(" ")
        return if (collapsed.length <= MAX_LENGTH) collapsed else collapsed.substring(0, MAX_LENGTH).trimEnd()
    }

    /** [base], or "base (2)", "base (3)" ... the first one no other project has (capital letters do not count). */
    fun unique(base: String, existing: Collection<String>): String {
        val taken = existing.map { it.lowercase() }.toHashSet()
        if (base.lowercase() !in taken) return base
        var n = 2
        while (true) {
            val candidate = "$base ($n)"
            if (candidate.lowercase() !in taken) return candidate
            n++
        }
    }

    /** "Project 1", "Project 2" ... for a project the person did not name. */
    fun nextDefault(existing: Collection<String>): String = unique("Project ${existing.size + 1}", existing)

    /** The name of a copy: "Trip video copy", then "Trip video copy (2)". */
    fun copyOf(name: String, existing: Collection<String>): String {
        val base = if (name.isBlank()) "Project copy" else clean("$name copy")
        return unique(base, existing)
    }

    /** True when [name] contains every word of [query] (any order, capital letters do not matter). An empty query matches all. */
    fun matches(name: String, query: String): Boolean {
        val words = query.lowercase().split(Regex("\\s+")).filter { it.isNotEmpty() }
        if (words.isEmpty()) return true
        val lower = name.lowercase()
        return words.all { lower.contains(it) }
    }

    /** 0:00, 4:05, 1:02:03 - a video length for a project card. */
    fun formatDuration(seconds: Double): String {
        val total = if (seconds.isNaN() || seconds < 0.0) 0L else Math.round(seconds)
        val h = total / 3600
        val m = (total % 3600) / 60
        val s = total % 60
        return if (h > 0) String.format(java.util.Locale.ROOT, "%d:%02d:%02d", h, m, s) else String.format(java.util.Locale.ROOT, "%d:%02d", m, s)
    }
}

/** Reads and writes the project list as JSON. A damaged list is reported as null, never as an exception. */
object ProjectIndexCodec {
    private const val VERSION = 1

    fun encode(index: ProjectIndex): String {
        val root = JSONObject()
        root.put("version", VERSION)
        root.put("activeId", index.activeId ?: JSONObject.NULL)
        val list = JSONArray()
        index.projects.forEach { p ->
            val o = JSONObject()
            o.put("id", p.id)
            o.put("name", p.name)
            o.put("created", p.createdAtMs)
            o.put("updated", p.updatedAtMs)
            o.put("slides", p.slideCount)
            o.put("photos", p.photoCount)
            o.put("duration", p.durationSec)
            list.put(o)
        }
        root.put("projects", list)
        return root.toString()
    }

    fun decode(text: String): ProjectIndex? {
        return try {
            val root = JSONObject(text)
            val list = root.optJSONArray("projects") ?: return null
            val seen = HashSet<String>()
            val projects = ArrayList<ProjectInfo>()
            for (i in 0 until list.length()) {
                val o = list.optJSONObject(i) ?: continue
                val id = o.optString("id", "")
                if (!isSafeId(id) || !seen.add(id)) continue
                val name = ProjectNames.clean(o.optString("name", "")).ifEmpty { "Untitled" }
                val duration = o.optDouble("duration", 0.0)
                projects.add(
                    ProjectInfo(
                        id = id,
                        name = name,
                        createdAtMs = o.optLong("created", 0L),
                        updatedAtMs = o.optLong("updated", 0L),
                        slideCount = o.optInt("slides", 0).coerceAtLeast(0),
                        photoCount = o.optInt("photos", 0).coerceAtLeast(0),
                        durationSec = if (duration.isNaN() || duration < 0.0) 0.0 else duration
                    )
                )
            }
            val active = if (root.isNull("activeId")) null else root.optString("activeId", "").takeIf { it.isNotEmpty() }
            ProjectIndex(projects, active).withActive(active)
        } catch (_: Exception) {
            null
        }
    }

    /** An id becomes part of a file name, so only plain letters, digits, - and _ are accepted. */
    fun isSafeId(id: String): Boolean = id.isNotEmpty() && id.length <= 64 && id.all { it in 'a'..'z' || it in 'A'..'Z' || it in '0'..'9' || it == '-' || it == '_' }
}
