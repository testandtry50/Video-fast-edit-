package com.videoslidemaker.app.voicefx

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import com.videoslidemaker.app.align.PlaybackSpeed

/**
 * Plays one short clip of 16-bit PCM (one spoken sentence, already changed by the voice changer).
 * Starting a new clip stops the previous one. Call from the main thread.
 */
class PcmClipPlayer {
    private var track: AudioTrack? = null

    /**
     * Plays [pcm]. [speed] (1 = normal) plays it faster or slower without changing the pitch (used by the
     * Preview's speed control). Returns the speed it really plays at: the one asked for, or the nearest
     * one this phone accepts (normal speed when nothing could be played).
     */
    fun play(pcm: ByteArray, sampleRate: Int = 44100, channels: Int = 2, speed: Float = 1f): Float {
        stop()
        var applied = 1f
        val frameBytes = channels * 2
        val size = pcm.size - pcm.size % frameBytes
        if (size <= 0) return applied
        try {
            val mask = if (channels == 1) AudioFormat.CHANNEL_OUT_MONO else AudioFormat.CHANNEL_OUT_STEREO
            val t = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sampleRate)
                        .setChannelMask(mask)
                        .build()
                )
                .setBufferSizeInBytes(size)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()
            t.write(pcm, 0, size)
            if (speed != 1f) applied = PlaybackSpeed.setOn(t, speed)
            t.play()
            track = t
        } catch (_: Exception) {
            track = null
            applied = 1f
        }
        return applied
    }

    fun stop() {
        val t = track
        track = null
        if (t != null) {
            runCatching { t.stop() }
            runCatching { t.release() }
        }
    }
}
