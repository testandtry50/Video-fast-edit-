package com.videoslidemaker.app.audio

import kotlin.math.roundToInt

/**
 * NEW (2.19): what a background sound IS. When a sound is assigned to B1, B2... the app asks this, because a rain loop,
 * a sad piano track and a door slam all need different treatment under a voice: the rain should stay low and steady, the
 * piano should step aside while someone speaks, the door slam should play once and be heard.
 */
enum class SoundKind(val label: String, val hint: String, val musicLike: Boolean) {
    /** Nothing chosen yet: the sound behaves like ordinary background music did before 2.19. */
    UNSET("Not set", "", false),
    MUSIC("Background music", "A song or a score, with or without singing", true),
    INSTRUMENTAL("Instrumental music", "Music with no singing - the easiest to talk over", true),
    BEAT("Beat or rhythm loop", "Drums, a groove or a short pattern that repeats", true),
    AMBIENCE("Ambience / background noise", "Room tone, street, traffic, café, machines", false),
    NATURE("Nature or weather", "Rain, wind, sea, birds, a fire", false),
    CROWD("Background voices", "A crowd, a murmur, people talking far away", false),
    SFX_OBJECT("Sound effect: object", "A door, a click, a phone, a car, glass", false),
    SFX_HUMAN("Sound effect: human", "Footsteps, a clap, a laugh, a cough, a breath", false),
    SFX_ANIMAL("Sound effect: animal", "A dog, a cat, a horse, a bird call", false),
    SFX_IMPACT("Hit, boom or impact", "A punch, a drum hit, an explosion, a drop", false),
    SFX_WHOOSH("Whoosh or transition", "A swoosh, a riser or a sweep between scenes", false),
    OTHER("Something else", "Any other sound", false);

    /** A short sound that happens at one moment (as opposed to a bed that runs under the voice). */
    val isEffect: Boolean get() = this == SFX_OBJECT || this == SFX_HUMAN || this == SFX_ANIMAL || this == SFX_IMPACT || this == SFX_WHOOSH

    companion object {
        /** What the user can choose from (everything but [UNSET]), in the order they are shown. */
        val choices: List<SoundKind> get() = values().filter { it != UNSET }

        /** Saved projects store the name; anything unknown or missing is [UNSET]. */
        fun fromName(name: String?): SoundKind = values().firstOrNull { it.name == name } ?: UNSET
    }
}

/** The feeling of a piece of music. Shown for music-like kinds only. */
enum class SoundMood(val label: String) {
    NONE("No special feeling"),
    ACTION("Action"),
    DRAMATIC("Dramatic"),
    EMOTIONAL("Emotional"),
    CALM("Calm"),
    HAPPY("Happy"),
    MYSTERY("Mystery"),
    EPIC("Epic"),
    DARK("Dark or sad"),
    ROMANTIC("Romantic"),
    FUNNY("Funny");

    companion object {
        fun fromName(name: String?): SoundMood = values().firstOrNull { it.name == name } ?: NONE
    }
}

/** What the app does to a sound of a given kind and mood. Every number can still be changed by hand afterwards. */
data class SoundProfile(
    /** Lowered while someone speaks. */
    val duck: Boolean,
    /** Added to the smart mix's lowering depth (dB). Positive = lowers less. */
    val duckAdjustDb: Double,
    /** How far below the voice its loudness is matched (dB, negative). null = the smart mix's standard distance. */
    val levelDb: Double?,
    /** Plays once when shorter than its time, instead of repeating. */
    val playOnce: Boolean,
    /** Repeats exactly (same length every round), for beats. */
    val exactLoop: Boolean,
    val fadeInSec: Double,
    val fadeOutSec: Double
)

/**
 * NEW (2.19): the table that turns "what is this sound?" into mixing choices - plain numbers, no AI, no internet. It is
 * mirrored in tools/audiomix-reference/beatmark.py, where the table is checked for sense (e.g. an effect is never lowered
 * under the voice, a sung track always steps further aside than an instrumental one).
 */
object SoundProfiles {
    /** The smart mix's own distance below the voice when music is lowered under speech (see [SmartMix.bedOffsetDb]). */
    const val STANDARD_BED_DB = -10.0

    private class MoodTune(val levelDb: Double, val duckAdjustDb: Double)

    // levelDb = how far below the voice the music sits between words; duckAdjustDb = extra lowering depth (+ = less)
    private val MOODS: Map<SoundMood, MoodTune> = mapOf(
        SoundMood.ACTION to MoodTune(-7.0, 3.0),
        SoundMood.EPIC to MoodTune(-8.0, 2.0),
        SoundMood.DRAMATIC to MoodTune(-9.0, 0.0),
        SoundMood.HAPPY to MoodTune(-9.0, 1.0),
        SoundMood.FUNNY to MoodTune(-9.0, 1.0),
        SoundMood.MYSTERY to MoodTune(-12.0, -1.0),
        SoundMood.DARK to MoodTune(-12.0, -1.0),
        SoundMood.EMOTIONAL to MoodTune(-12.0, -2.0),
        SoundMood.CALM to MoodTune(-13.0, -2.0),
        SoundMood.ROMANTIC to MoodTune(-13.0, -2.0)
    )

    private fun music(mood: SoundMood, bonusDb: Double, beat: Boolean): SoundProfile {
        val tune = MOODS[mood]
        val level: Double? = when {
            tune != null -> tune.levelDb + bonusDb
            bonusDb != 0.0 -> STANDARD_BED_DB + bonusDb
            else -> null
        }
        return SoundProfile(
            duck = true,
            duckAdjustDb = tune?.duckAdjustDb ?: 0.0,
            levelDb = level,
            playOnce = false,
            exactLoop = beat,
            fadeInSec = if (beat) 0.2 else 1.0,
            fadeOutSec = if (beat) 0.3 else 1.5
        )
    }

    private fun effect(levelDb: Double) = SoundProfile(
        duck = false, duckAdjustDb = 0.0, levelDb = levelDb, playOnce = true, exactLoop = false, fadeInSec = 0.02, fadeOutSec = 0.05
    )

    private fun bed(levelDb: Double, duckAdjustDb: Double, fadeSec: Double) = SoundProfile(
        duck = true, duckAdjustDb = duckAdjustDb, levelDb = levelDb, playOnce = false, exactLoop = false, fadeInSec = fadeSec, fadeOutSec = fadeSec
    )

    fun profile(kind: SoundKind, mood: SoundMood): SoundProfile = when (kind) {
        SoundKind.UNSET, SoundKind.OTHER ->
            SoundProfile(duck = true, duckAdjustDb = 0.0, levelDb = null, playOnce = false, exactLoop = false, fadeInSec = 1.0, fadeOutSec = 1.0)
        SoundKind.MUSIC -> music(mood, 0.0, beat = false)
        // no singing to compete with the voice, so it may sit a little higher
        SoundKind.INSTRUMENTAL -> music(mood, 1.0, beat = false)
        SoundKind.BEAT -> music(mood, 0.0, beat = true)
        // a steady bed: very low, and it dips only a little so it does not pump up and down under the words
        SoundKind.AMBIENCE -> bed(-20.0, 8.0, 2.0)
        SoundKind.NATURE -> bed(-19.0, 8.0, 2.0)
        // sounds like speech, so it must step well aside or it hides the real voice
        SoundKind.CROWD -> bed(-22.0, -4.0, 1.5)
        SoundKind.SFX_OBJECT, SoundKind.SFX_HUMAN, SoundKind.SFX_ANIMAL -> effect(-5.0)
        SoundKind.SFX_IMPACT -> effect(-3.0)
        SoundKind.SFX_WHOOSH -> effect(-6.0)
    }

    /**
     * Gives [c] the mixing choices of [kind] / [mood]: lowering under the voice, loudness against the voice, repeat or play
     * once, exact repeat, fades. The sound's volume, position, marked part and time range are left alone. Fades are kept
     * short enough to leave room in a short time range.
     */
    fun apply(c: AudioClip, kind: SoundKind, mood: SoundMood): AudioClip {
        val usedMood = if (kind.musicLike) mood else SoundMood.NONE
        val p = profile(kind, usedMood)
        val room = if (c.hasRange) (c.rangeEndSec - c.startSec) / 4.0 else Double.MAX_VALUE
        val out = c.copy(
            kind = kind,
            mood = usedMood,
            autoDuck = p.duck,
            duckAdjustDb = p.duckAdjustDb,
            levelDb = p.levelDb,
            playOnce = p.playOnce,
            // an exact repeat the user switched on stays on; only a beat turns it on by itself
            exactLoop = c.exactLoop || p.exactLoop,
            fadeInSec = minOf(p.fadeInSec, room),
            fadeOutSec = minOf(p.fadeOutSec, room)
        )
        // a one-shot sound is placed, not stretched over the whole video
        return if (p.playOnce) out.copy(fitVideo = false, loop = false) else out
    }

    /** "Background music · Action" - what the sound was set as, for its row; empty when nothing was chosen. */
    fun tag(c: AudioClip): String = when {
        c.kind == SoundKind.UNSET -> ""
        c.mood != SoundMood.NONE -> c.kind.label + " · " + c.mood.label
        else -> c.kind.label
    }

    /** What the app will do for this kind and mood, in plain words (shown before the user confirms and afterwards). */
    fun describe(kind: SoundKind, mood: SoundMood): String {
        val usedMood = if (kind.musicLike) mood else SoundMood.NONE
        val p = profile(kind, usedMood)
        val parts = ArrayList<String>(4)
        val level = p.levelDb
        parts.add(
            if (level == null) "Its loudness is matched to the voice, a little below it."
            else "Its loudness is matched to the voice, about ${(-level).roundToInt()} dB below it."
        )
        parts.add(
            when {
                !p.duck -> "It is not lowered while someone speaks, so it stays clear."
                p.duckAdjustDb >= 5.0 -> "It dips only a little under the voice, so it stays steady."
                p.duckAdjustDb <= -3.0 -> "It steps well aside while someone speaks."
                else -> "It lowers while someone speaks and swells back in the gaps."
            }
        )
        parts.add(
            if (p.playOnce) "A short sound plays once at its start time and is not repeated."
            else "It is cut or repeated to fill the time it is given."
        )
        if (p.exactLoop) parts.add("It repeats exactly, so the rhythm keeps its beat.")
        return parts.joinToString(" ")
    }
}
