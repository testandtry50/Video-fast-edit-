package com.videoslidemaker.app.export

/**
 * Converts a long stream of 16-bit little-endian PCM piece by piece to another sample rate and
 * channel count with the same band-limited filter as [PcmResampler.convert] (see SincResampler.kt). Unlike that
 * function, it never needs the whole recording in memory: feed it each decoded chunk in order and
 * it carries the few frames it needs between chunks, so a multi-hour recording is fine.
 *
 * The filter looks a little ahead of each output sample, so the output lags the input by about a millisecond
 * (the very last millisecond of a recording is not produced). The start of the sound is not moved.
 */
class StreamingPcmConverter(
    srcRate: Int,
    private val srcChannels: Int,
    dstRate: Int,
    private val dstChannels: Int
) {
    private val plan: ResamplePlan? =
        if (srcRate == dstRate || srcRate <= 0 || dstRate <= 0) null else ResamplePlan.of(srcRate, dstRate)
    private val resamplers: Array<ChannelResampler?> =
        Array(if (srcChannels > 0) srcChannels else 0) { if (plan != null) ChannelResampler(plan) else null }

    /** Converts one chunk. [length] bytes of [chunk] are used (a trailing half-frame is ignored). */
    fun convert(chunk: ByteArray, length: Int = chunk.size): ByteArray {
        if (srcChannels <= 0 || dstChannels <= 0) return ByteArray(0)
        val frames = length / (2 * srcChannels)
        if (frames <= 0) return ByteArray(0)

        val input = Array(srcChannels) { FloatArray(frames) }
        var idx = 0
        for (f in 0 until frames) {
            for (c in 0 until srcChannels) {
                val lo = chunk[idx].toInt() and 0xFF
                val hi = chunk[idx + 1].toInt()
                input[c][f] = ((hi shl 8) or lo).toShort() / 32768f
                idx += 2
            }
        }

        val converted: Array<FloatArray> =
            if (plan == null) input else Array(srcChannels) { c -> resamplers[c]!!.push(input[c], 0, frames) }
        val n = converted[0].size
        val out = ByteArray(n * dstChannels * 2)
        var o = 0
        for (i in 0 until n) {
            for (dc in 0 until dstChannels) {
                val v = when {
                    srcChannels == dstChannels -> converted[dc][i]
                    srcChannels == 1 -> converted[0][i]
                    dstChannels == 1 -> (converted[0][i] + converted[1][i]) / 2f
                    else -> converted[minOf(dc, srcChannels - 1)][i]
                }
                val iv = Math.round(v * 32768f).coerceIn(-32768, 32767)
                out[o] = (iv and 0xFF).toByte()
                out[o + 1] = ((iv shr 8) and 0xFF).toByte()
                o += 2
            }
        }
        return out
    }
}
