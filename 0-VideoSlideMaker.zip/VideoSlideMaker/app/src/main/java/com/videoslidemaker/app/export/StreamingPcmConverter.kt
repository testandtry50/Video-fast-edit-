package com.videoslidemaker.app.export

import kotlin.math.roundToInt

/**
 * Converts a long stream of 16-bit little-endian PCM piece by piece to another sample rate and
 * channel count (linear interpolation, the same quality as [PcmResampler.convert]). Unlike that
 * function, it never needs the whole recording in memory: feed it each decoded chunk in order and
 * it carries the one frame it needs between chunks, so a multi-hour recording is fine.
 */
class StreamingPcmConverter(
    srcRate: Int,
    private val srcChannels: Int,
    dstRate: Int,
    private val dstChannels: Int
) {
    private val step = srcRate.toDouble() / dstRate.toDouble() // source frames per output frame
    private var consumed = 0L        // source frames already received before the current chunk
    private var nextOut = 0L         // index of the next output frame to produce
    private val prevFrame = IntArray(srcChannels)
    private val interp = FloatArray(srcChannels)

    private fun sample(buf: ByteArray, frame: Int, channel: Int): Int {
        val idx = (frame * srcChannels + channel) * 2
        return (((buf[idx + 1].toInt()) shl 8) or (buf[idx].toInt() and 0xFF)).toShort().toInt()
    }

    /** Converts one chunk. [length] bytes of [chunk] are used (a trailing half-frame is ignored). */
    fun convert(chunk: ByteArray, length: Int = chunk.size): ByteArray {
        if (srcChannels <= 0 || dstChannels <= 0) return ByteArray(0)
        val frames = length / (2 * srcChannels)
        if (frames <= 0) return ByteArray(0)

        val maxOut = (frames / step).toInt() + 4
        val out = ByteArray(maxOut * dstChannels * 2)
        var o = 0
        while (o + dstChannels * 2 <= out.size) {
            val pos = nextOut * step
            val i0 = pos.toLong()
            // the output sample sits between source frames i0 and i0+1; wait for the next chunk if i0+1 is not here yet
            if (i0 + 1 > consumed + frames - 1) break
            val frac = (pos - i0).toFloat()
            for (c in 0 until srcChannels) {
                val s0 = if (i0 < consumed) prevFrame[c] else sample(chunk, (i0 - consumed).toInt(), c)
                val s1 = sample(chunk, (i0 + 1 - consumed).toInt(), c)
                interp[c] = s0 + (s1 - s0) * frac
            }
            for (dc in 0 until dstChannels) {
                val v = when {
                    srcChannels == dstChannels -> interp[dc]
                    srcChannels == 1 -> interp[0]
                    dstChannels == 1 -> (interp[0] + interp[1]) / 2f
                    else -> interp[minOf(dc, srcChannels - 1)]
                }
                val iv = v.roundToInt().coerceIn(-32768, 32767)
                out[o] = (iv and 0xFF).toByte()
                out[o + 1] = ((iv shr 8) and 0xFF).toByte()
                o += 2
            }
            nextOut++
        }
        for (c in 0 until srcChannels) prevFrame[c] = sample(chunk, frames - 1, c)
        consumed += frames
        return out.copyOf(o)
    }
}
