package com.videoslidemaker.app.export

import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Binder
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import com.videoslidemaker.app.MainActivity
import com.videoslidemaker.app.R
import com.videoslidemaker.app.VideoSlideMakerApp
import com.videoslidemaker.app.data.ImageStore
import com.videoslidemaker.app.model.ExportSettings
import com.videoslidemaker.app.model.ExportUiProgress
import com.videoslidemaker.app.model.PoolImage
import com.videoslidemaker.app.model.SentenceSlide
import com.videoslidemaker.app.model.TextOverlay
import com.videoslidemaker.app.tts.NarrationTts
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.concurrent.atomic.AtomicLong

/**
 * NEW / IMPROVED: the original app rendered its export on the same page the person was looking
 * at, in a browser tab that could be lost to a screen lock or a task switch. This runs the same
 * job as a proper Android foreground service with an ongoing notification, so it keeps working
 * — and the person can see progress — no matter what else they do with their phone meanwhile.
 */
class ExportForegroundService : Service() {

    private val scope = CoroutineScope(SupervisorJob())
    private val binder = LocalBinder()
    private var job: Job? = null
    private var wakeLock: PowerManager.WakeLock? = null

    inner class LocalBinder : Binder() {
        fun service(): ExportForegroundService = this@ExportForegroundService
    }

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onCreate() {
        super.onCreate()
        startForeground(NOTIFICATION_ID, buildNotification(0, "Starting…"))
    }

    fun startExport(slides: List<SentenceSlide>, images: List<PoolImage>, settings: ExportSettings, textOverlays: List<TextOverlay> = emptyList()) {
        // One export at a time for the whole app (not just this service object). A cancelled or old
        // export that is still winding down reports isActive == false, so it never blocks a new one.
        if (activeJob?.isActive == true) return

        // Every run gets its own number, and only the CURRENT run may update the progress bar.
        // The bar's value is shared by the whole app, so before this, an old export that was still
        // running in the background (e.g. one that was cancelled but hadn't stopped yet) kept writing
        // its own progress over the new one — the bar jumped up and down between the two.
        val runId = newRun()
        var lastPercent = 0 // within one run the bar may only ever move forward
        publish(runId, ExportUiProgress(running = true, percent = 0, message = "Starting…"))

        // A multi-minute export needs the CPU to keep running at full speed even if the screen
        // turns off while it's working. A foreground service gets SOME protection from Doze, but
        // not full immunity — especially under aggressive OEM battery managers — so a photo/video
        // pipeline like this one holding a wake lock for the duration is standard practice. The
        // timeout is a safety cap (not an indefinite hold) in case release() were ever missed.
        val powerManager = getSystemService(Context.POWER_SERVICE) as? PowerManager
        // Held in a local too, so each run releases only ITS OWN lock — a late-finishing old run
        // used to release the new run's lock and let the CPU slow down mid-export.
        val runLock = powerManager?.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "VideoSlideMaker:export")?.apply {
            setReferenceCounted(false)
            acquire(WAKE_LOCK_TIMEOUT_MS)
        }
        wakeLock = runLock

        val tts = NarrationTts(applicationContext)
        val engine = VideoExportEngine(applicationContext, ImageStore(applicationContext), tts)
        job = scope.launch {
            val result = try {
                engine.export(slides, images, settings, textOverlays) { percent, message ->
                    if (!isCurrentRun(runId)) return@export // a stale run must not touch the bar or notification
                    lastPercent = maxOf(lastPercent, percent.coerceIn(0, 100))
                    publish(runId, ExportUiProgress(running = true, percent = lastPercent, message = message))
                    updateNotification(lastPercent, message)
                }
            } catch (e: CancellationException) {
                // Cancel Export: cancel() has already reset the screen, so just let it end here.
                throw e
            } catch (e: Throwable) {
                // Anything unexpected becomes a readable message on screen instead of crashing the app.
                ExportResult(false, null, e.message ?: "Export failed (${e.javaClass.simpleName}).")
            } finally {
                runLock?.let { if (it.isHeld) it.release() }
                if (wakeLock === runLock) wakeLock = null
                // Each export makes its own speech engine; without this it was never released.
                try { tts.shutdown() } catch (_: Throwable) {}
            }
            // Same rule for the final result: an old run that finishes late must not overwrite the
            // screen of the run the person is actually watching.
            publish(
                runId,
                if (result.success) {
                    ExportUiProgress(running = false, percent = 100, message = "Done", done = true, outputUri = result.outputUri)
                } else {
                    ExportUiProgress(running = false, percent = 0, message = result.error ?: "Export failed", done = true, error = result.error)
                }
            )
            // Only the current run may shut the service down; an old run finishing late must not
            // stop the service out from under the export that is now running.
            if (isCurrentRun(runId)) {
                stopForeground(STOP_FOREGROUND_DETACH)
                stopSelf()
            }
        }
        activeJob = job
    }

    fun cancel() {
        // Retire the current run FIRST, so nothing it reports from here on can bring the bar back.
        retireCurrentRun(ExportUiProgress(running = false, percent = 0, message = "Cancelled", done = true))
        job?.cancel()
        activeJob?.cancel()
        releaseWakeLock()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    /**
     * Android 15 and newer end a "data sync" foreground service after about 6 hours in a day, and the service must
     * stop within a few seconds or the app is crashed. Stop the export the way Cancel does, but say why.
     */
    override fun onTimeout(startId: Int, fgsType: Int) {
        val why = "Android stops long background work after about 6 hours, so the export was paused. Press Export to try again."
        retireCurrentRun(ExportUiProgress(running = false, percent = 0, message = why, done = true, error = why))
        job?.cancel()
        activeJob?.cancel()
        releaseWakeLock()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun releaseWakeLock() {
        wakeLock?.let { if (it.isHeld) it.release() }
        wakeLock = null
    }

    private fun updateNotification(percent: Int, message: String) {
        val manager = getSystemService(NotificationManager::class.java)
        manager?.notify(NOTIFICATION_ID, buildNotification(percent, message))
    }

    private fun buildNotification(percent: Int, message: String): Notification {
        val openIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, VideoSlideMakerApp.EXPORT_CHANNEL_ID)
            .setContentTitle("Creating your video")
            .setContentText(message)
            .setSmallIcon(R.drawable.ic_notification)
            .setProgress(100, percent, false)
            .setOngoing(true)
            .setContentIntent(openIntent)
            .build()
    }

    override fun onDestroy() {
        releaseWakeLock()
        scope.cancel()
        super.onDestroy()
    }

    companion object {
        private const val NOTIFICATION_ID = 42
        // Safety cap, not an indefinite hold. 30 minutes was too short for a long, high-resolution
        // narrated video: the lock could expire mid-export and let the CPU slow right down.
        private const val WAKE_LOCK_TIMEOUT_MS = 3 * 60 * 60 * 1000L
        private val _progress = MutableStateFlow(ExportUiProgress())
        val progress: StateFlow<ExportUiProgress> = _progress.asStateFlow()

        // Identifies which export run is allowed to update [progress]. Guarded by [lock] so that
        // "check it is still current" and "write the value" can never be split by another thread.
        private val lock = Any()
        private val currentRun = AtomicLong(0)
        @Volatile private var activeJob: Job? = null

        private fun newRun(): Long = synchronized(lock) { currentRun.incrementAndGet() }

        private fun isCurrentRun(runId: Long): Boolean = currentRun.get() == runId

        private fun publish(runId: Long, value: ExportUiProgress) {
            synchronized(lock) {
                if (currentRun.get() == runId) _progress.value = value
            }
        }

        private fun retireCurrentRun(finalValue: ExportUiProgress) {
            synchronized(lock) {
                currentRun.incrementAndGet() // every earlier run is now stale
                _progress.value = finalValue
            }
        }
    }
}
