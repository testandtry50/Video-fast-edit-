package com.videoslidemaker.app.export

import android.media.MediaCodec
import android.media.MediaFormat
import android.media.MediaMuxer
import java.nio.ByteBuffer

/**
 * MediaMuxer requires every track to be registered via addTrack() before start() is called, and
 * no samples may be written until after start(). The video and audio encoders in this app
 * negotiate their final output formats independently, so this holder buffers any samples that
 * arrive before both tracks are known and flushes them the moment the muxer actually starts.
 *
 * CHANGED: the whole sound track is encoded BEFORE the first picture (see VideoExportEngine), so every sound sample
 * used to be written first and the video after it - an MP4 whose sound sits in one block ahead of the whole video.
 * Many players (and apps that re-process shared videos) read such a file badly and play only the first few seconds of
 * sound. Sound samples are now held back in [audioQueue] and written in step with the video: before each video
 * sample goes in, every sound sample up to its time goes in first, so the two tracks alternate as in any normal MP4.
 */
class MuxerHolder(outputPath: String, private val expectAudioTrack: Boolean) {
    private val muxer = MediaMuxer(outputPath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
    private var videoTrack = -1
    private var audioTrack = -1
    private var started = false
    private var lastVideoPtsUs = Long.MIN_VALUE

    private class Sample(val track: Int, val data: ByteBuffer, val info: MediaCodec.BufferInfo)

    /** Video that arrived before the muxer could start. */
    private val pendingVideo = mutableListOf<Sample>()

    /** Encoded sound waiting for the video to catch up with it. */
    private val audioQueue = TimedQueue<Sample>()

    @Synchronized
    fun addVideoTrack(format: MediaFormat): Int {
        videoTrack = muxer.addTrack(format)
        maybeStart()
        return videoTrack
    }

    @Synchronized
    fun addAudioTrack(format: MediaFormat): Int {
        audioTrack = muxer.addTrack(format)
        maybeStart()
        return audioTrack
    }

    private fun maybeStart() {
        val videoReady = videoTrack >= 0
        val audioReady = !expectAudioTrack || audioTrack >= 0
        if (videoReady && audioReady && !started) {
            muxer.start()
            started = true
            pendingVideo.forEach { writeVideoNow(it) }
            pendingVideo.clear()
        }
    }

    @Synchronized
    fun writeVideoSample(track: Int, buffer: ByteBuffer, info: MediaCodec.BufferInfo) {
        val sample = copyOf(track, buffer, info)
        if (!started) pendingVideo.add(sample) else writeVideoNow(sample)
    }

    @Synchronized
    fun writeAudioSample(track: Int, buffer: ByteBuffer, info: MediaCodec.BufferInfo) {
        audioQueue.add(info.presentationTimeUs, copyOf(track, buffer, info))
        // Sound that arrives after the picture it belongs with (not the case today, but cheap to keep right).
        if (started && lastVideoPtsUs != Long.MIN_VALUE) flushAudioUpTo(lastVideoPtsUs)
    }

    private fun writeVideoNow(sample: Sample) {
        flushAudioUpTo(sample.info.presentationTimeUs)
        muxer.writeSampleData(sample.track, sample.data, sample.info)
        lastVideoPtsUs = sample.info.presentationTimeUs
    }

    private fun flushAudioUpTo(uptoUs: Long) {
        audioQueue.drainUpTo(uptoUs) { muxer.writeSampleData(it.track, it.data, it.info) }
    }

    /** The codec reuses its output buffer as soon as it is released, so every sample is copied before it is kept. */
    private fun copyOf(track: Int, buffer: ByteBuffer, info: MediaCodec.BufferInfo): Sample {
        val copy = ByteBuffer.allocate(info.size)
        copy.put(buffer)
        copy.flip()
        val copiedInfo = MediaCodec.BufferInfo().apply {
            set(0, info.size, info.presentationTimeUs, info.flags)
        }
        return Sample(track, copy, copiedInfo)
    }

    @Synchronized
    fun release() {
        try {
            if (started) {
                // whatever sound is left (the sound track may run a little past the last picture)
                audioQueue.drainAll { muxer.writeSampleData(it.track, it.data, it.info) }
                muxer.stop()
            }
        } finally {
            muxer.release()
        }
    }
}
