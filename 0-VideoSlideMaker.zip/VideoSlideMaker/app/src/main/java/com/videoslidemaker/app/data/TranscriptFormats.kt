package com.videoslidemaker.app.data

/**
 * Real transcripts do not all write `0:06 - text`. This turns the other common shapes into that plain form BEFORE
 * [ScriptParser] looks at them, so [TimestampParser] stays the one place that turns text into a time.
 *
 * | Written as                                   | Read as                                   |
 * |----------------------------------------------|-------------------------------------------|
 * | `[00:05:20] text`, `(5:20) text`, `<0:06>`   | `00:05:20 text` (any of `[ ( < {`)        |
 * | `00:05:20,430 text` (SRT milliseconds)       | `00:05:20.430 text`                       |
 * | `00:05:20,430 --> 00:05:24,000 text`         | `00:05:20.430 text` (the END is ignored)  |
 * | SRT / WebVTT blocks: index, timing, text     | one line per cue, text lines joined       |
 * | `5m20s text`, `1h02m03.5s text`, `320s text` | `00:05:20.000 text` ...                   |
 *
 * Not accepted, on purpose: frame-based timecodes (`00:05:20:12`), because the frame rate is unknown and a guess would
 * be a wrong timestamp that looks right. Every line that already parsed before still parses to exactly the same result:
 * a line is only rewritten when it has one of the shapes above.
 */
object TranscriptFormats {

    /** One line of the script, with the 1-based number of the file line it started on. */
    class LogicalLine(val lineNumber: Int, val text: String)

    private const val RUN = "[0-9]+(?::[0-9]+)*(?:[.,][0-9]+)?"
    private const val ARROW = "\\s*(?:-->|\u2013>|\u2014>)\\s*"

    /** `[00:05:20]`, `(5:20)`, `<00:05:20.430>`, `{...}`; optionally a range inside; optional ':' after the closer. */
    private val BRACKET = Regex("^([\\[(<{])\\s*($RUN)(?:$ARROW($RUN))?\\s*([\\])>}])\\s*:?\\s*(.*)$")

    /** `00:05:20,430 --> 00:05:24,000 text` */
    private val INLINE_RANGE = Regex("^($RUN)$ARROW($RUN)(.*)$")

    /** An SRT millisecond comma: needs a colon, so `1,000 sold` and `5:20, hello` are left alone. */
    private val COMMA_DECIMAL = Regex("^([0-9]+:[0-9]+(?::[0-9]+)?),([0-9]{1,3})(?![0-9])")

    /** `1h02m03.5s`, `5m20s`, `320s`: digits directly followed by the unit, and the unit not followed by a letter. */
    private val UNITS = Regex("^(?:([0-9]+)h\\s*)?(?:([0-9]+)m\\s*)?(?:([0-9]+(?:\\.[0-9]+)?)s)?(?![A-Za-z0-9])")

    /** A timing line with nothing after the range except WebVTT cue settings (`align:start position:0%`). */
    private val RANGE_ONLY = Regex("^($RUN)$ARROW($RUN)(?:\\s+(?:[A-Za-z]+:\\S+\\s*)*)?$")

    private fun canon(run: String): String = run.replace(',', '.')

    private fun join(clock: String, rest: String): String {
        val r = rest.trimStart()
        return if (r.isEmpty()) clock else "$clock $r"
    }

    /**
     * Rewrites one (already trimmed) line into the plain `clock text` form when it has one of the shapes above; every other
     * line is returned exactly as it came.
     */
    fun normalizeShape(line: String): String {
        if (line.isEmpty()) return line
        val c0 = line[0]
        if (c0 == '[' || c0 == '(' || c0 == '<' || c0 == '{') {
            val m = BRACKET.matchEntire(line) ?: return line
            return join(canon(m.groupValues[2]), m.groupValues[5])
        }
        if (c0 !in '0'..'9') return line

        INLINE_RANGE.matchEntire(line)?.let { return join(canon(it.groupValues[1]), it.groupValues[3]) }

        COMMA_DECIMAL.find(line)?.let { return it.groupValues[1] + "." + it.groupValues[2] + line.substring(it.value.length) }

        val u = UNITS.find(line)
        if (u != null && (u.groupValues[1].isNotEmpty() || u.groupValues[2].isNotEmpty() || u.groupValues[3].isNotEmpty())) {
            val h = if (u.groupValues[1].isEmpty()) 0L else u.groupValues[1].toLong()
            val m = if (u.groupValues[2].isEmpty()) 0L else u.groupValues[2].toLong()
            val s = if (u.groupValues[3].isEmpty()) 0.0 else u.groupValues[3].toDouble()
            val ms = h * 3_600_000L + m * 60_000L + Math.round(s * 1000.0)
            return TimestampParser.formatCanonical(ms) + line.substring(u.value.length)
        }
        return line
    }

    /** The cue's start, as a plain clock, when [line] is a timing line with no text after it; otherwise null. */
    private fun cueStart(line: String): String? = RANGE_ONLY.matchEntire(line)?.let { canon(it.groupValues[1]) }

    /**
     * The script as logical lines. SRT / WebVTT cues (an optional index line, a `start --> end` line, then the text on the
     * following lines up to a blank line) become one line each; the index numbers and the WEBVTT header are dropped instead
     * of being mistaken for timestamps. Everything else passes through, trimmed. Blank lines are dropped.
     */
    fun logicalLines(content: String): List<LogicalLine> {
        val raw = content.lines()
        val out = ArrayList<LogicalLine>()
        var i = 0
        while (i < raw.size) {
            val line = TimestampParser.trimPadding(raw[i])
            if (line.isEmpty()) {
                i++
                continue
            }
            if (out.isEmpty() && (line == "WEBVTT" || line.startsWith("WEBVTT "))) {
                i++
                continue
            }
            val start = cueStart(line)
            if (start != null) {
                val parts = ArrayList<String>()
                var j = i + 1
                while (j < raw.size) {
                    val t = TimestampParser.trimPadding(raw[j])
                    if (t.isEmpty()) break
                    parts.add(t)
                    j++
                }
                out.add(LogicalLine(i + 1, join(start, parts.joinToString(" "))))
                i = j
                continue
            }
            if (line.all { it in '0'..'9' }) {
                // a bare number right before a timing line is the cue's index, not a timestamp
                var j = i + 1
                while (j < raw.size && TimestampParser.trimPadding(raw[j]).isEmpty()) j++
                if (j < raw.size && cueStart(TimestampParser.trimPadding(raw[j])) != null) {
                    i++
                    continue
                }
            }
            out.add(LogicalLine(i + 1, line))
            i++
        }
        return out
    }

    /** True for `00:05:20:12` / `00:05:20;12`: a frame-based timecode, which needs a frame rate we do not have. */
    fun looksLikeFrameTimecode(line: String): Boolean = Regex("^[0-9]+:[0-9]+:[0-9]+[:;][0-9]+").containsMatchIn(line)
}
