package com.videoslidemaker.app.voicefx

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.tanh

/** One voice effect. Takes a stereo frame and writes the changed stereo frame into [out] (size 2). */
interface StereoEffect {
    fun process(l: Double, r: Double, out: DoubleArray)
}

private fun lerp(a: Double, b: Double, t: Double): Double = a + (b - a) * t

/**
 * Underwater. The voice is muffled (low-pass), rippled (a slowly moving delay, a little different in
 * each ear), wrapped in soft reverb, and a few small bubbles blip past. [a] is the strength 0..1 and
 * [s] is the ripple speed 0..1.
 */
class AquaEffect(private val fs: Int, private val a: Double, s: Double, seed: Int) : StereoEffect {
    private val lp = Biquad().lowpass(fs, 4500.0 * (700.0 / 4500.0).pow(a), 0.9)
    private val depth = (0.0005 + 0.0030 * a) * fs
    private val base = depth + 2.0
    private val dly = DelayLine((base + depth).toInt() + 8)
    private val rate = TWO_PI * (0.35 + 1.4 * s) / fs
    private var ph = 0.0
    private val gain = 1.0 + 0.5 * a
    private val rev = Reverb(fs, 0.55, 0.7, 0.18 + 0.22 * a, 10.0)
    private val rng = Rng(seed)
    private val rateBub = (0.6 + 3.0 * a) / fs
    private val bOn = BooleanArray(BUBBLES)
    private val bF = DoubleArray(BUBBLES)
    private val bPh = DoubleArray(BUBBLES)
    private val bT = DoubleArray(BUBBLES)
    private val bAmp = DoubleArray(BUBBLES)
    private val bPan = DoubleArray(BUBBLES) { 0.5 }
    private val wet = DoubleArray(2)

    override fun process(l: Double, r: Double, out: DoubleArray) {
        val x = (l + r) * 0.5
        val y = lp.process(x) * gain
        ph += rate
        if (ph > TWO_PI) ph -= TWO_PI
        dly.write(y)
        val wl = dly.read(base + depth * sin(ph))
        val wr = dly.read(base + depth * sin(ph + PI / 2))
        var ol = 0.65 * wl + 0.35 * y
        var orr = 0.65 * wr + 0.35 * y
        rev.process(ol, orr, wet)
        ol += wet[0]
        orr += wet[1]

        if (rng.unit() < rateBub) {
            for (i in 0 until BUBBLES) {
                if (!bOn[i]) {
                    bOn[i] = true
                    bF[i] = 350.0 + 750.0 * rng.unit()
                    bPh[i] = 0.0
                    bT[i] = 0.0
                    bAmp[i] = (0.02 + 0.02 * rng.unit()) * (0.4 + 0.6 * a)
                    bPan[i] = rng.unit()
                    break
                }
            }
        }
        val dt = 1.0 / fs
        for (i in 0 until BUBBLES) {
            if (bOn[i]) {
                val t = bT[i]
                val f = bF[i] * (1.0 + 10.0 * min(t, 0.05))
                bPh[i] += TWO_PI * f * dt
                val env = exp(-t / 0.022) * (1.0 - exp(-t / 0.002))
                val v = sin(bPh[i]) * env * bAmp[i]
                ol += v * (1.0 - bPan[i])
                orr += v * bPan[i]
                bT[i] = t + dt
                if (t > 0.12) bOn[i] = false
            }
        }
        out[0] = ol
        out[1] = orr
    }

    private companion object {
        const val BUBBLES = 6
    }
}

/**
 * "8D audio": the voice travels around the listener's head. Left/right balance follows the circle,
 * the far ear hears it a little later and darker (head shadow), and the sound is a little duller when
 * it passes behind. [a] is how wide the circle is (0..1), [s] is the spin speed (a lap takes 14 s at
 * 0 and 3 s at 1).
 */
class RevolveEffect(private val fs: Int, private val a: Double, s: Double) : StereoEffect {
    private val inc = TWO_PI / (lerp(14.0, 3.0, s) * fs)
    private var theta = 0.0
    private val tau = 0.00066 * fs
    private val dly = DelayLine(tau.toInt() + 8)
    private var yl = 0.0
    private var yr = 0.0
    private var bl = 0.0
    private var br = 0.0
    private var kl = 1.0
    private var kr = 1.0
    private var kb = 1.0
    private var dl = 2.0
    private var dr = 2.0
    private var gl = 0.707
    private var gr = 0.707
    private var bgain = 1.0
    private var count = 0
    private val rev = Reverb(fs, 0.5, 0.5, 0.12 + 0.20 * a, 6.0)
    private val wet = DoubleArray(2)

    private fun control() {
        val sn = sin(theta)
        val cs = cos(theta)
        val pan = sn * (0.4 + 0.6 * a)
        val ang = (pan + 1.0) * PI / 4.0
        gl = cos(ang)
        gr = sin(ang)
        dl = 2.0 + tau * max(0.0, sn) * a
        dr = 2.0 + tau * max(0.0, -sn) * a
        val farL = max(0.0, sn) * a
        val farR = max(0.0, -sn) * a
        val fcl = 20000.0 * (2500.0 / 20000.0).pow(farL)
        val fcr = 20000.0 * (2500.0 / 20000.0).pow(farR)
        kl = 1.0 - exp(-TWO_PI * min(fcl, fs * 0.45) / fs)
        kr = 1.0 - exp(-TWO_PI * min(fcr, fs * 0.45) / fs)
        val back = max(0.0, -cs) * a
        val fcb = 20000.0 * (5500.0 / 20000.0).pow(back)
        kb = 1.0 - exp(-TWO_PI * min(fcb, fs * 0.45) / fs)
        bgain = 1.0 - 0.2 * back
    }

    override fun process(l: Double, r: Double, out: DoubleArray) {
        if (count == 0) control()
        count = (count + 1) % CONTROL
        theta += inc
        if (theta > TWO_PI) theta -= TWO_PI
        val x = (l + r) * 0.5
        dly.write(x)
        val el = dly.read(dl)
        val er = dly.read(dr)
        yl += kl * (el - yl)
        yr += kr * (er - yr)
        bl += kb * (yl - bl)
        br += kb * (yr - br)
        val ol = bl * gl * bgain * MAKEUP
        val orr = br * gr * bgain * MAKEUP
        rev.process(ol, orr, wet)
        out[0] = ol + wet[0]
        out[1] = orr + wet[1]
    }

    private companion object {
        const val CONTROL = 32
        const val MAKEUP = 1.3
    }
}

/** Room / Hall / Cave: the voice plus its own reverb. [a] sets how much reverb (0..1). */
class ReverbEffect(fs: Int, roomSize: Double, damp: Double, wetMax: Double, predelayMs: Double, a: Double) : StereoEffect {
    private val rev = Reverb(fs, roomSize, damp, wetMax * (0.3 + 0.7 * a), predelayMs)
    private val wet = DoubleArray(2)

    override fun process(l: Double, r: Double, out: DoubleArray) {
        rev.process(l, r, wet)
        out[0] = l + wet[0]
        out[1] = r + wet[1]
    }
}

/** Ping-pong echo: 0.3 s between repeats, bouncing left/right, each repeat a little duller. */
class EchoEffect(fs: Int, a: Double) : StereoEffect {
    private val n = (0.30 * fs).toInt()
    private val dl = DelayLine(n + 4)
    private val dr = DelayLine(n + 4)
    private val fb = 0.25 + 0.40 * a
    private val wet = 0.30 + 0.40 * a
    private val lpl = OnePole(fs, 4000.0)
    private val lpr = OnePole(fs, 4000.0)

    override fun process(l: Double, r: Double, out: DoubleArray) {
        val el = dl.readInt(n)
        val er = dr.readInt(n)
        dl.write((l + r) * 0.5 + fb * lpr.process(er))
        dr.write(fb * lpl.process(el))
        out[0] = l + wet * el
        out[1] = r + wet * er
    }
}

/** Metallic robot: ring modulation at 50 Hz plus a very short comb. */
class RobotEffect(fs: Int, a: Double) : StereoEffect {
    private val m = 0.4 + 0.6 * a
    private val carrier = TWO_PI * 50.0 / fs
    private var ph = 0.0
    private val n = (0.004 * fs).toInt()
    private val cg = 0.55 * a
    private val dly = DelayLine(n + 4)

    override fun process(l: Double, r: Double, out: DoubleArray) {
        val x = (l + r) * 0.5
        ph += carrier
        if (ph > TWO_PI) ph -= TWO_PI
        var y = x * (1.0 - m) + x * sin(ph) * m * 1.4
        dly.write(y)
        y += cg * dly.readInt(n)
        out[0] = y
        out[1] = y
    }
}

/** Telephone and megaphone: narrow the band, then push the voice into soft clipping. */
class BandEffect(fs: Int, a: Double, megaphone: Boolean) : StereoEffect {
    private val drive: Double
    private val outGain: Double
    private val slap: Int
    private val hp0: Biquad
    private val hp1: Biquad
    private val lp0: Biquad
    private val lp1: Biquad
    private val dly: DelayLine

    init {
        val hpFreq: Double
        val lpFreq: Double
        if (!megaphone) {
            hpFreq = 120.0 + 230.0 * a
            lpFreq = 7000.0 - 3800.0 * a
            drive = 1.0 + 0.6 * a
            outGain = 1.35
            slap = 0
        } else {
            hpFreq = 250.0 + 300.0 * a
            lpFreq = 6500.0 - 2500.0 * a
            drive = 1.5 + 2.5 * a
            outGain = 1.7 + 0.9 * a
            slap = (0.045 * fs).toInt()
        }
        hp0 = Biquad().highpass(fs, hpFreq, 0.8)
        hp1 = Biquad().highpass(fs, hpFreq, 0.8)
        lp0 = Biquad().lowpass(fs, lpFreq, 0.8)
        lp1 = Biquad().lowpass(fs, lpFreq, 0.8)
        dly = DelayLine(slap + 4)
    }

    override fun process(l: Double, r: Double, out: DoubleArray) {
        val x = (l + r) * 0.5
        var y = lp1.process(lp0.process(hp1.process(hp0.process(x))))
        y = tanh(drive * y) / max(drive, 1.0) * outGain
        if (slap > 0) {
            dly.write(y)
            y += 0.25 * dly.readInt(slap)
        }
        out[0] = y
        out[1] = y
    }
}

/**
 * Whisper: a noise vocoder. The voice is split into 14 bands; each band's loudness shapes a band of
 * random noise, so the words stay but the pitch disappears. [a] mixes how much of the original stays.
 */
class WhisperEffect(private val fs: Int, private val a: Double, seed: Int) : StereoEffect {
    private val rng = Rng(seed)
    private val wet = 0.35 + 0.65 * a
    private val dry = (1.0 - wet) * 0.5
    private val ana = ArrayList<Biquad>()
    private val syn = ArrayList<Biquad>()
    private val env = DoubleArray(BANDS)
    private val norm = DoubleArray(BANDS)
    private val kEnv = 1.0 - exp(-TWO_PI * 40.0 / fs)

    init {
        val cal = Rng(0xCAFE)
        for (i in 0 until BANDS) {
            val fc = 150.0 * (9000.0 / 150.0).pow(i.toDouble() / (BANDS - 1))
            ana.add(Biquad().bandpass(fs, fc, 3.2))
            syn.add(Biquad().bandpass(fs, fc, 3.2))
            val probe = Biquad().bandpass(fs, fc, 3.2)
            var acc = 0.0
            for (j in 0 until 8192) {
                val v = probe.process(cal.next())
                acc += v * v
            }
            val rms = Math.sqrt(acc / 8192)
            norm[i] = 1.0 / (0.8 * max(rms, 1e-6))
        }
    }

    override fun process(l: Double, r: Double, out: DoubleArray) {
        val x = (l + r) * 0.5
        val noise = rng.next()
        var acc = 0.0
        for (i in 0 until BANDS) {
            val band = ana[i].process(x)
            env[i] += kEnv * (abs(band) - env[i])
            acc += syn[i].process(noise) * norm[i] * env[i]
        }
        val y = (acc * wet + x * dry) * (0.95 - 0.20 * a)
        out[0] = y
        out[1] = y
    }

    private companion object {
        const val BANDS = 14
    }
}

/** Builds the effect for [effect]; null for [VoiceEffect.NONE]. */
fun makeEffect(fs: Int, effect: VoiceEffect, amount: Double, speed: Double, seed: Int): StereoEffect? {
    val a = amount.coerceIn(0.0, 1.0)
    val s = speed.coerceIn(0.0, 1.0)
    return when (effect) {
        VoiceEffect.NONE -> null
        VoiceEffect.AQUA -> AquaEffect(fs, a, s, mixSeed(0xA11CE5, seed))
        VoiceEffect.REVOLVE -> RevolveEffect(fs, a, s)
        VoiceEffect.ROOM -> ReverbEffect(fs, 0.35, 0.50, 0.6, 8.0, a)
        VoiceEffect.HALL -> ReverbEffect(fs, 0.78, 0.35, 0.8, 20.0, a)
        VoiceEffect.CAVE -> ReverbEffect(fs, 0.92, 0.55, 0.8, 35.0, a)
        VoiceEffect.ECHO -> EchoEffect(fs, a)
        VoiceEffect.ROBOT -> RobotEffect(fs, a)
        VoiceEffect.TELEPHONE -> BandEffect(fs, a, false)
        VoiceEffect.MEGAPHONE -> BandEffect(fs, a, true)
        VoiceEffect.WHISPER -> WhisperEffect(fs, a, mixSeed(0x57415349, seed))
    }
}
