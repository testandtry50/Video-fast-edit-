package com.videoslidemaker.app.model

/**
 * NEW (2.16): the rule behind the Match screen's "Auto-match" button - putting the photos on the sentences by itself.
 *
 * Photo 1 of the photo list goes on the EARLIEST sentence, photo 2 on the next sentence in time, photo 3 on the one
 * after that, and so on: the photos are used in the order they stand in the pool, the sentences in the order of time.
 * One photo goes on one sentence; sentences beyond the number of photos stay empty. Adding more photos and choosing
 * "Fill empty only" carries on from the next empty sentence.
 *
 * This is plain Kotlin on ids and times (no Android classes), so it can be tested on its own. The caller
 * ([com.videoslidemaker.app.viewmodel.AppViewModel.autoMatchPhotos]) turns the answer into one undoable change.
 */
object AutoMatch {

    /** What an auto-match does (or did), with the counts the screen reports. */
    data class Result(
        /** The photo id for every sentence, in the same order the sentences were given in (null = no photo). */
        val assignments: List<String?>,
        /** True when every sentence was re-matched from scratch; false when only the empty ones were filled. */
        val replaced: Boolean,
        /** How many sentences have a different photo than before. */
        val changed: Int,
        /** How many sentences now have a photo. */
        val withPhoto: Int,
        /** How many sentences have no photo of their own. */
        val withoutPhoto: Int,
        /** How many openable photos of the pool no sentence uses. */
        val unusedPhotos: Int,
        /** The photos of the pool that cannot be opened, in pool order. This never puts one of them on a sentence. */
        val brokenIds: List<String> = emptyList()
    ) {
        /**
         * One short, plain sentence or two for the screen.
         *
         * @param brokenNames the file names of the photos in [brokenIds], so the person knows which ones to add again.
         */
        fun message(brokenNames: List<String> = emptyList()): String {
            val broken = brokenWarning(brokenNames)
            if (changed == 0) {
                val same = when {
                    brokenIds.isNotEmpty() -> "Nothing changed."
                    replaced -> "Nothing changed - the photos are already matched in this order."
                    withoutPhoto == 0 -> "Nothing changed - no sentence was without a photo."
                    else -> "Nothing changed - there are no unused photos left for the sentences that have none."
                }
                return same + broken
            }
            val sentences = assignments.size
            val text = StringBuilder("Done - $withPhoto of $sentences sentences now have a photo, matched in order.")
            if (withoutPhoto > 0) {
                text.append(if (withoutPhoto == 1) " 1 sentence has no photo" else " $withoutPhoto sentences have no photo")
                text.append(if (brokenIds.isEmpty()) " (not enough photos)." else ".")
            }
            if (unusedPhotos > 0) {
                text.append(if (unusedPhotos == 1) " 1 photo was not used" else " $unusedPhotos photos were not used")
                text.append(" (more photos than sentences).")
            }
            return text.toString() + broken
        }

        private fun brokenWarning(names: List<String>): String {
            val count = brokenIds.size
            if (count == 0) return ""
            val listed = names.take(MAX_NAMES).joinToString(", ")
            val more = if (names.size > MAX_NAMES) " and ${names.size - MAX_NAMES} more" else ""
            val which = if (listed.isEmpty()) "" else ": $listed$more"
            val what = if (count == 1) "1 photo can't be opened" else "$count photos can't be opened"
            return "\n\n$what$which. Remove and add again on the Photos step (adding a whole folder is safest)."
        }
    }

    private const val MAX_NAMES = 5

    /**
     * @param times the start time of every sentence, in the order the sentences are kept in.
     * @param current the photo each of those sentences has now (null = none), the same length as [times].
     * @param poolIds the photo ids in pool order.
     * @param replaceExisting true: start over - the first photo goes on the earliest sentence, and so on; sentences
     *   beyond the number of photos end up with none. false: keep every match that is already there and give the
     *   photos that no sentence uses yet (in pool order) to the sentences that have none (in time order).
     * @param unopenable photos that cannot be opened. They are never placed (they would show as blank pictures).
     *   Starting over, such a photo's sentence stays empty so the others do not shift. Filling, matches that are
     *   already there are left alone, so new photos carry on after them.
     */
    fun plan(
        times: List<Double>,
        current: List<String?>,
        poolIds: List<String>,
        replaceExisting: Boolean,
        unopenable: Set<String> = emptySet()
    ): Result {
        val n = minOf(times.size, current.size)
        val out = ArrayList<String?>(n)
        for (i in 0 until n) out.add(current[i])
        val usable = poolIds.filter { it !in unopenable }

        // Nothing to place, or nothing to place it on: leave every match exactly as it is (never wipe them).
        if (n > 0 && usable.isNotEmpty()) {
            // Sentence positions, earliest first. A stable sort: sentences with the very same time keep their list order.
            val inTimeOrder = (0 until n).sortedBy { times[it] }
            if (replaceExisting) {
                for ((k, at) in inTimeOrder.withIndex()) out[at] = poolIds.getOrNull(k)?.takeIf { it !in unopenable }
            } else {
                val inPool = poolIds.toHashSet()
                val used = HashSet<String>()
                for (i in 0 until n) {
                    val id = out[i]
                    // a match to a photo that is no longer in the pool counts as no match
                    if (id != null && id in inPool) used.add(id) else out[i] = null
                }
                var next = 0
                for (at in inTimeOrder) {
                    if (out[at] != null) continue
                    while (next < usable.size && usable[next] in used) next++
                    if (next >= usable.size) break
                    out[at] = usable[next]
                    used.add(usable[next])
                    next++
                }
            }
        }

        var changed = 0
        var withPhoto = 0
        val usedNow = HashSet<String>()
        for (i in 0 until n) {
            if (out[i] != current[i]) changed++
            out[i]?.let { withPhoto++; usedNow.add(it) }
        }
        return Result(
            assignments = out,
            replaced = replaceExisting,
            changed = changed,
            withPhoto = withPhoto,
            withoutPhoto = n - withPhoto,
            unusedPhotos = usable.count { it !in usedNow },
            brokenIds = poolIds.filter { it in unopenable }
        )
    }
}
