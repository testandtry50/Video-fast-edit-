package com.videoslidemaker.app.model

/**
 * NEW (2.16): the rule behind the Match screen's "Auto-match" button - putting the photos on the sentences by itself.
 *
 * Photo 1 of the photo list goes on the EARLIEST sentence, photo 2 on the next sentence in time, photo 3 on the one
 * after that, and so on: the photos are used in the order they stand in the pool, the sentences in the order of time.
 *
 * This is plain Kotlin on ids and times (no Android classes), so it can be tested on its own. The caller
 * ([com.videoslidemaker.app.viewmodel.AppViewModel.autoMatchPhotos]) turns the answer into one undoable change.
 */
object AutoMatch {

    /** What an auto-match does (or did), with the counts the screen reports. */
    data class Result(
        /** The photo id for every sentence, in the same order the sentences were given in (null = no photo). */
        val assignments: List<String?>,
        /** True when every sentence was re-matched from scratch; false when only the empty ones were filled. */
        val replaced: Boolean,
        /** How many sentences have a different photo than before. */
        val changed: Int,
        /** How many sentences now have a photo. */
        val withPhoto: Int,
        /** How many sentences have no photo of their own. */
        val withoutPhoto: Int,
        /** How many photos of the pool no sentence uses. */
        val unusedPhotos: Int
    ) {
        /** One short, plain sentence or two for the screen. */
        fun message(): String {
            if (changed == 0) {
                return when {
                    replaced -> "Nothing changed - the photos are already matched in this order."
                    withoutPhoto == 0 -> "Nothing changed - no sentence was without a photo."
                    else -> "Nothing changed - there are no unused photos left for the sentences that have none."
                }
            }
            val sentences = assignments.size
            val text = StringBuilder("Done - $withPhoto of $sentences sentences now have a photo, matched in order.")
            if (withoutPhoto > 0) {
                text.append(if (withoutPhoto == 1) " 1 sentence has no photo" else " $withoutPhoto sentences have no photo")
                text.append(" (not enough photos).")
            }
            if (unusedPhotos > 0) {
                text.append(if (unusedPhotos == 1) " 1 photo was not used" else " $unusedPhotos photos were not used")
                text.append(" (more photos than sentences).")
            }
            return text.toString()
        }
    }

    /**
     * @param times the start time of every sentence, in the order the sentences are kept in.
     * @param current the photo each of those sentences has now (null = none), the same length as [times].
     * @param poolIds the photo ids in pool order.
     * @param replaceExisting true: start over - the first photo goes on the earliest sentence, and so on; sentences
     *   beyond the number of photos end up with none. false: keep every match that is already there and give the
     *   photos that no sentence uses yet (in pool order) to the sentences that have none (in time order).
     */
    fun plan(times: List<Double>, current: List<String?>, poolIds: List<String>, replaceExisting: Boolean): Result {
        val n = minOf(times.size, current.size)
        val out = ArrayList<String?>(n)
        for (i in 0 until n) out.add(current[i])

        // Nothing to place, or nothing to place it on: leave every match exactly as it is (never wipe them).
        if (n > 0 && poolIds.isNotEmpty()) {
            // Sentence positions, earliest first. A stable sort: sentences with the very same time keep their list order.
            val inTimeOrder = (0 until n).sortedBy { times[it] }
            if (replaceExisting) {
                for ((k, at) in inTimeOrder.withIndex()) out[at] = poolIds.getOrNull(k)
            } else {
                val inPool = poolIds.toHashSet()
                val used = HashSet<String>()
                for (i in 0 until n) {
                    val id = out[i]
                    // a match to a photo that is no longer in the pool counts as no match
                    if (id != null && id in inPool) used.add(id) else out[i] = null
                }
                var next = 0
                for (at in inTimeOrder) {
                    if (out[at] != null) continue
                    while (next < poolIds.size && poolIds[next] in used) next++
                    if (next >= poolIds.size) break
                    out[at] = poolIds[next]
                    used.add(poolIds[next])
                    next++
                }
            }
        }

        var changed = 0
        var withPhoto = 0
        val usedNow = HashSet<String>()
        for (i in 0 until n) {
            if (out[i] != current[i]) changed++
            out[i]?.let { withPhoto++; usedNow.add(it) }
        }
        return Result(
            assignments = out,
            replaced = replaceExisting,
            changed = changed,
            withPhoto = withPhoto,
            withoutPhoto = n - withPhoto,
            unusedPhotos = poolIds.count { it !in usedNow }
        )
    }
}
