plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.videoslidemaker.app"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.videoslidemaker.app"
        minSdk = 26
        // Google Play has required new apps AND updates to target Android 16 (API 36) since 31 Aug 2026.
        targetSdk = 36
        // Every upload to Google Play needs a HIGHER versionCode than the one before it.
        versionCode = 30
        versionName = "2.9.1"
        vectorDrawables.useSupportLibrary = true
    }

    // Signing for the Play Store. The key is NEVER stored in the project: it is read from the environment (GitHub
    // secrets in the workflow, or your own shell / ~/.gradle/gradle.properties). Without it a release build is simply
    // unsigned, and debug builds are not affected. See PLAY_STORE_CHECKLIST.md.
    val keystorePath: String? = System.getenv("KEYSTORE_PATH") ?: (project.findProperty("KEYSTORE_PATH") as String?)
    val releaseKeyReady = keystorePath != null && file(keystorePath).exists()
    signingConfigs {
        if (releaseKeyReady) {
            create("release") {
                storeFile = file(keystorePath!!)
                storePassword = System.getenv("KEYSTORE_PASSWORD") ?: (project.findProperty("KEYSTORE_PASSWORD") as String?)
                keyAlias = System.getenv("KEY_ALIAS") ?: (project.findProperty("KEY_ALIAS") as String?)
                keyPassword = System.getenv("KEY_PASSWORD") ?: (project.findProperty("KEY_PASSWORD") as String?)
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            if (releaseKeyReady) signingConfig = signingConfigs.getByName("release")
        }
        debug {
            isMinifyEnabled = false
            applicationIdSuffix = ".debug"
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }
    kotlinOptions {
        jvmTarget = "1.8"
    }
    buildFeatures {
        compose = true
    }
    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.14"
    }
    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.4")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.4")
    implementation("androidx.activity:activity-compose:1.9.1")

    implementation(platform("androidx.compose:compose-bom:2024.09.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.animation:animation")

    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")

    // Handles efficient decoding/downsampling/memory-caching of photos from content:// Uris
    // for on-screen thumbnails — the export pipeline itself decodes bitmaps separately via
    // ImageStore, since it needs raw pixel access rather than a displayable composable.
    implementation("io.coil-kt:coil-compose:2.6.0")

    debugImplementation("androidx.compose.ui:ui-tooling")

    // Unit tests for the timestamp parser (app/src/test) — run with ./gradlew testDebugUnitTest.
    testImplementation("junit:junit:4.13.2")
}
