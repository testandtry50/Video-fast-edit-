# VideoSlide Maker — Native Android

A full native Android (Kotlin + Jetpack Compose) rewrite of the original web app. It keeps
every feature of the original 5-step wizard (Script → Photos → Match → Preview → Export),
fixes the two things that don't scale well in a browser tab (large photo files, and audio),
and adds a few genuinely new capabilities on top.

## NEW in 2.9.1: calmer light theme, a true neutral dark theme, and an easier first screen

- **Calm light theme.** The page is a warm off-white "paper" colour, the cards are a shade lighter (no pure `#FFFFFF`), and the text is soft charcoal (no pure black). Big bright-white areas are what tire the eyes, so there are none. Text still passes WCAG contrast (about 12:1 for main text).
- **Proper dark theme, no purple.** Charcoal greys with equal red, green and blue (no tint), soft off-white text instead of glaring white, three close grey steps for page / bars / cards. The Violet accent was removed; the accents are now Blue, Teal, Green, Orange and Rose. The last purple leftovers (launcher icon background, text-overlay preview backdrop, unset Material dialog colours) are gone too. `ThemeContrastTest` now also fails the build if a purple accent, a pure-white light page, or a tinted dark grey comes back.
- **Easier first screen.** It is now called *Start your video*. The script file is clearly optional (the "no script yet" note is a calm info chip, not a yellow warning), and the long *Settings* and *How to write a script* cards fold away - the settings card still shows a one-line summary (seconds per photo, shape, resolution, sound), so the page is short and the main button is in view.
- **Steps that are not ready say so.** Text, Preview and Export need at least one photo. Their tabs are dimmed until you add one, and tapping one tells you why (before, the tap silently did nothing).
- **Icons instead of emoji** on the main path (upload boxes, folder button, export buttons, status chips) so they look the same on every phone. New shared pieces in `CommonComponents.kt`: `CollapsibleCard`, and optional `icon` on `PrimaryButton`, `SecondaryButton` and `BadgeChip`.
- **Fixed a wrong label:** with no script, Photos said "Next - Preview" but went to the Text step. It now says "Next - Add Text". After an export the repeat button says "Export it again" (it re-runs the same export, not a new project).

## NEW in 2.9: Remove or blur subtitles and text too - in one segment, a range, or all of them (and ready for Google Play)

The cleaner that removed or blurred a **logo** now also removes or blurs a **subtitle**, any other **text**, or an
**icon** - and you choose how much of the video it touches: **this one segment**, **a range of segments**, or **all of them**.

**Where.** Photos screen: *Remove or blur a logo, icon, subtitle or text*. Match screen (new): the same button, which opens on
the segment you were looking at, with its time and sentence, and counts *segments* (lines of your script), not photos.

**What to clean** - three buttons:

| | How it finds the thing | Best for |
|---|---|---|
| **Logo / icon** | what repeats across your photos (as in 2.3 / 2.4: *Find the logo automatically*, *One tap*) | watermarks, channel logos, app icons |
| **Subtitle** | photo by photo, inside the box you drag (it starts as a strip near the bottom) | burned-in captions, in any language - tested on Latin and Hindi |
| **Other text** | photo by photo, inside the box you drag | titles, names, numbers, phone numbers |

A subtitle is different in every photo, so there is nothing to compare across photos. Instead the cleaner looks at every
photo on its own for what text looks like: thin strokes much brighter or darker than what is around them, flat in colour, many
of them side by side along a line. **Only the letters are repainted** (Remove) or smudged (Blur) - not the whole box - so
the picture around a caption stays sharp. **Remove + Blur** works as before.

**Find a segment's photo in the photo list (Match screen).** In the *All segments* strip, **tap a segment to jump to it** (instant,
as before) and **tap it twice quickly to find its photo**: the photo list below scrolls to that photo, the page scrolls so the list is
on screen, and the photo is shown with a yellow border and a "📍 Found it" tag for a few seconds, with a line saying *"Segment 5's
photo is photo 1,234 of 100,000"*. It finds the photo the video really shows for that segment (your own pick, or the one that covers
it). With a screen reader the same thing is in the card's actions menu (*Find this photo in the photo list*).

**Where to clean** - three buttons: *This segment*, *A range* (type the numbers, or press *Start here* / *End here* while paging
with Previous / Next, or *To the last*), *All*. For text there are two ways to look:
* **Only where text is found** (default): photos where the box does not hold a caption (the caption is not on screen at that
  moment) are left untouched.
* **Everywhere in the box (no checking)**: short and faint captions too. A photo with no caption can then get a small smudge,
  so check a few photos afterwards.

**Logo and subtitle on the same photo.** Cleaning a second thing now goes on top of the first (before, starting again from the
original would have brought the logo back). Each photo shows what was done: *"✔ logo removed · subtitle blurred"*.
Cleaning the *same* thing again still starts from the original, so a redo never stacks. *Restore* returns the original;
there is now also *Restore the range*.

### How well does the text finder work? (measured, not guessed)

Designed and run first in Python (`tools/textclean-reference/`), then ported to Kotlin; the unit tests assert the same numbers.
Test frames are made with known text (so the true answer is known), half of them JPEG-compressed and slightly softened like real video
frames, on fresh random seeds that were not used to tune the thresholds:

| | result |
|---|---|
| Captions of 3-8 words, 6 styles (white + outline, yellow + outline, shadow, plain, dark-on-light, on a strip), Latin and Hindi, 30-80 px, on faces, scenes, plain walls, real photographs, fine stripes | **90 %** found by *Only where text is found*; about **96 %** by *Everywhere in the box*. The misses are mostly plain white text with no outline (61 % found) and text over fine stripes (81 %) - there is little contrast to find |
| Letter pixels that end up inside the mask | **99.1 %** |
| Mask size compared with the text itself | **1.7x** (so the repaint stays local: everything else in the box is untouched) |
| Short 1-2 word captions ("Yes.", "No way!") | **85 %** with *Only where text is found*, a little more with *Everywhere in the box* |
| Boxes with **no text** (552 hard ones: faces, fur, grass, gravel, bricks, stars, stripes) wrongly treated as text | **0 / 552** with *Only where text is found*; **5.8 %** with *Everywhere in the box* |
| Repair, around the letters (PSNR against the true background; about 8 dB if left alone) | repaired to **29.7 dB** on your kind of frame (25.9 dB if the whole box were filled instead), 30.3 dB on scenes, 35.1 dB on a plain wall (36.6 dB for a box fill - a wall is easy either way), 24.5 dB on real photographs, 18.9 dB on very busy ones. In short: about as good as filling the whole box where the picture is smooth, better where it is not, and it never touches pixels away from the letters |

Before / after on your own sample frame and on a Hindi caption: `tools/textclean-reference/sample/text_cleaner_before_after.png`.
Re-run everything: `cd tools/textclean-reference && python3 evaluate.py` (about 15 minutes), `python3 mirror_scenarios.py`,
`python3 kotlin_transliteration_check.py`, `python3 demo.py`.

**Honest limits.** Text on a dark or light *strip* behind it: the letters go but the strip stays (use *Logo / icon* with
*Exact spot* to remove the strip itself). A one-word caption may be missed in the default mode. Very busy backgrounds
(leaves, crowds) with white text and no outline are hard for any non-AI method. Text that moves or zooms inside one photo is
not followed. It does not read the text (no OCR), it only knows what text looks like.

### Ready for Google Play

Google Play has required new apps **and updates** to target Android 16 (API 36) since 31 Aug 2026. The project now does:
`targetSdk`/`compileSdk` 36, Android Gradle plugin 8.9.1 + Gradle 8.11.1, edge-to-edge screens (Android 15+ always draws apps behind
the status and navigation bars), the Android 15 foreground-service time limit (a long cleaning run now stops cleanly and says
*"press the button again to continue"* instead of crashing the app), predictive back, release signing from the environment and a
signed `.aab` in the GitHub workflow. **Everything you still have to do yourself (upload key, Play Console forms, device test list)
is in `PLAY_STORE_CHECKLIST.md`.** Version is now 2.9.0 (`versionCode` 29).

## NEW in 2.8: Preview at any speed (0.25x to 4x), the way viewers watch on YouTube

People watch YouTube faster and slower than the video was made. On the **Preview** screen, under the play
buttons, the new **⏩ Playback speed** card shows (and plays) your video that way, so you can see how the
photos, the name text and the sound come across at 0.5x, 2x, 3x ...

* **A speed button beside play/pause** shows the current speed; each tap goes to the next common one
  (0.5x -> 1x -> 1.5x -> 2x -> 3x, then round again), so you can change it while you keep your eyes on the picture.
* **One-tap speeds** in the card: 0.25x, 0.5x, 0.75x, 1x, 1.25x, 1.5x, 2x, 3x.
* **Every speed in between**: a slider from 0.25x to 4x (normal speed is in the middle, and every doubling is the same
  width, so slow and fast are equally easy to set) and small **-0.25 / -0.05 / +0.05 / +0.25** buttons.
* **Change it while it plays.** The sound restarts at the same spot at the new speed a moment after you stop moving the
  slider (the voice-changer sliders work the same way). With the sound off there is nothing to restart, so the pictures
  change speed at once.
* **What you hear**: the phone's voice speaks faster or slower; your own recording plays faster or slower **with the same
  pitch** (a voice at 2x is quick, not a chipmunk); with the voice changer on, the changed voice or recording is sped up
  or slowed down the same way.
* **What you see**: the zoom/pan, the name texts and the fades all follow the speed (a 0.35 s crossfade lasts about
  0.18 s at 2x and 0.7 s at 0.5x, exactly as it does when a viewer changes the speed). A **"2x"** badge sits on the
  picture whenever the speed is not normal. More photos are loaded ahead when slides fly by faster.
* **What it means for THIS video**: *Watch time at 2x: 3:10 (normal: 6:20)*, *Shortest photo on screen: 0.4 s*, and a
  warning when speeding up makes photos stay up for **under 1 second** (it also says how many already were at normal
  speed), so you can find the slides a fast viewer would miss.
* **Only the preview changes.** The exported video is always normal speed (viewers pick their own on YouTube). The speed
  is a viewing choice: it is not saved with the project and it is not an Undo step. "Hear a sample" in the voice changer
  always plays at normal speed.

Code: `model/PreviewSpeed.kt` (the maths: steps, slider, labels, watch time, fall-backs), `ui/screens/PreviewSpeedPanel.kt`
(the card), `align/PlaybackSpeed.kt` (asks Android to change the speed and keep the pitch), and small changes to
`AppViewModel` (the preview clock now runs at the chosen speed and starts the sound at that speed),
`PreviewRecordingPlayer`, `FxRecordingPlayer`, `PcmClipPlayer` and `PreviewScreen`. At 1x nothing changes from 2.7: the
recording player is not touched at all, and the clock maths is the same.

How the picture stays with the sound: the preview's clock moves `speed` seconds for every real second, and the sound is
started at that same speed. Your own recording is still the master clock (its position is checked ten times a second and
the photos are pulled back if they drift; the allowed drift is widened with the speed so it is still 0.12 s of what you
see). If a phone refuses a speed, the sound reports the speed it really has, the photos follow that, and the card moves to
it and says so.

Tests: `PreviewSpeedTest.kt` (speeds, slider round trip for every 0.05 step, labels, watch time, quick-photo counts,
fall-backs, voice rate, fade lengths). The same checks run in Python: `python3 tools/previewspeed-reference/run_tests.py`.

Honest limits:

* As with the rest of this project, the Kotlin has **not been compiled or run** where it was written. The first `Build`
  on GitHub (or in Android Studio) is the first real compile, and it runs `PreviewSpeedTest`.
* **Phones differ.** Android's sound speed-up is built into the phone and some phones accept only part of the range (a few
  stop at 2x). The app asks the phone to refuse what it can't do (instead of going silent) and then falls back towards
  normal speed - see the note under the card.
* **The phone's own voice has a speed limit.** Without the voice changer, the voice reads at (your voice speed x the preview
  speed) and the phone's speech engine decides how fast it can go. Above about 2x sentences can run late or get cut off
  when the next photo arrives. That is the preview only. (A changed voice is time-stretched instead, which works to 4x.)
* **Voice changer + your recording, at a speed other than 1x:** the photos follow the clock instead of the sound's own
  position (the position of a time-stretched sound is not relied on). They stay together unless the phone cannot keep up -
  the voice effects have to be calculated 2-4 times faster than real time, which a slow phone may not manage and the
  sound then stutters. If it ever drifts, press pause and play (or drag the bar) and it lines up again.
* Android's speed-up is good for speech but not perfect: at 3x-4x words get a little smeared. It shows the idea of how
  your video feels at that speed; it is not a copy of YouTube's own processing.

## NEW in 2.4: Remove + Blur, and "Clean ALL photos at once" for 100,000+ photos

In the logo cleaner (Photos screen, **🧽 Remove or blur a logo / watermark**):

* **Three modes** - **Remove**, **Blur**, and the new **Remove + Blur**: the logo is painted out first, then only the
  repaired spot is softly blurred (much gentler than plain Blur) so no seam, edge or faint patch is left. The strength
  slider applies to Blur and to Remove + Blur. Works for one photo, for all photos, and with "One tap".
* **Clean ALL photos at once** - built for very large projects. Pick *Where the logo is found* / *Even if the logo
  moves* / *Exact spot, no checking (fastest)*, then press **Clean ALL**. While it runs a card stays pinned at the top
  of the screen with the **percent done**, `done of total`, photos per second, **time left**, and live counts of
  cleaned / no logo / failed. Also shown as a progress notification.
* **⚡ One tap: find the logo + clean ALL** - scans for the logo that repeats, then cleans every photo that has it.
* **Stop and carry on later** - Stop keeps everything already cleaned. With **Skip photos that are already cleaned**
  on (default) pressing the button again continues where it stopped. Turn it off to redo everything with a new box.
* Runs of 500+ photos ask for a yes first and show the storage they will use. **Restore ALL** also shows progress.

How it copes with 100,000+ photos (what changed under the hood, `logoclean/LogoCleanController.kt`):

* Up to 4 photos are repainted at the same time (fewer on phones with little memory - `BulkMath.workerCount`).
* Finished photos are handed to the app in **batches** (every 1.5-10 s). Before, the whole photo list was rebuilt after
  every single photo, which is 100,000 x 100,000 steps - that alone made big runs unusable.
* `LogoCleanService` (foreground service + wake lock) keeps the run going with the screen off or another app open.
* Storage is checked before starting and while running (a cleaned copy of each photo is saved: roughly 0.6 MB per
  1080p frame, so 100,000 frames is about 60 GB). Bulk copies are saved at JPEG quality 90 (single photo: 95).
  If storage runs out the run stops cleanly instead of failing thousands of photos.
* Honest limit: speed depends on the phone and the photo size - the card shows the real speed and time left after
  a few seconds. Very large runs are hours, not minutes. Keep the phone charging, and do not swipe the app away from
  the recent-apps list while a run is going (pressing Home is fine).

Tests: `BulkMathTest.kt` (percent, time left, worker count, storage estimate) and three new cases in `LogoCleanTest.kt`
(Remove + Blur removes the logo, touches nothing far away, and is softer than Remove alone).

## NEW in 2.3: Logo & watermark cleaner (remove or blur just a small logo)

On the **Photos** screen, **🧽 Remove or blur a logo / watermark** opens a screen with one photo and a box.
Put the box over the logo (drag it, drag a corner to resize, or drag on an empty spot to draw a new one) and
choose what happens to **only that spot**:

* **Remove** - paints the logo out from the picture around it (smooth fill + matching film grain, feathered in),
  so it looks like it was never there. Best on smooth or out-of-focus backgrounds. A hard edge running straight
  through the logo gets softened - use Blur there.
* **Blur** - blurs just the logo (strength slider) so it can't be read; a soft smudge stays.
* **Find the logo automatically** - a watermark is the one thing at the *same place* in many photos, so the app
  stacks the edge maps of up to 40 photos of the same size and the edges that repeat are the logo. The box jumps
  onto it (up to 3 candidates, "in 100% of photos"). It needs at least 3 same-sized photos; otherwise drag the box by hand.
* **Clean this photo** / **Clean all photos where this logo is found** / **Clean ALL photos at this exact spot**.
  The "found" mode checks every photo for the logo and **leaves photos that don't have it untouched**.
  **The logo moves between photos** also looks for it elsewhere in each photo (follows a moving logo).
* Only the logo's own pixels are changed (its real shape, not a whole rectangle). Everything else in the
  photo is bit-for-bit identical.
* **Non-destructive:** your original photos are never modified. A cleaned copy is saved in the app's own folder and
  the photo points at it (so the Photos list, preview and export all use it); **Restore this photo / Restore ALL**
  switch back. Cleaning twice never stacks - it always starts again from the original. Cleaned copies are capped at
  4096 px on the long edge so a huge photo cannot run the phone out of memory.

Code: `app/src/main/java/com/videoslidemaker/app/logoclean/` (maths in `Imaging.kt`, detection and matching in
`LogoDetector.kt`, repainting in `LogoPaint.kt`, photo reading/writing in `LogoCleaner.kt`, the "clean all" logic
in `LogoCleanController.kt`; screen in `ui/components/LogoCleanerDialog.kt`).

It was designed and **measured first in Python** (`tools/logoclean-reference/`), then ported:

* `python3 demo.py` runs it on the bundled screenshot (`sample/before_after.png`): 0.72 % of the pixels change, all inside the logo.
* `python3 evaluate_matcher.py`: over 240 synthetic photos (real logo pasted on varied backgrounds) the "is the logo here?"
  check made 0 false positives and 0-2 % false negatives at the thresholds used.
* Removal beat OpenCV's Telea inpainting on every background type tested (32-36 dB vs 31-34 dB inside the repaired area).
* `python3 mirror_scenarios.py` produces the numbers that `LogoCleanTest.kt` asserts for the Kotlin code.

Honest limits: auto-detect assumes the logo sits at the same place in several photos of the same size (typical for
frames cut from one video). A busy, sharp background behind the logo cannot be reconstructed exactly - Remove then
looks smooth rather than perfect. As with the rest of this project, the Kotlin has **not been compiled** where it
was written; the first `Build` on GitHub (or in Android Studio) is the first real compile and test run.

## NEW in 2.2: Voice changer (pitch, "make it sound human", effects)

A **🎚️ Voice changer** card now appears on the **Script** screen and under the player on the **Preview**
screen (whenever sound is on). It works on **both** sounds - your own uploaded recording and the phone's
voice - in the preview and in the exported video. It never touches background music.

* **🎵 Pitch** - higher or lower **without changing the speed**, from -24 to +24 semitones in steps of
  0.01 (one cent). Choose how far the slider reaches (**Fine ±1**, ±3, ±12, ±24) so tiny changes and big
  changes are both easy; use the **-1 / -0.1 / -0.01 / +0.01 / +0.1 / +1** buttons; or type an exact value.
* **🧑 Make it sound human** - for AI voices (ElevenLabs etc.) that sound too clean: a tiny natural pitch
  drift, warmth, gentle dynamics, a faint room tone and small room reflections, plus optional soft **breaths**
  in real pauses. Try 40-60 %. It cannot fix robotic *delivery*; it removes the "too perfect" studio-clean sound.
* **🎭 Voice effects** - Aqua (underwater), Revolve 8D (circles around your head - use headphones), Room,
  Hall, Cave, Echo, Robot, Telephone, Megaphone, Whisper; each with a strength slider (Aqua and Revolve
  also have a speed slider).
* **▶ Hear a sample** plays about 8 seconds of your recording (or one sentence of the phone's voice) with the
  current settings. While the preview plays you can also move the sliders; the sound restarts at the same spot.

Notes: big pitch changes (beyond about ±4) also change the *character* of the voice (chipmunk / giant) because
the voice's tone shifts with the pitch. A stereo recording is mixed to one channel for processing (it is a voice
tool); the result is stereo again. With the voice changer **off**, nothing changes from 2.1.

The effect code lives in `app/src/main/java/com/videoslidemaker/app/voicefx/` and was designed and measured
in `tools/voicefx-reference/` (Python); `VoiceFxTest.kt` checks the Kotlin code against that reference.
As with the rest of this project, it has not been compiled in the place it was written - the first
`Build` run on GitHub (or Android Studio) is the first real compile.

## How to open and build this (with a computer)

1. Install **Android Studio** (Koala/2024.1 or newer).
2. `File → Open`, select the `VideoSlideMaker` folder, let Gradle sync (it will download the
   wrapper automatically — no network is available in the sandbox this was written in, so the
   wrapper jar itself isn't bundled, but Android Studio fetches it on first sync).
3. Run on a device/emulator with **Android 8.0 (API 26) or newer**.
4. If Android Studio suggests a newer Kotlin/AGP/Compose BOM version during sync, accepting the
   upgrade is safe — the versions pinned here are simply the ones current at the time of writing.
5. Optional cleanup: `Code → Optimize Imports` across the project removes a handful of harmless
   unused imports left over from earlier drafts of a few files.

I wrote and reviewed every file carefully, but I don't have an Android SDK or emulator in the
sandbox this was built in, so **this hasn't been compiled or run**. Treat it as a complete,
serious first build rather than a guaranteed zero-error one — if Android Studio flags anything
small (an import, a version mismatch), it'll point straight at the line.

## Building this with only an Android phone (no computer)

This project now includes `.github/workflows/build.yml`, which tells GitHub to compile the APK
on its own servers every time you push code — GitHub's machine does the compiling, not your
phone, so you never need Android Studio or the Android SDK on the device itself.

### 1. Get the unzipped project onto GitHub

GitHub's website doesn't unzip files you upload — you need to extract the folder first and
push it with `git`, which is easiest through a terminal app. **Termux** (a real Linux terminal
for Android) is the most reliable way to do this from just a phone:

1. Install **Termux** from F-Droid (not the outdated Play Store version): f-droid.org
2. Open Termux and run, one line at a time:
   ```
   termux-setup-storage
   pkg update -y
   pkg install -y git gh unzip
   cd ~/storage/downloads
   unzip VideoSlideMaker-Android.zip
   cd VideoSlideMaker
   git init && git add . && git commit -m "Initial commit"
   ```
3. Sign in to GitHub from the terminal (opens a browser to confirm — no typing passwords):
   ```
   gh auth login
   ```
   Choose **GitHub.com** → **HTTPS** → **Login with a web browser**, then follow the one-time
   code it shows you.
4. Create the repo and push everything in one command:
   ```
   gh repo create VideoSlideMaker --public --source=. --remote=origin --push
   ```
   (If that command errors, create an empty repo at github.com/new instead, then run
   `git remote add origin <the URL it gives you>` followed by `git push -u origin main`.)

A **public** repo is simplest — GitHub Actions is completely free and unlimited there. Private
repos also work and include 2,000 free build-minutes a month, more than enough for occasional
builds — just know the code stays visible to you only either way you choose the visibility.

### 2. Let GitHub build it

Once pushed, go to your repo on github.com → the **Actions** tab. You'll see "Build APK"
running (takes a few minutes). When it finishes with a green check, open that run and scroll to
**Artifacts** — download `VideoSlideMaker-debug-apk`. It downloads as a `.zip` (GitHub always
wraps artifacts that way); extract it with any file manager app to get the actual `.apk`.

### 3. Install it on your phone

Tap the `.apk` file. If Android blocks it, it'll offer a link to **Settings → allow installs
from this app** (usually your browser or file manager) — enable that once, then tap the file
again to install.

If a build fails, open the failed run in the Actions tab and check which step turned red — it
usually points straight at the problem (most often a version number Google has since bumped;
the fix is normally just updating that one number in `app/build.gradle.kts`).



1. **Script** — upload a `.txt` file of `timestamp - sentence` lines.
2. **Photos** — add a pool of photos, reorder, delete.
3. **Match** — go sentence by sentence, listen to it spoken aloud, split or merge sentences,
   and tap a photo to assign it.
4. **Preview** — play through the matched sequence at a faster preview speed.
5. **Export** — pick aspect ratio / resolution / zoom / fade, then render the real video.

Every one of these carried over — nothing was removed.

## Look, themes and accessibility

The app now has a proper **light** theme (calm, warm off-white, low glare) and a proper **dark**
theme. The old dark theme was tinted blue/purple; the new one is a true neutral charcoal (and
there is an optional pure-black version for OLED screens).

Two controls are always on screen, in the top bar:

- **Sun / moon button** - flips between light and dark in one tap.
- **Sliders button** - opens *Appearance & accessibility*, where you can set:
  - **Theme**: System (follows the phone), Light or Dark - plus *Pure black background*.
  - **Accent colour**: Blue (default), Teal, Green, Orange or Rose.
  - **Text size**: Default / Large / Larger / Largest, added *on top of* the phone's own font size.
  - **High contrast**: pure black/white text and stronger outlines on buttons and fields.

Everything applies instantly and is remembered (`ui/theme/Appearance.kt`).

Other usability changes that came with it:

- **System Back goes back one step** (it used to close the app mid-project), matching the on-screen "Back" buttons.
- **Photos, Preview and Export scroll properly.** Before, the Photos list shared a fixed-height column with the header and buttons and could shrink to almost nothing; Preview and Export could push their bottom buttons off-screen.
- **Bigger tap targets**: every button/control is at least 48dp; the photo row's arrows, delete, the +/- steppers and the remove buttons on thumbnails were 18-36dp before.
- **Not colour alone**: warnings/notes/success have an icon, finished steps show a tick, chosen options show a tick or thicker outline.
- **Screen readers (TalkBack)**: switches, tabs, chips and buttons announce their role and state, icon buttons have real names, and dragging the text label has "Move left/right/up/down" actions as an alternative.
- The text cursor is now visible in dark mode (it was black on near-black).
- **See a photo full size.** Photo tiles on the Match screen now show the *whole* picture (they used to crop it to a square, cutting off subtitles). Tap the magnifier on a tile, or press and hold it, to open the full-size viewer: pinch to zoom, drag to move, double-tap to zoom/reset, and a button to use that photo. Tapping the "Currently assigned" photo, or a thumbnail on the Photos screen, opens the same viewer (`ui/components/ImagePreviewDialog.kt`).
- **Browse all photos (fast picking).** On the Match screen, the **"Browse all photos — full size"** button opens a full-screen browser (`ui/components/PhotoBrowserDialog.kt`): photos are shown whole at their real shape (Large = 1 per row, Medium = 2, Small = 3), the sentence you are matching stays pinned at the top with arrows for previous/next sentence, tapping a photo uses it and the browser stays open (so with auto-advance on you can pick photo after photo), photos already placed are tagged "Used · #N", and **Unused only** hides them. The magnifier on a photo opens the pinch-to-zoom viewer.

How it works: screens never hard-code colours. `ui/theme/Color.kt` defines the palettes, and
`Accent`, `TextMain`, `CardBg`, `Outline`... resolve to whichever palette is active. To change a
colour, edit it there. `ThemeContrastTest` checks every theme/accent combination against WCAG
contrast ratios (4.5:1 for text, 3:1 for outlines), so a readability regression fails the build.

## Preview: smooth playback, and your original recording as the sound

**Sound choice.** On the Preview screen, under the play controls, pick what you hear with the photos:
**🔊 Voice** (the phone's text-to-speech reads each sentence), **🎧 Original** (your own recording), or
**🔇 Off**. The same choice is used by the exported video, and can also be changed on the Script screen
("Sound comes from"). The recording is the one chosen under *Automatic timestamp alignment* on the
Script screen (or on the Match screen); the Preview offers a button to choose it if none is set yet.

**How the original recording is kept in line with the photos.** The recording's clock is the script's
clock (a timestamp of 12.5 s means 12.5 s into the recording). While it plays, the recording's own
position is the master clock: the preview checks it ten times a second and, if the photos ever drift
more than 0.12 s away from what you hear, pulls them back. Pressing play, previous/next, or dragging
the new scrub bar all restart the recording at exactly that point, so you can jump to any sentence
and check that its photo appears when its words are spoken. In the export the recording is decoded in
small streaming pieces (so a multi-hour file does not fill memory), placed on the same clock, and
cut at the end of the video.

**Why the preview was choppy, and what changed.** The playing position used to live in the app's one
shared state and was updated 20 times a second, so every update redrew the whole app, and the zoom
could only move in 20 steps per second. Now: the position is kept separately and ticks once per
screen frame; only the photo layer (drawn with `graphicsLayer`), the clock text, the scrub bar and
the name labels read it, so nothing else is redrawn; the next two photos are loaded into memory ahead
of time (no blank flash at a cut); the outgoing photo keeps moving on its own time window while it
fades (it used to jump); and the text-to-speech voice is no longer re-initialised on every sentence
(that could stall the screen at each slide change).

## Timestamps

Timestamps can be typed in any of these styles — no single format is required, and leading
zeros and surrounding spaces don't matter:

| You type                                   | Meaning                         |
|--------------------------------------------|---------------------------------|
| `12`, `12.5`                               | seconds                         |
| `0:05`, `1:23`, `00:00`                    | minutes:seconds                 |
| `00:00.000`, `0:02.5`                      | minutes:seconds.milliseconds    |
| `00:00:00`, `01:23:45`                     | hours:minutes:seconds           |
| `00:00:00.000`, `01:23:45.500`             | hours:minutes:seconds.milliseconds |
| `00:00:000`, `1:23:456`                    | minutes:seconds:milliseconds    |

Every timestamp is converted to whole **milliseconds** by `data/TimestampParser.kt` (integer
arithmetic only). A three-part value with no decimal point whose last part is exactly three
digits is read as minutes:seconds:milliseconds; any other three-part value is
hours:minutes:seconds. Seconds (and minutes, when hours are given) must be 0–59; the largest
accepted time is 99:59:59.999. Invalid entries are rejected with a message that says why, and
any script line that is skipped is listed on the Script screen with its line number.
Times are shown as `m:ss` or `h:mm:ss`, with `.mmm` added only when the time has milliseconds.
Unit tests: `./gradlew testDebugUnitTest`.

## Automatic timestamp alignment

Script timestamps are often a little off — and the error is rarely constant: it commonly grows
through a long recording (say +0.8 s at 5 min, +1.4 s at 20 min, +2.1 s at 45 min). This feature
treats the **audio/video recording as the source of truth** and corrects each line against it.

**Using it** (Script screen → "Automatic timestamp alignment"): choose the recording (any audio
or video file), tap *Analyze timestamps*. For every line you see the original timestamp, the
timestamp detected in the audio, the difference (e.g. `+1.430 s`), the corrected timestamp, a
confidence score, and when the spoken line ends. Per line you can **Keep original** or **Apply
correction**; or **Apply all high-confidence** in one tap. On the review screen, **Keep original**
and **Apply correction** buttons at the top of the list act on every line at once (or only the
lines in the selected tab, e.g. *Needs review*). Lines the app isn't sure about are
marked **Needs review** with a plain-language reason and are never changed unless you apply them.
There is also an opt-in switch to apply high-confidence corrections automatically (off by
default). The script's original timestamp is always kept (`SentenceSlide.originalTimestampSec`),
survives restarts, and **Restore all original timestamps** puts everything back.

**Hearing the original recording on the Match screen**: once a recording is chosen, the Match
screen has an *Original recording* panel. **▶ Play original** plays only the current sentence's
slice of your recording (from its timestamp to the next sentence's), so every sentence is its own
part without any file being cut. **Starts** and **Ends** each have −1 / −0.5 / −0.1 / +0.1 / +0.5 / +1
second buttons; the sentence replays after every nudge, and the new time is saved with the
script's original kept (so *Restore all original timestamps* still works). If the analysis has run,
**Use the detected start** applies what it found for that sentence.

**How it works** (`align/`, all integer milliseconds):

1. `RecordingReader` decodes the audio in one streaming pass into 10 ms loudness frames (no raw
   audio held in memory, so multi-hour recordings are fine). Frame times are exact for any
   sample rate and honour where the audio track starts.
2. `SpeechAnalysis` finds speech with an adaptive noise floor (re-estimated every 5 s), rejects
   steady hum/tones, and places each onset at the *foot* of the rise rather than where it
   crosses a threshold. Loudness dips inside continuous speech become weaker candidate points.
3. `CoarseDrift` searches the whole recording at ±40 s for how far the script is from the audio,
   window by window, letting the lag change slowly (drift). Nothing assumes a constant offset.
4. `TimestampAligner` lets every line choose its own onset by dynamic programming: onsets after
   real pauses are preferred; lines stay in order; the speech between two onsets must match how
   long the earlier line's text takes to say; neighbours should have *similar* error, but only
   mildly. Lines can be skipped (text not in the audio, or speech not in the script) so one bad
   line can't push the rest off. Confident anchors then re-centre the search and the speaking
   rate is re-estimated (two repeats).
5. Confidence comes from how much worse the best *different* answer is, how clear the pause
   before the line was, how well the speech length matches the text, how clean the recording is,
   and whether the fine result agrees with the independent coarse drift estimate. A line is
   only "high" (0.80+) if all of these are good. A line with no text, a noisy recording, or
   disagreement with the drift pattern is capped below that.
6. `AlignmentApplier` refuses any change that would put lines out of order or less than 100 ms
   apart, because the preview, export and Match screen all rely on slides being in time order.

**Important limits.** It does **not** recognise words — it checks pause structure and how long
speech lasts against how long your text should take. If the wrong words are spoken at a similar
rhythm it can't tell. In a test where the script's sentences were shuffled (right pauses, wrong
words), confidence dropped but 38 % of lines were still rated high — their *timing* was right, but
nothing verified the words. That is a real limit; check anything where the content may not match. A very noisy recording gets mostly *Needs review* instead of guesses. Speech-length
modelling is tuned on Latin-script text and is rougher for Devanagari (it self-calibrates the
speaking rate per recording, but it has seen less testing there).

**Measured accuracy** on synthetic speech with known ground truth (15 recordings × 6 min, drift
0→2.4 s plus 250 ms random per-line error, 1 605 lines): 76 % of lines rated high-confidence, **0
of them wrong by more than 250 ms**, median onset error 13 ms, 99th percentile 101 ms. Adversarial
cases — a transcript that isn't in the recording, silence, a steady tone, lines with no text, a
line missing from the audio — are never rated high-confidence. Real recordings are harder than
synthetic ones; expect more *Needs review*, not more wrong corrections. Tests: `align/` under
`app/src/test` (synthetic speech generator + ground-truth assertions).


## Big folders (10 GB and more)

"Add a Whole Folder" now scans the chosen folder **and every sub-folder**, accepts photos even if
the storage app reports a generic file type, sorts frames in natural order (frame2 before
frame10), shows a live "photos found" count while scanning, and tells you plainly if Android
blocked the folder (it refuses Downloads and the very top of storage - pick a folder inside).
Only each photo's header is read, so folder size in GB doesn't matter - only the number of files.
Preview, Match and Export no longer rebuild their photo lists on every tick, which is what made
the screen freeze with thousands of photos.

## The two problems you asked me to fix

**"Handle large file work properly."** The original app reads every photo into memory as a
base64 string via `FileReader`, and keeps all of them there for the whole session — fine for a
few small images, but slow and memory-heavy for a phone camera roll. `data/ImageStore.kt`
instead keeps only a content `Uri` and true pixel size per photo; thumbnails are decoded
downsampled (`BitmapFactory.Options.inSampleSize`) to whatever size is actually on screen, and
full resolution is only ever decoded one photo at a time, right before that photo's export
frames are rendered.

**"The audio."** In the original, the on-device voice (browser `speechSynthesis`) was only ever
used live, while matching a sentence to a photo — the exported video itself was always silent.
That's the one place I changed the app's actual behavior rather than just its plumbing: the same
voice is now synthesized to file and baked into the exported video as a real, timed audio track
(see "New features" below). I flagged this clearly rather than assuming — you can turn narration
off per-project on the Script screen if you'd rather keep silent exports.

## Architecture

```
app/src/main/java/com/videoslidemaker/app/
├── model/         Plain data classes: SentenceSlide, PoolImage, ExportSettings, UiState
├── data/          Script parsing, Uri-based photo storage, JSON draft autosave
├── tts/           Android TextToSpeech wrapper (live speech + synthesize-to-file)
├── export/        The video pipeline (see below)
├── viewmodel/     AppViewModel — single StateFlow<UiState>, one method per user action
├── ui/theme/      Palettes (light/dark/high-contrast), accent choices, saved appearance prefs, typography
├── ui/components/ Reusable Compose widgets (cards, toggles, buttons, step bar)
├── ui/screens/    One file per wizard step
├── MainActivity.kt          Compose host + system file pickers (SAF)
└── VideoSlideMakerApp.kt    Notification channel setup
```

**Export pipeline** (`export/`): `VideoExportEngine` is the conductor. It computes the output
resolution, builds the final photo sequence (with the same "fall back to next unused photo"
rule as the original), synthesizes the combined audio timeline first, then renders and encodes
video frame-by-frame:

- `FrameRenderer` — cover-fit crop + Ken Burns zoom + fade, same math as the original canvas code.
- `Yuv420Writer` — converts each rendered frame to the YUV420 the encoder needs.
- `VideoEncoder` / `AudioEncoder` — MediaCodec H.264 / AAC, real presentation timestamps.
- `MuxerHolder` — combines both into one `.mp4` via MediaMuxer.
- `NarrationAudioBuilder` / `AudioDecoder` / `PcmResampler` / `WavUtils` — build the narration +
  music audio timeline described above.
- `ExportForegroundService` — runs all of this off the UI thread with a progress notification.

This replaces the original's `canvas.captureStream()` + `MediaRecorder`, which depends on
whatever codec the phone's browser happens to support and paces frames with `setTimeout`. The
native pipeline uses the device's real encoder with exact per-frame timing, so it doesn't drop
or duplicate frames and doesn't depend on browser codec support.

## What I improved (same feature, done more reliably)

- **Photo handling** — Uri-based, never loads a full photo into memory unless it's actively
  being drawn into a frame (see above).
- **Video encoding** — native MediaCodec/MediaMuxer instead of browser MediaRecorder.
- **Export reliability** — runs in a foreground service, so it keeps going if you switch apps,
  lock the screen, or the export takes a few minutes on a long project.
- **Saving the result** — goes straight into `Movies/VideoSlideMaker` via MediaStore (or the
  legacy public Movies folder on Android 9 and below), instead of a browser download.
- **Split-at-cursor** — uses Compose's real text cursor position instead of a DOM Range hack.

## New features added

- **Per-photo time control (latest addition).** Each photo on the Photos screen now has a
  tappable "⏱ 0:03" chip — tap it, type a time like `2:30` or `15:00`, save. To make that
  meaningful, the Script step became fully optional: if you don't load a script, the app
  automatically treats your photo pool as the timeline, one slide per photo in order, using
  each photo's own time. Match screen is skipped automatically in that case (there's nothing to
  match — each photo already maps to itself); Preview and Export both use whichever timeline is
  active. Loading a script still works exactly as before and takes priority if present.
- **Narration baked into the video** (see above) — on-device TTS per sentence, placed at that
  sentence's exact timestamp, mixed into the final MP4's audio track. Toggle it off on the
  Script screen if you want a silent export like before.
- **Optional background music** — pick an audio file on the Export screen; it's decoded, looped
  or trimmed to the video's length, and mixed underneath the narration at an adjustable volume.
- **Auto-saved project draft** — if you switch apps, rotate the phone, or Android reclaims memory
  in the background, your script, photos, and settings are restored automatically next time you
  open the app (`data/ProjectRepository.kt`). The original had no protection against a lost tab.
- **Share button** after export, using Android's native share sheet.

## Deliberately not changed / not added (so you know where I drew the line)

- The original's CSS hinted at drag-to-reorder photos (`.img-drag` classes) but never actually
  wired it up — only the up/down buttons worked. I kept the up/down buttons (100% reliable) and
  didn't add drag gestures on top, since a hand-rolled drag implementation is one of the riskier
  things to get right without being able to test it. It's a clean follow-up if you want it.
- The launcher icon is a simple placeholder (a purple square with a play glyph) so the project
  compiles out of the box — swap it via Android Studio's `Image Asset` tool for a polished icon.
- Typography uses the system font rather than bundling the original's Space Grotesk/Inter font
  files, again to avoid adding a dependency I couldn't verify without a network connection. Swap
  `FontFamily.Default` in `ui/theme/Type.kt` for bundled `.ttf` files if you want an exact match.

## Permissions

Only `POST_NOTIFICATIONS` (for export progress) and the foreground-service permissions are
requested up front. Photos, script, and music are all picked through Android's Storage Access
Framework, so the app never asks for broad photo-library or storage permission.
