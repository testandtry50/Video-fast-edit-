# VideoSlide Maker — Native Android

A full native Android (Kotlin + Jetpack Compose) rewrite of the original web app. It keeps
every feature of the original 5-step wizard (Script → Photos → Match → Preview → Export),
fixes the two things that don't scale well in a browser tab (large photo files, and audio),
and adds a few genuinely new capabilities on top.

## NEW in 2.14.0: many projects in one app (switch between hours of work without losing anything)

Tap the **project name at the top of any screen** (it has a small arrow) -> the **Projects** screen.

| | What it does |
|---|---|
| **New project** | Starts an empty project and opens it. A blank name becomes "Project 2", "Project 3"... The one you were in is saved first and stays exactly as it was. |
| **Open this project** | Saves the one you are in, then opens the other. It opens **on the same step you left it on** (Match, Preview, Export...) and **at the same sentence and scroll position**. |
| **Rename** | Names are kept unique ("Trip", then "Trip (2)"); capital letters don't count as different. |
| **Copy** | An independent copy of a project: script, photo list, matches, name texts, settings. Photos cleaned by the logo cleaner are copied too, so deleting a photo in one project can never break the other. The copy is not opened. |
| **Delete** | Removes the project from the app (after asking). Your original photos, your recording and exported videos are **never** touched; only the logo cleaner's own cleaned copies of *that project's* photos are removed. Deleting the open project opens the most recently edited other one (or a new empty one if it was the last). |
| **Search** | Appears once you have more than 5 projects; matches every word you type, in any order. |

Each card shows the slide count, photo count, **length of the finished video** (a 5-hour project shows `5:00:00`) and when it was last edited.

**Made for long work.**
- Only the **open** project is in memory. The others are small files on disk that cost nothing until you open them, so ten five-hour projects feel the same as one. Measured with the reference harness below: a project with 6,000 lines + 6,000 photos (a 5-hour film) is 1.2 MB on disk, saves in ~0.1 s and loads in ~0.14 s; listing ten projects is instant because the list keeps a one-line summary per project and never reads the project files.
- Working in one project only ever re-writes **that** project's file (checked: the other nine files were byte-for-byte untouched).
- **Undo / Redo stay with their project.** Switch away and back and Undo still works (the last 4 projects you used are kept for this session).
- **Export keeps running while you switch.** Start a long export, open another project and keep editing; the progress and the finished video show up in the project that was exported, and the other project does not see them. Only one export runs at a time: starting a second one tells you to wait for the first (or cancel it).
- **Your old project is moved in, not lost.** The first time 2.14 starts, the single draft from earlier versions becomes **"Project 1"** (with its scroll positions) and the old file is kept next to it as `project_draft.json.migrated`.

**What waits before you can switch.** Photo import, the logo cleaner, the timestamp check and the transcript check all write into the open project, so switching (or copying / deleting the open project) is refused with a plain sentence until they finish or you stop them; otherwise their results would land in the wrong project. The screens are rebuilt on every switch, so no typed text, dialog or ticked line from the last project can leak into the next.

**Safety.**
- The project you leave is written to disk **before** the other is read, and the other is read **before** anything on screen changes: if its file can't be read you simply stay where you were (and a `.corrupt` backup of the unreadable file is kept).
- A project and its id travel together in one object, so an auto-save can never write one project into another's file; a save that arrives after a project was deleted is dropped instead of bringing it back.
- Every write goes to a temporary file and is swapped in, as before. If the project list file is ever damaged, projects still on disk are put back as "Recovered project".

**Files.** Existing file names are unchanged. New: `data/ProjectIndex.kt` (the list, naming rules, JSON), `ui/screens/ProjectsScreen.kt`, `data/ProjectIndexTest.kt`, and `tools/projects-reference/`. Changed: `ProjectRepository.kt` (now one file per project + the list; the save/load format *inside* a project is byte-for-byte the old code, so old drafts read the same), `AppViewModel.kt`, `MainActivity.kt`, `AppTopBar.kt`, `ScrollMemory.kt`, `UiState.kt` (one new field, `projectId`), and a tiny `reset()` on `LogoCleanController` and `AdjustController`.

**How it was checked.** The project-list logic is pure Kotlin (`ProjectIndexTest`, 24 tests) and was **compiled with a real Kotlin compiler (1.9.24) and run**: 24/24 pass. `ProjectRepository` was compiled against the real model classes with two stand-ins for `Context` and `Uri`, and run against a real temporary folder by the harness in `tools/projects-reference/`: **51 checks, all pass** - first start, migrating an old draft, round trips, two projects staying isolated, copy/delete/rename, damaged list and damaged project files, unsafe ids (`../x`), 150 concurrent saves/switches, and the 5-hour project above. Three deliberately broken copies (a save that can resurrect a deleted project, a copy that shares cleaned files, a migration that forgets the scroll file) were each caught.

**Limits you should know about**
- **`AppViewModel`, `MainActivity`, `AppTopBar` and `ProjectsScreen` were NOT compiled or run** (they need the Android SDK and Compose, which this machine doesn't have); they only passed the bracket-balance lint, and I checked names, imports and types by hand. Expect the possibility of a small compile error on your first GitHub build, and the Projects screen layout has not been seen on a device.
- Only the last 4 projects keep their Undo history while the app runs, and **no** Undo history survives closing the app (same as before).
- Reopening the app puts each project back on **Script or Photos** (as before), not the exact step; the exact step is remembered while the app stays open.
- The picked-photo permission limit Android puts on an app (a few hundred individually picked photos) is shared by all projects together. Importing a **folder** uses one permission for the whole folder, so for big projects keep using *Add folder*.
- Copying a project that has many cleaned photos uses extra storage for the copies.

## NEW in 2.13.0: Adjust timestamps (with a preview, and the originals always kept)

Script step -> **Adjust timestamps**. Five options:

| | Option | What it does |
|---|---|---|
| 1 | **Adjust entire transcript** | Moves every timestamp earlier or later by the same amount (`1.43`, `-0.25`, `430ms`, `1:23.5`; or the -1 s / -0.1 s / +0.1 s / +1 s buttons). Optionally stretches the spacing by a percentage for a recording that was sped up or slowed down (the first line stays put). **All or nothing**: if any line would break, nothing moves, and it tells you the earliest shift allowed. |
| 2 | **Automatically synchronize entire transcript** | Listens to the recording (the alignment engine, with the spoken words if a speech model is installed), then shows the detected time for every line. Nothing is applied until you say so, even if "apply automatically" is switched on. |
| 3 | **Adjust selected timestamps** | Tick lines, then move them by an amount, or give **one** line an exact time (`00:01:25.430`, `1:25.43`). |
| 4 | **Apply detected corrections** | Previews the corrections an earlier analysis found. High-confidence ones are ticked for you; tick others on purpose if you want them. |
| 5 | **Undo corrections** | *Undo the last adjustment*, *restore the original timestamps* for every adjusted line, or *restore only the lines I pick*. Undo gets the same preview. |

**Preview before anything changes.** Every option ends in the same list, one card per line:

```
BEFORE
00:01:24 — Hello everyone
AFTER
00:01:25.430 — Hello everyone
Difference: +1.430 seconds
```

(Milliseconds are shown only when there are some, so a script that wrote `00:01:24` is shown as written.) Lines the analysis found
also show their confidence. Each card says plainly when a line **will change**, **is left alone** (and why), or **can't be
adjusted** (and why).

**Apply one, some, or all.** *Apply this one* on any card; *Apply selected (N)* for the ticked lines; *Apply all high-confidence
corrections (M)* for the lines the analysis was sure about (95 %+), whatever is ticked.

**The original is never destroyed.**
- A line's **first** original time is remembered (`originalTimestampSec`, the exact value, saved in the draft) and **never
  overwritten**, however many adjustments are stacked: shift +1 s, then synchronize, then nudge, and the original is still the
  time the script gave. Putting a line back to its original time clears the marker, and restores the *exact* original value, not a
  rounded copy.
- Every applied adjustment is also logged (the newest 20, saved in the draft, so **"undo the last adjustment" still works after
  the app was closed**). A line that was moved again by hand, or whose text was edited, after that adjustment is **left alone** by
  undo and the preview says so; undo never clobbers a later edit.
- Nothing is written back to your transcript file; the app never modifies it.
- Nothing that would break the timeline is applied: a line that would start before 0:00:00 or come within 0.1 s of (or past) its
  neighbour is refused and listed, the same rule the automatic corrections obey. The preview and the apply use the same code, so
  what the preview promises is exactly what happens.
- Applied adjustments also show up in the app's normal Undo/Redo (disabled while this screen is open, so the two can't fight).

**How it was checked.** The decision logic is a pure-Kotlin package (`app/.../adjust/`, no Android) so it could be verified without
a compiler: I transliterated it to Java and ran the same assertions, **6,141 checks including 60 random "adjust many times then
restore everything" trials and 30 "undo every step in reverse" trials**; five deliberately-broken copies (original overwritten,
marker not cleared, collision guard weakened, stale-line check removed, an adjusted-state rule loosened) were all caught. The same
cases are Kotlin tests (`TimestampAdjusterTest`, `AdjustControllerTest`, `AdjustSupportTest`) that run on your first GitHub build.

**Limits you should know about**
- The Kotlin and the Compose screen were **not compiled or run** here; expect possible small compile errors, and the layout has
  not been seen on a device.
- "Undo last adjustment" takes back one step at a time and has no redo of its own (the app's Redo covers it once this screen is
  closed). The log keeps the newest 20 adjustments; *restore originals* works however old the adjustment is.
- If you use the app's general Undo on an adjustment, the adjustment log still lists it (the general Undo restores the slides, not the log). "Undo the last adjustment" will then show those lines as already changed and leave them alone, which is safe but means that log entry is no longer useful.
- The stretch option scales the spacing from the first line; it is for a uniform speed change, not for drift that varies (use
  option 2 for that).
- The frame-based timecodes (`00:05:20:12`) in a script are still rejected (the frame rate is unknown).

## NEW in 2.12.0: a more accurate, more honest timestamp alignment

For every line the app now reports the **original** timestamp, the **detected** one, the **difference**, a **confidence**,
and a **correction status**:

| Original | Detected | Difference | Confidence | Status |
|---|---|---|---|---|
| 00:05:20.000 | 00:05:20.430 | +0.430 s | 98 % | Correction ready |
| 00:10:44.000 | 00:10:45.120 | +1.120 s | 96 % | Correction ready |
| 00:20:15.000 | 00:20:16.840 | +1.840 s | 91 % | Needs review |

(The review screen also shows a **±precision** and what the time is **based on**: the audio, the audio *and* the spoken
words, the words only, or the neighbouring lines.)

**Confidence means one specific thing:** the estimated chance that the detected time is within 0.25 s of where the line
really starts. It is a fitted probability, not a feeling, and it is **never shown above 99 %**: nothing here can be verified
to 100 %. Only lines at **95 % or more** are "Correction ready" (applied by *Apply all high-confidence*); everything between
is *Needs review*. Statuses: **Matches** (already right), **Correction ready**, **Needs review**, **Estimated** (no evidence of
its own: placed from the confident lines around it, never applied automatically) and **Cannot be aligned** (nothing found;
the timestamp is left alone). Consecutive lines that can't be aligned confidently are listed together at the top of the
review as **"Not confidently aligned"** stretches, with the reason, so you know where to listen.

**What changed in the engine** (all of it measured first in `tools/alignment-reference/`, then ported):

1. **A real weakness found and fixed: offset steps.** The drift tracker could only move 4 s per 45 s window, and the safety
   check "does the fine result agree with the coarse estimate" extrapolated the last good lag for up to 100 s. After an edit
   that shifts the audio by 20 s, the tracker stayed stuck on the old lag, the check compared the wrong answer against that
   stale lag and passed it, and **10 lines were rated high-confidence while 20 s wrong**. Now the tracker can jump any
   distance (two O(L) sweeps instead of a bounded search), a line is "high" only if a window *close to it* really has a
   clear peak (nothing is extrapolated), and a line near a step is searched on **both sides** of it. Same test: 53 % → 98 %
   of lines within 100 ms after a 20 s step, and 0 wrongly-trusted lines.
2. **The spoken words, when a speech model is installed** (the same one the accuracy checker uses; it is listened to once
   per recording and shared between the two). The words say *which sentence* each line is, at **any** offset (a 90 s error,
   far beyond the audio's ±40 s search, is found: 60 of 73 lines high-confidence, none wrong). The audio then chooses the
   *millisecond*. This split was measured, not assumed: at a pause the audio is better (median 14 ms vs 30 ms when averaged
   with the words), inside continuous speech the words are better (44 ms vs 106 ms), and when the two disagree by 0.3-1.5 s
   the audio is right 85-100 % of the time. So the audio keeps the answer and disagreement only lowers confidence.
3. **Confidence is calibrated, with hard gates on top.** A logistic model fitted on 14,215 simulated lines (10 scenarios:
   drift, jitter, steps of 6 s and 20 s, noise, a music bed, no pauses, 60 s of silence first, coughs, fast speech; × 5
   recognizer qualities × 4 random seeds) predicts "within 0.25 s". Lines from 3 other seeds that the model never saw confirm
   it is, if anything, conservative. A fitted curve is unreliable in the tail it rarely sees, so it can never talk the audio
   score up: audio-only evidence below 0.80 is never "high"; words found strongly at a *different place* or confident words
   that are not this line's text force *Needs review*. (An early version without those gates rated lines high at audio
   score 0.49-0.63; the gate removed every such case.)
4. **Timestamp formats.** `00:05:20,430` (SRT) used to be read as `00:05:20` with `,430` leaking into the sentence, silently
   losing the 430 ms. Now accepted: `[00:05:20] text`, `(5:20) text`, `00:05:20,430 text`, `start --> end text` (the end is
   ignored), whole **SRT / WebVTT** files (cue numbers and the `WEBVTT` header are dropped, text lines joined), and `5m20s`,
   `1h02m03.5s`, `320s`. Every line that already parsed is left exactly as before. **Not accepted, on purpose:** frame-based
   timecodes (`00:05:20:12`), because the frame rate is unknown and a guess would be a wrong timestamp that looks right.

**Measured, on fresh recordings the tuning never saw** (simulated speech with known ground truth, 1,457 lines per row,
`tools/alignment-reference/evaluate_pipeline.py`):

| Recognizer | Lines rated high | Wrongly rated high (>0.25 s off) | Stated confidence of high lines | Observed within 0.25 s |
|---|---|---|---|---|
| none (audio only) | 55 % | **0 of 808** | 97 % | 100 % |
| clean | 88 % | **0 of 1,285** | 98.8 % | 100 % |
| typical | 82 % | **0 of 1,198** | 98.7 % | 100 % |
| hard | 73 % | **0 of 1,069** | 98.4 % | 100 % |
| awful | 46 % | **0 of 675** | 97.3 % | 100 % |

A very poor recognizer makes the app more **cautious** (46 % trusted instead of 55 %), not less accurate. A 45-minute
recording with drift *and* an 8 s step: 95.7 % of lines within 0.25 s with the audio alone, 98.4 % with the words, 0 of 487
high-confidence lines wrong, and the number of unresolved stretches falls from 39 to 7. Situations where the right answer is
"I can't tell" (silence, a steady tone, blank text, a transcript of a different recording, 9-16 invented lines, a recognizer
hallucinating confident garbage) produced **no** wrongly-trusted lines. A transcript with the right rhythm but the **wrong
words** (shuffled lines) is no longer rated high 38 % of the time: with the recognizer it is 1 line in 72.

**Limits you should know about**
- **The numbers come from simulated recordings, including a simulated speech recognizer** (my model of its failure modes:
  dropped, wrong and extra words, lost lines, jittery word times). No real recording or real Vosk run was available when this
  was built. Real speech is harder; expect more *Needs review*, not more wrong corrections, and treat the stated percentages
  as upper bounds until you have checked a few real recordings by ear.
- **Continuous speech has no pause to latch onto.** Its start is only good to roughly ±0.15-0.4 s, the result says so (the
  ± column), and such a line is never rated high on its own.
- **Noisy audio reads late.** The voice emerges from under the noise floor: measured +55-75 ms median (up to ~+160 ms) at 12 dB
  signal-to-noise vs +11 ms clean. It is reported as a wider ± and a lower confidence, not "corrected" (that would import the
  recognizer's own unknown bias and call it truth).
- **If the recognizer hears nothing in a stretch, that stretch is judged by rhythm alone**, as before: it can't tell wrong
  words there.
- **Estimated lines are guesses.** Measured by pretending lines had no evidence: 84 % within 0.25 s when both neighbours agree,
  60-65 % otherwise; they are stated lower (50-70 %) and never applied automatically.
- **Time to listen.** The recognizer runs once per recording and is cached, but it takes however long Vosk takes on your
  phone; for a multi-hour recording that is a long wait. The audio-only path is unchanged and fast.
- The Kotlin was **not compiled** where it was written (see below); its logic was checked against the Python reference.

**How it was checked without a compiler.** `tools/alignment-reference/` holds the Python reference, the experiments and the
reproducible measurements. `export_golden.py` writes `app/src/test/resources/alignment_golden.txt`: 41 randomized cases (lexical
anchors, fusion with calibrated confidence, estimates, statuses, sections, the tracker's Viterbi, hypotheses and step-aware
re-centring) with the outputs the *Python* produces. `AlignmentGoldenTest` runs the same inputs through the Kotlin and requires
the same outputs; I also ran a Java transliteration of the new Kotlin logic against that file (2,415 checks, all matching, and
deliberately-broken copies are caught). That proves the *logic* matches; it does not prove the Kotlin *compiles*.

## NEW in 2.11.0: check the WORDS against the audio (accuracy checker)

The timestamp alignment below only checks *when* lines are spoken. This checks *what* is spoken. The recording is the
truth; the app listens to it **on the phone, offline**, compares every word with your script, and gives each line one status:

| | Status | Meaning |
|---|---|---|
| 🟢 | MATCH | nothing wrong found |
| 🟡 | TIMESTAMP ERROR | the words are right, but the line starts somewhere else than its timestamp says |
| 🔴 | TEXT MISMATCH | a transcript word was replaced (`program` → `show`) |
| 🔴 | MISSING WORD | spoken in the audio, **missing from the transcript** |
| 🔴 | EXTRA WORD | in the transcript, **not spoken** in the audio |
| ⚪ | UNCERTAIN | the recognizer isn't sure enough to accuse the transcript (low confidence, a number, a stutter, a line it can't find) |

Every problem shows the **exact place in the audio** (`00:00:04.340 – 00:00:04.720`) and a **Jump** button: tap it (or the
card) and the player at the top of the results screen seeks to that moment and plays. A timestamp error shows the
transcript timestamp, the actual speech time, the difference (`+3.120 seconds`) and the corrected timestamp, with a jump
button for both the claimed and the real place. (The status dot is drawn rather than the emoji so it looks the same on
every phone - the green and yellow circle emoji don't exist on Android 9 and older.)

**First use:** Script step → "Check the words against the audio" → choose a **Vosk speech model**. The app has no internet
permission, so you download the model's `.zip` yourself from alphacephei.com/vosk/models (e.g. `vosk-model-small-en-us`, about
40 MB; there is a small Hindi one too) and pick it once. Then choose the recording (the same one the alignment card uses)
and tap **Check the transcript**. What was heard is kept, so changing the tolerance or fixing the script and checking again
doesn't listen to the whole recording again.

**What is deliberately *not* counted as an error:** case and punctuation, "um/uh", `25` vs "twenty five", `2020` vs "twenty
twenty", `$5` vs "five dollars", `10%` vs "ten percent", a stutter ("the the"), and anything a low-confidence word is
involved in. Those show as UNCERTAIN / "possible" with the reason, never as red.

**The design was measured first** in `tools/accuracy-reference/checker.py` (the Python reference) with
`python3 tools/accuracy-reference/run_tests.py`: 28 scenarios including your two examples, Hindi, 88 minutes of speech
(8,900 words, 0.1 s even in Python), and the memory limits. Testing it found and fixed real bugs before the port (false MISSING WORD on years, a stale
cost cache between runs, one unscripted passage being split across two lines, lines that start with a number becoming
UNCERTAIN). `app/src/test/.../check/AccuracyCheckerTest.kt` runs **the same scenarios with the same expected numbers**.

**Limits you should know about**
- The checker is only as good as the recognizer. A small model mishears real words; that's why low-confidence words are
  "possible", not red, and why you can tap Jump and *listen* before changing anything.
- Compound words ("icecream" vs "ice cream") and abbreviations ("Dr." vs "doctor") can show as a mismatch.
- Speech before the first line / after the last line is only reported if it is within 1.5 s of it.
- Vosk adds roughly 30-50 MB of native libraries to a universal APK (a Play app bundle only delivers the matching CPU's).
- A small model needs a few hundred MB of RAM while listening.

## NEW in 2.10.0: fuzzy voice fixed, many more looks, small text, and layout choices

- **No more fuzzy hiss behind the voice when you change it.** Cause found and measured: a phone voice (usually 22.05 or
  24 kHz) was brought up to 44.1 kHz by drawing straight lines between samples, which leaves a faint mirror image of the
  voice above the voice's own top frequency (about 36 dB below it). You can't hear that at normal pitch, but the voice
  changer moves the whole sound - lower the pitch and the mirror image slides down into hearing range as a fuzzy hiss.
  The converter is now a proper band-limited (Kaiser-windowed sinc) filter: the mirror image is gone (about 107 dB
  below the tone in `SincResamplerTest`; the old method left it about 8 dB below for a high tone). It is used for
  the phone's voice, your recording (`StreamingPcmConverter`, still streaming - any length) and background music.
  The live preview also plays on an audio-priority thread with a 1 second cushion, so a busy phone cannot make it crackle.
  Measurement and a Python copy of the filter: `tools/voicefx-reference/resample_check.py`.
- **Dark mode styles (7):** Charcoal (the original), Pure black, Slate, Midnight, Forest, Mocha, Plum. **Light mode styles (6):**
  Paper (the original), Snow, Sepia, Mint, Blush, Lavender. Dark and light each keep their own style.
- **Accent colours: 20 presets + any colour.** Red, Coral, Orange, Amber, Yellow, Lime, Leaf, Green, Emerald, Teal, Cyan,
  Sky, Blue, Indigo, Violet, Purple, Magenta, Rose, Brown, Slate - and *Custom*, a rainbow slider for any colour on the
  wheel. Every accent is automatically nudged lighter or darker where a background style would make it hard to read, so every
  accent works on every style (`ColorMath.fitColor`). Violet and Purple are back as choices because you asked for all colours;
  the defaults are unchanged (Blue on Charcoal / Paper), so nothing looks different until you pick something.
- **Text size: Small, Default, Large, Larger, Largest** (Small is 87 % of your phone's own size).
- **Layout choices:** four ready-made layouts (Classic, Compact, One-hand, Sharp) or set them one by one - *step bar* at the
  top or the bottom of the screen (reachable with one thumb; it steps aside while the keyboard is open), *spacing*
  (Compact / Comfortable / Roomy) and *corners* (Round / Soft / Square). Buttons stay at least 48 dp tall in every choice.
- **Easier Appearance page:** a live *Preview* card at the top, the most-used choices first (light/dark, accent, text size),
  and a tiny picture of each background style so you can see it before you pick it.
- The old *Pure black background* switch is now the **Pure black** dark style; if you had it on, it is carried over.
- `ThemeContrastTest` now checks every dark style x light style x accent preset, plus a custom accent at every 15 degrees of the
  colour wheel, with and without high contrast. `tools/theme-reference/palette_check.py` runs the same checks in Python.
  The rule that forbade purple accents was dropped from the tests (you asked for all colours); the rules that the *default* look
  stays unchanged, light pages never glare, and Charcoal / Pure black stay tint-free were kept.

## NEW in 2.9.1: calmer light theme, a true neutral dark theme, and an easier first screen

- **Calm light theme.** The page is a warm off-white "paper" colour, the cards are a shade lighter (no pure `#FFFFFF`), and the text is soft charcoal (no pure black). Big bright-white areas are what tire the eyes, so there are none. Text still passes WCAG contrast (about 12:1 for main text).
- **Proper dark theme, no purple.** Charcoal greys with equal red, green and blue (no tint), soft off-white text instead of glaring white, three close grey steps for page / bars / cards. The Violet accent was removed; the accents are now Blue, Teal, Green, Orange and Rose. The last purple leftovers (launcher icon background, text-overlay preview backdrop, unset Material dialog colours) are gone too. `ThemeContrastTest` now also fails the build if a purple accent, a pure-white light page, or a tinted dark grey comes back.
- **Easier first screen.** It is now called *Start your video*. The script file is clearly optional (the "no script yet" note is a calm info chip, not a yellow warning), and the long *Settings* and *How to write a script* cards fold away - the settings card still shows a one-line summary (seconds per photo, shape, resolution, sound), so the page is short and the main button is in view.
- **Steps that are not ready say so.** Text, Preview and Export need at least one photo. Their tabs are dimmed until you add one, and tapping one tells you why (before, the tap silently did nothing).
- **Icons instead of emoji** on the main path (upload boxes, folder button, export buttons, status chips) so they look the same on every phone. New shared pieces in `CommonComponents.kt`: `CollapsibleCard`, and optional `icon` on `PrimaryButton`, `SecondaryButton` and `BadgeChip`.
- **Fixed a wrong label:** with no script, Photos said "Next - Preview" but went to the Text step. It now says "Next - Add Text". After an export the repeat button says "Export it again" (it re-runs the same export, not a new project).

## NEW in 2.9: Remove or blur subtitles and text too - in one segment, a range, or all of them (and ready for Google Play)

The cleaner that removed or blurred a **logo** now also removes or blurs a **subtitle**, any other **text**, or an
**icon** - and you choose how much of the video it touches: **this one segment**, **a range of segments**, or **all of them**.

**Where.** Photos screen: *Remove or blur a logo, icon, subtitle or text*. Match screen (new): the same button, which opens on
the segment you were looking at, with its time and sentence, and counts *segments* (lines of your script), not photos.

**What to clean** - three buttons:

| | How it finds the thing | Best for |
|---|---|---|
| **Logo / icon** | what repeats across your photos (as in 2.3 / 2.4: *Find the logo automatically*, *One tap*) | watermarks, channel logos, app icons |
| **Subtitle** | photo by photo, inside the box you drag (it starts as a strip near the bottom) | burned-in captions, in any language - tested on Latin and Hindi |
| **Other text** | photo by photo, inside the box you drag | titles, names, numbers, phone numbers |

A subtitle is different in every photo, so there is nothing to compare across photos. Instead the cleaner looks at every
photo on its own for what text looks like: thin strokes much brighter or darker than what is around them, flat in colour, many
of them side by side along a line. **Only the letters are repainted** (Remove) or smudged (Blur) - not the whole box - so
the picture around a caption stays sharp. **Remove + Blur** works as before.

**Find a segment's photo in the photo list (Match screen).** In the *All segments* strip, **tap a segment to jump to it** (instant,
as before) and **tap it twice quickly to find its photo**: the photo list below scrolls to that photo, the page scrolls so the list is
on screen, and the photo is shown with a yellow border and a "📍 Found it" tag for a few seconds, with a line saying *"Segment 5's
photo is photo 1,234 of 100,000"*. It finds the photo the video really shows for that segment (your own pick, or the one that covers
it). With a screen reader the same thing is in the card's actions menu (*Find this photo in the photo list*).

**Where to clean** - three buttons: *This segment*, *A range* (type the numbers, or press *Start here* / *End here* while paging
with Previous / Next, or *To the last*), *All*. For text there are two ways to look:
* **Only where text is found** (default): photos where the box does not hold a caption (the caption is not on screen at that
  moment) are left untouched.
* **Everywhere in the box (no checking)**: short and faint captions too. A photo with no caption can then get a small smudge,
  so check a few photos afterwards.

**Logo and subtitle on the same photo.** Cleaning a second thing now goes on top of the first (before, starting again from the
original would have brought the logo back). Each photo shows what was done: *"✔ logo removed · subtitle blurred"*.
Cleaning the *same* thing again still starts from the original, so a redo never stacks. *Restore* returns the original;
there is now also *Restore the range*.

### How well does the text finder work? (measured, not guessed)

Designed and run first in Python (`tools/textclean-reference/`), then ported to Kotlin; the unit tests assert the same numbers.
Test frames are made with known text (so the true answer is known), half of them JPEG-compressed and slightly softened like real video
frames, on fresh random seeds that were not used to tune the thresholds:

| | result |
|---|---|
| Captions of 3-8 words, 6 styles (white + outline, yellow + outline, shadow, plain, dark-on-light, on a strip), Latin and Hindi, 30-80 px, on faces, scenes, plain walls, real photographs, fine stripes | **90 %** found by *Only where text is found*; about **96 %** by *Everywhere in the box*. The misses are mostly plain white text with no outline (61 % found) and text over fine stripes (81 %) - there is little contrast to find |
| Letter pixels that end up inside the mask | **99.1 %** |
| Mask size compared with the text itself | **1.7x** (so the repaint stays local: everything else in the box is untouched) |
| Short 1-2 word captions ("Yes.", "No way!") | **85 %** with *Only where text is found*, a little more with *Everywhere in the box* |
| Boxes with **no text** (552 hard ones: faces, fur, grass, gravel, bricks, stars, stripes) wrongly treated as text | **0 / 552** with *Only where text is found*; **5.8 %** with *Everywhere in the box* |
| Repair, around the letters (PSNR against the true background; about 8 dB if left alone) | repaired to **29.7 dB** on your kind of frame (25.9 dB if the whole box were filled instead), 30.3 dB on scenes, 35.1 dB on a plain wall (36.6 dB for a box fill - a wall is easy either way), 24.5 dB on real photographs, 18.9 dB on very busy ones. In short: about as good as filling the whole box where the picture is smooth, better where it is not, and it never touches pixels away from the letters |

Before / after on your own sample frame and on a Hindi caption: `tools/textclean-reference/sample/text_cleaner_before_after.png`.
Re-run everything: `cd tools/textclean-reference && python3 evaluate.py` (about 15 minutes), `python3 mirror_scenarios.py`,
`python3 kotlin_transliteration_check.py`, `python3 demo.py`.

**Honest limits.** Text on a dark or light *strip* behind it: the letters go but the strip stays (use *Logo / icon* with
*Exact spot* to remove the strip itself). A one-word caption may be missed in the default mode. Very busy backgrounds
(leaves, crowds) with white text and no outline are hard for any non-AI method. Text that moves or zooms inside one photo is
not followed. It does not read the text (no OCR), it only knows what text looks like.

### Ready for Google Play

Google Play has required new apps **and updates** to target Android 16 (API 36) since 31 Aug 2026. The project now does:
`targetSdk`/`compileSdk` 36, Android Gradle plugin 8.9.1 + Gradle 8.11.1, edge-to-edge screens (Android 15+ always draws apps behind
the status and navigation bars), the Android 15 foreground-service time limit (a long cleaning run now stops cleanly and says
*"press the button again to continue"* instead of crashing the app), predictive back, release signing from the environment and a
signed `.aab` in the GitHub workflow. **Everything you still have to do yourself (upload key, Play Console forms, device test list)
is in `PLAY_STORE_CHECKLIST.md`.** Version is now 2.9.0 (`versionCode` 29).

## NEW in 2.8: Preview at any speed (0.25x to 4x), the way viewers watch on YouTube

People watch YouTube faster and slower than the video was made. On the **Preview** screen, under the play
buttons, the new **⏩ Playback speed** card shows (and plays) your video that way, so you can see how the
photos, the name text and the sound come across at 0.5x, 2x, 3x ...

* **A speed button beside play/pause** shows the current speed; each tap goes to the next common one
  (0.5x -> 1x -> 1.5x -> 2x -> 3x, then round again), so you can change it while you keep your eyes on the picture.
* **One-tap speeds** in the card: 0.25x, 0.5x, 0.75x, 1x, 1.25x, 1.5x, 2x, 3x.
* **Every speed in between**: a slider from 0.25x to 4x (normal speed is in the middle, and every doubling is the same
  width, so slow and fast are equally easy to set) and small **-0.25 / -0.05 / +0.05 / +0.25** buttons.
* **Change it while it plays.** The sound restarts at the same spot at the new speed a moment after you stop moving the
  slider (the voice-changer sliders work the same way). With the sound off there is nothing to restart, so the pictures
  change speed at once.
* **What you hear**: the phone's voice speaks faster or slower; your own recording plays faster or slower **with the same
  pitch** (a voice at 2x is quick, not a chipmunk); with the voice changer on, the changed voice or recording is sped up
  or slowed down the same way.
* **What you see**: the zoom/pan, the name texts and the fades all follow the speed (a 0.35 s crossfade lasts about
  0.18 s at 2x and 0.7 s at 0.5x, exactly as it does when a viewer changes the speed). A **"2x"** badge sits on the
  picture whenever the speed is not normal. More photos are loaded ahead when slides fly by faster.
* **What it means for THIS video**: *Watch time at 2x: 3:10 (normal: 6:20)*, *Shortest photo on screen: 0.4 s*, and a
  warning when speeding up makes photos stay up for **under 1 second** (it also says how many already were at normal
  speed), so you can find the slides a fast viewer would miss.
* **Only the preview changes.** The exported video is always normal speed (viewers pick their own on YouTube). The speed
  is a viewing choice: it is not saved with the project and it is not an Undo step. "Hear a sample" in the voice changer
  always plays at normal speed.

Code: `model/PreviewSpeed.kt` (the maths: steps, slider, labels, watch time, fall-backs), `ui/screens/PreviewSpeedPanel.kt`
(the card), `align/PlaybackSpeed.kt` (asks Android to change the speed and keep the pitch), and small changes to
`AppViewModel` (the preview clock now runs at the chosen speed and starts the sound at that speed),
`PreviewRecordingPlayer`, `FxRecordingPlayer`, `PcmClipPlayer` and `PreviewScreen`. At 1x nothing changes from 2.7: the
recording player is not touched at all, and the clock maths is the same.

How the picture stays with the sound: the preview's clock moves `speed` seconds for every real second, and the sound is
started at that same speed. Your own recording is still the master clock (its position is checked ten times a second and
the photos are pulled back if they drift; the allowed drift is widened with the speed so it is still 0.12 s of what you
see). If a phone refuses a speed, the sound reports the speed it really has, the photos follow that, and the card moves to
it and says so.

Tests: `PreviewSpeedTest.kt` (speeds, slider round trip for every 0.05 step, labels, watch time, quick-photo counts,
fall-backs, voice rate, fade lengths). The same checks run in Python: `python3 tools/previewspeed-reference/run_tests.py`.

Honest limits:

* As with the rest of this project, the Kotlin has **not been compiled or run** where it was written. The first `Build`
  on GitHub (or in Android Studio) is the first real compile, and it runs `PreviewSpeedTest`.
* **Phones differ.** Android's sound speed-up is built into the phone and some phones accept only part of the range (a few
  stop at 2x). The app asks the phone to refuse what it can't do (instead of going silent) and then falls back towards
  normal speed - see the note under the card.
* **The phone's own voice has a speed limit.** Without the voice changer, the voice reads at (your voice speed x the preview
  speed) and the phone's speech engine decides how fast it can go. Above about 2x sentences can run late or get cut off
  when the next photo arrives. That is the preview only. (A changed voice is time-stretched instead, which works to 4x.)
* **Voice changer + your recording, at a speed other than 1x:** the photos follow the clock instead of the sound's own
  position (the position of a time-stretched sound is not relied on). They stay together unless the phone cannot keep up -
  the voice effects have to be calculated 2-4 times faster than real time, which a slow phone may not manage and the
  sound then stutters. If it ever drifts, press pause and play (or drag the bar) and it lines up again.
* Android's speed-up is good for speech but not perfect: at 3x-4x words get a little smeared. It shows the idea of how
  your video feels at that speed; it is not a copy of YouTube's own processing.

## NEW in 2.4: Remove + Blur, and "Clean ALL photos at once" for 100,000+ photos

In the logo cleaner (Photos screen, **🧽 Remove or blur a logo / watermark**):

* **Three modes** - **Remove**, **Blur**, and the new **Remove + Blur**: the logo is painted out first, then only the
  repaired spot is softly blurred (much gentler than plain Blur) so no seam, edge or faint patch is left. The strength
  slider applies to Blur and to Remove + Blur. Works for one photo, for all photos, and with "One tap".
* **Clean ALL photos at once** - built for very large projects. Pick *Where the logo is found* / *Even if the logo
  moves* / *Exact spot, no checking (fastest)*, then press **Clean ALL**. While it runs a card stays pinned at the top
  of the screen with the **percent done**, `done of total`, photos per second, **time left**, and live counts of
  cleaned / no logo / failed. Also shown as a progress notification.
* **⚡ One tap: find the logo + clean ALL** - scans for the logo that repeats, then cleans every photo that has it.
* **Stop and carry on later** - Stop keeps everything already cleaned. With **Skip photos that are already cleaned**
  on (default) pressing the button again continues where it stopped. Turn it off to redo everything with a new box.
* Runs of 500+ photos ask for a yes first and show the storage they will use. **Restore ALL** also shows progress.

How it copes with 100,000+ photos (what changed under the hood, `logoclean/LogoCleanController.kt`):

* Up to 4 photos are repainted at the same time (fewer on phones with little memory - `BulkMath.workerCount`).
* Finished photos are handed to the app in **batches** (every 1.5-10 s). Before, the whole photo list was rebuilt after
  every single photo, which is 100,000 x 100,000 steps - that alone made big runs unusable.
* `LogoCleanService` (foreground service + wake lock) keeps the run going with the screen off or another app open.
* Storage is checked before starting and while running (a cleaned copy of each photo is saved: roughly 0.6 MB per
  1080p frame, so 100,000 frames is about 60 GB). Bulk copies are saved at JPEG quality 90 (single photo: 95).
  If storage runs out the run stops cleanly instead of failing thousands of photos.
* Honest limit: speed depends on the phone and the photo size - the card shows the real speed and time left after
  a few seconds. Very large runs are hours, not minutes. Keep the phone charging, and do not swipe the app away from
  the recent-apps list while a run is going (pressing Home is fine).

Tests: `BulkMathTest.kt` (percent, time left, worker count, storage estimate) and three new cases in `LogoCleanTest.kt`
(Remove + Blur removes the logo, touches nothing far away, and is softer than Remove alone).

## NEW in 2.3: Logo & watermark cleaner (remove or blur just a small logo)

On the **Photos** screen, **🧽 Remove or blur a logo / watermark** opens a screen with one photo and a box.
Put the box over the logo (drag it, drag a corner to resize, or drag on an empty spot to draw a new one) and
choose what happens to **only that spot**:

* **Remove** - paints the logo out from the picture around it (smooth fill + matching film grain, feathered in),
  so it looks like it was never there. Best on smooth or out-of-focus backgrounds. A hard edge running straight
  through the logo gets softened - use Blur there.
* **Blur** - blurs just the logo (strength slider) so it can't be read; a soft smudge stays.
* **Find the logo automatically** - a watermark is the one thing at the *same place* in many photos, so the app
  stacks the edge maps of up to 40 photos of the same size and the edges that repeat are the logo. The box jumps
  onto it (up to 3 candidates, "in 100% of photos"). It needs at least 3 same-sized photos; otherwise drag the box by hand.
* **Clean this photo** / **Clean all photos where this logo is found** / **Clean ALL photos at this exact spot**.
  The "found" mode checks every photo for the logo and **leaves photos that don't have it untouched**.
  **The logo moves between photos** also looks for it elsewhere in each photo (follows a moving logo).
* Only the logo's own pixels are changed (its real shape, not a whole rectangle). Everything else in the
  photo is bit-for-bit identical.
* **Non-destructive:** your original photos are never modified. A cleaned copy is saved in the app's own folder and
  the photo points at it (so the Photos list, preview and export all use it); **Restore this photo / Restore ALL**
  switch back. Cleaning twice never stacks - it always starts again from the original. Cleaned copies are capped at
  4096 px on the long edge so a huge photo cannot run the phone out of memory.

Code: `app/src/main/java/com/videoslidemaker/app/logoclean/` (maths in `Imaging.kt`, detection and matching in
`LogoDetector.kt`, repainting in `LogoPaint.kt`, photo reading/writing in `LogoCleaner.kt`, the "clean all" logic
in `LogoCleanController.kt`; screen in `ui/components/LogoCleanerDialog.kt`).

It was designed and **measured first in Python** (`tools/logoclean-reference/`), then ported:

* `python3 demo.py` runs it on the bundled screenshot (`sample/before_after.png`): 0.72 % of the pixels change, all inside the logo.
* `python3 evaluate_matcher.py`: over 240 synthetic photos (real logo pasted on varied backgrounds) the "is the logo here?"
  check made 0 false positives and 0-2 % false negatives at the thresholds used.
* Removal beat OpenCV's Telea inpainting on every background type tested (32-36 dB vs 31-34 dB inside the repaired area).
* `python3 mirror_scenarios.py` produces the numbers that `LogoCleanTest.kt` asserts for the Kotlin code.

Honest limits: auto-detect assumes the logo sits at the same place in several photos of the same size (typical for
frames cut from one video). A busy, sharp background behind the logo cannot be reconstructed exactly - Remove then
looks smooth rather than perfect. As with the rest of this project, the Kotlin has **not been compiled** where it
was written; the first `Build` on GitHub (or in Android Studio) is the first real compile and test run.

## NEW in 2.2: Voice changer (pitch, "make it sound human", effects)

A **🎚️ Voice changer** card now appears on the **Script** screen and under the player on the **Preview**
screen (whenever sound is on). It works on **both** sounds - your own uploaded recording and the phone's
voice - in the preview and in the exported video. It never touches background music.

* **🎵 Pitch** - higher or lower **without changing the speed**, from -24 to +24 semitones in steps of
  0.01 (one cent). Choose how far the slider reaches (**Fine ±1**, ±3, ±12, ±24) so tiny changes and big
  changes are both easy; use the **-1 / -0.1 / -0.01 / +0.01 / +0.1 / +1** buttons; or type an exact value.
* **🧑 Make it sound human** - for AI voices (ElevenLabs etc.) that sound too clean: a tiny natural pitch
  drift, warmth, gentle dynamics, a faint room tone and small room reflections, plus optional soft **breaths**
  in real pauses. Try 40-60 %. It cannot fix robotic *delivery*; it removes the "too perfect" studio-clean sound.
* **🎭 Voice effects** - Aqua (underwater), Revolve 8D (circles around your head - use headphones), Room,
  Hall, Cave, Echo, Robot, Telephone, Megaphone, Whisper; each with a strength slider (Aqua and Revolve
  also have a speed slider).
* **▶ Hear a sample** plays about 8 seconds of your recording (or one sentence of the phone's voice) with the
  current settings. While the preview plays you can also move the sliders; the sound restarts at the same spot.

Notes: big pitch changes (beyond about ±4) also change the *character* of the voice (chipmunk / giant) because
the voice's tone shifts with the pitch. A stereo recording is mixed to one channel for processing (it is a voice
tool); the result is stereo again. With the voice changer **off**, nothing changes from 2.1.

The effect code lives in `app/src/main/java/com/videoslidemaker/app/voicefx/` and was designed and measured
in `tools/voicefx-reference/` (Python); `VoiceFxTest.kt` checks the Kotlin code against that reference.
As with the rest of this project, it has not been compiled in the place it was written - the first
`Build` run on GitHub (or Android Studio) is the first real compile.

## How to open and build this (with a computer)

1. Install **Android Studio** (Koala/2024.1 or newer).
2. `File → Open`, select the `VideoSlideMaker` folder, let Gradle sync (it will download the
   wrapper automatically — no network is available in the sandbox this was written in, so the
   wrapper jar itself isn't bundled, but Android Studio fetches it on first sync).
3. Run on a device/emulator with **Android 8.0 (API 26) or newer**.
4. If Android Studio suggests a newer Kotlin/AGP/Compose BOM version during sync, accepting the
   upgrade is safe — the versions pinned here are simply the ones current at the time of writing.
5. Optional cleanup: `Code → Optimize Imports` across the project removes a handful of harmless
   unused imports left over from earlier drafts of a few files.

I wrote and reviewed every file carefully, but I don't have an Android SDK or emulator in the
sandbox this was built in, so **this hasn't been compiled or run**. Treat it as a complete,
serious first build rather than a guaranteed zero-error one — if Android Studio flags anything
small (an import, a version mismatch), it'll point straight at the line.

## Building this with only an Android phone (no computer)

This project now includes `.github/workflows/build.yml`, which tells GitHub to compile the APK
on its own servers every time you push code — GitHub's machine does the compiling, not your
phone, so you never need Android Studio or the Android SDK on the device itself.

### 1. Get the unzipped project onto GitHub

GitHub's website doesn't unzip files you upload — you need to extract the folder first and
push it with `git`, which is easiest through a terminal app. **Termux** (a real Linux terminal
for Android) is the most reliable way to do this from just a phone:

1. Install **Termux** from F-Droid (not the outdated Play Store version): f-droid.org
2. Open Termux and run, one line at a time:
   ```
   termux-setup-storage
   pkg update -y
   pkg install -y git gh unzip
   cd ~/storage/downloads
   unzip VideoSlideMaker-Android.zip
   cd VideoSlideMaker
   git init && git add . && git commit -m "Initial commit"
   ```
3. Sign in to GitHub from the terminal (opens a browser to confirm — no typing passwords):
   ```
   gh auth login
   ```
   Choose **GitHub.com** → **HTTPS** → **Login with a web browser**, then follow the one-time
   code it shows you.
4. Create the repo and push everything in one command:
   ```
   gh repo create VideoSlideMaker --public --source=. --remote=origin --push
   ```
   (If that command errors, create an empty repo at github.com/new instead, then run
   `git remote add origin <the URL it gives you>` followed by `git push -u origin main`.)

A **public** repo is simplest — GitHub Actions is completely free and unlimited there. Private
repos also work and include 2,000 free build-minutes a month, more than enough for occasional
builds — just know the code stays visible to you only either way you choose the visibility.

### 2. Let GitHub build it

Once pushed, go to your repo on github.com → the **Actions** tab. You'll see "Build APK"
running (takes a few minutes). When it finishes with a green check, open that run and scroll to
**Artifacts** — download `VideoSlideMaker-debug-apk`. It downloads as a `.zip` (GitHub always
wraps artifacts that way); extract it with any file manager app to get the actual `.apk`.

### 3. Install it on your phone

Tap the `.apk` file. If Android blocks it, it'll offer a link to **Settings → allow installs
from this app** (usually your browser or file manager) — enable that once, then tap the file
again to install.

If a build fails, open the failed run in the Actions tab and check which step turned red — it
usually points straight at the problem (most often a version number Google has since bumped;
the fix is normally just updating that one number in `app/build.gradle.kts`).



1. **Script** — upload a `.txt` file of `timestamp - sentence` lines.
2. **Photos** — add a pool of photos, reorder, delete.
3. **Match** — go sentence by sentence, listen to it spoken aloud, split or merge sentences,
   and tap a photo to assign it.
4. **Preview** — play through the matched sequence at a faster preview speed.
5. **Export** — pick aspect ratio / resolution / zoom / fade, then render the real video.

Every one of these carried over — nothing was removed.

## Look, themes and accessibility

The app now has a proper **light** theme (calm, warm off-white, low glare) and a proper **dark**
theme. The old dark theme was tinted blue/purple; the new one is a true neutral charcoal (and
there is an optional pure-black version for OLED screens).

Two controls are always on screen, in the top bar:

- **Sun / moon button** - flips between light and dark in one tap.
- **Sliders button** - opens *Appearance & layout*, where you can set:
  - **Light or dark**: System (follows the phone), Light or Dark.
  - **Accent colour**: 20 presets or *Custom* (any colour, rainbow slider).
  - **Text size**: Small / Default / Large / Larger / Largest, added *on top of* the phone's own font size.
  - **Dark mode style** and **Light mode style**: seven and six background looks.
  - **Layout**: Classic / Compact / One-hand / Sharp, or step bar position, spacing and corners one by one.
  - **High contrast**: pure black/white text and stronger outlines on buttons and fields.

Everything applies instantly and is remembered (`ui/theme/Appearance.kt`).

Other usability changes that came with it:

- **System Back goes back one step** (it used to close the app mid-project), matching the on-screen "Back" buttons.
- **Photos, Preview and Export scroll properly.** Before, the Photos list shared a fixed-height column with the header and buttons and could shrink to almost nothing; Preview and Export could push their bottom buttons off-screen.
- **Bigger tap targets**: every button/control is at least 48dp; the photo row's arrows, delete, the +/- steppers and the remove buttons on thumbnails were 18-36dp before.
- **Not colour alone**: warnings/notes/success have an icon, finished steps show a tick, chosen options show a tick or thicker outline.
- **Screen readers (TalkBack)**: switches, tabs, chips and buttons announce their role and state, icon buttons have real names, and dragging the text label has "Move left/right/up/down" actions as an alternative.
- The text cursor is now visible in dark mode (it was black on near-black).
- **See a photo full size.** Photo tiles on the Match screen now show the *whole* picture (they used to crop it to a square, cutting off subtitles). Tap the magnifier on a tile, or press and hold it, to open the full-size viewer: pinch to zoom, drag to move, double-tap to zoom/reset, and a button to use that photo. Tapping the "Currently assigned" photo, or a thumbnail on the Photos screen, opens the same viewer (`ui/components/ImagePreviewDialog.kt`).
- **Browse all photos (fast picking).** On the Match screen, the **"Browse all photos — full size"** button opens a full-screen browser (`ui/components/PhotoBrowserDialog.kt`): photos are shown whole at their real shape (Large = 1 per row, Medium = 2, Small = 3), the sentence you are matching stays pinned at the top with arrows for previous/next sentence, tapping a photo uses it and the browser stays open (so with auto-advance on you can pick photo after photo), photos already placed are tagged "Used · #N", and **Unused only** hides them. The magnifier on a photo opens the pinch-to-zoom viewer.

How it works: screens never hard-code colours. `ui/theme/Color.kt` defines the palettes, and
`Accent`, `TextMain`, `CardBg`, `Outline`... resolve to whichever palette is active. To change a
colour, edit it there. `ThemeContrastTest` checks every theme/accent combination against WCAG
contrast ratios (4.5:1 for text, 3:1 for outlines), so a readability regression fails the build.

## Preview: smooth playback, and your original recording as the sound

**Sound choice.** On the Preview screen, under the play controls, pick what you hear with the photos:
**🔊 Voice** (the phone's text-to-speech reads each sentence), **🎧 Original** (your own recording), or
**🔇 Off**. The same choice is used by the exported video, and can also be changed on the Script screen
("Sound comes from"). The recording is the one chosen under *Automatic timestamp alignment* on the
Script screen (or on the Match screen); the Preview offers a button to choose it if none is set yet.

**How the original recording is kept in line with the photos.** The recording's clock is the script's
clock (a timestamp of 12.5 s means 12.5 s into the recording). While it plays, the recording's own
position is the master clock: the preview checks it ten times a second and, if the photos ever drift
more than 0.12 s away from what you hear, pulls them back. Pressing play, previous/next, or dragging
the new scrub bar all restart the recording at exactly that point, so you can jump to any sentence
and check that its photo appears when its words are spoken. In the export the recording is decoded in
small streaming pieces (so a multi-hour file does not fill memory), placed on the same clock, and
cut at the end of the video.

**Why the preview was choppy, and what changed.** The playing position used to live in the app's one
shared state and was updated 20 times a second, so every update redrew the whole app, and the zoom
could only move in 20 steps per second. Now: the position is kept separately and ticks once per
screen frame; only the photo layer (drawn with `graphicsLayer`), the clock text, the scrub bar and
the name labels read it, so nothing else is redrawn; the next two photos are loaded into memory ahead
of time (no blank flash at a cut); the outgoing photo keeps moving on its own time window while it
fades (it used to jump); and the text-to-speech voice is no longer re-initialised on every sentence
(that could stall the screen at each slide change).

## Timestamps

Timestamps can be typed in any of these styles — no single format is required, and leading
zeros and surrounding spaces don't matter:

| You type                                   | Meaning                         |
|--------------------------------------------|---------------------------------|
| `12`, `12.5`                               | seconds                         |
| `0:05`, `1:23`, `00:00`                    | minutes:seconds                 |
| `00:00.000`, `0:02.5`                      | minutes:seconds.milliseconds    |
| `00:00:00`, `01:23:45`                     | hours:minutes:seconds           |
| `00:00:00.000`, `01:23:45.500`             | hours:minutes:seconds.milliseconds |
| `00:00:000`, `1:23:456`                    | minutes:seconds:milliseconds    |

Every timestamp is converted to whole **milliseconds** by `data/TimestampParser.kt` (integer
arithmetic only). A three-part value with no decimal point whose last part is exactly three
digits is read as minutes:seconds:milliseconds; any other three-part value is
hours:minutes:seconds. Seconds (and minutes, when hours are given) must be 0–59; the largest
accepted time is 99:59:59.999. Invalid entries are rejected with a message that says why, and
any script line that is skipped is listed on the Script screen with its line number.
Times are shown as `m:ss` or `h:mm:ss`, with `.mmm` added only when the time has milliseconds.
Unit tests: `./gradlew testDebugUnitTest`.

## Automatic timestamp alignment

Script timestamps are often a little off — and the error is rarely constant: it commonly grows
through a long recording (say +0.8 s at 5 min, +1.4 s at 20 min, +2.1 s at 45 min). This feature
treats the **audio/video recording as the source of truth** and corrects each line against it.

**Using it** (Script screen → "Automatic timestamp alignment"): choose the recording (any audio
or video file), tap *Analyze timestamps*. For every line you see the original timestamp, the
timestamp detected in the audio, the difference (e.g. `+1.430 s`), the corrected timestamp, a
confidence score, and when the spoken line ends. Per line you can **Keep original** or **Apply
correction**; or **Apply all high-confidence** in one tap. On the review screen, **Keep original**
and **Apply correction** buttons at the top of the list act on every line at once (or only the
lines in the selected tab, e.g. *Needs review*). Lines the app isn't sure about are
marked **Needs review** with a plain-language reason and are never changed unless you apply them.
There is also an opt-in switch to apply high-confidence corrections automatically (off by
default). The script's original timestamp is always kept (`SentenceSlide.originalTimestampSec`),
survives restarts, and **Restore all original timestamps** puts everything back.

**Hearing the original recording on the Match screen**: once a recording is chosen, the Match
screen has an *Original recording* panel. **▶ Play original** plays only the current sentence's
slice of your recording (from its timestamp to the next sentence's), so every sentence is its own
part without any file being cut. **Starts** and **Ends** each have −1 / −0.5 / −0.1 / +0.1 / +0.5 / +1
second buttons; the sentence replays after every nudge, and the new time is saved with the
script's original kept (so *Restore all original timestamps* still works). If the analysis has run,
**Use the detected start** applies what it found for that sentence.

**How it works** (`align/`, all integer milliseconds):

1. `RecordingReader` decodes the audio in one streaming pass into 10 ms loudness frames (no raw
   audio held in memory, so multi-hour recordings are fine). Frame times are exact for any
   sample rate and honour where the audio track starts.
2. `SpeechAnalysis` finds speech with an adaptive noise floor (re-estimated every 5 s), rejects
   steady hum/tones, and places each onset at the *foot* of the rise rather than where it
   crosses a threshold. Loudness dips inside continuous speech become weaker candidate points.
3. `CoarseDrift` searches the whole recording at ±40 s for how far the script is from the audio,
   window by window. The lag may change slowly (drift) or **all at once** (a step), at a cost proportional to the change.
   Where no window has a clear peak it says so, and nothing is extrapolated across that stretch.
4. `TimestampAligner` lets every line choose its own onset by dynamic programming: onsets after
   real pauses are preferred; lines stay in order; the speech between two onsets must match how
   long the earlier line's text takes to say; neighbours should have *similar* error, but only
   mildly. Lines can be skipped (text not in the audio, or speech not in the script) so one bad
   line can't push the rest off. Confident anchors then re-centre the search and the speaking
   rate is re-estimated (two repeats).
5. The audio engine scores each pick (how much worse the best *different* answer is, how clear the pause was, how well
   the speech length matches the text, how clean the recording is, whether the fine result agrees with a coarse estimate that
   really exists for that stretch). `LexicalAnchors` (optional) places each line from the recognized words, `LineFusion`
   fuses the two, turns the result into a **calibrated probability**, estimates lines with no evidence from their neighbours,
   and decides the status. A line is "high" only at 95 %+ and only if every hard gate passes.
6. `AlignmentApplier` refuses any change that would put lines out of order or less than 100 ms
   apart, because the preview, export and Match screen all rely on slides being in time order.

**Important limits (audio only).** Without a speech model it does **not** recognise words: it checks pause structure and
how long speech lasts against how long your text should take. If the wrong words are spoken at a similar rhythm it can't
tell (a shuffled script was still rated high 38 % of the time; with the speech model that falls to about 1 %). See *NEW in
2.12.0* above for the measured accuracy of the current engine and its limits. Speech-length modelling is tuned on
Latin-script text and is rougher for Devanagari (it self-calibrates the speaking rate per recording, but has seen less testing
there). Tests: `align/` under `app/src/test` (synthetic speech generator + ground-truth assertions + the golden test).


## Big folders (10 GB and more)

"Add a Whole Folder" now scans the chosen folder **and every sub-folder**, accepts photos even if
the storage app reports a generic file type, sorts frames in natural order (frame2 before
frame10), shows a live "photos found" count while scanning, and tells you plainly if Android
blocked the folder (it refuses Downloads and the very top of storage - pick a folder inside).
Only each photo's header is read, so folder size in GB doesn't matter - only the number of files.
Preview, Match and Export no longer rebuild their photo lists on every tick, which is what made
the screen freeze with thousands of photos.

## The two problems you asked me to fix

**"Handle large file work properly."** The original app reads every photo into memory as a
base64 string via `FileReader`, and keeps all of them there for the whole session — fine for a
few small images, but slow and memory-heavy for a phone camera roll. `data/ImageStore.kt`
instead keeps only a content `Uri` and true pixel size per photo; thumbnails are decoded
downsampled (`BitmapFactory.Options.inSampleSize`) to whatever size is actually on screen, and
full resolution is only ever decoded one photo at a time, right before that photo's export
frames are rendered.

**"The audio."** In the original, the on-device voice (browser `speechSynthesis`) was only ever
used live, while matching a sentence to a photo — the exported video itself was always silent.
That's the one place I changed the app's actual behavior rather than just its plumbing: the same
voice is now synthesized to file and baked into the exported video as a real, timed audio track
(see "New features" below). I flagged this clearly rather than assuming — you can turn narration
off per-project on the Script screen if you'd rather keep silent exports.

## Architecture

```
app/src/main/java/com/videoslidemaker/app/
├── model/         Plain data classes: SentenceSlide, PoolImage, ExportSettings, UiState
├── data/          Script parsing, Uri-based photo storage, JSON draft autosave
├── adjust/        Adjust timestamps: pure planner/preview/apply/undo engine, the log codec, and the controller
├── check/         Audio-transcript accuracy checker: pure-Kotlin engine (tokenizer, aligner, verdicts) + Vosk recognizer + model store + controller
├── tts/           Android TextToSpeech wrapper (live speech + synthesize-to-file)
├── export/        The video pipeline (see below)
├── viewmodel/     AppViewModel — single StateFlow<UiState>, one method per user action
├── ui/theme/      Background styles, accent colours, colour maths (ColorMath.kt), layout sizes (AppLayout.kt), saved appearance prefs, typography
├── ui/components/ Reusable Compose widgets (cards, toggles, buttons, step bar)
├── ui/screens/    One file per wizard step
├── MainActivity.kt          Compose host + system file pickers (SAF)
└── VideoSlideMakerApp.kt    Notification channel setup
```

**Export pipeline** (`export/`): `VideoExportEngine` is the conductor. It computes the output
resolution, builds the final photo sequence (with the same "fall back to next unused photo"
rule as the original), synthesizes the combined audio timeline first, then renders and encodes
video frame-by-frame:

- `FrameRenderer` — cover-fit crop + Ken Burns zoom + fade, same math as the original canvas code.
- `Yuv420Writer` — converts each rendered frame to the YUV420 the encoder needs.
- `VideoEncoder` / `AudioEncoder` — MediaCodec H.264 / AAC, real presentation timestamps.
- `MuxerHolder` — combines both into one `.mp4` via MediaMuxer.
- `NarrationAudioBuilder` / `AudioDecoder` / `PcmResampler` / `WavUtils` — build the narration +
  music audio timeline described above.
- `ExportForegroundService` — runs all of this off the UI thread with a progress notification.

This replaces the original's `canvas.captureStream()` + `MediaRecorder`, which depends on
whatever codec the phone's browser happens to support and paces frames with `setTimeout`. The
native pipeline uses the device's real encoder with exact per-frame timing, so it doesn't drop
or duplicate frames and doesn't depend on browser codec support.

## What I improved (same feature, done more reliably)

- **Photo handling** — Uri-based, never loads a full photo into memory unless it's actively
  being drawn into a frame (see above).
- **Video encoding** — native MediaCodec/MediaMuxer instead of browser MediaRecorder.
- **Export reliability** — runs in a foreground service, so it keeps going if you switch apps,
  lock the screen, or the export takes a few minutes on a long project.
- **Saving the result** — goes straight into `Movies/VideoSlideMaker` via MediaStore (or the
  legacy public Movies folder on Android 9 and below), instead of a browser download.
- **Split-at-cursor** — uses Compose's real text cursor position instead of a DOM Range hack.

## New features added

- **Per-photo time control (latest addition).** Each photo on the Photos screen now has a
  tappable "⏱ 0:03" chip — tap it, type a time like `2:30` or `15:00`, save. To make that
  meaningful, the Script step became fully optional: if you don't load a script, the app
  automatically treats your photo pool as the timeline, one slide per photo in order, using
  each photo's own time. Match screen is skipped automatically in that case (there's nothing to
  match — each photo already maps to itself); Preview and Export both use whichever timeline is
  active. Loading a script still works exactly as before and takes priority if present.
- **Narration baked into the video** (see above) — on-device TTS per sentence, placed at that
  sentence's exact timestamp, mixed into the final MP4's audio track. Toggle it off on the
  Script screen if you want a silent export like before.
- **Optional background music** — pick an audio file on the Export screen; it's decoded, looped
  or trimmed to the video's length, and mixed underneath the narration at an adjustable volume.
- **Auto-saved project draft** — if you switch apps, rotate the phone, or Android reclaims memory
  in the background, your script, photos, and settings are restored automatically next time you
  open the app (`data/ProjectRepository.kt`). The original had no protection against a lost tab.
- **Share button** after export, using Android's native share sheet.

## Deliberately not changed / not added (so you know where I drew the line)

- The original's CSS hinted at drag-to-reorder photos (`.img-drag` classes) but never actually
  wired it up — only the up/down buttons worked. I kept the up/down buttons (100% reliable) and
  didn't add drag gestures on top, since a hand-rolled drag implementation is one of the riskier
  things to get right without being able to test it. It's a clean follow-up if you want it.
- The launcher icon is a simple placeholder (a purple square with a play glyph) so the project
  compiles out of the box — swap it via Android Studio's `Image Asset` tool for a polished icon.
- Typography uses the system font rather than bundling the original's Space Grotesk/Inter font
  files, again to avoid adding a dependency I couldn't verify without a network connection. Swap
  `FontFamily.Default` in `ui/theme/Type.kt` for bundled `.ttf` files if you want an exact match.

## Permissions

No new permission was added for the accuracy checker: the speech model's .zip and the recording are both picked with the system
file picker, and recognition is offline.

No new permission was added in 2.12: the words come from the same offline speech model.

Only `POST_NOTIFICATIONS` (for export progress) and the foreground-service permissions are
requested up front. Photos, script, and music are all picked through Android's Storage Access
Framework, so the app never asks for broad photo-library or storage permission.
