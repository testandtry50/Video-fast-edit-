# Putting VideoSlide Maker on Google Play (2.9.1)

This file is the short list of everything between "the code is done" and "it is live". Part 1 is what was changed in
the project so Google Play will accept it. Part 2 is what only **you** can do (a signing key, and the forms in Play
Console). Part 3 is the test list to run on a real phone before you press "Roll out".

## Part 1 - what was changed in the project (and why)

| What | Why |
|---|---|
| `targetSdk` and `compileSdk` **34 -> 36** | Since 31 Aug 2026 Google Play only accepts new apps **and updates** that target Android 16 (API 36). With 34 the upload is refused. |
| Android Gradle plugin **8.5.0 -> 8.9.1**, Gradle **8.7 -> 8.11.1**, JVM memory 2 GB -> 4 GB | 8.9.1 is the first plugin that supports API 36 (Android's own compatibility table), and it needs Gradle 8.11.1. R8 (the release shrinker) needs the extra memory. |
| `versionCode` **1 -> 30**, `versionName` **2.2.0 -> 2.9.1** | Every upload needs a higher `versionCode` than the last. **If you already uploaded a build with a higher code, raise it again in `app/build.gradle.kts`.** |
| **Edge-to-edge** (`enableEdgeToEdge()` + insets in `MainActivity`, the settings page and the full-screen photo windows) | From Android 15, apps that target 35+ are always drawn behind the status and navigation bars. Without this, the top bar and the bottom buttons would sit under them. |
| **Foreground-service timeout** (`onTimeout` in `LogoCleanService` and `ExportForegroundService`) | From Android 15 a "data sync" service is ended after about 6 hours in a day, and **must stop within seconds or the app is crashed**. A 100,000-photo clean can last that long. Now the run stops cleanly, keeps everything finished, and says "press the button again to continue". |
| `android:enableOnBackInvokedCallback="true"` | Predictive back (the app already uses `BackHandler`, nothing else needed). |
| Release **signing from the environment** (`KEYSTORE_PATH`, `KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD`) and a **signed `.aab`** step in `.github/workflows/build.yml` | Play wants an Android App Bundle signed with your upload key. The key is never stored in the project. |
| A **16 KB page-size** report step in the workflow | Play rejects apps whose native libraries are not 16 KB-aligned. This app has no native code of its own (the only native library comes from Compose and is aligned by the new plugin); the step prints the result so you can see it. |

Already fine, checked in the project: only the permissions `POST_NOTIFICATIONS`, `FOREGROUND_SERVICE`,
`FOREGROUND_SERVICE_DATA_SYNC`, `WAKE_LOCK` (and `WRITE_EXTERNAL_STORAGE` up to Android 9). **There is no `INTERNET`
permission**, and photos/audio come through the system file picker, so nothing leaves the phone.

## Part 2 - what only you can do

### 2.1 Make the upload key (once, on any computer with Java)
```
keytool -genkeypair -v -keystore upload-key.jks -alias upload -keyalg RSA -keysize 2048 -validity 10000
```
Keep `upload-key.jks` and its passwords somewhere safe (a password manager and a backup). Play App Signing keeps the
real signing key; this is only your *upload* key, and Google can reset it if you lose it - but do not lose it.

### 2.2 Give the key to GitHub (once)
Repository -> Settings -> Secrets and variables -> Actions -> New repository secret:

| Secret | Value |
|---|---|
| `KEYSTORE_BASE64` | the key file as text: `base64 -w0 upload-key.jks` (on a Mac: `base64 -i upload-key.jks`) |
| `KEYSTORE_PASSWORD` | the keystore password |
| `KEY_ALIAS` | `upload` (or the alias you chose) |
| `KEY_PASSWORD` | the key password |

### 2.3 Build the bundle
Push to `main` (or Actions -> Build APK -> Run workflow). When it finishes, download the artifact
**VideoSlideMaker-release-aab**: `app-release.aab` is the file to upload. `mapping.txt` next to it is the
de-obfuscation file (the bundle already carries it; keep this copy anyway).
Without the secrets the workflow still builds the debug APK and runs the tests - it just skips the bundle.

### 2.4 Play Console forms (App content)
* **Foreground service declaration** (needed for `dataSync`). Suggested wording: *"The app cleans logos, subtitles and text
  out of thousands of the user's photos, and renders the user's video. Both jobs can take many minutes to hours, are
  started by the user, show a progress notification, and can be stopped at any time. If they were not a foreground
  service Android would stop them when the app is not on screen."*
  Both services use type `dataSync`. Record a short screen video of a clean run with the notification showing, if Play asks.
* **Data safety**: the app declares no internet access and keeps photos on the device, so "no data collected, no data
  shared" matches the code - but you are the one who answers, so check it against how you use the app.
* **Privacy policy URL**: add one even if it just says "everything stays on your phone". It is easy to add now and
  painful to be asked for later.
* **Content rating**, **target audience**, **ads: none**, store listing (icon, 2+ phone screenshots, short and full text).
* New *personal* developer accounts may have to run a **closed test** (a number of testers for some days) before they
  can publish to production. The rule changes - read what Play Console shows you.

## Part 3 - test on a real phone before you roll out
Use a phone with **Android 15 or 16** if you can (the edge-to-edge change only shows there), and an older one too.

1. Open every step (Script, Photos, Match, Text, Preview, Export): the top bar must not touch the status bar, the bottom
   buttons must not touch the navigation bar, the keyboard must not hide the text box you type in.
2. Settings page (the paint icon) and the three full-screen photo windows: same check, light and dark theme.
3. **Cleaner**: Photos -> *Remove or blur a logo, icon, subtitle or text*.
   * Logo, one photo -> Remove / Blur / Remove + Blur.
   * Subtitle, one photo -> the box starts as a strip at the bottom; Remove; check no ghost letters; Restore.
   * Subtitle, **A range** (Start here / End here), then **All**. Photos with no caption must be left alone.
   * Clean the **logo, then the subtitle** on the same photos: the logo must stay gone. Restore brings back the original.
   * Match screen -> *Remove or blur ... this segment, a range, or all*: opens on the segment you were looking at.
4. Match screen, *All segments* strip: tap a segment (must jump at once), tap another **twice quickly** (must scroll the photo
   list to that photo and show it in yellow with "Found it"; with 1,000+ photos too). Try a segment you removed the photo from.
5. Close the app in the middle of a big run, open it again: the finished photos are still cleaned, and pressing the button
   again carries on.
6. Export a short video with narration. Export a long one and lock the screen.
7. Turn on "Don't keep activities" (Developer options) and rotate: nothing is lost.

## What was NOT verified here
The code was written and the algorithms were measured in a sandbox with **no Android SDK, Kotlin compiler or network**, so
the Kotlin was never compiled and the app was never run. The first GitHub build is the real compile; read any red error
top to bottom, they are usually one-line fixes. Everything numeric about the text finder was measured in Python
(`tools/textclean-reference/`); the Kotlin unit tests assert those same numbers.
